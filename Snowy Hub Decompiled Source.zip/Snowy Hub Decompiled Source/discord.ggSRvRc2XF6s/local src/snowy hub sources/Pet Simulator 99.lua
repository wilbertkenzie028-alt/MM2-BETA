local Env = getfenv();
local J = {};
local v1 = {...};
local r1 = true;
local r2 = string.gmatch;
local function r3(...)
    error("Tamper Detected!");
    return; 
end;
local r4 = false;
local v2 = pcall(function(...)
    r4 = true;
    return; 
end) and r4;
local r5 = math.random;
local v3 = table.concat;
local function v4(...)
    while true do
        l1 = l2;
        l2 = l1;
        r3(); 
    end;
    return; 
end;
local r6 = table and table.unpack or unpack;
local r7 = r5(3, 65);
local v5 = {
    pcall(function(...)
        return "RiTLgsaV" / (5482570 - "ybFlquNKMFKYHm" ^ 7791390); 
    end)
};
local v6 = v5[2];
local r8 = tonumber(r2(tostring(v6), ":(%d*):")());
for G = 1, r7 do
    r9 = G;
    r10 = math.random(1, 100);
    r11 = r5(0, 255);
    r12 = r5(1, r10);
    r13 = r5(1, 2) == 1;
    r14 = v6.gsub(v6, ":(%d*):", ":" .. tostring(r5(0, 10000)) .. ":");
    u = {
        pcall(function(...)
            if r5(1, 2) == 1 or r9 == r7 then
                r1 = r1 and r8 == tonumber(r2(tostring(({
                    pcall(function(...)
                        return "Tyb9OTEkZGEUqQ" / (5902331 - "P704MtkEbkPs9mN" ^ 11389524); 
                    end)
                })[2]), ":(%d*):")());
            end;
            if r13 then
                error(r14, 0);
            end;
            v1 = {};
            for o = 1, r10 do
                v1[o] = r5(0, 255); 
            end;
            v1[r12] = r11;
            return r6(v1); 
        end)
    };
    if r13 then
        r1 = r1 and (pcall(function(...)
            if r5(1, 2) == 1 or r9 == r7 then
                r1 = r1 and r8 == tonumber(r2(tostring(({
                    pcall(function(...)
                        return "Tyb9OTEkZGEUqQ" / (5902331 - "P704MtkEbkPs9mN" ^ 11389524); 
                    end)
                })[2]), ":(%d*):")());
            end;
            if r13 then
                error(r14, 0);
            end;
            v1 = {};
            for o = 1, r10 do
                v1[o] = r5(0, 255); 
            end;
            v1[r12] = r11;
            return r6(v1); 
        end) == false and u[2] == r14);
    end; 
end;
r1 = r1 and 0 == 0;
if r1 then
    r17 = math.floor;
    o = math.random;
    r18 = 0;
    r19 = 2;
    r20 = {};
    v5 = {};
    N = 0;
    for X = 1, 256 do
        v5[X] = X; 
    end;
    v6 = #v5 == 0;
    X = table.remove(v5, o(1, #v5));
    r20[X] = string.char(X - 1);
    if #v5 == 0 then
        r21 = {};
        r23 = {};
        r15 = setmetatable({}, {
            ["__index"] = r23,
            ["__metatable"] = nil
        });
        task.wait(0.5);
        o = game;
        o.IsLoaded(o);
        task.wait();
        o = game;
        if o.IsLoaded(o) then
            o = game;
            o = game;
            r24 = o.GetService(o, "RunService");
            v2 = game;
            r25 = v2.GetService(v2, "UserInputService");
            j = game;
            r26 = j.GetService(j, "TweenService");
            v4 = game;
            r27 = v4.GetService(v4, "ReplicatedStorage");
            r28 = o.GetService(o, "Players").LocalPlayer;
            r29 = workspace.CurrentCamera;
            local function r30(...)
                return r28.Character; 
            end;
            local function r31(...)
                v1 = r30();
                if v1 then
                    b = v1.FindFirstChild(v1, "HumanoidRootPart");
                end;
                return v1; 
            end;
            local function r32(...)
                v1 = r30();
                if v1 then
                    b = v1.FindFirstChildOfClass(v1, "Humanoid");
                end;
                return v1; 
            end;
            r33 = {
                ["AutoFarm"] = false,
                ["AutoHatch"] = false,
                ["AutoCollect"] = false,
                ["AutoQuest"] = false,
                ["AutoRebirth"] = false,
                ["SpeedBoost"] = false,
                ["Fly"] = false,
                ["Noclip"] = false,
                ["AntiAFK"] = false,
                ["InfJump"] = false,
                ["ESP"] = false
            };
            r34 = {
                ["SpeedValue"] = 50,
                ["FlySpeed"] = 80,
                ["FarmRadius"] = 40,
                ["HatchEgg"] = "Best Egg",
                ["HatchAmount"] = 1
            };
            r39 = "Idle";
            local function r40(arg1_2, ...)
                y = r31();
                if y then
                    y.CFrame = CFrame.new(arg1_2 + Vector3.new(0, 3, 0));
                end; 
            end;
            local function r41(arg1_3, ...)
                v1 = arg1_3;
                v1.lower(v1);
                W = r27;
                o = W[2];
                W = W[1];
                for M, j in ipairs(W.GetDescendants(W)) do
                    v2 = M;
                    v4 = j.IsA(j, "RemoteEvent") or j.IsA(j, "RemoteFunction");
                    if v4 then
                        v3 = j.Name;
                        v4 = v3.lower(v3);
                        if v4.find(v4, v1.lower(v1), 1, true) then
                            return j;
                        else
                        end;
                    end; 
                end;
                return; 
            end;
            local function w(arg1_4, ...)
                r42 = {...};
                v3 = r27;
                r43 = v3.FindFirstChild(v3, arg1_4, true);
                W = r43;
                if W then
                    W = r43;
                    b = W.IsA(W, "RemoteFunction");
                end;
                if W then
                    return pcall(function(...)
                        v3 = r43;
                        return v3.InvokeServer(v3, table.unpack(r42)); 
                    end);
                end;
                return; 
            end;
            local function u(arg1_5, ...)
                r44 = {...};
                v3 = r27;
                r45 = v3.FindFirstChild(v3, arg1_5, true);
                W = r45;
                if W then
                    W = r45;
                    b = W.IsA(W, "RemoteEvent");
                end;
                if W then
                    pcall(function(...)
                        v3 = r45;
                        v3.FireServer(v3, table.unpack(r44));
                        return; 
                    end);
                end;
                return; 
            end;
            r46 = {
                "coin",
                "chest",
                "diamond",
                "gem",
                "orb",
                "crystal",
                "star",
                "token",
                "breakable",
                "object",
                "obstacle",
                "block",
                "box",
                "barrel",
                "crate",
                "jar"
            };
            local function r47(arg1_6, ...)
                v1 = arg1_6;
                y = v1.lower(v1);
                W = r46;
                W = 21[1];
                o = 21[2];
                for M, j in ipairs(W) do
                    v2 = M;
                    if y.find(y, j, 1, true) then
                        return true;
                    else
                        
                    end; 
                end;
                return false; 
            end;
            local function r48(...)
                v1 = r31();
                if not v1 then
                    return {};
                end;
                r49 = v1.Position;
                r50 = {};
                v2 = workspace;
                W = v2[3];
                v2 = v2[1];
                for W, v4 in v2, ipairs(v2.GetDescendants(v2)) do
                    j = W;
                    r51 = v4;
                    v4 = 93;
                    pcall(function(...)
                        y = r51;
                        if not y.IsA(y, "BasePart") and not y.IsA(y, "Model") then
                            return;
                        end;
                        if not r47(r51.Name) then
                            return;
                        end;
                        v3 = r51;
                        o = r15;
                        M = r16;
                        if v3.IsA(v3, "BasePart") then
                            v1 = r51.Position;
                        else
                            o = r51;
                            M = o.IsA(o, "Model");
                            if M then
                                b = r51.PrimaryPart;
                            end;
                            v3 = r51;
                            if M then
                                v1 = r51.PrimaryPart.Position;
                                y = (v1 - r49).Magnitude;
                                if y > r34.FarmRadius then
                                    return;
                                end;
                                table.insert(r50, {
                                    ["obj"] = r51,
                                    ["pos"] = v1,
                                    ["dist"] = y
                                });
                                return;
                            end;
                            return;
                        end; 
                    end); 
                end;
                table.sort(r50, function(arg1_7, arg2_7, ...)
                    return arg1_7.dist < arg2_7.dist; 
                end);
                return r50; 
            end;
            r52 = {
                "BreakObject",
                "Break",
                "DamageObject",
                "Interact",
                "TouchObject",
                "CollectObject",
                "HitObject"
            };
            local function r53(arg1_8, ...)
                r54 = arg1_8;
                M = r52;
                o = W[3];
                M = W[1];
                for o, v2 in M, ipairs(M) do
                    r55 = v2;
                    pcall(function(...)
                        v1 = r41(r55);
                        if v1 then
                            v1.FireServer(v1, r54);
                        end;
                        return; 
                    end); 
                end;
                v3 = ipairs;
                W = r54;
                v2 = {
                    W.GetDescendants(W)
                };
                o = W[2];
                y = W[1];
                for M, v2 in v3(k(v2)) do
                    W = M;
                    r56 = v2;
                    v3 = r56;
                    if v3.IsA(v3, "ProximityPrompt") then
                        pcall(function(...)
                            fireproximityprompt(r56);
                            return; 
                        end);
                    end; 
                end;
                v3 = r54;
                if v3.IsA(v3, "BasePart") then
                    pcall(function(...)
                        v1 = r31();
                        if v1 then
                            v1.CFrame = CFrame.new(r54.Position + Vector3.new(0, 4, 0));
                        end;
                        task.wait(.05);
                        mouse1click();
                        return; 
                    end);
                end;
                return; 
            end;
            local function r57(...)
                if r35 then
                    return;
                end;
                r39 = "\xf0\x9f\x90\xbe Farming...";
                r35 = task.spawn(function(...)
                    v1 = "AutoFarm";
                    while r33[v1] do
                        v1 = r48();
                        if #v1 == 0 then
                            r39 = "\xf0\x9f\x94\x8d Searching for objects...";
                            task.wait(1);
                            task.wait(.2);
                        end;
                        v2 = r15;
                        r39 = "\xf0\x9f\x90\xbe Breaking " .. #v1 .. " objects";
                        W = v2[3];
                        M = v2[2];
                        for W, v2 in ipairs(v1) do
                            y = W;
                            if not r33.AutoFarm then
                                
                            else
                                r40(v2.pos);
                                task.wait(.05);
                                r53(v2.obj);
                                task.wait(.1);
                            end; 
                        end; 
                    end;
                    r39 = "Idle";
                    return; 
                end);
                return; 
            end;
            local function r58(...)
                r33.AutoFarm = false;
                if r35 then
                    pcall(task.cancel, r35);
                end;
                r39 = "Idle";
                return; 
            end;
            r59 = {
                "HatchEgg",
                "Hatch",
                "BuyEgg",
                "OpenEgg",
                "PurchaseEgg"
            };
            local function r60(arg1_9, ...)
                v1 = arg1_9;
                W = workspace;
                M = W[3];
                o = W[2];
                W = "ipairs";
                for M, j in ipairs(W.GetDescendants(W)) do
                    v2 = M;
                    v3 = j.Name;
                    v4 = v3.lower(v3);
                    if v4.find(v4, v1.lower(v1), 1, true) then
                        if j.IsA(j, "Model") or j.IsA(j, "BasePart") then
                            return j;
                        else
                            
                        end;
                    end; 
                end;
                return; 
            end;
            local function r61(arg1_10, ...)
                r62 = arg1_10;
                y = r60(r62);
                if y then
                    if r31() then
                        v2 = b.IsA(b, "Model");
                        if v2 then
                            v3 = v3;
                            M = b.PrimaryPart and b.PrimaryPart.Position or b.Position;
                            v3 = v3;
                        end;
                        v3 = r31;
                        r40(v2 or b.Position);
                        task.wait(.1);
                    end;
                    j = y.GetDescendants;
                    v3 = ipairs;
                    v2 = {
                        j(y)
                    };
                    W = j[3];
                    v2 = j[1];
                    for W, v4 in v2, v3(k(v2)) do
                        j = W;
                        r63 = v4;
                        v3 = r63;
                        if v3.IsA(v3, "ProximityPrompt") then
                            pcall(function(...)
                                fireproximityprompt(r63);
                                return; 
                            end);
                        end; 
                    end;
                end;
                W = j[3];
                for W, j in j[1], ipairs(r59) do
                    r64 = j;
                    v2 = W;
                    pcall(function(...)
                        v1 = r41(r64);
                        if v1 then
                            v1.FireServer(v1, r62, r34.HatchAmount);
                        end;
                        return; 
                    end); 
                end;
                return; 
            end;
            local function r65(...)
                if r36 then
                    return;
                end;
                r36 = task.spawn(function(...)
                    while r33.AutoHatch do
                        r39 = "\xf0\x9f\xa5\x9a Hatching: " .. r34.HatchEgg;
                        r61(r34.HatchEgg);
                        task.wait(0.5); 
                    end;
                    return; 
                end);
                return; 
            end;
            local function r66(...)
                r33.AutoHatch = false;
                if r36 then
                    pcall(task.cancel, r36);
                end;
                return; 
            end;
            r67 = {
                "drop",
                "coin",
                "gem",
                "diamond",
                "reward",
                "loot",
                "orb",
                "star",
                "pickup",
                "collect",
                "crystal"
            };
            local function r68(arg1_11, ...)
                v1 = arg1_11;
                y = v1.lower(v1);
                W = r67;
                M = 21[3];
                W = 21[1];
                for M, j in W, ipairs(W) do
                    v2 = M;
                    if y.find(y, j, 1, true) then
                        return true;
                    else
                        
                    end; 
                end;
                return false; 
            end;
            local function r69(...)
                if r37 then
                    return;
                end;
                r37 = task.spawn(function(...)
                    while r33.AutoCollect do
                        pcall(function(...)
                            if not r31() then
                                return;
                            end;
                            M = workspace;
                            o = M[3];
                            y = M[2];
                            M = "ipairs";
                            for o, v2 in ipairs(M.GetDescendants(M)) do
                                W = o;
                                if not r33.AutoCollect then
                                    break;
                                else
                                    v3 = not j;
                                    if not (v2.IsA(v2, "BasePart") or v2.IsA(v2, "Model")) then
                                        
                                    else
                                        if not r68(v2.Name) then
                                            
                                        else
                                            if v2.IsA(v2, "BasePart") then
                                                j = v2.Position;
                                            else
                                                v2.IsA(v2, I);
                                                if v2.IsA(v2, "Model") and v2.PrimaryPart then
                                                    j = v2.PrimaryPart.Position;
                                                    if j.Y > 500 then
                                                        
                                                    else
                                                        if (j - r31().Position).Magnitude > 150 then
                                                            
                                                        else
                                                            x = r31();
                                                            if x then
                                                                x.CFrame = CFrame.new(I + Vector3.new(0, 2, 0));
                                                            end;
                                                            G = v2.GetDescendants;
                                                            X = {
                                                                G(v2)
                                                            };
                                                            v6 = G[3];
                                                            for v6, X in G[1], ipairs(k(X)) do
                                                                N = v6;
                                                                r70 = X;
                                                                G = r70;
                                                                if G.IsA(G, "ProximityPrompt") then
                                                                    pcall(function(...)
                                                                        fireproximityprompt(r70);
                                                                        return; 
                                                                    end);
                                                                end; 
                                                            end;
                                                            task.wait(.05);
                                                        end;
                                                    end;
                                                else
                                                    
                                                end;
                                            end;
                                        end;
                                    end;
                                end; 
                            end;
                            return; 
                        end);
                        task.wait(0.5); 
                    end;
                    return; 
                end);
                return; 
            end;
            local function r71(...)
                r33.AutoCollect = false;
                if r37 then
                    pcall(task.cancel, r37);
                end;
                return; 
            end;
            r72 = {
                "AcceptQuest",
                "Quest",
                "StartQuest",
                "TakeQuest"
            };
            r73 = {
                "FinishQuest",
                "CompleteQuest",
                "TurnInQuest",
                "ClaimQuest"
            };
            local function r74(...)
                o = r72;
                v1 = 115[2];
                o = 115[1];
                for y, W in ipairs(o) do
                    r75 = W;
                    pcall(function(...)
                        v1 = r41(r75);
                        if v1 then
                            v1.FireServer(v1);
                        end;
                        return; 
                    end); 
                end;
                M = workspace;
                W = {
                    M.GetDescendants(M)
                };
                y = M[2];
                o = M[3];
                for o, W in ipairs(k(W)) do
                    M = o;
                    r76 = W;
                    v3 = r76;
                    if v3.IsA(v3, "ProximityPrompt") then
                        v3 = r76.ActionText .. " " .. r76.ObjectText;
                        v2 = v3.lower(v3);
                        if v2.find(v2, "quest") or (v2.find(v2, "task") or (v2.find(v2, "mission") or v2.find(v2, "claim"))) then
                            pcall(function(...)
                                fireproximityprompt(r76);
                                return; 
                            end);
                        end;
                    end; 
                end;
                o = W[3];
                y = W[2];
                for o, W in ipairs(r73) do
                    r77 = W;
                    M = o;
                    pcall(function(...)
                        v1 = J[L](r77);
                        if v1 then
                            v1.FireServer(v1);
                        end;
                        return; 
                    end); 
                end;
                return; 
            end;
            local function r78(...)
                if r38 then
                    return;
                end;
                r38 = task.spawn(function(...)
                    while r33.AutoQuest do
                        r39 = "\xf0\x9f\x93\x8b Auto Quest...";
                        r74();
                        task.wait(3); 
                    end;
                    return; 
                end);
                return; 
            end;
            local function r79(...)
                r33.AutoQuest = false;
                if r38 then
                    pcall(task.cancel, r38);
                end;
                return; 
            end;
            r80 = {
                "Rebirth",
                "Prestige",
                "AutoRebirth"
            };
            local function r82(...)
                if r81 then
                    return;
                end;
                v3 = r24.Heartbeat;
                r81 = v3.Connect(v3, function(...)
                    if not r33.SpeedBoost then
                        return;
                    end;
                    v1 = r32();
                    if v1 then
                        v1.WalkSpeed = r34.SpeedValue;
                    end;
                    return; 
                end);
                return; 
            end;
            local function r83(...)
                if r81 then
                    v3 = r81;
                    v3.Disconnect(v3);
                end;
                v1 = r32();
                if v1 then
                    v1.WalkSpeed = 16;
                end;
                return; 
            end;
            local function r86(...)
                if r84 then
                    return;
                end;
                v1 = r31();
                if not v1 then
                    return;
                end;
                r85 = Instance.new("BodyVelocity", v1);
                r85.MaxForce = Vector3.new(100000, 100000, 100000);
                r85.Velocity = Vector3.zero;
                v3 = r24.Heartbeat;
                r84 = v3.Connect(v3, function(...)
                    if not r33.Fly then
                        return;
                    end;
                    if not r85 or not r31() then
                        return;
                    end;
                    y = Vector3.zero;
                    o = r29.CFrame;
                    M = r34.FlySpeed;
                    v3 = r25;
                    if v3.IsKeyDown(v3, Enum.KeyCode.W) then
                        y = Vector3.zero + o.LookVector * M;
                    end;
                    b = r25;
                    if b.IsKeyDown(b, Enum.KeyCode.S) then
                        y = Vector3.zero - o.LookVector * M;
                    end;
                    W = r25;
                    if W.IsKeyDown(W, Enum.KeyCode.A) then
                        y = Vector3.zero - o.RightVector * M;
                    end;
                    v2 = r25;
                    if v2.IsKeyDown(v2, Enum.KeyCode.D) then
                        y = Vector3.zero + o.RightVector * M;
                    end;
                    j = r25;
                    if j.IsKeyDown(j, Enum.KeyCode.Space) then
                        y = Vector3.zero + Vector3.new(0, M, 0);
                    end;
                    v4 = r25;
                    if v4.IsKeyDown(v4, Enum.KeyCode.LeftShift) then
                        y = Vector3.zero - Vector3.new(0, M, 0);
                    end;
                    r85.Velocity = y;
                    I = r32();
                    if I then
                        I.PlatformStand = y.Magnitude > 0;
                    end;
                    return; 
                end);
                return; 
            end;
            local function r87(...)
                if r84 then
                    v3 = r84;
                    v3.Disconnect(v3);
                end;
                if r85 then
                    b = r85;
                    b.Destroy(b);
                end;
                y = r32();
                if y then
                    y.PlatformStand = false;
                end;
                return; 
            end;
            local function r89(...)
                if r88 then
                    return;
                end;
                v3 = r24.Stepped;
                r88 = v3.Connect(v3, function(...)
                    if not r33.Noclip then
                        return;
                    end;
                    v1 = r30();
                    if not v1 then
                        return;
                    end;
                    W = v1.GetDescendants;
                    M = {
                        W(v1)
                    };
                    o = W[3];
                    M = W[1];
                    for o, v2 in M, ipairs(k(M)) do
                        W = o;
                        if v2.IsA(v2, "BasePart") then
                            v2.CanCollide = false;
                        end; 
                    end;
                    return; 
                end);
                return; 
            end;
            local function r90(...)
                if r88 then
                    v3 = r88;
                    v3.Disconnect(v3);
                end;
                return; 
            end;
            local function r92(...)
                if r91 then
                    return;
                end;
                v3 = game;
                r93 = v3.GetService(v3, "VirtualUser");
                v3 = r28.Idled;
                r91 = v3.Connect(v3, function(...)
                    v3 = r93;
                    v3.Button2Down(v3, Vector2.new(0, 0), r29.CFrame);
                    task.wait(.1);
                    v3 = r93;
                    v3.Button2Up(v3, Vector2.new(0, 0), r29.CFrame);
                    return; 
                end);
                return; 
            end;
            local function r94(...)
                if r91 then
                    v3 = r91;
                    v3.Disconnect(v3);
                end;
                return; 
            end;
            local function r96(...)
                if r95 then
                    return;
                end;
                v3 = r25.JumpRequest;
                r95 = v3.Connect(v3, function(...)
                    if not r33.InfJump then
                        return;
                    end;
                    v1 = r32();
                    if v1 then
                        v1.ChangeState(v1, Enum.HumanoidStateType.Jumping);
                    end;
                    return; 
                end);
                return; 
            end;
            local function r97(...)
                if r95 then
                    v3 = r95;
                    v3.Disconnect(v3);
                end;
                return; 
            end;
            r98 = {};
            local function r100(...)
                o = r98;
                v1 = 115[2];
                o = 115[1];
                for y, W in ipairs(o) do
                    r101 = W;
                    pcall(function(...)
                        v3 = J[v3];
                        v3.Destroy(v3);
                        return; 
                    end); 
                end;
                r98 = {};
                return; 
            end;
            local function r102(arg1_12, arg2_12, ...)
                r103 = arg1_12;
                r104 = arg2_12;
                pcall(function(...)
                    v3 = r103;
                    if v3.IsA(v3, "BasePart") then
                        v1 = r103.Position;
                    else
                        o = r103;
                        j = J[i[2]];
                        M = o.IsA(o, "Model");
                        if M then
                            b = r103.PrimaryPart;
                        end;
                        v3 = r103;
                        if M then
                            v1 = r103.PrimaryPart.Position;
                            o = Instance.new("BillboardGui", game.CoreGui);
                            o.Name = "KurbyESP";
                            o.AlwaysOnTop = true;
                            o.Size = UDim2.new(0, 80, 0, 20);
                            o.StudsOffset = Vector3.new(0, 2, 0);
                            j = "Adornee";
                            W = "Adornee";
                            v4 = r103;
                            x = v4.IsA(v4, "BasePart");
                            if x then
                                v2 = r103;
                            end;
                            v3 = y;
                            o.Adornee = x or r103.PrimaryPart;
                            M = Instance.new("TextLabel", o);
                            M.Size = UDim2.new(1, 0, 1, 0);
                            M.BackgroundTransparency = 1;
                            M.Text = r103.Name;
                            v2 = W;
                            y = "TextColor3";
                            j = r104;
                            W = j;
                            if j then
                                v3 = v3;
                                M[J[i[1]][J[i[2]](v4, x)]] = j;
                                M.Font = Enum.Font.GothamBold;
                                M.TextSize = 12;
                                M.TextStrokeTransparency = 0;
                                M.TextStrokeColor3 = Color3.new(0, 0, 0);
                                table.insert(J[i[3]], Instance.new("BillboardGui", game.CoreGui));
                                return;
                            else
                                W = Color3.fromRGB(255, 200, 50);
                            end;
                        end;
                        return;
                    end; 
                end);
                return; 
            end;
            local function r105(...)
                r100();
                if not r33.ESP then
                    return;
                end;
                o = workspace;
                y = o[3];
                v1 = o[2];
                o = "ipairs";
                for y, W in ipairs(o.GetDescendants(o)) do
                    M = y;
                    r106 = W;
                    W = 141;
                    pcall(function(...)
                        if r47(r106.Name) then
                            r102(r106, Color3.fromRGB(255, 200, 50));
                        end;
                        if r68(r106.Name) then
                            r102(r106, Color3.fromRGB(100, 255, 100));
                        end;
                        return; 
                    end); 
                end;
                return; 
            end;
            local function r107(...)
                v3 = r24.Heartbeat;
                r99 = v3.Connect(v3, function(...)
                    if not r33.ESP then
                        r100();
                        return;
                    end;
                    return; 
                end);
                task.spawn(function(...)
                    while r33.ESP do
                        r105();
                        task.wait(3); 
                    end;
                    r100();
                    return; 
                end);
                return; 
            end;
            local function r108(...)
                if r99 then
                    v3 = r99;
                    v3.Disconnect(v3);
                end;
                r100();
                return; 
            end;
            hq = r28;
            UT = hq.WaitForChild(hq, "PlayerGui");
            hq = UT.FindFirstChild(UT, "SnowPS99");
            if hq then
                hq.Destroy(hq);
            end;
            uq = Instance.new("ScreenGui", UT);
            uq.Name = "SnowPS99";
            cT[12] = 29812809397818;
            uq.ResetOnSpawn = false;
            uq.ZIndexBehavior = Enum.ZIndexBehavior.Sibling;
            uq.DisplayOrder = 999;
            cT[10] = 14732098591436;
            r109 = Instance.new("Frame", uq);
            r109.Name = "Main";
            cT[7] = 12365840078462;
            r109.Size = UDim2.new(0, 320, 0, 600);
            cT[5] = 6329412979587;
            cT[16] = 11302836966543;
            r109.Position = UDim2.new(0, 12, 0.5, -300);
            r109.BackgroundColor3 = Color3.fromRGB(14, 14, 22);
            r109.BorderSizePixel = 0;
            Instance.new("UICorner", r109).CornerRadius = UDim.new(0, 14);
            zq = Instance.new("ImageLabel", r109);
            zq.Size = UDim2.new(1, 30, 1, 30);
            zq.Position = UDim2.new(0, -15, 0, -15);
            zq.BackgroundTransparency = 1;
            zq.Image = "rbxassetid://5028857084";
            zq.ImageColor3 = Color3.new(0, 0, 0);
            zq.ImageTransparency = .6;
            zq.ScaleType = Enum.ScaleType.Slice;
            zq.SliceCenter = Rect.new(24, 24, 276, 276);
            zq.ZIndex = 0;
            sq = Instance.new("Frame", r109);
            cT[14] = 19958590940237;
            sq.Size = UDim2.new(1, 0, 0, 48);
            sq.BackgroundColor3 = Color3.fromRGB(173, 216, 230);
            sq.BorderSizePixel = 0;
            Instance.new("UICorner", sq).CornerRadius = UDim.new(0, 14);
            cT[6] = 25087290699170;
            cT[13] = 6588872281084;
            Lq = Instance.new("Frame", sq);
            Lq.Size = UDim2.new(1, 0, 0.5, 0);
            Lq.Position = UDim2.new(0, 0, 0.5, 0);
            Lq.BackgroundColor3 = Color3.fromRGB(173, 216, 230);
            Lq.BorderSizePixel = 0;
            eT = Instance.new("TextLabel", sq);
            cT[9] = 14144703961530;
            eT.Size = UDim2.new(1, -50, 1, 0);
            eT.Position = UDim2.new(0, 14, 0, 0);
            eT.BackgroundTransparency = 1;
            eT.Text = "\xe2\x9d\x84\xef\xb8\x8f  Snow Hub  |  Pet Sim 99";
            cT[4] = 29934698100339;
            eT.TextColor3 = Color3.new(.1, .1, .1);
            eT.Font = Enum.Font.GothamBold;
            eT.TextSize = 15;
            eT.TextXAlignment = Enum.TextXAlignment.Left;
            r110 = Instance.new("TextButton", sq);
            r110.Size = UDim2.new(0, 32, 0, 32);
            r110.Position = UDim2.new(1, -40, 0.5, -16);
            r110.BackgroundColor3 = Color3.fromRGB(140, 200, 230);
            r110.Text = "\xe2\x80\x94";
            r110.TextColor3 = Color3.new(.1, .1, .1);
            r110.Font = Enum.Font.GothamBold;
            r110.TextSize = 14;
            r110.BorderSizePixel = 0;
            Instance.new("UICorner", r110).CornerRadius = UDim.new(0, 8);
            r111 = Instance.new("Frame", r109);
            r111.Size = UDim2.new(1, -20, 0, 28);
            r111.Position = UDim2.new(0, 10, 0, 54);
            cT[3] = 34419192823451;
            r111.BackgroundColor3 = Color3.fromRGB(22, 22, 36);
            r111.BorderSizePixel = 0;
            cT[19] = 10086076846680;
            Instance.new("UICorner", r111).CornerRadius = UDim.new(0, 8);
            cT[15] = 15778703465651;
            r112 = Instance.new("TextLabel", r111);
            cT[18] = 3486084171351;
            cT[2] = "@m$";
            r112.Size = UDim2.new(1, -10, 1, 0);
            cT[20] = 25823944011513;
            r112.Position = UDim2.new(0, 8, 0, 0);
            r112.BackgroundTransparency = 1;
            r112.Text = "Status: Idle";
            r112.TextColor3 = Color3.fromRGB(160, 130, 255);
            r112.Font = Enum.Font.GothamMedium;
            r112.TextSize = 12;
            cT[17] = 24489416961163;
            r112.TextXAlignment = Enum.TextXAlignment.Left;
            r113 = Instance.new("ScrollingFrame", r109);
            r113.Size = UDim2.new(1, 0, 1, -90);
            r113.Position = UDim2.new(0, 0, 0, 88);
            r113.BackgroundTransparency = 1;
            cT[11] = 10586053399361;
            r113.BorderSizePixel = 0;
            r113.ScrollBarThickness = 3;
            r113.ScrollBarImageColor3 = Color3.fromRGB(138, 43, 226);
            r113.CanvasSize = UDim2.new(0, 0, 0, 0);
            r113.AutomaticCanvasSize = Enum.AutomaticSize.Y;
            gT = Instance.new("UIListLayout", r113);
            gT.Padding = UDim.new(0, 4);
            gT.HorizontalAlignment = Enum.HorizontalAlignment.Center;
            tT = Instance.new("UIPadding", r113);
            tT.PaddingLeft = UDim.new(0, 10);
            tT.PaddingRight = UDim.new(0, 10);
            tT.PaddingTop = UDim.new(0, 6);
            tT.PaddingBottom = UDim.new(0, 10);
            local function AT(arg1_13, arg2_13, arg3_13, arg4_13, ...)
                r114 = arg3_13;
                r115 = Instance.new("TextButton", r113);
                r115.Size = UDim2.new(1, 0, 0, 38);
                j = r115;
                b = "BackgroundColor3";
                v4 = r114;
                v2 = v4;
                if v4 then
                    v3 = v3;
                    v3[r15[r16(x, I)]] = v4;
                    r115.Text = arg2_13 .. "  " .. arg1_13;
                    r115.TextColor3 = Color3.new(1, 1, 1);
                    r115.Font = Enum.Font.GothamBold;
                    r115.TextSize = 13;
                    r115.BorderSizePixel = 0;
                    Instance.new("UICorner", r115).CornerRadius = UDim.new(0, 10);
                    r116 = Color3.fromRGB(math.min(r114.v3 * 255 + 30, 255), math.min(r114.G * 255 + 30, 255), math.min(r114.v5 * 255 + 30, 255));
                    v3 = r115.MouseEnter;
                    v3.Connect(v3, function(...)
                        v3 = r26;
                        b = v3.Create(v3, r115, TweenInfo.new(.15), {
                            ["BackgroundColor3"] = r116
                        });
                        b.Play(b);
                        return; 
                    end);
                    v3 = r115.MouseLeave;
                    v3.Connect(v3, function(...)
                        v3 = r26;
                        b = v3.Create(v3, r115, TweenInfo.new(.15), {
                            ["BackgroundColor3"] = r114
                        });
                        b.Play(b);
                        return; 
                    end);
                    v3 = r115.MouseButton1Click;
                    v3.Connect(v3, arg4_13);
                    return r115;
                else
                    v2 = Color3.fromRGB(138, 43, 226);
                end; 
            end;
            local function bT(arg1_14, arg2_14, arg3_14, ...)
                r117 = arg3_14;
                r118 = Instance.new("Frame", r113);
                r118.Size = UDim2.new(1, 0, 0, 40);
                r118.BackgroundColor3 = Color3.fromRGB(22, 22, 36);
                r118.BorderSizePixel = 0;
                Instance.new("UICorner", r118).CornerRadius = UDim.new(0, 10);
                W = Instance.new("TextLabel", r118);
                W.Size = UDim2.new(1, -60, 1, 0);
                W.Position = UDim2.new(0, 12, 0, 0);
                W.BackgroundTransparency = 1;
                W.Text = arg2_14 .. "  " .. arg1_14;
                W.TextColor3 = Color3.fromRGB(220, 220, 240);
                W.Font = Enum.Font.GothamMedium;
                W.TextSize = 13;
                W.TextXAlignment = Enum.TextXAlignment.Left;
                r119 = Instance.new("Frame", r118);
                r119.Size = UDim2.new(0, 44, 0, 24);
                r119.Position = UDim2.new(1, -54, 0.5, -12);
                r119.BackgroundColor3 = Color3.fromRGB(40, 40, 60);
                r119.BorderSizePixel = 0;
                Instance.new("UICorner", r119).CornerRadius = UDim.new(1, 0);
                r120 = Instance.new("Frame", r119);
                r120.Size = UDim2.new(0, 18, 0, 18);
                r120.Position = UDim2.new(0, 3, 0.5, -9);
                r120.BackgroundColor3 = Color3.fromRGB(160, 160, 180);
                r120.BorderSizePixel = 0;
                Instance.new("UICorner", r120).CornerRadius = UDim.new(1, 0);
                r121 = false;
                local function r122(arg1_15, ...)
                    v1 = arg1_15;
                    r121 = v1;
                    b = r26;
                    o = r119;
                    TweenInfo.new(.2);
                    v2 = "BackgroundColor3";
                    v4 = v1;
                    if v1 then
                        x = Color3.fromRGB(138, 43, 226);
                    end;
                    v3 = v1;
                    j = v1;
                    if v1 then
                        v3 = arg1_15;
                        y = b.Create(b, r119, M(.2), {
                            [r15[r16("N\xd18\xc7\x87,#\xff\xe70\xf9\xceF\xfe9\x80", N)]] = x
                        });
                        y.Play(y);
                        b = r26;
                        o = r120;
                        TweenInfo.new(.2);
                        v4 = v3;
                        v2 = "Position";
                        j = v1 and UDim2.new(0, 23, 0.5, -9);
                        v3 = v3;
                        if v1 then
                            if v1 then
                                N = Color3.new(1, 1, 1);
                            end;
                            v3 = v4;
                            if v1 then
                                v3 = r15[r16("\x15\x0b\x05M\xd9:'[\x92\x01\xa5m\xd4\x19\xd4f", v5)];
                                y = b.Create(b, r120, M(.2), {
                                    [r15[r16(")\xfaGx\xf8\x10\xecd", N)]] = x and UDim2.new(0, 23, 0.5, -9),
                                    ["BackgroundColor3"] = v1
                                });
                                y.Play(y);
                                r117(arg1_15);
                                return;
                            else
                                x = Color3.fromRGB(160, 160, 180);
                            end;
                        else
                            j = UDim2.new(0, 3, 0.5, -9);
                        end;
                    else
                        j = Color3.fromRGB(40, 40, 60);
                    end; 
                end;
                I = Instance.new("TextButton", r118);
                I.Size = UDim2.new(1, 0, 1, 0);
                I.BackgroundTransparency = 1;
                I.Text = "";
                v3 = I.MouseButton1Click;
                v3.Connect(v3, function(...)
                    r122(not r121);
                    return; 
                end);
                v3 = I.MouseEnter;
                v3.Connect(v3, function(...)
                    v3 = r26;
                    b = v3.Create(v3, r118, TweenInfo.new(.15), {
                        ["BackgroundColor3"] = Color3.fromRGB(30, 30, 48)
                    });
                    b.Play(b);
                    return; 
                end);
                v3 = I.MouseLeave;
                v3.Connect(v3, function(...)
                    v3 = r26;
                    b = v3.Create(v3, r118, TweenInfo.new(.15), {
                        ["BackgroundColor3"] = Color3.fromRGB(22, 22, 36)
                    });
                    b.Play(b);
                    return; 
                end);
                return r118, r122; 
            end;
            local function OT(arg1_16, arg2_16, arg3_16, arg4_16, ...)
                r123 = arg4_16;
                W = Instance.new("Frame", r113);
                W.Size = UDim2.new(1, 0, 0, 52);
                W.BackgroundColor3 = Color3.fromRGB(22, 22, 36);
                W.BorderSizePixel = 0;
                Instance.new("UICorner", W).CornerRadius = UDim.new(0, 10);
                v2 = Instance.new("TextLabel", W);
                v2.Size = UDim2.new(1, -20, 0, 22);
                v2.Position = UDim2.new(0, 12, 0, 3);
                v2.BackgroundTransparency = 1;
                v2.Text = arg2_16 .. "  " .. arg1_16;
                v2.TextColor3 = Color3.fromRGB(220, 220, 240);
                v2.Font = Enum.Font.GothamMedium;
                v2.TextSize = 12;
                v2.TextXAlignment = Enum.TextXAlignment.Left;
                r124 = Instance.new("TextBox", W);
                r124.Size = UDim2.new(1, -24, 0, 22);
                r124.Position = UDim2.new(0, 12, 0, 26);
                r124.BackgroundColor3 = Color3.fromRGB(30, 30, 48);
                r124.BorderSizePixel = 0;
                v4 = arg3_16;
                r124.Text = v4;
                r124.TextColor3 = Color3.new(1, 1, 1);
                r124.Font = Enum.Font.GothamMedium;
                r124.TextSize = 12;
                r124.ClearTextOnFocus = false;
                Instance.new("UICorner", r124).CornerRadius = UDim.new(0, 6);
                v3 = r124.FocusLost;
                v3.Connect(v3, function(...)
                    r123(r124.Text);
                    return; 
                end);
                return W; 
            end;
            local function HT(arg1_17, ...)
                y = Instance.new("TextLabel", r113);
                y.Size = UDim2.new(1, 0, 0, 26);
                y.BackgroundTransparency = 1;
                b = arg1_17;
                y.Text = b;
                y.TextColor3 = Color3.fromRGB(138, 43, 226);
                y.Font = Enum.Font.GothamBold;
                y.TextSize = 12;
                y.TextXAlignment = Enum.TextXAlignment.Left;
                return y; 
            end;
            local function JT(arg1_18, arg2_18, arg3_18, arg4_18, arg5_18, arg6_18, ...)
                W = arg5_18;
                r125 = arg3_18;
                r126 = arg4_18;
                r127 = arg6_18;
                j = Instance.new("Frame", r113);
                j.Size = UDim2.new(1, 0, 0, 52);
                j.BackgroundColor3 = Color3.fromRGB(22, 22, 36);
                j.BorderSizePixel = 0;
                Instance.new("UICorner", j).CornerRadius = UDim.new(0, 10);
                v4 = Instance.new("TextLabel", j);
                v4.Size = UDim2.new(1, -80, 0, 24);
                v4.Position = UDim2.new(0, 12, 0, 4);
                v4.BackgroundTransparency = 1;
                v4.Text = arg2_18 .. "  " .. arg1_18;
                v4.TextColor3 = Color3.fromRGB(220, 220, 240);
                v4.Font = Enum.Font.GothamMedium;
                v4.TextSize = 12;
                v4.TextXAlignment = Enum.TextXAlignment.Left;
                r128 = Instance.new("TextLabel", j);
                r128.Size = UDim2.new(0, 60, 0, 24);
                r128.Position = UDim2.new(1, -72, 0, 4);
                r128.BackgroundTransparency = 1;
                r128.Text = tostring(W);
                r128.TextColor3 = Color3.fromRGB(138, 43, 226);
                r128.Font = Enum.Font.GothamBold;
                r128.TextSize = 12;
                r128.TextXAlignment = Enum.TextXAlignment.Right;
                r129 = Instance.new("Frame", j);
                r129.Size = UDim2.new(1, -24, 0, 6);
                r129.Position = UDim2.new(0, 12, 0, 36);
                r129.BackgroundColor3 = Color3.fromRGB(40, 40, 60);
                r129.BorderSizePixel = 0;
                Instance.new("UICorner", r129).CornerRadius = UDim.new(1, 0);
                r130 = Instance.new("Frame", r129);
                r130.Size = UDim2.new((W - r125) / (r126 - r125), 0, 1, 0);
                r130.BackgroundColor3 = Color3.fromRGB(138, 43, 226);
                r130.BorderSizePixel = 0;
                Instance.new("UICorner", r130).CornerRadius = UDim.new(1, 0);
                r131 = false;
                v5 = Instance.new("TextButton", r129);
                v5.Size = UDim2.new(1, 0, 1, 0);
                v5.BackgroundTransparency = 1;
                v5.Text = "";
                local function r132(arg1_19, ...)
                    M = math.clamp((arg1_19 - r129.AbsolutePosition.X) / r129.AbsoluteSize.X, 0, 1);
                    W = math.floor(r125 + M * (r126 - r125));
                    r130.Size = UDim2.new(M, 0, 1, 0);
                    r128.Text = tostring(W);
                    r127(W);
                    return; 
                end;
                v3 = v5.MouseButton1Down;
                v3.Connect(v3, function(...)
                    r131 = true;
                    o = r25;
                    r132(o.GetMouseLocation(o).X);
                    return; 
                end);
                v3 = r25.InputEnded;
                v3.Connect(v3, function(arg1_20, ...)
                    if arg1_20.UserInputType == Enum.UserInputType.MouseButton1 then
                        r131 = false;
                    end;
                    return; 
                end);
                v3 = r25.InputChanged;
                v3.Connect(v3, function(arg1_21, ...)
                    v1 = arg1_21;
                    if r131 and v1.UserInputType == Enum.UserInputType.MouseMovement then
                        r132(v1.Position.X);
                    end;
                    return; 
                end);
                return j; 
            end;
            cT[1] = r16(cT[2], cT[3]);
            cT[3] = "\xba\x02\x93]\xb5";
            cT[1] = r16;
            cT[2] = cT[1](cT[3], cT[4]);
            cT[4] = "\xc9=\x01\x97(5\xdc\xdf\x19@\x13[";
            cT[1] = r15;
            cT[2] = r16;
            cT[3] = cT[2](cT[4], cT[5]);
            cT[5] = "\x0c\x16\x92\x88[\xba\xff\xed";
            cT[2] = r15;
            cT[3] = r16;
            cT[4] = cT[3](cT[5], cT[6]);
            cT[1] = cT[2][cT[4]];
            cT[3] = r15;
            cT[6] = "\xe4\x87\xe3\xcc\x82\x99\x93\n\xa1nH&\xfb";
            cT[4] = r16;
            cT[8] = 28457031594947;
            cT[5] = cT[4](cT[6], cT[7]);
            cT[2] = cT[3][cT[5]];
            cT[4] = r15;
            cT[7] = "!\x96\xa3\x83\xe7\x81\xa1U";
            cT[5] = r16;
            cT[6] = cT[5](cT[7], cT[8]);
            cT[8] = "\xb8\x10\x11\xde\x18\xca\\\xc8Y93";
            cT[3] = cT[4][cT[6]];
            cT[5] = r15;
            cT[6] = r16;
            cT[7] = cT[6](cT[8], cT[9]);
            cT[4] = cT[5][cT[7]];
            cT[6] = r15;
            cT[7] = r16;
            cT[9] = "\x1e\xec*\xb4R\xc1\x81y";
            cT[8] = cT[7](cT[9], cT[10]);
            cT[5] = cT[6][cT[8]];
            cT[10] = "\xab\xba\xae\xb7\\\xd4\xfd\xbf\xb2";
            cT[7] = r15;
            cT[8] = r16;
            cT[9] = cT[8](cT[10], cT[11]);
            cT[6] = cT[7][cT[9]];
            cT[8] = r15;
            cT[9] = r16;
            cT[11] = "\\\x15\xfeT[\xbcXL{\xba";
            cT[10] = cT[9](cT[11], cT[12]);
            cT[7] = cT[8][cT[10]];
            cT[9] = r15;
            cT[10] = r16;
            cT[12] = "B%gY\x81Q\xb3\xcc\xa7\n\xb8\xbb";
            cT[11] = cT[10](cT[12], cT[13]);
            cT[8] = cT[9][cT[11]];
            cT[10] = r15;
            cT[11] = r16;
            cT[13] = "\xe9\x8e\xbd!\x8d\x90\xe6\xfa\x91\x9e\xc7{\x90";
            cT[12] = cT[11](cT[13], cT[14]);
            cT[9] = cT[10][cT[12]];
            cT[11] = r15;
            cT[12] = r16;
            cT[14] = "q\xb6\x04\x14C\n\xbf\xc6\xec";
            cT[13] = cT[12](cT[14], cT[15]);
            cT[10] = cT[11][cT[13]];
            cT[12] = r15;
            cT[15] = "}\xe1:\xe7JRb\x17i\xa3";
            cT[13] = r16;
            cT[14] = cT[13](cT[15], cT[16]);
            cT[11] = cT[12][cT[14]];
            cT[16] = "\xde\xb1\xf7i\xc1\xb8\xad\xea\\\xad\\";
            cT[13] = r15;
            cT[14] = r16;
            cT[15] = cT[14](cT[16], cT[17]);
            cT[12] = cT[13][cT[15]];
            cT[17] = "j\xcbZ\xff\xd6b\x8a\x03l";
            cT[14] = r15;
            cT[15] = r16;
            cT[16] = cT[15](cT[17], cT[18]);
            cT[13] = cT[14][cT[16]];
            cT[18] = "k\x80\xa0r+)$\xac\x96";
            cT[15] = r15;
            cT[16] = r16;
            cT[17] = cT[16](cT[18], cT[19]);
            cT[14] = cT[15][cT[17]];
            cT[6] = 30887243757614;
            r133 = {
                r15[cT[1]],
                r15[cT[2]],
                cT[1][cT[3]],
                cT[1],
                cT[2],
                cT[3],
                cT[4],
                cT[5],
                cT[6],
                cT[7],
                cT[8],
                cT[9],
                cT[10],
                cT[11],
                cT[12],
                cT[13],
                cT[14]
            };
            local function r134(arg1_22, ...)
                v1 = arg1_22;
                y = v1.lower(v1);
                W = r133;
                W = 21[1];
                o = 21[2];
                for M, j in ipairs(W) do
                    v2 = M;
                    if y.find(y, j, 1, true) then
                        return true;
                    else
                        
                    end; 
                end;
                return false; 
            end;
            local function r135(...)
                r136 = {};
                r137 = {};
                W = workspace;
                M = W[3];
                o = W[2];
                W = "ipairs";
                for M, j in ipairs(W.GetDescendants(W)) do
                    r138 = j;
                    v2 = M;
                    j = 121;
                    pcall(function(...)
                        y = J[j];
                        v1 = 121;
                        o = y.IsA(y, "BasePart");
                        b = o;
                        if o then
                            v3 = v1;
                            if not o then
                                return;
                            end;
                            if not r134(J[j].Name) then
                                return;
                            end;
                            v3 = J[j].Name;
                            b = v3.lower(v3);
                            v1 = b.match(b, "^%s*(.-)%s*$");
                            if r137[v1] then
                                return;
                            end;
                            r137[v1] = true;
                            o = J[j];
                            b = o.IsA(o, "BasePart") or o.IsA(o, "MeshPart");
                            if b then
                                y = J[j].Position;
                            else
                                b = J[j];
                                if b.IsA(b, "Model") then
                                    if J[j].PrimaryPart then
                                        y = J[j].PrimaryPart.Position;
                                    else
                                        x = J[j];
                                        j = x[2];
                                        v4 = x[3];
                                        for v4, x in ipairs(x.GetDescendants(x)) do
                                            W = v4;
                                            if x.IsA(x, "BasePart") then
                                                o = Vector3.zero + x.Position;
                                                M = 0 + 1;
                                            end; 
                                        end;
                                        if 0 > 0 then
                                            y = Vector3.zero / 0;
                                        end;
                                    end;
                                end;
                                if v3 then
                                    o = v3.Y < 2000;
                                end;
                                if v3 then
                                    table.insert(r136, {
                                        ["name"] = J[j].Name,
                                        ["pos"] = v3,
                                        ["obj"] = J[j]
                                    });
                                end;
                                return;
                            end;
                        end;
                        M = J[j];
                        o = 121;
                        y = M.IsA(M, "Model") or M.IsA(M, "MeshPart");
                        return; 
                    end); 
                end;
                table.sort(r136, function(arg1_23, arg2_23, ...)
                    b = arg1_23.name;
                    b = arg2_23.name;
                    return b.lower(b) < b.lower(b); 
                end);
                return r136; 
            end;
            cT[2] = r15;
            cT[5] = "D0\xa0\xa5#gU\xa0\x9e;\x15\xce\xe0r";
            cT[3] = r16;
            cT[4] = cT[3](cT[5], cT[6]);
            cT[1] = cT[2][cT[4]];
            cT[8] = 14959743195958;
            cT[7] = 26002060848972;
            cT[6] = 33520538139897;
            cT[10] = "\x8fT\xf4";
            cT[5] = "KL \xf2\x01\xe6\xc6(\xa4";
            HT(cT[1]);
            cT[2] = r15;
            cT[3] = r16;
            cT[4] = cT[3](cT[5], cT[6]);
            cT[1] = cT[2][cT[4]];
            cT[3] = r15;
            cT[6] = "\x87\x9d\xfa\xb0";
            cT[4] = r16;
            cT[5] = cT[4](cT[6], cT[7]);
            cT[2] = cT[3][cT[5]];
            cT[3] = function(arg1_24, ...)
                v1 = arg1_24;
                r33.AutoFarm = v1;
                if v1 then
                    r57();
                else
                    r58();
                end;
                return; 
            end;
            cT[5] = "\xe3\xdd\x81\xbc\x94h\x1fKX\tX";
            bT(cT[1], cT[2], cT[3]);
            cT[2] = r15;
            cT[6] = 1822250206032;
            cT[3] = r16;
            cT[4] = cT[3](cT[5], cT[6]);
            cT[6] = "\xf4\x87TN";
            cT[7] = 903765606820;
            cT[1] = cT[2][cT[4]];
            cT[3] = r15;
            cT[4] = r16;
            cT[17] = 23191790397999;
            cT[5] = cT[4](cT[6], cT[7]);
            cT[2] = cT[3][cT[5]];
            cT[7] = 2176075826165;
            cT[5] = 40;
            cT[4] = 100;
            cT[6] = function(arg1_25, ...)
                r34.FarmRadius = arg1_25;
                return; 
            end;
            cT[3] = 10;
            JT(cT[1], cT[2], cT[3], cT[4], cT[5], cT[6]);
            cT[2] = r15;
            cT[5] = "\xd8\x97&\xe2\x1cg\xa6\x00h0\x82\x08 \x80";
            cT[3] = r16;
            cT[6] = 32104410200677;
            cT[4] = cT[3](cT[5], cT[6]);
            cT[1] = cT[2][cT[4]];
            cT[5] = "\x19\xc1\xb8x\x84\xde\xc7\x05\xef\xc8";
            HT(cT[1]);
            cT[2] = r15;
            cT[6] = 31042557950071;
            cT[3] = r16;
            cT[4] = cT[3](cT[5], cT[6]);
            cT[1] = cT[2][cT[4]];
            cT[3] = r15;
            cT[6] = "\xaf\xc2\xe5\xb0";
            cT[13] = 32961005370356;
            cT[4] = r16;
            cT[5] = cT[4](cT[6], cT[7]);
            cT[2] = cT[3][cT[5]];
            cT[7] = 31904826538504;
            cT[5] = "#k\x87o\x13Ml\x81k\x15h\\";
            cT[6] = 10966161527794;
            cT[3] = function(arg1_26, ...)
                v1 = arg1_26;
                r33.AutoHatch = v1;
                if v1 then
                    r65();
                else
                    r66();
                end;
                return; 
            end;
            bT(cT[1], cT[2], cT[3]);
            cT[2] = r15;
            cT[3] = r16;
            cT[4] = cT[3](cT[5], cT[6]);
            cT[1] = cT[2][cT[4]];
            cT[6] = "0\xfa\xe6\xc9";
            cT[3] = r15;
            cT[4] = r16;
            cT[11] = 1221830132280;
            cT[5] = cT[4](cT[6], cT[7]);
            cT[4] = 100;
            cT[2] = cT[3][cT[5]];
            cT[5] = 1;
            cT[3] = 1;
            cT[6] = function(arg1_27, ...)
                r34.HatchAmount = arg1_27;
                return; 
            end;
            JT(cT[1], cT[2], cT[3], cT[4], cT[5], cT[6]);
            cT[5] = "r\xa8\xe2N\xdd\x97#vF\xe4;qU\xa2`{7\xa3";
            cT[2] = r15;
            cT[6] = 30460114024296;
            cT[18] = 27183097213298;
            cT[3] = r16;
            cT[4] = cT[3](cT[5], cT[6]);
            cT[1] = cT[2][cT[4]];
            HT(cT[1]);
            cT[3] = "Instance";
            cT[2] = Env[cT[3]];
            cT[7] = "\xf1n}";
            cT[4] = r15;
            cT[5] = r16;
            cT[6] = cT[5](cT[7], cT[8]);
            cT[3] = cT[4][cT[6]];
            cT[1] = cT[2][cT[3]];
            cT[4] = r15;
            cT[8] = 25150538526143;
            cT[5] = r16;
            cT[7] = "\x94\x0c`\xb0\xf2B/\xd4\x1d";
            cT[6] = cT[5](cT[7], cT[8]);
            cT[3] = cT[4][cT[6]];
            cT[7] = "\xc3\x1a\x04[";
            cT[8] = 15106696010618;
            cT[4] = r113;
            cT[2] = cT[1](cT[3], cT[4]);
            cT[1] = 9;
            J[cT[1]] = cT[2];
            cT[2] = J[cT[1]];
            cT[4] = r15;
            cT[5] = r16;
            cT[6] = cT[5](cT[7], cT[8]);
            cT[3] = cT[4][cT[6]];
            cT[6] = "UDim2";
            cT[5] = Env[cT[6]];
            cT[7] = r15;
            cT[8] = r16;
            cT[9] = cT[8](cT[10], cT[11]);
            cT[8] = 0;
            cT[6] = cT[7][cT[9]];
            cT[7] = 0;
            cT[4] = cT[5][cT[6]];
            cT[6] = 1;
            cT[9] = 24;
            cT[5] = cT[4](cT[6], cT[7], cT[8], cT[9]);
            cT[2][cT[3]] = cT[5];
            cT[2] = J[cT[1]];
            cT[7] = "\x10\xa2s[\xc1\xa9\x16x0\x86\xf0\xf8l)\xfb\xf5/c\xc2\xc4\x0c\xcc";
            cT[4] = r15;
            cT[8] = 25891065458456;
            cT[5] = r16;
            cT[6] = cT[5](cT[7], cT[8]);
            cT[3] = cT[4][cT[6]];
            cT[7] = "!\"\xd9\xb4";
            cT[4] = 1;
            cT[2][cT[3]] = cT[4];
            cT[8] = 34172470820392;
            cT[10] = 17418615168943;
            cT[2] = J[cT[1]];
            cT[9] = "3\x1f\xa4\xb2.T'a\x9b\xb6";
            cT[4] = r15;
            cT[5] = r16;
            cT[6] = cT[5](cT[7], cT[8]);
            cT[3] = cT[4][cT[6]];
            cT[6] = r15;
            cT[7] = r16;
            cT[12] = "\xfd\xbf5\xcd\xd0N\xfdV";
            cT[8] = cT[7](cT[9], cT[10]);
            cT[5] = cT[6][cT[8]];
            cT[7] = r34;
            cT[9] = r15;
            cT[10] = r16;
            cT[11] = cT[10](cT[12], cT[13]);
            cT[8] = cT[9][cT[11]];
            cT[6] = cT[7][cT[8]];
            cT[4] = cT[5] .. cT[6];
            cT[2][cT[3]] = cT[4];
            cT[8] = 7956792118905;
            cT[2] = J[cT[1]];
            cT[4] = r15;
            cT[5] = r16;
            cT[10] = "3\x95\xa5\x9c\xdd\xde\xa4";
            cT[11] = 10796868178851;
            cT[7] = "\xb7\x027xL\x8e\xaeIK\x8e";
            cT[6] = cT[5](cT[7], cT[8]);
            cT[3] = cT[4][cT[6]];
            cT[6] = "Color3";
            cT[5] = Env[cT[6]];
            cT[7] = r15;
            cT[8] = r16;
            cT[9] = cT[8](cT[10], cT[11]);
            cT[6] = cT[7][cT[9]];
            cT[4] = cT[5][cT[6]];
            cT[6] = 160;
            cT[14] = "\xce.\x90";
            cT[8] = 255;
            cT[7] = 130;
            cT[5] = cT[4](cT[6], cT[7], cT[8]);
            cT[7] = "\xd11\xcf\x11";
            cT[2][cT[3]] = cT[5];
            cT[12] = 31070189500548;
            cT[2] = J[cT[1]];
            cT[4] = r15;
            cT[5] = r16;
            cT[8] = 33303604771988;
            cT[6] = cT[5](cT[7], cT[8]);
            cT[3] = cT[4][cT[6]];
            cT[7] = "Enum";
            cT[6] = Env[cT[7]];
            cT[8] = r15;
            cT[9] = r16;
            cT[11] = "q\x83\xa1L";
            cT[10] = cT[9](cT[11], cT[12]);
            cT[7] = cT[8][cT[10]];
            cT[5] = cT[6][cT[7]];
            cT[11] = 18907219780196;
            cT[10] = "\xcc\xa8\xcbU\xbf;\xbbV)\x18\x90\xae";
            cT[7] = r15;
            cT[8] = r16;
            cT[9] = cT[8](cT[10], cT[11]);
            cT[6] = cT[7][cT[9]];
            cT[4] = cT[5][cT[6]];
            cT[11] = "\xb2\xef\xca\xf9\x9d\xdd\xbd}\x95\xe4\xe9:\xad\xe0";
            cT[2][cT[3]] = cT[4];
            cT[2] = J[cT[1]];
            cT[8] = 9047885484149;
            cT[4] = r15;
            cT[5] = r16;
            cT[7] = "\"\xeeV\xc9\x02M)B";
            cT[6] = cT[5](cT[7], cT[8]);
            cT[3] = cT[4][cT[6]];
            cT[12] = 33606443679009;
            cT[4] = 12;
            cT[2][cT[3]] = cT[4];
            cT[8] = 13627652069577;
            cT[2] = J[cT[1]];
            cT[7] = " \x81G\xd5\x7f\x1d{\xd6\x85|@4f\xe2";
            cT[4] = r15;
            cT[5] = r16;
            cT[6] = cT[5](cT[7], cT[8]);
            cT[7] = "Enum";
            cT[3] = cT[4][cT[6]];
            cT[6] = Env[cT[7]];
            cT[8] = r15;
            cT[9] = r16;
            cT[10] = cT[9](cT[11], cT[12]);
            cT[7] = cT[8][cT[10]];
            cT[5] = cT[6][cT[7]];
            cT[10] = "i\xe1\x8e\x1f";
            cT[11] = 4750757152932;
            cT[7] = r15;
            cT[8] = r16;
            cT[9] = cT[8](cT[10], cT[11]);
            cT[6] = cT[7][cT[9]];
            cT[4] = cT[5][cT[6]];
            cT[2][cT[3]] = cT[4];
            cT[8] = "\x00#\x8c";
            cT[4] = "Instance";
            cT[3] = Env[cT[4]];
            cT[5] = r15;
            cT[9] = 11963818104259;
            cT[6] = r16;
            cT[7] = cT[6](cT[8], cT[9]);
            cT[4] = cT[5][cT[7]];
            cT[2] = cT[3][cT[4]];
            cT[5] = r15;
            cT[9] = 24424132422765;
            cT[8] = "Zsl\x93\x94";
            cT[6] = r16;
            cT[7] = cT[6](cT[8], cT[9]);
            cT[8] = "@#\xe4\xd0";
            cT[4] = cT[5][cT[7]];
            cT[5] = r113;
            cT[9] = 24943045766495;
            cT[3] = cT[2](cT[4], cT[5]);
            cT[2] = 10;
            cT[12] = 13786068310291;
            J[cT[2]] = cT[3];
            cT[3] = J[cT[2]];
            cT[5] = r15;
            cT[6] = r16;
            cT[7] = cT[6](cT[8], cT[9]);
            cT[4] = cT[5][cT[7]];
            cT[7] = "UDim2";
            cT[6] = Env[cT[7]];
            cT[8] = r15;
            cT[11] = "?\x0cD";
            cT[9] = r16;
            cT[10] = cT[9](cT[11], cT[12]);
            cT[7] = cT[8][cT[10]];
            cT[5] = cT[6][cT[7]];
            cT[7] = 1;
            cT[10] = 0;
            cT[9] = 0;
            cT[8] = 0;
            cT[12] = 19164181111516;
            cT[6] = cT[5](cT[7], cT[8], cT[9], cT[10]);
            cT[3][cT[4]] = cT[6];
            cT[8] = "\xbdt\xcb\xd0\x8c\xb1'\xad\x84\x8b\xe2\xa2PY\x1az";
            cT[9] = 25327898029586;
            cT[3] = J[cT[2]];
            cT[5] = r15;
            cT[6] = r16;
            cT[11] = "T\x03\xb1\x1eU\x0e\xd4";
            cT[7] = cT[6](cT[8], cT[9]);
            cT[4] = cT[5][cT[7]];
            cT[7] = "Color3";
            cT[6] = Env[cT[7]];
            cT[8] = r15;
            cT[9] = r16;
            cT[10] = cT[9](cT[11], cT[12]);
            cT[12] = 32152245418620;
            cT[7] = cT[8][cT[10]];
            cT[5] = cT[6][cT[7]];
            cT[8] = 18;
            cT[7] = 18;
            cT[9] = 30;
            cT[6] = cT[5](cT[7], cT[8], cT[9]);
            cT[10] = 21186083890825;
            cT[3][cT[4]] = cT[6];
            cT[8] = "O\xb5N\xa2\xe4Q\xf5R\xbc\xb5\xcf\x15\xd1\xd9H";
            cT[3] = J[cT[2]];
            cT[5] = r15;
            cT[9] = 10706106422137;
            cT[6] = r16;
            cT[15] = 588117541137;
            cT[7] = cT[6](cT[8], cT[9]);
            cT[9] = "d\xc8\x9d";
            cT[4] = cT[5][cT[7]];
            cT[5] = 0;
            cT[3][cT[4]] = cT[5];
            cT[5] = "Instance";
            cT[4] = Env[cT[5]];
            cT[6] = r15;
            cT[7] = r16;
            cT[8] = cT[7](cT[9], cT[10]);
            cT[5] = cT[6][cT[8]];
            cT[3] = cT[4][cT[5]];
            cT[6] = r15;
            cT[10] = 21340256937681;
            cT[9] = "&\xee\x07<\xff\xe4\xd9\x07";
            cT[11] = "\x12&\xeb";
            cT[7] = r16;
            cT[8] = cT[7](cT[9], cT[10]);
            cT[5] = cT[6][cT[8]];
            cT[9] = 3539003360879;
            cT[8] = "\xea7\x0e\xb4X\x04\xedPT\xeb\x04\xb3";
            cT[6] = J[cT[2]];
            cT[4] = cT[3](cT[5], cT[6]);
            cT[5] = r15;
            cT[6] = r16;
            cT[7] = cT[6](cT[8], cT[9]);
            cT[3] = cT[5][cT[7]];
            cT[7] = "UDim";
            cT[6] = Env[cT[7]];
            cT[8] = r15;
            cT[9] = r16;
            cT[10] = cT[9](cT[11], cT[12]);
            cT[7] = cT[8][cT[10]];
            cT[9] = ":2b";
            cT[8] = 10;
            cT[5] = cT[6][cT[7]];
            cT[7] = 0;
            cT[12] = 33020454566928;
            cT[10] = 18060711370970;
            cT[6] = cT[5](cT[7], cT[8]);
            cT[4][cT[3]] = cT[6];
            cT[5] = "Instance";
            cT[4] = Env[cT[5]];
            cT[6] = r15;
            cT[7] = r16;
            cT[8] = cT[7](cT[9], cT[10]);
            cT[5] = cT[6][cT[8]];
            cT[10] = 2303164154928;
            cT[9] = "\xfe\x91#H\xe8U\x88mN\x97\x0e\x86";
            cT[3] = cT[4][cT[5]];
            cT[6] = r15;
            cT[7] = r16;
            cT[8] = cT[7](cT[9], cT[10]);
            cT[5] = cT[6][cT[8]];
            cT[8] = "\x96)\xb6i\x92\xa6\n";
            cT[6] = J[cT[2]];
            cT[4] = cT[3](cT[5], cT[6]);
            cT[9] = 27427987337700;
            cT[5] = r15;
            cT[6] = r16;
            cT[7] = cT[6](cT[8], cT[9]);
            cT[13] = 7350311243102;
            cT[3] = cT[5][cT[7]];
            cT[7] = "UDim";
            cT[6] = Env[cT[7]];
            cT[11] = "6'\xde";
            cT[8] = r15;
            cT[9] = r16;
            cT[10] = cT[9](cT[11], cT[12]);
            cT[12] = "\x1b\x11\xe0\x9bh\xfe\x16k\xe5\xbc\xa6\x08E\xe7\xda\x12y<\xb8";
            cT[7] = cT[8][cT[10]];
            cT[8] = 2;
            cT[9] = 27453702681072;
            cT[5] = cT[6][cT[7]];
            cT[7] = 0;
            cT[6] = cT[5](cT[7], cT[8]);
            cT[8] = "\xebw\xff<&\rR\x1c^Q\xaa\xc3\x12\xff\xf9O\xdfj\xfb";
            cT[4][cT[3]] = cT[6];
            cT[5] = r15;
            cT[6] = r16;
            cT[7] = cT[6](cT[8], cT[9]);
            cT[3] = cT[5][cT[7]];
            cT[8] = "Enum";
            cT[7] = Env[cT[8]];
            cT[9] = r15;
            cT[10] = r16;
            cT[11] = cT[10](cT[12], cT[13]);
            cT[13] = 15937029299453;
            cT[8] = cT[9][cT[11]];
            cT[11] = "\xfe\x10\xc7\x04\x1b5";
            cT[6] = cT[7][cT[8]];
            cT[8] = r15;
            cT[12] = 34242284715593;
            cT[9] = r16;
            cT[10] = cT[9](cT[11], cT[12]);
            cT[7] = cT[8][cT[10]];
            cT[5] = cT[6][cT[7]];
            cT[4][cT[3]] = cT[5];
            cT[6] = "Instance";
            cT[5] = Env[cT[6]];
            cT[7] = r15;
            cT[8] = r16;
            cT[10] = "\x9b\x06\x88";
            cT[11] = 18160396034312;
            cT[9] = cT[8](cT[10], cT[11]);
            cT[11] = 6338409958279;
            cT[12] = "\x14\x01\x8a";
            cT[6] = cT[7][cT[9]];
            cT[3] = cT[5][cT[6]];
            cT[7] = r15;
            cT[10] = "\xaa\x8d\xfa8\x92dlf\x9b";
            cT[8] = r16;
            cT[9] = cT[8](cT[10], cT[11]);
            cT[6] = cT[7][cT[9]];
            cT[7] = J[cT[2]];
            cT[5] = cT[3](cT[6], cT[7]);
            cT[10] = 16476527779320;
            cT[6] = r15;
            cT[9] = "u\xfd\xb7\x90\x1c\xe0E\x18\xe8\xf9\xae";
            cT[7] = r16;
            cT[8] = cT[7](cT[9], cT[10]);
            cT[3] = cT[6][cT[8]];
            cT[8] = "UDim";
            cT[7] = Env[cT[8]];
            cT[9] = r15;
            cT[10] = r16;
            cT[11] = cT[10](cT[12], cT[13]);
            cT[8] = cT[9][cT[11]];
            cT[6] = cT[7][cT[8]];
            cT[8] = 0;
            cT[9] = 6;
            cT[7] = cT[6](cT[8], cT[9]);
            cT[19] = 23850250283874;
            cT[5][cT[3]] = cT[7];
            cT[6] = r15;
            cT[10] = 14295202077184;
            cT[9] = "Z\x7f\xc9U\xdc\x1a\x93\xe6^\x19\x12\xe5";
            cT[7] = r16;
            cT[8] = cT[7](cT[9], cT[10]);
            cT[3] = cT[6][cT[8]];
            cT[8] = "UDim";
            cT[13] = 27273395974556;
            cT[7] = Env[cT[8]];
            cT[9] = r15;
            cT[12] = "5\x10\\";
            cT[10] = r16;
            cT[11] = cT[10](cT[12], cT[13]);
            cT[8] = cT[9][cT[11]];
            cT[6] = cT[7][cT[8]];
            cT[8] = 0;
            cT[13] = 10181019472516;
            cT[9] = 6;
            cT[7] = cT[6](cT[8], cT[9]);
            cT[5][cT[3]] = cT[7];
            cT[12] = "^hq";
            cT[10] = 14056261982609;
            cT[6] = r15;
            cT[9] = "\xa0\x9d\xc0auo\xeb;\xaa\xed";
            cT[7] = r16;
            cT[8] = cT[7](cT[9], cT[10]);
            cT[16] = 9987685372458;
            cT[3] = cT[6][cT[8]];
            cT[8] = "UDim";
            cT[7] = Env[cT[8]];
            cT[9] = r15;
            cT[10] = r16;
            cT[11] = cT[10](cT[12], cT[13]);
            cT[8] = cT[9][cT[11]];
            cT[9] = 4;
            cT[6] = cT[7][cT[8]];
            cT[8] = 0;
            cT[7] = cT[6](cT[8], cT[9]);
            cT[5][cT[3]] = cT[7];
            cT[10] = 10996243649536;
            cT[6] = r15;
            cT[9] = "\x94\xc0\\\xc0\xb0\x9b\x15\xf2A\xa2\x03\x14s";
            cT[13] = 23104147466758;
            cT[7] = r16;
            cT[12] = "k\xe8\xd3";
            cT[8] = cT[7](cT[9], cT[10]);
            cT[3] = cT[6][cT[8]];
            cT[8] = "UDim";
            cT[7] = Env[cT[8]];
            cT[9] = r15;
            cT[10] = r16;
            cT[11] = cT[10](cT[12], cT[13]);
            cT[8] = cT[9][cT[11]];
            cT[6] = cT[7][cT[8]];
            cT[8] = 0;
            cT[9] = 4;
            cT[7] = cT[6](cT[8], cT[9]);
            cT[5][cT[3]] = cT[7];
            cT[11] = ":\x92\xac";
            cT[7] = "Instance";
            cT[12] = 23808671542094;
            cT[6] = Env[cT[7]];
            cT[8] = r15;
            cT[9] = r16;
            cT[10] = cT[9](cT[11], cT[12]);
            cT[7] = cT[8][cT[10]];
            cT[12] = 9418315223329;
            cT[3] = cT[6][cT[7]];
            cT[8] = r15;
            cT[11] = "\x86\x14\xb1\xfeE\"\xe6\x8f\x9a";
            cT[9] = r16;
            cT[10] = cT[9](cT[11], cT[12]);
            cT[7] = cT[8][cT[10]];
            cT[8] = J[cT[2]];
            cT[6] = cT[3](cT[7], cT[8]);
            cT[3] = 11;
            J[cT[3]] = cT[6];
            cT[6] = J[cT[3]];
            cT[8] = r15;
            cT[12] = 27854904619690;
            cT[11] = "\xdb\x99\xe9\xe9";
            cT[9] = r16;
            cT[10] = cT[9](cT[11], cT[12]);
            cT[7] = cT[8][cT[10]];
            cT[10] = "UDim2";
            cT[9] = Env[cT[10]];
            cT[11] = r15;
            cT[12] = r16;
            cT[13] = cT[12](cT[14], cT[15]);
            cT[10] = cT[11][cT[13]];
            cT[13] = 28;
            cT[12] = 0;
            cT[8] = cT[9][cT[10]];
            cT[11] = 0;
            cT[14] = "9\x94n\xfc]\x8c\xa9";
            cT[10] = 1;
            cT[9] = cT[8](cT[10], cT[11], cT[12], cT[13]);
            cT[6][cT[7]] = cT[9];
            cT[11] = "\t\x13\x83\x965?\x1a\xf20\xdc\xd1\xa58\xe7r\x18s\xaa\xa1\xfd<B";
            cT[6] = J[cT[3]];
            cT[12] = 33842447662479;
            cT[8] = r15;
            cT[9] = r16;
            cT[10] = cT[9](cT[11], cT[12]);
            cT[7] = cT[8][cT[10]];
            cT[8] = 1;
            cT[12] = 17613578297353;
            cT[11] = "\x1f\xf3\xc60";
            cT[6][cT[7]] = cT[8];
            cT[6] = J[cT[3]];
            cT[15] = 1593387303653;
            cT[8] = r15;
            cT[9] = r16;
            cT[13] = 14374185867813;
            cT[10] = cT[9](cT[11], cT[12]);
            cT[7] = cT[8][cT[10]];
            cT[12] = "K\xbe\x8cpc\xb1-\xe93:\xber\xa1\x865}\xc0\x00\xba@M\xcf\x17Yq\x9aj\xfc\xcana)8JQ2";
            cT[9] = r15;
            cT[10] = r16;
            cT[11] = cT[10](cT[12], cT[13]);
            cT[8] = cT[9][cT[11]];
            cT[12] = 23985973586849;
            cT[6][cT[7]] = cT[8];
            cT[11] = "\xf4e\x84Yw\xbe\xc6\xb2[m";
            cT[6] = J[cT[3]];
            cT[8] = r15;
            cT[9] = r16;
            cT[10] = cT[9](cT[11], cT[12]);
            cT[7] = cT[8][cT[10]];
            cT[10] = "Color3";
            cT[9] = Env[cT[10]];
            cT[11] = r15;
            cT[12] = r16;
            cT[13] = cT[12](cT[14], cT[15]);
            cT[10] = cT[11][cT[13]];
            cT[8] = cT[9][cT[10]];
            cT[15] = "\\u\xa9\x03";
            cT[12] = 130;
            cT[10] = 100;
            cT[11] = 100;
            cT[9] = cT[8](cT[10], cT[11], cT[12]);
            cT[11] = "q\x88\xab_";
            cT[6][cT[7]] = cT[9];
            cT[6] = J[cT[3]];
            cT[8] = r15;
            cT[12] = 25080292289950;
            cT[9] = r16;
            cT[10] = cT[9](cT[11], cT[12]);
            cT[7] = cT[8][cT[10]];
            cT[11] = "Enum";
            cT[10] = Env[cT[11]];
            cT[12] = r15;
            cT[13] = r16;
            cT[14] = cT[13](cT[15], cT[16]);
            cT[11] = cT[12][cT[14]];
            cT[9] = cT[10][cT[11]];
            cT[15] = 22933644241335;
            cT[11] = r15;
            cT[12] = r16;
            cT[14] = "\xfd\x82\xfb\xc1o_&\xd6\x08\xdf\xe5\xab";
            cT[13] = cT[12](cT[14], cT[15]);
            cT[10] = cT[11][cT[13]];
            cT[8] = cT[9][cT[10]];
            cT[11] = "\x1a]$\x88!\xefO}";
            cT[12] = 28619295650830;
            cT[6][cT[7]] = cT[8];
            cT[6] = J[cT[3]];
            cT[8] = r15;
            cT[9] = r16;
            cT[10] = cT[9](cT[11], cT[12]);
            cT[7] = cT[8][cT[10]];
            cT[8] = 11;
            cT[6][cT[7]] = cT[8];
            cT[12] = 6955558685862;
            cT[6] = J[cT[3]];
            cT[8] = r15;
            cT[11] = "=d\\\xa9\xd6\x87\xc0\xd4\x8f\x0e(";
            cT[16] = "\xf8\x9f\xd2";
            cT[9] = r16;
            cT[10] = cT[9](cT[11], cT[12]);
            cT[13] = 5809983507089;
            cT[7] = cT[8][cT[10]];
            cT[8] = true;
            cT[6][cT[7]] = cT[8];
            cT[8] = "Color3";
            cT[7] = Env[cT[8]];
            cT[9] = r15;
            cT[12] = "x\xb8\xf4\xfdC\x0f+";
            cT[10] = r16;
            cT[11] = cT[10](cT[12], cT[13]);
            cT[10] = 80;
            cT[14] = 30922459822143;
            cT[8] = cT[9][cT[11]];
            cT[6] = cT[7][cT[8]];
            cT[8] = 50;
            cT[9] = 160;
            cT[7] = cT[6](cT[8], cT[9], cT[10]);
            cT[6] = 12;
            cT[9] = "Instance";
            J[cT[6]] = cT[7];
            cT[8] = Env[cT[9]];
            cT[10] = r15;
            cT[11] = r16;
            cT[13] = "\xc7\xe0\x1f";
            cT[12] = cT[11](cT[13], cT[14]);
            cT[9] = cT[10][cT[12]];
            cT[7] = cT[8][cT[9]];
            cT[14] = 34383546023563;
            cT[13] = "L\xd2\x88\xbbdn\xee7\x18\xe2";
            cT[10] = r15;
            cT[11] = r16;
            cT[12] = cT[11](cT[13], cT[14]);
            cT[9] = cT[10][cT[12]];
            cT[10] = r113;
            cT[8] = cT[7](cT[9], cT[10]);
            cT[7] = 13;
            J[cT[7]] = cT[8];
            cT[8] = J[cT[7]];
            cT[13] = "\xc9\x8a\x85c";
            cT[14] = 3646065968801;
            cT[10] = r15;
            cT[11] = r16;
            cT[12] = cT[11](cT[13], cT[14]);
            cT[9] = cT[10][cT[12]];
            cT[12] = "UDim2";
            cT[11] = Env[cT[12]];
            cT[13] = r15;
            cT[14] = r16;
            cT[15] = cT[14](cT[16], cT[17]);
            cT[12] = cT[13][cT[15]];
            cT[10] = cT[11][cT[12]];
            cT[14] = 0;
            cT[15] = 36;
            cT[13] = 0;
            cT[12] = 1;
            cT[11] = cT[10](cT[12], cT[13], cT[14], cT[15]);
            cT[8][cT[9]] = cT[11];
            cT[8] = J[cT[7]];
            cT[10] = r15;
            cT[11] = r16;
            cT[14] = 6549485161449;
            cT[13] = "?X\x80\x94\x04\xee%i\xa5\xd6'KX\xe6\xd8\r";
            cT[12] = cT[11](cT[13], cT[14]);
            cT[16] = "4\xbf\xe8";
            cT[9] = cT[10][cT[12]];
            cT[10] = J[cT[6]];
            cT[8][cT[9]] = cT[10];
            cT[8] = J[cT[7]];
            cT[13] = "0\xbf]!";
            cT[10] = r15;
            cT[14] = 2703978579179;
            cT[11] = r16;
            cT[17] = 19180506374883;
            cT[12] = cT[11](cT[13], cT[14]);
            cT[9] = cT[10][cT[12]];
            cT[11] = r15;
            cT[14] = "i\xc1\xc8\x8d\xa5Y\x0e\x0b\x87~~6\xae\xb5%R\x05\x00\x1a\x13\xe2mSX9\x8d\x98A\xfe";
            cT[12] = r16;
            cT[15] = 6167814343480;
            cT[13] = cT[12](cT[14], cT[15]);
            cT[10] = cT[11][cT[13]];
            cT[13] = "\xebs\xab\xde>\xc0\x9f\x00P\xab";
            cT[8][cT[9]] = cT[10];
            cT[8] = J[cT[7]];
            cT[10] = r15;
            cT[11] = r16;
            cT[14] = 12887895119729;
            cT[12] = cT[11](cT[13], cT[14]);
            cT[9] = cT[10][cT[12]];
            cT[12] = "Color3";
            cT[11] = Env[cT[12]];
            cT[13] = r15;
            cT[14] = r16;
            cT[15] = cT[14](cT[16], cT[17]);
            cT[12] = cT[13][cT[15]];
            cT[10] = cT[11][cT[12]];
            cT[13] = 1;
            cT[14] = 1;
            cT[12] = 1;
            cT[11] = cT[10](cT[12], cT[13], cT[14]);
            cT[8][cT[9]] = cT[11];
            cT[8] = J[cT[7]];
            cT[14] = 22104843642933;
            cT[5] = nil;
            cT[10] = r15;
            cT[11] = r16;
            cT[13] = "\xf9\xa8;\xed";
            cT[12] = cT[11](cT[13], cT[14]);
            cT[13] = "Enum";
            cT[9] = cT[10][cT[12]];
            cT[12] = Env[cT[13]];
            cT[14] = r15;
            cT[15] = r16;
            cT[17] = "\x04\xd1\x179";
            cT[16] = cT[15](cT[17], cT[18]);
            cT[13] = cT[14][cT[16]];
            cT[16] = "\x14\x8a\x89$\x9f\x18E\r\xbc ";
            cT[11] = cT[12][cT[13]];
            cT[13] = r15;
            cT[17] = 11269530244223;
            cT[14] = r16;
            cT[15] = cT[14](cT[16], cT[17]);
            cT[12] = cT[13][cT[15]];
            cT[10] = cT[11][cT[12]];
            cT[8][cT[9]] = cT[10];
            cT[13] = "o\xec\xb8\x02\x91\x17\xc4\x8b";
            cT[14] = 976733520326;
            cT[8] = J[cT[7]];
            cT[10] = r15;
            cT[11] = r16;
            cT[12] = cT[11](cT[13], cT[14]);
            cT[9] = cT[10][cT[12]];
            cT[10] = 13;
            cT[13] = "\xc0d\xbe\x1a\xccF\x15|\xae\x8a\xec\"\xf9\x92\x86";
            cT[8][cT[9]] = cT[10];
            cT[8] = J[cT[7]];
            cT[16] = "[\x00\x91";
            cT[10] = r15;
            cT[14] = 2179744580599;
            cT[11] = r16;
            cT[12] = cT[11](cT[13], cT[14]);
            cT[9] = cT[10][cT[12]];
            cT[10] = 0;
            cT[8][cT[9]] = cT[10];
            cT[15] = 22265773893760;
            cT[10] = "Instance";
            cT[9] = Env[cT[10]];
            cT[14] = "E\xe8E";
            cT[17] = 31684089133474;
            cT[11] = r15;
            cT[12] = r16;
            cT[13] = cT[12](cT[14], cT[15]);
            cT[10] = cT[11][cT[13]];
            cT[15] = 24080881003469;
            cT[8] = cT[9][cT[10]];
            cT[11] = r15;
            cT[12] = r16;
            cT[14] = "Y\xa3\xc0\xef\x83]\xf3\xe0";
            cT[13] = cT[12](cT[14], cT[15]);
            cT[10] = cT[11][cT[13]];
            cT[11] = J[cT[7]];
            cT[9] = cT[8](cT[10], cT[11]);
            cT[14] = 25988416139077;
            cT[13] = "h\xd1\xd8\xba\xacb\xb0{\xc3\xa5\x8b/";
            cT[10] = r15;
            cT[11] = r16;
            cT[12] = cT[11](cT[13], cT[14]);
            cT[8] = cT[10][cT[12]];
            cT[12] = "UDim";
            cT[11] = Env[cT[12]];
            cT[13] = r15;
            cT[14] = r16;
            cT[15] = cT[14](cT[16], cT[17]);
            cT[12] = cT[13][cT[15]];
            cT[14] = "\x1b\x13\x99j\xee\x86Q";
            cT[10] = cT[11][cT[12]];
            cT[13] = 10;
            cT[15] = 16751413517944;
            cT[12] = 0;
            cT[11] = cT[10](cT[12], cT[13]);
            cT[10] = "Color3";
            cT[9][cT[8]] = cT[11];
            cT[9] = Env[cT[10]];
            cT[11] = r15;
            cT[12] = r16;
            cT[13] = cT[12](cT[14], cT[15]);
            cT[12] = 100;
            cT[10] = cT[11][cT[13]];
            cT[11] = 200;
            cT[15] = "Am\xb8\x8eDO\xa1\xe6\x11w";
            cT[8] = cT[9][cT[10]];
            cT[10] = 70;
            cT[9] = cT[8](cT[10], cT[11], cT[12]);
            cT[8] = 14;
            J[cT[8]] = cT[9];
            cT[10] = J[cT[7]];
            cT[12] = r15;
            cT[13] = r16;
            cT[16] = 26576533680215;
            cT[14] = cT[13](cT[15], cT[16]);
            cT[11] = cT[12][cT[14]];
            cT[9] = cT[10][cT[11]];
            cT[16] = 5766347442813;
            cT[11] = function(...)
                v3 = r26;
                b = v3.Create(v3, J[cT[7]], TweenInfo.new(.15), {
                    ["BackgroundColor3"] = J[cT[8]]
                });
                b.Play(b);
                return; 
            end;
            cT[10] = "Connect";
            cT[10] = cT[9][cT[10]];
            cT[10] = cT[10](cT[9], cT[11]);
            cT[15] = "x?\x9c\xa5\x8f\x1c\xc3\xfd/+";
            cT[10] = J[cT[7]];
            cT[12] = r15;
            cT[13] = r16;
            cT[14] = cT[13](cT[15], cT[16]);
            cT[11] = cT[12][cT[14]];
            cT[9] = cT[10][cT[11]];
            cT[11] = function(...)
                v3 = r26;
                b = v3.Create(v3, J[cT[7]], TweenInfo.new(.15), {
                    ["BackgroundColor3"] = J[cT[6]]
                });
                b.Play(b);
                return; 
            end;
            cT[10] = "Connect";
            cT[16] = 30846639732764;
            cT[10] = cT[9][cT[10]];
            cT[10] = cT[10](cT[9], cT[11]);
            cT[15] = "\xb1\x868\xf1\xba\x87O\xdd\x8f\xf6\xff\xa1\xbf.\xce!\xdd";
            cT[10] = J[cT[7]];
            cT[12] = r15;
            cT[13] = r16;
            cT[14] = cT[13](cT[15], cT[16]);
            cT[11] = cT[12][cT[14]];
            cT[15] = 20532204561753;
            cT[9] = cT[10][cT[11]];
            cT[10] = "Connect";
            cT[11] = function(...)
                J[cT[7]].Text = "\xe2\x8f\xb3  Scanning...";
                r39 = "\xf0\x9f\x94\xac Scanning for eggs...";
                M = J[cT[2]];
                W = {
                    M.GetChildren(M)
                };
                o = M[3];
                y = M[2];
                for o, W in ipairs(k(W)) do
                    M = o;
                    v3 = "\xf0\x9f\x94\xac Scanning for eggs...";
                    if W.IsA(W, "TextButton") or W.IsA(W, "TextLabel") then
                        W.Destroy(W);
                    end; 
                end;
                task.spawn(function(...)
                    task.wait(.1);
                    if #r135() == 0 then
                        J[cT[3]].Text = "\xe2\x9d\x8c No eggs found in workspace";
                        J[cT[3]].TextColor3 = Color3.fromRGB(255, 80, 80);
                        J[cT[2]].Size = UDim2.new(1, 0, 0, 36);
                        r39 = "\xf0\x9f\x94\xac No eggs found";
                    else
                        J[cT[3]].Visible = false;
                        J[cT[2]].Size = UDim2.new(1, 0, 0, #v1 * (30 + 2) + 10 * 2);
                        b = ipairs;
                        v2 = 1[3];
                        W = 1[2];
                        for v2, v4 in b(v1) do
                            j = v2;
                            r139 = Instance.new("TextButton", J[cT[2]]);
                            r139.Size = UDim2.new(1, 0, 0, 30);
                            r139.BackgroundColor3 = Color3.fromRGB(30, 30, 48);
                            r139.BorderSizePixel = 0;
                            r139.Text = "\xf0\x9f\xa5\x9a  " .. v4.name;
                            r139.TextColor3 = Color3.fromRGB(220, 220, 255);
                            r139.Font = Enum.Font.GothamMedium;
                            r139.TextSize = 12;
                            r139.TextXAlignment = Enum.TextXAlignment.Left;
                            Instance.new("UICorner", r139).CornerRadius = UDim.new(0, 7);
                            Instance.new("UIPadding", r139).PaddingLeft = UDim.new(0, 8);
                            b = r139.MouseEnter;
                            b.Connect(b, function(...)
                                v3 = r26;
                                b = v3.Create(v3, r139, TweenInfo.new(.1), {
                                    ["BackgroundColor3"] = Color3.fromRGB(60, 40, 100)
                                });
                                b.Play(b);
                                return; 
                            end);
                            b = r139.MouseLeave;
                            b.Connect(b, function(...)
                                v3 = r26;
                                b = v3.Create(v3, r139, TweenInfo.new(.1), {
                                    ["BackgroundColor3"] = Color3.fromRGB(30, 30, 48)
                                });
                                b.Play(b);
                                return; 
                            end);
                            r140 = v4.name;
                            b = r139.MouseButton1Click;
                            b.Connect(b, function(...)
                                r34.HatchEgg = r140;
                                J[cT[1]].Text = "Selected: " .. r140;
                                v3 = r26;
                                b = v3.Create(v3, r139, TweenInfo.new(.1), {
                                    ["BackgroundColor3"] = Color3.fromRGB(30, 120, 60)
                                });
                                b.Play(b);
                                task.delay(.4, function(...)
                                    v3 = r26;
                                    b = v3.Create(v3, r139, TweenInfo.new(.2), {
                                        ["BackgroundColor3"] = Color3.fromRGB(30, 30, 48)
                                    });
                                    b.Play(b);
                                    return; 
                                end);
                                r39 = "\xf0\x9f\xa5\x9a Selected: " .. r140;
                                return; 
                            end); 
                        end;
                        r39 = "\xf0\x9f\x94\xac Found " .. #v1 .. " egg(s)";
                        J[cT[7]].Text = "\xf0\x9f\x94\xac  Scan Workspace for Eggs";
                        return;
                    end; 
                end);
                return; 
            end;
            cT[10] = cT[9][cT[10]];
            cT[10] = cT[10](cT[9], cT[11]);
            cT[11] = r15;
            cT[14] = "\xe13\x9a\xf5\x99\x06\xb9\xb8wP\xad\xd8DN\x8bp\x93p5\xafO";
            cT[12] = r16;
            cT[13] = cT[12](cT[14], cT[15]);
            cT[16] = 2337464861760;
            cT[14] = "e\xfe\x06\x9d97\xf1\x1fT\xcbt\xd4";
            cT[10] = cT[11][cT[13]];
            cT[15] = 11888541013408;
            cT[9] = HT(cT[10]);
            cT[11] = r15;
            cT[12] = r16;
            cT[13] = cT[12](cT[14], cT[15]);
            cT[10] = cT[11][cT[13]];
            cT[12] = r15;
            cT[15] = "\x90\xc4\x97\xa0";
            cT[18] = "~\xe3C\xd4\xc7\x91\xee";
            cT[13] = r16;
            cT[14] = cT[13](cT[15], cT[16]);
            cT[11] = cT[12][cT[14]];
            cT[12] = function(arg1_28, ...)
                v1 = arg1_28;
                r33.AutoCollect = v1;
                if v1 then
                    r69();
                else
                    r71();
                end;
                return; 
            end;
            cT[9] = bT(cT[10], cT[11], cT[12]);
            cT[11] = r15;
            cT[12] = r16;
            cT[14] = "\t\xbf\xc8\x80\"\xc2I\xbfs\xdc";
            cT[15] = 5385446853067;
            cT[13] = cT[12](cT[14], cT[15]);
            cT[10] = cT[11][cT[13]];
            cT[12] = r15;
            cT[13] = r16;
            cT[16] = 17311133491069;
            cT[15] = "\x9d\xe0\x0e\x18";
            cT[14] = cT[13](cT[15], cT[16]);
            cT[11] = cT[12][cT[14]];
            cT[12] = function(arg1_29, ...)
                v1 = arg1_29;
                r33.AutoQuest = v1;
                if v1 then
                    r78();
                else
                    r79();
                end;
                return; 
            end;
            cT[9] = bT(cT[10], cT[11], cT[12]);
            cT[16] = 8638347513782;
            cT[11] = r15;
            cT[12] = r16;
            cT[14] = "A\xe8\x89- \x0c~J\x10\xfe\xf2";
            cT[15] = 35182079999998;
            cT[13] = cT[12](cT[14], cT[15]);
            cT[10] = cT[11][cT[13]];
            cT[12] = r15;
            cT[13] = r16;
            cT[15] = "\x01\x82=\xcd";
            cT[14] = cT[13](cT[15], cT[16]);
            cT[8] = nil;
            cT[11] = cT[12][cT[14]];
            cT[14] = "Color3";
            cT[13] = Env[cT[14]];
            cT[15] = r15;
            cT[16] = r16;
            cT[17] = cT[16](cT[18], cT[19]);
            cT[14] = cT[15][cT[17]];
            cT[12] = cT[13][cT[14]];
            cT[14] = 200;
            cT[16] = 20;
            cT[15] = 80;
            cT[13] = cT[12](cT[14], cT[15], cT[16]);
            cT[9] = AT(cT[10], cT[11], cT[13], function(...)
                o = r80;
                v1 = 115[2];
                o = 115[1];
                for y, W in ipairs(o) do
                    r141 = W;
                    pcall(function(...)
                        v1 = r41(r141);
                        if v1 then
                            v1.FireServer(v1);
                        end;
                        return; 
                    end); 
                end;
                M = workspace;
                W = {
                    M.GetDescendants(M)
                };
                o = M[3];
                for o, W in M[1], ipairs(k(W)) do
                    r142 = W;
                    M = o;
                    v3 = r142;
                    if v3.IsA(v3, "ProximityPrompt") then
                        v3 = r142.ActionText .. " " .. r142.ObjectText;
                        v2 = v3.lower(v3);
                        if v2.find(v2, "rebirth") or v2.find(v2, "prestige") then
                            pcall(function(...)
                                fireproximityprompt(r142);
                                return; 
                            end);
                        end;
                    end; 
                end;
                return; 
            end);
            cT[15] = 31886429780480;
            cT[11] = r15;
            cT[12] = r16;
            cT[14] = "k\xd0\xe5c2H\xe2\xe0\x1f!S\x8e\x13";
            cT[13] = cT[12](cT[14], cT[15]);
            cT[10] = cT[11][cT[13]];
            cT[9] = HT(cT[10]);
            cT[11] = r15;
            cT[12] = r16;
            cT[14] = "m\x8a\xce\xe0R\xe7\xb8\xfdfX^";
            cT[15] = 13683223599331;
            cT[13] = cT[12](cT[14], cT[15]);
            cT[10] = cT[11][cT[13]];
            cT[12] = r15;
            cT[13] = r16;
            cT[16] = 11907224753576;
            cT[15] = "p&\x0c";
            cT[14] = cT[13](cT[15], cT[16]);
            cT[11] = cT[12][cT[14]];
            cT[12] = function(arg1_30, ...)
                v1 = arg1_30;
                r33.SpeedBoost = v1;
                if v1 then
                    r82();
                else
                    r83();
                end;
                return; 
            end;
            cT[9] = bT(cT[10], cT[11], cT[12]);
            cT[11] = r15;
            cT[16] = 14678661913267;
            cT[12] = r16;
            cT[15] = 23249805781578;
            cT[14] = "}\xb5\xee%\x13\xdd\x86\xe9\x98\xde";
            cT[13] = cT[12](cT[14], cT[15]);
            cT[10] = cT[11][cT[13]];
            cT[12] = r15;
            cT[2] = nil;
            cT[15] = "SQ\xd15";
            cT[13] = r16;
            cT[14] = cT[13](cT[15], cT[16]);
            cT[15] = function(arg1_31, ...)
                r34.SpeedValue = arg1_31;
                return; 
            end;
            cT[11] = cT[12][cT[14]];
            cT[13] = 200;
            cT[14] = 50;
            cT[12] = 16;
            cT[9] = JT(cT[10], cT[11], cT[12], cT[13], cT[14], cT[15]);
            cT[15] = 28730255668290;
            cT[11] = r15;
            cT[14] = "`|D";
            cT[19] = 10826360640433;
            cT[12] = r16;
            cT[13] = cT[12](cT[14], cT[15]);
            cT[15] = "I\xe4Wy\x02\x0b\x02";
            cT[16] = 27322354315698;
            cT[10] = cT[11][cT[13]];
            cT[12] = r15;
            cT[13] = r16;
            cT[14] = cT[13](cT[15], cT[16]);
            cT[11] = cT[12][cT[14]];
            cT[15] = 706548580681;
            cT[16] = 33797696060794;
            cT[12] = function(arg1_32, ...)
                v1 = arg1_32;
                r33.Fly = v1;
                if v1 then
                    r86();
                else
                    r87();
                end;
                return; 
            end;
            cT[14] = "\xce\xab:\xc2\xe2\xfc\xaa\xd8f";
            cT[9] = bT(cT[10], cT[11], cT[12]);
            cT[11] = r15;
            cT[12] = r16;
            cT[13] = cT[12](cT[14], cT[15]);
            cT[10] = cT[11][cT[13]];
            cT[12] = r15;
            cT[15] = "\xb3Ao_";
            cT[13] = r16;
            cT[14] = cT[13](cT[15], cT[16]);
            cT[11] = cT[12][cT[14]];
            cT[15] = function(arg1_33, ...)
                r34.FlySpeed = arg1_33;
                return; 
            end;
            cT[14] = 80;
            cT[12] = 20;
            cT[13] = 300;
            cT[16] = 28051766604550;
            cT[4] = nil;
            cT[9] = JT(cT[10], cT[11], cT[12], cT[13], cT[14], cT[15]);
            cT[11] = r15;
            cT[12] = r16;
            cT[15] = 5209696373113;
            cT[14] = "0\xcc\x02\xb70\x87";
            cT[13] = cT[12](cT[14], cT[15]);
            cT[15] = "e\xa2D\x0f";
            cT[10] = cT[11][cT[13]];
            cT[12] = r15;
            cT[13] = r16;
            cT[14] = cT[13](cT[15], cT[16]);
            cT[11] = cT[12][cT[14]];
            cT[12] = function(arg1_34, ...)
                v1 = arg1_34;
                r33.Noclip = v1;
                if v1 then
                    r89();
                else
                    r90();
                end;
                return; 
            end;
            cT[15] = 31336890235136;
            cT[9] = bT(cT[10], cT[11], cT[12]);
            cT[16] = 10987204072444;
            cT[11] = r15;
            cT[14] = "V\xf1}\xc7X\n\xd8;";
            cT[12] = r16;
            cT[13] = cT[12](cT[14], cT[15]);
            cT[10] = cT[11][cT[13]];
            cT[15] = "N?\x92\x90";
            cT[12] = r15;
            cT[3] = nil;
            cT[13] = r16;
            cT[18] = "\xa7X-\xd0t~{";
            cT[14] = cT[13](cT[15], cT[16]);
            cT[11] = cT[12][cT[14]];
            cT[15] = 28739036968006;
            cT[14] = "\xd21~@\x99\x97m\x9e\x12\xf5";
            cT[12] = function(arg1_35, ...)
                v1 = arg1_35;
                r33.InfJump = v1;
                if v1 then
                    r96();
                else
                    r97();
                end;
                return; 
            end;
            cT[9] = bT(cT[10], cT[11], cT[12]);
            cT[11] = r15;
            cT[12] = r16;
            cT[13] = cT[12](cT[14], cT[15]);
            cT[6] = nil;
            cT[10] = cT[11][cT[13]];
            cT[9] = HT(cT[10]);
            cT[16] = 15845453421778;
            cT[14] = "\x86\xc3\xa7\xfa\x062\xb7\x96";
            cT[7] = nil;
            cT[11] = r15;
            cT[15] = 17890192679050;
            cT[12] = r16;
            cT[13] = cT[12](cT[14], cT[15]);
            cT[15] = "\xfb\x1c\xb7\xe9\x0eO\xf9";
            cT[10] = cT[11][cT[13]];
            cT[12] = r15;
            cT[13] = r16;
            cT[14] = cT[13](cT[15], cT[16]);
            cT[11] = cT[12][cT[14]];
            cT[16] = 25591473565324;
            cT[15] = 20227657540811;
            cT[12] = function(arg1_36, ...)
                v1 = arg1_36;
                r33.AntiAFK = v1;
                if v1 then
                    r92();
                else
                    r94();
                end;
                return; 
            end;
            cT[14] = "7uO\xe6\xc5\xfaN\xe9\"'\xa02;";
            cT[9] = bT(cT[10], cT[11], cT[12]);
            cT[11] = r15;
            cT[12] = r16;
            cT[13] = cT[12](cT[14], cT[15]);
            cT[10] = cT[11][cT[13]];
            cT[15] = "\xe5\x8f\xa5\xf9\xc5\"\x82";
            cT[12] = r15;
            cT[13] = r16;
            cT[14] = cT[13](cT[15], cT[16]);
            cT[11] = cT[12][cT[14]];
            cT[15] = 2354418926664;
            cT[12] = function(arg1_37, ...)
                v1 = arg1_37;
                r33.ESP = v1;
                if v1 then
                    r107();
                else
                    r108();
                end;
                return; 
            end;
            cT[9] = bT(cT[10], cT[11], cT[12]);
            cT[11] = r15;
            cT[12] = r16;
            cT[14] = "|>yl\xdd\xc0\xaa\xdaH\xec\xe0\xe8\xdc\x86\tP\xd5";
            cT[13] = cT[12](cT[14], cT[15]);
            cT[15] = "\xf8&lo";
            cT[10] = cT[11][cT[13]];
            cT[12] = r15;
            cT[13] = r16;
            cT[16] = 9230750814410;
            cT[14] = cT[13](cT[15], cT[16]);
            cT[11] = cT[12][cT[14]];
            cT[14] = "Color3";
            cT[13] = Env[cT[14]];
            cT[15] = r15;
            cT[16] = r16;
            cT[17] = cT[16](cT[18], cT[19]);
            cT[14] = cT[15][cT[17]];
            cT[12] = cT[13][cT[14]];
            cT[15] = 100;
            cT[16] = 180;
            cT[14] = 30;
            cT[13] = cT[12](cT[14], cT[15], cT[16]);
            cT[12] = function(...)
                v3 = workspace;
                v1 = v3.FindFirstChildOfClass(v3, "SpawnLocation");
                if v1 then
                    r40(v1.Position);
                end;
                return; 
            end;
            cT[17] = "\xdf\x99\x8f`\xd6\x8e\xf13y\xc4";
            cT[9] = AT(cT[10], cT[11], cT[13], cT[12]);
            cT[12] = 15;
            cT[11] = nil;
            cT[10] = nil;
            cT[9] = false;
            J[cT[12]] = cT[9];
            cT[18] = 7528418315697;
            cT[9] = 16;
            J[cT[9]] = cT[10];
            cT[10] = 17;
            J[cT[10]] = cT[11];
            cT[14] = r15;
            cT[19] = 6935759129757;
            cT[15] = r16;
            cT[16] = cT[15](cT[17], cT[18]);
            cT[13] = cT[14][cT[16]];
            cT[18] = "\xf6Rt\xba\xe6?\xf2\x17\xf9 ";
            cT[14] = function(arg1_38, ...)
                v1 = arg1_38;
                if v1.UserInputType == Enum.UserInputType.MouseButton1 then
                    J[cT[12]] = true;
                    J[cT[9]] = v1.Position;
                    J[cT[10]] = r109.Position;
                end;
                return; 
            end;
            cT[11] = sq[cT[13]];
            cT[13] = "Connect";
            cT[13] = cT[11][cT[13]];
            cT[13] = cT[13](cT[11], cT[14]);
            cT[13] = r25;
            cT[15] = r15;
            cT[16] = r16;
            cT[17] = cT[16](cT[18], cT[19]);
            cT[14] = cT[15][cT[17]];
            cT[11] = cT[13][cT[14]];
            cT[14] = function(arg1_39, ...)
                if arg1_39.UserInputType == Enum.UserInputType.MouseButton1 then
                    J[cT[12]] = false;
                end;
                return; 
            end;
            cT[18] = "9\xdccAC\x841U\xc4\xf8\x8ar";
            cT[13] = "Connect";
            cT[13] = cT[11][cT[13]];
            cT[13] = cT[13](cT[11], cT[14]);
            cT[13] = r25;
            cT[15] = r15;
            cT[19] = 6993855876280;
            cT[16] = r16;
            cT[17] = cT[16](cT[18], cT[19]);
            cT[14] = cT[15][cT[17]];
            cT[11] = cT[13][cT[14]];
            cT[14] = function(arg1_40, ...)
                v1 = arg1_40;
                if J[cT[12]] and v1.UserInputType == Enum.UserInputType.MouseMovement then
                    y = v1.Position - J[cT[9]];
                    r109.Position = UDim2.new(J[cT[10]].X.Scale, J[cT[10]].X.Offset + y.X, J[cT[10]].Y.Scale, J[cT[10]].Y.Offset + y.Y);
                end;
                return; 
            end;
            cT[13] = "Connect";
            cT[19] = "\x18;\xf4\xf0\x1a\xd2\xd9g\x04\n\x11Y\xca\xcd\xd0EO";
            cT[13] = cT[11][cT[13]];
            cT[13] = cT[13](cT[11], cT[14]);
            cT[11] = false;
            cT[13] = 18;
            J[cT[13]] = cT[11];
            cT[12] = nil;
            cT[14] = r110;
            cT[16] = r15;
            cT[10] = nil;
            cT[17] = r16;
            cT[18] = cT[17](cT[19], cT[20]);
            cT[15] = cT[16][cT[18]];
            cT[11] = cT[14][cT[15]];
            cT[15] = function(...)
                v3 = not J[cT[13]];
                J[cT[13]] = v3;
                r113.Visible = not J[cT[13]];
                r111.Visible = not J[cT[13]];
                b = r109;
                v1 = "Size";
                v2 = J[cT[13]];
                o = v3;
                if v2 then
                    M = UDim2.new(0, 320, 0, 52);
                end;
                v3 = v3;
                y = v2;
                if v2 then
                    r109.Size = M;
                    v3 = v3;
                    v3 = v3;
                    r110.Text = J[cT[13]] and "\xe2\x96\xa2" or "\xe2\x80\x94";
                    return;
                else
                    y = UDim2.new(0, 320, 0, 600);
                end; 
            end;
            cT[14] = "Connect";
            cT[19] = "\x16q@\x19\xcb";
            cT[20] = 22822570322307;
            cT[14] = cT[11][cT[14]];
            cT[14] = cT[14](cT[11], cT[15]);
            cT[15] = "task";
            cT[14] = Env[cT[15]];
            cT[16] = r15;
            cT[17] = r16;
            cT[18] = cT[17](cT[19], cT[20]);
            cT[19] = "\x16Z\xa9~iW\xb1\x82\xacF\xac-\x95+";
            cT[15] = cT[16][cT[18]];
            cT[9] = nil;
            cT[11] = cT[14][cT[15]];
            cT[15] = function(...)
                while task.wait(0.25) do
                    pcall(function(...)
                        r112.Text = "Status: " .. r39;
                        return; 
                    end); 
                end;
                return; 
            end;
            cT[20] = 24513867574423;
            cT[14] = cT[11](cT[15]);
            cT[14] = r28;
            cT[16] = r15;
            cT[17] = r16;
            cT[18] = cT[17](cT[19], cT[20]);
            cT[15] = cT[16][cT[18]];
            cT[20] = 20888349615614;
            cT[11] = cT[14][cT[15]];
            cT[15] = function(...)
                task.wait(1);
                if r33.SpeedBoost then
                    r83();
                    r82();
                end;
                if r33.Fly then
                    r87();
                    r86();
                end;
                if r33.Noclip then
                    r90();
                    r89();
                end;
                if r33.InfJump then
                    r97();
                    r96();
                end;
                return; 
            end;
            cT[14] = "Connect";
            cT[19] = "\x0f\x84\xf5j\xa9\xff\x83\x96\xc99G\xa7u\xfdXYe\x88\xa4\x93\x0b\x87\xb9\xf7)1\xa4\x82\xaa\xf8\xdc)zJbH\x17\xad";
            cT[14] = cT[11][cT[14]];
            cT[1] = nil;
            cT[14] = cT[14](cT[11], cT[15]);
            cT[14] = "print";
            cT[11] = Env[cT[14]];
            cT[16] = r15;
            cT[17] = r16;
            cT[18] = cT[17](cT[19], cT[20]);
            cT[13] = nil;
            cT[15] = cT[16][cT[18]];
            cT[14] = cT[11](cT[15]);
            return;
        end;
    end;
end;
return (function(...)
    while true do
        l1 = l2;
        l2 = l1;
        r3(); 
    end;
    return; 
end)();