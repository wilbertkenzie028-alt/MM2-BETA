local L_1_ = game:GetService("Players")
local L_2_ = game:GetService("RunService")
local L_3_ = game:GetService("UserInputService")
local L_4_ = game:GetService("TeleportService")
local L_5_ = game:GetService("HttpService")
local L_6_ = game:GetService("Lighting")
local L_7_ = game:GetService("Workspace")
local L_8_ = game:GetService("VirtualUser")
local L_9_ = game:GetService("ReplicatedStorage")
local L_10_ = game:GetService("TweenService")
local L_11_ = game:GetService("CollectionService")

local L_12_ = L_1_.LocalPlayer
local L_13_ = L_7_.CurrentCamera

local L_14_ = getgenv and getgenv() or _G

local L_15_ = " SNOWY HUB v6.0"
local L_16_ = "SNOWY HUB v6.0 | Built by Snowy Studios"
local L_17_ = "https://discord.gg/getsnowy"

local L_18_ = {
	AutoBuySeeds = false,
	AutoBuyPets = false,
	AutoHarvest = false,
	AutoSell = false,
	SelectedSeed = "ALL",
	SelectedPet = "ALL",
	SeedDelay = 0.03,
	PetDelay = 0.15,
	HarvestDelay = 0.08,
	PetTweenSpeed = 16,
	PetBuyingInProgress = false,
	WalkSpeed = 16,
	JumpPower = 50,
	WSLock = false,
	JPLock = false,
	Disable3D = false,
	FPSBoost = false,
}

local L_19_ = {
	Enabled = false,
	ShowFOV = false,
	FOVRadius = 100,
	Smoothness = 0.10,
	TeamCheck = false,
	TargetPart = "Head",
}

local L_20_ = {
	noclip = nil,
	antiIdle = nil,
	aimbot = nil,
	modifier = nil,
}

local L_21_ = {
	HubName = L_15_,
	Credit = L_16_,
	State = L_18_,
	Aimbot = L_19_,
}

local function L_22_func(L_96_arg0, L_97_arg1, L_98_arg2, L_99_arg3)
	L_98_arg2 = L_98_arg2 or 3
	local L_100_ = L_14_.Window
	if L_100_ and type(L_100_.Notify) == "function" then
		pcall(function()
			L_100_:Notify(L_96_arg0, L_97_arg1, L_98_arg2, L_99_arg3 == true)
		end)
		return
	end
	warn(("[SnowyHub] %s: %s"):format(tostring(L_96_arg0), tostring(L_97_arg1)))
end

local function L_23_func()
	return L_12_.Character
end

local function L_24_func()
	local L_101_ = L_23_func()
	return L_101_ and L_101_:FindFirstChild("HumanoidRootPart")
end

local function L_25_func()
	local L_102_ = L_23_func()
	return L_102_ and L_102_:FindFirstChildOfClass("Humanoid")
end

function L_21_.SetWalkSpeed(L_103_arg0)
	L_14_.WalkSpeedValue = L_103_arg0
	local L_104_ = L_25_func()
	if L_104_ then
		L_104_.WalkSpeed = L_103_arg0
	end
end

function L_21_.SetJumpPower(L_105_arg0)
	L_14_.JumpPowerValue = L_105_arg0
	local L_106_ = L_25_func()
	if L_106_ then
		L_106_.JumpPower = L_105_arg0
	end
end

function L_21_.SetGravity(L_107_arg0)
	L_7_.Gravity = L_107_arg0
end

local function L_26_func()
	local L_108_ = L_25_func()
	if not L_108_ then
		return
	end
	L_108_.MaxHealth = 100
	L_108_.Health = 100
	L_108_:SetStateEnabled(Enum.HumanoidStateType.Dead, true)
end

local function L_27_func()
	local L_109_ = L_23_func()
	if not L_109_ then
		return
	end
	local L_110_ = L_109_:FindFirstChild("Humanoid")
	local L_111_ = L_109_:FindFirstChild("HumanoidRootPart")
	if not L_110_ or not L_111_ or not L_14_.GodModeEnabled then
		return
	end
	if L_110_.MaxHealth ~= math.huge then
		L_110_.MaxHealth = math.huge
	end
	if L_110_.Health ~= math.huge then
		L_110_.Health = math.huge
	end
	pcall(function()
		L_110_:SetStateEnabled(Enum.HumanoidStateType.Dead, false)
	end)
end

function L_21_.SetGodMode(L_112_arg0)
	L_14_.GodModeEnabled = L_112_arg0
	if L_112_arg0 then
		pcall(L_27_func)
	else
		pcall(L_26_func)
	end
end

local function L_28_func()
	local L_113_ = L_23_func()
	if not L_113_ then
		return
	end
	for L_114_forvar0, L_115_forvar1 in pairs(L_113_:GetDescendants()) do
		if L_115_forvar1:IsA("BasePart")
            and L_115_forvar1.CanCollide
            and L_115_forvar1.Name ~= L_14_.floatName
        then
			L_115_forvar1.CanCollide = false
		end
	end

	task.wait(0.21)
end

function L_21_.SetNoclip(L_116_arg0)
	if L_116_arg0 then
		if not L_20_.noclip then
			L_20_.noclip = L_2_.Stepped:Connect(function()
				pcall(L_28_func)
			end)
		end
	elseif L_20_.noclip then
		L_20_.noclip:Disconnect()
		L_20_.noclip = nil
	end
end

local L_29_ = false

L_3_.JumpRequest:Connect(function()
	if not L_29_ then
		return
	end
	local L_117_ = L_25_func()
	if L_117_ then
		L_117_:ChangeState("Jumping")
	end
end)

function L_21_.SetInfiniteJump(L_118_arg0)
	L_29_ = L_118_arg0
end

function L_21_.SetCameraFOV(L_119_arg0)
	L_7_.CurrentCamera.FieldOfView = L_119_arg0
end

function L_21_.SetFullbright(L_120_arg0)
	if L_120_arg0 then
		L_6_.Ambient = Color3.new(1, 1, 1)
		L_6_.ColorShift_Bottom = Color3.new(1, 1, 1)
		L_6_.ColorShift_Top = Color3.new(1, 1, 1)
		L_6_.GlobalShadows = false
	else
		L_6_.Ambient = Color3.fromRGB(128, 128, 128)
		L_6_.GlobalShadows = true
	end
end

local L_30_ = {}

function L_21_.SetPlayerESP(L_121_arg0)
	if not L_121_arg0 then
		for L_122_forvar0, L_123_forvar1 in ipairs(L_30_) do
			pcall(function()
				L_123_forvar1:Destroy()
			end)
		end
		table.clear(L_30_)
		return
	end
	for L_124_forvar0, L_125_forvar1 in pairs(L_1_:GetPlayers()) do
		if L_125_forvar1 ~= L_12_ and L_125_forvar1.Character then
			local L_126_ = Instance.new("Highlight")
			L_126_.Parent = L_125_forvar1.Character

			L_126_.FillTransparency = 0.5
			L_126_.OutlineTransparency = 0
			table.insert(L_30_, L_126_)
		end
	end
end

local function L_31_func(L_127_arg0)
	local L_128_ = L_127_arg0.Character
	local L_129_ = L_128_ and L_128_:FindFirstChild("HumanoidRootPart")
	if not L_129_ then
		return
	end
	local L_130_ = _G.HeadSize
	L_129_.Size = Vector3.new(L_130_, L_130_, L_130_)
	L_129_.Transparency = 0.7
	L_129_.BrickColor = BrickColor.new("Really red")
	L_129_.Material = Enum.Material.Neon
	L_129_.CanCollide = false
end

function L_21_.SetHitboxSize(L_131_arg0)
	_G.HeadSize = L_131_arg0
	_G.Disabled = true

	L_2_.RenderStepped:Connect(function()
		if not _G.Disabled then
			return
		end
		for L_132_forvar0, L_133_forvar1 in next, L_1_:GetPlayers() do
			if L_133_forvar1.Name ~= L_12_.Name then
				pcall(L_31_func, L_133_forvar1)
			end
		end
	end)
end

local L_32_ = nil

if Drawing and Drawing.new then
	L_32_ = Drawing.new("Circle")
	L_32_.Visible = false
	L_32_.Filled = false
	L_32_.Thickness = 1
end

local function L_33_func()
	local L_134_ = L_19_.FOVRadius
	local L_135_ = nil
	local L_136_ = L_3_:GetMouseLocation()
	for L_137_forvar0, L_138_forvar1 in pairs(L_1_:GetPlayers()) do
		if L_138_forvar1 ~= L_12_ and L_138_forvar1.Character then
			local L_139_ = L_138_forvar1.Character:FindFirstChild(L_19_.TargetPart)
			local L_140_ = L_138_forvar1.Character:FindFirstChild("Humanoid")
			if L_139_ and L_140_ and L_140_.Health > 0 then
				local L_141_ = L_138_forvar1.Team == L_12_.Team

				if not L_19_.TeamCheck or not L_141_ then
					local L_142_, L_143_ =
                        L_7_.CurrentCamera:WorldToViewportPoint(L_139_.Position)
					if L_143_ then
						local L_144_ =
                            (Vector2.new(L_142_.X, L_142_.Y) - L_136_).Magnitude
						if L_144_ < L_134_ then
							L_134_ = L_144_
							L_135_ = L_138_forvar1
						end
					end
				end
			end
		end
	end
	return L_135_
end

local function L_34_func()
	if L_32_ then
		if L_19_.ShowFOV then
			L_32_.Position = L_3_:GetMouseLocation()
			L_32_.Radius = L_19_.FOVRadius
			L_32_.Visible = true
		else
			L_32_.Visible = false
		end
	end
	if not L_19_.Enabled then
		return
	end
	if not L_3_:IsMouseButtonPressed(Enum.UserInputType.MouseButton2) then
		return
	end
	local L_145_ = L_33_func()
	if not L_145_ or not L_145_.Character then
		return
	end
	local L_146_ = L_145_.Character:FindFirstChild(L_19_.TargetPart)
	if not L_146_ then
		return
	end
	L_13_ = L_7_.CurrentCamera
	local L_147_ =
        CFrame.new(L_13_.CFrame.Position, L_146_.Position)
	L_13_.CFrame =
        L_13_.CFrame:Lerp(L_147_, L_19_.Smoothness)
end

L_20_.aimbot = L_2_.RenderStepped:Connect(L_34_func)

function L_21_.SetAimbotEnabled(L_148_arg0)
	L_19_.Enabled = L_148_arg0
end

function L_21_.SetShowFOV(L_149_arg0)
	L_19_.ShowFOV = L_149_arg0
end

function L_21_.SetFOVRadius(L_150_arg0)
	L_19_.FOVRadius = L_150_arg0
end

function L_21_.SetAimbotSmoothness(L_151_arg0)
	L_19_.Smoothness = L_151_arg0 / 100
end

function L_21_.SetTeamCheck(L_152_arg0)
	L_19_.TeamCheck = L_152_arg0
end

function L_21_.GiveBtools()
	local L_153_ = L_12_:FindFirstChildOfClass("Backpack") or L_12_.Backpack
	local L_154_ = Instance.new("HopperBin", L_153_)
	L_154_.BinType = "Clone"
	local L_155_ = Instance.new("HopperBin", L_153_)
	L_155_.BinType = "Hammer"
	local L_156_ = Instance.new("HopperBin", L_153_)
	L_156_.BinType = "Grab"
end

function L_21_.TeleportToRandomPlayer()
	local L_157_ = L_1_:GetPlayers()
	if #L_157_ <= 1 then
		return
	end
	local L_158_
	repeat
		L_158_ = L_157_[math.random(1, #L_157_)]
	until L_158_ ~= L_12_
	local L_159_ = L_24_func()
	local L_160_ =
        L_158_.Character and L_158_.Character:FindFirstChild("HumanoidRootPart")
	if L_159_ and L_160_ then
		L_159_.CFrame = L_160_.CFrame * CFrame.new(0, 0, 3)
	end
end

function L_21_.RejoinServer()
	L_4_:TeleportToPlaceInstance(
        game.PlaceId,
        game.JobId,
        L_12_
    )
end

local function L_35_func(L_161_arg0, L_162_arg1)
	local L_163_ = L_162_arg1 and ("&cursor=" .. L_162_arg1) or ""
	local L_164_ = game:HttpGet(L_161_arg0 .. L_163_)
	return L_5_:JSONDecode(L_164_)
end

function L_21_.ServerHop()
	local L_165_ = game.PlaceId
	local L_166_ =
        "https://games.roblox.com/v1/games/"
        .. tostring(L_165_)
        .. "/servers/Public?sortOrder=Asc&limit=100"
	local L_167_ = nil
	repeat
		local L_168_ = L_35_func(L_166_, L_167_)
		for L_169_forvar0, L_170_forvar1 in ipairs(L_168_.data or {}) do
			if L_170_forvar1.id ~= game.JobId
                and L_170_forvar1.playing < L_170_forvar1.maxPlayers
            then
				L_4_:TeleportToPlaceInstance(
                    L_165_,
                    L_170_forvar1.id,
                    L_12_
                )
				return
			end
		end
		L_167_ = L_168_.nextPageCursor
	until not L_167_
end

local function L_36_func()
	L_8_:CaptureController()
	L_8_:ClickButton2(Vector2.new(0, 0))
end

function L_21_.SetAntiKick(L_171_arg0)

	local L_172_ = getconnections or get_signal_cons
	if L_171_arg0 and L_172_ then
		for L_173_forvar0, L_174_forvar1 in pairs(L_172_(L_12_.Idled)) do
			if L_174_forvar1.Disable then
				L_174_forvar1:Disable()
			elseif L_174_forvar1.Disconnect then
				L_174_forvar1:Disconnect()
			end
		end
	end
	if L_171_arg0 then
		if not L_20_.antiIdle then
			L_20_.antiIdle = L_12_.Idled:Connect(function()
				pcall(L_36_func)
			end)
		end
	elseif L_20_.antiIdle then
		pcall(function()
			L_20_.antiIdle:Disconnect()
		end)
		L_20_.antiIdle = nil
	end
	L_22_func(
        "AFK Safety",
        L_171_arg0 and "Anti-Kick Enabled" or "Anti-Kick Disabled"
    )
end

function L_21_.SetDisable3D(L_175_arg0)
	L_18_.Disable3D = L_175_arg0
	pcall(function()
		L_2_:Set3dRenderingEnabled(not L_18_.Disable3D)
	end)
	L_22_func(
        "Performance",
        L_175_arg0 and "3D Rendering Disabled" or "3D Rendering Enabled"
    )
end

local function L_37_func()
	local L_176_ = L_7_:FindFirstChildOfClass("Terrain")
	if L_18_.FPSBoost then
		settings().Rendering.QualityLevel = 1
		L_6_.GlobalShadows = false
		L_6_.OutdoorAmbient = Color3.new(1, 1, 1)
		if L_176_ then
			L_176_.WaterWaveSize = 0
			L_176_.WaterWaveSpeed = 0
			L_176_.WaterReflectance = 0
			L_176_.WaterDetailSize = 0
		end
		for L_177_forvar0, L_178_forvar1 in ipairs(L_7_:GetDescendants()) do
			if L_178_forvar1:IsA("BasePart") then
				L_178_forvar1.Material = Enum.Material.SmoothPlastic
				if L_178_forvar1:IsA("MeshPart") or L_178_forvar1:IsA("UnionOperation") then
					L_178_forvar1.Reflectance = 0
				end
			elseif L_178_forvar1:IsA("Decal") or L_178_forvar1:IsA("Texture") then
				L_178_forvar1:Destroy()
			end
		end
	else
		settings().Rendering.QualityLevel = 0
		L_6_.GlobalShadows = true
		if L_176_ then
			L_176_.WaterWaveSize = 0.15
			L_176_.WaterWaveSpeed = 10
			L_176_.WaterReflectance = 1
			L_176_.WaterDetailSize = 0.3
		end
	end
end

function L_21_.SetFPSBooster(L_179_arg0)
	L_18_.FPSBoost = L_179_arg0
	pcall(L_37_func)
	L_22_func(
        "Performance",
        L_179_arg0 and "FPS Booster Active" or "FPS Booster Disabled"
    )
end

function L_21_.CopyDiscord()
	if setclipboard then
		setclipboard(L_17_)
	end
	L_22_func("Copied!", "Discord link copied.", 3, false)
end

local L_38_ = 0

local function L_39_func(L_180_arg0)
	if not getgenv then
		return
	end
	for L_181_forvar0, L_182_forvar1 in pairs(getgenv()) do
		if type(L_181_forvar0) == "string"
            and L_181_forvar0:sub(1, 3) == "_h_"
            and typeof(L_182_forvar1) == "Instance"
            and L_182_forvar1:IsA("ScreenGui")
        then
			L_180_arg0(L_181_forvar0, L_182_forvar1)
		end
	end
end

function L_21_.SetUIOpacity(L_183_arg0)
	L_38_ = L_183_arg0 / 10
	pcall(function()
		L_39_func(function(L_184_arg0, L_185_arg1)
			local L_186_ = L_185_arg1:FindFirstChild("Main")
			if L_186_ then
				L_186_.BackgroundTransparency = L_38_
			end
		end)
	end)
end

function L_21_.CleanupUI()
	pcall(function()
		L_39_func(function(L_187_arg0, L_188_arg1)
			pcall(function()
				L_188_arg1:Destroy()
			end)
			getgenv()[L_187_arg0] = nil
		end)
	end)
end

function L_21_.ReloadUI(L_189_arg0)
	L_21_.CleanupUI()
	task.wait(0.1)
	if L_189_arg0 and L_189_arg0.CreateLib then
		getgenv().Window =
            L_189_arg0.CreateLib(L_15_, "Midnight")
	end
	L_22_func("Reloaded", "Hub UI restarted.", 3)
end

local L_40_ = nil
local L_41_ = nil
local L_42_ = nil

local L_43_ = {
	"ALL"
}
local L_44_ = {}
local L_45_ = {
	"ALL"
}
local L_46_ = {
	ALL = "ALL"
}
local L_47_ = {}

local L_48_ = setmetatable({}, {
	__mode = "k"
})
local L_49_ = {}
local L_50_ = setmetatable({}, {
	__mode = "k"
})

local L_51_ = nil
local L_52_ = 0

local function L_53_func(L_190_arg0, L_191_arg1)
	local L_192_ = L_190_arg0
	for L_193_forvar0, L_194_forvar1 in ipairs(L_191_arg1) do
		if not L_192_ then
			return nil
		end
		L_192_ = L_192_:FindFirstChild(L_194_forvar1)
	end
	return L_192_
end

local function L_54_func(L_195_arg0)
	local L_196_ = {
		{
			"Signs",
			"Garden",
			"CorePart",
			"SurfaceGui",
			"Player",
			"TextLabel"
		},
		{
			"Signs",
			"Garden",
			"Core_Part",
			"SurfaceGui",
			"Player",
			"TextLabel"
		},
		{
			"Sign",
			"CorePart",
			"SurfaceGui",
			"Player",
			"TextLabel"
		},
		{
			"Sign",
			"Core_Part",
			"SurfaceGui",
			"Player",
			"TextLabel"
		},
	}
	for L_197_forvar0, L_198_forvar1 in ipairs(L_196_) do
		local L_199_ = L_53_func(L_195_arg0, L_198_forvar1)
		if L_199_ and L_199_:IsA("TextLabel") then
			return L_199_.Text
		end
	end
	return nil
end

local function L_55_func(L_200_arg0)
	if typeof(L_200_arg0) ~= "string" then
		return false
	end
	local L_201_ = L_200_arg0:lower()
	local L_202_ = L_12_.Name:lower()
	local L_203_ = L_12_.DisplayName and L_12_.DisplayName:lower()
	if L_201_:find(L_202_, 1, true) then
		return true
	end
	return L_203_ ~= nil and L_201_:find(L_203_, 1, true) ~= nil
end

local function L_56_func()
	local L_204_ = L_7_:FindFirstChild("Gardens")
	if not L_204_ then
		return nil
	end
	for L_206_forvar0, L_207_forvar1 in ipairs(L_204_:GetChildren()) do
		local L_208_ = L_207_forvar1:GetAttribute("UserId")
            or L_207_forvar1:GetAttribute("OwnerUserId")
            or L_207_forvar1:GetAttribute("OwnerId")
		if tonumber(L_208_) == L_12_.UserId
            or L_55_func(L_54_func(L_207_forvar1))
        then
			return L_207_forvar1
		end
	end
	local L_205_ = L_12_:GetAttribute("PlotId")
	if L_205_ then
		return L_204_:FindFirstChild("Plot" .. tostring(L_205_))
	end
	return nil
end

local function L_57_func(L_209_arg0, L_210_arg1)
	local L_211_ = tonumber(L_209_arg0.Order) or math.huge
	local L_212_ = tonumber(L_210_arg1.Order) or math.huge
	if L_211_ == L_212_ then
		return tostring(L_209_arg0.Name) < tostring(L_210_arg1.Name)
	end
	return L_211_ < L_212_
end

local function L_58_func()
	table.clear(L_43_)
	table.clear(L_44_)
	table.insert(L_43_, "ALL")
	if not L_41_ then
		return
	end
	local L_213_ = {}
	for L_214_forvar0, L_215_forvar1 in ipairs(L_41_) do
		if typeof(L_215_forvar1) == "table"
            and L_215_forvar1.SeedName
            and L_215_forvar1.RestockShop == true
        then
			L_44_[L_215_forvar1.SeedName] = tonumber(L_215_forvar1.PurchasePrice) or 0
			table.insert(L_213_, {
				Name = L_215_forvar1.SeedName,
				Order = L_215_forvar1.SeedShopDisplayOrder,
			})
		end
	end
	table.sort(L_213_, L_57_func)
	for L_216_forvar0, L_217_forvar1 in ipairs(L_213_) do
		table.insert(L_43_, L_217_forvar1.Name)
	end
end

local function L_59_func(L_218_arg0, L_219_arg1)
	local L_220_ = tonumber(L_218_arg0.Order) or math.huge
	local L_221_ = tonumber(L_219_arg1.Order) or math.huge
	if L_220_ == L_221_ then
		return tostring(L_218_arg0.Display) < tostring(L_219_arg1.Display)
	end
	return L_220_ < L_221_
end

local function L_60_func()
	table.clear(L_45_)
	table.clear(L_46_)
	table.clear(L_47_)
	table.insert(L_45_, "ALL")
	L_46_.ALL = "ALL"
	if not L_42_ then
		return
	end
	local L_222_ = {}
	for L_223_forvar0, L_224_forvar1 in pairs(L_42_) do
		if typeof(L_223_forvar0) == "string" and typeof(L_224_forvar1) == "table" then
			local L_225_ = typeof(L_224_forvar1.DisplayName) == "string" and L_224_forvar1.DisplayName or L_223_forvar0
			if typeof(L_224_forvar1.Rarity) == "string" and L_224_forvar1.Rarity ~= "" then
				L_225_ = L_225_ .. " (" .. L_224_forvar1.Rarity .. ")"
			end
			L_47_[L_223_forvar0] = L_224_forvar1
			table.insert(L_222_, {
				Name = L_223_forvar0,
				Display = L_225_,
				Order = L_224_forvar1.BasePrice,
			})
		end
	end
	table.sort(L_222_, L_59_func)
	for L_226_forvar0, L_227_forvar1 in ipairs(L_222_) do
		table.insert(L_45_, L_227_forvar1.Display)
		L_46_[L_227_forvar1.Display] = L_227_forvar1.Name
		L_46_[L_227_forvar1.Name] = L_227_forvar1.Name
	end
end

local L_61_ = {
	"Stock",
	"Amount",
	"Quantity",
	"CurrentStock",
	"Value",
	"Price",
}

local function L_62_func(L_228_arg0)
	if not L_228_arg0 then
		return nil
	end
	local L_229_, L_230_ = pcall(function()
		return L_228_arg0.Value
	end)
	if L_229_ then
		if typeof(L_230_) == "number" then
			return L_230_
		elseif typeof(L_230_) == "string" then
			local L_231_ = tonumber((L_230_:gsub(",", "")))
			if L_231_ then
				return L_231_
			end
		end
	end
	for L_232_forvar0, L_233_forvar1 in ipairs(L_61_) do
		local L_234_ = L_228_arg0:GetAttribute(L_233_forvar1)
		if typeof(L_234_) == "number" then
			return L_234_
		elseif typeof(L_234_) == "string" then
			local L_236_ = tonumber((L_234_:gsub(",", "")))
			if L_236_ then
				return L_236_
			end
		end
		local L_235_ = L_228_arg0:FindFirstChild(L_233_forvar1)
		if L_235_ then
			local L_237_ = L_62_func(L_235_)
			if L_237_ ~= nil then
				return L_237_
			end
		end
	end
	return nil
end

local function L_63_func()
	local L_238_ = L_12_:FindFirstChild("leaderstats")
	local L_239_ = L_238_ and L_238_:FindFirstChild("Sheckles")
        or L_12_:FindFirstChild("Sheckles")
	local L_240_ = L_62_func(L_239_)
	if L_240_ == nil then
		return nil
	end
	if L_51_ ~= nil and L_51_ ~= L_240_ then
		L_52_ = 0
	end
	L_51_ = L_240_
	return math.max(L_240_ - L_52_, 0)
end

local function L_64_func(L_241_arg0)
	return L_44_[L_241_arg0] or 0
end

local function L_65_func(L_242_arg0, L_243_arg1)
	local L_244_ = L_62_func(L_242_arg0)
	if L_244_ and L_244_ > 0 then
		return L_244_
	end
	if L_242_arg0 then
		local L_246_ = L_242_arg0:GetAttribute("Price")
		if typeof(L_246_) == "number" then
			return L_246_
		end
	end
	local L_245_ = L_47_[L_243_arg1]
	return L_245_ and tonumber(L_245_.BasePrice) or 0
end

local function L_66_func(L_247_arg0)
	return typeof(L_247_arg0) == "Instance" and L_48_ or L_49_
end

local function L_67_func(L_248_arg0)
	local L_249_ = L_66_func(L_248_arg0)
	return (L_249_[L_248_arg0] or 0) <= os.clock()
end

local function L_68_func(L_250_arg0, L_251_arg1)
	local L_252_ = L_66_func(L_250_arg0)
	L_252_[L_250_arg0] = os.clock() + (L_251_arg1 or 4)
end

local function L_69_func(L_253_arg0)
	L_253_arg0 = tonumber(L_253_arg0) or 0
	if L_253_arg0 <= 0 then
		return true
	end
	local L_254_ = L_63_func()
	return L_254_ ~= nil and L_253_arg0 <= L_254_
end

local function L_70_func(L_255_arg0)
	L_255_arg0 = tonumber(L_255_arg0) or 0
	if L_255_arg0 > 0 then
		L_52_ = L_52_ + L_255_arg0
	end
end

local function L_71_func(L_256_arg0, L_257_arg1)
	local L_258_ = L_9_:FindFirstChild("StockValues")
	local L_259_ = L_258_ and L_258_:FindFirstChild(L_256_arg0)
	local L_260_ = L_259_ and L_259_:FindFirstChild("Items")
	local L_261_ = L_260_ and L_260_:FindFirstChild(L_257_arg1)
	return L_62_func(L_261_) or 0
end

local function L_72_func(L_262_arg0)
	if not L_262_arg0 or not L_40_ then
		return false
	end
	L_40_.SeedShop.PurchaseSeed:Fire(L_262_arg0)
	return true
end

local function L_73_func(L_263_arg0)
	if not L_263_arg0 or not L_40_ then
		return false
	end
	local L_264_ = false
	local L_265_ = L_64_func(L_263_arg0)
	local L_266_ = "Seed:" .. L_263_arg0
	if not L_67_func(L_266_) then
		return false
	end
	local L_267_ = L_71_func("SeedShop", L_263_arg0)
	local L_268_ = 0
	while L_18_.AutoBuySeeds and L_267_ > 0 and L_268_ < 25 do
		if not L_69_func(L_265_) then
			L_68_func(L_266_, 4)
			return L_264_
		end
		L_72_func(L_263_arg0)
		L_70_func(L_265_)
		L_264_ = true
		L_268_ = L_268_ + 1
		L_267_ = L_267_ - 1
		if L_268_ % 8 == 0 then
			task.wait()
		end
	end
	return L_264_
end

local function L_74_func(L_269_arg0)
	local L_270_ = L_269_arg0 and L_269_arg0.Parent
	while L_270_ do
		if L_270_:IsA("BasePart") then
			return L_270_
		end
		L_270_ = L_270_.Parent
	end
	return nil
end

local function L_75_func(L_271_arg0)
	local L_272_ = L_271_arg0 and L_271_arg0.Parent
	if L_272_ then
		local L_274_ = L_272_:FindFirstAncestorWhichIsA("Model")
		if L_274_ and L_274_:GetAttribute("PlantId") then
			return L_274_
		end
	end
	local L_273_ = L_271_arg0
	for L_275_forvar0 = 1, 8 do
		if not L_273_ then
			break
		end
		if L_273_:GetAttribute("PlantId") then
			return L_273_
		end
		L_273_ = L_273_.Parent
	end
	return nil
end

local function L_76_func()
	local L_276_ = L_56_func()
	if not L_276_ then
		return nil
	end
	return L_276_:FindFirstChild("Plants")
        or L_276_:FindFirstChild("Plants_Physical", true)
end

local function L_77_func(L_277_arg0)
	local L_278_ = false
	pcall(function()
		L_278_ = L_11_:HasTag(L_277_arg0, "HarvestPrompt")
	end)
	return L_278_
        or L_277_arg0.Name == "HarvestPrompt"
        or L_277_arg0.ActionText == "Harvest"
end

local function L_78_func()
	local L_279_ = L_76_func()
	local L_280_ = {}
	local L_281_ = os.clock()
	if not L_279_ then
		return L_280_
	end
	for L_283_forvar0, L_284_forvar1 in ipairs(L_279_:GetDescendants()) do
		if L_284_forvar1:IsA("ProximityPrompt")
            and L_284_forvar1:IsDescendantOf(L_7_)
            and L_77_func(L_284_forvar1)
            and L_284_forvar1.Enabled
            and not L_284_forvar1:GetAttribute("Collected")
            and ((L_50_[L_284_forvar1] or 0) <= L_281_)
        then
			table.insert(L_280_, L_284_forvar1)
		end
	end
	local L_282_ = L_24_func()
	if L_282_ then
		table.sort(L_280_, function(L_285_arg0, L_286_arg1)
			local L_287_ = L_74_func(L_285_arg0)
			local L_288_ = L_74_func(L_286_arg1)
			local L_289_ = L_287_ and (L_287_.Position - L_282_.Position).Magnitude or math.huge
			local L_290_ = L_288_ and (L_288_.Position - L_282_.Position).Magnitude or math.huge
			return L_289_ < L_290_
		end)
	end
	return L_280_
end

local function L_79_func(L_291_arg0)
	if not L_291_arg0
        or not L_291_arg0:IsA("ProximityPrompt")
        or not L_291_arg0:IsDescendantOf(L_7_)
        or not L_40_
        or L_291_arg0:GetAttribute("Collected")
    then
		return false
	end
	local L_292_ = L_75_func(L_291_arg0)
	local L_293_ = L_292_ and L_292_:GetAttribute("PlantId")
	if not L_293_ then
		return false
	end
	local L_294_ = L_292_:GetAttribute("FruitId") or ""
	L_40_.Garden.CollectFruit:Fire(tostring(L_293_), tostring(L_294_))
	L_50_[L_291_arg0] = os.clock() + 0.35
	return true
end

local function L_80_func()
	local L_295_ = L_7_:FindFirstChild("Map")
	return L_295_ and L_295_:FindFirstChild("WildPetRef")
end

local function L_81_func(L_296_arg0)
	local L_297_ = L_46_[L_296_arg0] or L_296_arg0
	local L_298_ = L_80_func()
	local L_299_ = {}
	if not L_298_ then
		return L_299_
	end
	for L_300_forvar0, L_301_forvar1 in ipairs(L_298_:GetChildren()) do
		if L_301_forvar1:IsA("BasePart") and L_301_forvar1:IsDescendantOf(L_7_) then
			local L_302_ = tostring(L_301_forvar1:GetAttribute("PetName") or "")
			local L_303_ = tonumber(L_301_forvar1:GetAttribute("OwnerUserId"))
			local L_304_ = tostring(L_301_forvar1:GetAttribute("State") or ""):lower()
			local L_305_ = L_303_ == nil or L_303_ ~= L_12_.UserId
			local L_306_ = L_305_
                and not L_304_:find("owned", 1, true)
                and not L_304_:find("despawn", 1, true)
			if L_306_
                and L_302_ ~= ""
                and L_67_func(L_301_forvar1)
                and (not L_297_ or L_297_ == "ALL" or L_302_ == L_297_)
            then
				local L_307_ = L_65_func(L_301_forvar1, L_302_)
				if L_69_func(L_307_) then
					table.insert(L_299_, L_301_forvar1)
				else
					L_68_func(L_301_forvar1, 4)
				end
			end
		end
	end
	table.sort(L_299_, function(L_308_arg0, L_309_arg1)
		local L_310_ = tostring(L_308_arg0:GetAttribute("PetName") or "")
		local L_311_ = tostring(L_309_arg1:GetAttribute("PetName") or "")
		local L_312_ = L_65_func(L_308_arg0, L_310_)
		local L_313_ = L_65_func(L_309_arg1, L_311_)
		if L_312_ == L_313_ then
			return L_310_ < L_311_
		end
		return L_312_ < L_313_
	end)
	return L_299_
end

local function L_82_func(L_314_arg0)
	local L_315_ = L_24_func()
	if not L_315_ or not L_314_arg0 then
		return false
	end
	local L_316_ = L_314_arg0.Position + Vector3.new(0, 3, 0)
	local L_317_ = (L_315_.Position - L_316_).Magnitude
	if L_317_ < 8 then
		return true
	end
	local L_318_ = L_25_func()
	local L_319_ = tonumber(L_318_ and L_318_.WalkSpeed)
        or tonumber(L_18_.PetTweenSpeed)
        or 16
	local L_320_ = math.clamp(L_317_ / math.max(L_319_, 1), 0.15, 12)
	local L_321_ = L_10_:Create(
        L_315_,
        TweenInfo.new(L_320_, Enum.EasingStyle.Linear, Enum.EasingDirection.Out),
        {
		CFrame = CFrame.new(L_316_, L_316_ + L_315_.CFrame.LookVector)
	}
    )
	L_321_:Play()
	local L_322_ = false
	local L_323_ = L_321_.Completed:Connect(function()
		L_322_ = true
	end)
	while L_18_.AutoBuyPets and not L_322_ do
		task.wait()
	end
	L_323_:Disconnect()
	if not L_18_.AutoBuyPets and not L_322_ then
		L_321_:Cancel()
		return false
	end
	return true
end

local function L_83_func()
	local L_324_ = {}
	for L_325_forvar0, L_326_forvar1 in ipairs(L_43_) do
		if L_326_forvar1 ~= "ALL" then
			table.insert(L_324_, L_326_forvar1)
		end
	end
	table.sort(L_324_, function(L_327_arg0, L_328_arg1)
		local L_329_ = L_64_func(L_327_arg0)
		local L_330_ = L_64_func(L_328_arg1)
		if L_329_ == L_330_ then
			return tostring(L_327_arg0) < tostring(L_328_arg1)
		end
		return L_329_ < L_330_
	end)
	return L_324_
end

local function L_84_func(L_331_arg0)
	if not L_331_arg0 or not L_40_ then
		return false
	end
	local L_332_ = tostring(L_331_arg0:GetAttribute("PetName") or "")
	local L_333_ = L_65_func(L_331_arg0, L_332_)
	if not L_69_func(L_333_) then
		L_68_func(L_331_arg0, 4)
		return false
	end
	if not L_82_func(L_331_arg0) then
		return false
	end
	if not L_69_func(L_333_) then
		L_68_func(L_331_arg0, 4)
		return false
	end
	L_40_.Pets.WildPetTame:Fire(L_331_arg0)
	L_70_func(L_333_)
	L_68_func(L_331_arg0, 1)
	return true
end

local function L_85_func(L_334_arg0)
	if L_18_.PetBuyingInProgress then
		return false
	end
	local L_335_ = L_81_func(L_334_arg0)
	local L_336_ = L_335_[1]
	if not L_336_ then
		return false
	end
	L_18_.PetBuyingInProgress = true
	local L_337_, L_338_ = pcall(L_84_func, L_336_)
	L_18_.PetBuyingInProgress = false
	return L_337_ and L_338_ or false
end

local function L_86_func()
	while L_18_.AutoBuySeeds do
		if L_18_.SelectedSeed == "ALL" then
			for L_339_forvar0, L_340_forvar1 in ipairs(L_83_func()) do
				if not L_18_.AutoBuySeeds then
					break
				end
				L_73_func(L_340_forvar1)
			end
		else
			L_73_func(L_18_.SelectedSeed)
		end
		task.wait(L_18_.SeedDelay)
	end
end

local function L_87_func()
	while L_18_.AutoBuyPets do
		L_85_func(L_18_.SelectedPet)
		task.wait(L_18_.PetDelay)
	end
end

local function L_88_func()
	while L_18_.AutoHarvest do
		for L_341_forvar0, L_342_forvar1 in ipairs(L_78_func()) do
			if not L_18_.AutoHarvest then
				break
			end
			L_79_func(L_342_forvar1)
			task.wait(L_18_.HarvestDelay)
		end
		task.wait()
	end
end

local function L_89_func()
	if not L_40_ then
		return false
	end
	for L_343_forvar0, L_344_forvar1 in pairs(L_40_) do
		if typeof(L_344_forvar1) == "table" then
			for L_345_forvar0, L_346_forvar1 in ipairs({
				"SellInventory",
				"Sell",
				"SellAll"
			}) do
				local L_347_ = L_344_forvar1[L_346_forvar1]
				if L_347_ then
					if type(L_347_.Fire) == "function" then
						L_347_:Fire()
						return true
					elseif type(L_347_.InvokeServer) == "function" then
						L_347_:InvokeServer()
						return true
					end
				end
			end
		end
	end
	return false
end

local function L_90_func()
	local L_348_ = nil
	local L_349_ = L_9_:FindFirstChild("common")
	if L_349_ and L_349_:FindFirstChild("packages") and L_349_.packages:FindFirstChild("Knit") then
		L_348_ = require(L_349_.packages.Knit)
	elseif L_9_:FindFirstChild("Packages") and L_9_.Packages:FindFirstChild("Knit") then
		L_348_ = require(L_9_.Packages.Knit)
	elseif L_9_:FindFirstChild("Knit") then
		L_348_ = require(L_9_.Knit)
	end
	if not L_348_ or type(L_348_.GetService) ~= "function" then
		return false
	end
	local L_350_ = L_348_.GetService("SellService")
        or L_348_.GetService("MarketService")
        or L_348_.GetService("ShopService")
	if not L_350_ then
		return false
	end
	local L_351_ = L_350_:FindFirstChild("RF")
	if L_351_ then
		local L_352_ = L_351_:FindFirstChild("SellInventory") or L_351_:FindFirstChild("Sell")
		if L_352_ then
			L_352_:InvokeServer()
			return true
		end
	end
	if type(L_350_.SellInventory) == "function" then
		L_350_:SellInventory()
		return true
	elseif type(L_350_.Sell) == "function" then
		L_350_:Sell()
		return true
	end
	return false
end

local function L_91_func()
	for L_353_forvar0, L_354_forvar1 in ipairs(L_9_:GetDescendants()) do
		if L_354_forvar1:IsA("RemoteEvent") or L_354_forvar1:IsA("RemoteFunction") then
			local L_355_ = L_354_forvar1.Name:lower()
			if L_355_:find("sell", 1, true) or L_355_:find("sheckle", 1, true) then
				pcall(function()
					if L_354_forvar1:IsA("RemoteEvent") then
						L_354_forvar1:FireServer()
					else
						L_354_forvar1:InvokeServer()
					end
				end)
			end
		end
	end
end

local function L_92_func()
	local L_356_ = false
	if L_40_ then
		pcall(function()
			L_356_ = L_89_func()
		end)
	end
	if not L_356_ then
		pcall(function()
			L_356_ = L_90_func()
		end)
	end
	if not L_356_ then
		pcall(L_91_func)
	end
	return L_356_
end

local function L_93_func()
	while L_18_.AutoSell do
		pcall(L_92_func)
		task.wait(1.5)
	end
end

function L_21_.SetAutoHarvest(L_357_arg0)
	if L_18_.AutoHarvest == L_357_arg0 then
		return
	end
	L_18_.AutoHarvest = L_357_arg0
	if L_357_arg0 then
		task.spawn(L_88_func)
	end
	L_22_func("Auto Farm", L_357_arg0 and "Auto Harvest Enabled" or "Auto Harvest Disabled")
end

function L_21_.SetHarvestDelayMs(L_358_arg0)
	L_18_.HarvestDelay = L_358_arg0 / 1000
end

function L_21_.SetAutoSell(L_359_arg0)
	if L_18_.AutoSell == L_359_arg0 then
		return
	end
	L_18_.AutoSell = L_359_arg0
	if L_359_arg0 then
		task.spawn(L_93_func)
	end
	L_22_func("Auto Farm", L_359_arg0 and "Auto Sell Enabled" or "Auto Sell Disabled")
end

function L_21_.SetAutoBuySeeds(L_360_arg0)
	if L_18_.AutoBuySeeds == L_360_arg0 then
		return
	end
	L_18_.AutoBuySeeds = L_360_arg0
	if L_360_arg0 then
		task.spawn(L_86_func)
	end
	L_22_func("Seeds", L_360_arg0 and "Auto Buy Seeds Enabled" or "Auto Buy Seeds Disabled")
end

function L_21_.SetSelectedSeed(L_361_arg0)
	L_18_.SelectedSeed = L_361_arg0 or "ALL"
end

function L_21_.SetSeedDelayMs(L_362_arg0)
	L_18_.SeedDelay = L_362_arg0 / 1000
end

function L_21_.SetAutoBuyPets(L_363_arg0)
	if L_18_.AutoBuyPets == L_363_arg0 then
		return
	end
	L_18_.AutoBuyPets = L_363_arg0
	if L_363_arg0 then
		task.spawn(L_87_func)
	end
	L_22_func("Pets", L_363_arg0 and "Auto Buy Pets Enabled" or "Auto Buy Pets Disabled")
end

function L_21_.SetSelectedPet(L_364_arg0)
	L_18_.SelectedPet = L_364_arg0 or "ALL"
end

function L_21_.SetPetDelayMs(L_365_arg0)
	L_18_.PetDelay = L_365_arg0 / 1000
end

function L_21_.SetPetTweenSpeed(L_366_arg0)
	L_18_.PetTweenSpeed = L_366_arg0
end

function L_21_.SetGrowGardenWalkSpeed(L_367_arg0)
	L_18_.WalkSpeed = L_367_arg0
end

function L_21_.SetGrowGardenWalkSpeedLock(L_368_arg0)
	L_18_.WSLock = L_368_arg0
end

function L_21_.SetGrowGardenJumpPower(L_369_arg0)
	L_18_.JumpPower = L_369_arg0
end

function L_21_.SetGrowGardenJumpPowerLock(L_370_arg0)
	L_18_.JPLock = L_370_arg0
end

function L_21_.TeleportToShop()
	for L_371_forvar0, L_372_forvar1 in ipairs(L_7_:GetDescendants()) do
		if L_372_forvar1:IsA("BasePart") then
			local L_373_ = L_372_forvar1.Name:lower()
			if L_373_:find("shop", 1, true)
                or L_373_:find("store", 1, true)
                or L_373_:find("market", 1, true)
            then
				local L_374_ = L_24_func()
				if L_374_ then
					L_374_.CFrame = L_372_forvar1.CFrame * CFrame.new(0, 3, 0)
					pcall(L_22_func, "Teleport", "Teleported to Shop!")
				end
				return
			end
		end
	end
	pcall(L_22_func, "Teleport", "Shop location not found!", 3)
end

function L_21_.TeleportToMyGarden()
	local L_375_ = L_56_func()
	local L_376_ = L_24_func()
	if L_375_ and L_376_ then
		local L_377_ = L_375_:FindFirstChildWhichIsA("BasePart", true) or L_375_.PrimaryPart
		if L_377_ then
			L_376_.CFrame = L_377_.CFrame * CFrame.new(0, 5, 0)
			pcall(L_22_func, "Teleport", "Teleported to Plot!")
			return
		end
	end
	pcall(L_22_func, "Teleport", "Plot location not found!", 3)
end

local function L_94_func()
	if L_21_.CurrentGame and L_21_.CurrentGame.name ~= "Grow a Garden 2" then
		return
	end
	local L_378_ = L_25_func()
	if not L_378_ then
		return
	end
	if L_18_.WSLock then
		L_378_.WalkSpeed = L_18_.WalkSpeed
	end
	if L_18_.JPLock then
		L_378_.JumpPower = L_18_.JumpPower
		L_378_.UseJumpPower = true
	end
end

L_2_.RenderStepped:Connect(L_94_func)

local function L_95_func()
	local L_379_ = L_9_:WaitForChild("SharedModules", 30)
	local L_380_ = L_9_:WaitForChild("SharedData", 30)
	if L_379_ then
		pcall(function()
			L_40_ = require(L_379_:WaitForChild("Networking", 15))
			L_41_ = require(L_379_:WaitForChild("SeedData", 15))
		end)
	end
	if L_380_ then
		pcall(function()
			L_42_ = require(L_380_:WaitForChild("PetData", 15))
		end)
	end
	L_58_func()
	L_60_func()
end

task.spawn(L_95_func)

L_21_.GrowGarden = {
	ReadNumberValue = L_62_func,
	GetShecklesValue = L_63_func,
	GetSeedPrice = L_64_func,
	GetWildPetPrice = L_65_func,
	CanAttempt = L_67_func,
	CooldownItem = L_68_func,
	CanAfford = L_69_func,
	MarkSpent = L_70_func,
	GetStock = L_71_func,
	BuySeed = L_72_func,
	BuySeedBurst = L_73_func,
	GetPromptPart = L_74_func,
	FindHarvestPayloadHolder = L_75_func,
	GetHarvestPlantsFolder = L_76_func,
	GetHarvestPrompts = L_78_func,
	HarvestPrompt = L_79_func,
	GetWildPetFolder = L_80_func,
	GetWildPetRefs = L_81_func,
	TweenToPet = L_82_func,
	GetSeedBuyList = L_83_func,
	BuyPet = L_84_func,
	BuyAvailablePet = L_85_func,
	FindLocalGardenPlot = L_56_func,
	RefreshSeedCatalog = L_58_func,
	RefreshPetCatalog = L_60_func,
	SeedOptions = L_43_,
	PetOptions = L_45_,
}

L_21_.PetFinderConfig = {
	Title = "❄️ Snowy Hub | Pet Finder",
	Edition = "❄️ Snowy Hub Edition",
	PopupTitle = "SNOWY PET FINDER",
	PopupText = "Search for pets across multiple servers!\nFind the rarest pets instantly.",
	Species = {
		"Unicorn",
		"Unicorn 👑",
		"Raccoon 👑",
		"Golden Dragonfly",
		"Bear",
	},
	Rarities = {
		"Mythic",
		"Mythic [Premium]",
		"Super [Premium]",
	},
	Mutations = {
		"🌈 Rainbow",
		"⬆ Big",
		"⬆⬆ Mega",
	},
	Controls = {
		"🔍 Search Now",
		"🛒 Auto-Buy",
		"▶ Auto-Join",
		"JOIN →",
	},
}

function L_21_.OpenPetFinderPopup()

	local L_381_ = (gethui and gethui()) or game:GetService("CoreGui")
	local L_382_ = Instance.new("ScreenGui")
	L_382_.Name = "SnowyPetFinderPopup"
	L_382_.ResetOnSpawn = false
	L_382_.Parent = L_381_
	local L_383_ = Instance.new("Frame")
	L_383_.Name = "Main"
	L_383_.Size = UDim2.fromOffset(440, 230)
	L_383_.Position = UDim2.new(0.5, -220, 0.5, -115)
	L_383_.BackgroundColor3 = Color3.fromRGB(20, 22, 28)
	L_383_.Parent = L_382_
	local L_384_ = Instance.new("UICorner")
	L_384_.CornerRadius = UDim.new(0, 12)
	L_384_.Parent = L_383_
	local L_385_ = Instance.new("TextLabel")
	L_385_.BackgroundTransparency = 1
	L_385_.Size = UDim2.new(1, -30, 0, 42)
	L_385_.Position = UDim2.fromOffset(15, 16)
	L_385_.Text = L_21_.PetFinderConfig.PopupTitle
	L_385_.TextColor3 = Color3.new(1, 1, 1)
	L_385_.TextScaled = true
	L_385_.Parent = L_383_
	local L_386_ = Instance.new("TextLabel")
	L_386_.BackgroundTransparency = 1
	L_386_.Size = UDim2.new(1, -40, 0, 70)
	L_386_.Position = UDim2.fromOffset(20, 72)
	L_386_.Text = L_21_.PetFinderConfig.PopupText
	L_386_.TextColor3 = Color3.fromRGB(205, 210, 220)
	L_386_.TextWrapped = true
	L_386_.TextScaled = true
	L_386_.Parent = L_383_
	local L_387_ = Instance.new("TextButton")
	L_387_.Size = UDim2.fromOffset(180, 42)
	L_387_.Position = UDim2.new(0.5, -190, 1, -62)
	L_387_.Text = "Load Pet Finder"
	L_387_.Parent = L_383_
	local L_388_ = Instance.new("TextButton")
	L_388_.Size = UDim2.fromOffset(180, 42)
	L_388_.Position = UDim2.new(0.5, 10, 1, -62)
	L_388_.Text = "Maybe Later"
	L_388_.Parent = L_383_
	L_388_.MouseButton1Click:Connect(function()
		L_382_:Destroy()
	end)
	L_387_.MouseButton1Click:Connect(function()
		L_22_func("Pet Finder", "Advanced Pet Finder Loaded!")
		L_382_:Destroy()

	end)
	L_22_func("Pet Finder", "Pet Finder GUI opened!")
	return L_382_
end

L_21_.UIBindings = {
	Player = {
		{
			"Walk Speed Value",
			L_21_.SetWalkSpeed
		},
		{
			"Jump Power Value",
			L_21_.SetJumpPower
		},
		{
			"Gravity",
			L_21_.SetGravity
		},
		{
			"God Mode",
			L_21_.SetGodMode
		},
		{
			"Noclip",
			L_21_.SetNoclip
		},
		{
			"Infinite Jump",
			L_21_.SetInfiniteJump
		},
	},
	Visuals = {
		{
			"Field of View",
			L_21_.SetCameraFOV
		},
		{
			"Fullbright",
			L_21_.SetFullbright
		},
		{
			"Player ESP",
			L_21_.SetPlayerESP
		},
		{
			"Hitbox Expander",
			L_21_.SetHitboxSize
		},
	},
	Aimbot = {
		{
			"Enable Aimbot (Right Click)",
			L_21_.SetAimbotEnabled
		},
		{
			"Show FOV Circle",
			L_21_.SetShowFOV
		},
		{
			"FOV Size",
			L_21_.SetFOVRadius
		},
		{
			"Aimbot Smoothness",
			L_21_.SetAimbotSmoothness
		},
		{
			"Team Check",
			L_21_.SetTeamCheck
		},
	},
	Utility = {
		{
			"Give Btools",
			L_21_.GiveBtools
		},
		{
			"Teleport to Random Player",
			L_21_.TeleportToRandomPlayer
		},
		{
			"Rejoin Server",
			L_21_.RejoinServer
		},
		{
			"Server Hop",
			L_21_.ServerHop
		},
		{
			"Anti-Kick (Anti-AFK)",
			L_21_.SetAntiKick
		},
		{
			"Disable 3D Rendering",
			L_21_.SetDisable3D
		},
		{
			"FPS Booster",
			L_21_.SetFPSBooster
		},
		{
			"Copy Discord Link",
			L_21_.CopyDiscord
		},
		{
			"Pet Finder",
			L_21_.OpenPetFinderPopup
		},
	},
	GrowGarden = {
		{
			"Auto Harvest Crops",
			L_21_.SetAutoHarvest
		},
		{
			"Harvest Delay (ms)",
			L_21_.SetHarvestDelayMs
		},
		{
			"Auto Sell Crops",
			L_21_.SetAutoSell
		},
		{
			"Auto Buy Seeds",
			L_21_.SetAutoBuySeeds
		},
		{
			"Select Seed",
			L_21_.SetSelectedSeed
		},
		{
			"Seed Delay (ms)",
			L_21_.SetSeedDelayMs
		},
		{
			"Auto Buy Pets",
			L_21_.SetAutoBuyPets
		},
		{
			"Select Pet",
			L_21_.SetSelectedPet
		},
		{
			"Pet Delay (ms)",
			L_21_.SetPetDelayMs
		},
		{
			"Pet Tween Speed",
			L_21_.SetPetTweenSpeed
		},
		{
			"Walk Speed Value",
			L_21_.SetGrowGardenWalkSpeed
		},
		{
			"Lock Walk Speed",
			L_21_.SetGrowGardenWalkSpeedLock
		},
		{
			"Jump Power Value",
			L_21_.SetGrowGardenJumpPower
		},
		{
			"Lock Jump Power",
			L_21_.SetGrowGardenJumpPowerLock
		},
		{
			"Teleport to Shop",
			L_21_.TeleportToShop
		},
		{
			"Teleport to My Garden",
			L_21_.TeleportToMyGarden
		},
	},
}

L_21_.Recovery = {
	ConstantSeed = 4142844079,
	InstructionKey = 3490071335,
	Constants = 6873,
	Prototypes = 396,
	Instructions = 19499,
	Opcodes = 58,
}

print("[SnowyHub] Payload reconstructed: " .. L_15_)
return L_21_
