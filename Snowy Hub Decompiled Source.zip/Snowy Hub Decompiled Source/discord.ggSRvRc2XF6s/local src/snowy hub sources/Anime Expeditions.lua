local L_1_ = {}

local L_2_ = game:GetService("Players")
local L_3_ = game:GetService("ReplicatedStorage")
local L_4_ = game:GetService("HttpService")
local L_5_ = game:GetService("VirtualInputManager")

local L_6_ = L_2_.LocalPlayer

local L_7_ = {
	Folder = "AeMacro",
	MacroFolder = "AeMacro/Macros",
	SettingsFile = "AeMacro/settings.json",
}

local L_8_ = {
	Recording = false,
	Replaying = false,
	RecordStart = 0,
	ReplayStart = 0,
	Current = nil,
	RecPlacementSeq = 0,
	LiveIdToIndex = {},
	NewUnitQueue = {},
	PendingPlace = nil,
	Status = "Idle",
	StepText = "",
	NextText = "",
	Mode = "Yen",
	MacroName = "MyMacro",
	SelectedMacro = nil,
	PlayMacro = false,
	AutoRetry = false,
	AutoStart = true,
	AutoJoin = true,
	ReplayedThisMatch = false,
	LastSavedMacro = nil,
	ResultSent = false,
	MatchActive = false,
	RoundStarted = false,
	StageCounts = {},
	Snapshot = nil,
	UnitDamage = {},
	Joiner = {
		Gamemode = "Story",
		Map = "SchoolGrounds",
		Act = "Act 1",
		Difficulty = "Normal",
	},
	WebhookUrl = "",
	WebhookEnabled = false,
	WebhookItems = {
		"Gem",
		"Gold",
		"TraitReroll",
	},
	AutoClaimQuests = false,
	AutoClaimEvents = false,
	AutoClaimIndex = false,
	AutoClaimMilestones = false,
	AutoClaimGroup = false,
	AutoClaimCodes = false,
	AutoClaimBattlepass = false,
	AutoSellEnabled = false,
	AutoSellRarities = {},
	AutoSummon = false,
	SummonBanner = "Standard",
	SummonAmount = 1,
	SummonTargets = {},
	SummonUntilUnit = false,
	DiscordId = "",
	SummonPing = false,
	GameDropPing = false,
	AutoBuyMerchant = false,
	MerchantItems = {},
}

L_1_.State = L_8_
L_1_.Paths = L_7_

local L_9_ = nil
local L_10_ = nil
local L_11_
local L_12_
local L_13_

local function L_14_func()
	local L_158_ = L_3_:FindFirstChild("Shared")
	return L_158_ and L_158_:FindFirstChild("Information") or nil
end

local L_15_ = nil
local L_16_ = nil

local function L_17_func()
	if type(L_15_) == "table" then
		return L_15_
	end
	local L_159_ = L_3_:FindFirstChild("Shared")
	local L_160_ = L_159_ and L_159_:FindFirstChild("ReplicaClient")
	if not L_160_ then
		return nil
	end
	local L_161_, L_162_ = pcall(require, L_160_)
	if L_161_ and type(L_162_) == "table" then
		L_15_ = L_162_
	end
	return L_15_
end

local function L_18_func()
	local L_163_ = L_17_func()
	if not L_163_ or type(L_163_.FromId) ~= "function" then
		return L_16_
	end
	if not debug or type(debug.getupvalue) ~= "function" then
		return L_16_
	end
	local L_164_, L_165_, L_166_ = pcall(debug.getupvalue, L_163_.FromId, 1)
	if L_164_ then

		if type(L_166_) == "table" then
			L_16_ = L_166_
		elseif type(L_165_) == "table" then
			L_16_ = L_165_
		end
	end
	return L_16_
end

local function L_19_func(L_167_arg0)
	return tostring(L_167_arg0.Token or L_167_arg0.Class)
end

local function L_20_func(L_168_arg0)
	local L_169_ = L_16_ or L_18_func()
	if type(L_169_) ~= "table" then
		return nil
	end
	local L_170_ = tostring(L_168_arg0)
	for L_171_forvar0, L_172_forvar1 in pairs(L_169_) do
		local L_173_, L_174_ = pcall(L_19_func, L_172_forvar1)
		if L_173_ and L_174_ == L_170_ then
			return L_172_forvar1
		end
	end
	return nil
end

local L_21_ = nil
local L_22_ = nil

local function L_23_func()
	local L_175_ = L_6_:FindFirstChild("PlayerScripts")
	L_21_ = L_175_ and L_175_:FindFirstChild("FireRelay") or nil
	local L_176_ = L_3_:FindFirstChild("Nodes")
	local L_177_ = L_176_ and L_176_:FindFirstChild("Network") or nil
	local L_178_ = L_177_ and L_177_:FindFirstChild("NetworkEvents") or nil
	L_22_ = L_178_ and L_178_:FindFirstChild("_updateNode") or nil
end

local function L_24_func()
	if L_21_ and L_21_.Parent
        and L_22_ and L_22_.Parent then
		return true
	end
	pcall(L_23_func)
	return L_21_ ~= nil and L_22_ ~= nil
end

local function L_25_func(L_179_arg0, ...)
	if not L_24_func() then
		return false
	end
	local L_180_ = table.pack(...)
	return pcall(function()
		L_21_:SendMessage(
            "Fire",
            L_22_,
            {
			Type = "Post"
		},
            L_179_arg0,
            table.unpack(L_180_, 1, L_180_.n)
        )
	end)
end

local function L_26_func()
	local L_181_ = L_6_.Character
	if L_181_ and L_181_:GetAttribute("InMap") == true then
		return true
	end
	return workspace:FindFirstChild("Map") ~= nil
end

L_1_.getInformationRoot = L_14_func
L_1_.resolveReplicaClient = L_17_func
L_1_.captureReplicaStorage = L_18_func
L_1_.findReplica = L_20_func
L_1_.installNetworkHooks = L_24_func
L_1_.fireRelay = L_25_func
L_1_.isInMap = L_26_func

local L_27_ = typeof(writefile) == "function"

local function L_28_func()
	if not L_27_ then
		return
	end
	pcall(function()
		if not isfolder(L_7_.Folder) then
			makefolder(L_7_.Folder)
		end
		if not isfolder(L_7_.MacroFolder) then
			makefolder(L_7_.MacroFolder)
		end
	end)
end

local function L_29_func(L_182_arg0, L_183_arg1)
	if not L_27_ then
		return false
	end
	local L_184_, L_185_ = pcall(L_4_.JSONEncode, L_4_, L_183_arg1)
	if not L_184_ then
		return false
	end
	return pcall(writefile, L_182_arg0, L_185_)
end

local function L_30_func(L_186_arg0)
	if not L_27_ or not isfile(L_186_arg0) then
		return nil
	end
	local L_187_, L_188_ = pcall(function()
		return L_4_:JSONDecode(readfile(L_186_arg0))
	end)
	if L_187_ and type(L_188_) == "table" then
		return L_188_
	end
	return nil
end

L_1_.ensureDataFolders = L_28_func
L_1_.writeJson = L_29_func
L_1_.readJson = L_30_func

local function L_31_func(L_189_arg0)
	if type(L_189_arg0) ~= "table" or #L_189_arg0 < 12 then
		return nil
	end
	return CFrame.new(table.unpack(L_189_arg0))
end

local function L_32_func(L_190_arg0)
	if typeof(L_190_arg0) ~= "CFrame" then
		return nil
	end
	return {
		L_190_arg0:GetComponents()
	}
end

local function L_33_func(L_191_arg0)
	local L_192_ = math.floor(tonumber(L_191_arg0) or 0)
	local L_193_ = math.floor(L_192_ / 3600)
	local L_194_ = math.floor(L_192_ / 60) % 60
	local L_195_ = L_192_ % 60
	return string.format("%02d:%02d:%02d", L_193_, L_194_, L_195_)
end

local function L_34_func(L_196_arg0)
	local L_197_ = tostring(math.floor(tonumber(L_196_arg0) or 0)):reverse()
	L_197_ = L_197_:gsub("(%d%d%d)", "%1,"):reverse()
	return L_197_:gsub("^,", "")
end

local function L_35_func(L_198_arg0)
	if type(L_198_arg0) ~= "string" then
		return nil
	end
	local L_199_ = L_198_arg0:gsub("[^%d%.KkMmBb]", "")
	local L_200_ = tonumber(L_199_:match("[%d%.]+"))
	if not L_200_ then
		return nil
	end
	local L_201_ = (L_199_:match("%a") or ""):lower()
	if L_201_ == "k" then
		return L_200_ * 1_000
	elseif L_201_ == "m" then
		return L_200_ * 1_000_000
	elseif L_201_ == "b" then
		return L_200_ * 1_000_000_000
	end
	return L_200_
end

local function L_36_func(L_202_arg0)
	return "||" .. tostring(L_202_arg0) .. "||"
end

local function L_37_func(L_203_arg0)
	local L_204_ = tostring(L_8_.DiscordId or ""):gsub("%D", "")
	if not L_203_arg0 or L_204_ == "" then
		return nil
	end
	return "<@" .. L_204_ .. ">"
end

local function L_38_func(L_205_arg0)
	return L_205_arg0 ~= nil and tostring(L_205_arg0.Active) == "true"
end

local function L_39_func(L_206_arg0)
	if not L_206_arg0 then
		return false
	end
	if tostring(L_206_arg0.Active) == "true" then
		return true
	end
	return (tonumber(L_206_arg0.Wave) or 0) >= 1
end

local function L_40_func(L_207_arg0)
	if not L_207_arg0 then
		return false
	end
	return (tonumber(L_207_arg0.BaseHealth) or 1) <= 0
end

local function L_41_func(L_208_arg0, L_209_arg1)
	return L_209_arg1[L_208_arg0] or tostring(L_208_arg0)
end

local function L_42_func(L_210_arg0)
	local L_211_ = {}
	local L_212_ = {}
	for L_213_forvar0, L_214_forvar1 in pairs(L_210_arg0) do
		table.insert(L_211_, L_214_forvar1)
		L_212_[L_214_forvar1] = L_213_forvar0
	end
	table.sort(L_211_)
	return L_211_, L_212_
end

local function L_43_func(L_215_arg0, L_216_arg1, L_217_arg2)
	local L_218_ = 0
	for L_219_forvar0, L_220_forvar1 in pairs(L_217_arg2 or {}) do
		local L_221_ = L_215_arg0 and L_215_arg0[L_220_forvar1]
		if type(L_221_) == "number" and L_221_ > L_218_ then
			L_218_ = L_221_
		end
		local L_222_ = L_216_arg1 and L_216_arg1[L_220_forvar1]
		if type(L_222_) == "number" and L_222_ > L_218_ then
			L_218_ = L_222_
		end
	end
	return L_218_
end

local function L_44_func(L_223_arg0)
	if not L_223_arg0 then
		return "—"
	end
	local L_224_ = L_223_arg0.Kind
	if L_224_ == "Place" then
		local L_225_ = L_223_arg0.Name or ("slot " .. tostring(L_223_arg0.Slot))
		local L_226_ = L_223_arg0.Cost and (" (¥" .. L_34_func(L_223_arg0.Cost) .. ")") or ""
		return "Place " .. L_225_ .. L_226_
	elseif L_224_ == "Upgrade" then
		local L_227_ = L_223_arg0.Name or ("unit #" .. tostring(L_223_arg0.Ref))
		local L_228_ = L_223_arg0.Count and L_223_arg0.Count > 1 and (" x" .. tostring(L_223_arg0.Count)) or ""
		return "Upgrade " .. L_227_ .. L_228_
	elseif L_224_ == "Sell" then
		return "Sell " .. (L_223_arg0.Name or ("unit #" .. tostring(L_223_arg0.Ref)))
	elseif L_224_ == "Ability" then
		return "Ability " .. (L_223_arg0.Name or ("unit #" .. tostring(L_223_arg0.Ref)))
	elseif L_224_ == "Vote" then
		return "Vote " .. tostring(L_223_arg0.Value)
	end
	return tostring(L_224_)
end

L_1_.cframeFromArray = L_31_func
L_1_.cframeToArray = L_32_func
L_1_.formatDuration = L_33_func
L_1_.formatNumber = L_34_func
L_1_.parseAbbreviatedNumber = L_35_func
L_1_.discordSpoiler = L_36_func
L_1_.discordMention = L_37_func
L_1_.isMatchActive = L_39_func
L_1_.isUnitDefeated = L_40_func
L_1_.describeMacroAction = L_44_func

local L_45_ = {
	"Mode",
	"MacroName",
	"SelectedMacro",
	"PlayMacro",
	"AutoRetry",
	"AutoStart",
	"AutoJoin",
	"Joiner",
	"StageCounts",
	"WebhookUrl",
	"WebhookEnabled",
	"WebhookItems",
	"AutoClaimQuests",
	"AutoClaimEvents",
	"AutoClaimIndex",
	"AutoClaimMilestones",
	"AutoClaimGroup",
	"AutoClaimCodes",
	"AutoClaimBattlepass",
	"AutoSellEnabled",
	"AutoSellRarities",
	"AutoSummon",
	"SummonBanner",
	"SummonAmount",
	"SummonTargets",
	"SummonUntilUnit",
	"DiscordId",
	"SummonPing",
	"GameDropPing",
	"AutoBuyMerchant",
	"MerchantItems",
}

local function L_46_func()
	local L_229_ = {}
	for L_230_forvar0, L_231_forvar1 in ipairs(L_45_) do
		L_229_[L_231_forvar1] = L_8_[L_231_forvar1]
	end
	L_29_func(L_7_.SettingsFile, L_229_)
end

local function L_47_func()
	local L_232_ = L_30_func(L_7_.SettingsFile)
	if not L_232_ then
		return
	end
	L_8_.Mode = L_232_.Mode or L_8_.Mode
	L_8_.MacroName = L_232_.MacroName or L_8_.MacroName
	L_8_.SelectedMacro = L_232_.SelectedMacro
	L_8_.PlayMacro = L_232_.PlayMacro == true
	L_8_.AutoRetry = L_232_.AutoRetry == true
	L_8_.AutoStart = L_232_.AutoStart ~= false
	L_8_.AutoJoin = L_232_.AutoJoin ~= false
	if type(L_232_.Joiner) == "table" then
		L_8_.Joiner = L_232_.Joiner
	end
	if type(L_232_.StageCounts) == "table" then
		L_8_.StageCounts = L_232_.StageCounts
	end
	L_8_.WebhookUrl = L_232_.WebhookUrl or ""
	L_8_.WebhookEnabled = L_232_.WebhookEnabled == true
	if type(L_232_.WebhookItems) == "table" and #L_232_.WebhookItems > 0 then
		L_8_.WebhookItems = L_232_.WebhookItems
	end
	L_8_.AutoClaimQuests = L_232_.AutoClaimQuests == true
	L_8_.AutoClaimEvents = L_232_.AutoClaimEvents == true
	L_8_.AutoClaimIndex = L_232_.AutoClaimIndex == true
	L_8_.AutoClaimMilestones = L_232_.AutoClaimMilestones == true
	L_8_.AutoClaimGroup = L_232_.AutoClaimGroup == true
	L_8_.AutoClaimCodes = L_232_.AutoClaimCodes == true
	L_8_.AutoClaimBattlepass = L_232_.AutoClaimBattlepass == true
	L_8_.AutoSellEnabled = L_232_.AutoSellEnabled == true
	if type(L_232_.AutoSellRarities) == "table" then
		L_8_.AutoSellRarities = L_232_.AutoSellRarities
	end
	L_8_.AutoSummon = L_232_.AutoSummon == true
	L_8_.SummonBanner = L_232_.SummonBanner or L_8_.SummonBanner
	L_8_.SummonAmount = tonumber(L_232_.SummonAmount) or L_8_.SummonAmount
	if type(L_232_.SummonTargets) == "table" then
		L_8_.SummonTargets = L_232_.SummonTargets
	end
	L_8_.SummonUntilUnit = L_232_.SummonUntilUnit == true
	L_8_.DiscordId = L_232_.DiscordId or ""
	L_8_.SummonPing = L_232_.SummonPing == true
	L_8_.GameDropPing = L_232_.GameDropPing == true
	L_8_.AutoBuyMerchant = L_232_.AutoBuyMerchant == true
	if type(L_232_.MerchantItems) == "table" then
		L_8_.MerchantItems = L_232_.MerchantItems
	end
end

L_1_.saveSettings = L_46_func
L_1_.loadSettings = L_47_func

local function L_48_func(L_233_arg0)
	return function(L_234_arg0)
		L_8_[L_233_arg0] = L_234_arg0
		L_46_func()
	end
end

local function L_49_func(L_235_arg0)
	return function(L_236_arg0)
		L_8_.Joiner[L_235_arg0] = L_236_arg0
		L_46_func()
	end
end

L_1_.Callbacks = {
	on_AutoClaimBattlepass = L_48_func("AutoClaimBattlepass"),
	on_MacroName = L_48_func("MacroName"),
	on_SummonAmount = L_48_func("SummonAmount"),
	on_AutoBuyMerchant = L_48_func("AutoBuyMerchant"),
	on_SelectedMacro = L_48_func("SelectedMacro"),
	on_GameDropPing = L_48_func("GameDropPing"),
	on_SummonUntilUnit = L_48_func("SummonUntilUnit"),
	on_AutoRetry = L_48_func("AutoRetry"),
	on_AutoClaimGroup = L_48_func("AutoClaimGroup"),
	on_WebhookEnabled = L_48_func("WebhookEnabled"),
	on_WebhookUrl = L_48_func("WebhookUrl"),
	on_AutoClaimQuests = L_48_func("AutoClaimQuests"),
	on_AutoSummon = L_48_func("AutoSummon"),
	on_DiscordId = L_48_func("DiscordId"),
	on_AutoClaimEvents = L_48_func("AutoClaimEvents"),
	on_AutoJoin = L_48_func("AutoJoin"),
	on_SummonPing = L_48_func("SummonPing"),
	on_SummonBanner = L_48_func("SummonBanner"),
	on_Mode = L_48_func("Mode"),
	on_AutoStart = L_48_func("AutoStart"),
	on_AutoClaimMilestones = L_48_func("AutoClaimMilestones"),
	on_AutoClaimCodes = L_48_func("AutoClaimCodes"),
	on_AutoClaimIndex = L_48_func("AutoClaimIndex"),
	on_JoinGamemode = L_49_func("Gamemode"),
	on_JoinMap = L_49_func("Map"),
	on_JoinAct = L_49_func("Act"),
	on_JoinDifficulty = L_49_func("Difficulty"),
}

local function L_50_func(L_237_arg0, L_238_arg1)
	if not L_237_arg0 then
		return nil
	end
	local L_239_ = L_237_arg0:FindFirstChild(L_238_arg1)
	if not L_239_ then
		return nil
	end
	local L_240_, L_241_ = pcall(require, L_239_)
	if L_240_ and type(L_241_) == "table" then
		return L_241_
	end
	return nil
end

local function L_51_func(L_242_arg0)
	return L_50_func(L_242_arg0, "BannerInfo")
end

local function L_52_func(L_243_arg0)
	return L_50_func(L_243_arg0, "Units")
end

local function L_53_func()
	return L_51_func(L_14_func())
end

local function L_54_func(L_244_arg0)
	local L_245_ = L_53_func()
	local L_246_ = L_245_ and L_245_.Banners
	local L_247_ = type(L_246_) == "table" and L_246_[L_244_arg0] or nil
	return tonumber(type(L_247_) == "table" and L_247_.Cost) or 0
end

local function L_55_func(L_248_arg0, L_249_arg1, L_250_arg2)
	local L_251_ = L_248_arg0 and L_248_arg0:FindFirstChild("Maps")
	local L_252_ = L_251_ and L_251_:FindFirstChild(L_249_arg1 or "")
	local L_253_ = L_252_ and L_252_:FindFirstChild(L_250_arg2 or "")
	if not L_253_ then
		return nil
	end
	local L_254_, L_255_ = pcall(require, L_253_)
	return L_254_ and L_255_ or nil
end

local function L_56_func(L_256_arg0)
	local L_257_ = {}
	local L_258_ = L_256_arg0 and L_256_arg0:FindFirstChild("Maps")
	if not L_258_ then
		return L_257_
	end
	for L_259_forvar0, L_260_forvar1 in pairs(L_258_:GetChildren()) do
		if #L_260_forvar1:GetChildren() > 0 then
			table.insert(L_257_, L_260_forvar1.Name)
		end
	end
	table.sort(L_257_)
	return L_257_
end

local function L_57_func(L_261_arg0, L_262_arg1)
	local L_263_ = {}
	local L_264_ = L_261_arg0 and L_261_arg0:FindFirstChild("Maps")
	local L_265_ = L_264_ and L_264_:FindFirstChild(L_262_arg1 or "")
	if not L_265_ then
		return L_263_
	end
	for L_266_forvar0, L_267_forvar1 in pairs(L_265_:GetChildren()) do
		table.insert(L_263_, L_267_forvar1.Name)
	end
	table.sort(L_263_)
	return L_263_
end

local function L_58_func(L_268_arg0, L_269_arg1, L_270_arg2)
	local L_271_ = L_268_arg0(L_269_arg1, L_270_arg2)
	local L_272_ = {}
	if L_271_ and type(L_271_.ActProgression) == "table" then
		for L_273_forvar0, L_274_forvar1 in pairs(L_271_.ActProgression) do
			table.insert(L_272_, tostring(L_274_forvar1))
		end
	elseif L_271_ and type(L_271_.Acts) == "table" then
		for L_275_forvar0 in pairs(L_271_.Acts) do
			table.insert(L_272_, tostring(L_275_forvar0))
		end
	end
	if #L_272_ == 0 then
		table.insert(L_272_, "Act 1")
	end
	table.sort(L_272_)
	return L_272_
end

local function L_59_func(L_276_arg0, L_277_arg1, L_278_arg2)
	local L_279_ = L_276_arg0(L_277_arg1, L_278_arg2)
	local L_280_ = {}
	if L_279_ and type(L_279_.Difficulties) == "table" then
		local L_281_ = {}
		for L_282_forvar0 in pairs(L_279_.Difficulties) do
			table.insert(L_281_, L_282_forvar0)
		end
		table.sort(L_281_, function(L_283_arg0, L_284_arg1)
			return (tonumber(L_283_arg0) or 0) < (tonumber(L_284_arg1) or 0)
		end)
		for L_285_forvar0, L_286_forvar1 in pairs(L_281_) do
			table.insert(L_280_, tostring(L_279_.Difficulties[L_286_forvar1]))
		end
	end
	if #L_280_ == 0 then
		L_280_[1] = "Normal"
	end
	return L_280_
end

local function L_60_func(L_287_arg0, L_288_arg1)
	return L_55_func(L_14_func(), L_287_arg0, L_288_arg1)
end

local function L_61_func()
	local L_289_ = L_56_func(L_14_func())
	return #L_289_ > 0 and L_289_ or {
		"Default"
	}
end

local function L_62_func(L_290_arg0)
	local L_291_ = L_57_func(L_14_func(), L_290_arg0)
	return #L_291_ > 0 and L_291_ or {
		"Default"
	}
end

local function L_63_func(L_292_arg0, L_293_arg1)
	return L_58_func(L_60_func, L_292_arg0, L_293_arg1)
end

local function L_64_func(L_294_arg0, L_295_arg1)
	return L_59_func(L_60_func, L_294_arg0, L_295_arg1)
end

L_1_.listGamemodes = L_61_func
L_1_.listMaps = L_62_func
L_1_.listActs = L_63_func
L_1_.listDifficulties = L_64_func

local function L_65_func(L_296_arg0)
	L_296_arg0 = L_296_arg0 or L_20_func
	local L_297_ = L_296_arg0("PlayerData")
	return L_297_ and L_297_.Data or nil
end

local function L_66_func(L_298_arg0)
	L_298_arg0 = L_298_arg0 or L_20_func
	local L_299_ = L_298_arg0("PlayerData")
	local L_300_ = L_299_ and L_299_.Data
	if L_300_ and type(L_300_.UnitData) == "table" then
		return L_300_.UnitData
	end
	return nil
end

local function L_67_func(L_301_arg0, L_302_arg1)
	L_301_arg0 = L_301_arg0 or L_65_func
	local L_303_ = L_301_arg0()
	local L_304_ = L_303_ and L_303_.ItemData and L_303_.ItemData[L_302_arg1]
	return tonumber(L_304_ and L_304_.Amount) or 0
end

local function L_68_func(L_305_arg0)
	return L_67_func(L_65_func, L_305_arg0)
end

local function L_69_func()
	local L_306_ = L_20_func("GameState")
	if not L_306_ then
		return nil
	end
	local L_307_, L_308_ = pcall(function()
		return L_306_.Data
	end)
	return L_307_ and L_308_ or nil
end

local function L_70_func()
	local L_309_ = L_20_func("GamePlayerData")
	local L_310_ = L_309_ and L_309_.Data and L_309_.Data.Yen
	return tonumber(L_310_) or 0
end

L_1_.listMapChildren = function(L_311_arg0)
	return L_62_func(L_311_arg0)
end
L_1_.getPlayerData = L_65_func
L_1_.getUnitData = L_66_func
L_1_.getItemData = L_67_func
L_1_.getCurrency = L_68_func
L_1_.getGameState = L_69_func
L_1_.getGameYen = L_70_func
L_1_.getBannerData = L_53_func
L_1_.getSummonPrice = L_54_func

local L_71_ = {}
local L_72_ = {}

local function L_73_func(L_312_arg0, L_313_arg1, L_314_arg2)
	local L_315_ = L_312_arg0 and L_312_arg0:FindFirstChild("Items")
	if not L_315_ then
		return
	end
	local L_316_, L_317_ = pcall(require, L_315_)
	if not L_316_ or type(L_317_) ~= "table" then
		return
	end
	for L_318_forvar0, L_319_forvar1 in pairs(L_317_) do
		if type(L_319_forvar1) == "table" then
			local L_320_ = tostring(L_318_forvar0)
			local L_321_ = L_319_forvar1.DisplayName or L_319_forvar1.Name or L_320_
			L_313_arg1[L_320_] = tostring(L_321_)
			L_314_arg2[L_320_] = L_319_forvar1
		end
	end
end

local function L_74_func()
	table.clear(L_71_)
	table.clear(L_72_)
	L_73_func(L_14_func(), L_71_, L_72_)
end

local function L_75_func(L_322_arg0)
	local L_323_ = tostring(L_322_arg0)
	return L_41_func(L_323_, L_71_)
end

local L_76_ = {}

local function L_77_func()
	local L_324_ = {}
	table.clear(L_76_)
	local L_325_ = L_52_func(L_14_func())
	if type(L_325_) == "table" then
		for L_326_forvar0, L_327_forvar1 in pairs(L_325_) do
			if type(L_327_forvar1) == "table"
                and type(L_327_forvar1.Summonable) == "table"
                and next(L_327_forvar1.Summonable) ~= nil then
				local L_328_ = tostring(L_326_forvar0)
				L_76_[L_328_] = {
					Display = tostring(L_327_forvar1.DisplayName or L_326_forvar0),
					Rarity = tostring(L_327_forvar1.Rarity or "?"),
				}
				table.insert(L_324_, L_328_)
			end
		end
	end
	table.sort(L_324_)
	return L_324_
end

local function L_78_func()
	local L_329_ = {}
	local L_330_ = L_53_func()
	if type(L_330_) == "table" and type(L_330_.Banners) == "table" then
		for L_331_forvar0 in pairs(L_330_.Banners) do
			table.insert(L_329_, tostring(L_331_forvar0))
		end
	end
	if #L_329_ == 0 then
		L_329_ = {
			"Standard",
			"Mini"
		}
	end
	table.sort(L_329_)
	return L_329_
end

local function L_79_func()
	local L_332_ = {}
	if type(listfiles) ~= "function" then
		return L_332_
	end
	pcall(function()
		for L_333_forvar0, L_334_forvar1 in ipairs(listfiles(L_7_.MacroFolder)) do
			local L_335_ = string.match(L_334_forvar1, "([^/\\]+)%.json$")
			if L_335_ then
				table.insert(L_332_, L_335_)
			end
		end
	end)
	table.sort(L_332_)
	return L_332_
end

L_1_.ItemDisplayNames = L_71_
L_1_.ItemMetadata = L_72_
L_1_.loadItemMetadata = L_73_func
L_1_.initializeItemMetadata = L_74_func
L_1_.itemDisplayName = L_75_func
L_1_.listSummonUnits = L_77_func
L_1_.listBanners = L_78_func
L_1_.listMacros = L_79_func
L_1_.SummonUnitInfo = L_76_

local function L_80_func(L_336_arg0)
	local L_337_ = L_336_arg0 and L_336_arg0.QuestData
	if type(L_337_) ~= "table" then
		return false
	end
	local function L_338_func(L_339_arg0)
		if type(L_339_arg0) ~= "table" then
			return false
		end
		if L_339_arg0.Completed == true and L_339_arg0.Claimed ~= true then
			return true
		end
		if type(L_339_arg0.Quests) == "table" then
			for L_340_forvar0, L_341_forvar1 in pairs(L_339_arg0.Quests) do
				if L_338_func(L_341_forvar1) then
					return true
				end
			end
		end
		for L_342_forvar0, L_343_forvar1 in pairs(L_339_arg0) do
			if type(L_343_forvar1) == "table" and L_343_forvar1 ~= L_339_arg0.Quests and L_338_func(L_343_forvar1) then
				return true
			end
		end
		return false
	end
	return L_338_func(L_337_)
end

local function L_81_func(L_344_arg0, L_345_arg1)
	local L_346_ = L_344_arg0 and L_344_arg0.BattlepassData
	if type(L_346_) ~= "table" then
		return
	end
	for L_347_forvar0 in pairs(L_346_) do
		L_345_arg1("CLAIM_ALL_BATTLEPASS_REWARDS", tostring(L_347_forvar0))
		task.wait(0.3)
	end
end

local L_82_ = {}
local L_83_ = 0

local function L_84_func(L_348_arg0, L_349_arg1, L_350_arg2)
	local L_351_ = L_348_arg0 and L_348_arg0:FindFirstChild("Codes")
	if not L_351_ then
		return
	end
	local L_352_, L_353_ = pcall(require, L_351_)
	if not L_352_ or type(L_353_) ~= "table" then
		return
	end
	local L_354_ = L_353_.Codes or L_353_
	if type(L_354_) ~= "table" then
		return
	end
	local L_355_ = {}
	if L_349_arg1 and type(L_349_arg1.ClaimedCodes) == "table" then
		for L_357_forvar0, L_358_forvar1 in pairs(L_349_arg1.ClaimedCodes) do
			L_355_[tostring(L_358_forvar1)] = true
		end
	end
	local L_356_ = os.time()
	for L_359_forvar0, L_360_forvar1 in pairs(L_354_) do
		L_359_forvar0 = tostring(L_359_forvar0)
		if not L_355_[L_359_forvar0]
            and not L_82_[L_359_forvar0]
            and type(L_360_forvar1) == "table" then
			local L_361_ = tonumber(L_360_forvar1.ActiveFrom) or 0
			local L_362_ = tonumber(L_360_forvar1.ActiveUntil) or math.huge
			local L_363_ = L_360_forvar1.RequiredRole or L_360_forvar1.MinimumRole or L_360_forvar1.MinumumRole
			if L_361_ <= L_356_ and L_356_ <= L_362_ and not L_363_ then
				claimCodeNonce += 1
				L_82_[L_359_forvar0] = true
				L_350_arg2("CLAIM_CODE_RequestNODE", L_83_, L_359_forvar0)
				task.wait(0.6)
			end
		end
	end
end

local function L_85_func()
	if not L_26_func() then
		return
	end
	local L_364_ = L_65_func()
	if not L_364_ then
		return
	end
	if L_8_.AutoClaimQuests and L_80_func(L_364_) then
		L_25_func("QUEST_CLAIM_ALL_CATEGORIES")
		task.wait(0.3)
	end
	if L_8_.AutoClaimIndex then
		L_25_func("INDEX_CLAIM_ALL")
		task.wait(0.3)
	end
	if L_8_.AutoClaimGroup then
		L_25_func("GROUP_REWARDS_CLAIM")
		task.wait(0.3)
	end
	if L_8_.AutoClaimMilestones then
		L_25_func("CLAIM_LEVEL_MILESTONE")
		task.wait(0.3)
	end
	if L_8_.AutoClaimEvents then
		L_25_func("QUESTBOARD_CLAIM_ALL_MILESTONES")
		task.wait(0.3)
		L_25_func("CLAIM_CALENDAR")
		task.wait(0.3)
	end
	if L_8_.AutoClaimBattlepass then
		L_81_func(L_364_, L_25_func)
	end
	if L_8_.AutoClaimCodes then
		L_84_func(L_14_func(), L_364_, L_25_func)
	end
end

L_1_.hasClaimableQuest = L_80_func
L_1_.claimBattlepassRewards = L_81_func
L_1_.claimCodes = L_84_func
L_1_.claimAvailableRewards = L_85_func

local L_86_ = false
local L_87_ = false
local L_88_ = nil

local function L_89_func(L_365_arg0, L_366_arg1)
	if L_9_ and L_9_.notify then
		pcall(L_9_.notify, L_365_arg0, L_366_arg1 or 4)
	end
end

local function L_90_func()
	if L_86_ then
		return
	end
	L_86_ = true
	L_25_func("CLIENT_CHANGE_SETTING", "SummonMax", true)
end

local function L_91_func()
	if L_8_.SummonUntilUnit then
		L_8_.SummonUntilUnit = false
		if L_10_ and L_10_.SummonUntilToggle then
			pcall(function()
				L_10_.SummonUntilToggle:SetValue(false)
			end)
		end
	end
	L_46_func()
end

local function L_92_func()

	if L_26_func() then
		return
	end
	if not L_8_.AutoSummon and not L_8_.SummonUntilUnit then
		return
	end
	local L_367_ = L_8_.SummonBanner or "Standard"
	local L_368_ = math.max(1, tonumber(L_8_.SummonAmount) or 1)
	if L_368_ > 1 then
		L_90_func()
	end
	local L_369_ = L_54_func(L_367_)
	local L_370_ = L_369_ * L_368_
	local L_371_ = L_68_func("Gem")
	if L_371_ < L_370_ then
		if not L_87_ then
			L_89_func("Out of Gems — auto summon paused.", 4)
		end
		L_87_ = true
		return
	end
	L_87_ = false
	L_25_func("BANNER_SUMMON", L_367_, L_368_)
end

local function L_93_func()
	if not L_8_.SummonUntilUnit or next(L_8_.SummonTargets) == nil then
		return
	end
	local L_372_ = L_66_func()
	if type(L_372_) ~= "table" then
		return
	end
	local L_373_ = {}
	for L_375_forvar0, L_376_forvar1 in pairs(L_8_.SummonTargets) do
		L_373_[tostring(L_376_forvar1)] = true
	end
	if L_88_ == nil then
		L_88_ = {}
		for L_377_forvar0 in pairs(L_372_) do
			L_88_[L_377_forvar0] = true
		end
		return
	end
	local L_374_ = false
	for L_378_forvar0, L_379_forvar1 in pairs(L_372_) do
		if not L_88_[L_378_forvar0] then
			L_88_[L_378_forvar0] = true
			local L_380_ = type(L_379_forvar1) == "table" and L_379_forvar1.Asset or nil
			local L_381_ = L_380_ and tostring(L_380_) or nil
			if L_381_ and L_373_[L_381_] then
				L_374_ = true
				local L_382_ = L_76_[L_381_] or {}
				local L_383_ = L_382_.Display or L_381_
				L_89_func("Summoned " .. L_383_ .. "!", 6)
				if L_11_ then
					task.spawn(L_11_, L_381_, L_379_forvar1)
				end
			end
		end
	end
	if L_374_ then
		L_91_func()
	end
end

local function L_94_func()
	L_88_ = nil
end

L_1_.autoSummonWorker = L_92_func
L_1_.handleSummonResult = L_93_func
L_1_.stopSummonUntilTarget = L_91_func
L_1_.resetSummonResultBaseline = L_94_func

local L_95_ = {
	"Common",
	"Uncommon",
	"Rare",
	"Epic",
	"Legendary",
	"Mythic",
}

local function L_96_func()
	local L_384_ = {}
	local L_385_ = {}
	local L_386_ = L_65_func()
	local L_387_ = L_386_
        and L_386_.Settings
        and L_386_.Settings.AutoSell
        and L_386_.Settings.AutoSell.Standard
	if type(L_387_) == "table" then
		for L_388_forvar0 in pairs(L_387_) do
			L_388_forvar0 = tostring(L_388_forvar0)
			if not L_385_[L_388_forvar0] then
				L_385_[L_388_forvar0] = true
				table.insert(L_384_, L_388_forvar0)
			end
		end
	end

	for L_389_forvar0, L_390_forvar1 in ipairs(L_95_) do
		if not L_385_[L_390_forvar1] then
			L_385_[L_390_forvar1] = true
			table.insert(L_384_, L_390_forvar1)
		end
	end
	return L_384_
end

local function L_97_func()
	local L_391_ = {}
	if L_8_.AutoSellEnabled then
		for L_392_forvar0, L_393_forvar1 in pairs(L_8_.AutoSellRarities) do
			L_391_[L_393_forvar1] = true
		end
	end
	for L_394_forvar0, L_395_forvar1 in ipairs(L_96_func()) do
		L_25_func("CHANGE_AUTOSELL_SETTING", L_395_forvar1, L_391_[L_395_forvar1] == true)
		task.wait(0.2)
	end
end

local function L_98_func(L_396_arg0)
	L_8_.AutoSellEnabled = L_396_arg0
	L_46_func()
	task.spawn(function()
		L_97_func()
	end)
end

local function L_99_func(L_397_arg0)
	L_8_.AutoSellRarities = L_397_arg0 or {}
	L_46_func()
	task.spawn(function()
		L_97_func()
	end)
end

L_1_.listAutoSellRarities = L_96_func
L_1_.applyAutoSellSettings = L_97_func
L_1_.onAutoSellEnabled = L_98_func
L_1_.onAutoSellRarities = L_99_func

local function L_100_func(L_398_arg0)
	local L_399_ = L_16_ or L_18_func()
	if type(L_399_) ~= "table" then
		return nil
	end
	local L_400_ = tostring(L_398_arg0)
	for L_401_forvar0, L_402_forvar1 in pairs(L_399_) do
		local L_403_ = false
		pcall(function()
			local L_404_ = tostring(L_402_forvar1.Token or L_402_forvar1.Class)
			L_403_ = L_404_ == "ShopData"
                and tostring(L_402_forvar1.Data.DataKey) == L_400_
		end)
		if L_403_ then
			return L_402_forvar1
		end
	end
	return nil
end

local function L_101_func(L_405_arg0, L_406_arg1)
	local L_407_ = L_100_func(L_405_arg0)
	if not L_407_ then
		return nil, {}
	end
	local L_408_ = L_407_.Data
	local L_409_ = L_408_ and L_408_.Shops and L_408_.Shops[L_405_arg0]
	local L_410_ = L_409_ and L_409_.Items
	if type(L_410_) ~= "table" then
		return L_407_, {}
	end
	local L_411_ = L_408_.PurchaseHistory
	L_411_ = L_411_ and L_411_[L_406_arg1]
	L_411_ = L_411_ and L_411_[L_405_arg0]
	local L_412_ = {}
	for L_413_forvar0, L_414_forvar1 in pairs(L_410_) do
		local L_415_ = tonumber(L_413_forvar0)
		if L_415_ and type(L_414_forvar1) == "table" then
			local L_416_ = tostring(L_414_forvar1.Name)
			local L_417_ = tonumber(type(L_411_) == "table" and L_411_[L_416_]) or 0
			local L_418_ = tonumber(L_414_forvar1.Price) or 0
			local L_419_ = tonumber(L_414_forvar1.Stock) or 0
			table.insert(L_412_, {
				Index = L_415_,
				Name = L_416_,
				Label = L_75_func(L_416_),
				Price = L_418_,
				Remaining = L_419_ - L_417_,
			})
		end
	end
	table.sort(L_412_, function(L_420_arg0, L_421_arg1)
		return L_420_arg0.Price < L_421_arg1.Price
	end)
	return L_407_, L_412_
end

local function L_102_func()
	if L_26_func() then
		return
	end
	if next(L_8_.MerchantItems) == nil then
		return
	end
	local L_422_, L_423_ = L_101_func("GoldShop", "GoldShop1")
	if not L_422_ then
		return
	end
	local L_424_ = {}
	for L_427_forvar0, L_428_forvar1 in pairs(L_8_.MerchantItems) do
		L_424_[L_428_forvar1] = true
	end
	local L_425_ = L_68_func("Gold")
	local L_426_ = false
	for L_429_forvar0, L_430_forvar1 in ipairs(L_423_) do
		if L_424_[L_430_forvar1.Name] and L_430_forvar1.Remaining > 0 then
			if L_430_forvar1.Price <= L_425_ then
				pcall(function()
					L_422_:FireServer("PurchaseItem", "GoldShop1", L_430_forvar1.Index, 1)
				end)
				gold -= L_430_forvar1.Price
				task.wait(0.4)
			else
				L_426_ = true
			end
		end
	end
	if L_426_ then
		L_89_func("Not enough Gold for all selected merchant items.", 4)
	end
end

local function L_103_func()
	task.spawn(L_102_func)
end

L_1_.findShopReplica = L_100_func
L_1_.buildMerchantItems = L_101_func
L_1_.runMerchantPurchase = L_102_func
L_1_.startMerchantWorker = L_103_func

local function L_104_func(L_431_arg0)
	if not L_15_ or type(L_15_.FromId) ~= "function" then
		return nil
	end
	local L_432_, L_433_ = pcall(L_15_.FromId, tonumber(L_431_arg0))
	return L_432_ and L_433_ or nil
end

local function L_105_func(L_434_arg0)
	local L_435_ = L_434_arg0
	if type(L_435_) ~= "table" then
		L_435_ = L_104_func(L_434_arg0)
	end
	if not L_435_ then
		return nil
	end
	local L_436_ = L_435_.Data
	local L_437_ = type(L_436_) == "table" and L_436_.UnitData or nil
	if type(L_437_) ~= "table" then
		return "Unit"
	end
	return tostring(L_437_.Asset or L_437_.Name or "Unit")
end

local function L_106_func(L_438_arg0)
	local L_439_ = L_6_:FindFirstChild("PlayerGui")
	local L_440_ = L_439_ and L_439_:FindFirstChild("BottomHUD")
	if not L_440_ then
		return nil
	end
	for L_441_forvar0, L_442_forvar1 in ipairs(L_440_:GetDescendants()) do
		if (L_442_forvar1:IsA("TextButton") or L_442_forvar1:IsA("ImageButton"))
            and L_442_forvar1.LayoutOrder == L_438_arg0 then
			for L_443_forvar0, L_444_forvar1 in ipairs(L_442_forvar1:GetDescendants()) do
				if L_444_forvar1:IsA("TextLabel") and string.find(L_444_forvar1.Text or "", "¥", 1, true) then
					return L_35_func(L_444_forvar1.Text)
				end
			end
		end
	end
	return nil
end

local function L_107_func(L_445_arg0)
	local L_446_ = L_104_func(L_445_arg0)
	if not L_446_ then
		return nil
	end
	local L_447_ = L_446_.Data
	local L_448_ = type(L_447_) == "table" and L_447_.NextStats or nil
	return tonumber(L_448_ and L_448_.Cost)
end

local function L_108_func(L_449_arg0)
	if L_8_.Replaying then
		table.insert(L_8_.NewUnitQueue, L_449_arg0)
		return
	end
	if not L_8_.Recording then
		return
	end
	State.RecPlacementSeq += 1
	local L_450_, L_451_ = pcall(function()
		return tostring(L_449_arg0.Id)
	end)
	if L_450_ and L_451_ then
		L_8_.LiveIdToIndex[L_451_] = L_8_.RecPlacementSeq
	end
	local L_452_ = L_8_.PendingPlace
	if not L_452_ then
		return
	end
	local L_453_ = L_105_func(L_449_arg0) or "Unit"
	L_452_.Name = L_453_
	local L_454_ = L_452_.Cost and (" (¥" .. L_34_func(L_452_.Cost) .. ")") or ""
	L_8_.StepText = "Unit Placed : " .. L_453_ .. L_454_
	L_8_.PendingPlace = nil
end

local function L_109_func()
	if not L_15_ or type(L_15_.OnNew) ~= "function" then
		return false
	end
	return pcall(function()
		L_15_.OnNew("GameUnit", L_108_func)
	end)
end

local function L_110_func(L_455_arg0, L_456_arg1)
	if not L_8_.Recording or L_8_.Replaying then
		return
	end
	local L_457_ = tostring(L_455_arg0.Token or L_455_arg0.Class)
	local L_458_ = tostring(L_456_arg1[1])
	local L_459_ = os.clock() - L_8_.RecordStart
	local L_460_ = L_8_.Current and L_8_.Current.Actions
	if type(L_460_) ~= "table" then
		return
	end
	if L_457_ == "GamePlayerData" then
		if L_458_ == "PlaceGameUnit" then
			local L_461_ = L_456_arg1[2]
			local L_462_ = {
				Kind = "Place",
				T = L_459_,
				Slot = L_461_,
				CFrame = L_32_func(L_456_arg1[3]),
				Yen = L_70_func(),
				Cost = L_106_func(L_461_),
			}
			table.insert(L_460_, L_462_)
			L_8_.PendingPlace = L_462_
			return
		end
		if L_458_ == "UpgradeGameUnit" then
			local L_463_ = tostring(L_456_arg1[2])
			local L_464_ = L_8_.LiveIdToIndex[L_463_]
			local L_465_ = L_105_func(L_463_) or "Unit"
			local L_466_ = L_107_func(L_463_)
			local L_467_ = L_460_[#L_460_]
			if L_467_ and L_467_.Kind == "Upgrade" and L_467_.Ref == L_464_ then
				L_467_.Count = (L_467_.Count or 1) + 1
				L_467_.TEnd = L_459_
			else
				table.insert(L_460_, {
					Kind = "Upgrade",
					T = L_459_,
					Ref = L_464_,
					Count = 1,
					Yen = L_70_func(),
					Name = L_465_,
				})
			end
			local L_468_ = L_466_ and (" (¥" .. L_34_func(L_466_) .. ")") or ""
			L_8_.StepText = "Unit Upgraded : " .. L_465_ .. L_468_
			return
		end
		if L_458_ == "SellGameUnit" then
			local L_469_ = tostring(L_456_arg1[2])
			local L_470_ = L_105_func(L_469_) or "Unit"
			table.insert(L_460_, {
				Kind = "Sell",
				T = L_459_,
				Ref = L_8_.LiveIdToIndex[L_469_],
				Name = L_470_,
			})
			L_8_.StepText = "Unit Sold : " .. L_470_
			return
		end
		if string.find(L_458_, "Ability", 1, true) then
			local L_471_ = tostring(L_456_arg1[2])
			local L_472_ = L_105_func(L_471_) or "Unit"
			table.insert(L_460_, {
				Kind = "Ability",
				T = L_459_,
				Action = L_458_,
				Ref = L_8_.LiveIdToIndex[L_471_],
				Name = L_472_,
			})
			L_8_.StepText = "Ability Used : " .. L_472_
		end
		return
	end
	if L_457_ == "VotePrompt" and L_458_ == "Response" then
		table.insert(L_460_, {
			Kind = "Vote",
			T = L_459_,
			Value = L_456_arg1[2],
		})
		L_8_.StepText = "Vote : " .. tostring(L_456_arg1[2])
	end
end

local function L_111_func()
	if not L_15_ or type(hookfunction) ~= "function" then
		return false
	end
	local L_473_ = type(getgenv) == "function" and getgenv() or _G
	L_473_.AeRecordCallback = L_110_func
	if L_473_.AeHookInstalled then
		return true
	end
	local L_474_
	L_474_ = hookfunction(L_15_.FireServer, function(L_475_arg0, ...)
		local L_476_ = L_473_.AeRecordCallback
		if L_476_ then
			pcall(L_476_, L_475_arg0, table.pack(...))
		end
		return L_474_(L_475_arg0, ...)
	end)
	L_473_.AeHookInstalled = true
	return true
end

local function L_112_func()
	if L_8_.Recording then
		return
	end
	L_8_.Current = {
		Name = "Untitled",
		Actions = {},
	}
	L_8_.RecPlacementSeq = 0
	L_8_.LiveIdToIndex = {}
	L_8_.PendingPlace = nil
	L_8_.StepText = "Recording started"
	L_8_.RecordStart = os.clock()
	L_8_.Recording = true
end

local function L_113_func()
	L_8_.Recording = false
	return L_8_.Current
end

local function L_114_func()
	if not L_8_.Recording then
		return nil
	end
	local L_477_ = L_113_func()
	if not L_477_ then
		return nil
	end
	local L_478_ = L_8_.MacroName
	if not L_478_ or L_478_ == "" then
		L_478_ = "MyMacro"
	end
	L_477_.Name = L_478_
	L_29_func(L_7_.MacroFolder .. "/" .. L_478_ .. ".json", L_477_)
	L_8_.SelectedMacro = L_478_
	L_8_.LastSavedMacro = L_478_
	L_46_func()
	return L_478_, #L_477_.Actions
end

local function L_115_func()
	if not L_8_.SelectedMacro then
		return nil
	end
	return L_30_func(L_7_.MacroFolder .. "/" .. L_8_.SelectedMacro .. ".json")
end

local function L_116_func(L_479_arg0)
	if not L_479_arg0 then
		return false, "No macro selected"
	end
	local L_480_ = L_7_.MacroFolder .. "/" .. L_479_arg0 .. ".json"
	if not isfile(L_480_) then
		return false, "Macro not found"
	end
	local L_481_ = readfile(L_480_)
	if setclipboard then
		pcall(setclipboard, L_481_)
	end
	return true, L_481_
end

local function L_117_func(L_482_arg0)
	while L_8_.Replaying and os.clock() < L_482_arg0 do
		task.wait()
	end
end

local function L_118_func(L_483_arg0)
	local L_484_ = os.clock() + (L_483_arg0 or 10)
	while L_8_.Replaying and os.clock() < L_484_ do
		local L_485_ = L_8_.NewUnitQueue[1]
		if L_485_ then
			table.remove(L_8_.NewUnitQueue, 1)
			local L_486_, L_487_ = pcall(function()
				return tostring(L_485_.Id)
			end)
			return L_486_ and L_487_ or nil
		end
		task.wait()
	end
	return nil
end

local function L_119_func(L_488_arg0, L_489_arg1, L_490_arg2, L_491_arg3, L_492_arg4)
	local L_493_ = L_31_func(L_490_arg2.CFrame)
	if not L_493_ or not L_8_.Replaying then
		return
	end
	if L_8_.Mode == "Yen" then
		local L_495_ = L_106_func(L_490_arg2.Slot)
		while L_495_ and L_8_.Replaying and L_70_func() < L_495_ do
			L_8_.Status = "Waiting ¥" .. math.floor(L_495_)
                .. " to place slot " .. tostring(L_490_arg2.Slot)
                .. " (have " .. tostring(L_70_func()) .. ")"
			task.wait()
		end
	end
	if not L_8_.Replaying then
		return
	end
	L_8_.Status = "Placing slot " .. tostring(L_490_arg2.Slot)
	L_8_.NewUnitQueue = {}
	if L_489_arg1 then
		pcall(function()
			L_489_arg1:FireServer("SelectSlot", L_490_arg2.Slot)
		end)
	end
	pcall(function()
		L_488_arg0:FireServer("PlaceGameUnit", L_490_arg2.Slot, L_493_)
	end)
	local L_494_ = L_118_func(10)
	if L_494_ then
		L_491_arg3[L_492_arg4] = L_494_
	end
end

local function L_120_func(L_496_arg0, L_497_arg1, L_498_arg2)
	local L_499_ = L_497_arg1.Ref and L_498_arg2[L_497_arg1.Ref] or nil
	if not L_499_ then
		return
	end
	local L_500_ = tonumber(L_497_arg1.Count) or 1
	for L_501_forvar0 = 1, L_500_ do
		if not L_8_.Replaying then
			return
		end
		local L_502_ = L_104_func(L_499_)
		if not L_502_ or not L_502_.Data then
			return
		end
		local L_503_ = L_502_.Data
		local L_504_ = tonumber(L_503_.Upgrade) or 0
		local L_505_ = tonumber(L_503_.MaxUpgrade) or math.huge
		if L_504_ >= L_505_ then
			return
		end
		local L_506_ = tonumber(L_503_.NextStats and L_503_.NextStats.Cost) or math.huge
		if L_8_.Mode == "Yen" then
			while L_8_.Replaying and L_70_func() < L_506_ do
				L_8_.Status = "Waiting ¥" .. math.floor(L_506_)
                    .. " to upgrade unit " .. tostring(L_499_)
                    .. " (have " .. tostring(L_70_func()) .. ")"
				task.wait()
			end
		end
		if not L_8_.Replaying then
			return
		end
		L_8_.Status = "Upgrading unit " .. tostring(L_499_)
            .. " (" .. L_501_forvar0 .. "/" .. L_500_ .. ")"
		pcall(function()
			L_496_arg0:FireServer("UpgradeGameUnit", L_499_)
		end)

		for L_507_forvar0 = 1, 180 do
			task.wait()
			L_502_ = L_104_func(L_499_)
			L_503_ = L_502_ and L_502_.Data or nil
			local L_508_ = tonumber(L_503_ and L_503_.Upgrade) or L_504_
			if L_508_ > L_504_ or not L_8_.Replaying then
				break
			end
			if not L_105_func(L_502_) then
				break
			end
		end
	end
end

local function L_121_func(L_509_arg0)
	if L_8_.Replaying or not L_509_arg0 or type(L_509_arg0.Actions) ~= "table" then
		return
	end
	L_8_.Replaying = true
	L_8_.Status = "Starting replay"
	L_8_.StepText = "Starting replay"
	L_8_.NextText = L_44_func(L_509_arg0.Actions[1])
	L_8_.NewUnitQueue = {}
	L_8_.ReplayStart = os.clock()
	local L_510_ = {}
	local L_511_ = L_20_func("GamePlayerData")
	local L_512_ = L_20_func("HotbarData")
	local L_513_ = L_20_func("VotePrompt")
	for L_514_forvar0, L_515_forvar1 in ipairs(L_509_arg0.Actions) do
		if not L_8_.Replaying then
			break
		end
		if L_8_.Mode == "Time" then
			L_117_func(L_8_.ReplayStart + (tonumber(L_515_forvar1.T) or 0))
		end
		L_8_.StepText = L_44_func(L_515_forvar1)
		L_8_.NextText = L_44_func(L_509_arg0.Actions[L_514_forvar0 + 1])
		if L_515_forvar1.Kind == "Place" and L_511_ then
			L_119_func(L_511_, L_512_, L_515_forvar1, L_510_, L_514_forvar0)
		elseif L_515_forvar1.Kind == "Upgrade" and L_511_ then
			L_120_func(L_511_, L_515_forvar1, L_510_)
		elseif L_515_forvar1.Kind == "Sell" and L_511_ then
			local L_516_ = L_515_forvar1.Ref and L_510_[L_515_forvar1.Ref] or nil
			if L_516_ then
				L_8_.Status = "Selling unit " .. tostring(L_516_)
				pcall(function()
					L_511_:FireServer("SellGameUnit", L_516_)
				end)
			end
		elseif L_515_forvar1.Kind == "Ability" and L_511_ then
			local L_517_ = L_515_forvar1.Ref and L_510_[L_515_forvar1.Ref] or nil
			if L_517_ then
				L_8_.Status = "Ability on unit " .. tostring(L_517_)
				pcall(function()
					L_511_:FireServer(L_515_forvar1.Action, L_517_)
				end)
			end
		elseif L_515_forvar1.Kind == "Vote" and L_513_ then
			pcall(function()
				L_513_:FireServer("Response", L_515_forvar1.Value)
			end)
		end
	end
	L_8_.Replaying = false
	L_8_.Status = "Replay finished"
	L_8_.StepText = "Replay finished"
	L_8_.NextText = ""
end

L_1_.replicaFromId = L_104_func
L_1_.unitName = L_105_func
L_1_.getSlotCost = L_106_func
L_1_.getNextUpgradeCost = L_107_func
L_1_.installGameUnitTracker = L_109_func
L_1_.recordReplicaAction = L_110_func
L_1_.installRecordingHook = L_111_func
L_1_.startRecording = L_112_func
L_1_.stopRecording = L_113_func
L_1_.saveRecording = L_114_func
L_1_.loadCurrentMacro = L_115_func
L_1_.exportMacro = L_116_func
L_1_.waitWhileReplaying = L_117_func
L_1_.waitForPlacedUnit = L_118_func
L_1_.replayMacro = L_121_func

local function L_122_func()
	local L_518_ = L_6_:FindFirstChild("PlayerGui")
	if not L_518_ then
		return nil
	end
	for L_519_forvar0, L_520_forvar1 in ipairs(L_518_:GetDescendants()) do
		if L_520_forvar1:IsA("TextLabel") or L_520_forvar1:IsA("TextButton") then
			local L_521_ = string.lower(L_520_forvar1.Text or "")
			if L_521_:find("victory", 1, true)
                or L_521_:find("you win", 1, true)
                or L_521_:find("cleared", 1, true) then
				return "Victory"
			end
			if L_521_:find("defeat", 1, true)
                or L_521_:find("you los", 1, true)
                or L_521_:find("game over", 1, true) then
				return "Defeat"
			end
		end
	end
	return nil
end

local function L_123_func(L_522_arg0)
	if not L_522_arg0 then
		return nil
	end
	local L_523_ = L_122_func()
	if L_523_ then
		return L_523_
	end
	if L_40_func(L_522_arg0) then
		return "Defeat"
	end
	local L_524_ = tonumber(L_522_arg0.Wave) or 0
	local L_525_ = tonumber(L_522_arg0.MaxWave) or 0
	local L_526_ = tonumber(L_522_arg0.EnemyCount) or -1
	if L_525_ > 0
        and L_524_ >= L_525_
        and L_526_ == 0
        and tostring(L_522_arg0.Active) ~= "true" then
		return "Victory"
	end
	return nil
end

local function L_124_func()
	local L_527_ = L_20_func("VotePrompt")
	if not L_527_ then
		return false
	end
	return pcall(function()
		L_527_:FireServer("Response", true)
	end)
end

local function L_125_func()
	local L_528_ = L_20_func("PlayerGroupData")
	if L_528_ then
		return pcall(function()
			L_528_:FireServer("StartGame")
		end)
	end

	return pcall(function()
		local L_529_ = L_3_:FindFirstChild("FusionPackage")
		local L_530_ = L_529_ and L_529_:FindFirstChild("Actions")
		local L_531_ = require(L_530_)
		L_531_.PartyStartGame({
			Gamemode = L_8_.Joiner.Gamemode,
			MapName = L_8_.Joiner.Map,
			ActName = L_8_.Joiner.Act,
			Difficulty = L_8_.Joiner.Difficulty,
		})
	end)
end

local function L_126_func()
	if not L_26_func() then
		if L_8_.Recording then
			L_114_func()
		end
		L_8_.Replaying = false
		L_8_.ReplayedThisMatch = false
		L_8_.RoundStarted = false
		if L_8_.AutoJoin then
			task.wait(3)
			L_125_func()
		end
		return
	end
	local L_532_ = L_69_func()
	local L_533_ = L_123_func(L_532_)
	if L_533_ then
		if L_8_.Recording then
			L_114_func()
		end
		L_8_.Replaying = false
		return
	end
	if not L_38_func(L_532_) then
		if L_8_.AutoStart then
			L_124_func()
		end
		return
	end
	L_8_.RoundStarted = true
	if (L_8_.PlayMacro or L_8_.AutoRetry)
        and not L_8_.Replaying
        and not L_8_.ReplayedThisMatch then
		local L_534_ = L_115_func()
		if L_534_ then
			L_8_.ReplayedThisMatch = true
			task.spawn(L_121_func, L_534_)
		end
	end
end

L_1_.getExplicitOutcome = L_122_func
L_1_.getMatchOutcome = L_123_func
L_1_.startRound = L_124_func
L_1_.joinSelectedStage = L_125_func
L_1_.updateMatchAutomation = L_126_func

local function L_127_func()
	local L_535_ = L_20_func("PlayerData")
	local L_536_ = {
		Items = {},
		Level = 0,
		Exp = 0,
		Units = {},
	}
	if not L_535_ or type(L_535_.Data) ~= "table" then
		return L_536_
	end
	local L_537_ = L_535_.Data
	L_536_.Level = tonumber(L_537_.Level) or 0
	L_536_.Exp = tonumber(L_537_.Exp) or 0
	if type(L_537_.ItemData) == "table" then
		for L_538_forvar0, L_539_forvar1 in pairs(L_537_.ItemData) do
			if type(L_539_forvar1) == "table" and L_539_forvar1.Amount ~= nil then
				L_536_.Items[tostring(L_538_forvar0)] = tonumber(L_539_forvar1.Amount) or 0
			end
		end
	end
	if type(L_537_.UnitData) == "table" then
		for L_540_forvar0, L_541_forvar1 in pairs(L_537_.UnitData) do
			if type(L_541_forvar1) == "table" then
				L_536_.Units[tostring(L_540_forvar0)] = tonumber(L_541_forvar1.EXP) or 0
			end
		end
	end
	return L_536_
end

local L_128_ = {
	"Kills",
	"Takedowns",
	"TotalTakedowns"
}
local L_129_ = {
	"TotalDamage",
	"Damage",
	"DamageDealt",
	"DamageDone"
}

local function L_130_func()
	if type(L_16_) ~= "table" then
		L_18_func()
	end
	if type(L_16_) ~= "table" then
		return
	end
	for L_542_forvar0, L_543_forvar1 in pairs(L_16_) do
		if L_19_func(L_543_forvar1) == "GameUnit" then
			local L_544_ = L_543_forvar1.Data
			local L_545_ = type(L_544_) == "table" and L_544_.UnitData or nil
			if type(L_544_) == "table" then
				local L_546_ = tostring(
                    (type(L_545_) == "table" and L_545_.Asset)
                    or L_544_.Asset
                    or L_544_.Name
                    or "Unit"
                )
				local L_547_ = tostring(L_543_forvar1.Id)
				local L_548_ = L_43_func(L_544_, L_545_, L_128_)
				local L_549_ = L_43_func(L_544_, L_545_, L_129_)
				local L_550_ = tonumber(L_544_.Upgrade) or 0
				local L_551_ = L_8_.UnitDamage[L_547_]
				if not L_551_ or L_548_ >= (L_551_.Kills or 0) or L_549_ >= (L_551_.Damage or 0) then
					L_8_.UnitDamage[L_547_] = {
						Name = L_546_,
						Kills = math.max(L_548_, L_551_ and L_551_.Kills or 0),
						Damage = math.max(L_549_, L_551_ and L_551_.Damage or 0),
						Level = L_550_,
					}
				end
			end
		end
	end
end

local function L_131_func()
	local L_552_ = L_20_func("MapData")
	local L_553_ = L_552_ and L_552_.Data and L_552_.Data.Parameters
	if type(L_553_) ~= "table" then
		return "Unknown"
	end
	return tostring(L_553_.Gamemode)
        .. "|" .. tostring(L_553_.MapName)
        .. "|" .. tostring(L_553_.ActName)
        .. "|" .. tostring(L_553_.Difficulty)
end

local function L_132_func(L_554_arg0)
	local L_555_ = L_20_func("MapData")
	local L_556_ = L_20_func("GameState")
	local L_557_ = L_20_func("GamePlayerData")
	local L_558_ = L_127_func()
	local L_559_ = {
		Result = L_554_arg0,
		User = L_36_func(L_6_.Name),
		Level = L_558_.Level,
		MatchCount = L_8_.StageCounts[L_131_func()] or 0,
		Items = L_558_.Items,
		Gained = {},
	}
	pcall(function()
		local L_562_ = L_555_.Data.Parameters
		L_559_.Gamemode = tostring(L_562_.Gamemode)
		L_559_.Map = tostring(L_562_.MapName)
		L_559_.Act = tostring(L_562_.ActName)
		L_559_.Difficulty = tostring(L_562_.Difficulty)
	end)
	pcall(function()
		local L_563_ = L_556_.Data
		L_559_.Duration = L_563_.GameTime or L_563_.SessionTime
		L_559_.Wave = L_563_.Wave
		L_559_.MaxWave = L_563_.MaxWave
	end)
	pcall(function()
		local L_564_ = L_557_.Data
		L_559_.Kills = L_564_.TotalKills
		L_559_.Damage = L_564_.TotalDamage
		L_559_.Takedowns = L_564_.TotalTakedowns
	end)
	local L_560_ = L_8_.Snapshot
	if L_560_ then
		for L_566_forvar0, L_567_forvar1 in pairs(L_558_.Items) do
			local L_568_ = L_560_.Items[L_566_forvar0]
			if L_568_ == nil then
				L_568_ = L_567_forvar1
			end
			local L_569_ = L_567_forvar1 - L_568_
			if L_569_ > 0 then
				L_559_.Gained[L_566_forvar0] = {
					Delta = L_569_,
					Total = L_567_forvar1,
				}
			end
		end
		L_559_.ExpGained = L_558_.Exp - L_560_.Exp
		local L_565_ = 0
		for L_570_forvar0, L_571_forvar1 in pairs(L_558_.Units) do
			local L_572_ = L_560_.Units[L_570_forvar0]
			if L_572_ == nil then
				L_572_ = L_571_forvar1
			end
			unitExpGained += math.max(0, L_571_forvar1 - L_572_)
		end
		L_559_.UnitExpGained = L_565_
	end
	local L_561_ = {}
	for L_573_forvar0, L_574_forvar1 in pairs(L_8_.UnitDamage) do
		table.insert(L_561_, L_574_forvar1)
	end
	table.sort(L_561_, function(L_575_arg0, L_576_arg1)
		return (L_575_arg0.Kills or 0) > (L_576_arg1.Kills or 0)
	end)
	L_559_.Units = L_561_
	return L_559_
end

L_13_ = function()
	if not L_8_.WebhookEnabled then
		return
	end
	if not L_26_func() then
		L_8_.ResultSent = false
		L_8_.MatchActive = false
		L_8_.Snapshot = nil
		L_8_.UnitDamage = {}
		return
	end
	local L_577_ = L_69_func()
	if not L_8_.MatchActive and L_39_func(L_577_) then
		L_8_.MatchActive = true
		L_8_.RoundStarted = true
		L_8_.Snapshot = L_127_func()
		L_8_.UnitDamage = {}
	end
	if L_8_.MatchActive then
		L_130_func()
	end
	if L_8_.RoundStarted then
		local L_578_ = L_123_func(L_577_)
		if L_578_ and not L_8_.ResultSent then
			L_8_.ResultSent = true
			local L_579_ = L_131_func()
			L_8_.StageCounts[L_579_] = (L_8_.StageCounts[L_579_] or 0) + 1
			L_46_func()
			if L_12_ then
				L_12_(L_132_func(L_578_))
			end
		end
	end
end

L_1_.capturePlayerSnapshot = L_127_func
L_1_.updateUnitDamage = L_130_func
L_1_.getStageKey = L_131_func
L_1_.buildMatchResult = L_132_func
L_1_.updateMatchResult = function()
	return L_13_()
end

local L_133_ = tick()
local L_134_ = tick()

local function L_135_func()
	L_133_ = tick()
end

local function L_136_func()
	local L_580_ = workspace.CurrentCamera
	if not L_580_ then
		return
	end
	L_5_:Button2Down(Vector2.new(0, 0), L_580_.CFrame)
	task.wait(0.1)
	L_5_:Button2Up(Vector2.new(0, 0), L_580_.CFrame)
	L_134_ = tick()
end

local function L_137_func(L_581_arg0, L_582_arg1)
	while not L_581_arg0.Unloaded do
		task.wait(2)
		if L_582_arg1.Value then
			local L_583_ = tick() - L_133_
			local L_584_ = tick() - L_134_
			if L_583_ >= 300 or L_584_ >= 300 then
				pcall(L_136_func)
			end
		end
	end
end

L_1_.markInputActivity = L_135_func
L_1_.simulateRightClick = L_136_func
L_1_.antiAfkLoop = L_137_func

local L_138_ = false

local function L_139_func(L_585_arg0, L_586_arg1)
	if not L_585_arg0 then
		return
	end
	if type(L_585_arg0.Set) == "function" then
		L_585_arg0:Set(L_586_arg1)
	elseif L_585_arg0.Text ~= nil then
		L_585_arg0.Text = L_586_arg1
	end
end

local function L_140_func(L_587_arg0)
	if not L_587_arg0 then
		return
	end
	if L_8_.Recording then
		local L_589_ = L_8_.StepText
		if not L_589_ or L_589_ == "" then
			L_589_ = "Waiting for an action..."
		end
		local L_590_ = L_8_.Current and L_8_.Current.Actions and #L_8_.Current.Actions or 0
		L_139_func(L_587_arg0.StepLabel, L_589_ .. "\nRecording - " .. tostring(L_590_) .. " actions")
	elseif L_8_.Replaying then
		local L_591_ = (L_8_.StepText and L_8_.StepText ~= "") and L_8_.StepText or "--"
		local L_592_ = (L_8_.NextText and L_8_.NextText ~= "") and L_8_.NextText or "--"
		L_139_func(L_587_arg0.StepLabel, "Current Step: " .. L_591_ .. "\nNext Step: " .. L_592_)
	else
		L_139_func(L_587_arg0.StepLabel, "Step: Idle")
	end
	L_139_func(L_587_arg0.YenLabel, "Yen: " .. tostring(L_70_func()))
	local L_588_ = L_69_func()
	if L_588_ then
		L_139_func(
            L_587_arg0.WaveLabel,
            "Wave: " .. tostring(L_588_.Wave)
                .. " / " .. tostring(L_588_.MaxWave)
                .. " | State: " .. tostring(L_588_.CurrentGameState)
        )
	else
		L_139_func(L_587_arg0.WaveLabel, "Wave: (lobby) | State: lobby")
	end
end

local function L_141_func(L_593_arg0)
	while L_138_ do
		if L_593_arg0 and L_593_arg0.Window and L_593_arg0.Window.Unloaded then
			return
		end
		pcall(L_140_func, L_593_arg0)
		task.wait(1)
	end
end

L_1_.updateHud = L_140_func
L_1_.hudUpdateLoop = L_141_func

local function L_142_func()
	while L_138_ do
		pcall(L_85_func)
		pcall(L_102_func)
		task.wait(20)
	end
end

local function L_143_func()
	L_138_ = true
	while L_138_ do
		pcall(L_126_func)
		pcall(L_13_)
		pcall(L_92_func)
		pcall(L_93_func)
		task.wait(2)
	end
end

local function L_144_func()
	L_138_ = false
end

L_1_.periodicRefreshLoop = L_142_func
L_1_.runtimeUpdateLoop = L_143_func
L_1_.stopRuntime = L_144_func

local function L_145_func()
	if syn and syn.request then
		return syn.request
	end
	if http_request then
		return http_request
	end
	if request then
		return request
	end
	if http and http.request then
		return http.request
	end
	return nil
end

local function L_146_func(L_594_arg0)
	local L_595_ = L_145_func()
	if not L_595_ or L_8_.WebhookUrl == "" then
		return false
	end
	local L_596_ = pcall(L_595_, {
		Url = L_8_.WebhookUrl,
		Method = "POST",
		Headers = {
			["Content-Type"] = "application/json",
		},
		Body = L_4_:JSONEncode(L_594_arg0),
	})
	return L_596_
end

L_11_ = function(L_597_arg0, L_598_arg1)
	if not L_145_func() or L_8_.WebhookUrl == "" then
		return false
	end
	local L_599_ = L_76_[L_597_arg0] or {}
	local L_600_ = L_599_.Display or L_597_arg0
	local L_601_ = L_599_.Rarity or (type(L_598_arg1) == "table" and L_598_arg1.Rarity) or "?"
	return L_146_func({
		username = "IndraHub | Anime Expedition",
		content = L_37_func(L_8_.SummonPing),
		embeds = {
			{
				title = "Summon hit!",
				description = "**[USER]** " .. L_36_func(L_6_.Name)
                    .. "\n**[UNIT]** " .. tostring(L_600_) .. " (" .. tostring(L_597_arg0) .. ")"
                    .. "\n**[RARITY]** " .. tostring(L_601_)
                    .. "\n**[BANNER]** " .. tostring(L_8_.SummonBanner or "?"),
				color = 16766720,
				footer = {
					text = tostring(os.time()),
				},
			},
		},
	})
end

L_12_ = function(L_602_arg0)
	if not L_145_func() or L_8_.WebhookUrl == "" then
		return false
	end
	local L_603_ = L_602_arg0.Result == "Victory"
	local L_604_ = L_603_ and 5763719 or 15548997
	local L_605_ = {}
	for L_609_forvar0, L_610_forvar1 in pairs(L_8_.WebhookItems) do
		table.insert(
            L_605_,
            "**" .. L_75_func(L_610_forvar1) .. ":** "
                .. L_34_func((L_602_arg0.Items and L_602_arg0.Items[L_610_forvar1]) or 0)
        )
	end
	if #L_605_ == 0 then
		L_605_ = {
			"—"
		}
	end
	local L_606_ = {}
	for L_611_forvar0, L_612_forvar1 in pairs(L_602_arg0.Gained or {}) do
		table.insert(
            L_606_,
            "+" .. L_34_func(L_612_forvar1.Delta) .. " " .. tostring(L_611_forvar0)
                .. " [ Total: " .. L_34_func(L_612_forvar1.Total) .. " ]"
        )
	end
	if (L_602_arg0.ExpGained or 0) > 0 then
		table.insert(
            L_606_,
            "+" .. L_34_func(L_602_arg0.ExpGained)
                .. " EXP [ Level " .. tostring(L_602_arg0.Level) .. " ]"
        )
	end
	if (L_602_arg0.UnitExpGained or 0) > 0 then
		table.insert(L_606_, "+" .. L_34_func(L_602_arg0.UnitExpGained) .. " Unit EXP")
	end
	if #L_606_ == 0 then
		L_606_ = {
			"—"
		}
	end
	local L_607_ = {}
	for L_613_forvar0, L_614_forvar1 in pairs(L_602_arg0.Units or {}) do
		table.insert(
            L_607_,
            "[" .. tostring(L_614_forvar1.Level) .. "] **[" .. tostring(L_614_forvar1.Name) .. "]**"
        )
		if #L_607_ >= 12 then
			break
		end
	end
	if #L_607_ == 0 then
		L_607_ = {
			"—"
		}
	end
	local L_608_ = L_33_func(L_602_arg0.Duration)
        .. " - Wave " .. tostring(L_602_arg0.Wave)
        .. "\n**[" .. tostring(L_602_arg0.Gamemode or "?") .. "]**"
        .. " **[" .. tostring(L_602_arg0.Difficulty or "?") .. "]** - "
        .. tostring(L_602_arg0.Map or "?") .. ": " .. tostring(L_602_arg0.Act or "?")
        .. " - **[" .. (L_603_ and "VICTORY" or "DEFEAT") .. "]**"
	return L_146_func({
		username = "IndraHub | Anime Expedition",
		content = L_37_func(L_8_.GameDropPing),
		embeds = {
			{
				title = "IndraHub | Anime Expedition",
				description = "**<**\n**[USER]** " .. tostring(L_602_arg0.User)
                    .. "\n**[LEVEL]** " .. tostring(L_602_arg0.Level),
				color = L_604_,
				fields = {
					{
						name = "Player stats",
						value = table.concat(L_605_, "\n"),
						inline = true,
					},
					{
						name = "Rewards",
						value = table.concat(L_606_, "\n"),
						inline = true,
					},
					{
						name = "Units",
						value = table.concat(L_607_, "\n"),
						inline = false,
					},
					{
						name = "Match results",
						value = L_608_,
						inline = false,
					},
				},
				footer = {
					text = tostring(os.time()),
				},
			},
		},
	})
end

local function L_147_func()
	return L_146_func({
		username = "IndraHub | Anime Expedition",
		embeds = {
			{
				title = "Webhook Test",
				description = "Webhook is working.",
				color = 5763719,
				footer = {
					text = tostring(os.time())
				},
			},
		},
	})
end

L_1_.resolveRequestFunction = L_145_func
L_1_.sendWebhook = L_146_func
L_1_.sendSummonWebhook = function(...)
	return L_11_(...)
end
L_1_.sendMatchWebhook = function(...)
	return L_12_(...)
end
L_1_.testWebhook = L_147_func

local function L_148_func(L_615_arg0, L_616_arg1)
	for L_617_forvar0, L_618_forvar1 in ipairs(L_615_arg0) do
		if L_618_forvar1 == L_616_arg1 then
			return false
		end
	end
	table.insert(L_615_arg0, L_616_arg1)
	return true
end

local function L_149_func(L_619_arg0)
	if L_148_func(L_8_.SummonTargets, L_619_arg0) then
		L_46_func()
		L_89_func("Added unit to summon targets.", 3)
		return true
	end
	L_89_func("Unit is already in summon targets.", 3)
	return false
end

local function L_150_func()
	L_8_.SummonTargets = {}
	L_46_func()
	L_89_func("Cleared all summon targets.", 3)
end

local function L_151_func()
	local L_620_ = {}
	local L_621_ = {}
	for L_622_forvar0, L_623_forvar1 in ipairs(L_77_func()) do
		local L_624_ = L_76_[L_623_forvar1] or {}
		local L_625_ = tostring(L_623_forvar1)
            .. " - " .. tostring(L_624_.Display or L_623_forvar1)
            .. " [" .. tostring(L_624_.Rarity or "?") .. "]"
		table.insert(L_620_, L_625_)
		L_621_[L_625_] = L_623_forvar1
	end
	return L_620_, L_621_
end

local function L_152_func()
	local L_626_, L_627_ = L_101_func("GoldShop", "GoldShop1")
	local L_628_ = {}
	local L_629_ = {}
	local L_630_ = {}
	for L_631_forvar0, L_632_forvar1 in ipairs(L_627_) do
		table.insert(L_628_, L_632_forvar1.Label)
		L_629_[L_632_forvar1.Label] = L_632_forvar1.Name
		L_630_[L_632_forvar1.Name] = L_632_forvar1.Label
	end
	return L_628_, L_629_, L_630_
end

local function L_153_func(L_633_arg0)
	if L_148_func(L_8_.MerchantItems, L_633_arg0) then
		L_46_func()
		L_89_func("Added item to merchant list.", 3)
		return true
	end
	L_89_func("Item is already in merchant list.", 3)
	return false
end

local function L_154_func()
	L_8_.MerchantItems = {}
	L_46_func()
	L_89_func("Cleared merchant auto-buy list.", 3)
end

local function L_155_func(L_634_arg0)
	if L_148_func(L_8_.WebhookItems, L_634_arg0) then
		table.sort(L_8_.WebhookItems)
		L_46_func()
		L_89_func("Added item to tracking list.", 3)
		return true
	end
	return false
end

local function L_156_func()
	L_8_.WebhookItems = {}
	L_46_func()
	L_89_func("Cleared tracked items list.", 3)
end

L_1_.addSummonTarget = L_149_func
L_1_.clearSummonTargets = L_150_func
L_1_.buildSummonTargetOptions = L_151_func
L_1_.buildMerchantItemOptions = L_152_func
L_1_.addMerchantItem = L_153_func
L_1_.clearMerchantItems = L_154_func
L_1_.addWebhookItem = L_155_func
L_1_.clearWebhookItems = L_156_func

local function L_157_func(L_635_arg0)
	local L_636_ = L_635_arg0("Anime Expeditions", "Anime Expeditions Features")
	local L_637_ = L_636_:NewSection("Macros")
	L_637_:NewInput(
        "Macro Name",
        "Name of macro to record/save",
        L_8_.MacroName or "",
        L_1_.Callbacks.on_MacroName
    )
	L_637_:NewToggle(
        "Record Macro",
        "Record your actions",
        false,
        function(L_659_arg0)
		if L_659_arg0 then
			L_112_func()
		else
			local L_660_, L_661_ = L_114_func()
			if L_660_ then
				L_89_func("Saved " .. L_660_ .. " (" .. tostring(L_661_) .. " actions)", 4)
			end
		end
	end
    )
	L_637_:NewDropdown(
        "Selected Macro",
        "Macro to play",
        (#L_79_func() > 0 and L_79_func()) or {
		"Default"
	},
        L_1_.Callbacks.on_SelectedMacro
    )
	L_637_:NewDropdown(
        "Replay Mode",
        "Replay coordinate mode",
        {
		"Yen",
		"Time"
	},
        L_1_.Callbacks.on_Mode
    )
	L_637_:NewToggle(
        "Play Macro",
        "Starts playing selected macro",
        L_8_.PlayMacro,
        function(L_662_arg0)
		L_8_.PlayMacro = not not L_662_arg0
		L_46_func()
		if L_662_arg0 and not L_26_func() then
			L_89_func("Macro will start when the round becomes active.", 4)
		end
	end
    )
	L_637_:NewButton(
        "Copy Macro to Clipboard",
        "Copy current macro json",
        function()
		return L_116_func(L_8_.SelectedMacro)
	end
    )
	local L_638_ = L_637_:NewLabel("Step: Idle")
	local L_639_ = L_637_:NewLabel("Yen: --")
	local L_640_ = L_637_:NewLabel("Wave: -- | State: --")
	local L_641_ = L_636_:NewSection("Stage Joiner")
	local L_642_
	local L_643_
	local L_644_
	local function L_645_func()
		local L_663_ = L_63_func(L_8_.Joiner.Gamemode, L_8_.Joiner.Map)
		local L_664_ = L_64_func(L_8_.Joiner.Gamemode, L_8_.Joiner.Map)
		if L_643_ then
			pcall(function()
				L_643_:Refresh(L_663_)
			end)
		end
		if L_644_ then
			pcall(function()
				L_644_:Refresh(L_664_)
			end)
		end
		if table.find(L_663_, L_8_.Joiner.Act) == nil then
			L_8_.Joiner.Act = L_663_[1]
		end
		if table.find(L_664_, L_8_.Joiner.Difficulty) == nil then
			local L_665_ = tonumber(L_8_.Joiner.Difficulty)
			L_8_.Joiner.Difficulty = (L_665_ and L_664_[L_665_]) or L_664_[1]
		end
		if L_643_ then
			pcall(function()
				L_643_:SetValue(L_8_.Joiner.Act)
			end)
		end
		if L_644_ then
			pcall(function()
				L_644_:SetValue(L_8_.Joiner.Difficulty)
			end)
		end
		L_46_func()
	end
	local function L_646_func()
		local L_666_ = L_62_func(L_8_.Joiner.Gamemode)
		if L_642_ then
			pcall(function()
				L_642_:Refresh(L_666_)
			end)
		end
		if table.find(L_666_, L_8_.Joiner.Map) == nil then
			L_8_.Joiner.Map = L_666_[1]
		end
		if L_642_ then
			pcall(function()
				L_642_:SetValue(L_8_.Joiner.Map)
			end)
		end
		L_645_func()
	end
	L_641_:NewDropdown(
        "Gamemode",
        "Select Gamemode",
        L_61_func(),
        function(L_667_arg0)
		L_1_.Callbacks.on_JoinGamemode(L_667_arg0)
		L_646_func()
	end
    )
	L_642_ = L_641_:NewDropdown(
        "Map",
        "Select Map",
        L_62_func(L_8_.Joiner.Gamemode),
        function(L_668_arg0)
		L_1_.Callbacks.on_JoinMap(L_668_arg0)
		L_645_func()
	end
    )
	L_643_ = L_641_:NewDropdown(
        "Act",
        "Select Act",
        L_63_func(L_8_.Joiner.Gamemode, L_8_.Joiner.Map),
        L_1_.Callbacks.on_JoinAct
    )
	L_644_ = L_641_:NewDropdown(
        "Difficulty",
        "Select Difficulty",
        L_64_func(L_8_.Joiner.Gamemode, L_8_.Joiner.Map),
        L_1_.Callbacks.on_JoinDifficulty
    )
	L_641_:NewToggle("Auto Retry", "Auto retry on defeat/victory", L_8_.AutoRetry, L_1_.Callbacks.on_AutoRetry)
	L_641_:NewToggle("Auto Start Round", "Auto start round inside stage", L_8_.AutoStart, L_1_.Callbacks.on_AutoStart)
	L_641_:NewToggle("Auto Join Stage", "Auto join selected stage from lobby", L_8_.AutoJoin, L_1_.Callbacks.on_AutoJoin)
	local L_647_ = L_636_:NewSection("Lobby Features")
	L_647_:NewToggle("Auto Claim Quests", "Automatically claim quest rewards", L_8_.AutoClaimQuests, L_1_.Callbacks.on_AutoClaimQuests)
	L_647_:NewToggle("Auto Claim Events", "Automatically claim event rewards", L_8_.AutoClaimEvents, L_1_.Callbacks.on_AutoClaimEvents)
	L_647_:NewToggle("Auto Claim Index", "Automatically claim index rewards", L_8_.AutoClaimIndex, L_1_.Callbacks.on_AutoClaimIndex)
	L_647_:NewToggle("Auto Claim Milestones", "Automatically claim level milestones", L_8_.AutoClaimMilestones, L_1_.Callbacks.on_AutoClaimMilestones)
	L_647_:NewToggle("Auto Claim Group", "Automatically claim group rewards", L_8_.AutoClaimGroup, L_1_.Callbacks.on_AutoClaimGroup)
	L_647_:NewToggle("Auto Claim Battlepass", "Automatically claim battlepass rewards", L_8_.AutoClaimBattlepass, L_1_.Callbacks.on_AutoClaimBattlepass)
	L_647_:NewToggle("Auto Claim Codes", "Automatically claim working codes", L_8_.AutoClaimCodes, L_1_.Callbacks.on_AutoClaimCodes)
	local L_648_ = L_647_:NewToggle("Auto Sell", "Automatically sell units of selected rarities", L_8_.AutoSellEnabled, function(L_669_arg0)
		L_98_func(L_669_arg0)
	end)
	for L_670_forvar0, L_671_forvar1 in ipairs({
		"Common",
		"Uncommon",
		"Rare",
		"Epic",
		"Legendary",
		"Mythic"
	}) do
		L_647_:NewToggle(
            "Sell Rarity: " .. L_671_forvar1,
            "Auto sell " .. L_671_forvar1 .. " units",
            table.find(L_8_.AutoSellRarities, L_671_forvar1) ~= nil,
            function(L_672_arg0)
			local L_673_ = {}
			for L_675_forvar0, L_676_forvar1 in ipairs(L_8_.AutoSellRarities) do
				L_673_[L_676_forvar1] = true
			end
			L_673_[L_671_forvar1] = L_672_arg0 or nil
			local L_674_ = {}
			for L_677_forvar0 in pairs(L_673_) do
				table.insert(L_674_, L_677_forvar0)
			end
			table.sort(L_674_)
			L_99_func(L_674_)
		end
        )
	end
	local L_649_ = L_636_:NewSection("Summoning")
	L_649_:NewDropdown("Summon Banner", "Select Summon Banner", L_78_func(), L_1_.Callbacks.on_SummonBanner)
	L_649_:NewSlider("Units per Summon", "Amount to summon at once", 50, 1, L_8_.SummonAmount, L_1_.Callbacks.on_SummonAmount)
	L_649_:NewToggle("Auto Summon", "Keep summoning automatically", L_8_.AutoSummon, L_1_.Callbacks.on_AutoSummon)
	local L_650_, L_651_ = L_151_func()
	L_649_:NewDropdown(
        "Add Summon Target",
        "Select unit to add to targets",
        (#L_650_ > 0 and L_650_) or {
		"None"
	},
        function(L_678_arg0)
		local L_679_ = L_651_[L_678_arg0]
		if L_679_ then
			L_149_func(L_679_)
		end
	end
    )
	L_649_:NewButton("Clear Summon Targets", "Remove all targets", L_150_func)
	local L_652_ = L_649_:NewToggle(
        "Summon Until Target",
        "Stop summoning when target is hit",
        L_8_.SummonUntilUnit,
        L_1_.Callbacks.on_SummonUntilUnit
    )
	L_649_:NewToggle("Auto Buy Merchant", "Automatically buy selected merchant items", L_8_.AutoBuyMerchant, L_1_.Callbacks.on_AutoBuyMerchant)
	local L_653_, L_654_ = L_152_func()
	L_649_:NewDropdown(
        "Add Merchant Item",
        "Add item to auto-buy list",
        (#L_653_ > 0 and L_653_) or {
		"None"
	},
        function(L_680_arg0)
		local L_681_ = L_654_[L_680_arg0]
		if L_681_ then
			L_153_func(L_681_)
		end
	end
    )
	L_649_:NewButton("Clear Merchant Items", "Remove all items from auto-buy list", L_154_func)
	local L_655_ = L_636_:NewSection("Webhooks")
	L_655_:NewInput("Webhook URL", "Discord Webhook URL", L_8_.WebhookUrl or "", L_1_.Callbacks.on_WebhookUrl)
	L_655_:NewToggle("Enable Webhook", "Send results & summons to Discord", L_8_.WebhookEnabled, L_1_.Callbacks.on_WebhookEnabled)
	local L_656_, L_657_ = L_42_func(L_71_)
	L_655_:NewDropdown(
        "Add Tracked Item",
        "Select item to track in webhook",
        (#L_656_ > 0 and L_656_) or {
		"None"
	},
        function(L_682_arg0)
		local L_683_ = L_657_[L_682_arg0]
		if L_683_ then
			L_155_func(L_683_)
		end
	end
    )
	L_655_:NewButton("Clear Tracked Items", "Remove all items from tracking list", L_156_func)
	L_655_:NewInput("Discord ID", "Ping this Discord ID", L_8_.DiscordId or "", L_1_.Callbacks.on_DiscordId)
	L_655_:NewToggle("Ping Summon", "Ping on summon hit", L_8_.SummonPing, L_1_.Callbacks.on_SummonPing)
	L_655_:NewToggle("Ping Match Result", "Ping on match completion", L_8_.GameDropPing, L_1_.Callbacks.on_GameDropPing)
	L_655_:NewButton("Test Webhook", "Send a test embed", L_147_func)
	local L_658_ = L_636_:NewSection("Settings")
	L_658_:NewButton("Save Settings", "Saves your configuration", L_46_func)
	return {
		Window = L_636_,
		StepLabel = L_638_,
		YenLabel = L_639_,
		WaveLabel = L_640_,
		AutoSellToggle = L_648_,
		SummonUntilToggle = L_652_,
	}
end

L_1_.buildUI = L_157_func

function L_1_.start(L_684_arg0)
	L_684_arg0 = L_684_arg0 or {}
	L_9_ = L_684_arg0
	L_28_func()
	L_47_func()
	L_74_func()
	L_77_func()
	L_17_func()
	L_18_func()
	L_24_func()
	pcall(L_109_func)
	pcall(L_111_func)
	L_138_ = true
	task.spawn(L_143_func)
	task.spawn(L_142_func)
	local L_685_ = L_684_arg0.createWindow
	assert(type(L_685_) == "function", "Snowy.start requires runtime.createWindow")
	local L_686_ = L_157_func(L_685_)
	L_10_ = L_686_
	task.spawn(L_141_func, L_686_)
	if L_684_arg0.afterUiLoaded then
		pcall(L_684_arg0.afterUiLoaded)
	end
	return L_686_
end

return L_1_
