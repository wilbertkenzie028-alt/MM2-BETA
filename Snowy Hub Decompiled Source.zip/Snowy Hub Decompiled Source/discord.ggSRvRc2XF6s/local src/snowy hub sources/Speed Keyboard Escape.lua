local L_1_ = {}

L_1_.entry = function(...)
	local L_2_, L_3_
	return L_1_.main(...)
end

L_1_.premiumTag = function(L_4_arg0)
	local L_5_, L_6_
	return tostring(L_4_arg0)
end

L_1_.isPremiumUser = function()
	local L_7_
	return true
end

L_1_.createCorner = function(L_8_arg0, L_9_arg1)
	local L_10_, L_11_, L_12_, L_13_, L_14_, L_15_, L_16_, L_17_
	L_10_ = typeof(L_9_arg1)
	L_11_ = L_9_arg1
	L_16_ = "Instance"
	L_17_ = (typeof(L_9_arg1) == "Instance")
	if not (L_17_) then
		return nil
	end
	L_10_ = Instance.new("UICorner")
	L_11_ = UDim.new
	L_12_ = 0
	L_13_ = tonumber(L_8_arg0)
	L_14_ = tonumber(L_8_arg0)
	L_15_ = L_8_arg0
	if L_13_ then
		L_10_.CornerRadius = L_11_(L_12_, L_13_)
		L_10_.Parent = L_9_arg1
		return L_10_
	end
	L_13_ = 8
	L_10_.CornerRadius = L_11_(L_12_, L_13_)
	L_10_.Parent = L_9_arg1
	return L_10_
end

L_1_.createStroke = function(L_18_arg0, L_19_arg1, L_20_arg2)
	local L_21_, L_22_, L_23_, L_24_, L_25_, L_26_, L_27_
	L_21_ = typeof(L_20_arg2)
	L_22_ = L_20_arg2
	L_26_ = "Instance"
	L_27_ = (typeof(L_20_arg2) == "Instance")
	if not (L_27_) then
		return nil
	end
	L_21_ = Instance.new("UIStroke")
	L_22_ = L_18_arg0
	if not (L_22_) then
		L_22_ = Color3.fromRGB(85, 213, 254)
		L_23_ = 85
		L_24_ = 213
		L_25_ = 254
	end
	L_21_.Color = L_22_
	L_22_ = tonumber(L_19_arg1)
	L_23_ = tonumber(L_19_arg1)
	L_24_ = L_19_arg1
	if L_22_ then
		L_21_.Thickness = L_22_
		L_21_.Parent = L_20_arg2
		return L_21_
	end
	L_22_ = 1
	L_21_.Thickness = L_22_
	L_21_.Parent = L_20_arg2
	return L_21_
end

L_1_.createGradient = function(L_28_arg0, L_29_arg1, L_30_arg2, L_31_arg3)
	local L_32_, L_33_, L_34_, L_35_, L_36_, L_37_, L_38_, L_39_, L_40_
	L_32_ = typeof(L_28_arg0)
	L_33_ = L_28_arg0
	L_39_ = "Instance"
	L_40_ = (typeof(L_28_arg0) == "Instance")
	if not (L_40_) then
		return nil
	end
	L_32_ = Instance.new("UIGradient")
	L_33_ = ColorSequence.new
	L_34_ = L_29_arg1
	if not (L_34_) then
		L_34_ = Color3.fromRGB(18, 24, 64)
		L_35_ = 18
		L_36_ = 24
		L_37_ = 64
	end
	L_35_ = L_30_arg2
	if not (L_35_) then
		L_35_ = L_29_arg1
		if not (L_35_) then
			L_35_ = Color3.fromRGB(24, 32, 85)
			L_36_ = 24
			L_37_ = 32
			L_38_ = 85
		end
	end
	L_32_.Color = L_33_(L_34_, L_35_)
	L_33_ = tonumber(L_31_arg3)
	L_34_ = tonumber(L_31_arg3)
	L_35_ = L_31_arg3
	if L_33_ then
		L_32_.Rotation = L_33_
		L_32_.Parent = L_28_arg0
		return L_32_
	end
	L_33_ = 0
	L_32_.Rotation = L_33_
	L_32_.Parent = L_28_arg0
	return L_32_
end

L_1_.createShadow = function(L_41_arg0)
	local L_42_, L_43_, L_44_, L_45_, L_46_, L_47_, L_48_, L_49_
	L_42_ = typeof(L_41_arg0)
	L_43_ = L_41_arg0
	L_48_ = "Instance"
	L_49_ = (typeof(L_41_arg0) == "Instance")
	if L_49_ then
		L_42_ = Instance.new("ImageLabel")
		L_42_.Name = "SnowyShadow"
		L_42_.BackgroundTransparency = 1
		L_42_.Position = UDim2.new(0, -18, 0, -18)
		L_42_.Size = UDim2.new(1, 36, 1, 36)
		L_42_.Image = "rbxassetid://6015897843"
		L_42_.ImageColor3 = Color3.new(0, 0, 0)
		L_42_.ImageTransparency = 0.42
		L_42_.ScaleType = Enum.ScaleType.Slice
		L_42_.SliceCenter = Rect.new(49, 49, 450, 450)
		L_42_.ZIndex = 0
		L_42_.Parent = L_41_arg0
		return L_42_
	else
		return nil
	end
end

L_1_.tween = function(L_50_arg0, L_51_arg1, L_52_arg2, L_53_arg3, L_54_arg4)
	local L_55_, L_56_, L_57_, L_58_, L_59_, L_60_, L_61_, L_62_, L_63_
	L_55_ = typeof(L_50_arg0)
	L_56_ = L_50_arg0
	L_62_ = "Instance"
	L_63_ = (typeof(L_50_arg0) == "Instance")
	if not (L_63_) then
		return nil
	end
	L_55_ = type(L_51_arg1)
	L_56_ = L_51_arg1
	L_62_ = "table"
	L_63_ = (type(L_51_arg1) == "table")
	if not (L_63_) then
		return nil
	end
	L_55_ = game:GetService("TweenService")
	L_56_ = game
	L_57_ = L_50_arg0
	L_58_ = TweenInfo.new
	L_59_ = tonumber(L_52_arg2)
	L_60_ = tonumber(L_52_arg2)
	L_61_ = L_52_arg2
	if not (L_59_) then
		L_59_ = 0.2
	end
	L_60_ = L_53_arg3
	if not (L_60_) then
		L_60_ = Enum.EasingStyle.Quad
	end
	L_61_ = L_54_arg4
	if L_61_ then
		L_55_ = L_55_:Create(L_57_, L_58_(L_59_, L_60_, L_61_), L_51_arg1)
		L_55_:Play()
		return L_55_
	end
	L_61_ = Enum.EasingDirection.Out
	L_55_ = L_55_:Create(L_57_, L_58_(L_59_, L_60_, L_61_), L_51_arg1)
	L_55_:Play()
	return L_55_
end

L_1_._nagPremium = function()
	local L_64_
	return
end

L_1_.callback_9 = function()
	local L_65_, L_66_, L_67_
	return _G[upvalue_0]
end

L_1_.callback_10 = function()
	local L_68_, L_69_, L_70_
	return getgenv()[upvalue_0]
end

L_1_.callback_11 = function(L_71_arg0)
	local L_72_, L_73_, L_74_, L_75_, L_76_, L_77_, L_78_
	L_72_ = pcall
	L_73_ = L_1_.callback_9
	L_72_, L_73_ = pcall(L_1_.callback_9)
	if L_72_ then
		if L_73_ then
			return L_73_
		end
		L_74_ = pcall
		L_75_ = L_1_.callback_10
		L_74_, L_75_ = pcall(L_1_.callback_10)
		if L_74_ then
			if L_75_ then
				return L_75_
			end
			L_77_ = _ENV
			if L_77_ then
				return rawget(L_77_, L_71_arg0)
			end
			L_77_ = _G
			return rawget(L_77_, L_71_arg0)
		else
			L_77_ = _ENV
			if L_77_ then
				return rawget(L_77_, L_71_arg0)
			end
			L_77_ = _G
			return rawget(L_77_, L_71_arg0)
		end
	else
		L_74_ = pcall
		L_75_ = L_1_.callback_10
		L_74_, L_75_ = pcall(L_1_.callback_10)
		if L_74_ then
			if L_75_ then
				return L_75_
			end
			L_77_ = _ENV
			if L_77_ then
				return rawget(L_77_, L_71_arg0)
			end
			L_77_ = _G
			return rawget(L_77_, L_71_arg0)
		else
			L_77_ = _ENV
			if L_77_ then
				return rawget(L_77_, L_71_arg0)
			end
			L_77_ = _G
			return rawget(L_77_, L_71_arg0)
		end
	end
end

L_1_.callback_12 = function()
	local L_79_, L_80_, L_81_
	L_79_ = getgenv()
	L_79_[upvalue_0] = upvalue_1
	return
end

L_1_.callback_13 = function(L_82_arg0, L_83_arg1)
	local L_84_, L_85_
	pcall(L_1_.callback_12)
	return
end

L_1_.callback_14 = function()
	local L_86_, L_87_, L_88_
	L_86_ = getgenv()
	L_87_ = getgenv().__realGetRawMT
	L_88_ = getgenv()
	if not (L_87_) then
		L_87_ = upvalue_0("getrawmetatable")
		L_88_ = "getrawmetatable"
	end
	L_86_.__realGetRawMT = L_87_
	L_86_ = getgenv()
	L_87_ = getgenv().__realHookNamecall
	L_88_ = getgenv()
	if not (L_87_) then
		L_87_ = upvalue_0("hookmetamethod")
		L_88_ = "hookmetamethod"
	end
	L_86_.__realHookNamecall = L_87_
	L_86_ = getgenv()
	L_87_ = getgenv().__realNewCClosure
	L_88_ = getgenv()
	if L_87_ then
		L_86_.__realNewCClosure = L_87_
		return
	end
	L_87_ = upvalue_0("newcclosure")
	L_88_ = "newcclosure"
	L_86_.__realNewCClosure = L_87_
	return
end

L_1_.callback_15 = function()
	local L_89_
	return
end

L_1_.__index = function()
	local L_90_
	return L_1_.callback_15
end

L_1_.__newindex = function()
	local L_91_
	return
end

L_1_.callback_18 = function(L_92_arg0)
	local L_93_, L_94_, L_95_, L_96_
	L_95_ = {}
	L_95_.__index = L_1_.__index
	L_95_.__newindex = L_1_.__newindex
	return setmetatable({}, L_95_)
end

L_1_.callback_19 = function()
	local L_97_
	return nil
end

L_1_.callback_20 = function(L_98_arg0, L_99_arg1, L_100_arg2)
	local L_101_
	return L_1_.callback_19
end

L_1_.callback_21 = function()
	local L_102_
	return
end

L_1_.callback_22 = function(L_103_arg0, L_104_arg1)
	return L_103_arg0
end

L_1_.callback_23 = function(L_105_arg0)
	local L_106_, L_107_, L_108_
	Clipboard:set(L_105_arg0)
	return
end

L_1_.callback_24 = function()
	local L_109_
	return
end

L_1_.callback_25 = function()
	local L_110_, L_111_, L_112_, L_113_, L_114_, L_115_, L_116_, L_117_
	upvalue_0:SendMouseButtonEvent(0, 0, 0, true, game, 1)
	return
end

L_1_.mouse1press = function()
	local L_118_, L_119_
	pcall(L_1_.callback_25)
	return
end

L_1_.callback_27 = function()
	local L_120_, L_121_, L_122_, L_123_, L_124_, L_125_, L_126_, L_127_
	upvalue_0:SendMouseButtonEvent(0, 0, 0, false, game, 1)
	return
end

L_1_.mouse1release = function()
	local L_128_, L_129_
	pcall(L_1_.callback_27)
	return
end

L_1_.Remove = function(L_130_arg0)
	return
end

L_1_.Destroy = function(L_131_arg0)
	return
end

L_1_.__newindex_31 = function()
	local L_132_
	return
end

L_1_.callback_32 = function()
	local L_133_
	return
end

L_1_.__index_33 = function()
	local L_134_
	return L_1_.callback_32
end

L_1_.new = function(L_135_arg0)
	local L_136_, L_137_, L_138_, L_139_
	L_137_ = {}
	L_137_.Visible = false
	L_137_.Remove = L_1_.Remove
	L_137_.Destroy = L_1_.Destroy
	L_138_ = {}
	L_138_.__newindex = L_1_.__newindex_31
	L_138_.__index = L_1_.__index_33
	return setmetatable(L_137_, L_138_)
end

L_1_.callback_35 = function()
	local L_140_, L_141_
	L_140_ = getgenv()
	L_140_.Drawing = upvalue_0
	return
end

L_1_.queue_on_teleport = function()
	local L_142_, L_143_
	L_142_ = request
	if not (L_142_) then
		return
	end
	L_142_ = getgenv()
	L_142_.request = request
	L_143_ = request
	return
end

L_1_.queue_on_teleport_37 = function()
	local L_144_
	return
end

L_1_.gethui = function()
	local L_145_, L_146_, L_147_
	return game:GetService("CoreGui")
end

L_1_.identifyexecutor = function()
	local L_148_, L_149_
	return "Unknown", "0.0.0"
end

L_1_.WindowWidth = function()
	local L_150_, L_151_, L_152_, L_153_, L_154_
	L_150_ = setclipboard
	if not (L_150_) then
		L_150_ = toclipboard
		if L_150_ then
			setclipboard = toclipboard
			L_150_ = toclipboard
		else
			L_150_ = Clipboard
			if L_150_ then
				L_150_ = Clipboard.set
				if L_150_ then
					setclipboard = L_1_.callback_23
					L_150_ = L_1_.callback_23
				else
					setclipboard = L_1_.callback_24
					L_150_ = L_1_.callback_24
				end
			else
				setclipboard = L_1_.callback_24
				L_150_ = L_1_.callback_24
			end
		end
	end
	L_150_ = mouse1press
	if not (L_150_) then
		L_151_ = getgenv()
		L_151_.mouse1press = L_1_.mouse1press
		L_151_ = getgenv()
		L_151_.mouse1release = L_1_.mouse1release
		L_150_ = game:GetService("VirtualInputManager")
		L_152_ = L_1_.mouse1release
	end
	L_150_ = getgenv().Drawing
	L_151_ = getgenv()
	if L_150_ then
		L_150_ = type(getgenv().Drawing)
		L_151_ = getgenv().Drawing
		L_152_ = getgenv()
		L_153_ = "table"
		L_154_ = (type(getgenv().Drawing) == "table")
		if L_154_ then
			L_150_ = getgenv().Drawing.new
			L_151_ = getgenv().Drawing
			L_152_ = getgenv()
			if not (L_150_) then
				L_150_ = {}
				L_150_.new = L_1_.new
				L_151_ = {}
				L_151_.UI = 0
				L_151_.System = 1
				L_151_.Plex = 2
				L_151_.Monospace = 3
				L_150_.Fonts = L_151_
				pcall(L_1_.callback_35)
				L_151_ = pcall
				L_152_ = L_1_.callback_35
			end
		else
			L_150_ = {}
			L_150_.new = L_1_.new
			L_151_ = {}
			L_151_.UI = 0
			L_151_.System = 1
			L_151_.Plex = 2
			L_151_.Monospace = 3
			L_150_.Fonts = L_151_
			pcall(L_1_.callback_35)
			L_151_ = pcall
			L_152_ = L_1_.callback_35
		end
	else
		L_150_ = {}
		L_150_.new = L_1_.new
		L_151_ = {}
		L_151_.UI = 0
		L_151_.System = 1
		L_151_.Plex = 2
		L_151_.Monospace = 3
		L_150_.Fonts = L_151_
		pcall(L_1_.callback_35)
		L_151_ = pcall
		L_152_ = L_1_.callback_35
	end
	L_150_ = request
	if not (L_150_) then
		L_150_ = syn
		if L_150_ then
			L_150_ = syn.request
			if L_150_ then
				request = syn.request
				L_150_ = syn.request
			else
				L_150_ = http
				if L_150_ then
					L_150_ = http.request
					if L_150_ then
						request = http.request
						L_150_ = http.request
					else
						L_150_ = http_request
						if L_150_ then
							request = http_request
							L_150_ = http_request
						end
					end
				else
					L_150_ = http_request
					if L_150_ then
						request = http_request
						L_150_ = http_request
					end
				end
			end
		else
			L_150_ = http
			if L_150_ then
				L_150_ = http.request
				if L_150_ then
					request = http.request
					L_150_ = http.request
				else
					L_150_ = http_request
					if L_150_ then
						request = http_request
						L_150_ = http_request
					end
				end
			else
				L_150_ = http_request
				if L_150_ then
					request = http_request
					L_150_ = http_request
				end
			end
		end
	end
	pcall(L_1_.queue_on_teleport)
	L_150_ = queue_on_teleport
	L_151_ = L_1_.queue_on_teleport
	if not (L_150_) then
		L_150_ = getgenv()
		L_150_.queue_on_teleport = L_1_.queue_on_teleport_37
		L_151_ = L_1_.queue_on_teleport_37
	end
	L_150_ = gethui
	if not (L_150_) then
		L_150_ = getgenv()
		L_150_.gethui = L_1_.gethui
		L_151_ = L_1_.gethui
	end
	L_150_ = identifyexecutor
	if L_150_ then
		return
	end
	L_150_ = getgenv()
	L_150_.identifyexecutor = L_1_.identifyexecutor
	L_151_ = L_1_.identifyexecutor
	return
end

L_1_.callback_41 = function()
	local L_155_, L_156_, L_157_
	L_155_ = game:GetService("MarketplaceService")
	L_155_ = L_155_:GetProductInfo(upvalue_0)
	L_156_ = L_155_
	L_157_ = upvalue_0
	if not (L_155_) then
		return
	end
	L_156_ = L_155_.Name
	if not (L_156_) then
		return
	end
	upvalue_1 = L_155_.Name:lower()
	L_156_ = L_155_.Name:lower()
	L_157_ = L_155_.Name
	return
end

L_1_.name = function()
	local L_158_, L_159_, L_160_, L_161_, L_162_, L_163_, L_164_, L_165_, L_166_
	L_158_ = game:GetService("ReplicatedStorage")
	L_159_ = L_158_:FindFirstChild("TS")
	L_160_ = L_158_
	L_161_ = "TS"

	L_159_ = lplr.PlayerScripts:FindFirstChild("TS")
	L_160_ = lplr.PlayerScripts
	L_161_ = "TS"

	L_159_ = ipairs
	L_160_ = upvalue_0
	L_159_, L_160_, L_161_ = ipairs(upvalue_0)

	L_164_ = L_163_.name
	L_165_ = "BedWars"
	L_166_ = (L_163_.name == "BedWars")

	upvalue_1 = L_163_
	do
		return
	end

	do
		return
	end

	L_159_ = L_158_:FindFirstChild("TS")
	L_160_ = L_158_
	L_161_ = "TS"

	L_159_ = lplr.PlayerScripts:FindFirstChild("TS")
	L_160_ = lplr.PlayerScripts
	L_161_ = "TS"

	L_159_ = ipairs
	L_160_ = upvalue_0
	L_159_, L_160_, L_161_ = ipairs(upvalue_0)

	L_164_ = L_163_.name
	L_165_ = "BedWars"
	L_166_ = (L_163_.name == "BedWars")

	upvalue_1 = L_163_
	do
		return
	end

	do
		return
	end

	L_159_ = L_158_:FindFirstChild("Remotes")
	L_160_ = L_158_
	L_161_ = "Remotes"

	L_159_ = L_158_.Remotes:FindFirstChild("CommF_")
	L_160_ = L_158_.Remotes
	L_161_ = "CommF_"

	L_159_ = ipairs
	L_160_ = upvalue_0
	L_159_, L_160_, L_161_ = ipairs(upvalue_0)

	L_164_ = L_163_.name
	L_165_ = "Blox Fruits"
	L_166_ = (L_163_.name == "Blox Fruits")

	upvalue_1 = L_163_
	do
		return
	end

	do
		return
	end

	L_159_ = L_158_:FindFirstChild("events")
	L_160_ = L_158_
	L_161_ = "events"

	L_159_ = L_158_.events:FindFirstChild("reels")
	L_160_ = L_158_.events
	L_161_ = "reels"

	L_159_ = ipairs
	L_160_ = upvalue_0
	L_159_, L_160_, L_161_ = ipairs(upvalue_0)

	L_164_ = L_163_.name
	L_165_ = "Fish It"
	L_166_ = (L_163_.name == "Fish It")

	upvalue_1 = L_163_
	do
		return
	end

	do
		return
	end

	L_159_ = L_158_:FindFirstChild("Forsaken")
	L_160_ = L_158_
	L_161_ = "Forsaken"

	L_159_ = workspace:FindFirstChild("Forsaken")
	L_160_ = workspace
	L_161_ = "Forsaken"

	L_159_ = ipairs
	L_160_ = upvalue_0
	L_159_, L_160_, L_161_ = ipairs(upvalue_0)

	L_164_ = L_163_.name
	L_165_ = "Forsaken"
	L_166_ = (L_163_.name == "Forsaken")

	upvalue_1 = L_163_
	do
		return
	end

	do
		return
	end

	L_159_ = L_158_:FindFirstChild("Volleyball")
	L_160_ = L_158_
	L_161_ = "Volleyball"

	L_159_ = workspace:FindFirstChild("Volleyball")
	L_160_ = workspace
	L_161_ = "Volleyball"

	L_159_ = L_158_:FindFirstChild("Volley")
	L_160_ = L_158_
	L_161_ = "Volley"

	L_159_ = ipairs
	L_160_ = upvalue_0
	L_159_, L_160_, L_161_ = ipairs(upvalue_0)

	L_164_ = L_163_.name
	L_165_ = "Volley Ball Legends"
	L_166_ = (L_163_.name == "Volley Ball Legends")

	upvalue_1 = L_163_
	do
		return
	end

	do
		return
	end

	L_159_ = L_158_:FindFirstChild("Brainrots")
	L_160_ = L_158_
	L_161_ = "Brainrots"

	L_159_ = workspace:FindFirstChild("Brainrots")
	L_160_ = workspace
	L_161_ = "Brainrots"

	L_159_ = ipairs
	L_160_ = upvalue_0
	L_159_, L_160_, L_161_ = ipairs(upvalue_0)

	L_164_ = L_163_.name
	L_165_ = "SAB"
	L_166_ = (L_163_.name == "SAB")

	upvalue_1 = L_163_
	do
		return
	end

	do
		return
	end

	L_159_ = workspace:FindFirstChild("Pickaxes")
	L_160_ = workspace
	L_161_ = "Pickaxes"

	L_159_ = ipairs
	L_160_ = upvalue_0
	L_159_, L_160_, L_161_ = ipairs(upvalue_0)

	L_164_ = L_163_.name
	L_165_ = "+1 Pickaxe Swing Escape"
	L_166_ = (L_163_.name == "+1 Pickaxe Swing Escape")

	upvalue_1 = L_163_
	do
		return
	end

	do
		return
	end
end

L_1_.callback_43 = function()
	local L_167_, L_168_
	upvalue_0:Destroy()
	return
end

L_1_.callback_44 = function()
	local L_169_, L_170_, L_171_, L_172_, L_173_, L_174_, L_175_, L_176_
	L_171_ = {}
	L_171_.Position = UDim2.new(1, 380, 1, -100)
	L_171_.BackgroundTransparency = 0.5
	tw(upvalue_0, L_171_, 0.4)
	task.wait(0.45)
	pcall(L_1_.callback_43)
	return
end

L_1_.callback_45 = function(L_177_arg0, L_178_arg1, L_179_arg2, L_180_arg3)
	local L_181_, L_182_, L_183_, L_184_, L_185_, L_186_, L_187_, L_188_, L_189_, L_190_, L_191_, L_192_, L_193_
	if not (L_179_arg2) then
		L_179_arg2 = 4
	end
	L_181_ = upvalue_0
	if not (L_181_) then
		L_181_ = Instance.new("ScreenGui", upvalue_1)
		L_181_.Name = "SnowyNotifs"
		L_181_.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
		upvalue_0 = L_181_
		L_182_ = Enum.ZIndexBehavior.Sibling
		L_183_ = upvalue_1
	end
	L_181_ = Instance.new("Frame", upvalue_0)
	L_181_.Size = UDim2.new(0, 340, 0, 80)
	L_181_.Position = UDim2.new(1, 360, 1, -100)
	L_181_.BackgroundColor3 = upvalue_2.BgCard
	L_181_.ZIndex = 500
	corner(upvalue_2.RadiusSm, L_181_)
	L_182_ = stroke
	L_183_ = upvalue_2.RadiusSm
	L_184_ = L_181_
	L_185_ = 1
	L_186_ = -100
	if L_180_arg3 then
		L_183_ = upvalue_2.Premium
		L_184_ = upvalue_2
		if not (L_183_) then
			L_183_ = upvalue_2.Accent
			L_184_ = upvalue_2
		end
	else
		L_183_ = upvalue_2.Accent
		L_184_ = upvalue_2
	end
	L_182_(L_183_, 1.5, L_181_)
	gradient(L_181_, upvalue_2.BgSecondary, upvalue_2.BgCard, 90)
	L_182_ = Instance.new("Frame", L_181_)
	L_182_.Size = UDim2.new(0, 5, 0.6, 0)
	L_182_.Position = UDim2.new(0, 10, 0.2, 0)
	L_183_ = UDim2.new(0, 10, 0.2, 0)
	L_184_ = 0
	L_185_ = 10
	L_186_ = 0.2
	L_187_ = 0
	if L_180_arg3 then
		L_183_ = upvalue_2.Premium
		L_184_ = upvalue_2
		if not (L_183_) then
			L_183_ = upvalue_2.Accent
			L_184_ = upvalue_2
		end
	else
		L_183_ = upvalue_2.Accent
		L_184_ = upvalue_2
	end
	L_182_.BackgroundColor3 = L_183_
	L_182_.BorderSizePixel = 0
	L_182_.ZIndex = 501
	corner(upvalue_2.RadiusPill, L_182_)
	L_183_ = Instance.new("TextLabel", L_181_)
	L_183_.Size = UDim2.new(1, -40, 0, 22)
	L_183_.Position = UDim2.new(0, 24, 0, 10)
	L_183_.BackgroundTransparency = 1
	L_183_.Text = L_177_arg0
	L_184_ = 1
	L_185_ = 0
	L_186_ = 24
	L_187_ = 0
	L_188_ = 10
	if L_180_arg3 then
		L_184_ = upvalue_2.Premium
		L_185_ = upvalue_2
		if not (L_184_) then
			L_184_ = upvalue_2.AccentBright
			L_185_ = upvalue_2
		end
	else
		L_184_ = upvalue_2.AccentBright
		L_185_ = upvalue_2
	end
	L_183_.TextColor3 = L_184_
	L_183_.Font = Enum.Font.GothamBlack
	L_183_.TextSize = 14
	L_183_.ZIndex = 501
	L_183_.TextXAlignment = Enum.TextXAlignment.Left
	L_184_ = Instance.new("TextLabel", L_181_)
	L_184_.Size = UDim2.new(1, -40, 0, 36)
	L_184_.Position = UDim2.new(0, 24, 0, 34)
	L_184_.BackgroundTransparency = 1
	L_184_.Text = L_178_arg1
	L_184_.TextColor3 = upvalue_2.TextSecondary
	L_184_.Font = Enum.Font.Gotham
	L_184_.TextSize = 12
	L_184_.TextWrapped = true
	L_184_.ZIndex = 501
	L_184_.TextXAlignment = Enum.TextXAlignment.Left
	L_185_ = Instance.new("Frame", L_181_)
	L_185_.Size = UDim2.new(1, -20, 0, 3)
	L_185_.Position = UDim2.new(0, 10, 1, -8)
	L_186_ = UDim2.new(0, 10, 1, -8)
	L_187_ = 0
	L_188_ = 10
	L_189_ = 1
	L_190_ = -8
	if L_180_arg3 then
		L_186_ = upvalue_2.Premium
		L_187_ = upvalue_2
		if L_186_ then
			L_185_.BackgroundColor3 = L_186_
			L_185_.ZIndex = 501
			corner(upvalue_2.RadiusPill, L_185_)
			L_188_ = {}
			L_188_.Size = UDim2.new(0, 0, 0, 3)
			tw(L_185_, L_188_, L_179_arg2, Enum.EasingStyle.Linear)
			L_188_ = {}
			L_188_.Position = UDim2.new(1, -360, 1, -100)
			tw(L_181_, L_188_, 0.5, Enum.EasingStyle.Back)
			task.delay(L_179_arg2, L_1_.callback_44)
			return
		end
		L_186_ = upvalue_2.Accent
		L_187_ = upvalue_2
	else
		L_186_ = upvalue_2.Accent
		L_187_ = upvalue_2
	end
	L_185_.BackgroundColor3 = L_186_
	L_185_.ZIndex = 501
	corner(upvalue_2.RadiusPill, L_185_)
	L_188_ = {}
	L_188_.Size = UDim2.new(0, 0, 0, 3)
	tw(L_185_, L_188_, L_179_arg2, Enum.EasingStyle.Linear)
	L_188_ = {}
	L_188_.Position = UDim2.new(1, -360, 1, -100)
	tw(L_181_, L_188_, 0.5, Enum.EasingStyle.Back)
	task.delay(L_179_arg2, L_1_.callback_44)
	return
end

L_1_.Notify = function(L_194_arg0, L_195_arg1, L_196_arg2, L_197_arg3, L_198_arg4)
	local L_199_, L_200_, L_201_, L_202_, L_203_, L_204_
	task.spawn(upvalue_0, L_195_arg1, L_196_arg2, L_197_arg3, L_198_arg4)
	return
end

L_1_.callback_47 = function()
	local L_205_, L_206_
	upvalue_0:Destroy()
	return
end

L_1_.callback_48 = function()
	local L_207_, L_208_
	syn.protect_gui(upvalue_0)
	L_207_ = upvalue_0
	L_207_.Parent = upvalue_1
	upvalue_2 = true
	return
end

L_1_.callback_49 = function()
	local L_209_, L_210_
	L_209_ = upvalue_0
	L_209_.Parent = gethui()
	upvalue_1 = true
	return
end

L_1_.callback_50 = function()
	local L_211_, L_212_
	L_211_ = upvalue_0
	L_211_.Parent = get_hidden_gui()
	upvalue_1 = true
	return
end

L_1_.callback_51 = function()
	local L_213_, L_214_, L_215_, L_216_
	L_213_ = upvalue_0
	L_215_ = upvalue_1:IsStudio()
	L_216_ = upvalue_1
	if L_215_ then
		L_214_ = upvalue_2.PlayerGui
		L_215_ = upvalue_2
		if L_214_ then
			L_213_.Parent = L_214_
			return
		end
		L_214_ = upvalue_3
	else
		L_214_ = upvalue_3
	end
	L_213_.Parent = L_214_
	return
end

L_1_.callback_52 = function()
	local L_217_, L_218_, L_219_, L_220_, L_221_, L_222_, L_223_, L_224_
	L_219_ = {}
	L_219_.Size = UDim2.new(1, -52, 0, 46)
	tw(upvalue_0, L_219_, 0.15)
	return
end

L_1_.callback_53 = function()
	local L_225_, L_226_, L_227_, L_228_, L_229_, L_230_, L_231_, L_232_
	L_227_ = {}
	L_227_.Size = UDim2.new(1, -60, 0, 44)
	tw(upvalue_0, L_227_, 0.15)
	return
end

L_1_.callback_54 = function()
	local L_233_, L_234_
	L_233_ = setclipboard
	if not (L_233_) then
		return
	end
	setclipboard("https://getsnowy.xyz/pricing")
	upvalue_0 = true
	L_233_ = true
	L_234_ = "https://getsnowy.xyz/pricing"
	return
end

L_1_.callback_55 = function()
	local L_235_, L_236_
	toclipboard("https://getsnowy.xyz/pricing")
	upvalue_0 = true
	return
end

L_1_.callback_56 = function()
	local L_237_, L_238_, L_239_, L_240_, L_241_
	L_237_ = upvalue_0
	L_237_.Text = "\u{2726}  getsnowy.xyz/pricing    \u{2022}  Click to copy"
	L_239_ = {}
	L_239_.BackgroundColor3 = upvalue_1.Premium
	tw(upvalue_0, L_239_, 0.2)
	return
end

L_1_.callback_57 = function()
	local L_242_, L_243_
	pcall(L_1_.callback_56)
	return
end

L_1_.callback_58 = function()
	local L_244_, L_245_, L_246_, L_247_, L_248_, L_249_
	pcall(L_1_.callback_54)
	L_244_ = false
	L_245_ = pcall
	L_246_ = L_1_.callback_54
	if not (L_244_) then
		pcall(L_1_.callback_55)
		L_245_ = pcall
		L_246_ = L_1_.callback_55
	end
	L_245_ = upvalue_0
	if L_244_ then
		L_246_ = "\u{2714}  Copied  https://getsnowy.xyz/pricing"
		L_247_ = "\u{2714}  Copied  "
		L_248_ = "https://getsnowy.xyz/pricing"
		if L_246_ then
			L_245_.Text = L_246_
			L_247_ = {}
			L_247_.BackgroundColor3 = upvalue_1.Success
			tw(upvalue_0, L_247_, 0.15)
			task.delay(1.4, L_1_.callback_57)

			return
		end
		L_246_ = "Visit getsnowy.xyz/pricing"
		L_247_ = "Visit "
		L_248_ = "getsnowy.xyz/pricing"
	else
		L_246_ = "Visit getsnowy.xyz/pricing"
		L_247_ = "Visit "
		L_248_ = "getsnowy.xyz/pricing"
	end
	L_245_.Text = L_246_
	L_247_ = {}
	L_247_.BackgroundColor3 = upvalue_1.Success
	tw(upvalue_0, L_247_, 0.15)
	task.delay(1.4, L_1_.callback_57)

	return
end

L_1_.callback_59 = function()
	local L_250_, L_251_
	upvalue_0:Destroy()
	return
end

L_1_.callback_60 = function()
	local L_252_, L_253_, L_254_, L_255_
	pcall(L_1_.callback_59)
	L_252_ = upvalue_1
	L_253_ = upvalue_0
	L_255_ = (upvalue_1 == upvalue_0)
	if not (L_255_) then
		return
	end
	upvalue_1 = nil
	L_252_ = nil
	return
end

L_1_.callback_61 = function()
	local L_256_, L_257_, L_258_, L_259_, L_260_, L_261_
	L_256_ = upvalue_0.Parent
	L_257_ = upvalue_0
	if L_256_ then
		L_258_ = {}
		L_258_.BackgroundTransparency = 1
		tw(upvalue_1, L_258_, 0.2)
		L_258_ = {}
		L_258_.Size = UDim2.fromOffset(0, 0)
		tw(upvalue_2, L_258_, 0.18, Enum.EasingStyle.Back, Enum.EasingDirection.In)
		task.delay(0.22, L_1_.callback_60)
		return
	else
		return
	end
end

L_1_.callback_62 = function()
	local L_262_, L_263_, L_264_, L_265_
	L_262_ = upvalue_0
	L_263_ = upvalue_1
	L_265_ = (upvalue_0 == upvalue_1)
	if not (L_265_) then
		return
	end
	upvalue_2()
	L_262_ = upvalue_2
	return
end

L_1_.callback_63 = function()
	local L_266_, L_267_, L_268_, L_269_, L_270_, L_271_, L_272_, L_273_, L_274_, L_275_, L_276_, L_277_, L_278_, L_279_, L_280_, L_281_
	local L_282_, L_283_, L_284_, L_285_, L_286_, L_287_, L_288_, L_289_, L_290_, L_291_, L_292_, L_293_
	L_267_ = upvalue_0
	if L_267_ then
		L_266_ = tostring(upvalue_0)
		L_267_ = upvalue_0
		if not (L_266_) then
			L_266_ = "That feature"
		end
	else
		L_266_ = "That feature"
	end
	L_267_ = Instance.new("ScreenGui")
	L_267_.Name = "SnowyPremiumModal"
	L_267_.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
	L_267_.IgnoreGuiInset = true
	L_267_.ResetOnSpawn = false
	L_267_.DisplayOrder = 2147483647
	L_268_ = false
	L_269_ = upvalue_1:IsStudio()
	L_270_ = upvalue_1
	if not (L_269_) then
		L_269_ = syn
		if L_269_ then
			L_269_ = syn.protect_gui
			if L_269_ then
				pcall(L_1_.callback_48)
				L_269_ = pcall
				L_270_ = L_1_.callback_48
			end
		end
		if not (L_268_) then
			L_269_ = gethui
			if L_269_ then
				pcall(L_1_.callback_49)
				L_269_ = pcall
				L_270_ = L_1_.callback_49
			end
		end
		if not (L_268_) then
			L_269_ = get_hidden_gui
			if L_269_ then
				pcall(L_1_.callback_50)
				L_269_ = pcall
				L_270_ = L_1_.callback_50
			end
		end
	end
	if L_268_ then
		upvalue_4 = L_267_
		L_269_ = Instance.new("TextButton", L_267_)
		L_269_.Name = "Backdrop"
		L_269_.Size = UDim2.fromScale(1, 1)
		L_269_.BackgroundColor3 = Color3.new(0, 0, 0)
		L_269_.BackgroundTransparency = 1
		L_269_.BorderSizePixel = 0
		L_269_.AutoButtonColor = false
		L_269_.Text = ""
		L_269_.ZIndex = 9000
		L_272_ = {}
		L_272_.BackgroundTransparency = 0.45
		tw(L_269_, L_272_, 0.2)
		L_270_ = Instance.new("Frame", L_267_)
		L_270_.Name = "Card"
		L_270_.AnchorPoint = Vector2.new(0.5, 0.5)
		L_270_.Position = UDim2.fromScale(0.5, 0.5)
		L_270_.Size = UDim2.fromOffset(0, 0)
		L_270_.BackgroundColor3 = upvalue_5.BgCard
		L_270_.BorderSizePixel = 0
		L_270_.ZIndex = 9010
		L_270_.ClipsDescendants = true
		corner(18, L_270_)
		stroke(upvalue_5.Premium, 2, L_270_)
		gradient(L_270_, upvalue_5.BgSecondary, upvalue_5.BgCard, 125)
		shadow(L_270_)
		L_271_ = Instance.new("Frame", L_270_)
		L_271_.Size = UDim2.new(1, 0, 0, 4)
		L_271_.BackgroundColor3 = upvalue_5.Premium
		L_271_.BorderSizePixel = 0
		L_271_.ZIndex = 9011
		gradient(L_271_, upvalue_5.PremiumDark, upvalue_5.Premium, 0)
		L_272_ = Instance.new("Frame", L_270_)
		L_272_.Name = "LockContainer"
		L_272_.Size = UDim2.new(0, 68, 0, 68)
		L_272_.Position = UDim2.new(0.5, -34, 0, 28)
		L_272_.BackgroundColor3 = upvalue_5.PremiumDim
		L_272_.BorderSizePixel = 0
		L_272_.ZIndex = 9012
		corner(999, L_272_)
		stroke(upvalue_5.Premium, 2, L_272_)
		L_273_ = Instance.new("Frame", L_272_)
		L_273_.Name = "Shackle"
		L_273_.Size = UDim2.new(0, 26, 0, 26)
		L_273_.Position = UDim2.new(0.5, -13, 0.5, -23)
		L_273_.BackgroundTransparency = 1
		L_273_.ZIndex = 9013
		L_274_ = Instance.new("UICorner", L_273_)
		L_274_.CornerRadius = UDim.new(0.5, 0)
		L_275_ = Instance.new("UIStroke", L_273_)
		L_275_.Color = upvalue_5.Premium
		L_275_.Thickness = 3
		L_275_.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		L_276_ = Instance.new("Frame", L_272_)
		L_276_.Name = "Body"
		L_276_.Size = UDim2.new(0, 34, 0, 26)
		L_276_.Position = UDim2.new(0.5, -17, 0.5, -7)
		L_276_.BackgroundColor3 = upvalue_5.Premium
		L_276_.BorderSizePixel = 0
		L_276_.ZIndex = 9014
		L_277_ = Instance.new("UICorner", L_276_)
		L_277_.CornerRadius = UDim.new(0, 4)
		L_278_ = Instance.new("Frame", L_276_)
		L_278_.Name = "KeyholeCircle"
		L_278_.Size = UDim2.new(0, 6, 0, 6)
		L_278_.Position = UDim2.new(0.5, -3, 0.3, 0)
		L_278_.BackgroundColor3 = upvalue_5.BgCard
		L_278_.BorderSizePixel = 0
		L_278_.ZIndex = 9015
		L_279_ = Instance.new("UICorner", L_278_)
		L_279_.CornerRadius = UDim.new(1, 0)
		L_280_ = Instance.new("Frame", L_276_)
		L_280_.Name = "KeyholeLine"
		L_280_.Size = UDim2.new(0, 3, 0, 8)
		L_280_.Position = UDim2.new(0.5, -1.5, 0.3, 4)
		L_280_.BackgroundColor3 = upvalue_5.BgCard
		L_280_.BorderSizePixel = 0
		L_280_.ZIndex = 9015
		L_281_ = Instance.new("UICorner", L_280_)
		L_281_.CornerRadius = UDim.new(0, 1)
		L_282_ = Instance.new("TextLabel", L_270_)
		L_282_.Size = UDim2.new(1, -30, 0, 28)
		L_282_.Position = UDim2.new(0, 15, 0, 106)
		L_282_.BackgroundTransparency = 1
		L_282_.Text = "PREMIUM FEATURE"
		L_282_.TextColor3 = upvalue_5.Premium
		L_282_.Font = Enum.Font.GothamBlack
		L_282_.TextSize = 20
		L_282_.ZIndex = 9012
		L_283_ = Instance.new("TextLabel", L_270_)
		L_283_.Size = UDim2.new(1, -30, 0, 22)
		L_283_.Position = UDim2.new(0, 15, 0, 136)
		L_283_.BackgroundTransparency = 1
		L_283_.Text = "\u{201c}" .. L_266_ .. "\u{201d} is locked."
		L_283_.TextColor3 = upvalue_5.TextPrimary
		L_283_.Font = Enum.Font.GothamSemibold
		L_283_.TextSize = 14
		L_283_.TextTruncate = Enum.TextTruncate.AtEnd
		L_283_.ZIndex = 9012
		L_284_ = Instance.new("TextLabel", L_270_)
		L_284_.Size = UDim2.new(1, -30, 0, 20)
		L_284_.Position = UDim2.new(0, 15, 0, 160)
		L_284_.BackgroundTransparency = 1
		L_284_.Text = "Unlock every Snowy Premium feature at"
		L_284_.TextColor3 = upvalue_5.TextSecondary
		L_284_.Font = Enum.Font.Gotham
		L_284_.TextSize = 12
		L_284_.ZIndex = 9012
		L_285_ = Instance.new("TextButton", L_270_)
		L_285_.Size = UDim2.new(1, -60, 0, 44)
		L_285_.Position = UDim2.new(0, 30, 0, 188)
		L_285_.BackgroundColor3 = upvalue_5.Premium
		L_285_.BorderSizePixel = 0
		L_285_.AutoButtonColor = false
		L_285_.Text = "\u{2726}  getsnowy.xyz/pricing    \u{2022}  Click to copy"
		L_285_.TextColor3 = Color3.fromRGB(20, 15, 0)
		L_285_.Font = Enum.Font.GothamBlack
		L_285_.TextSize = 15
		L_285_.ZIndex = 9012
		corner(10, L_285_)
		stroke(upvalue_5.PremiumDark, 1, L_285_)
		gradient(L_285_, upvalue_5.Premium, upvalue_5.PremiumDark, 90)
		L_285_.MouseEnter:Connect(L_1_.callback_52)
		L_285_.MouseLeave:Connect(L_1_.callback_53)
		L_285_.Activated:Connect(L_1_.callback_58)
		L_286_ = Instance.new("TextButton", L_270_)
		L_286_.Size = UDim2.new(1, -60, 0, 32)
		L_286_.Position = UDim2.new(0, 30, 0, 242)
		L_286_.BackgroundColor3 = upvalue_5.BgInput
		L_286_.BorderSizePixel = 0
		L_286_.AutoButtonColor = false
		L_286_.Text = "Maybe later"
		L_286_.TextColor3 = upvalue_5.TextSecondary
		L_286_.Font = Enum.Font.GothamMedium
		L_286_.TextSize = 13
		L_286_.ZIndex = 9012
		corner(8, L_286_)
		stroke(upvalue_5.Border, 1, L_286_)
		L_286_.Activated:Connect(L_1_.callback_61)
		L_269_.Activated:Connect(L_1_.callback_61)
		L_270_.Size = UDim2.fromOffset(0, 0)
		L_290_ = {}
		L_290_.Size = UDim2.fromOffset(400, 300)
		tw(L_270_, L_290_, 0.35, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
		task.delay(7, L_1_.callback_62)

		return
	end
	pcall(L_1_.callback_51)
	L_269_ = pcall
	L_270_ = L_1_.callback_51
	upvalue_4 = L_267_
	L_269_ = Instance.new("TextButton", L_267_)
	L_269_.Name = "Backdrop"
	L_269_.Size = UDim2.fromScale(1, 1)
	L_269_.BackgroundColor3 = Color3.new(0, 0, 0)
	L_269_.BackgroundTransparency = 1
	L_269_.BorderSizePixel = 0
	L_269_.AutoButtonColor = false
	L_269_.Text = ""
	L_269_.ZIndex = 9000
	L_272_ = {}
	L_272_.BackgroundTransparency = 0.45
	tw(L_269_, L_272_, 0.2)
	L_270_ = Instance.new("Frame", L_267_)
	L_270_.Name = "Card"
	L_270_.AnchorPoint = Vector2.new(0.5, 0.5)
	L_270_.Position = UDim2.fromScale(0.5, 0.5)
	L_270_.Size = UDim2.fromOffset(0, 0)
	L_270_.BackgroundColor3 = upvalue_5.BgCard
	L_270_.BorderSizePixel = 0
	L_270_.ZIndex = 9010
	L_270_.ClipsDescendants = true
	corner(18, L_270_)
	stroke(upvalue_5.Premium, 2, L_270_)
	gradient(L_270_, upvalue_5.BgSecondary, upvalue_5.BgCard, 125)
	shadow(L_270_)
	L_271_ = Instance.new("Frame", L_270_)
	L_271_.Size = UDim2.new(1, 0, 0, 4)
	L_271_.BackgroundColor3 = upvalue_5.Premium
	L_271_.BorderSizePixel = 0
	L_271_.ZIndex = 9011
	gradient(L_271_, upvalue_5.PremiumDark, upvalue_5.Premium, 0)
	L_272_ = Instance.new("Frame", L_270_)
	L_272_.Name = "LockContainer"
	L_272_.Size = UDim2.new(0, 68, 0, 68)
	L_272_.Position = UDim2.new(0.5, -34, 0, 28)
	L_272_.BackgroundColor3 = upvalue_5.PremiumDim
	L_272_.BorderSizePixel = 0
	L_272_.ZIndex = 9012
	corner(999, L_272_)
	stroke(upvalue_5.Premium, 2, L_272_)
	L_273_ = Instance.new("Frame", L_272_)
	L_273_.Name = "Shackle"
	L_273_.Size = UDim2.new(0, 26, 0, 26)
	L_273_.Position = UDim2.new(0.5, -13, 0.5, -23)
	L_273_.BackgroundTransparency = 1
	L_273_.ZIndex = 9013
	L_274_ = Instance.new("UICorner", L_273_)
	L_274_.CornerRadius = UDim.new(0.5, 0)
	L_275_ = Instance.new("UIStroke", L_273_)
	L_275_.Color = upvalue_5.Premium
	L_275_.Thickness = 3
	L_275_.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	L_276_ = Instance.new("Frame", L_272_)
	L_276_.Name = "Body"
	L_276_.Size = UDim2.new(0, 34, 0, 26)
	L_276_.Position = UDim2.new(0.5, -17, 0.5, -7)
	L_276_.BackgroundColor3 = upvalue_5.Premium
	L_276_.BorderSizePixel = 0
	L_276_.ZIndex = 9014
	L_277_ = Instance.new("UICorner", L_276_)
	L_277_.CornerRadius = UDim.new(0, 4)
	L_278_ = Instance.new("Frame", L_276_)
	L_278_.Name = "KeyholeCircle"
	L_278_.Size = UDim2.new(0, 6, 0, 6)
	L_278_.Position = UDim2.new(0.5, -3, 0.3, 0)
	L_278_.BackgroundColor3 = upvalue_5.BgCard
	L_278_.BorderSizePixel = 0
	L_278_.ZIndex = 9015
	L_279_ = Instance.new("UICorner", L_278_)
	L_279_.CornerRadius = UDim.new(1, 0)
	L_280_ = Instance.new("Frame", L_276_)
	L_280_.Name = "KeyholeLine"
	L_280_.Size = UDim2.new(0, 3, 0, 8)
	L_280_.Position = UDim2.new(0.5, -1.5, 0.3, 4)
	L_280_.BackgroundColor3 = upvalue_5.BgCard
	L_280_.BorderSizePixel = 0
	L_280_.ZIndex = 9015
	L_281_ = Instance.new("UICorner", L_280_)
	L_281_.CornerRadius = UDim.new(0, 1)
	L_282_ = Instance.new("TextLabel", L_270_)
	L_282_.Size = UDim2.new(1, -30, 0, 28)
	L_282_.Position = UDim2.new(0, 15, 0, 106)
	L_282_.BackgroundTransparency = 1
	L_282_.Text = "PREMIUM FEATURE"
	L_282_.TextColor3 = upvalue_5.Premium
	L_282_.Font = Enum.Font.GothamBlack
	L_282_.TextSize = 20
	L_282_.ZIndex = 9012
	L_283_ = Instance.new("TextLabel", L_270_)
	L_283_.Size = UDim2.new(1, -30, 0, 22)
	L_283_.Position = UDim2.new(0, 15, 0, 136)
	L_283_.BackgroundTransparency = 1
	L_283_.Text = "\u{201c}" .. L_266_ .. "\u{201d} is locked."
	L_283_.TextColor3 = upvalue_5.TextPrimary
	L_283_.Font = Enum.Font.GothamSemibold
	L_283_.TextSize = 14
	L_283_.TextTruncate = Enum.TextTruncate.AtEnd
	L_283_.ZIndex = 9012
	L_284_ = Instance.new("TextLabel", L_270_)
	L_284_.Size = UDim2.new(1, -30, 0, 20)
	L_284_.Position = UDim2.new(0, 15, 0, 160)
	L_284_.BackgroundTransparency = 1
	L_284_.Text = "Unlock every Snowy Premium feature at"
	L_284_.TextColor3 = upvalue_5.TextSecondary
	L_284_.Font = Enum.Font.Gotham
	L_284_.TextSize = 12
	L_284_.ZIndex = 9012
	L_285_ = Instance.new("TextButton", L_270_)
	L_285_.Size = UDim2.new(1, -60, 0, 44)
	L_285_.Position = UDim2.new(0, 30, 0, 188)
	L_285_.BackgroundColor3 = upvalue_5.Premium
	L_285_.BorderSizePixel = 0
	L_285_.AutoButtonColor = false
	L_285_.Text = "\u{2726}  getsnowy.xyz/pricing    \u{2022}  Click to copy"
	L_285_.TextColor3 = Color3.fromRGB(20, 15, 0)
	L_285_.Font = Enum.Font.GothamBlack
	L_285_.TextSize = 15
	L_285_.ZIndex = 9012
	corner(10, L_285_)
	stroke(upvalue_5.PremiumDark, 1, L_285_)
	gradient(L_285_, upvalue_5.Premium, upvalue_5.PremiumDark, 90)
	L_285_.MouseEnter:Connect(L_1_.callback_52)
	L_285_.MouseLeave:Connect(L_1_.callback_53)
	L_285_.Activated:Connect(L_1_.callback_58)
	L_286_ = Instance.new("TextButton", L_270_)
	L_286_.Size = UDim2.new(1, -60, 0, 32)
	L_286_.Position = UDim2.new(0, 30, 0, 242)
	L_286_.BackgroundColor3 = upvalue_5.BgInput
	L_286_.BorderSizePixel = 0
	L_286_.AutoButtonColor = false
	L_286_.Text = "Maybe later"
	L_286_.TextColor3 = upvalue_5.TextSecondary
	L_286_.Font = Enum.Font.GothamMedium
	L_286_.TextSize = 13
	L_286_.ZIndex = 9012
	corner(8, L_286_)
	stroke(upvalue_5.Border, 1, L_286_)
	L_286_.Activated:Connect(L_1_.callback_61)
	L_269_.Activated:Connect(L_1_.callback_61)
	L_270_.Size = UDim2.fromOffset(0, 0)
	L_290_ = {}
	L_290_.Size = UDim2.fromOffset(400, 300)
	tw(L_270_, L_290_, 0.35, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
	task.delay(7, L_1_.callback_62)

	return
end

L_1_.callback_64 = function(L_294_arg0)
	local L_295_, L_296_, L_297_, L_298_, L_299_, L_300_, L_301_, L_302_, L_303_, L_304_, L_305_, L_306_, L_307_
	L_295_ = tick()
	L_296_ = (tick() - upvalue_0)
	L_297_ = 1.2
	L_307_ = ((tick() - upvalue_0) < 1.2)
	if L_307_ then
		return
	end
	upvalue_0 = L_295_
	L_296_ = upvalue_1
	if L_296_ then
		pcall(L_1_.callback_47)
		upvalue_1 = nil
		L_296_ = nil
		L_297_ = L_1_.callback_47
	end
	L_296_ = pcall
	L_297_ = L_1_.callback_63
	L_296_, L_297_ = pcall(L_1_.callback_63)
	if L_296_ then
		return
	end
	if L_294_arg0 then
		L_298_ = "'" .. tostring(L_294_arg0) .. "'"
		L_299_ = "'"
		L_300_ = tostring(L_294_arg0)
		L_301_ = "'"
		L_302_ = tostring(L_294_arg0)
		L_303_ = L_294_arg0
		if not (L_298_) then
			L_298_ = "That feature"
		end
	else
		L_298_ = "That feature"
	end
	upvalue_6:Notify("\u{2726}  PREMIUM LOCKED", L_298_ .. " is locked to Snowy Premium. Upgrade at getsnowy.xyz/pricing", 5, true)
	L_299_ = upvalue_6.Notify
	L_300_ = upvalue_6
	L_301_ = "\u{2726}  PREMIUM LOCKED"
	L_302_ = L_298_ .. " is locked to Snowy Premium. Upgrade at getsnowy.xyz/pricing"
	L_303_ = 5
	L_304_ = true
	L_305_ = "getsnowy.xyz/pricing"
	return
end

L_1_.callback_65 = function(L_308_arg0, L_309_arg1)
	local L_310_, L_311_, L_312_, L_313_, L_314_, L_315_, L_316_, L_317_
	L_310_ = Instance.new(L_308_arg0)
	L_311_ = next
	L_312_ = L_309_arg1
	L_313_ = nil
	for L_318_forvar0, L_319_forvar1 in L_311_, L_312_, L_313_ do
		L_316_ = "Parent"
		L_317_ = (L_318_forvar0 == "Parent")
		if not (L_317_) then
			L_310_[L_318_forvar0] = L_319_forvar1
		end
	end
	L_310_.Parent = L_309_arg1.Parent
	return L_310_
end

L_1_.callback_66 = function(L_320_arg0, L_321_arg1, L_322_arg2)
	local L_323_, L_324_, L_325_, L_326_, L_327_, L_328_, L_329_
	L_323_ = upvalue_0:Create(L_320_arg0, TweenInfo.new(L_321_arg1, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_322_arg2)
	L_323_:Play()
	return
end

L_1_.callback_67 = function(L_330_arg0)
	local L_331_, L_332_, L_333_, L_334_
	L_331_ = L_330_arg0.UserInputType
	L_332_ = Enum.UserInputType.MouseButton1
	L_334_ = (L_330_arg0.UserInputType == Enum.UserInputType.MouseButton1)
	if L_334_ then
		L_331_ = upvalue_0._blockDrag
		L_332_ = upvalue_0
		if L_331_ then
			return
		end
		upvalue_1 = true
		upvalue_2 = false
		upvalue_3 = L_330_arg0.Position
		upvalue_4 = upvalue_5.Position
		L_331_ = upvalue_5.Position
		L_332_ = upvalue_5
	else
		L_331_ = L_330_arg0.UserInputType
		L_332_ = Enum.UserInputType.Touch
		L_334_ = (L_330_arg0.UserInputType == Enum.UserInputType.Touch)
		if not (L_334_) then
			return
		end
		L_331_ = upvalue_0._blockDrag
		L_332_ = upvalue_0
		if L_331_ then
			return
		end
		upvalue_1 = true
		upvalue_2 = false
		upvalue_3 = L_330_arg0.Position
		upvalue_4 = upvalue_5.Position
		L_331_ = upvalue_5.Position
		L_332_ = upvalue_5
	end
	return
end

L_1_.callback_68 = function(L_335_arg0)
	local L_336_, L_337_, L_338_, L_339_
	L_336_ = L_335_arg0.UserInputType
	L_337_ = Enum.UserInputType.MouseButton1
	L_339_ = (L_335_arg0.UserInputType == Enum.UserInputType.MouseButton1)
	if L_339_ then
		upvalue_0 = false
		L_336_ = false
	else
		L_336_ = L_335_arg0.UserInputType
		L_337_ = Enum.UserInputType.Touch
		L_339_ = (L_335_arg0.UserInputType == Enum.UserInputType.Touch)
		if not (L_339_) then
			return
		end
		upvalue_0 = false
		L_336_ = false
	end
	return
end

L_1_.callback_69 = function(L_340_arg0)
	local L_341_, L_342_, L_343_, L_344_, L_345_, L_346_, L_347_, L_348_, L_349_, L_350_, L_351_, L_352_
	L_341_ = upvalue_0
	if not (L_341_) then
		return
	end
	L_341_ = L_340_arg0.UserInputType
	L_342_ = Enum.UserInputType.MouseMovement
	L_352_ = (L_340_arg0.UserInputType == Enum.UserInputType.MouseMovement)
	if L_352_ then
		L_341_ = (L_340_arg0.Position - upvalue_1)
		L_342_ = upvalue_2
		L_343_ = upvalue_1
		if not (L_342_) then
			L_342_ = math.abs(L_341_.X)
			L_343_ = 4
			L_352_ = (4 <= math.abs(L_341_.X))
			if L_352_ then
				upvalue_2 = true
				L_342_ = true
			else
				L_342_ = math.abs(L_341_.Y)
				L_343_ = 4
				L_352_ = (4 <= math.abs(L_341_.Y))
				if L_352_ then
					upvalue_2 = true
					L_342_ = true
				end
			end
		end
		L_342_ = upvalue_2
		if not (L_342_) then
			return
		end
		L_342_ = upvalue_3
		L_342_.Position = UDim2.new(upvalue_4.X.Scale, (upvalue_4.X.Offset + L_341_.X), upvalue_4.Y.Scale, (upvalue_4.Y.Offset + L_341_.Y))
		L_343_ = UDim2.new(upvalue_4.X.Scale, (upvalue_4.X.Offset + L_341_.X), upvalue_4.Y.Scale, (upvalue_4.Y.Offset + L_341_.Y))
		L_344_ = upvalue_4.X.Scale
		L_345_ = (upvalue_4.X.Offset + L_341_.X)
		L_346_ = upvalue_4.Y.Scale
		L_347_ = (upvalue_4.Y.Offset + L_341_.Y)
		L_348_ = upvalue_4.Y.Offset
		L_349_ = L_341_.Y
		L_350_ = upvalue_4
	else
		L_341_ = L_340_arg0.UserInputType
		L_342_ = Enum.UserInputType.Touch
		L_352_ = (L_340_arg0.UserInputType == Enum.UserInputType.Touch)
		if not (L_352_) then
			return
		end
		L_341_ = (L_340_arg0.Position - upvalue_1)
		L_342_ = upvalue_2
		L_343_ = upvalue_1
		if not (L_342_) then
			L_342_ = math.abs(L_341_.X)
			L_343_ = 4
			L_352_ = (4 <= math.abs(L_341_.X))
			if L_352_ then
				upvalue_2 = true
				L_342_ = true
			else
				L_342_ = math.abs(L_341_.Y)
				L_343_ = 4
				L_352_ = (4 <= math.abs(L_341_.Y))
				if L_352_ then
					upvalue_2 = true
					L_342_ = true
				end
			end
		end
		L_342_ = upvalue_2
		if not (L_342_) then
			return
		end
		L_342_ = upvalue_3
		L_342_.Position = UDim2.new(upvalue_4.X.Scale, (upvalue_4.X.Offset + L_341_.X), upvalue_4.Y.Scale, (upvalue_4.Y.Offset + L_341_.Y))
		L_343_ = UDim2.new(upvalue_4.X.Scale, (upvalue_4.X.Offset + L_341_.X), upvalue_4.Y.Scale, (upvalue_4.Y.Offset + L_341_.Y))
		L_344_ = upvalue_4.X.Scale
		L_345_ = (upvalue_4.X.Offset + L_341_.X)
		L_346_ = upvalue_4.Y.Scale
		L_347_ = (upvalue_4.Y.Offset + L_341_.Y)
		L_348_ = upvalue_4.Y.Offset
		L_349_ = L_341_.Y
		L_350_ = upvalue_4
	end
	return
end

L_1_.callback_70 = function()
	local L_353_, L_354_
	upvalue_0 = false
	return upvalue_0
end

L_1_.MakeDraggable = function(L_355_arg0, L_356_arg1, L_357_arg2)
	local L_358_, L_359_, L_360_, L_361_, L_362_, L_363_, L_364_
	if L_357_arg2 then
		L_356_arg1.InputBegan:Connect(L_1_.callback_67)
		L_356_arg1.InputEnded:Connect(L_1_.callback_68)
		upvalue_1.InputChanged:Connect(L_1_.callback_69)

		return L_1_.callback_70
	end
	L_357_arg2 = L_356_arg1
	L_356_arg1.InputBegan:Connect(L_1_.callback_67)
	L_356_arg1.InputEnded:Connect(L_1_.callback_68)
	upvalue_1.InputChanged:Connect(L_1_.callback_69)

	return L_1_.callback_70
end

L_1_.GetIcon = function(L_365_arg0, L_366_arg1)
	local L_367_, L_368_
	L_367_ = upvalue_0[L_366_arg1]
	L_368_ = upvalue_0
	if L_367_ then
		return L_367_
	end
	L_367_ = upvalue_0.home
	L_368_ = upvalue_0
	return L_367_
end

L_1_.callback_73 = function()
	local L_369_, L_370_, L_371_, L_372_
	L_369_ = game:GetService("HttpService")
	L_369_ = L_369_:GenerateGUID(false)
	return L_369_:sub(1, 8)
end

L_1_.callback_74 = function()
	local L_373_, L_374_
	syn.protect_gui(upvalue_0)
	L_373_ = upvalue_0
	L_373_.Parent = upvalue_1
	upvalue_2 = true
	return
end

L_1_.callback_75 = function()
	local L_375_, L_376_
	L_375_ = upvalue_0
	L_375_.Parent = gethui()
	upvalue_1 = true
	return
end

L_1_.callback_76 = function()
	local L_377_, L_378_
	L_377_ = upvalue_0
	L_377_.Parent = get_hidden_gui()
	upvalue_1 = true
	return
end

L_1_.callback_77 = function()
	local L_379_, L_380_, L_381_
	L_379_ = getgenv()[upvalue_0]
	L_379_:Destroy()
	return
end

L_1_.callback_78 = function()
	local L_382_, L_383_, L_384_
	L_382_ = upvalue_0:IsDescendantOf(game)
	L_383_ = upvalue_0
	L_384_ = game
	if L_382_ then
		return
	end
	upvalue_1:Cancel()
	L_382_ = upvalue_1.Cancel
	L_383_ = upvalue_1
	return
end

L_1_.callback_79 = function()
	local L_385_, L_386_, L_387_, L_388_, L_389_, L_390_, L_391_
	L_390_ = {}
	L_390_.ImageTransparency = 0.8
	L_386_ = upvalue_0:Create(upvalue_1, TweenInfo.new(2, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut, -1, true), L_390_)
	L_386_:Play()
	upvalue_2.AncestryChanged:Connect(L_1_.callback_78)
	return
end

L_1_.callback_80 = function()
	local L_392_, L_393_, L_394_, L_395_, L_396_
	L_392_ = upvalue_0.GetUserThumbnailAsync
	L_393_ = upvalue_0
	L_394_ = upvalue_1.UserId
	L_395_ = Enum.ThumbnailType.HeadShot
	L_396_ = Enum.ThumbnailSize.Size100x100
	L_392_, L_393_ = upvalue_0:GetUserThumbnailAsync(upvalue_1.UserId, Enum.ThumbnailType.HeadShot, Enum.ThumbnailSize.Size100x100)
	if not (L_393_) then
		return
	end
	L_394_ = upvalue_2
	L_394_.Image = L_392_
	return
end

L_1_.callback_81 = function()
	local L_397_, L_398_
	pcall(L_1_.callback_80)
	return
end

L_1_.Name = function()
	local L_399_, L_400_
	L_399_ = upvalue_0()
	if L_399_ then
		return
	end
	upvalue_1:Destroy()
	L_399_ = upvalue_1.Destroy
	L_400_ = upvalue_1
	return
end

L_1_.callback_83 = function()
	local L_401_, L_402_, L_403_, L_404_, L_405_, L_406_, L_407_, L_408_, L_409_
	L_402_ = {}
	L_402_.TextColor3 = upvalue_1.Accent
	L_403_ = upvalue_2:Create(upvalue_0, TweenInfo.new(0.15, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_402_)
	L_403_:Play()
	return
end

L_1_.callback_84 = function()
	local L_410_, L_411_, L_412_, L_413_, L_414_, L_415_, L_416_, L_417_, L_418_
	L_411_ = {}
	L_411_.TextColor3 = Color3.new(1, 1, 1)
	L_412_ = upvalue_1:Create(upvalue_0, TweenInfo.new(0.15, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_411_)
	L_412_:Play()
	return
end

L_1_.callback_85 = function()
	local L_419_, L_420_, L_421_, L_422_, L_423_, L_424_, L_425_, L_426_, L_427_
	L_420_ = {}
	L_420_.TextColor3 = upvalue_1.Error
	L_421_ = upvalue_2:Create(upvalue_0, TweenInfo.new(0.15, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_420_)
	L_421_:Play()
	return
end

L_1_.BackgroundTransparency = function()
	local L_428_, L_429_, L_430_, L_431_, L_432_, L_433_, L_434_, L_435_, L_436_
	L_429_ = {}
	L_429_.TextColor3 = Color3.new(1, 1, 1)
	L_430_ = upvalue_1:Create(upvalue_0, TweenInfo.new(0.15, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_429_)
	L_430_:Play()
	return
end

L_1_.callback_87 = function(L_437_arg0)
	local L_438_, L_439_, L_440_, L_441_, L_442_, L_443_
	L_438_ = L_437_arg0.UserInputType
	L_439_ = Enum.UserInputType.Touch
	L_443_ = (L_437_arg0.UserInputType == Enum.UserInputType.Touch)
	if L_443_ then
		L_438_ = upvalue_0()
		if L_438_ then
			return
		end
		L_438_ = upvalue_1
		L_438_.Visible = not upvalue_1.Visible
		L_439_ = not upvalue_1.Visible
		L_440_ = upvalue_1.Visible
		L_441_ = upvalue_1
	else
		L_438_ = L_437_arg0.UserInputType
		L_439_ = Enum.UserInputType.MouseButton1
		L_443_ = (L_437_arg0.UserInputType == Enum.UserInputType.MouseButton1)
		if not (L_443_) then
			return
		end
		L_438_ = upvalue_0()
		if L_438_ then
			return
		end
		L_438_ = upvalue_1
		L_438_.Visible = not upvalue_1.Visible
		L_439_ = not upvalue_1.Visible
		L_440_ = upvalue_1.Visible
		L_441_ = upvalue_1
	end
	return
end

L_1_.Name_88 = function(L_444_arg0)
	local L_445_, L_446_, L_447_, L_448_, L_449_, L_450_
	L_445_ = L_444_arg0.KeyCode
	L_446_ = Enum.KeyCode.RightShift
	L_450_ = (L_444_arg0.KeyCode == Enum.KeyCode.RightShift)
	if not (L_450_) then
		return
	end
	L_445_ = upvalue_0
	L_445_.Visible = not upvalue_0.Visible
	L_446_ = not upvalue_0.Visible
	L_447_ = upvalue_0.Visible
	L_448_ = upvalue_0
	return
end

L_1_.callback_89 = function()
	local L_451_, L_452_, L_453_
	L_451_ = upvalue_0:IsDescendantOf(game)
	L_452_ = upvalue_0
	L_453_ = game
	if L_451_ then
		return
	end
	upvalue_1:Cancel()
	L_451_ = upvalue_1.Cancel
	L_452_ = upvalue_1
	return
end

L_1_.callback_90 = function()
	local L_454_, L_455_, L_456_, L_457_, L_458_, L_459_, L_460_
	L_459_ = {}
	L_459_.ImageTransparency = 0.85
	L_455_ = upvalue_0:Create(upvalue_1, TweenInfo.new(1.6, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut, -1, true), L_459_)
	L_455_:Play()
	upvalue_2.AncestryChanged:Connect(L_1_.callback_89)
	return
end

L_1_.callback_91 = function()
	local L_461_, L_462_, L_463_, L_464_, L_465_, L_466_, L_467_, L_468_, L_469_
	L_461_ = upvalue_0
	if L_461_ then
		return
	else
		upvalue_0 = true
		L_461_ = upvalue_1
		L_461_.Visible = false
		L_461_ = upvalue_2
		L_461_.Visible = true
		L_461_ = upvalue_2
		L_461_.Size = UDim2.new(0, 0, 0, 0)
		L_462_ = {}
		L_462_.Size = UDim2.new(0, 170, 0, 46)
		L_463_ = upvalue_3:Create(upvalue_2, TweenInfo.new(0.35, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_462_)
		L_463_:Play()
		return
	end
end

L_1_.callback_92 = function()
	local L_470_, L_471_
	L_470_ = upvalue_0
	L_470_.Visible = false
	return
end

L_1_.callback_93 = function()
	local L_472_, L_473_, L_474_, L_475_, L_476_, L_477_, L_478_, L_479_, L_480_
	L_472_ = upvalue_0
	if L_472_ then
		upvalue_0 = false
		L_473_ = {}
		L_473_.Size = UDim2.new(0, 0, 0, 0)
		L_474_ = upvalue_2:Create(upvalue_1, TweenInfo.new(0.25, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_473_)
		L_474_:Play()
		task.delay(0.26, L_1_.callback_92)
		L_472_ = upvalue_3
		L_472_.Visible = true
		return
	else
		return
	end
end

L_1_.callback_94 = function()
	local L_481_
	L_481_ = upvalue_0()
	if L_481_ then
		return
	end
	upvalue_1()
	L_481_ = upvalue_1
	return
end

L_1_.Select = function(L_482_arg0)
	local L_483_, L_484_, L_485_, L_486_, L_487_, L_488_, L_489_, L_490_, L_491_, L_492_, L_493_, L_494_, L_495_, L_496_, L_497_, L_498_
	local L_499_, L_500_, L_501_, L_502_
	L_483_ = next
	L_484_ = upvalue_0.GetChildren
	L_485_ = upvalue_0
	L_484_, L_485_ = upvalue_0:GetChildren()
	for L_503_forvar0, L_504_forvar1 in L_483_, L_484_, L_485_ do
		L_488_ = L_504_forvar1:IsA("ImageButton")
		L_489_ = L_504_forvar1
		L_490_ = "ImageButton"
		if L_488_ then
			L_488_ = L_504_forvar1:FindFirstChild("Indicator")
			L_489_ = L_504_forvar1
			L_490_ = "Indicator"
			if L_488_ then
				L_489_ = {}
				L_489_.BackgroundTransparency = 1
				L_490_ = upvalue_1:Create(L_504_forvar1.Indicator, TweenInfo.new(0.25, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_489_)
				L_490_:Play()
				L_488_ = L_504_forvar1.Indicator
				L_490_ = L_490_.Play
				L_491_ = L_490_
				L_492_ = L_504_forvar1.Indicator
				L_493_ = TweenInfo.new(0.25, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
				L_494_ = L_489_
				L_495_ = Enum.EasingStyle.Quart
				L_496_ = Enum.EasingDirection.Out
			end
			L_488_ = L_504_forvar1:FindFirstChild("Icon")
			L_489_ = L_504_forvar1
			L_490_ = "Icon"
			if L_488_ then
				L_489_ = {}
				L_489_.ImageColor3 = Color3.fromRGB(140, 140, 140)
				L_490_ = upvalue_1:Create(L_504_forvar1.Icon, TweenInfo.new(0.25, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_489_)
				L_490_:Play()
				L_488_ = L_504_forvar1.Icon
				L_490_ = L_490_.Play
				L_491_ = L_490_
				L_492_ = L_504_forvar1.Icon
				L_493_ = TweenInfo.new(0.25, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
				L_494_ = L_489_
				L_495_ = Enum.EasingStyle.Quart
				L_496_ = Enum.EasingDirection.Out
			end
			L_488_ = next
			L_489_ = L_504_forvar1.GetChildren
			L_490_ = L_504_forvar1
			L_489_, L_490_ = L_504_forvar1:GetChildren()
			for L_505_forvar0, L_506_forvar1 in L_488_, L_489_, L_490_ do
				L_493_ = L_506_forvar1:IsA("Frame")
				L_494_ = L_506_forvar1
				L_495_ = "Frame"
				if L_493_ then
					L_493_ = L_506_forvar1.Name
					L_501_ = "Indicator"
					L_502_ = (L_506_forvar1.Name == "Indicator")
					if not (L_502_) then
						L_493_ = {}
						L_493_.BackgroundTransparency = 1
						L_494_ = upvalue_1:Create(L_506_forvar1, TweenInfo.new(0.25, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_493_)
						L_494_:Play()
						L_494_ = L_494_.Play
						L_495_ = L_494_
						L_496_ = L_506_forvar1
						L_497_ = TweenInfo.new(0.25, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
						L_498_ = L_493_
						L_499_ = Enum.EasingStyle.Quart
						L_500_ = Enum.EasingDirection.Out
					end
				end
			end
		end
	end
	L_483_ = upvalue_2.Current
	L_484_ = upvalue_2
	if L_483_ then
		L_483_ = next
		L_484_ = upvalue_2.Current.Tab.SubTabs
		L_485_ = nil
		L_486_ = upvalue_2.Current.Tab
		L_487_ = upvalue_2.Current
		L_488_ = upvalue_2
		for L_507_forvar0, L_508_forvar1 in L_483_, L_484_, L_485_ do
			L_488_ = L_508_forvar1.Btn
			L_488_.Visible = false
			L_488_ = L_508_forvar1.Page
			L_488_.Visible = false
			L_489_ = false
		end
	end
	L_484_ = {}
	L_484_.Tab = upvalue_3
	L_483_ = upvalue_2
	L_483_.Current = L_484_
	L_484_ = {}
	L_484_.ImageColor3 = upvalue_5.Accent
	L_485_ = upvalue_1:Create(upvalue_4, TweenInfo.new(0.25, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_484_)
	L_485_:Play()
	L_484_ = {}
	L_484_.BackgroundTransparency = 0
	L_485_ = upvalue_1:Create(upvalue_6, TweenInfo.new(0.25, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_484_)
	L_485_:Play()
	L_484_ = {}
	L_484_.BackgroundTransparency = 0.85
	L_485_ = upvalue_1:Create(upvalue_7, TweenInfo.new(0.25, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_484_)
	L_485_:Play()
	L_483_ = next
	L_484_ = upvalue_3.SubTabs
	L_485_ = nil
	L_486_ = upvalue_3
	L_487_ = upvalue_7
	L_488_ = TweenInfo.new(0.25, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
	L_489_ = L_484_
	L_490_ = Enum.EasingStyle.Quart
	L_491_ = Enum.EasingDirection.Out
	for L_509_forvar0, L_510_forvar1 in L_483_, L_484_, L_485_ do
		L_488_ = L_510_forvar1.Btn
		L_488_.Visible = true
		L_489_ = true
	end
	L_483_ = upvalue_3.CurrentST
	L_484_ = upvalue_3
	if L_483_ then
		upvalue_3.CurrentST:Select()
		return
	end
	L_483_ = upvalue_3.SubTabs[1]
	L_484_ = upvalue_3.SubTabs
	L_485_ = upvalue_3
	if not (L_483_) then
		return
	end
	upvalue_3.SubTabs[1]:Select()
	L_483_ = upvalue_3.SubTabs[1].Select
	L_484_ = upvalue_3.SubTabs[1]
	L_485_ = upvalue_3
	return
end

L_1_.callback_96 = function()
	local L_511_, L_512_
	upvalue_0:Select()
	return
end

L_1_.SetVisible = function(L_513_arg0, L_514_arg1)
	local L_515_
	L_515_ = upvalue_0
	L_515_.Visible = L_514_arg1
	return
end

L_1_.Select_98 = function(L_516_arg0)
	local L_517_, L_518_, L_519_, L_520_, L_521_, L_522_, L_523_, L_524_, L_525_
	L_517_ = upvalue_0.CurrentST
	L_518_ = upvalue_0
	if not (L_517_) then
		L_517_ = upvalue_0
		L_517_.CurrentST = upvalue_2
		L_517_ = upvalue_3
		L_517_.Visible = true
		L_518_ = {}
		L_518_.TextColor3 = Color3.new(1, 1, 1)
		L_519_ = upvalue_1:Create(upvalue_4, TweenInfo.new(0.2, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_518_)
		L_519_:Play()
		L_518_ = {}
		L_518_.ImageColor3 = upvalue_6.Accent
		L_519_ = upvalue_1:Create(upvalue_5, TweenInfo.new(0.2, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_518_)
		L_519_:Play()
		L_518_ = {}
		L_518_.BackgroundTransparency = 0
		L_519_ = upvalue_1:Create(upvalue_7, TweenInfo.new(0.2, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_518_)
		L_519_:Play()
		return
	end
	L_517_ = upvalue_0.CurrentST.Page
	L_517_.Visible = false
	L_518_ = {}
	L_518_.TextColor3 = Color3.fromRGB(160, 160, 160)
	L_519_ = upvalue_1:Create(upvalue_0.CurrentST.Btn.Label, TweenInfo.new(0.2, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_518_)
	L_519_:Play()
	L_518_ = {}
	L_518_.ImageColor3 = Color3.fromRGB(160, 160, 160)
	L_519_ = upvalue_1:Create(upvalue_0.CurrentST.Btn.Icon, TweenInfo.new(0.2, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_518_)
	L_519_:Play()
	L_517_ = upvalue_0.CurrentST.Btn:FindFirstChildOfClass("Frame")
	L_518_ = upvalue_0.CurrentST.Btn
	L_519_ = "Frame"
	L_520_ = L_519_
	L_521_ = upvalue_0.CurrentST.Btn.Icon
	L_522_ = TweenInfo.new(0.2, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
	L_523_ = L_518_
	L_524_ = Enum.EasingStyle.Quart
	L_525_ = Enum.EasingDirection.Out
	if not (L_517_) then
		L_517_ = upvalue_0
		L_517_.CurrentST = upvalue_2
		L_517_ = upvalue_3
		L_517_.Visible = true
		L_518_ = {}
		L_518_.TextColor3 = Color3.new(1, 1, 1)
		L_519_ = upvalue_1:Create(upvalue_4, TweenInfo.new(0.2, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_518_)
		L_519_:Play()
		L_518_ = {}
		L_518_.ImageColor3 = upvalue_6.Accent
		L_519_ = upvalue_1:Create(upvalue_5, TweenInfo.new(0.2, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_518_)
		L_519_:Play()
		L_518_ = {}
		L_518_.BackgroundTransparency = 0
		L_519_ = upvalue_1:Create(upvalue_7, TweenInfo.new(0.2, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_518_)
		L_519_:Play()
		return
	end
	L_518_ = {}
	L_518_.BackgroundTransparency = 1
	L_519_ = upvalue_1:Create(L_517_, TweenInfo.new(0.2, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_518_)
	L_519_:Play()
	L_519_ = L_519_.Play
	L_520_ = L_519_
	L_521_ = L_517_
	L_522_ = TweenInfo.new(0.2, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
	L_523_ = L_518_
	L_524_ = Enum.EasingStyle.Quart
	L_525_ = Enum.EasingDirection.Out
	L_517_ = upvalue_0
	L_517_.CurrentST = upvalue_2
	L_517_ = upvalue_3
	L_517_.Visible = true
	L_518_ = {}
	L_518_.TextColor3 = Color3.new(1, 1, 1)
	L_519_ = upvalue_1:Create(upvalue_4, TweenInfo.new(0.2, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_518_)
	L_519_:Play()
	L_518_ = {}
	L_518_.ImageColor3 = upvalue_6.Accent
	L_519_ = upvalue_1:Create(upvalue_5, TweenInfo.new(0.2, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_518_)
	L_519_:Play()
	L_518_ = {}
	L_518_.BackgroundTransparency = 0
	L_519_ = upvalue_1:Create(upvalue_7, TweenInfo.new(0.2, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_518_)
	L_519_:Play()
	return
end

L_1_.callback_99 = function()
	local L_526_, L_527_
	upvalue_0:Select()
	return
end

L_1_.callback_100 = function()
	local L_528_, L_529_, L_530_, L_531_, L_532_, L_533_, L_534_, L_535_, L_536_
	L_528_ = upvalue_0
	L_529_ = {}
	L_531_ = upvalue_1
	if L_531_ then
		L_530_ = upvalue_2.Accent
		L_531_ = upvalue_2
		if not (L_530_) then
			L_530_ = Color3.fromRGB(35, 35, 35)
			L_531_ = 35
			L_532_ = 35
			L_533_ = 35
		end
	else
		L_530_ = Color3.fromRGB(35, 35, 35)
		L_531_ = 35
		L_532_ = 35
		L_533_ = 35
	end
	L_529_.BackgroundColor3 = L_530_
	L_530_ = upvalue_3:Create(L_528_, TweenInfo.new(0.2, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_529_)
	L_530_:Play()
	L_528_ = upvalue_4
	L_529_ = {}
	L_530_ = L_530_.Play
	L_531_ = upvalue_1
	L_532_ = L_528_
	L_533_ = TweenInfo.new(0.2, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
	L_534_ = L_529_
	L_535_ = Enum.EasingStyle.Quart
	L_536_ = Enum.EasingDirection.Out
	if L_531_ then
		L_530_ = UDim2.new(1, -16, 0.5, -7)
		L_531_ = 1
		L_532_ = -16
		L_533_ = 0.5
		L_534_ = -7
		if not (L_530_) then
			L_530_ = UDim2.new(0, 2, 0.5, -7)
			L_531_ = 0
			L_532_ = 2
			L_533_ = 0.5
			L_534_ = -7
		end
	else
		L_530_ = UDim2.new(0, 2, 0.5, -7)
		L_531_ = 0
		L_532_ = 2
		L_533_ = 0.5
		L_534_ = -7
	end
	L_529_.Position = L_530_
	L_530_ = upvalue_3:Create(L_528_, TweenInfo.new(0.2, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_529_)
	L_530_:Play()
	L_528_ = upvalue_5
	L_529_ = {}
	L_530_ = L_530_.Play
	L_531_ = upvalue_1
	L_532_ = L_528_
	L_533_ = TweenInfo.new(0.2, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
	L_534_ = L_529_
	L_535_ = Enum.EasingStyle.Quart
	L_536_ = Enum.EasingDirection.Out
	if L_531_ then
		L_530_ = upvalue_2.Accent
		L_531_ = upvalue_2
		if not (L_530_) then
			L_530_ = Color3.fromRGB(225, 225, 225)
			L_531_ = 225
			L_532_ = 225
			L_533_ = 225
		end
	else
		L_530_ = Color3.fromRGB(225, 225, 225)
		L_531_ = 225
		L_532_ = 225
		L_533_ = 225
	end
	L_529_.TextColor3 = L_530_
	L_530_ = upvalue_3:Create(L_528_, TweenInfo.new(0.2, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_529_)
	L_530_:Play()
	L_528_ = upvalue_6
	L_530_ = L_530_.Play
	L_531_ = L_530_
	L_532_ = L_528_
	L_533_ = TweenInfo.new(0.2, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
	L_534_ = L_529_
	L_535_ = Enum.EasingStyle.Quart
	L_536_ = Enum.EasingDirection.Out
	if not (L_528_) then
		return
	end
	upvalue_6(upvalue_1)
	L_528_ = upvalue_6
	L_529_ = upvalue_1
	return
end

L_1_.callback_101 = function(L_537_arg0)
	local L_538_, L_539_, L_540_, L_541_
	L_538_ = L_537_arg0.UserInputType
	L_539_ = Enum.UserInputType.MouseButton1
	L_541_ = (L_537_arg0.UserInputType == Enum.UserInputType.MouseButton1)
	if L_541_ then
		upvalue_0 = not upvalue_0
		upvalue_1()
		L_538_ = upvalue_1
		L_539_ = upvalue_0
	else
		L_538_ = L_537_arg0.UserInputType
		L_539_ = Enum.UserInputType.Touch
		L_541_ = (L_537_arg0.UserInputType == Enum.UserInputType.Touch)
		if not (L_541_) then
			return
		end
		upvalue_0 = not upvalue_0
		upvalue_1()
		L_538_ = upvalue_1
		L_539_ = upvalue_0
	end
	return
end

L_1_.Set = function(L_542_arg0, L_543_arg1)
	local L_544_
	upvalue_0 = L_543_arg1
	upvalue_1()
	return
end

L_1_.CreateToggle = function(L_545_arg0, L_546_arg1, L_547_arg2, L_548_arg3)
	local L_549_, L_550_, L_551_, L_552_, L_553_, L_554_, L_555_, L_556_, L_557_, L_558_, L_559_, L_560_, L_561_
	L_550_ = {}
	L_550_.Parent = upvalue_0
	L_550_.BackgroundColor3 = Color3.fromRGB(13, 13, 13)
	L_550_.Size = UDim2.new(1, 0, 0, 42)
	L_551_ = Instance.new("Frame")
	L_552_ = next
	L_553_ = L_550_
	L_554_ = nil
	L_555_ = 42
	for L_562_forvar0, L_563_forvar1 in L_552_, L_553_, L_554_ do
		L_560_ = "Parent"
		L_561_ = (L_562_forvar0 == "Parent")
		if not (L_561_) then
			L_551_[L_562_forvar0] = L_563_forvar1
		end
	end
	L_551_.Parent = L_550_.Parent
	L_550_ = {}
	L_550_.CornerRadius = UDim.new(0, 6)
	L_550_.Parent = L_551_
	L_549_ = L_551_
	L_551_ = Instance.new("UICorner")
	L_552_ = next
	L_553_ = L_550_
	L_554_ = nil
	for L_564_forvar0, L_565_forvar1 in L_552_, L_553_, L_554_ do
		L_560_ = "Parent"
		L_561_ = (L_564_forvar0 == "Parent")
		if not (L_561_) then
			L_551_[L_564_forvar0] = L_565_forvar1
		end
	end
	L_551_.Parent = L_550_.Parent
	L_551_ = {}
	L_551_.Parent = L_549_
	L_551_.BackgroundTransparency = 1
	L_551_.Position = UDim2.new(0, 12, 0, 0)
	L_551_.Size = UDim2.new(1, -64, 1, 0)
	L_551_.Font = "Gotham"
	L_551_.Text = L_546_arg1
	L_551_.TextColor3 = Color3.fromRGB(225, 225, 225)
	L_551_.TextSize = 14
	L_551_.TextXAlignment = "Left"
	L_552_ = Instance.new("TextLabel")
	L_553_ = next
	L_554_ = L_551_
	L_555_ = nil
	L_556_ = 0
	for L_566_forvar0, L_567_forvar1 in L_553_, L_554_, L_555_ do
		L_560_ = "Parent"
		L_561_ = (L_566_forvar0 == "Parent")
		if not (L_561_) then
			L_552_[L_566_forvar0] = L_567_forvar1
		end
	end
	L_552_.Parent = L_551_.Parent
	L_552_ = {}
	L_552_.Parent = L_549_
	L_552_.AnchorPoint = Vector2.new(1, 0.5)
	L_552_.BackgroundColor3 = Color3.fromRGB(35, 35, 35)
	L_552_.Position = UDim2.new(1, -12, 0.5, 0)
	L_552_.Size = UDim2.new(0, 36, 0, 18)
	L_550_ = L_552_
	L_553_ = Instance.new("Frame")
	L_554_ = next
	L_555_ = L_552_
	L_556_ = nil
	L_557_ = 18
	for L_568_forvar0, L_569_forvar1 in L_554_, L_555_, L_556_ do
		L_560_ = "Parent"
		L_561_ = (L_568_forvar0 == "Parent")
		if not (L_561_) then
			L_553_[L_568_forvar0] = L_569_forvar1
		end
	end
	L_553_.Parent = L_552_.Parent
	L_552_ = {}
	L_552_.CornerRadius = UDim.new(1, 0)
	L_552_.Parent = L_553_
	L_551_ = L_553_
	L_553_ = Instance.new("UICorner")
	L_554_ = next
	L_555_ = L_552_
	L_556_ = nil
	for L_570_forvar0, L_571_forvar1 in L_554_, L_555_, L_556_ do
		L_560_ = "Parent"
		L_561_ = (L_570_forvar0 == "Parent")
		if not (L_561_) then
			L_553_[L_570_forvar0] = L_571_forvar1
		end
	end
	L_553_.Parent = L_552_.Parent
	L_553_ = {}
	L_553_.Parent = L_551_
	L_553_.BackgroundColor3 = Color3.new(1, 1, 1)
	L_553_.Position = UDim2.new(0, 2, 0.5, -7)
	L_553_.Size = UDim2.new(0, 14, 0, 14)
	L_554_ = Instance.new("Frame")
	L_555_ = next
	L_556_ = L_553_
	L_557_ = nil
	L_558_ = 14
	for L_572_forvar0, L_573_forvar1 in L_555_, L_556_, L_557_ do
		L_560_ = "Parent"
		L_561_ = (L_572_forvar0 == "Parent")
		if not (L_561_) then
			L_554_[L_572_forvar0] = L_573_forvar1
		end
	end
	L_554_.Parent = L_553_.Parent
	L_553_ = {}
	L_553_.CornerRadius = UDim.new(1, 0)
	L_553_.Parent = L_554_
	L_552_ = L_554_
	L_554_ = Instance.new("UICorner")
	L_555_ = next
	L_556_ = L_553_
	L_557_ = nil
	for L_574_forvar0, L_575_forvar1 in L_555_, L_556_, L_557_ do
		L_560_ = "Parent"
		L_561_ = (L_574_forvar0 == "Parent")
		if not (L_561_) then
			L_554_[L_574_forvar0] = L_575_forvar1
		end
	end
	L_554_.Parent = L_553_.Parent
	L_553_ = L_547_arg2
	L_555_ = L_553_.Parent
	if L_553_ then
		L_549_.InputBegan:Connect(L_1_.callback_101)
		L_1_.callback_100()
		L_555_ = {}
		L_555_.Set = L_1_.Set

		return L_555_
	end
	L_553_ = false
	L_549_.InputBegan:Connect(L_1_.callback_101)
	L_1_.callback_100()
	L_555_ = {}
	L_555_.Set = L_1_.Set

	return L_555_
end

L_1_.callback_104 = function()
	local L_576_
	L_576_ = upvalue_0
	if not (L_576_) then
		return
	end
	upvalue_0()
	L_576_ = upvalue_0
	return
end

L_1_.CreateButton = function(L_577_arg0, L_578_arg1, L_579_arg2)
	local L_580_, L_581_, L_582_, L_583_, L_584_, L_585_, L_586_, L_587_, L_588_, L_589_
	L_581_ = {}
	L_581_.Parent = upvalue_0
	L_581_.BackgroundColor3 = Color3.fromRGB(13, 13, 13)
	L_581_.Size = UDim2.new(1, 0, 0, 42)
	L_581_.Text = ""
	L_581_.AutoButtonColor = false
	L_582_ = Instance.new("TextButton")
	L_583_ = next
	L_584_ = L_581_
	L_585_ = nil
	L_586_ = 42
	for L_590_forvar0, L_591_forvar1 in L_583_, L_584_, L_585_ do
		L_588_ = "Parent"
		L_589_ = (L_590_forvar0 == "Parent")
		if not (L_589_) then
			L_582_[L_590_forvar0] = L_591_forvar1
		end
	end
	L_582_.Parent = L_581_.Parent
	L_581_ = {}
	L_581_.CornerRadius = UDim.new(0, 6)
	L_581_.Parent = L_582_
	L_580_ = L_582_
	L_582_ = Instance.new("UICorner")
	L_583_ = next
	L_584_ = L_581_
	L_585_ = nil
	for L_592_forvar0, L_593_forvar1 in L_583_, L_584_, L_585_ do
		L_588_ = "Parent"
		L_589_ = (L_592_forvar0 == "Parent")
		if not (L_589_) then
			L_582_[L_592_forvar0] = L_593_forvar1
		end
	end
	L_582_.Parent = L_581_.Parent
	L_581_ = {}
	L_581_.Parent = L_580_
	L_581_.BackgroundTransparency = 1
	L_581_.Size = UDim2.new(1, 0, 1, 0)
	L_581_.Font = "Gotham"
	L_581_.Text = L_578_arg1
	L_581_.TextColor3 = Color3.fromRGB(225, 225, 225)
	L_581_.TextSize = 14
	L_582_ = Instance.new("TextLabel")
	L_583_ = next
	L_584_ = L_581_
	L_585_ = nil
	L_586_ = 0
	for L_594_forvar0, L_595_forvar1 in L_583_, L_584_, L_585_ do
		L_588_ = "Parent"
		L_589_ = (L_594_forvar0 == "Parent")
		if not (L_589_) then
			L_582_[L_594_forvar0] = L_595_forvar1
		end
	end
	L_582_.Parent = L_581_.Parent
	L_580_.Activated:Connect(L_1_.callback_104)
	return L_580_
end

L_1_.callback_106 = function(L_596_arg0)
	local L_597_, L_598_, L_599_, L_600_, L_601_, L_602_, L_603_, L_604_
	L_599_ = upvalue_3
	L_599_.Size = UDim2.new(math.clamp(((L_596_arg0.Position.X - upvalue_0.AbsolutePosition.X) / upvalue_0.AbsoluteSize.X), 0, 1), 0, 1, 0)
	L_599_ = upvalue_4
	L_599_.Text = tostring(math.floor((upvalue_1 + ((upvalue_2 - upvalue_1) * math.clamp(((L_596_arg0.Position.X - upvalue_0.AbsolutePosition.X) / upvalue_0.AbsoluteSize.X), 0, 1)))))
	upvalue_5(math.floor((upvalue_1 + ((upvalue_2 - upvalue_1) * math.clamp(((L_596_arg0.Position.X - upvalue_0.AbsolutePosition.X) / upvalue_0.AbsoluteSize.X), 0, 1)))))
	return
end

L_1_.callback_107 = function(L_605_arg0)
	local L_606_, L_607_, L_608_, L_609_
	L_606_ = L_605_arg0.UserInputType
	L_607_ = Enum.UserInputType.MouseButton1
	L_609_ = (L_605_arg0.UserInputType == Enum.UserInputType.MouseButton1)
	if L_609_ then
		upvalue_0 = true
		upvalue_1(L_605_arg0)
		L_606_ = upvalue_1
		L_607_ = L_605_arg0
	else
		L_606_ = L_605_arg0.UserInputType
		L_607_ = Enum.UserInputType.Touch
		L_609_ = (L_605_arg0.UserInputType == Enum.UserInputType.Touch)
		if not (L_609_) then
			return
		end
		upvalue_0 = true
		upvalue_1(L_605_arg0)
		L_606_ = upvalue_1
		L_607_ = L_605_arg0
	end
	return
end

L_1_.callback_108 = function(L_610_arg0)
	local L_611_, L_612_, L_613_, L_614_
	L_611_ = L_610_arg0.UserInputType
	L_612_ = Enum.UserInputType.MouseButton1
	L_614_ = (L_610_arg0.UserInputType == Enum.UserInputType.MouseButton1)
	if L_614_ then
		upvalue_0 = false
		L_611_ = false
	else
		L_611_ = L_610_arg0.UserInputType
		L_612_ = Enum.UserInputType.Touch
		L_614_ = (L_610_arg0.UserInputType == Enum.UserInputType.Touch)
		if not (L_614_) then
			return
		end
		upvalue_0 = false
		L_611_ = false
	end
	return
end

L_1_.callback_109 = function(L_615_arg0)
	local L_616_, L_617_, L_618_, L_619_
	L_616_ = upvalue_0
	if not (L_616_) then
		return
	end
	L_616_ = L_615_arg0.UserInputType
	L_617_ = Enum.UserInputType.MouseMovement
	L_619_ = (L_615_arg0.UserInputType == Enum.UserInputType.MouseMovement)
	if L_619_ then
		upvalue_1(L_615_arg0)
		L_616_ = upvalue_1
		L_617_ = L_615_arg0
	else
		L_616_ = L_615_arg0.UserInputType
		L_617_ = Enum.UserInputType.Touch
		L_619_ = (L_615_arg0.UserInputType == Enum.UserInputType.Touch)
		if not (L_619_) then
			return
		end
		upvalue_1(L_615_arg0)
		L_616_ = upvalue_1
		L_617_ = L_615_arg0
	end
	return
end

L_1_.Set_110 = function(L_620_arg0, L_621_arg1)
	local L_622_, L_623_, L_624_, L_625_, L_626_, L_627_, L_628_
	L_623_ = upvalue_2
	L_623_.Size = UDim2.new(((L_621_arg1 - upvalue_0) / (upvalue_1 - upvalue_0)), 0, 1, 0)
	L_623_ = upvalue_3
	L_623_.Text = tostring(L_621_arg1)
	upvalue_4(L_621_arg1)
	return
end

L_1_.CreateSlider = function(L_629_arg0, L_630_arg1, L_631_arg2, L_632_arg3, L_633_arg4, L_634_arg5)
	local L_635_, L_636_, L_637_, L_638_, L_639_, L_640_, L_641_, L_642_, L_643_, L_644_, L_645_, L_646_, L_647_, L_648_
	L_636_ = {}
	L_636_.Parent = upvalue_0
	L_636_.BackgroundColor3 = Color3.fromRGB(13, 13, 13)
	L_636_.Size = UDim2.new(1, 0, 0, 50)
	L_637_ = Instance.new("Frame")
	L_638_ = next
	L_639_ = L_636_
	L_640_ = nil
	L_641_ = 50
	for L_649_forvar0, L_650_forvar1 in L_638_, L_639_, L_640_ do
		L_647_ = "Parent"
		L_648_ = (L_649_forvar0 == "Parent")
		if not (L_648_) then
			L_637_[L_649_forvar0] = L_650_forvar1
		end
	end
	L_637_.Parent = L_636_.Parent
	L_636_ = {}
	L_636_.CornerRadius = UDim.new(0, 6)
	L_636_.Parent = L_637_
	L_635_ = L_637_
	L_637_ = Instance.new("UICorner")
	L_638_ = next
	L_639_ = L_636_
	L_640_ = nil
	for L_651_forvar0, L_652_forvar1 in L_638_, L_639_, L_640_ do
		L_647_ = "Parent"
		L_648_ = (L_651_forvar0 == "Parent")
		if not (L_648_) then
			L_637_[L_651_forvar0] = L_652_forvar1
		end
	end
	L_637_.Parent = L_636_.Parent
	L_636_ = {}
	L_636_.Parent = L_635_
	L_636_.BackgroundTransparency = 1
	L_636_.Position = UDim2.new(0, 12, 0, 0)
	L_636_.Size = UDim2.new(1, -64, 0, 28)
	L_636_.Font = "Gotham"
	L_636_.Text = L_630_arg1
	L_636_.TextColor3 = Color3.fromRGB(225, 225, 225)
	L_636_.TextSize = 14
	L_636_.TextXAlignment = "Left"
	L_637_ = Instance.new("TextLabel")
	L_638_ = next
	L_639_ = L_636_
	L_640_ = nil
	L_641_ = 28
	for L_653_forvar0, L_654_forvar1 in L_638_, L_639_, L_640_ do
		L_647_ = "Parent"
		L_648_ = (L_653_forvar0 == "Parent")
		if not (L_648_) then
			L_637_[L_653_forvar0] = L_654_forvar1
		end
	end
	L_637_.Parent = L_636_.Parent
	L_637_ = {}
	L_637_.Parent = L_635_
	L_637_.BackgroundTransparency = 1
	L_637_.Position = UDim2.new(1, -60, 0, 0)
	L_637_.Size = UDim2.new(0, 48, 0, 24)
	L_637_.Font = "GothamBold"
	L_637_.Text = tostring(L_633_arg4)
	L_637_.TextColor3 = upvalue_1.Accent
	L_637_.TextSize = 13
	L_637_.TextXAlignment = "Right"
	L_638_ = Instance.new("TextLabel")
	L_639_ = next
	L_640_ = L_637_
	L_641_ = nil
	L_642_ = 24
	for L_655_forvar0, L_656_forvar1 in L_639_, L_640_, L_641_ do
		L_647_ = "Parent"
		L_648_ = (L_655_forvar0 == "Parent")
		if not (L_648_) then
			L_638_[L_655_forvar0] = L_656_forvar1
		end
	end
	L_638_.Parent = L_637_.Parent
	L_638_ = {}
	L_638_.Parent = L_635_
	L_638_.BackgroundColor3 = Color3.fromRGB(35, 35, 35)
	L_638_.Position = UDim2.new(0, 12, 0, 32)
	L_638_.Size = UDim2.new(1, -24, 0, 6)
	L_636_ = L_638_
	L_639_ = Instance.new("Frame")
	L_640_ = next
	L_641_ = L_638_
	L_642_ = nil
	L_643_ = 6
	for L_657_forvar0, L_658_forvar1 in L_640_, L_641_, L_642_ do
		L_647_ = "Parent"
		L_648_ = (L_657_forvar0 == "Parent")
		if not (L_648_) then
			L_639_[L_657_forvar0] = L_658_forvar1
		end
	end
	L_639_.Parent = L_638_.Parent
	L_638_ = {}
	L_638_.CornerRadius = UDim.new(1, 0)
	L_638_.Parent = L_639_
	L_637_ = L_639_
	L_639_ = Instance.new("UICorner")
	L_640_ = next
	L_641_ = L_638_
	L_642_ = nil
	for L_659_forvar0, L_660_forvar1 in L_640_, L_641_, L_642_ do
		L_647_ = "Parent"
		L_648_ = (L_659_forvar0 == "Parent")
		if not (L_648_) then
			L_639_[L_659_forvar0] = L_660_forvar1
		end
	end
	L_639_.Parent = L_638_.Parent
	L_639_ = {}
	L_639_.Parent = L_637_
	L_639_.BackgroundColor3 = upvalue_1.Accent
	L_639_.Size = UDim2.new(((L_633_arg4 - L_631_arg2) / (L_632_arg3 - L_631_arg2)), 0, 1, 0)
	L_640_ = Instance.new("Frame")
	L_641_ = next
	L_642_ = L_639_
	L_643_ = nil
	L_644_ = 0
	for L_661_forvar0, L_662_forvar1 in L_641_, L_642_, L_643_ do
		L_647_ = "Parent"
		L_648_ = (L_661_forvar0 == "Parent")
		if not (L_648_) then
			L_640_[L_661_forvar0] = L_662_forvar1
		end
	end
	L_640_.Parent = L_639_.Parent
	L_639_ = {}
	L_639_.CornerRadius = UDim.new(1, 0)
	L_639_.Parent = L_640_
	L_638_ = L_640_
	L_640_ = Instance.new("UICorner")
	L_641_ = next
	L_642_ = L_639_
	L_643_ = nil
	for L_663_forvar0, L_664_forvar1 in L_641_, L_642_, L_643_ do
		L_647_ = "Parent"
		L_648_ = (L_663_forvar0 == "Parent")
		if not (L_648_) then
			L_640_[L_663_forvar0] = L_664_forvar1
		end
	end
	L_640_.Parent = L_639_.Parent
	L_640_ = {}
	L_640_.Parent = L_638_
	L_640_.AnchorPoint = Vector2.new(1, 0.5)
	L_640_.BackgroundColor3 = Color3.new(1, 1, 1)
	L_640_.Position = UDim2.new(1, 0, 0.5, 0)
	L_640_.Size = UDim2.new(0, 12, 0, 12)
	L_641_ = Instance.new("Frame")
	L_642_ = next
	L_643_ = L_640_
	L_644_ = nil
	L_645_ = 12
	for L_665_forvar0, L_666_forvar1 in L_642_, L_643_, L_644_ do
		L_647_ = "Parent"
		L_648_ = (L_665_forvar0 == "Parent")
		if not (L_648_) then
			L_641_[L_665_forvar0] = L_666_forvar1
		end
	end
	L_641_.Parent = L_640_.Parent
	L_640_ = {}
	L_640_.CornerRadius = UDim.new(1, 0)
	L_640_.Parent = L_641_
	L_639_ = L_641_
	L_641_ = Instance.new("UICorner")
	L_642_ = next
	L_643_ = L_640_
	L_644_ = nil
	for L_667_forvar0, L_668_forvar1 in L_642_, L_643_, L_644_ do
		L_647_ = "Parent"
		L_648_ = (L_667_forvar0 == "Parent")
		if not (L_648_) then
			L_641_[L_667_forvar0] = L_668_forvar1
		end
	end
	L_641_.Parent = L_640_.Parent
	L_637_.InputBegan:Connect(L_1_.callback_107)
	upvalue_2.InputEnded:Connect(L_1_.callback_108)
	upvalue_2.InputChanged:Connect(L_1_.callback_109)
	L_642_ = {}
	L_642_.Set = L_1_.Set_110

	return L_642_
end

L_1_.callback_112 = function()
	local L_669_, L_670_, L_671_, L_672_, L_673_, L_674_, L_675_, L_676_, L_677_
	L_669_ = upvalue_0
	L_669_.Text = upvalue_1 .. ": " .. tostring(upvalue_2)
	upvalue_3 = false
	L_669_ = upvalue_4
	L_669_.Text = "\u{25bc}"
	L_670_ = {}
	L_670_.Size = UDim2.new(1, 0, 0, 42)
	L_671_ = upvalue_6:Create(upvalue_5, TweenInfo.new(0.25, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_670_)
	L_671_:Play()
	L_669_ = upvalue_7
	L_671_ = L_671_.Play
	L_672_ = L_671_
	L_673_ = upvalue_5
	L_674_ = TweenInfo.new(0.25, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
	L_675_ = L_670_
	L_676_ = Enum.EasingStyle.Quart
	L_677_ = Enum.EasingDirection.Out
	if not (L_669_) then
		return
	end
	upvalue_7(upvalue_2)
	L_669_ = upvalue_7
	L_670_ = upvalue_2
	return
end

L_1_.callback_113 = function(L_678_arg0)
	local L_679_, L_680_, L_681_, L_682_, L_683_, L_684_, L_685_, L_686_, L_687_, L_688_, L_689_, L_690_, L_691_, L_692_, L_693_
	L_679_ = next
	L_680_ = upvalue_0.GetChildren
	L_681_ = upvalue_0
	L_680_, L_681_ = upvalue_0:GetChildren()
	for L_694_forvar0, L_695_forvar1 in L_679_, L_680_, L_681_ do
		L_684_ = L_695_forvar1:IsA("TextButton")
		L_685_ = L_695_forvar1
		L_686_ = "TextButton"
		if L_684_ then
			L_695_forvar1:Destroy()
			L_684_ = L_695_forvar1.Destroy
			L_685_ = L_695_forvar1
		end
	end
	L_679_ = next
	L_680_ = L_678_arg0
	L_681_ = nil
	for L_696_forvar0, L_697_forvar1 in L_679_, L_680_, L_681_ do
		L_685_ = {}
		L_685_.Parent = upvalue_0
		L_685_.BackgroundColor3 = Color3.fromRGB(22, 22, 22)
		L_685_.Size = UDim2.new(1, 0, 0, 28)
		L_685_.Font = "Gotham"
		L_685_.Text = tostring(L_697_forvar1)
		L_685_.TextColor3 = Color3.fromRGB(200, 200, 200)
		L_685_.TextSize = 13
		L_685_.AutoButtonColor = true
		L_686_ = Instance.new("TextButton")
		L_687_ = next
		L_688_ = L_685_
		L_689_ = nil
		L_690_ = 28
		for L_698_forvar0, L_699_forvar1 in L_687_, L_688_, L_689_ do
			L_692_ = "Parent"
			L_693_ = (L_698_forvar0 == "Parent")
			if not (L_693_) then
				L_686_[L_698_forvar0] = L_699_forvar1
			end
		end
		L_686_.Parent = L_685_.Parent
		L_685_ = {}
		L_685_.CornerRadius = UDim.new(0, 4)
		L_685_.Parent = L_686_
		L_684_ = L_686_
		L_686_ = Instance.new("UICorner")
		L_687_ = next
		L_688_ = L_685_
		L_689_ = nil
		for L_700_forvar0, L_701_forvar1 in L_687_, L_688_, L_689_ do
			L_692_ = "Parent"
			L_693_ = (L_700_forvar0 == "Parent")
			if not (L_693_) then
				L_686_[L_700_forvar0] = L_701_forvar1
			end
		end
		L_686_.Parent = L_685_.Parent
		L_684_.Activated:Connect(L_1_.callback_112)
		L_685_ = L_684_.Activated.Connect
		L_686_ = L_684_.Activated
		L_687_ = L_1_.callback_112
	end
	return
end

L_1_.callback_114 = function(L_702_arg0)
	local L_703_, L_704_, L_705_, L_706_, L_707_, L_708_, L_709_, L_710_, L_711_, L_712_, L_713_, L_714_
	L_703_ = L_702_arg0.UserInputType
	L_704_ = Enum.UserInputType.MouseButton1
	L_714_ = (L_702_arg0.UserInputType == Enum.UserInputType.MouseButton1)
	if L_714_ then
		L_703_ = L_702_arg0.Position.Y
		L_704_ = (upvalue_0.AbsolutePosition.Y + 42)
		L_705_ = upvalue_0.AbsolutePosition.Y
		L_706_ = upvalue_0.AbsolutePosition
		L_707_ = upvalue_0
		L_714_ = (L_702_arg0.Position.Y < (upvalue_0.AbsolutePosition.Y + 42))
		if not (L_714_) then
			return
		end
		upvalue_1 = not upvalue_1
		L_703_ = upvalue_2
		L_704_ = upvalue_1
		L_705_ = upvalue_1
		if L_705_ then
			L_704_ = "\u{25b2}"
		else
			L_704_ = "\u{25bc}"
		end
		L_703_.Text = L_704_
		L_704_ = upvalue_1
		if L_704_ then
			L_703_ = ((42 + upvalue_3.UIListLayout.AbsoluteContentSize.Y) + 8)
			L_704_ = (42 + upvalue_3.UIListLayout.AbsoluteContentSize.Y)
			L_705_ = 42
			L_706_ = upvalue_3.UIListLayout.AbsoluteContentSize.Y
			L_707_ = upvalue_3.UIListLayout.AbsoluteContentSize
			L_708_ = upvalue_3.UIListLayout
			L_709_ = upvalue_3
			if not (L_703_) then
				L_703_ = 42
			end
		else
			L_703_ = 42
		end
		L_705_ = {}
		L_705_.Size = UDim2.new(1, 0, 0, L_703_)
		L_706_ = upvalue_4:Create(upvalue_0, TweenInfo.new(0.25, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_705_)
		L_706_:Play()
		L_704_ = upvalue_0
		L_706_ = L_706_.Play
		L_707_ = L_706_
		L_708_ = upvalue_0
		L_709_ = TweenInfo.new(0.25, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
		L_710_ = L_705_
		L_711_ = Enum.EasingStyle.Quart
		L_712_ = Enum.EasingDirection.Out
	else
		L_703_ = L_702_arg0.UserInputType
		L_704_ = Enum.UserInputType.Touch
		L_714_ = (L_702_arg0.UserInputType == Enum.UserInputType.Touch)
		if not (L_714_) then
			return
		end
		L_703_ = L_702_arg0.Position.Y
		L_704_ = (upvalue_0.AbsolutePosition.Y + 42)
		L_705_ = upvalue_0.AbsolutePosition.Y
		L_706_ = upvalue_0.AbsolutePosition
		L_707_ = upvalue_0
		L_714_ = (L_702_arg0.Position.Y < (upvalue_0.AbsolutePosition.Y + 42))
		if not (L_714_) then
			return
		end
		upvalue_1 = not upvalue_1
		L_703_ = upvalue_2
		L_704_ = upvalue_1
		L_705_ = upvalue_1
		if L_705_ then
			L_704_ = "\u{25b2}"
		else
			L_704_ = "\u{25bc}"
		end
		L_703_.Text = L_704_
		L_704_ = upvalue_1
		if L_704_ then
			L_703_ = ((42 + upvalue_3.UIListLayout.AbsoluteContentSize.Y) + 8)
			L_704_ = (42 + upvalue_3.UIListLayout.AbsoluteContentSize.Y)
			L_705_ = 42
			L_706_ = upvalue_3.UIListLayout.AbsoluteContentSize.Y
			L_707_ = upvalue_3.UIListLayout.AbsoluteContentSize
			L_708_ = upvalue_3.UIListLayout
			L_709_ = upvalue_3
			if not (L_703_) then
				L_703_ = 42
			end
		else
			L_703_ = 42
		end
		L_705_ = {}
		L_705_.Size = UDim2.new(1, 0, 0, L_703_)
		L_706_ = upvalue_4:Create(upvalue_0, TweenInfo.new(0.25, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_705_)
		L_706_:Play()
		L_704_ = upvalue_0
		L_706_ = L_706_.Play
		L_707_ = L_706_
		L_708_ = upvalue_0
		L_709_ = TweenInfo.new(0.25, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
		L_710_ = L_705_
		L_711_ = Enum.EasingStyle.Quart
		L_712_ = Enum.EasingDirection.Out
	end
	return
end

L_1_.Refresh = function(L_715_arg0, L_716_arg1)
	local L_717_, L_718_
	upvalue_0(L_716_arg1)
	return
end

L_1_.CreateDropdown = function(L_719_arg0, L_720_arg1, L_721_arg2, L_722_arg3, L_723_arg4)
	local L_724_, L_725_, L_726_, L_727_, L_728_, L_729_, L_730_, L_731_, L_732_, L_733_, L_734_, L_735_, L_736_
	L_725_ = {}
	L_725_.Parent = upvalue_0
	L_725_.BackgroundColor3 = Color3.fromRGB(13, 13, 13)
	L_725_.Size = UDim2.new(1, 0, 0, 42)
	L_725_.ClipsDescendants = true
	L_726_ = Instance.new("Frame")
	L_727_ = next
	L_728_ = L_725_
	L_729_ = nil
	L_730_ = 42
	for L_737_forvar0, L_738_forvar1 in L_727_, L_728_, L_729_ do
		L_735_ = "Parent"
		L_736_ = (L_737_forvar0 == "Parent")
		if not (L_736_) then
			L_726_[L_737_forvar0] = L_738_forvar1
		end
	end
	L_726_.Parent = L_725_.Parent
	L_725_ = {}
	L_725_.CornerRadius = UDim.new(0, 6)
	L_725_.Parent = L_726_
	L_724_ = L_726_
	L_726_ = Instance.new("UICorner")
	L_727_ = next
	L_728_ = L_725_
	L_729_ = nil
	for L_739_forvar0, L_740_forvar1 in L_727_, L_728_, L_729_ do
		L_735_ = "Parent"
		L_736_ = (L_739_forvar0 == "Parent")
		if not (L_736_) then
			L_726_[L_739_forvar0] = L_740_forvar1
		end
	end
	L_726_.Parent = L_725_.Parent
	L_725_ = {}
	L_725_.Color = Color3.fromRGB(28, 28, 36)
	L_725_.Thickness = 1
	L_725_.Parent = L_724_
	L_726_ = Instance.new("UIStroke")
	L_727_ = next
	L_728_ = L_725_
	L_729_ = nil
	for L_741_forvar0, L_742_forvar1 in L_727_, L_728_, L_729_ do
		L_735_ = "Parent"
		L_736_ = (L_741_forvar0 == "Parent")
		if not (L_736_) then
			L_726_[L_741_forvar0] = L_742_forvar1
		end
	end
	L_726_.Parent = L_725_.Parent
	L_726_ = {}
	L_726_.Parent = L_724_
	L_726_.BackgroundTransparency = 1
	L_726_.Position = UDim2.new(0, 12, 0, 0)
	L_726_.Size = UDim2.new(1, -52, 0, 42)
	L_726_.Font = "Gotham"
	L_727_ = "Gotham"
	L_728_ = 1
	L_729_ = -52
	L_730_ = 0
	L_731_ = 42
	if L_722_arg3 then
		L_727_ = L_720_arg1 .. ": " .. tostring(L_722_arg3)
		L_728_ = L_720_arg1
		L_729_ = ": "
		L_730_ = tostring(L_722_arg3)
		L_731_ = L_722_arg3
		if not (L_727_) then
			L_727_ = L_720_arg1 .. ": Select Option"
			L_728_ = L_720_arg1
			L_729_ = ": Select Option"
		end
	else
		L_727_ = L_720_arg1 .. ": Select Option"
		L_728_ = L_720_arg1
		L_729_ = ": Select Option"
	end
	L_726_.Text = L_727_
	L_726_.TextColor3 = Color3.fromRGB(225, 225, 225)
	L_726_.TextSize = 13
	L_726_.TextXAlignment = "Left"
	L_727_ = Instance.new("TextLabel")
	L_728_ = next
	L_729_ = L_726_
	L_730_ = nil
	for L_743_forvar0, L_744_forvar1 in L_728_, L_729_, L_730_ do
		L_735_ = "Parent"
		L_736_ = (L_743_forvar0 == "Parent")
		if not (L_736_) then
			L_727_[L_743_forvar0] = L_744_forvar1
		end
	end
	L_727_.Parent = L_726_.Parent
	L_727_ = {}
	L_727_.Parent = L_724_
	L_727_.BackgroundTransparency = 1
	L_727_.Position = UDim2.new(1, -38, 0, 0)
	L_727_.Size = UDim2.new(0, 28, 0, 42)
	L_727_.Font = "GothamBold"
	L_727_.Text = "\u{25bc}"
	L_725_ = L_727_
	L_728_ = upvalue_1.Accent
	L_729_ = upvalue_1
	L_730_ = 28
	L_731_ = 0
	L_732_ = 42
	if not (L_728_) then
		L_728_ = Color3.fromRGB(0, 162, 255)
		L_729_ = 0
		L_730_ = 162
		L_731_ = 255
	end
	L_727_.TextColor3 = L_728_
	L_727_.TextSize = 16
	L_728_ = Instance.new("TextLabel")
	L_729_ = next
	L_730_ = L_727_
	L_731_ = nil
	for L_745_forvar0, L_746_forvar1 in L_729_, L_730_, L_731_ do
		L_735_ = "Parent"
		L_736_ = (L_745_forvar0 == "Parent")
		if not (L_736_) then
			L_728_[L_745_forvar0] = L_746_forvar1
		end
	end
	L_728_.Parent = L_727_.Parent
	L_728_ = {}
	L_728_.Parent = L_724_
	L_728_.BackgroundTransparency = 1
	L_728_.Position = UDim2.new(0, 6, 0, 42)
	L_728_.Size = UDim2.new(1, -12, 0, 0)
	L_726_ = L_728_
	L_729_ = Instance.new("Frame")
	L_730_ = next
	L_731_ = L_728_
	L_732_ = nil
	L_733_ = 0
	for L_747_forvar0, L_748_forvar1 in L_730_, L_731_, L_732_ do
		L_735_ = "Parent"
		L_736_ = (L_747_forvar0 == "Parent")
		if not (L_736_) then
			L_729_[L_747_forvar0] = L_748_forvar1
		end
	end
	L_729_.Parent = L_728_.Parent
	L_728_ = {}
	L_728_.Parent = L_729_
	L_728_.Padding = UDim.new(0, 3)
	L_727_ = L_729_
	L_729_ = Instance.new("UIListLayout")
	L_730_ = next
	L_731_ = L_728_
	L_732_ = nil
	for L_749_forvar0, L_750_forvar1 in L_730_, L_731_, L_732_ do
		L_735_ = "Parent"
		L_736_ = (L_749_forvar0 == "Parent")
		if not (L_736_) then
			L_729_[L_749_forvar0] = L_750_forvar1
		end
	end
	L_729_.Parent = L_728_.Parent
	L_1_.callback_113(L_721_arg2)
	L_724_.InputBegan:Connect(L_1_.callback_114)
	L_730_ = {}
	L_730_.Refresh = L_1_.Refresh

	return L_730_
end

L_1_.Set_117 = function(L_751_arg0, L_752_arg1)
	local L_753_, L_754_, L_755_, L_756_, L_757_
	L_754_ = L_752_arg1:gsub("^\u{2500}\u{2500}%s*", "")
	L_753_ = upvalue_0
	L_753_.Text = L_754_:gsub("%s*\u{2500}\u{2500}$", "")
	return
end

L_1_.Set_118 = function(L_758_arg0, L_759_arg1)
	local L_760_
	L_760_ = upvalue_0
	L_760_.Text = L_759_arg1
	return
end

L_1_.CreateLabel = function(L_761_arg0, L_762_arg1)
	local L_763_, L_764_, L_765_, L_766_, L_767_, L_768_, L_769_, L_770_, L_771_, L_772_, L_773_, L_774_, L_775_
	L_763_ = true
	L_764_ = L_762_arg1:sub(1, 2)
	L_765_ = L_762_arg1
	L_766_ = 1
	L_767_ = 2
	L_774_ = "\u{2500}\u{2500}"
	L_775_ = (L_762_arg1:sub(1, 2) == "\u{2500}\u{2500}")
	if not (L_775_) then
		L_764_ = L_762_arg1:sub(1, 1)
		L_765_ = L_762_arg1
		L_766_ = 1
		L_767_ = 1
		L_774_ = "\u{2726}"
		L_775_ = (L_762_arg1:sub(1, 1) == "\u{2726}")
		if L_775_ then
			L_763_ = true
		else
			L_763_ = false
		end
	end
	if L_763_ then
		L_764_ = L_762_arg1:gsub("^\u{2500}\u{2500}%s*", "")
		L_766_ = {}
		L_766_.Parent = upvalue_0
		L_766_.BackgroundTransparency = 1
		L_766_.Size = UDim2.new(1, 0, 0, 26)
		L_764_ = L_764_:gsub("%s*\u{2500}\u{2500}$", "")
		L_765_ = L_764_
		L_767_ = Instance.new("Frame")
		L_768_ = next
		L_769_ = L_766_
		L_770_ = nil
		L_771_ = 26
		for L_776_forvar0, L_777_forvar1 in L_768_, L_769_, L_770_ do
			L_774_ = "Parent"
			L_775_ = (L_776_forvar0 == "Parent")
			if not (L_775_) then
				L_767_[L_776_forvar0] = L_777_forvar1
			end
		end
		L_767_.Parent = L_766_.Parent
		L_767_ = {}
		L_767_.Parent = L_767_
		L_767_.BackgroundTransparency = 1
		L_767_.Position = UDim2.new(0, 4, 0, 4)
		L_767_.Size = UDim2.new(1, -8, 1, -4)
		L_767_.Font = "GothamBold"
		L_767_.Text = L_764_
		L_765_ = L_767_
		L_768_ = upvalue_1.Accent
		L_769_ = upvalue_1
		L_770_ = -8
		L_771_ = 1
		L_772_ = -4
		if not (L_768_) then
			L_768_ = Color3.fromRGB(0, 162, 255)
			L_769_ = 0
			L_770_ = 162
			L_771_ = 255
		end
		L_767_.TextColor3 = L_768_
		L_767_.TextSize = 12
		L_767_.TextXAlignment = "Left"
		L_768_ = Instance.new("TextLabel")
		L_769_ = next
		L_770_ = L_767_
		L_771_ = nil
		for L_778_forvar0, L_779_forvar1 in L_769_, L_770_, L_771_ do
			L_774_ = "Parent"
			L_775_ = (L_778_forvar0 == "Parent")
			if not (L_775_) then
				L_768_[L_778_forvar0] = L_779_forvar1
			end
		end
		L_768_.Parent = L_767_.Parent
		L_767_ = {}
		L_767_.Set = L_1_.Set_117
		return L_767_
	else
		L_765_ = {}
		L_765_.Parent = upvalue_0
		L_765_.BackgroundColor3 = Color3.fromRGB(13, 13, 13)
		L_765_.Size = UDim2.new(1, 0, 0, 32)
		L_766_ = Instance.new("Frame")
		L_767_ = next
		L_768_ = L_765_
		L_769_ = nil
		L_770_ = 32
		for L_780_forvar0, L_781_forvar1 in L_767_, L_768_, L_769_ do
			L_774_ = "Parent"
			L_775_ = (L_780_forvar0 == "Parent")
			if not (L_775_) then
				L_766_[L_780_forvar0] = L_781_forvar1
			end
		end
		L_766_.Parent = L_765_.Parent
		L_765_ = {}
		L_765_.CornerRadius = UDim.new(0, 6)
		L_765_.Parent = L_766_
		L_764_ = L_766_
		L_766_ = Instance.new("UICorner")
		L_767_ = next
		L_768_ = L_765_
		L_769_ = nil
		for L_782_forvar0, L_783_forvar1 in L_767_, L_768_, L_769_ do
			L_774_ = "Parent"
			L_775_ = (L_782_forvar0 == "Parent")
			if not (L_775_) then
				L_766_[L_782_forvar0] = L_783_forvar1
			end
		end
		L_766_.Parent = L_765_.Parent
		L_766_ = {}
		L_766_.Parent = L_764_
		L_766_.BackgroundTransparency = 1
		L_766_.Position = UDim2.new(0, 12, 0, 0)
		L_766_.Size = UDim2.new(1, -24, 1, 0)
		L_766_.Font = "Gotham"
		L_766_.Text = L_762_arg1
		L_766_.TextColor3 = Color3.fromRGB(180, 180, 180)
		L_766_.TextSize = 13
		L_766_.TextXAlignment = "Left"
		L_767_ = Instance.new("TextLabel")
		L_768_ = next
		L_769_ = L_766_
		L_770_ = nil
		L_771_ = 0
		for L_784_forvar0, L_785_forvar1 in L_768_, L_769_, L_770_ do
			L_774_ = "Parent"
			L_775_ = (L_784_forvar0 == "Parent")
			if not (L_775_) then
				L_767_[L_784_forvar0] = L_785_forvar1
			end
		end
		L_767_.Parent = L_766_.Parent
		L_766_ = {}
		L_766_.Set = L_1_.Set_118
		return L_766_
	end
end

L_1_.callback_120 = function(L_786_arg0)
	local L_787_, L_788_, L_789_
	L_787_ = upvalue_0
	if not (L_787_) then
		return
	end
	upvalue_0(upvalue_1.Text)
	L_787_ = upvalue_0
	L_788_ = upvalue_1.Text
	L_789_ = upvalue_1
	return
end

L_1_.Set_121 = function(L_790_arg0, L_791_arg1)
	local L_792_, L_793_, L_794_
	L_792_ = upvalue_0
	L_792_.Text = tostring(L_791_arg1)
	return
end

L_1_.CreateInput = function(L_795_arg0, L_796_arg1, L_797_arg2, L_798_arg3)
	local L_799_, L_800_, L_801_, L_802_, L_803_, L_804_, L_805_, L_806_, L_807_, L_808_, L_809_, L_810_
	L_800_ = {}
	L_800_.Parent = upvalue_0
	L_800_.BackgroundColor3 = Color3.fromRGB(13, 13, 13)
	L_800_.Size = UDim2.new(1, 0, 0, 42)
	L_801_ = Instance.new("Frame")
	L_802_ = next
	L_803_ = L_800_
	L_804_ = nil
	L_805_ = 42
	for L_811_forvar0, L_812_forvar1 in L_802_, L_803_, L_804_ do
		L_809_ = "Parent"
		L_810_ = (L_811_forvar0 == "Parent")
		if not (L_810_) then
			L_801_[L_811_forvar0] = L_812_forvar1
		end
	end
	L_801_.Parent = L_800_.Parent
	L_800_ = {}
	L_800_.CornerRadius = UDim.new(0, 6)
	L_800_.Parent = L_801_
	L_799_ = L_801_
	L_801_ = Instance.new("UICorner")
	L_802_ = next
	L_803_ = L_800_
	L_804_ = nil
	for L_813_forvar0, L_814_forvar1 in L_802_, L_803_, L_804_ do
		L_809_ = "Parent"
		L_810_ = (L_813_forvar0 == "Parent")
		if not (L_810_) then
			L_801_[L_813_forvar0] = L_814_forvar1
		end
	end
	L_801_.Parent = L_800_.Parent
	L_800_ = {}
	L_800_.Color = Color3.fromRGB(28, 28, 36)
	L_800_.Thickness = 1
	L_800_.Parent = L_799_
	L_801_ = Instance.new("UIStroke")
	L_802_ = next
	L_803_ = L_800_
	L_804_ = nil
	for L_815_forvar0, L_816_forvar1 in L_802_, L_803_, L_804_ do
		L_809_ = "Parent"
		L_810_ = (L_815_forvar0 == "Parent")
		if not (L_810_) then
			L_801_[L_815_forvar0] = L_816_forvar1
		end
	end
	L_801_.Parent = L_800_.Parent
	L_801_ = {}
	L_801_.Parent = L_799_
	L_801_.BackgroundTransparency = 1
	L_801_.Position = UDim2.new(0, 12, 0, 0)
	L_801_.Size = UDim2.new(0.4, -12, 1, 0)
	L_801_.Font = "Gotham"
	L_801_.Text = L_796_arg1
	L_801_.TextColor3 = Color3.fromRGB(225, 225, 225)
	L_801_.TextSize = 13
	L_801_.TextXAlignment = "Left"
	L_802_ = Instance.new("TextLabel")
	L_803_ = next
	L_804_ = L_801_
	L_805_ = nil
	L_806_ = 0
	for L_817_forvar0, L_818_forvar1 in L_803_, L_804_, L_805_ do
		L_809_ = "Parent"
		L_810_ = (L_817_forvar0 == "Parent")
		if not (L_810_) then
			L_802_[L_817_forvar0] = L_818_forvar1
		end
	end
	L_802_.Parent = L_801_.Parent
	L_802_ = {}
	L_802_.Parent = L_799_
	L_802_.BackgroundColor3 = Color3.fromRGB(22, 22, 22)
	L_802_.Position = UDim2.new(0.4, 0, 0.15, 0)
	L_802_.Size = UDim2.new(0.6, -12, 0.7, 0)
	L_802_.Font = "Gotham"
	L_800_ = L_802_
	L_803_ = L_797_arg2
	L_804_ = 0.6
	L_805_ = -12
	L_806_ = 0.7
	L_807_ = 0
	if not (L_803_) then
		L_803_ = ""
	end
	L_802_.Text = L_803_
	L_802_.TextColor3 = Color3.fromRGB(255, 255, 255)
	L_803_ = L_797_arg2
	L_804_ = 255
	L_805_ = 255
	L_806_ = 255
	if not (L_803_) then
		L_803_ = "Type here..."
	end
	L_802_.PlaceholderText = L_803_
	L_802_.TextSize = 13
	L_802_.ClearTextOnFocus = false
	L_803_ = Instance.new("TextBox")
	L_804_ = next
	L_805_ = L_802_
	L_806_ = nil
	for L_819_forvar0, L_820_forvar1 in L_804_, L_805_, L_806_ do
		L_809_ = "Parent"
		L_810_ = (L_819_forvar0 == "Parent")
		if not (L_810_) then
			L_803_[L_819_forvar0] = L_820_forvar1
		end
	end
	L_803_.Parent = L_802_.Parent
	L_802_ = {}
	L_802_.CornerRadius = UDim.new(0, 4)
	L_802_.Parent = L_803_
	L_801_ = L_803_
	L_803_ = Instance.new("UICorner")
	L_804_ = next
	L_805_ = L_802_
	L_806_ = nil
	for L_821_forvar0, L_822_forvar1 in L_804_, L_805_, L_806_ do
		L_809_ = "Parent"
		L_810_ = (L_821_forvar0 == "Parent")
		if not (L_810_) then
			L_803_[L_821_forvar0] = L_822_forvar1
		end
	end
	L_803_.Parent = L_802_.Parent
	L_801_.FocusLost:Connect(L_1_.callback_120)
	L_802_ = {}
	L_802_.Set = L_1_.Set_121
	return L_802_
end

L_1_.CreateSection = function(L_823_arg0, L_824_arg1)
	local L_825_, L_826_, L_827_, L_828_, L_829_, L_830_, L_831_, L_832_, L_833_, L_834_, L_835_
	L_826_ = {}
	L_826_.Parent = upvalue_0
	L_826_.BackgroundColor3 = Color3.fromRGB(16, 16, 16)
	L_826_.Size = UDim2.new(1, 0, 0, 24)
	L_827_ = Instance.new("Frame")
	L_828_ = next
	L_829_ = L_826_
	L_830_ = nil
	L_831_ = 24
	for L_836_forvar0, L_837_forvar1 in L_828_, L_829_, L_830_ do
		L_834_ = "Parent"
		L_835_ = (L_836_forvar0 == "Parent")
		if not (L_835_) then
			L_827_[L_836_forvar0] = L_837_forvar1
		end
	end
	L_827_.Parent = L_826_.Parent
	L_826_ = {}
	L_826_.CornerRadius = UDim.new(0, 6)
	L_826_.Parent = L_827_
	L_825_ = L_827_
	L_827_ = Instance.new("UICorner")
	L_828_ = next
	L_829_ = L_826_
	L_830_ = nil
	for L_838_forvar0, L_839_forvar1 in L_828_, L_829_, L_830_ do
		L_834_ = "Parent"
		L_835_ = (L_838_forvar0 == "Parent")
		if not (L_835_) then
			L_827_[L_838_forvar0] = L_839_forvar1
		end
	end
	L_827_.Parent = L_826_.Parent
	L_826_ = {}
	L_826_.Parent = L_825_
	L_826_.BackgroundTransparency = 1
	L_826_.Position = UDim2.new(0, 12, 0, 0)
	L_826_.Size = UDim2.new(1, -12, 1, 0)
	L_826_.Font = "GothamBold"
	L_826_.Text = L_824_arg1:upper()
	L_826_.TextColor3 = Color3.fromRGB(190, 190, 190)
	L_826_.TextSize = 10
	L_826_.TextXAlignment = "Left"
	L_827_ = Instance.new("TextLabel")
	L_828_ = next
	L_829_ = L_826_
	L_830_ = nil
	L_831_ = 0
	for L_840_forvar0, L_841_forvar1 in L_828_, L_829_, L_830_ do
		L_834_ = "Parent"
		L_835_ = (L_840_forvar0 == "Parent")
		if not (L_835_) then
			L_827_[L_840_forvar0] = L_841_forvar1
		end
	end
	L_827_.Parent = L_826_.Parent
	L_827_ = {}
	L_827_.Parent = upvalue_0
	L_827_.BackgroundTransparency = 1
	L_827_.Size = UDim2.new(1, 0, 0, 0)
	L_827_.AutomaticSize = "Y"
	L_828_ = Instance.new("Frame")
	L_829_ = next
	L_830_ = L_827_
	L_831_ = nil
	L_832_ = 0
	for L_842_forvar0, L_843_forvar1 in L_829_, L_830_, L_831_ do
		L_834_ = "Parent"
		L_835_ = (L_842_forvar0 == "Parent")
		if not (L_835_) then
			L_828_[L_842_forvar0] = L_843_forvar1
		end
	end
	L_828_.Parent = L_827_.Parent
	L_827_ = {}
	L_827_.Parent = L_828_
	L_827_.Padding = UDim.new(0, 4)
	L_826_ = L_828_
	L_828_ = Instance.new("UIListLayout")
	L_829_ = next
	L_830_ = L_827_
	L_831_ = nil
	for L_844_forvar0, L_845_forvar1 in L_829_, L_830_, L_831_ do
		L_834_ = "Parent"
		L_835_ = (L_844_forvar0 == "Parent")
		if not (L_835_) then
			L_828_[L_844_forvar0] = L_845_forvar1
		end
	end
	L_828_.Parent = L_827_.Parent
	L_827_ = {}
	L_827_.CreateToggle = L_1_.CreateToggle
	L_827_.CreateButton = L_1_.CreateButton
	L_827_.CreateSlider = L_1_.CreateSlider
	L_827_.CreateDropdown = L_1_.CreateDropdown
	L_827_.CreateLabel = L_1_.CreateLabel
	L_827_.CreateInput = L_1_.CreateInput
	return L_827_
end

L_1_.CreateSubTab = function(L_846_arg0, L_847_arg1, L_848_arg2)
	local L_849_, L_850_, L_851_, L_852_, L_853_, L_854_, L_855_, L_856_, L_857_, L_858_, L_859_, L_860_, L_861_, L_862_, L_863_, L_864_
	L_849_ = upvalue_0
	L_851_ = L_848_arg2
	if not (L_851_) then
		L_851_ = "layout"
	end
	L_851_ = {}
	L_851_.Parent = upvalue_1
	L_851_.BackgroundTransparency = 1
	L_851_.Size = UDim2.new(0, 0, 1, 0)
	L_851_.AutomaticSize = "X"
	L_851_.Visible = false
	L_849_ = L_849_:GetIcon(L_851_)
	L_850_ = L_849_
	L_852_ = Instance.new("Frame")
	L_853_ = next
	L_854_ = L_851_
	L_855_ = nil
	L_856_ = 0
	for L_865_forvar0, L_866_forvar1 in L_853_, L_854_, L_855_ do
		L_863_ = "Parent"
		L_864_ = (L_865_forvar0 == "Parent")
		if not (L_864_) then
			L_852_[L_865_forvar0] = L_866_forvar1
		end
	end
	L_852_.Parent = L_851_.Parent
	L_852_ = {}
	L_852_.Parent = L_852_
	L_852_.BackgroundTransparency = 1
	L_852_.Size = UDim2.new(1, 0, 1, 0)
	L_852_.Text = ""
	L_850_ = L_852_
	L_853_ = Instance.new("TextButton")
	L_854_ = next
	L_855_ = L_852_
	L_856_ = nil
	L_857_ = 0
	for L_867_forvar0, L_868_forvar1 in L_854_, L_855_, L_856_ do
		L_863_ = "Parent"
		L_864_ = (L_867_forvar0 == "Parent")
		if not (L_864_) then
			L_853_[L_867_forvar0] = L_868_forvar1
		end
	end
	L_853_.Parent = L_852_.Parent
	L_853_ = {}
	L_853_.Name = "Icon"
	L_853_.Parent = L_850_
	L_853_.BackgroundTransparency = 1
	L_853_.Position = UDim2.new(0, 0, 0.5, -10)
	L_853_.Size = UDim2.new(0, 20, 0, 20)
	L_853_.Image = "rbxassetid://" .. L_849_[1]
	L_853_.ImageRectSize = Vector2.new(L_849_[2], L_849_[3])
	L_853_.ImageRectOffset = Vector2.new(L_849_[4], L_849_[5])
	L_853_.ImageColor3 = Color3.fromRGB(160, 160, 160)
	L_853_.ScaleType = Enum.ScaleType.Fit
	L_851_ = L_853_
	L_854_ = Instance.new("ImageLabel")
	L_855_ = next
	L_856_ = L_853_
	L_857_ = nil
	L_858_ = 20
	for L_869_forvar0, L_870_forvar1 in L_855_, L_856_, L_857_ do
		L_863_ = "Parent"
		L_864_ = (L_869_forvar0 == "Parent")
		if not (L_864_) then
			L_854_[L_869_forvar0] = L_870_forvar1
		end
	end
	L_854_.Parent = L_853_.Parent
	L_854_ = {}
	L_854_.Name = "Label"
	L_854_.Parent = L_850_
	L_854_.BackgroundTransparency = 1
	L_854_.Position = UDim2.new(0, 22, 0, 0)
	L_854_.Size = UDim2.new(0, 0, 1, 0)
	L_854_.AutomaticSize = "X"
	L_854_.Font = "Gotham"
	L_854_.Text = L_847_arg1
	L_854_.TextColor3 = Color3.fromRGB(160, 160, 160)
	L_854_.TextSize = 13
	L_852_ = L_854_
	L_855_ = Instance.new("TextLabel")
	L_856_ = next
	L_857_ = L_854_
	L_858_ = nil
	L_859_ = 0
	for L_871_forvar0, L_872_forvar1 in L_856_, L_857_, L_858_ do
		L_863_ = "Parent"
		L_864_ = (L_871_forvar0 == "Parent")
		if not (L_864_) then
			L_855_[L_871_forvar0] = L_872_forvar1
		end
	end
	L_855_.Parent = L_854_.Parent
	L_855_ = {}
	L_855_.Parent = L_850_
	L_855_.BackgroundColor3 = upvalue_0.Accent
	L_855_.BackgroundTransparency = 1
	L_855_.BorderSizePixel = 0
	L_855_.Position = UDim2.new(0, 0, 1, -2)
	L_855_.Size = UDim2.new(1, 0, 0, 2)
	L_853_ = L_855_
	L_856_ = Instance.new("Frame")
	L_857_ = next
	L_858_ = L_855_
	L_859_ = nil
	L_860_ = 2
	for L_873_forvar0, L_874_forvar1 in L_857_, L_858_, L_859_ do
		L_863_ = "Parent"
		L_864_ = (L_873_forvar0 == "Parent")
		if not (L_864_) then
			L_856_[L_873_forvar0] = L_874_forvar1
		end
	end
	L_856_.Parent = L_855_.Parent
	L_856_ = {}
	L_856_.Parent = upvalue_2
	L_856_.BackgroundTransparency = 1
	L_856_.BorderSizePixel = 0
	L_856_.Size = UDim2.new(1, 0, 1, 0)
	L_856_.Visible = false
	L_856_.ScrollBarThickness = 2
	L_856_.ScrollBarImageColor3 = upvalue_0.Accent
	L_856_.CanvasSize = UDim2.new(0, 0, 0, 0)
	L_856_.AutomaticCanvasSize = "Y"
	L_854_ = L_856_
	L_857_ = Instance.new("ScrollingFrame")
	L_858_ = next
	L_859_ = L_856_
	L_860_ = nil
	L_861_ = 0
	for L_875_forvar0, L_876_forvar1 in L_858_, L_859_, L_860_ do
		L_863_ = "Parent"
		L_864_ = (L_875_forvar0 == "Parent")
		if not (L_864_) then
			L_857_[L_875_forvar0] = L_876_forvar1
		end
	end
	L_857_.Parent = L_856_.Parent
	L_856_ = {}
	L_856_.Parent = L_857_
	L_856_.Padding = UDim.new(0, 6)
	L_856_.HorizontalAlignment = "Center"
	L_855_ = L_857_
	L_857_ = Instance.new("UIListLayout")
	L_858_ = next
	L_859_ = L_856_
	L_860_ = nil
	for L_877_forvar0, L_878_forvar1 in L_858_, L_859_, L_860_ do
		L_863_ = "Parent"
		L_864_ = (L_877_forvar0 == "Parent")
		if not (L_864_) then
			L_857_[L_877_forvar0] = L_878_forvar1
		end
	end
	L_857_.Parent = L_856_.Parent
	L_856_ = {}
	L_856_.Parent = L_855_
	L_856_.PaddingTop = UDim.new(0, 10)
	L_856_.PaddingLeft = UDim.new(0, 18)
	L_856_.PaddingRight = UDim.new(0, 18)
	L_857_ = Instance.new("UIPadding")
	L_858_ = next
	L_859_ = L_856_
	L_860_ = nil
	for L_879_forvar0, L_880_forvar1 in L_858_, L_859_, L_860_ do
		L_863_ = "Parent"
		L_864_ = (L_879_forvar0 == "Parent")
		if not (L_864_) then
			L_857_[L_879_forvar0] = L_880_forvar1
		end
	end
	L_857_.Parent = L_856_.Parent
	L_856_ = {}
	L_856_.Page = L_855_
	L_856_.Btn = L_850_
	L_856_.Select = L_1_.Select_98
	L_851_.Activated:Connect(L_1_.callback_99)
	table.insert(upvalue_3.SubTabs, L_856_)
	L_857_ = upvalue_5.Current
	L_858_ = upvalue_5
	L_859_ = L_856_
	if not (L_857_) then
		L_856_.CreateSection = L_1_.CreateSection
		return L_856_
	end
	L_857_ = upvalue_5.Current.Tab
	L_858_ = upvalue_3
	L_859_ = upvalue_5
	L_864_ = (upvalue_5.Current.Tab == upvalue_3)
	if not (L_864_) then
		L_856_.CreateSection = L_1_.CreateSection
		return L_856_
	end
	L_857_ = upvalue_3.CurrentST
	L_858_ = upvalue_3
	if L_857_ then
		L_856_.CreateSection = L_1_.CreateSection
		return L_856_
	end
	L_850_.Visible = true
	L_856_:Select()
	L_857_ = L_856_.Select
	L_858_ = L_856_
	L_856_.CreateSection = L_1_.CreateSection
	return L_856_
end

L_1_.CreateTab = function(L_881_arg0, L_882_arg1, L_883_arg2)
	local L_884_, L_885_, L_886_, L_887_, L_888_, L_889_, L_890_, L_891_, L_892_, L_893_, L_894_, L_895_, L_896_, L_897_
	L_885_ = {}
	L_885_.Name = L_882_arg1 .. "Tab"
	L_885_.Parent = upvalue_0
	L_885_.BackgroundTransparency = 1
	L_885_.Size = UDim2.new(1, 0, 0, 50)
	L_886_ = Instance.new("ImageButton")
	L_887_ = next
	L_888_ = L_885_
	L_889_ = nil
	L_890_ = 50
	for L_898_forvar0, L_899_forvar1 in L_887_, L_888_, L_889_ do
		L_896_ = "Parent"
		L_897_ = (L_898_forvar0 == "Parent")
		if not (L_897_) then
			L_886_[L_898_forvar0] = L_899_forvar1
		end
	end
	L_886_.Parent = L_885_.Parent
	L_886_ = {}
	L_886_.Parent = L_886_
	L_886_.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
	L_886_.BackgroundTransparency = 1
	L_886_.BorderSizePixel = 0
	L_886_.Size = UDim2.new(1, 0, 1, 0)
	L_884_ = L_886_
	L_887_ = Instance.new("Frame")
	L_888_ = next
	L_889_ = L_886_
	L_890_ = nil
	L_891_ = 0
	for L_900_forvar0, L_901_forvar1 in L_888_, L_889_, L_890_ do
		L_896_ = "Parent"
		L_897_ = (L_900_forvar0 == "Parent")
		if not (L_897_) then
			L_887_[L_900_forvar0] = L_901_forvar1
		end
	end
	L_887_.Parent = L_886_.Parent
	L_886_ = {}
	L_886_.CornerRadius = UDim.new(0, 6)
	L_886_.Parent = L_887_
	L_885_ = L_887_
	L_887_ = Instance.new("UICorner")
	L_888_ = next
	L_889_ = L_886_
	L_890_ = nil
	for L_902_forvar0, L_903_forvar1 in L_888_, L_889_, L_890_ do
		L_896_ = "Parent"
		L_897_ = (L_902_forvar0 == "Parent")
		if not (L_897_) then
			L_887_[L_902_forvar0] = L_903_forvar1
		end
	end
	L_887_.Parent = L_886_.Parent
	L_887_ = {}
	L_887_.Name = "Indicator"
	L_887_.Parent = L_884_
	L_887_.BackgroundColor3 = upvalue_1.Accent
	L_887_.BorderSizePixel = 0
	L_887_.Position = UDim2.new(0, 0, 0.5, -12)
	L_887_.Size = UDim2.new(0, 3, 0, 24)
	L_887_.BackgroundTransparency = 1
	L_887_.ZIndex = 5
	L_888_ = Instance.new("Frame")
	L_889_ = next
	L_890_ = L_887_
	L_891_ = nil
	L_892_ = 24
	for L_904_forvar0, L_905_forvar1 in L_889_, L_890_, L_891_ do
		L_896_ = "Parent"
		L_897_ = (L_904_forvar0 == "Parent")
		if not (L_897_) then
			L_888_[L_904_forvar0] = L_905_forvar1
		end
	end
	L_888_.Parent = L_887_.Parent
	L_887_ = {}
	L_887_.CornerRadius = UDim.new(1, 0)
	L_887_.Parent = L_888_
	L_886_ = L_888_
	L_888_ = Instance.new("UICorner")
	L_889_ = next
	L_890_ = L_887_
	L_891_ = nil
	for L_906_forvar0, L_907_forvar1 in L_889_, L_890_, L_891_ do
		L_896_ = "Parent"
		L_897_ = (L_906_forvar0 == "Parent")
		if not (L_897_) then
			L_888_[L_906_forvar0] = L_907_forvar1
		end
	end
	L_888_.Parent = L_887_.Parent
	L_887_ = upvalue_1
	L_889_ = L_883_arg2
	if not (L_889_) then
		L_889_ = "home"
	end
	L_889_ = {}
	L_889_.Name = "Icon"
	L_889_.Parent = L_884_
	L_889_.BackgroundTransparency = 1
	L_889_.Position = UDim2.new(0.5, -18, 0.5, -18)
	L_889_.Size = UDim2.new(0, 36, 0, 36)
	L_889_.Image = "rbxassetid://" .. L_887_:GetIcon(L_889_)[1]
	L_889_.ImageRectSize = Vector2.new(L_887_:GetIcon(L_889_)[2], L_887_:GetIcon(L_889_)[3])
	L_889_.ImageRectOffset = Vector2.new(L_887_:GetIcon(L_889_)[4], L_887_:GetIcon(L_889_)[5])
	L_889_.ImageColor3 = Color3.fromRGB(140, 140, 140)
	L_889_.ScaleType = Enum.ScaleType.Fit
	L_889_.ZIndex = 6
	L_887_ = L_887_:GetIcon(L_889_)
	L_888_ = L_887_
	L_890_ = Instance.new("ImageLabel")
	L_891_ = next
	L_892_ = L_889_
	L_893_ = nil
	L_894_ = 36
	for L_908_forvar0, L_909_forvar1 in L_891_, L_892_, L_893_ do
		L_896_ = "Parent"
		L_897_ = (L_908_forvar0 == "Parent")
		if not (L_897_) then
			L_890_[L_908_forvar0] = L_909_forvar1
		end
	end
	L_890_.Parent = L_889_.Parent
	L_889_ = {}
	L_889_.SubTabs = {}
	L_889_.CurrentST = nil
	L_889_.Select = L_1_.Select
	L_884_.Activated:Connect(L_1_.callback_96)
	L_889_.SetVisible = L_1_.SetVisible
	L_889_.CreateSubTab = L_1_.CreateSubTab
	L_890_ = Window.Tabs
	L_890_[L_882_arg1] = L_889_
	L_888_ = L_890_
	L_890_ = upvalue_3.Current
	L_891_ = upvalue_3
	L_892_ = L_1_.callback_96
	if L_890_ then
		return L_889_
	end
	L_889_:Select()
	L_890_ = L_889_.Select
	L_891_ = L_889_
	return L_889_
end

L_1_.CreateWindow = function(L_910_arg0, L_911_arg1)
	local L_912_, L_913_, L_914_, L_915_, L_916_, L_917_, L_918_, L_919_, L_920_, L_921_, L_922_, L_923_, L_924_, L_925_, L_926_, L_927_
	local L_928_, L_929_, L_930_, L_931_, L_932_, L_933_, L_934_, L_935_, L_936_, L_937_, L_938_, L_939_, L_940_, L_941_, L_942_, L_943_
	local L_944_
	L_912_ = nil
	L_913_ = pcall
	L_914_ = L_1_.callback_73
	L_913_, L_914_ = pcall(L_1_.callback_73)
	if L_913_ then
		L_915_ = L_914_
		if not (L_915_) then
			L_915_ = tostring(math.random(10000000, 90000000))
			L_916_ = select(1, math.random(10000000, 90000000))
			L_917_ = 10000000
			L_918_ = 90000000
		end
	else
		L_915_ = tostring(math.random(10000000, 90000000))
		L_916_ = select(1, math.random(10000000, 90000000))
		L_917_ = 10000000
		L_918_ = 90000000
	end
	L_914_ = {}
	L_914_.Name = L_915_
	L_914_.ResetOnSpawn = false
	L_912_ = L_915_
	L_915_ = Instance.new("ScreenGui")
	L_916_ = next
	L_917_ = L_914_
	L_918_ = nil
	for L_945_forvar0, L_946_forvar1 in L_916_, L_917_, L_918_ do
		L_943_ = "Parent"
		L_944_ = (L_945_forvar0 == "Parent")
		if not (L_944_) then
			L_915_[L_945_forvar0] = L_946_forvar1
		end
	end
	L_915_.Parent = L_914_.Parent
	L_913_ = L_915_
	L_914_ = false
	L_915_ = upvalue_0:IsStudio()
	L_916_ = upvalue_0
	if not (L_915_) then
		L_915_ = syn
		if L_915_ then
			L_915_ = syn.protect_gui
			if L_915_ then
				pcall(L_1_.callback_74)
				L_915_ = pcall
				L_916_ = L_1_.callback_74
			end
		end
		if not (L_914_) then
			L_915_ = gethui
			if L_915_ then
				pcall(L_1_.callback_75)
				L_915_ = pcall
				L_916_ = L_1_.callback_75
			end
		end
		if not (L_914_) then
			L_915_ = get_hidden_gui
			if L_915_ then
				pcall(L_1_.callback_76)
				L_915_ = pcall
				L_916_ = L_1_.callback_76
			end
		end
	end
	if not (L_914_) then
		L_916_ = upvalue_0:IsStudio()
		L_917_ = upvalue_0
		if L_916_ then
			L_915_ = upvalue_2.PlayerGui
			L_916_ = upvalue_2
			if not (L_915_) then
				L_915_ = upvalue_1
			end
		else
			L_915_ = upvalue_1
		end
		L_913_.Parent = L_915_
	end
	L_915_ = getgenv
	if L_915_ then
		L_915_ = "_h_" .. L_912_
		L_916_ = getgenv()["_h_" .. L_912_]
		L_917_ = getgenv()
		if L_916_ then
			pcall(L_1_.callback_77)
			L_916_ = pcall
			L_917_ = L_1_.callback_77
		end
		L_916_ = getgenv()
		L_916_[L_915_] = L_913_
	end
	L_916_ = {}
	L_916_.Parent = L_913_
	L_916_.BackgroundColor3 = upvalue_3.BgPrimary
	L_916_.Position = UDim2.new(0.5, -300, 0.5, -220)
	L_916_.Size = UDim2.new(0, 600, 0, 440)
	L_916_.ClipsDescendants = true
	L_916_.Visible = true
	L_917_ = Instance.new("Frame")
	L_918_ = next
	L_919_ = L_916_
	L_920_ = nil
	L_921_ = 440
	for L_947_forvar0, L_948_forvar1 in L_918_, L_919_, L_920_ do
		L_943_ = "Parent"
		L_944_ = (L_947_forvar0 == "Parent")
		if not (L_944_) then
			L_917_[L_947_forvar0] = L_948_forvar1
		end
	end
	L_917_.Parent = L_916_.Parent
	L_916_ = {}
	L_916_.CornerRadius = UDim.new(0, 10)
	L_916_.Parent = L_917_
	L_915_ = L_917_
	L_917_ = Instance.new("UICorner")
	L_918_ = next
	L_919_ = L_916_
	L_920_ = nil
	for L_949_forvar0, L_950_forvar1 in L_918_, L_919_, L_920_ do
		L_943_ = "Parent"
		L_944_ = (L_949_forvar0 == "Parent")
		if not (L_944_) then
			L_917_[L_949_forvar0] = L_950_forvar1
		end
	end
	L_917_.Parent = L_916_.Parent
	L_917_ = {}
	L_917_.Name = "Glow"
	L_917_.Parent = L_915_
	L_917_.ZIndex = 0
	L_917_.BackgroundTransparency = 1
	L_917_.Position = UDim2.new(0, -25, 0, -25)
	L_917_.Size = UDim2.new(1, 50, 1, 50)
	L_917_.Image = "rbxassetid://6015667320"
	L_917_.ImageColor3 = upvalue_3.Accent
	L_917_.ImageTransparency = 0.5
	L_917_.ScaleType = Enum.ScaleType.Slice
	L_917_.SliceCenter = Rect.new(49, 49, 450, 450)
	L_918_ = Instance.new("ImageLabel")
	L_919_ = next
	L_920_ = L_917_
	L_921_ = nil
	L_922_ = 450
	for L_951_forvar0, L_952_forvar1 in L_919_, L_920_, L_921_ do
		L_943_ = "Parent"
		L_944_ = (L_951_forvar0 == "Parent")
		if not (L_944_) then
			L_918_[L_951_forvar0] = L_952_forvar1
		end
	end
	L_918_.Parent = L_917_.Parent
	L_917_ = {}
	L_917_.Color = upvalue_3.Border
	L_917_.Thickness = 1
	L_917_.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	L_917_.LineJoinMode = Enum.LineJoinMode.Round
	L_917_.Parent = L_915_
	L_916_ = L_918_
	L_918_ = Instance.new("UIStroke")
	L_919_ = next
	L_920_ = L_917_
	L_921_ = nil
	for L_953_forvar0, L_954_forvar1 in L_919_, L_920_, L_921_ do
		L_943_ = "Parent"
		L_944_ = (L_953_forvar0 == "Parent")
		if not (L_944_) then
			L_918_[L_953_forvar0] = L_954_forvar1
		end
	end
	L_918_.Parent = L_917_.Parent
	task.spawn(L_1_.callback_79)
	L_918_ = {}
	L_918_.Parent = L_915_
	L_918_.BackgroundColor3 = upvalue_3.BgSecondary
	L_918_.Size = UDim2.new(0, 65, 1, 0)
	L_917_ = task.spawn
	L_919_ = Instance.new("Frame")
	L_920_ = next
	L_921_ = L_918_
	L_922_ = nil
	L_923_ = 0
	for L_955_forvar0, L_956_forvar1 in L_920_, L_921_, L_922_ do
		L_943_ = "Parent"
		L_944_ = (L_955_forvar0 == "Parent")
		if not (L_944_) then
			L_919_[L_955_forvar0] = L_956_forvar1
		end
	end
	L_919_.Parent = L_918_.Parent
	L_918_ = {}
	L_918_.CornerRadius = UDim.new(0, 10)
	L_918_.Parent = L_919_
	L_917_ = L_919_
	L_919_ = Instance.new("UICorner")
	L_920_ = next
	L_921_ = L_918_
	L_922_ = nil
	for L_957_forvar0, L_958_forvar1 in L_920_, L_921_, L_922_ do
		L_943_ = "Parent"
		L_944_ = (L_957_forvar0 == "Parent")
		if not (L_944_) then
			L_919_[L_957_forvar0] = L_958_forvar1
		end
	end
	L_919_.Parent = L_918_.Parent
	L_918_ = {}
	L_918_.Parent = L_917_
	L_918_.BackgroundColor3 = upvalue_3.BgSecondary
	L_918_.BorderSizePixel = 0
	L_918_.AnchorPoint = Vector2.new(1, 0)
	L_918_.Position = UDim2.new(1, 0, 0, 0)
	L_918_.Size = UDim2.new(0, 15, 1, 0)
	L_919_ = Instance.new("Frame")
	L_920_ = next
	L_921_ = L_918_
	L_922_ = nil
	L_923_ = 0
	for L_959_forvar0, L_960_forvar1 in L_920_, L_921_, L_922_ do
		L_943_ = "Parent"
		L_944_ = (L_959_forvar0 == "Parent")
		if not (L_944_) then
			L_919_[L_959_forvar0] = L_960_forvar1
		end
	end
	L_919_.Parent = L_918_.Parent
	L_918_ = {}
	L_918_.Color = upvalue_3.Border
	L_918_.ApplyStrokeMode = "Border"
	L_918_.Parent = L_917_
	L_919_ = Instance.new("UIStroke")
	L_920_ = next
	L_921_ = L_918_
	L_922_ = nil
	for L_961_forvar0, L_962_forvar1 in L_920_, L_921_, L_922_ do
		L_943_ = "Parent"
		L_944_ = (L_961_forvar0 == "Parent")
		if not (L_944_) then
			L_919_[L_961_forvar0] = L_962_forvar1
		end
	end
	L_919_.Parent = L_918_.Parent
	L_919_ = {}
	L_919_.Name = "Branding"
	L_919_.Parent = L_917_
	L_919_.BackgroundTransparency = 1
	L_919_.Size = UDim2.new(1, 0, 0, 65)
	L_920_ = Instance.new("Frame")
	L_921_ = next
	L_922_ = L_919_
	L_923_ = nil
	L_924_ = 65
	for L_963_forvar0, L_964_forvar1 in L_921_, L_922_, L_923_ do
		L_943_ = "Parent"
		L_944_ = (L_963_forvar0 == "Parent")
		if not (L_944_) then
			L_920_[L_963_forvar0] = L_964_forvar1
		end
	end
	L_920_.Parent = L_919_.Parent
	L_919_ = {}
	L_919_.Parent = L_920_
	L_919_.BackgroundTransparency = 1
	L_919_.AnchorPoint = Vector2.new(0.5, 0.5)
	L_919_.Position = UDim2.new(0.5, 0, 0.5, 0)
	L_919_.Size = UDim2.new(0, 42, 0, 42)
	L_919_.Image = "rbxassetid://123802801726537"
	L_919_.ScaleType = Enum.ScaleType.Fit
	L_918_ = L_920_
	L_920_ = Instance.new("ImageLabel")
	L_921_ = next
	L_922_ = L_919_
	L_923_ = nil
	L_924_ = 42
	for L_965_forvar0, L_966_forvar1 in L_921_, L_922_, L_923_ do
		L_943_ = "Parent"
		L_944_ = (L_965_forvar0 == "Parent")
		if not (L_944_) then
			L_920_[L_965_forvar0] = L_966_forvar1
		end
	end
	L_920_.Parent = L_919_.Parent
	L_919_ = {}
	L_919_.Parent = L_918_
	L_919_.BackgroundColor3 = Color3.fromRGB(35, 35, 35)
	L_919_.BorderSizePixel = 0
	L_919_.Position = UDim2.new(0, 10, 1, -1)
	L_919_.Size = UDim2.new(1, -20, 0, 1)
	L_920_ = Instance.new("Frame")
	L_921_ = next
	L_922_ = L_919_
	L_923_ = nil
	L_924_ = 1
	for L_967_forvar0, L_968_forvar1 in L_921_, L_922_, L_923_ do
		L_943_ = "Parent"
		L_944_ = (L_967_forvar0 == "Parent")
		if not (L_944_) then
			L_920_[L_967_forvar0] = L_968_forvar1
		end
	end
	L_920_.Parent = L_919_.Parent
	L_920_ = {}
	L_920_.Parent = L_917_
	L_920_.BackgroundTransparency = 1
	L_920_.Position = UDim2.new(0, 0, 0, 65)
	L_920_.Size = UDim2.new(1, 0, 1, -135)
	L_920_.CanvasSize = UDim2.new(0, 0, 0, 0)
	L_920_.AutomaticCanvasSize = "Y"
	L_920_.ScrollBarThickness = 1
	L_920_.ScrollBarImageTransparency = 1
	L_920_.ScrollingDirection = "Y"
	L_921_ = Instance.new("ScrollingFrame")
	L_922_ = next
	L_923_ = L_920_
	L_924_ = nil
	L_925_ = 0
	for L_969_forvar0, L_970_forvar1 in L_922_, L_923_, L_924_ do
		L_943_ = "Parent"
		L_944_ = (L_969_forvar0 == "Parent")
		if not (L_944_) then
			L_921_[L_969_forvar0] = L_970_forvar1
		end
	end
	L_921_.Parent = L_920_.Parent
	L_920_ = {}
	L_920_.Parent = L_921_
	L_920_.HorizontalAlignment = "Center"
	L_920_.Padding = UDim.new(0, 8)
	L_919_ = L_921_
	L_921_ = Instance.new("UIListLayout")
	L_922_ = next
	L_923_ = L_920_
	L_924_ = nil
	for L_971_forvar0, L_972_forvar1 in L_922_, L_923_, L_924_ do
		L_943_ = "Parent"
		L_944_ = (L_971_forvar0 == "Parent")
		if not (L_944_) then
			L_921_[L_971_forvar0] = L_972_forvar1
		end
	end
	L_921_.Parent = L_920_.Parent
	L_921_ = {}
	L_921_.Name = "Profile"
	L_921_.Parent = L_917_
	L_921_.BackgroundTransparency = 1
	L_921_.AnchorPoint = Vector2.new(0, 1)
	L_921_.Position = UDim2.new(0, 0, 1, 0)
	L_921_.Size = UDim2.new(1, 0, 0, 70)
	L_922_ = Instance.new("Frame")
	L_923_ = next
	L_924_ = L_921_
	L_925_ = nil
	L_926_ = 70
	for L_973_forvar0, L_974_forvar1 in L_923_, L_924_, L_925_ do
		L_943_ = "Parent"
		L_944_ = (L_973_forvar0 == "Parent")
		if not (L_944_) then
			L_922_[L_973_forvar0] = L_974_forvar1
		end
	end
	L_922_.Parent = L_921_.Parent
	L_921_ = {}
	L_921_.Parent = L_922_
	L_921_.BackgroundColor3 = Color3.fromRGB(35, 35, 35)
	L_921_.BorderSizePixel = 0
	L_921_.Position = UDim2.new(0, 10, 0, 0)
	L_921_.Size = UDim2.new(1, -20, 0, 1)
	L_920_ = L_922_
	L_922_ = Instance.new("Frame")
	L_923_ = next
	L_924_ = L_921_
	L_925_ = nil
	L_926_ = 1
	for L_975_forvar0, L_976_forvar1 in L_923_, L_924_, L_925_ do
		L_943_ = "Parent"
		L_944_ = (L_975_forvar0 == "Parent")
		if not (L_944_) then
			L_922_[L_975_forvar0] = L_976_forvar1
		end
	end
	L_922_.Parent = L_921_.Parent
	L_922_ = {}
	L_922_.Parent = L_920_
	L_922_.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
	L_922_.AnchorPoint = Vector2.new(0.5, 0.5)
	L_922_.Position = UDim2.new(0.5, 0, 0.5, 0)
	L_922_.Size = UDim2.new(0, 44, 0, 44)
	L_923_ = Instance.new("Frame")
	L_924_ = next
	L_925_ = L_922_
	L_926_ = nil
	L_927_ = 44
	for L_977_forvar0, L_978_forvar1 in L_924_, L_925_, L_926_ do
		L_943_ = "Parent"
		L_944_ = (L_977_forvar0 == "Parent")
		if not (L_944_) then
			L_923_[L_977_forvar0] = L_978_forvar1
		end
	end
	L_923_.Parent = L_922_.Parent
	L_922_ = {}
	L_922_.CornerRadius = UDim.new(1, 0)
	L_922_.Parent = L_923_
	L_921_ = L_923_
	L_923_ = Instance.new("UICorner")
	L_924_ = next
	L_925_ = L_922_
	L_926_ = nil
	for L_979_forvar0, L_980_forvar1 in L_924_, L_925_, L_926_ do
		L_943_ = "Parent"
		L_944_ = (L_979_forvar0 == "Parent")
		if not (L_944_) then
			L_923_[L_979_forvar0] = L_980_forvar1
		end
	end
	L_923_.Parent = L_922_.Parent
	L_922_ = {}
	L_922_.Color = upvalue_3.Border
	L_922_.Thickness = 1
	L_922_.Parent = L_921_
	L_923_ = Instance.new("UIStroke")
	L_924_ = next
	L_925_ = L_922_
	L_926_ = nil
	for L_981_forvar0, L_982_forvar1 in L_924_, L_925_, L_926_ do
		L_943_ = "Parent"
		L_944_ = (L_981_forvar0 == "Parent")
		if not (L_944_) then
			L_923_[L_981_forvar0] = L_982_forvar1
		end
	end
	L_923_.Parent = L_922_.Parent
	L_923_ = {}
	L_923_.Parent = L_921_
	L_923_.BackgroundTransparency = 1
	L_923_.Size = UDim2.new(1, 0, 1, 0)
	L_923_.Image = ""
	L_924_ = Instance.new("ImageLabel")
	L_925_ = next
	L_926_ = L_923_
	L_927_ = nil
	L_928_ = 0
	for L_983_forvar0, L_984_forvar1 in L_925_, L_926_, L_927_ do
		L_943_ = "Parent"
		L_944_ = (L_983_forvar0 == "Parent")
		if not (L_944_) then
			L_924_[L_983_forvar0] = L_984_forvar1
		end
	end
	L_924_.Parent = L_923_.Parent
	L_923_ = {}
	L_923_.CornerRadius = UDim.new(1, 0)
	L_923_.Parent = L_924_
	L_922_ = L_924_
	L_924_ = Instance.new("UICorner")
	L_925_ = next
	L_926_ = L_923_
	L_927_ = nil
	for L_985_forvar0, L_986_forvar1 in L_925_, L_926_, L_927_ do
		L_943_ = "Parent"
		L_944_ = (L_985_forvar0 == "Parent")
		if not (L_944_) then
			L_924_[L_985_forvar0] = L_986_forvar1
		end
	end
	L_924_.Parent = L_923_.Parent
	task.spawn(L_1_.callback_81)
	L_924_ = {}
	L_924_.Parent = L_915_
	L_924_.BackgroundTransparency = 1
	L_924_.Position = UDim2.new(0, 65, 0, 0)
	L_924_.Size = UDim2.new(1, -65, 1, 0)
	L_923_ = task.spawn
	L_925_ = Instance.new("Frame")
	L_926_ = next
	L_927_ = L_924_
	L_928_ = nil
	L_929_ = 0
	for L_987_forvar0, L_988_forvar1 in L_926_, L_927_, L_928_ do
		L_943_ = "Parent"
		L_944_ = (L_987_forvar0 == "Parent")
		if not (L_944_) then
			L_925_[L_987_forvar0] = L_988_forvar1
		end
	end
	L_925_.Parent = L_924_.Parent
	L_925_ = {}
	L_925_.Name = "DragBar"
	L_925_.Parent = L_915_
	L_925_.BackgroundTransparency = 1
	L_925_.Size = UDim2.new(1, 0, 0, 48)
	L_925_.ZIndex = 0
	L_923_ = L_925_
	L_926_ = Instance.new("Frame")
	L_927_ = next
	L_928_ = L_925_
	L_929_ = nil
	L_930_ = 48
	for L_989_forvar0, L_990_forvar1 in L_927_, L_928_, L_929_ do
		L_943_ = "Parent"
		L_944_ = (L_989_forvar0 == "Parent")
		if not (L_944_) then
			L_926_[L_989_forvar0] = L_990_forvar1
		end
	end
	L_926_.Parent = L_925_.Parent
	L_926_ = {}
	L_926_.Name = "DragSide"
	L_926_.Parent = L_917_
	L_926_.BackgroundTransparency = 1
	L_926_.Size = UDim2.new(1, 0, 0, 65)
	L_926_.ZIndex = 11
	L_924_ = L_926_
	L_927_ = Instance.new("Frame")
	L_928_ = next
	L_929_ = L_926_
	L_930_ = nil
	L_931_ = 65
	for L_991_forvar0, L_992_forvar1 in L_928_, L_929_, L_930_ do
		L_943_ = "Parent"
		L_944_ = (L_991_forvar0 == "Parent")
		if not (L_944_) then
			L_927_[L_991_forvar0] = L_992_forvar1
		end
	end
	L_927_.Parent = L_926_.Parent
	upvalue_6:MakeDraggable(L_927_, L_915_)
	L_928_ = {}
	L_928_.Parent = L_923_
	L_928_.BackgroundTransparency = 1
	L_928_.Size = UDim2.new(1, 0, 0, 48)
	L_925_ = L_927_
	L_926_ = upvalue_6:MakeDraggable(L_924_, L_915_)
	L_927_ = upvalue_6.MakeDraggable
	L_929_ = Instance.new("Frame")
	L_930_ = next
	L_931_ = L_928_
	L_932_ = nil
	L_933_ = 48
	for L_993_forvar0, L_994_forvar1 in L_930_, L_931_, L_932_ do
		L_943_ = "Parent"
		L_944_ = (L_993_forvar0 == "Parent")
		if not (L_944_) then
			L_929_[L_993_forvar0] = L_994_forvar1
		end
	end
	L_929_.Parent = L_928_.Parent
	L_928_ = {}
	L_928_.Parent = L_929_
	L_928_.BackgroundTransparency = 1
	L_928_.Position = UDim2.new(0, 16, 0, 0)
	L_928_.Size = UDim2.new(0, 180, 1, 0)
	L_928_.Font = "GothamBold"
	L_927_ = L_929_
	L_929_ = L_911_arg1
	L_930_ = 0
	L_931_ = 180
	L_932_ = 1
	L_933_ = 0
	if not (L_929_) then
		L_929_ = "Snowy Studios"
	end
	L_928_.Text = L_929_
	L_928_.TextColor3 = Color3.new(1, 1, 1)
	L_928_.TextSize = 18
	L_928_.TextXAlignment = "Left"
	L_929_ = Instance.new("TextLabel")
	L_930_ = next
	L_931_ = L_928_
	L_932_ = nil
	for L_995_forvar0, L_996_forvar1 in L_930_, L_931_, L_932_ do
		L_943_ = "Parent"
		L_944_ = (L_995_forvar0 == "Parent")
		if not (L_944_) then
			L_929_[L_995_forvar0] = L_996_forvar1
		end
	end
	L_929_.Parent = L_928_.Parent
	L_929_ = {}
	L_929_.Name = "CloseBtn"
	L_929_.Parent = L_927_
	L_929_.AnchorPoint = Vector2.new(1, 0.5)
	L_929_.BackgroundTransparency = 1
	L_929_.Position = UDim2.new(1, -12, 0.5, 0)
	L_929_.Size = UDim2.new(0, 24, 0, 24)
	L_929_.Font = "GothamBold"
	L_929_.Text = "X"
	L_929_.TextColor3 = Color3.new(1, 1, 1)
	L_929_.TextSize = 13
	L_929_.AutoButtonColor = false
	L_929_.ZIndex = 12
	L_930_ = Instance.new("TextButton")
	L_931_ = next
	L_932_ = L_929_
	L_933_ = nil
	L_934_ = 24
	for L_997_forvar0, L_998_forvar1 in L_931_, L_932_, L_933_ do
		L_943_ = "Parent"
		L_944_ = (L_997_forvar0 == "Parent")
		if not (L_944_) then
			L_930_[L_997_forvar0] = L_998_forvar1
		end
	end
	L_930_.Parent = L_929_.Parent
	L_930_.Activated:Connect(L_1_.Name)
	L_930_ = {}
	L_930_.Name = "MinBtn"
	L_930_.Parent = L_927_
	L_930_.AnchorPoint = Vector2.new(1, 0.5)
	L_930_.BackgroundTransparency = 1
	L_930_.Position = UDim2.new(1, -42, 0.5, 0)
	L_930_.Size = UDim2.new(0, 24, 0, 24)
	L_930_.Font = "GothamBold"
	L_930_.Text = "\u{2013}"
	L_930_.TextColor3 = Color3.new(1, 1, 1)
	L_930_.TextSize = 22
	L_930_.AutoButtonColor = false
	L_930_.ZIndex = 12
	L_928_ = L_930_
	L_929_ = L_930_.Activated.Connect
	L_931_ = Instance.new("TextButton")
	L_932_ = next
	L_933_ = L_930_
	L_934_ = nil
	L_935_ = 24
	for L_999_forvar0, L_1000_forvar1 in L_932_, L_933_, L_934_ do
		L_943_ = "Parent"
		L_944_ = (L_999_forvar0 == "Parent")
		if not (L_944_) then
			L_931_[L_999_forvar0] = L_1000_forvar1
		end
	end
	L_931_.Parent = L_930_.Parent
	L_931_.MouseEnter:Connect(L_1_.callback_83)
	L_931_.MouseLeave:Connect(L_1_.callback_84)
	L_928_.MouseEnter:Connect(L_1_.callback_85)
	L_928_.MouseLeave:Connect(L_1_.BackgroundTransparency)
	L_931_ = {}
	L_931_.Parent = L_927_
	L_931_.BackgroundTransparency = 1
	L_931_.Position = UDim2.new(0, 200, 0, 0)
	L_931_.Size = UDim2.new(1, -240, 1, 0)
	L_929_ = L_931_
	L_930_ = L_928_.MouseLeave.Connect
	L_932_ = Instance.new("Frame")
	L_933_ = next
	L_934_ = L_931_
	L_935_ = nil
	L_936_ = 0
	for L_1001_forvar0, L_1002_forvar1 in L_933_, L_934_, L_935_ do
		L_943_ = "Parent"
		L_944_ = (L_1001_forvar0 == "Parent")
		if not (L_944_) then
			L_932_[L_1001_forvar0] = L_1002_forvar1
		end
	end
	L_932_.Parent = L_931_.Parent
	L_931_ = {}
	L_931_.Parent = L_932_
	L_931_.FillDirection = "Horizontal"
	L_931_.Padding = UDim.new(0, 18)
	L_931_.VerticalAlignment = "Center"
	L_930_ = L_932_
	L_932_ = Instance.new("UIListLayout")
	L_933_ = next
	L_934_ = L_931_
	L_935_ = nil
	for L_1003_forvar0, L_1004_forvar1 in L_933_, L_934_, L_935_ do
		L_943_ = "Parent"
		L_944_ = (L_1003_forvar0 == "Parent")
		if not (L_944_) then
			L_932_[L_1003_forvar0] = L_1004_forvar1
		end
	end
	L_932_.Parent = L_931_.Parent
	L_931_ = {}
	L_931_.Parent = L_927_
	L_931_.BackgroundColor3 = upvalue_3.Border
	L_931_.BorderSizePixel = 0
	L_931_.Position = UDim2.new(0, 0, 1, -1)
	L_931_.Size = UDim2.new(1, 0, 0, 1)
	L_932_ = Instance.new("Frame")
	L_933_ = next
	L_934_ = L_931_
	L_935_ = nil
	L_936_ = 1
	for L_1005_forvar0, L_1006_forvar1 in L_933_, L_934_, L_935_ do
		L_943_ = "Parent"
		L_944_ = (L_1005_forvar0 == "Parent")
		if not (L_944_) then
			L_932_[L_1005_forvar0] = L_1006_forvar1
		end
	end
	L_932_.Parent = L_931_.Parent
	L_932_ = {}
	L_932_.Name = "MainFolder"
	L_932_.Parent = L_923_
	L_932_.BackgroundTransparency = 1
	L_933_ = UDim2.new
	L_934_ = 0
	L_935_ = 0
	L_936_ = 0
	L_938_ = upvalue_7
	if L_938_ then
		L_937_ = 92
	else
		L_937_ = 48
	end
	L_932_.Position = L_933_(L_934_, L_935_, L_936_, L_937_)
	L_933_ = UDim2.new
	L_934_ = 1
	L_935_ = 0
	L_936_ = 1
	L_938_ = upvalue_7
	if L_938_ then
		L_937_ = -92
	else
		L_937_ = -48
	end
	L_932_.Size = L_933_(L_934_, L_935_, L_936_, L_937_)
	L_933_ = Instance.new("Frame")
	L_934_ = next
	L_935_ = L_932_
	L_936_ = nil
	for L_1007_forvar0, L_1008_forvar1 in L_934_, L_935_, L_936_ do
		L_943_ = "Parent"
		L_944_ = (L_1007_forvar0 == "Parent")
		if not (L_944_) then
			L_933_[L_1007_forvar0] = L_1008_forvar1
		end
	end
	L_933_.Parent = L_932_.Parent
	L_931_ = L_933_
	L_932_ = upvalue_8.TouchEnabled
	L_933_ = upvalue_8
	L_934_ = L_932_.Parent
	if L_932_ then
		L_933_ = {}
		L_933_.Name = "MobileToggle"
		L_933_.Parent = L_913_
		L_933_.BackgroundColor3 = upvalue_3.BgSecondary
		L_933_.Position = UDim2.new(1, -60, 1, -60)
		L_933_.Size = UDim2.new(0, 44, 0, 44)
		L_933_.Image = ""
		L_933_.AutoButtonColor = false
		L_933_.ZIndex = 100
		L_934_ = Instance.new("ImageButton")
		L_935_ = next
		L_936_ = L_933_
		L_937_ = nil
		L_938_ = 44
		for L_1009_forvar0, L_1010_forvar1 in L_935_, L_936_, L_937_ do
			L_943_ = "Parent"
			L_944_ = (L_1009_forvar0 == "Parent")
			if not (L_944_) then
				L_934_[L_1009_forvar0] = L_1010_forvar1
			end
		end
		L_934_.Parent = L_933_.Parent
		L_933_ = {}
		L_933_.CornerRadius = UDim.new(0, 10)
		L_933_.Parent = L_934_
		L_932_ = L_934_
		L_934_ = Instance.new("UICorner")
		L_935_ = next
		L_936_ = L_933_
		L_937_ = nil
		for L_1011_forvar0, L_1012_forvar1 in L_935_, L_936_, L_937_ do
			L_943_ = "Parent"
			L_944_ = (L_1011_forvar0 == "Parent")
			if not (L_944_) then
				L_934_[L_1011_forvar0] = L_1012_forvar1
			end
		end
		L_934_.Parent = L_933_.Parent
		L_933_ = {}
		L_933_.Color = upvalue_6.Accent
		L_933_.Thickness = 2
		L_933_.Parent = L_932_
		L_934_ = Instance.new("UIStroke")
		L_935_ = next
		L_936_ = L_933_
		L_937_ = nil
		for L_1013_forvar0, L_1014_forvar1 in L_935_, L_936_, L_937_ do
			L_943_ = "Parent"
			L_944_ = (L_1013_forvar0 == "Parent")
			if not (L_944_) then
				L_934_[L_1013_forvar0] = L_1014_forvar1
			end
		end
		L_934_.Parent = L_933_.Parent
		L_933_ = {}
		L_933_.Parent = L_932_
		L_933_.BackgroundTransparency = 1
		L_933_.Position = UDim2.new(0.5, -14, 0.5, -14)
		L_933_.Size = UDim2.new(0, 28, 0, 28)
		L_933_.Image = "rbxassetid://123802801726537"
		L_933_.ScaleType = Enum.ScaleType.Fit
		L_933_.ZIndex = 101
		L_934_ = Instance.new("ImageLabel")
		L_935_ = next
		L_936_ = L_933_
		L_937_ = nil
		L_938_ = 28
		for L_1015_forvar0, L_1016_forvar1 in L_935_, L_936_, L_937_ do
			L_943_ = "Parent"
			L_944_ = (L_1015_forvar0 == "Parent")
			if not (L_944_) then
				L_934_[L_1015_forvar0] = L_1016_forvar1
			end
		end
		L_934_.Parent = L_933_.Parent
		L_932_.InputEnded:Connect(L_1_.callback_87)
		L_933_ = upvalue_6:MakeDraggable(L_932_)
		L_934_ = L_932_.InputEnded.Connect
		L_935_ = L_932_.InputEnded
		L_936_ = L_1_.callback_87
	end
	upvalue_8.InputBegan:Connect(L_1_.Name_88)
	L_933_ = {}
	L_933_.Name = "SnowyMarketBubble"
	L_933_.Parent = L_913_
	L_933_.AnchorPoint = Vector2.new(0, 0)
	L_933_.Position = UDim2.new(0, 30, 0, 30)
	L_933_.Size = UDim2.new(0, 0, 0, 0)
	L_933_.BackgroundColor3 = upvalue_3.BgCard
	L_933_.BorderSizePixel = 0
	L_933_.AutoButtonColor = false
	L_933_.Image = ""
	L_933_.Visible = false
	L_933_.ZIndex = 200
	L_932_ = upvalue_8.InputBegan.Connect
	L_934_ = Instance.new("ImageButton")
	L_935_ = next
	L_936_ = L_933_
	L_937_ = nil
	L_938_ = 0
	for L_1017_forvar0, L_1018_forvar1 in L_935_, L_936_, L_937_ do
		L_943_ = "Parent"
		L_944_ = (L_1017_forvar0 == "Parent")
		if not (L_944_) then
			L_934_[L_1017_forvar0] = L_1018_forvar1
		end
	end
	L_934_.Parent = L_933_.Parent
	L_933_ = {}
	L_933_.CornerRadius = UDim.new(1, 0)
	L_933_.Parent = L_934_
	L_932_ = L_934_
	L_934_ = Instance.new("UICorner")
	L_935_ = next
	L_936_ = L_933_
	L_937_ = nil
	for L_1019_forvar0, L_1020_forvar1 in L_935_, L_936_, L_937_ do
		L_943_ = "Parent"
		L_944_ = (L_1019_forvar0 == "Parent")
		if not (L_944_) then
			L_934_[L_1019_forvar0] = L_1020_forvar1
		end
	end
	L_934_.Parent = L_933_.Parent
	L_933_ = {}
	L_933_.Color = upvalue_3.Accent
	L_933_.Thickness = 2
	L_933_.Parent = L_932_
	L_934_ = Instance.new("UIStroke")
	L_935_ = next
	L_936_ = L_933_
	L_937_ = nil
	for L_1021_forvar0, L_1022_forvar1 in L_935_, L_936_, L_937_ do
		L_943_ = "Parent"
		L_944_ = (L_1021_forvar0 == "Parent")
		if not (L_944_) then
			L_934_[L_1021_forvar0] = L_1022_forvar1
		end
	end
	L_934_.Parent = L_933_.Parent
	L_933_ = {}
	L_933_.Color = ColorSequence.new(upvalue_3.BgSecondary, upvalue_3.BgCard)
	L_933_.Rotation = 125
	L_933_.Parent = L_932_
	L_934_ = Instance.new("UIGradient")
	L_935_ = next
	L_936_ = L_933_
	L_937_ = nil
	for L_1023_forvar0, L_1024_forvar1 in L_935_, L_936_, L_937_ do
		L_943_ = "Parent"
		L_944_ = (L_1023_forvar0 == "Parent")
		if not (L_944_) then
			L_934_[L_1023_forvar0] = L_1024_forvar1
		end
	end
	L_934_.Parent = L_933_.Parent
	L_934_ = {}
	L_934_.Parent = L_932_
	L_934_.BackgroundTransparency = 1
	L_934_.Position = UDim2.new(0, -15, 0, -15)
	L_934_.Size = UDim2.new(1, 30, 1, 30)
	L_934_.Image = "rbxassetid://6015667320"
	L_934_.ImageColor3 = upvalue_3.Accent
	L_934_.ImageTransparency = 0.55
	L_934_.ScaleType = Enum.ScaleType.Slice
	L_934_.SliceCenter = Rect.new(49, 49, 450, 450)
	L_934_.ZIndex = 199
	L_935_ = Instance.new("ImageLabel")
	L_936_ = next
	L_937_ = L_934_
	L_938_ = nil
	L_939_ = 450
	for L_1025_forvar0, L_1026_forvar1 in L_936_, L_937_, L_938_ do
		L_943_ = "Parent"
		L_944_ = (L_1025_forvar0 == "Parent")
		if not (L_944_) then
			L_935_[L_1025_forvar0] = L_1026_forvar1
		end
	end
	L_935_.Parent = L_934_.Parent
	L_935_ = {}
	L_935_.Parent = L_932_
	L_935_.BackgroundTransparency = 1
	L_935_.AnchorPoint = Vector2.new(0.5, 0.5)
	L_935_.Position = UDim2.new(0, 26, 0.5, 0)
	L_935_.Size = UDim2.new(0, 30, 0, 30)
	L_935_.Image = "rbxassetid://123802801726537"
	L_935_.ScaleType = Enum.ScaleType.Fit
	L_935_.ZIndex = 201
	L_933_ = L_935_
	L_936_ = Instance.new("ImageLabel")
	L_937_ = next
	L_938_ = L_935_
	L_939_ = nil
	L_940_ = 30
	for L_1027_forvar0, L_1028_forvar1 in L_937_, L_938_, L_939_ do
		L_943_ = "Parent"
		L_944_ = (L_1027_forvar0 == "Parent")
		if not (L_944_) then
			L_936_[L_1027_forvar0] = L_1028_forvar1
		end
	end
	L_936_.Parent = L_935_.Parent
	L_936_ = {}
	L_936_.Parent = L_932_
	L_936_.BackgroundTransparency = 1
	L_936_.Position = UDim2.new(0, 52, 0, 0)
	L_936_.Size = UDim2.new(1, -64, 1, 0)
	L_936_.Font = Enum.Font.GothamBlack
	L_936_.Text = "Snowy Studios"
	L_936_.TextColor3 = Color3.new(1, 1, 1)
	L_936_.TextSize = 15
	L_936_.TextXAlignment = Enum.TextXAlignment.Left
	L_936_.ZIndex = 201
	L_934_ = L_936_
	L_937_ = Instance.new("TextLabel")
	L_938_ = next
	L_939_ = L_936_
	L_940_ = nil
	L_941_ = 0
	for L_1029_forvar0, L_1030_forvar1 in L_938_, L_939_, L_940_ do
		L_943_ = "Parent"
		L_944_ = (L_1029_forvar0 == "Parent")
		if not (L_944_) then
			L_937_[L_1029_forvar0] = L_1030_forvar1
		end
	end
	L_937_.Parent = L_936_.Parent
	L_936_ = {}
	L_936_.Color = ColorSequence.new(upvalue_3.AccentGlow, upvalue_3.AccentBright)
	L_936_.Parent = L_937_
	L_935_ = L_937_
	L_937_ = Instance.new("UIGradient")
	L_938_ = next
	L_939_ = L_936_
	L_940_ = nil
	for L_1031_forvar0, L_1032_forvar1 in L_938_, L_939_, L_940_ do
		L_943_ = "Parent"
		L_944_ = (L_1031_forvar0 == "Parent")
		if not (L_944_) then
			L_937_[L_1031_forvar0] = L_1032_forvar1
		end
	end
	L_937_.Parent = L_936_.Parent
	upvalue_6:MakeDraggable(L_932_)
	task.spawn(L_1_.callback_90)
	L_929_.Activated:Connect(L_1_.callback_94)
	L_932_.Activated:Connect(L_1_.callback_93)
	L_939_ = {}
	L_939_.Current = nil
	L_939_.MainContainer = L_923_
	L_939_.CreateTab = L_1_.CreateTab

	return L_939_
end

L_1_.callback_127 = function()
	local L_1033_, L_1034_, L_1035_, L_1036_, L_1037_, L_1038_, L_1039_, L_1040_, L_1041_, L_1042_, L_1043_, L_1044_, L_1045_, L_1046_
	L_1039_ = {}
	L_1039_.Toggled = true
	L_1039_.Accent = Color3.fromRGB(0, 162, 255)
	L_1039_._blockDrag = false
	L_1041_ = {}
	L_1041_[1] = 16898613509
	L_1041_[2] = 48
	L_1041_[3] = 48
	L_1041_[4] = 820
	L_1041_[5] = 147
	L_1040_ = {}
	L_1040_.home = L_1041_
	L_1041_ = {}
	L_1041_[1] = 16898613353
	L_1041_[2] = 48
	L_1041_[3] = 48
	L_1041_[4] = 967
	L_1041_[5] = 306
	L_1040_.flame = L_1041_
	L_1041_ = {}
	L_1041_[1] = 16898613777
	L_1041_[2] = 48
	L_1041_[3] = 48
	L_1041_[4] = 771
	L_1041_[5] = 257
	L_1040_.settings = L_1041_
	L_1041_ = {}
	L_1041_[1] = 16898613869
	L_1041_[2] = 48
	L_1041_[3] = 48
	L_1041_[4] = 661
	L_1041_[5] = 869
	L_1040_.account = L_1041_
	L_1041_ = {}
	L_1041_[1] = 16898613353
	L_1041_[2] = 48
	L_1041_[3] = 48
	L_1041_[4] = 771
	L_1041_[5] = 563
	L_1040_.eye = L_1041_
	L_1041_ = {}
	L_1041_[1] = 16898613613
	L_1041_[2] = 48
	L_1041_[3] = 48
	L_1041_[4] = 820
	L_1041_[5] = 257
	L_1040_["map-pin"] = L_1041_
	L_1041_ = {}
	L_1041_[1] = 16898612629
	L_1041_[2] = 48
	L_1041_[3] = 48
	L_1041_[4] = 967
	L_1041_[5] = 710
	L_1040_["bar-chart-2"] = L_1041_
	L_1041_ = {}
	L_1041_[1] = 16898613777
	L_1041_[2] = 48
	L_1041_[3] = 48
	L_1041_[4] = 967
	L_1041_[5] = 759
	L_1040_.swords = L_1041_
	L_1041_ = {}
	L_1041_[1] = 16898613869
	L_1041_[2] = 48
	L_1041_[3] = 48
	L_1041_[4] = 661
	L_1041_[5] = 869
	L_1040_.user = L_1041_
	L_1041_ = {}
	L_1041_[1] = 16898613777
	L_1041_[2] = 48
	L_1041_[3] = 48
	L_1041_[4] = 869
	L_1041_[5] = 0
	L_1040_.shield = L_1041_
	L_1041_ = {}
	L_1041_[1] = 16898613869
	L_1041_[2] = 48
	L_1041_[3] = 48
	L_1041_[4] = 918
	L_1041_[5] = 906
	L_1040_.zap = L_1041_
	L_1041_ = {}
	L_1041_[1] = 16898613869
	L_1041_[2] = 48
	L_1041_[3] = 48
	L_1041_[4] = 514
	L_1041_[5] = 771
	L_1040_.target = L_1041_
	L_1041_ = {}
	L_1041_[1] = 16898613509
	L_1041_[2] = 48
	L_1041_[3] = 48
	L_1041_[4] = 771
	L_1041_[5] = 563
	L_1040_.globe = L_1041_
	L_1041_ = {}
	L_1041_[1] = 16898613509
	L_1041_[2] = 48
	L_1041_[3] = 48
	L_1041_[4] = 967
	L_1041_[5] = 612
	L_1040_.layout = L_1041_
	L_1041_ = {}
	L_1041_[1] = 16898613699
	L_1041_[2] = 48
	L_1041_[3] = 48
	L_1041_[4] = 918
	L_1041_[5] = 857
	L_1040_.search = L_1041_
	L_1041_ = {}
	L_1041_[1] = 16898613699
	L_1041_[2] = 48
	L_1041_[3] = 48
	L_1041_[4] = 918
	L_1041_[5] = 453
	L_1040_.save = L_1041_
	L_1041_ = {}
	L_1041_[1] = 16898613777
	L_1041_[2] = 48
	L_1041_[3] = 48
	L_1041_[4] = 404
	L_1041_[5] = 771
	L_1040_.sliders = L_1041_
	L_1039_.MakeDraggable = L_1_.MakeDraggable
	L_1039_.GetIcon = L_1_.GetIcon
	L_1039_.CreateWindow = L_1_.CreateWindow
	return L_1039_
end

L_1_.callback_128 = function(L_1047_arg0, L_1048_arg1, L_1049_arg2)
	local L_1050_, L_1051_, L_1052_, L_1053_, L_1054_, L_1055_, L_1056_, L_1057_
	L_1050_ = nil
	L_1051_ = nil
	L_1052_ = nil
	L_1053_ = type(L_1047_arg0)
	L_1054_ = L_1047_arg0
	L_1056_ = "table"
	L_1057_ = (type(L_1047_arg0) == "table")
	if L_1057_ then
		L_1050_ = L_1047_arg0
		L_1054_ = type(L_1048_arg1)
		L_1055_ = L_1048_arg1
		L_1056_ = "string"
		L_1057_ = (type(L_1048_arg1) == "string")
		if L_1057_ then
			L_1053_ = L_1048_arg1
			if not (L_1053_) then
				L_1053_ = nil
			end
		else
			L_1053_ = nil
		end
		L_1051_ = L_1053_
		L_1054_ = type(L_1048_arg1)
		L_1055_ = L_1048_arg1
		L_1056_ = "function"
		L_1057_ = (type(L_1048_arg1) == "function")
		if L_1057_ then
			L_1053_ = L_1048_arg1
			if not (L_1053_) then
				L_1053_ = L_1049_arg2
			end
		else
			L_1053_ = L_1049_arg2
		end
		L_1052_ = L_1053_
	else
		L_1050_ = L_1048_arg1
		L_1051_ = nil
		L_1052_ = L_1049_arg2
	end
	L_1053_ = L_1050_
	if L_1053_ then
		return L_1053_, L_1051_, L_1052_
	end
	L_1053_ = {}
	return L_1053_, L_1051_, L_1052_
end

L_1_.NewToggle = function(L_1058_arg0, L_1059_arg1, L_1060_arg2, L_1061_arg3)
	local L_1062_, L_1063_, L_1064_, L_1065_, L_1066_
	return upvalue_0:CreateToggle(L_1059_arg1, false, L_1061_arg3)
end

L_1_.NewSlider = function(L_1067_arg0, L_1068_arg1, L_1069_arg2, L_1070_arg3, L_1071_arg4, L_1072_arg5)
	local L_1073_, L_1074_, L_1075_, L_1076_, L_1077_, L_1078_, L_1079_
	return upvalue_0:CreateSlider(L_1068_arg1, L_1071_arg4, L_1070_arg3, L_1071_arg4, L_1072_arg5)
end

L_1_.NewButton = function(L_1080_arg0, L_1081_arg1, L_1082_arg2, L_1083_arg3)
	local L_1084_, L_1085_, L_1086_, L_1087_
	return upvalue_0:CreateButton(L_1081_arg1, L_1083_arg3)
end

L_1_.NewDropdown = function(L_1088_arg0, L_1089_arg1, L_1090_arg2, L_1091_arg3, L_1092_arg4)
	local L_1093_, L_1094_, L_1095_, L_1096_, L_1097_, L_1098_, L_1099_, L_1100_, L_1101_
	L_1093_ = upvalue_0
	L_1094_ = L_1090_arg2
	L_1095_ = L_1091_arg3
	L_1096_ = L_1092_arg4
	L_1093_, L_1094_, L_1095_ = upvalue_0(L_1090_arg2, L_1091_arg3, L_1092_arg4)
	return upvalue_1:CreateDropdown(L_1089_arg1, L_1093_, L_1094_, L_1095_)
end

L_1_.NewLabel = function(L_1102_arg0, L_1103_arg1)
	local L_1104_, L_1105_, L_1106_
	return upvalue_0:CreateLabel(L_1103_arg1)
end

L_1_.NewInput = function(L_1107_arg0, L_1108_arg1, L_1109_arg2, L_1110_arg3)
	local L_1111_, L_1112_, L_1113_, L_1114_, L_1115_
	return upvalue_0:CreateInput(L_1108_arg1, L_1109_arg2, L_1110_arg3)
end

L_1_.NewTitle = function(L_1116_arg0, L_1117_arg1)
	local L_1118_, L_1119_, L_1120_, L_1121_, L_1122_
	return upvalue_0:CreateLabel("\u{2726} " .. L_1117_arg1)
end

L_1_.NewSection = function(L_1123_arg0)
	local L_1124_
	return upvalue_0
end

L_1_.callback_137 = function()
	local L_1125_, L_1126_, L_1127_
	upvalue_0:Set(false)
	return
end

L_1_.callback_138 = function()
	local L_1128_, L_1129_
	pcall(L_1_.callback_137)
	task.wait()
	upvalue_1 = false
	return
end

L_1_.callback_139 = function(L_1130_arg0)
	local L_1131_, L_1132_
	L_1131_ = upvalue_0
	if L_1131_ then
		return
	end
	L_1131_ = _isPremiumUser()
	if L_1131_ then
		L_1131_ = upvalue_1
		if L_1131_ then
			upvalue_1(L_1130_arg0)
			return
		else
			return
		end
	else
		if not (L_1130_arg0) then
			return
		end
		upvalue_2(upvalue_3)
		upvalue_0 = true
		task.defer(L_1_.callback_138)
		L_1131_ = task.defer
		L_1132_ = L_1_.callback_138
		return
	end
end

L_1_.NewPremiumToggle = function(L_1133_arg0, L_1134_arg1, L_1135_arg2, L_1136_arg3)
	local L_1137_, L_1138_, L_1139_, L_1140_, L_1141_, L_1142_, L_1143_

	return upvalue_0:CreateToggle(_premTag(L_1134_arg1), false, L_1_.callback_139)
end

L_1_.callback_141 = function()
	local L_1144_, L_1145_
	L_1144_ = _isPremiumUser()
	if L_1144_ then
		L_1144_ = upvalue_0
		if L_1144_ then
			upvalue_0()
			return
		else
			return
		end
	else
		upvalue_1(upvalue_2)
		L_1144_ = upvalue_1
		L_1145_ = upvalue_2
		return
	end
end

L_1_.NewPremiumButton = function(L_1146_arg0, L_1147_arg1, L_1148_arg2, L_1149_arg3)
	local L_1150_, L_1151_, L_1152_, L_1153_
	return upvalue_0:CreateButton(_premTag(L_1147_arg1), L_1_.callback_141)
end

L_1_.callback_143 = function(L_1154_arg0)
	local L_1155_, L_1156_
	L_1155_ = _isPremiumUser()
	if L_1155_ then
		L_1155_ = upvalue_0
		if L_1155_ then
			upvalue_0(L_1154_arg0)
			return
		else
			return
		end
	else
		upvalue_1(upvalue_2)
		L_1155_ = upvalue_1
		L_1156_ = upvalue_2
		return
	end
end

L_1_.NewPremiumSlider = function(L_1157_arg0, L_1158_arg1, L_1159_arg2, L_1160_arg3, L_1161_arg4, L_1162_arg5)
	local L_1163_, L_1164_, L_1165_, L_1166_, L_1167_, L_1168_, L_1169_
	L_1163_ = upvalue_0
	L_1165_ = _premTag(L_1158_arg1)
	L_1166_ = L_1161_arg4
	if not (L_1166_) then
		L_1166_ = 0
	end
	L_1167_ = L_1160_arg3
	if not (L_1167_) then
		L_1167_ = 100
	end
	L_1168_ = L_1161_arg4
	if L_1168_ then
		return L_1163_:CreateSlider(L_1165_, L_1166_, L_1167_, L_1168_, L_1_.callback_143)
	end
	L_1168_ = 0
	return L_1163_:CreateSlider(L_1165_, L_1166_, L_1167_, L_1168_, L_1_.callback_143)
end

L_1_.callback_145 = function(L_1170_arg0)
	local L_1171_, L_1172_
	L_1171_ = _isPremiumUser()
	if L_1171_ then
		L_1171_ = upvalue_0
		if L_1171_ then
			upvalue_0(L_1170_arg0)
			return
		else
			return
		end
	else
		upvalue_1(upvalue_2)
		L_1171_ = upvalue_1
		L_1172_ = upvalue_2
		return
	end
end

L_1_.NewPremiumDropdown = function(L_1173_arg0, L_1174_arg1, L_1175_arg2, L_1176_arg3, L_1177_arg4)
	local L_1178_, L_1179_, L_1180_, L_1181_, L_1182_, L_1183_, L_1184_, L_1185_, L_1186_
	L_1178_ = upvalue_0
	L_1179_ = L_1175_arg2
	L_1180_ = L_1176_arg3
	L_1181_ = L_1177_arg4
	L_1178_, L_1179_, L_1180_ = upvalue_0(L_1175_arg2, L_1176_arg3, L_1177_arg4)
	return upvalue_1:CreateDropdown(_premTag(L_1174_arg1), L_1178_, L_1179_, L_1_.callback_145)
end

L_1_.NewSection_147 = function(L_1187_arg0, L_1188_arg1)
	local L_1189_, L_1190_, L_1191_, L_1192_, L_1193_, L_1194_, L_1195_
	L_1189_ = "layout"
	L_1190_ = L_1188_arg1
	if not (L_1190_) then
		L_1190_ = ""
	end
	L_1190_ = L_1190_:lower()
	L_1191_ = L_1190_:find("combat", 1, true)
	L_1192_ = L_1190_
	L_1193_ = "combat"
	L_1194_ = 1
	L_1195_ = true
	if L_1191_ then
		L_1189_ = "swords"
	else
		L_1191_ = L_1190_:find("visual", 1, true)
		L_1192_ = L_1190_
		L_1193_ = "visual"
		L_1194_ = 1
		L_1195_ = true
		if L_1191_ then
			L_1189_ = "eye"
		else
			L_1191_ = L_1190_:find("main", 1, true)
			L_1192_ = L_1190_
			L_1193_ = "main"
			L_1194_ = 1
			L_1195_ = true
			if L_1191_ then
				L_1189_ = "home"
			else
				L_1191_ = L_1190_:find("home", 1, true)
				L_1192_ = L_1190_
				L_1193_ = "home"
				L_1194_ = 1
				L_1195_ = true
				if L_1191_ then
					L_1189_ = "home"
				else
					L_1191_ = L_1190_:find("setting", 1, true)
					L_1192_ = L_1190_
					L_1193_ = "setting"
					L_1194_ = 1
					L_1195_ = true
					if L_1191_ then
						L_1189_ = "settings"
					else
						L_1191_ = L_1190_:find("config", 1, true)
						L_1192_ = L_1190_
						L_1193_ = "config"
						L_1194_ = 1
						L_1195_ = true
						if L_1191_ then
							L_1189_ = "settings"
						end
					end
				end
			end
		end
	end
	L_1191_ = L_1187_arg0.ActualTab
	L_1193_ = L_1188_arg1
	if not (L_1193_) then
		L_1193_ = "Main"
	end
	L_1191_ = L_1191_:CreateSubTab(L_1193_, L_1189_)
	L_1192_ = L_1191_
	L_1194_ = L_1188_arg1
	if L_1194_ then
		L_1193_ = {}
		L_1193_.NewToggle = L_1_.NewToggle
		L_1193_.NewSlider = L_1_.NewSlider
		L_1193_.NewButton = L_1_.NewButton
		L_1193_.NewDropdown = L_1_.NewDropdown
		L_1193_.NewLabel = L_1_.NewLabel
		L_1193_.NewInput = L_1_.NewInput
		L_1193_.NewTitle = L_1_.NewTitle
		L_1193_.NewSection = L_1_.NewSection
		L_1193_.NewPremiumToggle = L_1_.NewPremiumToggle
		L_1193_.NewPremiumButton = L_1_.NewPremiumButton
		L_1193_.NewPremiumSlider = L_1_.NewPremiumSlider
		L_1193_.NewPremiumDropdown = L_1_.NewPremiumDropdown
		return L_1193_
	end
	L_1194_ = "Main"
	L_1193_ = {}
	L_1193_.NewToggle = L_1_.NewToggle
	L_1193_.NewSlider = L_1_.NewSlider
	L_1193_.NewButton = L_1_.NewButton
	L_1193_.NewDropdown = L_1_.NewDropdown
	L_1193_.NewLabel = L_1_.NewLabel
	L_1193_.NewInput = L_1_.NewInput
	L_1193_.NewTitle = L_1_.NewTitle
	L_1193_.NewSection = L_1_.NewSection
	L_1193_.NewPremiumToggle = L_1_.NewPremiumToggle
	L_1193_.NewPremiumButton = L_1_.NewPremiumButton
	L_1193_.NewPremiumSlider = L_1_.NewPremiumSlider
	L_1193_.NewPremiumDropdown = L_1_.NewPremiumDropdown
	return L_1193_
end

L_1_.HideTabButton = function(L_1196_arg0)
	local L_1197_, L_1198_, L_1199_
	L_1196_arg0.ActualTab:SetVisible(false)
	return
end

L_1_.Select_149 = function(L_1200_arg0)
	local L_1201_, L_1202_
	L_1200_arg0.ActualTab:Select()
	return
end

L_1_.NewTab = function(L_1203_arg0, L_1204_arg1)
	local L_1205_, L_1206_, L_1207_, L_1208_, L_1209_, L_1210_, L_1211_
	L_1206_ = L_1204_arg1:lower()
	L_1205_ = "home"
	L_1207_ = L_1206_:find("aim", 1, true)
	L_1208_ = L_1206_
	L_1209_ = "aim"
	L_1210_ = 1
	L_1211_ = true

	L_1207_ = L_1206_:find("combat", 1, true)
	L_1208_ = L_1206_
	L_1209_ = "combat"
	L_1210_ = 1
	L_1211_ = true

	L_1207_ = L_1206_:find("kill", 1, true)
	L_1208_ = L_1206_
	L_1209_ = "kill"
	L_1210_ = 1
	L_1211_ = true

	L_1207_ = L_1206_:find("gun", 1, true)
	L_1208_ = L_1206_
	L_1209_ = "gun"
	L_1210_ = 1
	L_1211_ = true

	L_1205_ = "target"

	L_1207_ = L_1206_:find("player", 1, true)
	L_1208_ = L_1206_
	L_1209_ = "player"
	L_1210_ = 1
	L_1211_ = true

	L_1207_ = L_1206_:find("user", 1, true)
	L_1208_ = L_1206_
	L_1209_ = "user"
	L_1210_ = 1
	L_1211_ = true

	L_1207_ = L_1206_:find("char", 1, true)
	L_1208_ = L_1206_
	L_1209_ = "char"
	L_1210_ = 1
	L_1211_ = true

	L_1207_ = L_1206_:find("move", 1, true)
	L_1208_ = L_1206_
	L_1209_ = "move"
	L_1210_ = 1
	L_1211_ = true

	L_1205_ = "user"

	L_1207_ = L_1206_:find("visual", 1, true)
	L_1208_ = L_1206_
	L_1209_ = "visual"
	L_1210_ = 1
	L_1211_ = true

	L_1207_ = L_1206_:find("esp", 1, true)
	L_1208_ = L_1206_
	L_1209_ = "esp"
	L_1210_ = 1
	L_1211_ = true

	L_1207_ = L_1206_:find("eye", 1, true)
	L_1208_ = L_1206_
	L_1209_ = "eye"
	L_1210_ = 1
	L_1211_ = true

	L_1207_ = L_1206_:find("render", 1, true)
	L_1208_ = L_1206_
	L_1209_ = "render"
	L_1210_ = 1
	L_1211_ = true

	L_1205_ = "eye"

	L_1207_ = L_1206_:find("setting", 1, true)
	L_1208_ = L_1206_
	L_1209_ = "setting"
	L_1210_ = 1
	L_1211_ = true

	L_1207_ = L_1206_:find("config", 1, true)
	L_1208_ = L_1206_
	L_1209_ = "config"
	L_1210_ = 1
	L_1211_ = true

	L_1207_ = L_1206_:find("ui", 1, true)
	L_1208_ = L_1206_
	L_1209_ = "ui"
	L_1210_ = 1
	L_1211_ = true

	L_1205_ = "settings"

	L_1207_ = L_1206_:find("util", 1, true)
	L_1208_ = L_1206_
	L_1209_ = "util"
	L_1210_ = 1
	L_1211_ = true

	L_1207_ = L_1206_:find("misc", 1, true)
	L_1208_ = L_1206_
	L_1209_ = "misc"
	L_1210_ = 1
	L_1211_ = true

	L_1207_ = L_1206_:find("tool", 1, true)
	L_1208_ = L_1206_
	L_1209_ = "tool"
	L_1210_ = 1
	L_1211_ = true

	L_1205_ = "sliders"

	L_1207_ = L_1206_:find("game", 1, true)
	L_1208_ = L_1206_
	L_1209_ = "game"
	L_1210_ = 1
	L_1211_ = true

	L_1207_ = L_1206_:find("hub", 1, true)
	L_1208_ = L_1206_
	L_1209_ = "hub"
	L_1210_ = 1
	L_1211_ = true

	L_1207_ = L_1206_:find("main", 1, true)
	L_1208_ = L_1206_
	L_1209_ = "main"
	L_1210_ = 1
	L_1211_ = true

	L_1205_ = "layout"

	L_1208_ = {}
	L_1208_.ActualTab = upvalue_0:CreateTab(L_1204_arg1, L_1205_)
	L_1208_.NewSection = L_1_.NewSection_147
	L_1208_.HideTabButton = L_1_.HideTabButton
	L_1208_.Select = L_1_.Select_149
	do
		return L_1208_
	end
end

L_1_.CreateLib = function(L_1212_arg0, L_1213_arg1)
	local L_1214_, L_1215_, L_1216_
	L_1215_ = {}
	L_1215_.Tabs = {}
	L_1215_.Window = upvalue_0:CreateWindow(L_1212_arg0)
	L_1215_.NewTab = L_1_.NewTab
	return L_1215_
end

L_1_.callback_152 = function()
	local L_1217_, L_1218_
	return upvalue_0.Character
end

L_1_.callback_153 = function()
	local L_1219_, L_1220_, L_1221_, L_1222_
	L_1219_ = upvalue_0.Character
	L_1220_ = upvalue_0.Character
	if not (L_1220_) then
		return L_1220_
	end
	L_1220_ = L_1219_:FindFirstChildWhichIsA("Humanoid")
	L_1221_ = L_1219_
	L_1222_ = "Humanoid"
	return L_1220_
end

L_1_.callback_154 = function()
	local L_1223_, L_1224_, L_1225_, L_1226_
	L_1223_ = upvalue_0.Character
	L_1224_ = upvalue_0.Character
	if not (L_1224_) then
		return L_1224_
	end
	L_1224_ = L_1223_:FindFirstChild("HumanoidRootPart")
	L_1225_ = L_1223_
	L_1226_ = "HumanoidRootPart"
	return L_1224_
end

L_1_.callback_155 = function(...)
	local L_1227_, L_1228_, L_1229_, L_1230_, L_1231_, L_1232_, L_1233_, L_1234_, L_1235_, L_1236_, L_1237_, L_1238_, L_1239_, L_1240_, L_1241_, L_1242_
	L_1227_ = {
		...
	}
	L_1228_ = pairs
	L_1229_ = select(1, workspace:GetDescendants())
	L_1230_ = workspace
	L_1228_, L_1229_, L_1230_ = pairs(workspace:GetDescendants())
	for L_1243_forvar0, L_1244_forvar1 in L_1228_, L_1229_, L_1230_ do
		L_1233_ = pairs
		L_1234_ = L_1227_
		L_1233_, L_1234_, L_1235_ = pairs(L_1227_)
		for L_1245_forvar0, L_1246_forvar1 in L_1233_, L_1234_, L_1235_ do
			L_1238_ = L_1244_forvar1.Name:lower()
			L_1239_ = L_1246_forvar1:lower()
			L_1240_ = L_1246_forvar1
			L_1242_ = (L_1244_forvar1.Name:lower() == L_1246_forvar1:lower())
			if L_1242_ then
				L_1238_ = L_1244_forvar1:IsA("IntValue")
				L_1239_ = L_1244_forvar1
				L_1240_ = "IntValue"
				if L_1238_ then
					return L_1244_forvar1
				end
				L_1238_ = L_1244_forvar1:IsA("NumberValue")
				L_1239_ = L_1244_forvar1
				L_1240_ = "NumberValue"
				if L_1238_ then
					return L_1244_forvar1
				end
			end
		end
	end
	return nil
end

L_1_.callback_156 = function(L_1247_arg0, L_1248_arg1, L_1249_arg2)
	local L_1250_, L_1251_, L_1252_, L_1253_, L_1254_, L_1255_
	upvalue_0:Notify(L_1247_arg0, L_1248_arg1, L_1249_arg2, false)
	return
end

L_1_.callback_157 = function()
	local L_1256_, L_1257_, L_1258_
	L_1256_ = getgenv().__SnowyLoadingOverlay
	L_1257_ = getgenv()
	if not (L_1256_) then
		return
	end
	L_1256_:Destroy()
	L_1257_ = getgenv()
	L_1257_.__SnowyLoadingOverlay = nil
	L_1258_ = nil
	return
end

L_1_.gameTab = function()
	local L_1259_, L_1260_
	pcall(L_1_.callback_157)
	return
end

L_1_.NewToggle_159 = function()
	local L_1261_
	return
end

L_1_.NewSection_160 = function()
	local L_1262_
	return upvalue_0
end

L_1_.NewSection_161 = function()
	local L_1263_
	return upvalue_0
end

L_1_.callback_162 = function(L_1264_arg0, L_1265_arg1)
	local L_1266_, L_1267_, L_1268_, L_1269_, L_1270_
	L_1266_ = upvalue_0[L_1264_arg0]
	L_1267_ = upvalue_0
	if L_1266_ then
		return upvalue_1[L_1264_arg0]
	end
	L_1266_ = upvalue_2.Window
	L_1267_ = upvalue_2
	L_1268_ = L_1264_arg0
	L_1269_ = L_1265_arg1
	if L_1269_ then
		L_1266_ = L_1266_:CreateTab(L_1268_, L_1269_)
		L_1267_ = L_1266_:CreateSubTab("Main", "layout")
		L_1269_ = upvalue_0
		L_1269_[L_1264_arg0] = L_1266_
		L_1269_ = upvalue_1
		L_1269_[L_1264_arg0] = L_1267_:CreateSection("Features")
		return L_1267_:CreateSection("Features")
	end
	L_1269_ = "layout"
	L_1266_ = L_1266_:CreateTab(L_1268_, L_1269_)
	L_1267_ = L_1266_:CreateSubTab("Main", "layout")
	L_1269_ = upvalue_0
	L_1269_[L_1264_arg0] = L_1266_
	L_1269_ = upvalue_1
	L_1269_[L_1264_arg0] = L_1267_:CreateSection("Features")
	return L_1267_:CreateSection("Features")
end

L_1_.NewToggle_163 = function(L_1271_arg0, L_1272_arg1, L_1273_arg2, L_1274_arg3)
	local L_1275_, L_1276_, L_1277_, L_1278_, L_1279_
	return upvalue_0:CreateToggle(L_1272_arg1, false, L_1274_arg3)
end

L_1_.NewButton_164 = function(L_1280_arg0, L_1281_arg1, L_1282_arg2, L_1283_arg3)
	local L_1284_, L_1285_, L_1286_, L_1287_
	return upvalue_0:CreateButton(L_1281_arg1, L_1283_arg3)
end

L_1_.NewSlider_165 = function(L_1288_arg0, L_1289_arg1, L_1290_arg2, L_1291_arg3, L_1292_arg4, L_1293_arg5)
	local L_1294_, L_1295_, L_1296_, L_1297_, L_1298_, L_1299_, L_1300_
	L_1294_ = upvalue_0
	L_1296_ = L_1289_arg1
	L_1297_ = L_1292_arg4
	if not (L_1297_) then
		L_1297_ = 0
	end
	L_1298_ = L_1291_arg3
	if not (L_1298_) then
		L_1298_ = 100
	end
	L_1299_ = L_1292_arg4
	if L_1299_ then
		return L_1294_:CreateSlider(L_1296_, L_1297_, L_1298_, L_1299_, L_1293_arg5)
	end
	L_1299_ = 0
	return L_1294_:CreateSlider(L_1296_, L_1297_, L_1298_, L_1299_, L_1293_arg5)
end

L_1_.NewDropdown_166 = function(L_1301_arg0, L_1302_arg1, L_1303_arg2, L_1304_arg3, L_1305_arg4)
	local L_1306_, L_1307_, L_1308_, L_1309_, L_1310_, L_1311_, L_1312_, L_1313_, L_1314_
	L_1306_ = upvalue_0
	L_1307_ = L_1303_arg2
	L_1308_ = L_1304_arg3
	L_1309_ = L_1305_arg4
	L_1306_, L_1307_, L_1308_ = upvalue_0(L_1303_arg2, L_1304_arg3, L_1305_arg4)
	return upvalue_1:CreateDropdown(L_1302_arg1, L_1306_, L_1307_, L_1308_)
end

L_1_.NewLabel_167 = function(L_1315_arg0, L_1316_arg1)
	local L_1317_, L_1318_, L_1319_
	return upvalue_0:CreateLabel(L_1316_arg1)
end

L_1_.NewInput_168 = function(L_1320_arg0, L_1321_arg1, L_1322_arg2, L_1323_arg3)
	local L_1324_, L_1325_, L_1326_, L_1327_, L_1328_
	return upvalue_0:CreateInput(L_1321_arg1, L_1322_arg2, L_1323_arg3)
end

L_1_.NewTitle_169 = function(L_1329_arg0, L_1330_arg1)
	local L_1331_, L_1332_, L_1333_, L_1334_, L_1335_
	return upvalue_0:CreateLabel("\u{2726} " .. L_1330_arg1)
end

L_1_.NewSection_170 = function(L_1336_arg0)
	local L_1337_
	return upvalue_0
end

L_1_.callback_171 = function()
	local L_1338_, L_1339_, L_1340_
	upvalue_0:Set(false)
	return
end

L_1_.callback_172 = function()
	local L_1341_, L_1342_
	pcall(L_1_.callback_171)
	task.wait()
	upvalue_1 = false
	return
end

L_1_.callback_173 = function(L_1343_arg0)
	local L_1344_, L_1345_
	L_1344_ = upvalue_0
	if L_1344_ then
		return
	end
	L_1344_ = _isPremiumUser()
	if L_1344_ then
		L_1344_ = upvalue_1
		if L_1344_ then
			upvalue_1(L_1343_arg0)
			return
		else
			return
		end
	else
		if not (L_1343_arg0) then
			return
		end
		upvalue_2(upvalue_3)
		upvalue_0 = true
		task.defer(L_1_.callback_172)
		L_1344_ = task.defer
		L_1345_ = L_1_.callback_172
		return
	end
end

L_1_.NewPremiumToggle_174 = function(L_1346_arg0, L_1347_arg1, L_1348_arg2, L_1349_arg3)
	local L_1350_, L_1351_, L_1352_, L_1353_, L_1354_, L_1355_, L_1356_

	return upvalue_0:CreateToggle(_premTag(L_1347_arg1), false, L_1_.callback_173)
end

L_1_.callback_175 = function()
	local L_1357_, L_1358_
	L_1357_ = _isPremiumUser()
	if L_1357_ then
		L_1357_ = upvalue_0
		if L_1357_ then
			upvalue_0()
			return
		else
			return
		end
	else
		upvalue_1(upvalue_2)
		L_1357_ = upvalue_1
		L_1358_ = upvalue_2
		return
	end
end

L_1_.NewPremiumButton_176 = function(L_1359_arg0, L_1360_arg1, L_1361_arg2, L_1362_arg3)
	local L_1363_, L_1364_, L_1365_, L_1366_
	return upvalue_0:CreateButton(_premTag(L_1360_arg1), L_1_.callback_175)
end

L_1_.callback_177 = function(L_1367_arg0)
	local L_1368_, L_1369_
	L_1368_ = _isPremiumUser()
	if L_1368_ then
		L_1368_ = upvalue_0
		if L_1368_ then
			upvalue_0(L_1367_arg0)
			return
		else
			return
		end
	else
		upvalue_1(upvalue_2)
		L_1368_ = upvalue_1
		L_1369_ = upvalue_2
		return
	end
end

L_1_.NewPremiumSlider_178 = function(L_1370_arg0, L_1371_arg1, L_1372_arg2, L_1373_arg3, L_1374_arg4, L_1375_arg5)
	local L_1376_, L_1377_, L_1378_, L_1379_, L_1380_, L_1381_, L_1382_
	L_1376_ = upvalue_0
	L_1378_ = _premTag(L_1371_arg1)
	L_1379_ = L_1374_arg4
	if not (L_1379_) then
		L_1379_ = 0
	end
	L_1380_ = L_1373_arg3
	if not (L_1380_) then
		L_1380_ = 100
	end
	L_1381_ = L_1374_arg4
	if L_1381_ then
		return L_1376_:CreateSlider(L_1378_, L_1379_, L_1380_, L_1381_, L_1_.callback_177)
	end
	L_1381_ = 0
	return L_1376_:CreateSlider(L_1378_, L_1379_, L_1380_, L_1381_, L_1_.callback_177)
end

L_1_.callback_179 = function(L_1383_arg0)
	local L_1384_, L_1385_
	L_1384_ = _isPremiumUser()
	if L_1384_ then
		L_1384_ = upvalue_0
		if L_1384_ then
			upvalue_0(L_1383_arg0)
			return
		else
			return
		end
	else
		upvalue_1(upvalue_2)
		L_1384_ = upvalue_1
		L_1385_ = upvalue_2
		return
	end
end

L_1_.NewPremiumDropdown_180 = function(L_1386_arg0, L_1387_arg1, L_1388_arg2, L_1389_arg3, L_1390_arg4)
	local L_1391_, L_1392_, L_1393_, L_1394_, L_1395_, L_1396_, L_1397_, L_1398_, L_1399_
	L_1391_ = upvalue_0
	L_1392_ = L_1388_arg2
	L_1393_ = L_1389_arg3
	L_1394_ = L_1390_arg4
	L_1391_, L_1392_, L_1393_ = upvalue_0(L_1388_arg2, L_1389_arg3, L_1390_arg4)
	return upvalue_1:CreateDropdown(_premTag(L_1387_arg1), L_1391_, L_1392_, L_1_.callback_179)
end

L_1_.NewSection_181 = function(L_1400_arg0, L_1401_arg1)
	local L_1402_, L_1403_, L_1404_, L_1405_, L_1406_, L_1407_, L_1408_, L_1409_, L_1410_, L_1411_, L_1412_, L_1413_
	L_1402_ = L_1401_arg1

	L_1402_ = "General"

	L_1403_ = L_1402_:lower()
	L_1404_ = "General"
	L_1405_ = "globe"
	L_1406_ = L_1403_:find("free feat")
	L_1407_ = L_1403_
	L_1408_ = "free feat"

	L_1404_ = "Free"
	L_1405_ = "home"

	L_1406_ = L_1403_:find("premium feat")
	L_1407_ = L_1403_
	L_1408_ = "premium feat"

	L_1404_ = "Premium"
	L_1405_ = "zap"

	L_1406_ = L_1403_:find("combat")
	L_1407_ = L_1403_
	L_1408_ = "combat"

	L_1406_ = L_1403_:find("aimbot")
	L_1407_ = L_1403_
	L_1408_ = "aimbot"

	L_1406_ = L_1403_:find("aim")
	L_1407_ = L_1403_
	L_1408_ = "aim"

	L_1406_ = L_1403_:find("weapon")
	L_1407_ = L_1403_
	L_1408_ = "weapon"

	L_1406_ = L_1403_:find("gun")
	L_1407_ = L_1403_
	L_1408_ = "gun"

	L_1406_ = L_1403_:find("silent")
	L_1407_ = L_1403_
	L_1408_ = "silent"

	L_1406_ = L_1403_:find("aura")
	L_1407_ = L_1403_
	L_1408_ = "aura"

	L_1404_ = "Combat"
	L_1405_ = "swords"

	L_1406_ = L_1403_:find("esp")
	L_1407_ = L_1403_
	L_1408_ = "esp"

	L_1406_ = L_1403_:find("visual")
	L_1407_ = L_1403_
	L_1408_ = "visual"

	L_1406_ = L_1403_:find("wallhack")
	L_1407_ = L_1403_
	L_1408_ = "wallhack"

	L_1406_ = L_1403_:find("radar")
	L_1407_ = L_1403_
	L_1408_ = "radar"

	L_1406_ = L_1403_:find("chams")
	L_1407_ = L_1403_
	L_1408_ = "chams"

	L_1406_ = L_1403_:find("render")
	L_1407_ = L_1403_
	L_1408_ = "render"

	L_1404_ = "Visuals"
	L_1405_ = "eye"

	L_1406_ = L_1403_:find("move")
	L_1407_ = L_1403_
	L_1408_ = "move"

	L_1406_ = L_1403_:find("fly")
	L_1407_ = L_1403_
	L_1408_ = "fly"

	L_1406_ = L_1403_:find("speed")
	L_1407_ = L_1403_
	L_1408_ = "speed"

	L_1406_ = L_1403_:find("noclip")
	L_1407_ = L_1403_
	L_1408_ = "noclip"

	L_1406_ = L_1403_:find("jump")
	L_1407_ = L_1403_
	L_1408_ = "jump"

	L_1406_ = L_1403_:find("travel")
	L_1407_ = L_1403_
	L_1408_ = "travel"

	L_1406_ = L_1403_:find("tp")
	L_1407_ = L_1403_
	L_1408_ = "tp"

	L_1406_ = L_1403_:find("teleport")
	L_1407_ = L_1403_
	L_1408_ = "teleport"

	L_1404_ = "Movement"
	L_1405_ = "bar-chart-2"

	L_1406_ = L_1403_:find("farm")
	L_1407_ = L_1403_
	L_1408_ = "farm"

	L_1406_ = L_1403_:find("auto")
	L_1407_ = L_1403_
	L_1408_ = "auto"

	L_1406_ = L_1403_:find("fish")
	L_1407_ = L_1403_
	L_1408_ = "fish"

	L_1406_ = L_1403_:find("chest")
	L_1407_ = L_1403_
	L_1408_ = "chest"

	L_1406_ = L_1403_:find("collect")
	L_1407_ = L_1403_
	L_1408_ = "collect"

	L_1406_ = L_1403_:find("resource")
	L_1407_ = L_1403_
	L_1408_ = "resource"

	L_1404_ = "AutoFarm"
	L_1405_ = "zap"

	L_1406_ = L_1403_:find("survival")
	L_1407_ = L_1403_
	L_1408_ = "survival"

	L_1406_ = L_1403_:find("god")
	L_1407_ = L_1403_
	L_1408_ = "god"

	L_1406_ = L_1403_:find("oxygen")
	L_1407_ = L_1403_
	L_1408_ = "oxygen"

	L_1406_ = L_1403_:find("survive")
	L_1407_ = L_1403_
	L_1408_ = "survive"

	L_1406_ = L_1403_:find("anti")
	L_1407_ = L_1403_
	L_1408_ = "anti"

	L_1404_ = "Survival"
	L_1405_ = "shield"

	L_1406_ = L_1403_:find("troll")
	L_1407_ = L_1403_
	L_1408_ = "troll"

	L_1406_ = L_1403_:find("rage")
	L_1407_ = L_1403_
	L_1408_ = "rage"

	L_1406_ = L_1403_:find("hitbox")
	L_1407_ = L_1403_
	L_1408_ = "hitbox"

	L_1404_ = "Rage"
	L_1405_ = "flame"

	L_1406_ = L_1403_:find("misc")
	L_1407_ = L_1403_
	L_1408_ = "misc"

	L_1406_ = L_1403_:find("util")
	L_1407_ = L_1403_
	L_1408_ = "util"

	L_1406_ = L_1403_:find("extra")
	L_1407_ = L_1403_
	L_1408_ = "extra"

	L_1406_ = L_1403_:find("general")
	L_1407_ = L_1403_
	L_1408_ = "general"

	L_1406_ = L_1403_:find("server")
	L_1407_ = L_1403_
	L_1408_ = "server"

	L_1404_ = "Utility"
	L_1405_ = "sliders"

	L_1406_ = L_1403_:find("economy")
	L_1407_ = L_1403_
	L_1408_ = "economy"

	L_1406_ = L_1403_:find("money")
	L_1407_ = L_1403_
	L_1408_ = "money"

	L_1406_ = L_1403_:find("shop")
	L_1407_ = L_1403_
	L_1408_ = "shop"

	L_1404_ = "Economy"
	L_1405_ = "bar-chart-2"

	L_1406_ = L_1403_:find("belt")
	L_1407_ = L_1403_
	L_1408_ = "belt"

	L_1404_ = "Belts"
	L_1405_ = "layout"

	L_1406_ = L_1403_:find("tank")
	L_1407_ = L_1403_
	L_1408_ = "tank"

	L_1404_ = "Tanks"
	L_1405_ = "layout"

	L_1406_ = L_1403_:find("slot")
	L_1407_ = L_1403_
	L_1408_ = "slot"

	L_1404_ = "Slots"
	L_1405_ = "layout"

	L_1407_ = L_1404_
	L_1408_ = L_1405_
	L_1409_ = upvalue_0[L_1404_]
	L_1410_ = upvalue_0

	L_1406_ = upvalue_1[L_1407_]
	L_1409_ = upvalue_1

	L_1409_ = upvalue_2.Window
	L_1410_ = upvalue_2
	L_1411_ = L_1407_
	L_1412_ = L_1408_

	L_1412_ = "layout"

	L_1409_ = L_1409_:CreateTab(L_1411_, L_1412_)
	L_1410_ = L_1409_:CreateSubTab("Main", "layout")
	L_1412_ = upvalue_0
	L_1412_[L_1407_] = L_1409_
	L_1412_ = upvalue_1
	L_1412_[L_1407_] = L_1410_:CreateSection("Features")
	L_1406_ = L_1410_:CreateSection("Features")
	L_1411_ = L_1410_:CreateSection("Features")
	L_1413_ = "Features"

	L_1406_:CreateLabel("\u{2500}\u{2500} " .. L_1402_ .. " \u{2500}\u{2500}")
	L_1407_ = {}
	L_1407_.NewToggle = L_1_.NewToggle_163
	L_1407_.NewButton = L_1_.NewButton_164
	L_1407_.NewSlider = L_1_.NewSlider_165
	L_1407_.NewDropdown = L_1_.NewDropdown_166
	L_1407_.NewLabel = L_1_.NewLabel_167
	L_1407_.NewInput = L_1_.NewInput_168
	L_1407_.NewTitle = L_1_.NewTitle_169
	L_1407_.NewSection = L_1_.NewSection_170
	L_1407_.NewPremiumToggle = L_1_.NewPremiumToggle_174
	L_1407_.NewPremiumButton = L_1_.NewPremiumButton_176
	L_1407_.NewPremiumSlider = L_1_.NewPremiumSlider_178
	L_1407_.NewPremiumDropdown = L_1_.NewPremiumDropdown_180
	do
		return L_1407_
	end
end

L_1_.NewToggle_182 = function()
	local L_1414_
	return
end

L_1_.gameTab_183 = function(L_1415_arg0, L_1416_arg1)
	local L_1417_, L_1418_, L_1419_, L_1420_, L_1421_, L_1422_, L_1423_
	L_1417_ = upvalue_0
	if not (L_1417_) then
		L_1418_ = {}
		L_1418_.NewToggle = L_1_.NewToggle_159
		L_1418_.NewButton = L_1_.NewToggle_159
		L_1418_.NewSlider = L_1_.NewToggle_159
		L_1418_.NewDropdown = L_1_.NewToggle_159
		L_1418_.NewLabel = L_1_.NewToggle_159
		L_1418_.NewPremiumToggle = L_1_.NewToggle_159
		L_1418_.NewPremiumButton = L_1_.NewToggle_159
		L_1418_.NewPremiumSlider = L_1_.NewToggle_159
		L_1418_.NewPremiumDropdown = L_1_.NewToggle_159
		L_1418_.NewSection = L_1_.NewSection_160
		L_1419_ = {}
		L_1419_.NewSection = L_1_.NewSection_161
		L_1419_.NewToggle = L_1_.NewToggle_159
		L_1419_.NewButton = L_1_.NewToggle_159
		L_1419_.NewSlider = L_1_.NewToggle_159
		L_1419_.NewDropdown = L_1_.NewToggle_159
		L_1419_.NewPremiumToggle = L_1_.NewToggle_159
		L_1419_.NewPremiumButton = L_1_.NewToggle_159
		L_1419_.NewPremiumSlider = L_1_.NewToggle_159
		L_1419_.NewPremiumDropdown = L_1_.NewToggle_159
		return L_1419_
	end
	L_1417_ = upvalue_0.name:lower()
	L_1418_ = L_1415_arg0:lower()
	L_1419_ = L_1415_arg0
	L_1423_ = (upvalue_0.name:lower() == L_1415_arg0:lower())
	if L_1423_ then
		L_1420_ = {}
		L_1420_.NewSection = L_1_.NewSection_181
		L_1420_.NewToggle = L_1_.NewToggle_182
		L_1420_.NewButton = L_1_.NewToggle_182
		L_1420_.NewSlider = L_1_.NewToggle_182
		return L_1420_
	else
		L_1418_ = {}
		L_1418_.NewToggle = L_1_.NewToggle_159
		L_1418_.NewButton = L_1_.NewToggle_159
		L_1418_.NewSlider = L_1_.NewToggle_159
		L_1418_.NewDropdown = L_1_.NewToggle_159
		L_1418_.NewLabel = L_1_.NewToggle_159
		L_1418_.NewPremiumToggle = L_1_.NewToggle_159
		L_1418_.NewPremiumButton = L_1_.NewToggle_159
		L_1418_.NewPremiumSlider = L_1_.NewToggle_159
		L_1418_.NewPremiumDropdown = L_1_.NewToggle_159
		L_1418_.NewSection = L_1_.NewSection_160
		L_1419_ = {}
		L_1419_.NewSection = L_1_.NewSection_161
		L_1419_.NewToggle = L_1_.NewToggle_159
		L_1419_.NewButton = L_1_.NewToggle_159
		L_1419_.NewSlider = L_1_.NewToggle_159
		L_1419_.NewDropdown = L_1_.NewToggle_159
		L_1419_.NewPremiumToggle = L_1_.NewToggle_159
		L_1419_.NewPremiumButton = L_1_.NewToggle_159
		L_1419_.NewPremiumSlider = L_1_.NewToggle_159
		L_1419_.NewPremiumDropdown = L_1_.NewToggle_159
		return L_1419_
	end
end

L_1_.callback_184 = function(L_1424_arg0, L_1425_arg1)
	local L_1426_, L_1427_, L_1428_, L_1429_, L_1430_, L_1431_, L_1432_, L_1433_, L_1434_, L_1435_, L_1436_, L_1437_, L_1438_, L_1439_, L_1440_, L_1441_
	local L_1442_, L_1443_, L_1444_
	L_1426_ = L_1424_arg0
	if not (L_1426_) then
		L_1426_ = ""
	end
	L_1426_ = L_1426_:lower()
	L_1427_ = L_1425_arg1
	if not (L_1427_) then
		L_1427_ = ""
	end
	L_1428_ = {}
	L_1428_[1] = "auto"
	L_1428_[2] = "farm"
	L_1428_[3] = "kill"
	L_1428_[4] = "aura"
	L_1428_[5] = "tp"
	L_1428_[6] = "teleport"
	L_1428_[7] = "fly"
	L_1428_[8] = "speed"
	L_1428_[9] = "click"
	L_1428_[10] = "mansion"
	L_1428_[11] = "oil"
	L_1428_[12] = "ship"
	L_1428_[13] = "airdrop"
	L_1428_[14] = "rob"
	L_1428_[15] = "npc"
	L_1428_[16] = "turret"
	L_1428_[17] = "glider"
	L_1428_[18] = "items"
	L_1428_[19] = "give"
	L_1427_ = L_1427_:lower()
	L_1429_ = ipairs
	L_1430_ = L_1428_
	L_1431_ = "give"
	L_1432_ = "aura"
	L_1433_ = "tp"
	L_1434_ = "teleport"
	L_1435_ = "fly"
	L_1436_ = "speed"
	L_1437_ = "click"
	L_1438_ = "mansion"
	L_1439_ = "oil"
	L_1440_ = "ship"
	L_1441_ = "airdrop"
	L_1442_ = "rob"
	L_1443_ = "npc"
	L_1444_ = "turret"
	L_1429_, L_1430_, L_1431_ = ipairs(L_1428_)
	for L_1445_forvar0, L_1446_forvar1 in L_1429_, L_1430_, L_1431_ do
		L_1434_ = L_1426_:find(L_1446_forvar1, 1, true)
		L_1435_ = L_1426_
		L_1436_ = L_1446_forvar1
		L_1437_ = 1
		L_1438_ = true
		if L_1434_ then
			return true
		end
		L_1434_ = L_1427_:find(L_1446_forvar1, 1, true)
		L_1435_ = L_1427_
		L_1436_ = L_1446_forvar1
		L_1437_ = 1
		L_1438_ = true
		if L_1434_ then
			return true
		end
	end
	return false
end

L_1_.AddSection = function(L_1447_arg0, L_1448_arg1)
	return L_1447_arg0
end

L_1_.AddButton = function(L_1449_arg0, L_1450_arg1)
	local L_1451_, L_1452_, L_1453_, L_1454_, L_1455_, L_1456_
	L_1451_ = upvalue_0
	L_1452_ = L_1450_arg1.Title
	if not (L_1452_) then
		L_1452_ = L_1450_arg1.Name
	end
	L_1453_ = L_1450_arg1.Description
	if not (L_1453_) then
		L_1453_ = L_1450_arg1.Desc
	end
	L_1451_ = L_1451_(L_1452_, L_1453_)
	if L_1451_ then
		L_1452_ = upvalue_1
		L_1454_ = L_1450_arg1.Title
		if not (L_1454_) then
			L_1454_ = L_1450_arg1.Name
			if not (L_1454_) then
				L_1454_ = "Button"
			end
		end
		L_1455_ = L_1450_arg1.Description
		if L_1455_ then
			L_1452_:NewPremiumButton(L_1454_, L_1455_, L_1450_arg1.Callback)
			return
		end
		L_1455_ = L_1450_arg1.Desc
		if L_1455_ then
			L_1452_:NewPremiumButton(L_1454_, L_1455_, L_1450_arg1.Callback)
			return
		end
		L_1455_ = ""
		L_1452_:NewPremiumButton(L_1454_, L_1455_, L_1450_arg1.Callback)
		return
	else
		L_1452_ = upvalue_2
		L_1454_ = L_1450_arg1.Title
		if not (L_1454_) then
			L_1454_ = L_1450_arg1.Name
			if not (L_1454_) then
				L_1454_ = "Button"
			end
		end
		L_1455_ = L_1450_arg1.Description
		if L_1455_ then
			L_1452_:NewButton(L_1454_, L_1455_, L_1450_arg1.Callback)
			return
		end
		L_1455_ = L_1450_arg1.Desc
		if L_1455_ then
			L_1452_:NewButton(L_1454_, L_1455_, L_1450_arg1.Callback)
			return
		end
		L_1455_ = ""
		L_1452_:NewButton(L_1454_, L_1455_, L_1450_arg1.Callback)
		return
	end
end

L_1_.callback_187 = function()
	local L_1457_, L_1458_
	upvalue_0(upvalue_1)
	return
end

L_1_.callback_188 = function(L_1459_arg0)
	local L_1460_, L_1461_
	L_1460_ = upvalue_0
	if not (L_1460_) then
		return
	end
	pcall(L_1_.callback_187)
	L_1460_ = pcall
	L_1461_ = L_1_.callback_187
	return
end

L_1_.callback_189 = function()
	local L_1462_, L_1463_
	upvalue_0(upvalue_1)
	return
end

L_1_.callback_190 = function(L_1464_arg0)
	local L_1465_, L_1466_
	L_1465_ = upvalue_0
	if not (L_1465_) then
		return
	end
	pcall(L_1_.callback_189)
	L_1465_ = pcall
	L_1466_ = L_1_.callback_189
	return
end

L_1_.OnChanged = function()
	local L_1467_, L_1468_, L_1469_
	upvalue_0:Set(upvalue_1)
	return
end

L_1_.OnChanged_192 = function(L_1470_arg0, L_1471_arg1)
	local L_1472_
	upvalue_0 = L_1471_arg1
	return upvalue_1
end

L_1_.callback_193 = function()
	local L_1473_, L_1474_, L_1475_
	upvalue_0:Set(upvalue_1)
	return
end

L_1_.SetValue = function(L_1476_arg0, L_1477_arg1)
	local L_1478_, L_1479_
	pcall(L_1_.callback_193)
	return
end

L_1_.AddToggle = function(L_1480_arg0, L_1481_arg1, L_1482_arg2)
	local L_1483_, L_1484_, L_1485_, L_1486_, L_1487_, L_1488_, L_1489_, L_1490_, L_1491_, L_1492_, L_1493_, L_1494_, L_1495_
	L_1483_ = L_1482_arg2
	if not (L_1483_) then
		L_1483_ = L_1481_arg1
	end
	L_1484_ = L_1483_.Title
	if not (L_1484_) then
		L_1484_ = L_1483_.Name
		if not (L_1484_) then
			L_1484_ = "Toggle"
		end
	end
	L_1485_ = L_1483_.Description
	if not (L_1485_) then
		L_1485_ = L_1483_.Desc
		if not (L_1485_) then
			L_1485_ = ""
		end
	end
	L_1486_ = L_1483_.Callback
	L_1487_ = L_1483_.Default
	L_1488_ = L_1483_.Default
	if not (L_1487_) then
		L_1487_ = false
	end
	L_1488_ = upvalue_0(L_1484_, L_1485_)
	L_1489_ = L_1486_
	L_1490_ = nil
	if L_1488_ then
		L_1490_ = upvalue_1:NewPremiumToggle(L_1484_, L_1485_, L_1_.callback_188)
		L_1491_ = upvalue_1:NewPremiumToggle(L_1484_, L_1485_, L_1_.callback_188)
		L_1492_ = upvalue_1
		L_1493_ = L_1484_
		L_1494_ = L_1485_
		L_1495_ = L_1_.callback_188
	else
		L_1490_ = upvalue_2:NewToggle(L_1484_, L_1485_, L_1_.callback_190)
		L_1491_ = upvalue_2:NewToggle(L_1484_, L_1485_, L_1_.callback_190)
		L_1492_ = upvalue_2
		L_1493_ = L_1484_
		L_1494_ = L_1485_
		L_1495_ = L_1_.callback_190
	end
	if not (L_1487_) then
		L_1491_ = {}
		L_1491_.OnChanged = L_1_.OnChanged_192
		L_1491_.SetValue = L_1_.SetValue

		return L_1491_
	end
	if not (L_1490_) then
		L_1491_ = {}
		L_1491_.OnChanged = L_1_.OnChanged_192
		L_1491_.SetValue = L_1_.SetValue

		return L_1491_
	end
	L_1491_ = L_1490_.Set
	if not (L_1491_) then
		L_1491_ = {}
		L_1491_.OnChanged = L_1_.OnChanged_192
		L_1491_.SetValue = L_1_.SetValue

		return L_1491_
	end
	pcall(L_1_.OnChanged)
	L_1491_ = pcall
	L_1492_ = L_1_.OnChanged
	L_1491_ = {}
	L_1491_.OnChanged = L_1_.OnChanged_192
	L_1491_.SetValue = L_1_.SetValue

	return L_1491_
end

L_1_.callback_196 = function()
	local L_1496_, L_1497_
	upvalue_0(upvalue_1)
	return
end

L_1_.callback_197 = function(L_1498_arg0)
	local L_1499_, L_1500_
	L_1499_ = upvalue_0
	if not (L_1499_) then
		return
	end
	pcall(L_1_.callback_196)
	L_1499_ = pcall
	L_1500_ = L_1_.callback_196
	return
end

L_1_.callback_198 = function()
	local L_1501_, L_1502_
	upvalue_0(upvalue_1)
	return
end

L_1_.callback_199 = function(L_1503_arg0)
	local L_1504_, L_1505_
	L_1504_ = upvalue_0
	if not (L_1504_) then
		return
	end
	pcall(L_1_.callback_198)
	L_1504_ = pcall
	L_1505_ = L_1_.callback_198
	return
end

L_1_.OnChanged_200 = function()
	local L_1506_, L_1507_, L_1508_
	upvalue_0:Set(upvalue_1)
	return
end

L_1_.OnChanged_201 = function(L_1509_arg0, L_1510_arg1)
	local L_1511_
	upvalue_0 = L_1510_arg1
	return upvalue_1
end

L_1_.callback_202 = function()
	local L_1512_, L_1513_, L_1514_
	upvalue_0:Set(upvalue_1)
	return
end

L_1_.SetValue_203 = function(L_1515_arg0, L_1516_arg1)
	local L_1517_, L_1518_
	pcall(L_1_.callback_202)
	return
end

L_1_.AddSlider = function(L_1519_arg0, L_1520_arg1, L_1521_arg2)
	local L_1522_, L_1523_, L_1524_, L_1525_, L_1526_, L_1527_, L_1528_, L_1529_, L_1530_, L_1531_, L_1532_, L_1533_, L_1534_, L_1535_, L_1536_, L_1537_
	local L_1538_
	L_1522_ = L_1521_arg2
	if not (L_1522_) then
		L_1522_ = L_1520_arg1
	end
	L_1523_ = L_1522_.Title
	if not (L_1523_) then
		L_1523_ = L_1522_.Name
		if not (L_1523_) then
			L_1523_ = "Slider"
		end
	end
	L_1524_ = L_1522_.Description
	if not (L_1524_) then
		L_1524_ = L_1522_.Desc
		if not (L_1524_) then
			L_1524_ = ""
		end
	end
	L_1525_ = L_1522_.Callback
	L_1526_ = L_1522_.Min
	L_1527_ = L_1522_.Min
	if not (L_1526_) then
		L_1526_ = 0
	end
	L_1527_ = L_1522_.Max
	L_1528_ = L_1522_.Max
	if not (L_1527_) then
		L_1527_ = 100
	end
	L_1528_ = L_1522_.Default
	L_1529_ = L_1522_.Default
	if not (L_1528_) then
		L_1528_ = L_1526_
	end
	L_1529_ = upvalue_0(L_1523_, L_1524_)
	L_1530_ = L_1525_
	L_1531_ = nil
	if L_1529_ then
		L_1531_ = upvalue_1:NewPremiumSlider(L_1523_, L_1524_, L_1527_, L_1526_, L_1_.callback_197)
		L_1532_ = upvalue_1:NewPremiumSlider(L_1523_, L_1524_, L_1527_, L_1526_, L_1_.callback_197)
		L_1533_ = upvalue_1
		L_1534_ = L_1523_
		L_1535_ = L_1524_
		L_1536_ = L_1527_
		L_1537_ = L_1526_
		L_1538_ = L_1_.callback_197
	else
		L_1531_ = upvalue_2:NewSlider(L_1523_, L_1524_, L_1527_, L_1526_, L_1_.callback_199)
		L_1532_ = upvalue_2:NewSlider(L_1523_, L_1524_, L_1527_, L_1526_, L_1_.callback_199)
		L_1533_ = upvalue_2
		L_1534_ = L_1523_
		L_1535_ = L_1524_
		L_1536_ = L_1527_
		L_1537_ = L_1526_
		L_1538_ = L_1_.callback_199
	end
	if not (L_1528_) then
		L_1532_ = {}
		L_1532_.OnChanged = L_1_.OnChanged_201
		L_1532_.SetValue = L_1_.SetValue_203

		return L_1532_
	end
	if not (L_1531_) then
		L_1532_ = {}
		L_1532_.OnChanged = L_1_.OnChanged_201
		L_1532_.SetValue = L_1_.SetValue_203

		return L_1532_
	end
	L_1532_ = L_1531_.Set
	if not (L_1532_) then
		L_1532_ = {}
		L_1532_.OnChanged = L_1_.OnChanged_201
		L_1532_.SetValue = L_1_.SetValue_203

		return L_1532_
	end
	pcall(L_1_.OnChanged_200)
	L_1532_ = pcall
	L_1533_ = L_1_.OnChanged_200
	L_1532_ = {}
	L_1532_.OnChanged = L_1_.OnChanged_201
	L_1532_.SetValue = L_1_.SetValue_203

	return L_1532_
end

L_1_.callback_205 = function()
	local L_1539_, L_1540_
	upvalue_0(upvalue_1)
	return
end

L_1_.callback_206 = function(L_1541_arg0)
	local L_1542_, L_1543_
	L_1542_ = upvalue_0
	if not (L_1542_) then
		return
	end
	pcall(L_1_.callback_205)
	L_1542_ = pcall
	L_1543_ = L_1_.callback_205
	return
end

L_1_.callback_207 = function()
	local L_1544_, L_1545_
	upvalue_0(upvalue_1)
	return
end

L_1_.callback_208 = function(L_1546_arg0)
	local L_1547_, L_1548_
	L_1547_ = upvalue_0
	if not (L_1547_) then
		return
	end
	pcall(L_1_.callback_207)
	L_1547_ = pcall
	L_1548_ = L_1_.callback_207
	return
end

L_1_.OnChanged_209 = function()
	local L_1549_, L_1550_, L_1551_
	upvalue_0:Set(upvalue_1)
	return
end

L_1_.OnChanged_210 = function(L_1552_arg0, L_1553_arg1)
	local L_1554_
	upvalue_0 = L_1553_arg1
	return upvalue_1
end

L_1_.callback_211 = function()
	local L_1555_, L_1556_, L_1557_
	upvalue_0:Set(upvalue_1)
	return
end

L_1_.SetValue_212 = function(L_1558_arg0, L_1559_arg1)
	local L_1560_, L_1561_
	pcall(L_1_.callback_211)
	return
end

L_1_.AddDropdown = function(L_1562_arg0, L_1563_arg1, L_1564_arg2)
	local L_1565_, L_1566_, L_1567_, L_1568_, L_1569_, L_1570_, L_1571_, L_1572_, L_1573_, L_1574_, L_1575_, L_1576_, L_1577_, L_1578_, L_1579_
	L_1565_ = L_1564_arg2
	if not (L_1565_) then
		L_1565_ = L_1563_arg1
	end
	L_1566_ = L_1565_.Title
	if not (L_1566_) then
		L_1566_ = L_1565_.Name
		if not (L_1566_) then
			L_1566_ = "Dropdown"
		end
	end
	L_1567_ = L_1565_.Description
	if not (L_1567_) then
		L_1567_ = L_1565_.Desc
		if not (L_1567_) then
			L_1567_ = ""
		end
	end
	L_1568_ = L_1565_.Callback
	L_1569_ = L_1565_.Values
	if not (L_1569_) then
		L_1569_ = L_1565_.List
		if not (L_1569_) then
			L_1569_ = {}
		end
	end
	L_1570_ = L_1565_.Default
	L_1571_ = L_1565_.Default
	if not (L_1570_) then
		L_1570_ = nil
	end
	L_1571_ = upvalue_0(L_1566_, L_1567_)
	L_1572_ = L_1568_
	L_1573_ = nil
	if L_1571_ then
		L_1573_ = upvalue_1:NewPremiumDropdown(L_1566_, L_1567_, L_1569_, L_1_.callback_206)
		L_1574_ = upvalue_1:NewPremiumDropdown(L_1566_, L_1567_, L_1569_, L_1_.callback_206)
		L_1575_ = upvalue_1
		L_1576_ = L_1566_
		L_1577_ = L_1567_
		L_1578_ = L_1569_
		L_1579_ = L_1_.callback_206
	else
		L_1573_ = upvalue_2:NewDropdown(L_1566_, L_1567_, L_1569_, L_1_.callback_208)
		L_1574_ = upvalue_2:NewDropdown(L_1566_, L_1567_, L_1569_, L_1_.callback_208)
		L_1575_ = upvalue_2
		L_1576_ = L_1566_
		L_1577_ = L_1567_
		L_1578_ = L_1569_
		L_1579_ = L_1_.callback_208
	end
	if not (L_1570_) then
		L_1574_ = {}
		L_1574_.OnChanged = L_1_.OnChanged_210
		L_1574_.SetValue = L_1_.SetValue_212

		return L_1574_
	end
	if not (L_1573_) then
		L_1574_ = {}
		L_1574_.OnChanged = L_1_.OnChanged_210
		L_1574_.SetValue = L_1_.SetValue_212

		return L_1574_
	end
	L_1574_ = L_1573_.Set
	if not (L_1574_) then
		L_1574_ = {}
		L_1574_.OnChanged = L_1_.OnChanged_210
		L_1574_.SetValue = L_1_.SetValue_212

		return L_1574_
	end
	pcall(L_1_.OnChanged_209)
	L_1574_ = pcall
	L_1575_ = L_1_.OnChanged_209
	L_1574_ = {}
	L_1574_.OnChanged = L_1_.OnChanged_210
	L_1574_.SetValue = L_1_.SetValue_212

	return L_1574_
end

L_1_.AddLabel = function(L_1580_arg0, L_1581_arg1)
	local L_1582_, L_1583_, L_1584_
	upvalue_0:NewLabel(L_1581_arg1)
	return
end

L_1_.AddParagraph = function(L_1585_arg0, L_1586_arg1)
	local L_1587_, L_1588_, L_1589_, L_1590_, L_1591_, L_1592_, L_1593_
	L_1587_ = upvalue_0
	L_1590_ = L_1586_arg1.Title
	L_1593_ = L_1586_arg1.Title
	if not (L_1590_) then
		L_1590_ = ""
	end
	L_1591_ = ": "
	L_1592_ = L_1586_arg1.Content
	L_1593_ = L_1586_arg1.Content
	if L_1592_ then
		L_1587_:NewLabel(L_1590_ .. L_1591_ .. L_1592_)
		return
	end
	L_1592_ = ""
	L_1587_:NewLabel(L_1590_ .. L_1591_ .. L_1592_)
	return
end

L_1_.OnChanged_216 = function(L_1594_arg0, L_1595_arg1)
	return L_1594_arg0
end

L_1_.SetValue_217 = function(L_1596_arg0, L_1597_arg1)
	return
end

L_1_.AddKeybind = function(L_1598_arg0, L_1599_arg1, L_1600_arg2)
	local L_1601_, L_1602_
	L_1601_ = {}
	L_1601_.OnChanged = L_1_.OnChanged_216
	L_1601_.SetValue = L_1_.SetValue_217
	return L_1601_
end

L_1_.OnChanged_219 = function(L_1603_arg0, L_1604_arg1)
	return L_1603_arg0
end

L_1_.SetValue_220 = function(L_1605_arg0, L_1606_arg1)
	return
end

L_1_.AddColorpicker = function(L_1607_arg0, L_1608_arg1, L_1609_arg2)
	local L_1610_, L_1611_
	L_1610_ = {}
	L_1610_.OnChanged = L_1_.OnChanged_219
	L_1610_.SetValue = L_1_.SetValue_220
	return L_1610_
end

L_1_.AddTab = function(L_1612_arg0, L_1613_arg1)
	local L_1614_, L_1615_
	L_1614_ = {}
	L_1614_.AddSection = L_1_.AddSection
	L_1614_.AddButton = L_1_.AddButton
	L_1614_.AddToggle = L_1_.AddToggle
	L_1614_.AddSlider = L_1_.AddSlider
	L_1614_.AddDropdown = L_1_.AddDropdown
	L_1614_.AddLabel = L_1_.AddLabel
	L_1614_.AddParagraph = L_1_.AddParagraph
	L_1614_.AddKeybind = L_1_.AddKeybind
	L_1614_.AddColorpicker = L_1_.AddColorpicker
	return L_1614_
end

L_1_.SelectTab = function(L_1616_arg0, L_1617_arg1)
	return
end

L_1_.CreateWindow_224 = function(L_1618_arg0, L_1619_arg1)
	local L_1620_, L_1621_
	L_1620_ = {}
	L_1620_.AddTab = L_1_.AddTab
	L_1620_.SelectTab = L_1_.SelectTab
	return L_1620_
end

L_1_.callback_225 = function()
	local L_1622_, L_1623_, L_1624_, L_1625_, L_1626_, L_1627_, L_1628_
	L_1622_ = upvalue_0
	L_1624_ = upvalue_1.Title
	L_1625_ = upvalue_1.Title
	L_1626_ = upvalue_1
	if not (L_1624_) then
		L_1624_ = "Notification"
	end
	L_1625_ = upvalue_1.Content
	L_1626_ = upvalue_1
	if not (L_1625_) then
		L_1625_ = upvalue_1.Text
		L_1626_ = upvalue_1
		if not (L_1625_) then
			L_1625_ = ""
		end
	end
	L_1626_ = upvalue_1.Duration
	L_1627_ = upvalue_1.Duration
	L_1628_ = upvalue_1
	if L_1626_ then
		L_1622_:Notify(L_1624_, L_1625_, L_1626_)
		return
	end
	L_1626_ = 3
	L_1622_:Notify(L_1624_, L_1625_, L_1626_)
	return
end

L_1_.Notify_226 = function(L_1629_arg0, L_1630_arg1)
	local L_1631_, L_1632_
	pcall(L_1_.callback_225)
	return
end

L_1_.callback_227 = function(L_1633_arg0)
	local L_1634_, L_1635_, L_1636_, L_1637_, L_1638_, L_1639_
	L_1634_ = upvalue_0(L_1633_arg0, L_1633_arg0)
	L_1635_ = {}
	L_1635_.CreateWindow = L_1_.CreateWindow_224
	L_1635_.Notify = L_1_.Notify_226
	return L_1635_
end

L_1_.PlayerModifierLoop = function()
	local L_1640_, L_1641_
	L_1640_ = getgenv().PlayerModifierLoop
	L_1640_:Disconnect()
	return
end

L_1_.callback_229 = function()
	local L_1642_, L_1643_, L_1644_, L_1645_
	upvalue_0:SetStateEnabled(Enum.HumanoidStateType.Dead, false)
	return
end

L_1_.callback_230 = function()
	local L_1646_, L_1647_, L_1648_, L_1649_, L_1650_, L_1651_
	L_1646_ = game.Players.LocalPlayer.Character
	L_1647_ = game.Players.LocalPlayer
	if not (L_1646_) then
		return
	end
	L_1647_ = L_1646_:FindFirstChild("Humanoid")
	L_1648_ = L_1646_
	L_1649_ = "Humanoid"
	if not (L_1647_) then
		return
	end
	L_1647_ = L_1646_:FindFirstChild("HumanoidRootPart")
	L_1648_ = L_1646_
	L_1649_ = "HumanoidRootPart"
	if not (L_1647_) then
		return
	end
	L_1647_ = L_1646_.Humanoid
	L_1648_ = getgenv().GodModeEnabled
	L_1649_ = getgenv()
	if not (L_1648_) then
		return
	end
	L_1648_ = L_1647_.MaxHealth
	L_1650_ = inf
	L_1651_ = (L_1647_.MaxHealth == inf)
	if not (L_1651_) then
		L_1647_.MaxHealth = inf
		L_1648_ = inf
	end
	L_1648_ = L_1647_.Health
	L_1650_ = inf
	L_1651_ = (L_1647_.Health == inf)
	if not (L_1651_) then
		L_1647_.Health = inf
		L_1648_ = inf
	end
	pcall(L_1_.callback_229)
	L_1648_ = pcall
	L_1649_ = L_1_.callback_229
	return
end

L_1_.callback_231 = function(L_1652_arg0)
	local L_1653_, L_1654_
	pcall(L_1_.callback_230)
	return
end

L_1_.callback_232 = function(L_1655_arg0)
	local L_1656_, L_1657_, L_1658_
	L_1656_ = getgenv()
	L_1656_.WalkSpeedValue = L_1655_arg0
	L_1656_ = game.Players.LocalPlayer.Character
	L_1657_ = game.Players.LocalPlayer
	if not (L_1656_) then
		return
	end
	L_1656_ = game.Players.LocalPlayer.Character:FindFirstChild("Humanoid")
	L_1657_ = game.Players.LocalPlayer.Character
	L_1658_ = "Humanoid"
	if not (L_1656_) then
		return
	end
	L_1656_ = game.Players.LocalPlayer.Character.Humanoid
	L_1656_.WalkSpeed = L_1655_arg0
	L_1657_ = game.Players.LocalPlayer.Character
	L_1658_ = game.Players.LocalPlayer
	return
end

L_1_.callback_233 = function(L_1659_arg0)
	local L_1660_, L_1661_, L_1662_
	L_1660_ = getgenv()
	L_1660_.JumpPowerValue = L_1659_arg0
	L_1660_ = game.Players.LocalPlayer.Character
	L_1661_ = game.Players.LocalPlayer
	if not (L_1660_) then
		return
	end
	L_1660_ = game.Players.LocalPlayer.Character:FindFirstChild("Humanoid")
	L_1661_ = game.Players.LocalPlayer.Character
	L_1662_ = "Humanoid"
	if not (L_1660_) then
		return
	end
	L_1660_ = game.Players.LocalPlayer.Character.Humanoid
	L_1660_.JumpPower = L_1659_arg0
	L_1661_ = game.Players.LocalPlayer.Character
	L_1662_ = game.Players.LocalPlayer
	return
end

L_1_.callback_234 = function(L_1663_arg0)
	local L_1664_
	L_1664_ = game.Workspace
	L_1664_.Gravity = L_1663_arg0
	return
end

L_1_.callback_235 = function()
	local L_1665_, L_1666_, L_1667_, L_1668_, L_1669_
	L_1665_ = game.Players.LocalPlayer.Character
	L_1666_ = game.Players.LocalPlayer
	if not (L_1665_) then
		return
	end
	L_1666_ = L_1665_:FindFirstChild("Humanoid")
	L_1667_ = L_1665_
	L_1668_ = "Humanoid"
	if not (L_1666_) then
		return
	end
	L_1666_ = L_1665_.Humanoid
	L_1666_.MaxHealth = 100
	L_1666_ = L_1665_.Humanoid
	L_1666_.Health = 100
	L_1665_.Humanoid:SetStateEnabled(Enum.HumanoidStateType.Dead, true)
	L_1666_ = L_1665_.Humanoid.SetStateEnabled
	L_1667_ = L_1665_.Humanoid
	L_1668_ = Enum.HumanoidStateType.Dead
	L_1669_ = true
	return
end

L_1_.callback_236 = function(L_1670_arg0)
	local L_1671_, L_1672_
	L_1671_ = getgenv()
	L_1671_.GodModeEnabled = L_1670_arg0
	if L_1670_arg0 then
		return
	end
	pcall(L_1_.callback_235)
	L_1671_ = pcall
	L_1672_ = L_1_.callback_235
	return
end

L_1_.callback_237 = function()
	local L_1673_, L_1674_, L_1675_, L_1676_, L_1677_, L_1678_, L_1679_, L_1680_, L_1681_, L_1682_
	L_1673_ = upvalue_0
	L_1681_ = false
	L_1682_ = (upvalue_0 == false)
	if not (L_1682_) then
		wait(0.21)
		return
	end
	L_1673_ = game.Players.LocalPlayer.Character
	L_1674_ = game.Players.LocalPlayer
	L_1681_ = nil
	L_1682_ = (game.Players.LocalPlayer.Character == nil)
	if L_1682_ then
		wait(0.21)
		return
	end
	L_1673_ = pairs
	L_1674_ = select(1, game.Players.LocalPlayer.Character:GetDescendants())
	L_1675_ = game.Players.LocalPlayer.Character
	L_1673_, L_1674_, L_1675_ = pairs(game.Players.LocalPlayer.Character:GetDescendants())
	for L_1683_forvar0, L_1684_forvar1 in L_1673_, L_1674_, L_1675_ do
		L_1678_ = L_1684_forvar1:IsA("BasePart")
		L_1679_ = L_1684_forvar1
		L_1680_ = "BasePart"
		if L_1678_ then
			L_1678_ = L_1684_forvar1.CanCollide
			if L_1678_ then
				L_1678_ = L_1684_forvar1.Name
				L_1679_ = floatName
				L_1682_ = (L_1684_forvar1.Name == floatName)
				if not (L_1682_) then
					L_1684_forvar1.CanCollide = false
					L_1678_ = false
				end
			end
		end
	end
	wait(0.21)
	return
end

L_1_.enableNoclip = function()
	local L_1685_, L_1686_, L_1687_, L_1688_, L_1689_
	upvalue_0 = false
	L_1686_ = game:GetService("RunService").Stepped
	upvalue_1 = L_1686_:Connect(L_1_.callback_237)
	return
end

L_1_.disableNoclip = function()
	local L_1690_, L_1691_
	L_1690_ = upvalue_0
	if not (L_1690_) then
		upvalue_1 = true
		return
	end
	upvalue_0:Disconnect()
	L_1690_ = upvalue_0.Disconnect
	L_1691_ = upvalue_0
	upvalue_1 = true
	return
end

L_1_.callback_240 = function(L_1692_arg0)
	local L_1693_
	if L_1692_arg0 then
		noclip()
		return
	else
		clip()
		return
	end
end

L_1_.callback_241 = function()
	local L_1694_, L_1695_, L_1696_
	L_1694_ = upvalue_0
	if not (L_1694_) then
		return
	end
	L_1694_ = game.Players.LocalPlayer.Character
	L_1695_ = game.Players.LocalPlayer
	if not (L_1694_) then
		return
	end
	L_1694_ = game.Players.LocalPlayer.Character:FindFirstChild("Humanoid")
	L_1695_ = game.Players.LocalPlayer.Character
	L_1696_ = "Humanoid"
	if not (L_1694_) then
		return
	end
	game.Players.LocalPlayer.Character.Humanoid:ChangeState("Jumping")
	L_1694_ = game.Players.LocalPlayer.Character.Humanoid.ChangeState
	L_1695_ = game.Players.LocalPlayer.Character.Humanoid
	L_1696_ = "Jumping"
	return
end

L_1_.callback_242 = function(L_1697_arg0)
	local L_1698_, L_1699_, L_1700_, L_1701_
	upvalue_0 = L_1697_arg0
	L_1698_ = game:GetService("UserInputService").JumpRequest
	L_1698_:Connect(L_1_.callback_241)
	return
end

L_1_.callback_243 = function(L_1702_arg0)
	local L_1703_
	L_1703_ = game.Workspace.CurrentCamera
	L_1703_.FieldOfView = L_1702_arg0
	return
end

L_1_.callback_244 = function(L_1704_arg0)
	local L_1705_, L_1706_, L_1707_, L_1708_, L_1709_
	if L_1704_arg0 then
		L_1705_ = game.Lighting
		L_1705_.Ambient = Color3.new(1, 1, 1)
		L_1705_ = game.Lighting
		L_1705_.ColorShift_Bottom = Color3.new(1, 1, 1)
		L_1705_ = game.Lighting
		L_1705_.ColorShift_Top = Color3.new(1, 1, 1)
		L_1705_ = game.Lighting
		L_1705_.GlobalShadows = false
		return
	else
		L_1705_ = game.Lighting
		L_1705_.Ambient = Color3.fromRGB(128, 128, 128)
		L_1705_ = game.Lighting
		L_1705_.GlobalShadows = true
		return
	end
end

L_1_.callback_245 = function(L_1710_arg0)
	local L_1711_, L_1712_, L_1713_, L_1714_, L_1715_, L_1716_, L_1717_, L_1718_, L_1719_, L_1720_, L_1721_
	if L_1710_arg0 then
		L_1711_ = pairs
		L_1712_ = select(1, game.Players:GetPlayers())
		L_1713_ = game.Players
		L_1711_, L_1712_, L_1713_ = pairs(game.Players:GetPlayers())
		for L_1722_forvar0, L_1723_forvar1 in L_1711_, L_1712_, L_1713_ do
			L_1716_ = game.Players.LocalPlayer
			L_1721_ = (L_1723_forvar1 == game.Players.LocalPlayer)
			if not (L_1721_) then
				L_1716_ = L_1723_forvar1.Character
				if L_1716_ then
					L_1716_ = Instance.new("Highlight")
					L_1716_.Parent = L_1723_forvar1.Character
					L_1716_.FillColor = upvalue_0.AccentColor
					L_1716_.OutlineColor = upvalue_0.SecondaryColor
					L_1716_.FillTransparency = 0.5
					table.insert(upvalue_1, L_1716_)
					L_1717_ = table.insert
					L_1718_ = upvalue_1
					L_1719_ = L_1716_
				end
			end
		end
		return
	else
		L_1711_ = pairs
		L_1712_ = upvalue_1
		L_1711_, L_1712_, L_1713_ = pairs(upvalue_1)
		for L_1724_forvar0, L_1725_forvar1 in L_1711_, L_1712_, L_1713_ do
			if L_1725_forvar1 then
				L_1716_ = L_1725_forvar1.Parent
				if L_1716_ then
					L_1725_forvar1:Destroy()
					L_1716_ = L_1725_forvar1.Destroy
					L_1717_ = L_1725_forvar1
				end
			end
		end
		upvalue_1 = {}
		return
	end
end

L_1_.callback_246 = function()
	local L_1726_, L_1727_, L_1728_, L_1729_, L_1730_, L_1731_
	L_1726_ = upvalue_0.Character.HumanoidRootPart
	L_1726_.Size = Vector3.new(_G.HeadSize, _G.HeadSize, _G.HeadSize)
	L_1726_ = upvalue_0.Character.HumanoidRootPart
	L_1726_.Transparency = 0.7
	L_1726_ = upvalue_0.Character.HumanoidRootPart
	L_1726_.BrickColor = BrickColor.new("Really blue")
	L_1726_ = upvalue_0.Character.HumanoidRootPart
	L_1726_.Material = "Neon"
	L_1726_ = upvalue_0.Character.HumanoidRootPart
	L_1726_.CanCollide = false
	return
end

L_1_.callback_247 = function()
	local L_1732_, L_1733_, L_1734_, L_1735_, L_1736_, L_1737_, L_1738_, L_1739_, L_1740_, L_1741_, L_1742_, L_1743_, L_1744_
	L_1732_ = _G.Disabled
	L_1733_ = _G
	if not (L_1732_) then
		return
	end
	L_1733_ = game:GetService("Players")
	L_1732_ = next
	L_1733_ = L_1733_.GetPlayers
	L_1734_ = L_1733_
	L_1735_ = "Players"
	L_1733_, L_1734_ = L_1733_:GetPlayers()
	for L_1745_forvar0, L_1746_forvar1 in L_1732_, L_1733_, L_1734_ do
		L_1737_ = L_1746_forvar1.Name
		L_1738_ = game:GetService("Players").LocalPlayer.Name
		L_1739_ = game:GetService("Players").LocalPlayer
		L_1740_ = game:GetService("Players")
		L_1741_ = game
		L_1742_ = "Players"
		L_1744_ = (L_1746_forvar1.Name == game:GetService("Players").LocalPlayer.Name)
		if not (L_1744_) then
			pcall(L_1_.callback_246)
			L_1737_ = pcall
			L_1738_ = L_1_.callback_246
		end
	end
	return
end

L_1_.callback_248 = function(L_1747_arg0)
	local L_1748_, L_1749_, L_1750_, L_1751_
	L_1748_ = _G
	L_1748_.HeadSize = L_1747_arg0
	L_1748_ = _G
	L_1748_.Disabled = true
	L_1748_ = game:GetService("RunService").RenderStepped
	L_1748_:connect(L_1_.callback_247)
	return
end

L_1_.callback_249 = function()
	local L_1752_, L_1753_, L_1754_, L_1755_, L_1756_, L_1757_
	L_1752_ = Instance.new("HopperBin", game.Players.LocalPlayer.Backpack)
	L_1752_.BinType = "Clone"
	L_1753_ = Instance.new("HopperBin", game.Players.LocalPlayer.Backpack)
	L_1753_.BinType = "Hammer"
	L_1754_ = Instance.new("HopperBin", game.Players.LocalPlayer.Backpack)
	L_1754_.BinType = "Grab"
	return
end

L_1_.callback_250 = function()
	local L_1758_, L_1759_, L_1760_, L_1761_, L_1762_, L_1763_, L_1764_, L_1765_, L_1766_, L_1767_, L_1768_
	L_1758_ = game.Players:GetPlayers()
	L_1759_ = #game.Players:GetPlayers()
	L_1760_ = 1
	L_1768_ = (1 < #game.Players:GetPlayers())
	if not (L_1768_) then
		return
	end
	L_1759_ = L_1758_[math.random(1, #L_1758_)]
	L_1760_ = math.random(1, #L_1758_)
	L_1761_ = 1
	L_1762_ = #L_1758_
	repeat
		L_1759_ = L_1758_[math.random(1, #L_1758_)]
		L_1760_ = L_1758_[math.random(1, #L_1758_)].Name
		L_1761_ = game.Players.LocalPlayer.Name
		L_1762_ = game.Players.LocalPlayer
		L_1768_ = (L_1758_[math.random(1, #L_1758_)].Name == game.Players.LocalPlayer.Name)
	until not (L_1768_)
	L_1760_ = L_1759_.Character
	if not (L_1760_) then
		return
	end
	L_1760_ = L_1759_.Character:FindFirstChild("HumanoidRootPart")
	L_1761_ = L_1759_.Character
	L_1762_ = "HumanoidRootPart"
	if not (L_1760_) then
		return
	end
	L_1760_ = game.Players.LocalPlayer.Character
	L_1761_ = game.Players.LocalPlayer
	if not (L_1760_) then
		return
	end
	L_1760_ = game.Players.LocalPlayer.Character:FindFirstChild("HumanoidRootPart")
	L_1761_ = game.Players.LocalPlayer.Character
	L_1762_ = "HumanoidRootPart"
	if not (L_1760_) then
		return
	end
	L_1760_ = game.Players.LocalPlayer.Character.HumanoidRootPart
	L_1760_.CFrame = (L_1759_.Character.HumanoidRootPart.CFrame * CFrame.new(0, 0, 3))
	L_1761_ = (L_1759_.Character.HumanoidRootPart.CFrame * CFrame.new(0, 0, 3))
	L_1762_ = L_1759_.Character.HumanoidRootPart.CFrame
	L_1763_ = CFrame.new(0, 0, 3)
	L_1764_ = 0
	L_1765_ = 0
	L_1766_ = 3
	return
end

L_1_.callback_251 = function()
	local L_1769_, L_1770_, L_1771_, L_1772_, L_1773_
	L_1769_ = game:GetService("TeleportService")
	L_1769_:TeleportToPlaceInstance(game.PlaceId, game.JobId, game.Players.LocalPlayer)
	return
end

L_1_.callback_252 = function(L_1774_arg0)
	local L_1775_, L_1776_, L_1777_, L_1778_, L_1779_, L_1780_, L_1781_
	L_1775_ = game
	L_1778_ = upvalue_0
	if L_1774_arg0 then
		L_1779_ = "&cursor=" .. L_1774_arg0
		L_1780_ = "&cursor="
		L_1781_ = L_1774_arg0
		if L_1779_ then
			return upvalue_1:JSONDecode(L_1775_:HttpGet(L_1778_ .. L_1779_))
		end
		L_1779_ = ""
	else
		L_1779_ = ""
	end
	return upvalue_1:JSONDecode(L_1775_:HttpGet(L_1778_ .. L_1779_))
end

L_1_.callback_253 = function()
	local L_1782_, L_1783_, L_1784_, L_1785_, L_1786_, L_1787_, L_1788_, L_1789_, L_1790_, L_1791_, L_1792_, L_1793_, L_1794_, L_1795_, L_1796_, L_1797_
	L_1782_ = game:GetService("HttpService")
	L_1783_ = game:GetService("TeleportService")
	L_1784_ = game.PlaceId
	L_1785_ = "https://games.roblox.com/v1/games/" .. tostring(game.PlaceId) .. "/servers/Public?sortOrder=Asc&limit=100"
	L_1786_ = L_1_.callback_252
	L_1787_ = nil
	L_1788_ = nil
	L_1789_ = tostring(game.PlaceId)
	L_1790_ = game.PlaceId
	repeat
		L_1790_ = L_1788_
		L_1791_ = game
		L_1794_ = L_1785_
		if L_1790_ then
			L_1795_ = "&cursor=" .. L_1790_
			L_1796_ = "&cursor="
			L_1797_ = L_1790_
			if not (L_1795_) then
				L_1795_ = ""
			end
		else
			L_1795_ = ""
		end
		L_1787_ = L_1782_:JSONDecode(L_1791_:HttpGet(L_1794_ .. L_1795_)).data[1]
		L_1788_ = L_1782_:JSONDecode(L_1791_:HttpGet(L_1794_ .. L_1795_)).nextPageCursor
		L_1789_ = L_1782_:JSONDecode(L_1791_:HttpGet(L_1794_ .. L_1795_))
		L_1790_ = L_1782_:JSONDecode(L_1791_:HttpGet(L_1794_ .. L_1795_)).data
		L_1791_ = L_1791_:HttpGet(L_1794_ .. L_1795_)
		L_1792_ = L_1782_:JSONDecode(L_1791_:HttpGet(L_1794_ .. L_1795_))
		L_1793_ = L_1782_
		L_1794_ = L_1791_:HttpGet(L_1794_ .. L_1795_)
	until L_1787_
	L_1783_:TeleportToPlaceInstance(L_1784_, L_1787_.id, game.Players.LocalPlayer)
	return
end

L_1_.callback_254 = function(L_1798_arg0)
	local L_1799_, L_1800_, L_1801_, L_1802_, L_1803_, L_1804_, L_1805_, L_1806_
	L_1799_ = getconnections
	if not (L_1799_) then
		L_1799_ = get_signal_cons
	end
	if not (L_1798_arg0) then
		return
	end
	if not (L_1799_) then
		return
	end
	L_1800_ = pairs
	L_1801_ = select(1, L_1799_(game.Players.LocalPlayer.Idled))
	L_1802_ = game.Players.LocalPlayer.Idled
	L_1803_ = game.Players.LocalPlayer
	L_1800_, L_1801_, L_1802_ = pairs(L_1799_(game.Players.LocalPlayer.Idled))
	for L_1807_forvar0, L_1808_forvar1 in L_1800_, L_1801_, L_1802_ do
		L_1805_ = L_1808_forvar1.Disable
		if L_1805_ then
			L_1808_forvar1.Disable(L_1808_forvar1)
			L_1805_ = L_1808_forvar1.Disable
			L_1806_ = L_1808_forvar1
		else
			L_1805_ = L_1808_forvar1.Disconnect
			if L_1805_ then
				L_1808_forvar1.Disconnect(L_1808_forvar1)
				L_1805_ = L_1808_forvar1.Disconnect
				L_1806_ = L_1808_forvar1
			end
		end
	end
	return
end

L_1_.callback_255 = function()
	local L_1809_, L_1810_, L_1811_, L_1812_, L_1813_, L_1814_, L_1815_, L_1816_, L_1817_, L_1818_, L_1819_, L_1820_, L_1821_, L_1822_, L_1823_, L_1824_
	local L_1825_
	L_1811_ = game:GetService("UserInputService")
	L_1809_ = upvalue_0.FOVRadius
	L_1810_ = nil
	L_1811_ = L_1811_:GetMouseLocation()
	L_1812_ = pairs
	L_1813_ = select(1, game.Players:GetPlayers())
	L_1814_ = game.Players
	L_1812_, L_1813_, L_1814_ = pairs(game.Players:GetPlayers())
	for L_1826_forvar0, L_1827_forvar1 in L_1812_, L_1813_, L_1814_ do
		L_1817_ = game.Players.LocalPlayer
		L_1825_ = (L_1827_forvar1 == game.Players.LocalPlayer)
		if not (L_1825_) then
			L_1817_ = L_1827_forvar1.Character
			if L_1817_ then
				L_1817_ = L_1827_forvar1.Character:FindFirstChild(upvalue_0.TargetPart)
				L_1818_ = L_1827_forvar1.Character
				L_1819_ = upvalue_0.TargetPart
				L_1820_ = upvalue_0
				if L_1817_ then
					L_1817_ = L_1827_forvar1.Character:FindFirstChild("Humanoid")
					L_1818_ = L_1827_forvar1.Character
					L_1819_ = "Humanoid"
					if L_1817_ then
						L_1817_ = L_1827_forvar1.Character.Humanoid.Health
						L_1818_ = 0
						L_1819_ = L_1827_forvar1.Character
						L_1825_ = (0 < L_1827_forvar1.Character.Humanoid.Health)
						if L_1825_ then
							L_1817_ = upvalue_0.TeamCheck
							L_1818_ = upvalue_0
							if L_1817_ then
								L_1817_ = L_1827_forvar1.Team
								L_1818_ = game.Players.LocalPlayer.Team
								L_1819_ = game.Players.LocalPlayer
								L_1825_ = (L_1827_forvar1.Team == game.Players.LocalPlayer.Team)
								if not (L_1825_) then
								end
							end
							L_1817_ = game.Workspace.CurrentCamera.WorldToViewportPoint
							L_1818_ = game.Workspace.CurrentCamera
							L_1819_ = L_1827_forvar1.Character[upvalue_0.TargetPart].Position
							L_1820_ = L_1827_forvar1.Character[upvalue_0.TargetPart]
							L_1821_ = L_1827_forvar1.Character
							L_1822_ = upvalue_0.TargetPart
							L_1823_ = upvalue_0
							L_1817_, L_1818_ = game.Workspace.CurrentCamera:WorldToViewportPoint(L_1827_forvar1.Character[upvalue_0.TargetPart].Position)
							if L_1818_ then
								L_1819_ = (Vector2.new(L_1817_.X, L_1817_.Y) - L_1811_).Magnitude
								L_1820_ = (Vector2.new(L_1817_.X, L_1817_.Y) - L_1811_)
								L_1821_ = Vector2.new(L_1817_.X, L_1817_.Y)
								L_1822_ = L_1817_.X
								L_1823_ = L_1817_.Y
								L_1825_ = ((Vector2.new(L_1817_.X, L_1817_.Y) - L_1811_).Magnitude < L_1809_)
								if L_1825_ then
									L_1809_ = L_1819_
									L_1810_ = L_1827_forvar1
								end
							end
						end
					end
				end
			end
		end
	end
	return L_1810_
end

L_1_.callback_256 = function()
	local L_1828_, L_1829_, L_1830_, L_1831_, L_1832_, L_1833_, L_1834_, L_1835_, L_1836_
	L_1828_ = upvalue_0.ShowFOV
	L_1829_ = upvalue_0
	if L_1828_ then
		L_1829_ = game:GetService("UserInputService")
		L_1828_ = upvalue_1
		L_1828_.Position = L_1829_:GetMouseLocation()
		L_1828_ = upvalue_1
		L_1828_.Radius = upvalue_0.FOVRadius
		L_1828_ = upvalue_1
		L_1828_.Visible = true
		L_1829_ = true
		L_1830_ = upvalue_0
		L_1831_ = "UserInputService"
	else
		L_1828_ = upvalue_1
		L_1828_.Visible = false
		L_1829_ = false
	end
	L_1828_ = upvalue_0.Enabled
	L_1829_ = upvalue_0
	if not (L_1828_) then
		return
	end
	L_1828_ = game:GetService("UserInputService")
	L_1828_ = L_1828_:IsMouseButtonPressed(Enum.UserInputType.MouseButton2)
	L_1829_ = L_1828_
	L_1830_ = Enum.UserInputType.MouseButton2
	if not (L_1828_) then
		return
	end
	L_1828_ = upvalue_2()
	if not (L_1828_) then
		return
	end
	L_1829_ = L_1828_.Character
	if not (L_1829_) then
		return
	end
	L_1829_ = L_1828_.Character:FindFirstChild(upvalue_0.TargetPart)
	L_1830_ = L_1828_.Character
	L_1831_ = upvalue_0.TargetPart
	L_1832_ = upvalue_0
	if not (L_1829_) then
		return
	end
	L_1829_ = game.Workspace.CurrentCamera
	L_1829_.CFrame = game.Workspace.CurrentCamera.CFrame:Lerp(CFrame.new(game.Workspace.CurrentCamera.CFrame.Position, L_1828_.Character[upvalue_0.TargetPart].Position), upvalue_0.Smoothness)
	L_1830_ = CFrame.new(game.Workspace.CurrentCamera.CFrame.Position, L_1828_.Character[upvalue_0.TargetPart].Position)
	L_1831_ = game.Workspace.CurrentCamera.CFrame:Lerp(CFrame.new(game.Workspace.CurrentCamera.CFrame.Position, L_1828_.Character[upvalue_0.TargetPart].Position), upvalue_0.Smoothness)
	L_1832_ = game.Workspace.CurrentCamera.CFrame
	L_1833_ = CFrame.new(game.Workspace.CurrentCamera.CFrame.Position, L_1828_.Character[upvalue_0.TargetPart].Position)
	L_1834_ = upvalue_0.Smoothness
	L_1835_ = upvalue_0
	L_1836_ = upvalue_0
	return
end

L_1_.callback_257 = function(L_1837_arg0)
	local L_1838_
	L_1838_ = upvalue_0
	L_1838_.Enabled = L_1837_arg0
	return
end

L_1_.callback_258 = function(L_1839_arg0)
	local L_1840_
	L_1840_ = upvalue_0
	L_1840_.ShowFOV = L_1839_arg0
	return
end

L_1_.callback_259 = function(L_1841_arg0)
	local L_1842_
	L_1842_ = upvalue_0
	L_1842_.FOVRadius = L_1841_arg0
	return
end

L_1_.callback_260 = function(L_1843_arg0)
	local L_1844_, L_1845_
	L_1844_ = upvalue_0
	L_1844_.Smoothness = (L_1843_arg0 / 100)
	return
end

L_1_.callback_261 = function(L_1846_arg0)
	local L_1847_
	L_1847_ = upvalue_0
	L_1847_.TeamCheck = L_1846_arg0
	return
end

L_1_.callback_262 = function()
	local L_1848_, L_1849_, L_1850_, L_1851_, L_1852_, L_1853_
	upvalue_0:Notify("Test", "Notifications are working!", 4, false)
	return
end

L_1_.callback_263 = function()
	local L_1854_, L_1855_, L_1856_, L_1857_, L_1858_, L_1859_
	upvalue_0:Notify("Premium Alert", "This is how premium alerts look!", 4, true)
	return
end

L_1_.callback_264 = function()
	local L_1860_, L_1861_, L_1862_, L_1863_, L_1864_, L_1865_, L_1866_, L_1867_, L_1868_, L_1869_, L_1870_
	L_1860_ = pairs
	L_1861_ = select(1, getgenv())
	L_1860_, L_1861_, L_1862_ = pairs(getgenv())
	for L_1871_forvar0, L_1872_forvar1 in L_1860_, L_1861_, L_1862_ do
		L_1865_ = type(L_1871_forvar0)
		L_1866_ = L_1871_forvar0
		L_1869_ = "string"
		L_1870_ = (type(L_1871_forvar0) == "string")
		if L_1870_ then
			L_1865_ = L_1871_forvar0:sub(1, 3)
			L_1866_ = L_1871_forvar0
			L_1867_ = 1
			L_1868_ = 3
			L_1869_ = "_h_"
			L_1870_ = (L_1871_forvar0:sub(1, 3) == "_h_")
			if L_1870_ then
				L_1865_ = typeof(L_1872_forvar1)
				L_1866_ = L_1872_forvar1
				L_1869_ = "Instance"
				L_1870_ = (typeof(L_1872_forvar1) == "Instance")
				if L_1870_ then
					L_1865_ = L_1872_forvar1:IsA("ScreenGui")
					L_1866_ = L_1872_forvar1
					L_1867_ = "ScreenGui"
					if L_1865_ then
						L_1865_ = L_1872_forvar1:FindFirstChild("Main")
						L_1866_ = L_1872_forvar1
						L_1867_ = "Main"
						if L_1865_ then
							L_1865_.BackgroundTransparency = upvalue_0
							L_1866_ = upvalue_0
						end
					end
				end
			end
		end
	end
	return
end

L_1_.callback_265 = function(L_1873_arg0)
	local L_1874_, L_1875_
	upvalue_0 = (L_1873_arg0 / 10)
	pcall(L_1_.callback_264)
	return
end

L_1_.callback_266 = function()
	local L_1876_, L_1877_, L_1878_, L_1879_, L_1880_, L_1881_
	L_1876_ = setclipboard
	if not (L_1876_) then
		upvalue_0:Notify("Copied!", "Discord link copied.", 3, false)
		return
	end
	setclipboard("https://discord.gg/getsnowy")
	L_1876_ = setclipboard
	L_1877_ = "https://discord.gg/getsnowy"
	upvalue_0:Notify("Copied!", "Discord link copied.", 3, false)
	return
end

L_1_.callback_267 = function()
	local L_1882_, L_1883_
	upvalue_0:Destroy()
	return
end

L_1_.callback_268 = function()
	local L_1884_, L_1885_, L_1886_, L_1887_, L_1888_, L_1889_, L_1890_, L_1891_, L_1892_, L_1893_, L_1894_
	L_1884_ = pairs
	L_1885_ = select(1, getgenv())
	L_1884_, L_1885_, L_1886_ = pairs(getgenv())
	for L_1895_forvar0, L_1896_forvar1 in L_1884_, L_1885_, L_1886_ do
		L_1889_ = type(L_1895_forvar0)
		L_1890_ = L_1895_forvar0
		L_1893_ = "string"
		L_1894_ = (type(L_1895_forvar0) == "string")
		if L_1894_ then
			L_1889_ = L_1895_forvar0:sub(1, 3)
			L_1890_ = L_1895_forvar0
			L_1891_ = 1
			L_1892_ = 3
			L_1893_ = "_h_"
			L_1894_ = (L_1895_forvar0:sub(1, 3) == "_h_")
			if L_1894_ then
				L_1889_ = typeof(L_1896_forvar1)
				L_1890_ = L_1896_forvar1
				L_1893_ = "Instance"
				L_1894_ = (typeof(L_1896_forvar1) == "Instance")
				if L_1894_ then
					L_1889_ = L_1896_forvar1:IsA("ScreenGui")
					L_1890_ = L_1896_forvar1
					L_1891_ = "ScreenGui"
					if L_1889_ then
						pcall(L_1_.callback_267)
						L_1889_ = getgenv()
						L_1889_[L_1895_forvar0] = nil
						L_1890_ = nil
					end
				end
			end
		end
	end
	return
end

L_1_.callback_269 = function()
	local L_1897_, L_1898_, L_1899_, L_1900_, L_1901_, L_1902_
	pcall(L_1_.callback_268)
	task.wait(0.1)
	L_1897_ = getgenv()
	L_1897_.Window = upvalue_0.CreateLib(upvalue_1.HubName, "Midnight")
	upvalue_2:Notify("Reloaded", "Hub UI restarted.", 3, false)
	return
end

L_1_.NewToggle_270 = function()
	local L_1903_
	return
end

L_1_.NewSection_271 = function()
	local L_1904_
	return upvalue_0
end

L_1_.NewSection_272 = function()
	local L_1905_
	return upvalue_0
end

L_1_.createFallbackGameTab = function()
	local L_1906_, L_1907_, L_1908_, L_1909_
	L_1907_ = {}
	L_1907_.NewToggle = L_1_.NewToggle_270
	L_1907_.NewButton = L_1_.NewToggle_270
	L_1907_.NewSlider = L_1_.NewToggle_270
	L_1907_.NewDropdown = L_1_.NewToggle_270
	L_1907_.NewLabel = L_1_.NewToggle_270
	L_1907_.NewPremiumToggle = L_1_.NewToggle_270
	L_1907_.NewPremiumButton = L_1_.NewToggle_270
	L_1907_.NewPremiumSlider = L_1_.NewToggle_270
	L_1907_.NewPremiumDropdown = L_1_.NewToggle_270
	L_1907_.NewSection = L_1_.NewSection_271
	L_1908_ = {}
	L_1908_.NewSection = L_1_.NewSection_272
	L_1908_.HideTabButton = L_1_.NewToggle_270
	L_1908_.Select = L_1_.NewToggle_270
	L_1909_ = {}
	L_1909_.SetVisible = L_1_.NewToggle_270
	L_1908_.ActualTab = L_1909_
	return L_1908_
end

L_1_.unlockTreadmillClientFlags = function()
	local L_1910_, L_1911_, L_1912_, L_1913_, L_1914_, L_1915_, L_1916_
	L_1910_ = require(upvalue_0:WaitForChild("ClientState", 10))
	L_1911_ = require(upvalue_0:WaitForChild("ClientState", 10))
	L_1912_ = upvalue_0
	L_1913_ = "ClientState"
	L_1914_ = 10
	if L_1911_ then
		L_1911_ = L_1910_.Get
		if L_1911_ then
			L_1911_ = L_1910_:Get()
			L_1912_ = L_1910_
		end
	end
	L_1912_ = type(L_1911_)
	L_1913_ = L_1911_
	L_1915_ = "table"
	L_1916_ = (type(L_1911_) == "table")
	if not (L_1916_) then
		return
	end
	L_1911_.GoldTreadmillActive = true
	L_1911_.DiamondTreadmillActive = true
	L_1911_.CandyTreadmillActive = true
	L_1911_.AdminTreadmillActive = true
	L_1911_.AdminAbuseTreadmillActive = true
	L_1911_.ManualGoldAccess = true
	L_1911_.ManualDiamondAccess = true
	L_1911_.ManualCandyAccess = true
	L_1911_.ManualAdminAccess = true
	L_1912_ = true
	return
end

L_1_.BypassFunction = function()
	local L_1917_, L_1918_
	return pcall(L_1_.unlockTreadmillClientFlags)
end

L_1_.unlockInfinityTrailImpl = function()
	local L_1919_, L_1920_, L_1921_, L_1922_, L_1923_, L_1924_, L_1925_
	L_1919_ = upvalue_0:WaitForChild("Remotes", 10)
	L_1920_ = upvalue_0:WaitForChild("Remotes", 10)
	L_1921_ = "Remotes"
	L_1922_ = 10
	if L_1920_ then
		L_1920_ = L_1919_:WaitForChild("BuyTrail", 10)
		L_1921_ = L_1919_
		L_1922_ = "BuyTrail"
		L_1923_ = 10
	end
	L_1921_ = L_1919_
	if L_1921_ then
		L_1921_ = L_1919_:WaitForChild("EquipTrail", 10)
		L_1922_ = L_1919_
		L_1923_ = "EquipTrail"
		L_1924_ = 10
	end
	if not (L_1920_) then
		return false
	end
	if L_1921_ then
		task.wait(0.5)
		L_1921_:FireServer("InfinityTrail")
		return L_1920_:InvokeServer("InfinityTrail", "Wins")
	else
		return false
	end
end

L_1_.UnlockInfinityTrail = function()
	local L_1926_, L_1927_
	return pcall(L_1_.unlockInfinityTrailImpl)
end

L_1_.unlockAuraImpl = function()
	local L_1928_, L_1929_, L_1930_, L_1931_, L_1932_, L_1933_, L_1934_
	L_1928_ = upvalue_0:WaitForChild("Remotes", 10)
	L_1929_ = upvalue_0:WaitForChild("Remotes", 10)
	L_1928_ = L_1928_:FindFirstChild("BuyAura")
	L_1929_ = L_1929_:FindFirstChild("EquipAura")
	L_1930_ = L_1929_
	L_1931_ = "EquipAura"
	L_1932_ = 10
	if not (L_1928_) then
		return false
	end
	if L_1929_ then
		task.wait(0.5)
		L_1929_:FireServer(upvalue_1:gsub("%s+", ""))
		return L_1928_:InvokeServer(upvalue_1:gsub("%s+", ""), "Wins")
	else
		return false
	end
end

L_1_.UnlockAuraBypass = function(L_1935_arg0)
	local L_1936_, L_1937_
	return pcall(L_1_.unlockAuraImpl)
end

L_1_.setAutoStepFarm = function(L_1938_arg0)
	local L_1939_
	L_1939_ = upvalue_0
	L_1939_.AutoStepFarm = L_1938_arg0
	return
end

L_1_.setWorld1WinTarget = function(L_1940_arg0)
	local L_1941_
	L_1941_ = upvalue_0
	if L_1941_ then
		return
	end
	L_1941_ = upvalue_1
	L_1941_.SelectedWinTarget = L_1940_arg0
	return
end

L_1_.setWorld2WinTarget = function(L_1942_arg0)
	local L_1943_
	L_1943_ = upvalue_0
	if not (L_1943_) then
		return
	end
	L_1943_ = upvalue_1
	L_1943_.SelectedWinTarget = L_1942_arg0
	return
end

L_1_.setAutoWinsFarm = function(L_1944_arg0)
	local L_1945_
	L_1945_ = upvalue_0
	L_1945_.AutoWinsFarm = L_1944_arg0
	return
end

L_1_.setTweenSpeed = function(L_1946_arg0)
	local L_1947_
	L_1947_ = upvalue_0
	L_1947_.TweenSpeed = L_1946_arg0
	L_1947_ = _G
	L_1947_.TweenSpeed = L_1946_arg0
	return
end

L_1_.setAutoRebirth = function(L_1948_arg0)
	local L_1949_
	L_1949_ = upvalue_0
	L_1949_.AutoRebirth = L_1948_arg0
	return
end

L_1_.setFreezePosition = function(L_1950_arg0)
	local L_1951_
	L_1951_ = upvalue_0
	L_1951_.FreezePosition = L_1950_arg0
	return
end

L_1_.setTargetTreadmill = function(L_1952_arg0)
	local L_1953_
	L_1953_ = upvalue_0
	L_1953_.TargetTreadmill = L_1952_arg0
	return
end

L_1_.runTreadmillBypass = function()
	local L_1954_, L_1955_, L_1956_, L_1957_, L_1958_, L_1959_, L_1960_, L_1961_, L_1962_
	L_1954_ = upvalue_0.BypassFunction
	L_1955_ = upvalue_0
	L_1954_, L_1955_ = upvalue_0.BypassFunction()
	if L_1954_ then
		upvalue_1:Notify("Bypass Success!", "All Treadmills successfully unlocked!", 5)
		return
	else
		upvalue_1:Notify("Bypass Failed", "Error: " .. tostring(L_1955_), 5)
		return
	end
end

L_1_.runInfinityTrailUnlock = function()
	local L_1963_, L_1964_, L_1965_, L_1966_, L_1967_, L_1968_, L_1969_, L_1970_, L_1971_
	L_1963_ = upvalue_0.UnlockInfinityTrail
	L_1964_ = upvalue_0
	L_1963_, L_1964_ = upvalue_0.UnlockInfinityTrail()
	if L_1963_ then
		upvalue_1:Notify("Bypass Success!", "Infinity Trail successfully unlocked and equipped!", 5)
		return
	else
		upvalue_1:Notify("Bypass Failed", "Error: " .. tostring(L_1964_), 5)
		return
	end
end

L_1_.setSelectedAura = function(L_1972_arg0)
	local L_1973_
	L_1973_ = upvalue_0
	L_1973_.SelectedAura = L_1972_arg0
	return
end

L_1_.buySelectedAura = function()
	local L_1974_, L_1975_, L_1976_, L_1977_, L_1978_, L_1979_, L_1980_, L_1981_, L_1982_
	L_1974_ = upvalue_0.UnlockAuraBypass
	L_1975_ = upvalue_0.SelectedAura
	L_1976_ = upvalue_0.SelectedAura
	L_1977_ = upvalue_0
	if not (L_1975_) then
		L_1975_ = "GlowAura"
	end
	L_1974_, L_1975_ = L_1974_(L_1975_)
	if L_1974_ then
		upvalue_1:Notify("Buy Aura Success", "Aura successfully unlocked and equipped!", 5)
		return
	else
		upvalue_1:Notify("Bypass Failed", "Error: " .. tostring(L_1975_), 5)
		return
	end
end

L_1_.equipSelectedAura = function()
	local L_1983_, L_1984_, L_1985_, L_1986_, L_1987_, L_1988_, L_1989_, L_1990_
	L_1983_ = upvalue_0:WaitForChild("Remotes", 10)
	L_1983_ = L_1983_:FindFirstChild("EquipAura")
	L_1984_ = upvalue_1.SelectedAura
	L_1985_ = upvalue_1.SelectedAura
	L_1986_ = upvalue_1
	if not (L_1984_) then
		L_1984_ = "GlowAura"
	end
	if not (L_1983_) then
		return
	end
	L_1983_:FireServer(L_1984_:gsub("%s+", ""))
	upvalue_2:Notify("Equipped!", "Aura successfully equipped!", 5)
	L_1985_ = L_1984_:gsub("%s+", "")
	L_1986_ = upvalue_2.Notify
	L_1987_ = upvalue_2
	L_1988_ = "Equipped!"
	L_1989_ = "Aura successfully equipped!"
	L_1990_ = 5
	return
end

L_1_.setAutoEquipBest = function(L_1991_arg0)
	local L_1992_
	L_1992_ = upvalue_0
	L_1992_.AutoEquipBest = L_1991_arg0
	return
end

L_1_.setTargetBuyItem = function(L_1993_arg0)
	local L_1994_, L_1995_, L_1996_
	L_1995_ = {}
	L_1995_[1] = L_1993_arg0
	L_1994_ = upvalue_0
	L_1994_.TargetBuyItems = L_1995_
	return
end

L_1_.setAutoBuyItems = function(L_1997_arg0)
	local L_1998_
	L_1998_ = upvalue_0
	L_1998_.AutoBuyItems = L_1997_arg0
	return
end

L_1_.antiAfkPulse = function()
	local L_1999_, L_2000_, L_2001_, L_2002_, L_2003_
	L_1999_ = game:GetService("VirtualUser")
	L_1999_:CaptureController()
	L_1999_ = game:GetService("VirtualUser")
	L_1999_:ClickButton2(Vector2.new(0, 0))
	return
end

L_1_.configureAntiAfk = function(L_2004_arg0)
	local L_2005_, L_2006_, L_2007_, L_2008_, L_2009_, L_2010_, L_2011_, L_2012_
	if not (L_2004_arg0) then
		return
	end
	L_2005_ = getconnections
	if not (L_2005_) then
		L_2005_ = get_signal_cons
	end
	if L_2005_ then
		L_2006_ = pairs
		L_2007_ = select(1, L_2005_(upvalue_0.Idled))
		L_2008_ = upvalue_0.Idled
		L_2009_ = upvalue_0
		L_2006_, L_2007_, L_2008_ = pairs(L_2005_(upvalue_0.Idled))
		for L_2013_forvar0, L_2014_forvar1 in L_2006_, L_2007_, L_2008_ do
			L_2011_ = L_2014_forvar1.Disable
			if L_2011_ then
				L_2014_forvar1:Disable()
				L_2011_ = L_2014_forvar1.Disable
				L_2012_ = L_2014_forvar1
			else
				L_2011_ = L_2014_forvar1.Disconnect
				if L_2011_ then
					L_2014_forvar1:Disconnect()
					L_2011_ = L_2014_forvar1.Disconnect
					L_2012_ = L_2014_forvar1
				end
			end
		end
		return
	else
		upvalue_0.Idled:Connect(L_1_.antiAfkPulse)
		L_2006_ = upvalue_0.Idled.Connect
		L_2007_ = upvalue_0.Idled
		L_2008_ = L_1_.antiAfkPulse
		return
	end
end

L_1_.setCFrameSpeed = function(L_2015_arg0)
	local L_2016_
	L_2016_ = upvalue_0
	L_2016_.CFrameSpeed = L_2015_arg0
	return
end

L_1_.setTargetWalkSpeed = function(L_2017_arg0)
	local L_2018_
	L_2018_ = upvalue_0
	L_2018_.TargetWalkSpeed = L_2017_arg0
	return
end

L_1_.setCFrameFly = function(L_2019_arg0)
	local L_2020_, L_2021_, L_2022_, L_2023_, L_2024_, L_2025_, L_2026_
	L_2020_ = upvalue_0
	L_2020_.CFrameFly = L_2019_arg0
	L_2020_ = upvalue_1.Character
	L_2021_ = upvalue_1.Character
	if L_2021_ then
		L_2021_ = L_2020_:FindFirstChild("HumanoidRootPart")
		L_2022_ = L_2020_
		L_2023_ = "HumanoidRootPart"
	end
	if not (L_2021_) then
		return
	end
	L_2022_ = L_2021_:FindFirstChild("IY_Fly_BV")
	L_2023_ = L_2021_
	L_2024_ = "IY_Fly_BV"
	if L_2019_arg0 then
		if L_2022_ then
			return
		else
			L_2022_ = Instance.new("BodyVelocity")
			L_2022_.Name = "IY_Fly_BV"
			L_2022_.MaxForce = Vector3.new(9000000000, 9000000000, 9000000000)
			L_2022_.Velocity = Vector3.zero
			L_2022_.Parent = L_2021_
			return
		end
	else
		if not (L_2022_) then
			return
		end
		L_2022_:Destroy()
		L_2023_ = L_2022_.Destroy
		L_2024_ = L_2022_
		return
	end
end

L_1_.setTargetFlySpeed = function(L_2027_arg0)
	local L_2028_
	L_2028_ = upvalue_0
	L_2028_.TargetFlySpeed = L_2027_arg0
	return
end

L_1_.lifecycleWorkerA = function()
	local L_2029_, L_2030_
	repeat
		L_2029_ = upvalue_0.HubRunning
		L_2030_ = upvalue_0
	until not (L_2029_)
	return
end

L_1_.applyFreezePosition = function()
	local L_2031_, L_2032_, L_2033_, L_2034_, L_2035_
	L_2031_ = upvalue_0.Character
	L_2032_ = upvalue_0.Character
	if L_2032_ then
		L_2032_ = L_2031_:FindFirstChild("HumanoidRootPart")
		L_2033_ = L_2031_
		L_2034_ = "HumanoidRootPart"
	end
	if not (L_2032_) then
		return
	end
	L_2033_ = not upvalue_1.AutoWinsFarm
	L_2034_ = upvalue_1.AutoWinsFarm
	L_2035_ = upvalue_1
	if L_2033_ then
		L_2033_ = upvalue_1.FreezePosition
		L_2034_ = upvalue_1
	end
	L_2032_.Anchored = L_2033_
	return
end

L_1_.lifecycleWorkerB = function()
	local L_2036_, L_2037_
	repeat
		L_2036_ = upvalue_0.HubRunning
		L_2037_ = upvalue_0
	until not (L_2036_)
	return
end

L_1_.getTrailMultiplier = function(L_2038_arg0, L_2039_arg1, L_2040_arg2)
	local L_2041_, L_2042_, L_2043_, L_2044_, L_2045_, L_2046_, L_2047_, L_2048_, L_2049_
	if not (L_2039_arg1) then
		return 1
	end
	L_2041_ = L_2039_arg1.TRAILS
	if not (L_2041_) then
		return 1
	end
	L_2041_ = L_2039_arg1.TRAILS[L_2038_arg0]
	L_2042_ = L_2039_arg1.TRAILS
	if not (L_2041_) then
		if L_2040_arg2 then
			L_2042_ = ipairs
			L_2043_ = L_2040_arg2.Trails
			if not (L_2043_) then
				L_2043_ = {}
			end
			L_2042_, L_2043_, L_2044_ = L_2042_(L_2043_)
			for L_2050_forvar0, L_2051_forvar1 in L_2042_, L_2043_, L_2044_ do
				L_2047_ = L_2051_forvar1.Key
				L_2049_ = (L_2051_forvar1.Key == L_2038_arg0)
				if L_2049_ then
					L_2041_ = L_2051_forvar1
					if L_2041_ then
						break
					end
					L_2042_ = 1
					return L_2042_
				end
			end
		end
	end
	if L_2041_ then
		L_2042_ = L_2041_.Multiplier
		if L_2042_ then
			return L_2042_
		end
		L_2042_ = 1
	else
		L_2042_ = 1
	end
	return L_2042_
end

L_1_.runStepFarmTick = function()
	local L_2052_, L_2053_, L_2054_, L_2055_, L_2056_, L_2057_, L_2058_, L_2059_, L_2060_, L_2061_, L_2062_
	L_2052_ = upvalue_0:Get()
	L_2053_ = upvalue_0
	if not (L_2052_) then
		return
	end
	L_2053_ = L_2052_.onTreadmill
	if L_2053_ then
		upvalue_1 = true
		return
	end
	L_2053_ = upvalue_1
	if L_2053_ then
		upvalue_2:FireServer(false)
		upvalue_1 = false
		task.wait(0.1)
		L_2053_ = task.wait
		L_2054_ = 0.1
		L_2055_ = false
	end
	upvalue_3:FireServer("Walking")
	L_2053_ = upvalue_4
	L_2054_ = L_2052_.EquippedTrail
	L_2055_ = L_2052_.EquippedTrail
	if not (L_2054_) then
		L_2054_ = "None"
	end
	L_2053_ = L_2053_(L_2054_, upvalue_5, upvalue_6)
	L_2054_ = upvalue_7
	L_2055_ = upvalue_5
	L_2056_ = L_2052_.StepBonus
	L_2057_ = L_2052_.Multiplier
	L_2058_ = L_2052_.SpeedBoostMultiplier
	L_2059_ = L_2053_(L_2054_, upvalue_5, upvalue_6)
	L_2060_ = 1
	L_2061_ = L_2052_.BonusXPMultiplier
	L_2062_ = L_2052_.BonusXPMultiplier
	if L_2061_ then
		L_2054_:ShowPlusOne(L_2056_, L_2057_, L_2058_, L_2059_, L_2060_, L_2061_)
		return
	end
	L_2061_ = 1
	L_2054_:ShowPlusOne(L_2056_, L_2057_, L_2058_, L_2059_, L_2060_, L_2061_)
	return
end

L_1_.autoStepFarmWorker = function()
	local L_2063_, L_2064_, L_2065_, L_2066_, L_2067_, L_2068_, L_2069_, L_2070_, L_2071_
	L_2063_ = require(upvalue_0:WaitForChild("ClientState", 10))
	L_2064_ = require(upvalue_0:WaitForChild("NotificationSystem", 10))
	L_2065_ = require(upvalue_0:WaitForChild("EventsConfig", 10))
	L_2066_ = upvalue_0:WaitForChild("Config", 10)
	L_2067_ = upvalue_0:WaitForChild("Config", 10)
	L_2068_ = "Config"
	L_2069_ = 10

	L_2068_ = L_2066_:IsA("Folder")
	L_2069_ = L_2066_
	L_2070_ = "Folder"

	L_2067_ = require(L_2066_:WaitForChild("GeneralConfig", 10))
	L_2068_ = select(1, L_2066_:WaitForChild("GeneralConfig", 10))
	L_2069_ = L_2066_
	L_2070_ = "GeneralConfig"
	L_2071_ = 10

	L_2067_ = require(L_2066_)
	L_2068_ = L_2066_

	L_2068_ = false

	L_2069_ = upvalue_1.HubRunning
	L_2070_ = upvalue_1

	task.wait(0.05)
	L_2069_ = upvalue_1.AutoStepFarm
	L_2070_ = upvalue_1

	L_2069_ = upvalue_1.AutoWinsFarm
	L_2070_ = upvalue_1

	pcall(L_1_.runStepFarmTick)
	L_2069_ = pcall
	L_2070_ = L_1_.runStepFarmTick

	do
		return
	end
end

L_1_.findWorld1WallTrap = function()
	local L_2072_, L_2073_, L_2074_, L_2075_, L_2076_
	L_2072_ = upvalue_0
	if L_2072_ then
		L_2072_ = upvalue_1
		if L_2072_ then
			L_2072_ = upvalue_0.Parent
			L_2073_ = upvalue_0
			if L_2072_ then
				L_2072_ = upvalue_1.Parent
				L_2073_ = upvalue_1
				if L_2072_ then
					return
				end
				L_2072_ = workspace:FindFirstChild("NPC & Piege")
				L_2073_ = workspace
				L_2074_ = "NPC & Piege"
				if not (L_2072_) then
					return
				end
				L_2073_ = L_2072_:FindFirstChild("CorridorTrap")
				L_2074_ = L_2072_
				L_2075_ = "CorridorTrap"
				if not (L_2073_) then
					return
				end
				upvalue_0 = L_2073_:FindFirstChild("WallL")
				upvalue_1 = L_2073_:FindFirstChild("WallR")
				L_2074_ = L_2073_:FindFirstChild("WallR")
				L_2075_ = L_2073_
				L_2076_ = "WallR"
			else
				L_2072_ = workspace:FindFirstChild("NPC & Piege")
				L_2073_ = workspace
				L_2074_ = "NPC & Piege"
				if not (L_2072_) then
					return
				end
				L_2073_ = L_2072_:FindFirstChild("CorridorTrap")
				L_2074_ = L_2072_
				L_2075_ = "CorridorTrap"
				if not (L_2073_) then
					return
				end
				upvalue_0 = L_2073_:FindFirstChild("WallL")
				upvalue_1 = L_2073_:FindFirstChild("WallR")
				L_2074_ = L_2073_:FindFirstChild("WallR")
				L_2075_ = L_2073_
				L_2076_ = "WallR"
			end
		else
			L_2072_ = workspace:FindFirstChild("NPC & Piege")
			L_2073_ = workspace
			L_2074_ = "NPC & Piege"
			if not (L_2072_) then
				return
			end
			L_2073_ = L_2072_:FindFirstChild("CorridorTrap")
			L_2074_ = L_2072_
			L_2075_ = "CorridorTrap"
			if not (L_2073_) then
				return
			end
			upvalue_0 = L_2073_:FindFirstChild("WallL")
			upvalue_1 = L_2073_:FindFirstChild("WallR")
			L_2074_ = L_2073_:FindFirstChild("WallR")
			L_2075_ = L_2073_
			L_2076_ = "WallR"
		end
	else
		L_2072_ = workspace:FindFirstChild("NPC & Piege")
		L_2073_ = workspace
		L_2074_ = "NPC & Piege"
		if not (L_2072_) then
			return
		end
		L_2073_ = L_2072_:FindFirstChild("CorridorTrap")
		L_2074_ = L_2072_
		L_2075_ = "CorridorTrap"
		if not (L_2073_) then
			return
		end
		upvalue_0 = L_2073_:FindFirstChild("WallL")
		upvalue_1 = L_2073_:FindFirstChild("WallR")
		L_2074_ = L_2073_:FindFirstChild("WallR")
		L_2075_ = L_2073_
		L_2076_ = "WallR"
	end
	return
end

L_1_.findWorld1LavaTrap = function()
	local L_2077_, L_2078_, L_2079_, L_2080_, L_2081_
	L_2077_ = upvalue_0
	if L_2077_ then
		L_2077_ = upvalue_1
		if L_2077_ then
			L_2077_ = upvalue_0.Parent
			L_2078_ = upvalue_0
			if L_2077_ then
				L_2077_ = upvalue_1.Parent
				L_2078_ = upvalue_1
				if L_2077_ then
					return
				end
				L_2077_ = workspace:FindFirstChild("NPC & Piege")
				L_2078_ = workspace
				L_2079_ = "NPC & Piege"
				if not (L_2077_) then
					return
				end
				L_2078_ = L_2077_:FindFirstChild("LavaTower")
				L_2079_ = L_2077_
				L_2080_ = "LavaTower"
				if not (L_2078_) then
					return
				end
				upvalue_0 = L_2078_:FindFirstChild("LavaPart")
				upvalue_1 = L_2078_:FindFirstChild("LavaBottom")
				L_2079_ = L_2078_:FindFirstChild("LavaBottom")
				L_2080_ = L_2078_
				L_2081_ = "LavaBottom"
			else
				L_2077_ = workspace:FindFirstChild("NPC & Piege")
				L_2078_ = workspace
				L_2079_ = "NPC & Piege"
				if not (L_2077_) then
					return
				end
				L_2078_ = L_2077_:FindFirstChild("LavaTower")
				L_2079_ = L_2077_
				L_2080_ = "LavaTower"
				if not (L_2078_) then
					return
				end
				upvalue_0 = L_2078_:FindFirstChild("LavaPart")
				upvalue_1 = L_2078_:FindFirstChild("LavaBottom")
				L_2079_ = L_2078_:FindFirstChild("LavaBottom")
				L_2080_ = L_2078_
				L_2081_ = "LavaBottom"
			end
		else
			L_2077_ = workspace:FindFirstChild("NPC & Piege")
			L_2078_ = workspace
			L_2079_ = "NPC & Piege"
			if not (L_2077_) then
				return
			end
			L_2078_ = L_2077_:FindFirstChild("LavaTower")
			L_2079_ = L_2077_
			L_2080_ = "LavaTower"
			if not (L_2078_) then
				return
			end
			upvalue_0 = L_2078_:FindFirstChild("LavaPart")
			upvalue_1 = L_2078_:FindFirstChild("LavaBottom")
			L_2079_ = L_2078_:FindFirstChild("LavaBottom")
			L_2080_ = L_2078_
			L_2081_ = "LavaBottom"
		end
	else
		L_2077_ = workspace:FindFirstChild("NPC & Piege")
		L_2078_ = workspace
		L_2079_ = "NPC & Piege"
		if not (L_2077_) then
			return
		end
		L_2078_ = L_2077_:FindFirstChild("LavaTower")
		L_2079_ = L_2077_
		L_2080_ = "LavaTower"
		if not (L_2078_) then
			return
		end
		upvalue_0 = L_2078_:FindFirstChild("LavaPart")
		upvalue_1 = L_2078_:FindFirstChild("LavaBottom")
		L_2079_ = L_2078_:FindFirstChild("LavaBottom")
		L_2080_ = L_2078_
		L_2081_ = "LavaBottom"
	end
	return
end

L_1_.world1HazardStateWorker = function()
	local L_2082_, L_2083_, L_2084_, L_2085_, L_2086_, L_2087_, L_2088_, L_2089_, L_2090_, L_2091_, L_2092_
	L_2082_ = 0
	L_2083_ = 0

	L_2084_ = upvalue_0.HubRunning
	L_2085_ = upvalue_0

	L_2084_ = upvalue_0.isWorld2
	L_2085_ = upvalue_0

	upvalue_1()
	L_2084_ = upvalue_2

	L_2084_ = upvalue_3

	L_2086_ = upvalue_0
	L_2086_.WallDistance = (upvalue_2.Position - upvalue_3.Position).Magnitude
	L_2082_ = (upvalue_2.Position - upvalue_3.Position).Magnitude
	L_2084_ = (upvalue_2.Position - upvalue_3.Position).Magnitude
	L_2085_ = ((upvalue_2.Position - upvalue_3.Position).Magnitude - L_2082_)
	L_2086_ = math.abs(((upvalue_2.Position - upvalue_3.Position).Magnitude - L_2082_))
	L_2087_ = 0.05
	L_2088_ = upvalue_3
	L_2092_ = (math.abs(((upvalue_2.Position - upvalue_3.Position).Magnitude - L_2082_)) < 0.05)

	L_2086_ = upvalue_0
	L_2088_ = 65
	L_2092_ = (65 < L_2084_)

	L_2087_ = "Open"

	L_2087_ = "Closed"

	L_2086_.WallState = L_2087_

	L_2086_ = 0.05
	L_2092_ = (0.05 < L_2085_)

	L_2086_ = upvalue_0
	L_2086_.WallState = "Opening"
	L_2087_ = "Opening"

	L_2086_ = -0.05
	L_2092_ = (L_2085_ < -0.05)

	L_2086_ = upvalue_0
	L_2086_.WallState = "Closing"
	L_2087_ = "Closing"

	L_2084_ = upvalue_0
	L_2084_.WallState = "Unknown"
	L_2085_ = "Unknown"

	upvalue_4()
	L_2084_ = upvalue_5

	L_2084_ = upvalue_6

	L_2088_ = upvalue_0
	L_2088_.LavaDistance = math.abs((upvalue_5.Position.Y - upvalue_6.Position.Y))
	L_2083_ = upvalue_5.Position.Y
	L_2084_ = upvalue_5.Position.Y
	L_2085_ = upvalue_6.Position.Y
	L_2086_ = math.abs((upvalue_5.Position.Y - upvalue_6.Position.Y))
	L_2087_ = (upvalue_5.Position.Y - L_2083_)
	L_2088_ = math.abs((upvalue_5.Position.Y - L_2083_))
	L_2089_ = 0.05
	L_2092_ = (math.abs((upvalue_5.Position.Y - L_2083_)) < 0.05)

	L_2088_ = upvalue_0
	L_2090_ = 8
	L_2092_ = (L_2086_ < 8)

	L_2089_ = "Safe"

	L_2089_ = "Danger"

	L_2088_.LavaState = L_2089_

	L_2088_ = 0.05
	L_2092_ = (0.05 < L_2087_)

	L_2088_ = upvalue_0
	L_2088_.LavaState = "Rising"
	L_2089_ = "Rising"

	L_2088_ = -0.05
	L_2092_ = (L_2087_ < -0.05)

	L_2088_ = upvalue_0
	L_2088_.LavaState = "Falling"
	L_2089_ = "Falling"

	L_2084_ = upvalue_0
	L_2084_.LavaState = "Unknown"
	L_2085_ = "Unknown"

	L_2084_ = upvalue_0
	L_2084_.WallState = "Unknown"
	L_2084_ = upvalue_0
	L_2084_.LavaState = "Unknown"
	L_2085_ = "Unknown"

	task.wait(0.05)
	L_2084_ = task.wait
	L_2085_ = 0.05

	do
		return
	end
end

L_1_.findWorld2WallTrap = function()
	local L_2093_, L_2094_, L_2095_, L_2096_, L_2097_, L_2098_, L_2099_, L_2100_, L_2101_, L_2102_, L_2103_, L_2104_, L_2105_
	L_2093_ = upvalue_0

	L_2093_ = upvalue_1

	L_2093_ = upvalue_0.Parent
	L_2094_ = upvalue_0

	L_2093_ = upvalue_1.Parent
	L_2094_ = upvalue_1

	L_2093_ = workspace:FindFirstChild("WORLD 2")
	L_2094_ = workspace
	L_2095_ = "WORLD 2"

	L_2094_ = L_2093_:FindFirstChild("Stage2")
	L_2095_ = L_2093_
	L_2096_ = "Stage2"

	L_2095_ = {}
	L_2096_ = pairs
	L_2097_ = select(1, L_2094_:GetChildren())
	L_2098_ = L_2094_
	L_2096_, L_2097_, L_2098_ = pairs(L_2094_:GetChildren())

	L_2101_ = L_2100_.Name
	L_2104_ = "MovingWalls"
	L_2105_ = (L_2100_.Name == "MovingWalls")

	table.insert(L_2095_, L_2100_)
	L_2101_ = table.insert
	L_2102_ = L_2095_
	L_2103_ = L_2100_

	L_2096_ = #L_2095_
	L_2097_ = 2
	L_2105_ = (2 <= #L_2095_)

	upvalue_0 = L_2095_[1]:FindFirstChild("MovingWall1")
	upvalue_1 = L_2095_[2]:FindFirstChild("MovingWall1")
	L_2096_ = L_2095_[2]:FindFirstChild("MovingWall1")
	L_2097_ = L_2095_[2]
	L_2098_ = "MovingWall1"

	do
		return upvalue_0, upvalue_1
	end
end

L_1_.findWorld2LavaTrap = function()
	local L_2106_, L_2107_, L_2108_, L_2109_, L_2110_
	L_2106_ = upvalue_0
	if L_2106_ then
		L_2106_ = upvalue_1
		if L_2106_ then
			L_2106_ = upvalue_0.Parent
			L_2107_ = upvalue_0
			if L_2106_ then
				L_2106_ = upvalue_1.Parent
				L_2107_ = upvalue_1
				if L_2106_ then
					return upvalue_0, upvalue_1
				end
				L_2106_ = workspace:FindFirstChild("Pieges & Lava")
				L_2107_ = workspace
				L_2108_ = "Pieges & Lava"
				if not (L_2106_) then
					return upvalue_0, upvalue_1
				end
				L_2107_ = L_2106_:FindFirstChild("Lava_Stage3")
				L_2108_ = L_2106_
				L_2109_ = "Lava_Stage3"
				if not (L_2107_) then
					return upvalue_0, upvalue_1
				end
				upvalue_0 = L_2107_:FindFirstChild("LavaPart")
				upvalue_1 = L_2107_:FindFirstChild("LavaBottom")
				L_2108_ = L_2107_:FindFirstChild("LavaBottom")
				L_2109_ = L_2107_
				L_2110_ = "LavaBottom"
			else
				L_2106_ = workspace:FindFirstChild("Pieges & Lava")
				L_2107_ = workspace
				L_2108_ = "Pieges & Lava"
				if not (L_2106_) then
					return upvalue_0, upvalue_1
				end
				L_2107_ = L_2106_:FindFirstChild("Lava_Stage3")
				L_2108_ = L_2106_
				L_2109_ = "Lava_Stage3"
				if not (L_2107_) then
					return upvalue_0, upvalue_1
				end
				upvalue_0 = L_2107_:FindFirstChild("LavaPart")
				upvalue_1 = L_2107_:FindFirstChild("LavaBottom")
				L_2108_ = L_2107_:FindFirstChild("LavaBottom")
				L_2109_ = L_2107_
				L_2110_ = "LavaBottom"
			end
		else
			L_2106_ = workspace:FindFirstChild("Pieges & Lava")
			L_2107_ = workspace
			L_2108_ = "Pieges & Lava"
			if not (L_2106_) then
				return upvalue_0, upvalue_1
			end
			L_2107_ = L_2106_:FindFirstChild("Lava_Stage3")
			L_2108_ = L_2106_
			L_2109_ = "Lava_Stage3"
			if not (L_2107_) then
				return upvalue_0, upvalue_1
			end
			upvalue_0 = L_2107_:FindFirstChild("LavaPart")
			upvalue_1 = L_2107_:FindFirstChild("LavaBottom")
			L_2108_ = L_2107_:FindFirstChild("LavaBottom")
			L_2109_ = L_2107_
			L_2110_ = "LavaBottom"
		end
	else
		L_2106_ = workspace:FindFirstChild("Pieges & Lava")
		L_2107_ = workspace
		L_2108_ = "Pieges & Lava"
		if not (L_2106_) then
			return upvalue_0, upvalue_1
		end
		L_2107_ = L_2106_:FindFirstChild("Lava_Stage3")
		L_2108_ = L_2106_
		L_2109_ = "Lava_Stage3"
		if not (L_2107_) then
			return upvalue_0, upvalue_1
		end
		upvalue_0 = L_2107_:FindFirstChild("LavaPart")
		upvalue_1 = L_2107_:FindFirstChild("LavaBottom")
		L_2108_ = L_2107_:FindFirstChild("LavaBottom")
		L_2109_ = L_2107_
		L_2110_ = "LavaBottom"
	end
	return upvalue_0, upvalue_1
end

L_1_.world2WallStateWorker = function()
	local L_2111_, L_2112_, L_2113_, L_2114_, L_2115_, L_2116_, L_2117_, L_2118_, L_2119_, L_2120_
	L_2111_ = upvalue_0.HubRunning
	L_2112_ = upvalue_0

	task.wait(0.05)
	L_2111_ = upvalue_0.isWorld2
	L_2112_ = upvalue_0

	L_2111_ = upvalue_1
	L_2111_, L_2112_ = upvalue_1()

	L_2113_ = (L_2111_.Position - L_2112_.Position).Magnitude
	L_2114_ = upvalue_2
	L_2115_ = L_2111_.Position
	L_2116_ = L_2112_.Position
	L_2120_ = ((L_2111_.Position - L_2112_.Position).Magnitude < upvalue_2)

	upvalue_2 = L_2113_

	L_2114_ = upvalue_3
	L_2120_ = (upvalue_3 < L_2113_)

	upvalue_3 = L_2113_

	L_2114_ = (upvalue_3 - upvalue_2)
	L_2115_ = 1
	L_2116_ = upvalue_2
	L_2120_ = (1 < (upvalue_3 - upvalue_2))

	L_2115_ = (((L_2113_ - upvalue_2) / L_2114_) * 100)
	L_2116_ = upvalue_0
	L_2117_ = (L_2113_ - upvalue_2)
	L_2118_ = 70
	L_2120_ = (70 < (((L_2113_ - upvalue_2) / L_2114_) * 100))

	L_2117_ = "Open"

	L_2117_ = "Closed"

	L_2116_.World2WallState = L_2117_

	L_2115_ = upvalue_0
	L_2115_.World2WallState = "Calibrating"
	L_2116_ = "Calibrating"

	L_2113_ = upvalue_0
	L_2113_.World2WallState = "Unknown"
	L_2114_ = "Unknown"

	do
		return
	end
end

L_1_.world2LavaStateWorker = function()
	local L_2121_, L_2122_, L_2123_, L_2124_, L_2125_, L_2126_, L_2127_, L_2128_, L_2129_, L_2130_, L_2131_
	L_2121_ = upvalue_0.HubRunning
	L_2122_ = upvalue_0

	task.wait(0.05)
	L_2121_ = upvalue_0.isWorld2
	L_2122_ = upvalue_0

	L_2121_ = upvalue_1
	L_2121_, L_2122_ = upvalue_1()

	upvalue_2 = L_2121_.Position.Y
	L_2123_ = L_2121_.Position.Y
	L_2124_ = L_2122_.Position.Y
	L_2125_ = math.abs((L_2121_.Position.Y - L_2122_.Position.Y))
	L_2126_ = (L_2121_.Position.Y - upvalue_2)
	L_2127_ = math.abs((L_2121_.Position.Y - upvalue_2))
	L_2128_ = 0.05
	L_2131_ = (math.abs((L_2121_.Position.Y - upvalue_2)) < 0.05)

	L_2127_ = upvalue_0
	L_2129_ = 8
	L_2131_ = (L_2125_ < 8)

	L_2128_ = "Safe"

	L_2128_ = "Danger"

	L_2127_.World2LavaState = L_2128_

	L_2127_ = upvalue_0
	L_2127_.World2LavaState = "Danger"
	L_2128_ = "Danger"

	L_2123_ = upvalue_0
	L_2123_.World2LavaState = "Unknown"
	L_2124_ = "Unknown"

	do
		return
	end
end

L_1_.isRouteTimerSafe = function(L_2132_arg0)
	local L_2133_, L_2134_, L_2135_, L_2136_, L_2137_, L_2138_, L_2139_, L_2140_, L_2141_, L_2142_, L_2143_, L_2144_, L_2145_, L_2146_
	L_2133_ = true
	L_2134_ = ipairs
	L_2135_ = select(1, upvalue_0:GetTagged("Timer"))
	L_2136_ = upvalue_0
	L_2137_ = "Timer"
	L_2134_, L_2135_, L_2136_ = ipairs(upvalue_0:GetTagged("Timer"))
	for L_2147_forvar0, L_2148_forvar1 in L_2134_, L_2135_, L_2136_ do
		L_2139_ = L_2148_forvar1:IsA("TextLabel")
		L_2140_ = L_2148_forvar1
		L_2141_ = "TextLabel"
		if L_2139_ then
			L_2139_ = L_2148_forvar1:FindFirstAncestorOfClass("Model")
			L_2140_ = L_2148_forvar1
			L_2141_ = "Model"
			if L_2139_ then
				L_2140_ = L_2139_.PrimaryPart
				if not (L_2140_) then
					L_2140_ = L_2139_:FindFirstChildWhichIsA("BasePart")
					L_2141_ = L_2139_
					L_2142_ = "BasePart"
				end
				if L_2140_ then
					L_2141_ = (L_2140_.Position - L_2132_arg0).Magnitude
					L_2142_ = 50
					L_2143_ = L_2140_.Position
					L_2146_ = ((L_2140_.Position - L_2132_arg0).Magnitude < 50)
					if L_2146_ then
						L_2141_ = string.gsub(L_2148_forvar1.Text, "%s+", "")
						L_2142_ = tonumber(string.gsub(L_2148_forvar1.Text, "%s+", ""))
						L_2143_ = string.gsub(L_2148_forvar1.Text, "%s+", "")
						L_2144_ = ""
						if L_2142_ then
							L_2143_ = 1.5
							L_2146_ = (1.5 < L_2142_)
							if L_2146_ then
								return false
							end
						end
					end
				end
			end
		end
	end
	return L_2133_
end

L_1_.isLocalPlayerAlive = function()
	local L_2149_, L_2150_, L_2151_, L_2152_, L_2153_, L_2154_, L_2155_
	L_2149_ = upvalue_0.Character
	L_2150_ = upvalue_0.Character
	if L_2150_ then
		L_2150_ = L_2149_:FindFirstChildOfClass("Humanoid")
		L_2151_ = L_2149_
		L_2152_ = "Humanoid"
	end
	L_2151_ = L_2150_
	if not (L_2151_) then
		return L_2151_
	end
	L_2152_ = L_2150_.Health
	L_2153_ = 0
	L_2155_ = (0 < L_2150_.Health)
	if L_2155_ then
		L_2151_ = true
	else
		L_2151_ = false
	end
	return L_2151_
end

L_1_.unanchorRootPart = function()
	local L_2156_, L_2157_, L_2158_, L_2159_
	L_2156_ = upvalue_0.Character
	L_2157_ = upvalue_0.Character
	if L_2157_ then
		L_2157_ = L_2156_:FindFirstChild("HumanoidRootPart")
		L_2158_ = L_2156_
		L_2159_ = "HumanoidRootPart"
	end
	if not (L_2157_) then
		return
	end
	L_2157_.Anchored = false
	L_2158_ = false
	return
end

L_1_.waitForRespawnThenUnanchor = function()
	local L_2160_, L_2161_, L_2162_, L_2163_, L_2164_, L_2165_, L_2166_
	repeat
		L_2160_ = upvalue_0.HubRunning
		L_2161_ = upvalue_0
		if not (L_2160_) then
			break
		end
		L_2160_ = upvalue_0.AutoWinsFarm
		L_2161_ = upvalue_0
		if not (L_2160_) then
			break
		end
		L_2161_ = upvalue_1.Character
		L_2162_ = upvalue_1.Character
		if L_2162_ then
			L_2162_ = L_2161_:FindFirstChildOfClass("Humanoid")
			L_2163_ = L_2161_
			L_2164_ = "Humanoid"
		end
		L_2160_ = L_2162_
		if L_2160_ then
			L_2163_ = L_2162_.Health
			L_2164_ = 0
			L_2166_ = (0 < L_2162_.Health)
			if L_2166_ then
				L_2160_ = true
			else
				L_2160_ = false
			end
		end
	until L_2160_
	task.wait(1)
	pcall(L_1_.unanchorRootPart)
	return
end

L_1_.tweenRootTo = function(L_2167_arg0)
	local L_2168_, L_2169_, L_2170_, L_2171_, L_2172_, L_2173_, L_2174_, L_2175_, L_2176_, L_2177_, L_2178_, L_2179_, L_2180_, L_2181_, L_2182_, L_2183_
	local L_2184_, L_2185_, L_2186_
	L_2168_ = upvalue_0.Character
	L_2169_ = upvalue_0.Character

	L_2169_ = L_2168_:FindFirstChild("HumanoidRootPart")
	L_2170_ = L_2168_
	L_2171_ = "HumanoidRootPart"

	L_2170_ = L_2168_

	L_2170_ = L_2168_:FindFirstChildOfClass("Humanoid")
	L_2171_ = L_2168_
	L_2172_ = "Humanoid"

	L_2171_ = L_2170_.Health
	L_2172_ = 0
	L_2186_ = (L_2170_.Health <= 0)

	do
		return false
	end

	L_2171_ = (L_2169_.Position - L_2167_arg0).Magnitude
	L_2172_ = _G.TempTweenSpeed
	L_2173_ = _G

	L_2172_ = _G.TweenSpeed
	L_2173_ = _G

	L_2172_ = upvalue_1.TweenSpeed
	L_2173_ = upvalue_1

	L_2172_ = 150

	L_2173_ = 10
	L_2186_ = (L_2172_ < 10)

	L_2172_ = 150

	L_2178_ = {}
	L_2178_.CFrame = CFrame.new((L_2167_arg0 + Vector3.new(0, 3, 0)))
	L_2174_ = upvalue_2:Create(L_2169_, TweenInfo.new(math.max((L_2171_ / L_2172_), 0.01), Enum.EasingStyle.Linear, Enum.EasingDirection.Out), L_2178_)
	L_2174_:Play()
	L_2173_ = math.max((L_2171_ / L_2172_), 0.01)
	L_2175_ = L_2174_.Play
	L_2176_ = L_2174_
	L_2177_ = TweenInfo.new(math.max((L_2171_ / L_2172_), 0.01), Enum.EasingStyle.Linear, Enum.EasingDirection.Out)
	L_2179_ = CFrame.new((L_2167_arg0 + Vector3.new(0, 3, 0)))
	L_2180_ = (L_2167_arg0 + Vector3.new(0, 3, 0))
	L_2181_ = Vector3.new(0, 3, 0)
	L_2182_ = 0
	L_2183_ = 3
	L_2184_ = 0

	L_2175_ = L_2174_.PlaybackState
	L_2176_ = Enum.PlaybackState.Playing
	L_2186_ = (L_2174_.PlaybackState == Enum.PlaybackState.Playing)

	L_2175_ = L_2170_.Health
	L_2176_ = 0
	L_2186_ = (L_2170_.Health <= 0)

	L_2174_:Cancel()
	do
		return false
	end

	task.wait()
	L_2175_ = task.wait

	L_2175_ = _G
	L_2175_.TempTweenSpeed = nil
	do
		return true
	end
end

L_1_.anchorRootPart = function()
	local L_2187_, L_2188_, L_2189_, L_2190_
	L_2187_ = upvalue_0.Character
	L_2188_ = upvalue_0.Character
	if L_2188_ then
		L_2188_ = L_2187_:FindFirstChild("HumanoidRootPart")
		L_2189_ = L_2187_
		L_2190_ = "HumanoidRootPart"
	end
	if not (L_2188_) then
		return
	end
	L_2188_.Anchored = true
	L_2189_ = true
	return
end

L_1_.unanchorRootPartImmediate = function()
	local L_2191_, L_2192_, L_2193_, L_2194_
	L_2191_ = upvalue_0.Character
	L_2192_ = upvalue_0.Character
	if L_2192_ then
		L_2192_ = L_2191_:FindFirstChild("HumanoidRootPart")
		L_2193_ = L_2191_
		L_2194_ = "HumanoidRootPart"
	end
	if not (L_2192_) then
		return
	end
	L_2192_.Anchored = false
	L_2193_ = false
	return
end

L_1_.autoWinsRouteWorker = function()
	local L_2195_, L_2196_, L_2197_, L_2198_, L_2199_, L_2200_, L_2201_, L_2202_, L_2203_, L_2204_, L_2205_, L_2206_, L_2207_, L_2208_, L_2209_, L_2210_
	local L_2211_, L_2212_
	L_2195_ = upvalue_0.HubRunning
	L_2196_ = upvalue_0

	task.wait(0.05)
	L_2195_ = upvalue_0.AutoWinsFarm
	L_2196_ = upvalue_0

	L_2196_ = upvalue_1.Character
	L_2197_ = upvalue_1.Character

	L_2197_ = L_2196_:FindFirstChildOfClass("Humanoid")
	L_2198_ = L_2196_
	L_2199_ = "Humanoid"

	L_2195_ = L_2197_

	L_2198_ = L_2197_.Health
	L_2199_ = 0
	L_2212_ = (0 < L_2197_.Health)

	L_2195_ = false

	L_2195_ = true

	upvalue_2()
	L_2195_ = upvalue_2

	L_2195_ = upvalue_0.SelectedWinTarget
	L_2196_ = upvalue_0.CurrentConfig[upvalue_0.SelectedWinTarget]
	L_2197_ = upvalue_0.CurrentConfig
	L_2198_ = upvalue_0

	L_2197_ = tick()
	L_2198_ = true
	L_2199_ = false
	L_2200_ = L_2196_.RouteIndex
	L_2201_ = 1
	L_2202_ = 1
	L_2203_ = upvalue_0.AutoWinsFarm
	L_2204_ = upvalue_0

	L_2203_ = upvalue_0.HubRunning
	L_2204_ = upvalue_0

	L_2198_ = false

	L_2204_ = upvalue_1.Character
	L_2205_ = upvalue_1.Character

	L_2205_ = L_2204_:FindFirstChildOfClass("Humanoid")
	L_2206_ = L_2204_
	L_2207_ = "Humanoid"

	L_2203_ = L_2205_

	L_2206_ = L_2205_.Health
	L_2207_ = 0
	L_2212_ = (0 < L_2205_.Health)

	L_2203_ = false

	L_2203_ = true

	L_2198_ = false
	L_2199_ = true

	L_2203_ = upvalue_0.CurrentRoute[L_2202_]
	L_2204_ = upvalue_0.isWorld2
	L_2205_ = upvalue_0

	L_2211_ = 16
	L_2212_ = (L_2202_ == 16)

	L_2204_ = upvalue_1.Character
	L_2205_ = upvalue_1.Character

	L_2205_ = L_2204_:FindFirstChild("HumanoidRootPart")
	L_2206_ = L_2204_
	L_2207_ = "HumanoidRootPart"

	L_2205_.Anchored = true
	L_2206_ = true

	task.wait(0.05)
	L_2206_ = upvalue_0.WallState
	L_2207_ = upvalue_0
	L_2211_ = "Opening"
	L_2212_ = (upvalue_0.WallState == "Opening")

	L_2206_ = upvalue_0.AutoWinsFarm
	L_2207_ = upvalue_0

	L_2207_ = upvalue_1.Character
	L_2208_ = upvalue_1.Character

	L_2208_ = L_2207_:FindFirstChildOfClass("Humanoid")
	L_2209_ = L_2207_
	L_2210_ = "Humanoid"

	L_2206_ = L_2208_

	L_2209_ = L_2208_.Health
	L_2210_ = 0
	L_2212_ = (0 < L_2208_.Health)

	L_2206_ = false

	L_2206_ = true

	L_2205_.Anchored = false
	L_2206_ = false

	L_2204_ = upvalue_0.isWorld2
	L_2205_ = upvalue_0

	L_2211_ = 17
	L_2212_ = (L_2202_ == 17)

	L_2204_ = upvalue_1.Character
	L_2205_ = upvalue_1.Character

	L_2205_ = L_2204_:FindFirstChild("HumanoidRootPart")
	L_2206_ = L_2204_
	L_2207_ = "HumanoidRootPart"

	L_2205_.Anchored = true
	L_2206_ = true

	task.wait(0.05)
	L_2206_ = upvalue_0.LavaState
	L_2207_ = upvalue_0
	L_2211_ = "Safe"
	L_2212_ = (upvalue_0.LavaState == "Safe")

	L_2206_ = upvalue_0.AutoWinsFarm
	L_2207_ = upvalue_0

	L_2207_ = upvalue_1.Character
	L_2208_ = upvalue_1.Character

	L_2208_ = L_2207_:FindFirstChildOfClass("Humanoid")
	L_2209_ = L_2207_
	L_2210_ = "Humanoid"

	L_2206_ = L_2208_

	L_2209_ = L_2208_.Health
	L_2210_ = 0
	L_2212_ = (0 < L_2208_.Health)

	L_2206_ = false

	L_2206_ = true

	L_2205_.Anchored = false
	L_2206_ = false

	L_2204_ = upvalue_0.isWorld2
	L_2205_ = upvalue_0

	L_2211_ = 6
	L_2212_ = (L_2202_ == 6)

	L_2204_ = upvalue_1.Character
	L_2205_ = upvalue_1.Character

	L_2205_ = L_2204_:FindFirstChild("HumanoidRootPart")
	L_2206_ = L_2204_
	L_2207_ = "HumanoidRootPart"

	L_2205_.Anchored = true
	L_2206_ = true

	task.wait(0.05)
	L_2206_ = upvalue_0.World2WallState
	L_2207_ = upvalue_0
	L_2211_ = "Open"
	L_2212_ = (upvalue_0.World2WallState == "Open")

	L_2206_ = upvalue_0.AutoWinsFarm
	L_2207_ = upvalue_0

	L_2207_ = upvalue_1.Character
	L_2208_ = upvalue_1.Character

	L_2208_ = L_2207_:FindFirstChildOfClass("Humanoid")
	L_2209_ = L_2207_
	L_2210_ = "Humanoid"

	L_2206_ = L_2208_

	L_2209_ = L_2208_.Health
	L_2210_ = 0
	L_2212_ = (0 < L_2208_.Health)

	L_2206_ = false

	L_2206_ = true

	L_2205_.Anchored = false
	L_2206_ = false

	L_2206_ = _G
	L_2206_.TempTweenSpeed = 110
	L_2207_ = 110

	L_2204_ = upvalue_0.isWorld2
	L_2205_ = upvalue_0

	L_2211_ = 7
	L_2212_ = (L_2202_ == 7)

	L_2204_ = upvalue_1.Character
	L_2205_ = upvalue_1.Character

	L_2205_ = L_2204_:FindFirstChild("HumanoidRootPart")
	L_2206_ = L_2204_
	L_2207_ = "HumanoidRootPart"

	L_2205_.Anchored = true
	L_2206_ = true

	task.wait(0.05)
	L_2206_ = upvalue_0.World2LavaState
	L_2207_ = upvalue_0
	L_2211_ = "Safe"
	L_2212_ = (upvalue_0.World2LavaState == "Safe")

	L_2206_ = upvalue_0.AutoWinsFarm
	L_2207_ = upvalue_0

	L_2207_ = upvalue_1.Character
	L_2208_ = upvalue_1.Character

	L_2208_ = L_2207_:FindFirstChildOfClass("Humanoid")
	L_2209_ = L_2207_
	L_2210_ = "Humanoid"

	L_2206_ = L_2208_

	L_2209_ = L_2208_.Health
	L_2210_ = 0
	L_2212_ = (0 < L_2208_.Health)

	L_2206_ = false

	L_2206_ = true

	L_2205_.Anchored = false
	L_2206_ = false

	L_2204_ = upvalue_3(L_2203_)
	L_2205_ = L_2203_

	pcall(L_1_.anchorRootPart)
	L_2204_ = pcall
	L_2205_ = L_1_.anchorRootPart

	task.wait(0.1)
	L_2204_ = upvalue_3(L_2203_)
	L_2205_ = L_2203_

	L_2204_ = upvalue_0.AutoWinsFarm
	L_2205_ = upvalue_0

	L_2205_ = upvalue_1.Character
	L_2206_ = upvalue_1.Character

	L_2206_ = L_2205_:FindFirstChildOfClass("Humanoid")
	L_2207_ = L_2205_
	L_2208_ = "Humanoid"

	L_2204_ = L_2206_

	L_2207_ = L_2206_.Health
	L_2208_ = 0
	L_2212_ = (0 < L_2206_.Health)

	L_2204_ = false

	L_2204_ = true

	pcall(L_1_.unanchorRootPartImmediate)
	L_2204_ = pcall
	L_2205_ = L_1_.unanchorRootPartImmediate

	L_2205_ = upvalue_1.Character
	L_2206_ = upvalue_1.Character

	L_2206_ = L_2205_:FindFirstChildOfClass("Humanoid")
	L_2207_ = L_2205_
	L_2208_ = "Humanoid"

	L_2204_ = L_2206_

	L_2207_ = L_2206_.Health
	L_2208_ = 0
	L_2212_ = (0 < L_2206_.Health)

	L_2204_ = false

	L_2204_ = true

	L_2198_ = false
	L_2199_ = true

	L_2204_ = upvalue_4(upvalue_0.CurrentRoute[L_2202_])
	L_2205_ = upvalue_0.CurrentRoute[L_2202_]
	L_2206_ = upvalue_0.CurrentRoute
	L_2207_ = upvalue_0

	L_2198_ = false

	upvalue_2()
	L_2200_ = upvalue_2

	L_2200_ = (tick() - L_2197_)
	L_2201_ = L_2196_.MinTime
	L_2212_ = ((tick() - L_2197_) < L_2196_.MinTime)

	task.wait((L_2196_.MinTime - L_2200_))
	L_2201_ = task.wait
	L_2202_ = (L_2196_.MinTime - L_2200_)
	L_2203_ = L_2196_.MinTime

	L_2201_ = workspace:FindFirstChild(L_2196_.BlockName, true)
	L_2202_ = workspace
	L_2203_ = L_2196_.BlockName
	L_2204_ = true

	L_2203_ = upvalue_1.Character
	L_2204_ = upvalue_1.Character

	L_2204_ = L_2203_:FindFirstChildOfClass("Humanoid")
	L_2205_ = L_2203_
	L_2206_ = "Humanoid"

	L_2202_ = L_2204_

	L_2205_ = L_2204_.Health
	L_2206_ = 0
	L_2212_ = (0 < L_2204_.Health)

	L_2202_ = false

	L_2202_ = true

	upvalue_4((L_2201_.Position + Vector3.new(0, 3, 0)))
	task.wait(3)
	L_2202_ = task.wait
	L_2203_ = 3
	L_2204_ = L_2201_.Position
	L_2205_ = Vector3.new(0, 3, 0)
	L_2206_ = 0
	L_2207_ = 3
	L_2208_ = 0

	task.wait(1)
	L_2202_ = task.wait
	L_2203_ = 1

	task.wait(1)
	L_2197_ = task.wait
	L_2198_ = 1

	do
		return
	end
end

L_1_.buySelectedShopItemsTick = function()
	local L_2213_, L_2214_, L_2215_, L_2216_, L_2217_, L_2218_, L_2219_, L_2220_, L_2221_, L_2222_, L_2223_, L_2224_, L_2225_, L_2226_, L_2227_, L_2228_
	L_2213_ = upvalue_0:Get()
	L_2214_ = upvalue_0
	if L_2213_ then
		L_2214_ = L_2213_.Wins
		if not (L_2214_) then
			L_2214_ = 0
		end
	else
		L_2214_ = 0
	end
	L_2215_ = pairs
	L_2216_ = upvalue_1.TargetBuyItems
	L_2218_ = upvalue_1
	L_2215_, L_2216_, L_2217_ = pairs(upvalue_1.TargetBuyItems)
	for L_2229_forvar0, L_2230_forvar1 in L_2215_, L_2216_, L_2217_ do
		L_2220_ = false
		L_2221_ = type(L_2230_forvar1)
		L_2222_ = L_2230_forvar1
		L_2227_ = "string"
		L_2228_ = (type(L_2230_forvar1) == "string")
		if L_2228_ then
			L_2220_ = false
			L_2227_ = true
			L_2228_ = (L_2230_forvar1 == true)
			if not (L_2228_) then
				L_2220_ = L_2230_forvar1
			end
		end
		if L_2220_ then
			L_2227_ = "Epic"
			L_2228_ = (L_2220_ == "Epic")
			if L_2228_ then
				L_2221_ = "Mysterious"
			else
				L_2221_ = L_2220_
			end
			L_2222_ = upvalue_2[L_2221_]
			L_2223_ = upvalue_2[L_2221_]
			L_2224_ = upvalue_2
			if not (L_2222_) then
				L_2222_ = 0
			end
			L_2228_ = (L_2222_ <= L_2214_)
			if L_2228_ then
				upvalue_3:FireServer("BuyWins", L_2221_)
				task.wait(0.1)
				L_2223_ = task.wait
				L_2224_ = 0.1
				L_2225_ = "BuyWins"
				L_2226_ = L_2221_
			end
		end
	end
	return
end

L_1_.autoBuyItemsWorker = function()
	local L_2231_, L_2232_, L_2233_, L_2234_, L_2235_, L_2236_
	L_2231_ = upvalue_0:WaitForChild("Remotes", 10)
	L_2231_ = L_2231_:WaitForChild("ItemsShopAction", 10)
	L_2232_ = require(upvalue_0:WaitForChild("ClientState", 10))
	L_2233_ = select(1, upvalue_0:WaitForChild("ClientState", 10))
	L_2234_ = upvalue_0
	L_2235_ = "ClientState"
	L_2236_ = 10

	L_2233_ = upvalue_1.HubRunning
	L_2234_ = upvalue_1

	task.wait(1.5)
	L_2233_ = upvalue_1.AutoBuyItems
	L_2234_ = upvalue_1

	L_2233_ = upvalue_1.TargetBuyItems
	L_2234_ = upvalue_1

	pcall(L_1_.buySelectedShopItemsTick)
	L_2233_ = pcall
	L_2234_ = L_1_.buySelectedShopItemsTick

	do
		return
	end
end

L_1_.equipBestItemsTick = function()
	local L_2237_, L_2238_, L_2239_
	upvalue_0:FireServer("EquipBest")
	upvalue_0:FireServer("EquipBestItems")
	return
end

L_1_.autoEquipBestWorker = function()
	local L_2240_, L_2241_, L_2242_, L_2243_
	L_2240_ = upvalue_0:WaitForChild("Remotes", 10)
	L_2240_ = L_2240_:FindFirstChild("ItemAction")
	L_2241_ = L_2240_
	L_2242_ = "ItemAction"
	L_2243_ = 10

	L_2241_ = upvalue_1.HubRunning
	L_2242_ = upvalue_1

	task.wait(2)
	L_2241_ = upvalue_1.AutoEquipBest
	L_2242_ = upvalue_1

	pcall(L_1_.equipBestItemsTick)
	L_2241_ = pcall
	L_2242_ = L_1_.equipBestItemsTick

	do
		return
	end
end

L_1_.rebirthTick = function()
	local L_2244_, L_2245_
	upvalue_0:FireServer()
	return
end

L_1_.autoRebirthWorker = function()
	local L_2246_, L_2247_, L_2248_, L_2249_
	L_2246_ = upvalue_0:WaitForChild("Remotes")
	L_2246_ = L_2246_:WaitForChild("Rebirth", 5)
	L_2247_ = L_2246_
	L_2248_ = "Rebirth"
	L_2249_ = 5

	L_2247_ = upvalue_1.HubRunning
	L_2248_ = upvalue_1

	task.wait(0.5)
	L_2247_ = upvalue_1.AutoRebirth
	L_2248_ = upvalue_1

	pcall(L_1_.rebirthTick)
	L_2247_ = pcall
	L_2248_ = L_1_.rebirthTick

	do
		return
	end
end

L_1_.updateCFrameMovement = function(L_2250_arg0)
	local L_2251_, L_2252_, L_2253_, L_2254_, L_2255_, L_2256_, L_2257_, L_2258_, L_2259_, L_2260_, L_2261_, L_2262_, L_2263_, L_2264_
	L_2251_ = upvalue_0.CFrameSpeed
	L_2252_ = upvalue_0
	if L_2251_ then
		L_2251_ = upvalue_1.Character
		L_2252_ = upvalue_1
		if L_2251_ then
			L_2251_ = upvalue_1.Character:FindFirstChild("HumanoidRootPart")
			L_2252_ = upvalue_1.Character
			L_2253_ = "HumanoidRootPart"
			if L_2251_ then
				L_2251_ = upvalue_1.Character:FindFirstChild("Humanoid")
				L_2252_ = upvalue_1.Character
				L_2253_ = "Humanoid"
				if L_2251_ then
					L_2251_ = upvalue_1.Character.Humanoid
					L_2252_ = upvalue_1.Character.HumanoidRootPart
					L_2253_ = upvalue_1.Character.Humanoid.MoveDirection.Magnitude
					L_2254_ = 0
					L_2264_ = (0 < upvalue_1.Character.Humanoid.MoveDirection.Magnitude)
					if L_2264_ then
						L_2253_ = upvalue_0.CFrameFly
						L_2254_ = upvalue_0
						if not (L_2253_) then
							L_2252_.CFrame = (L_2252_.CFrame + ((L_2251_.MoveDirection * (upvalue_0.TargetWalkSpeed - 16)) * L_2250_arg0))
							L_2253_ = (L_2252_.CFrame + ((L_2251_.MoveDirection * (upvalue_0.TargetWalkSpeed - 16)) * L_2250_arg0))
							L_2254_ = L_2252_.CFrame
							L_2255_ = ((L_2251_.MoveDirection * (upvalue_0.TargetWalkSpeed - 16)) * L_2250_arg0)
							L_2256_ = (L_2251_.MoveDirection * (upvalue_0.TargetWalkSpeed - 16))
							L_2257_ = L_2251_.MoveDirection
							L_2258_ = (upvalue_0.TargetWalkSpeed - 16)
							L_2259_ = upvalue_0.TargetWalkSpeed
							L_2260_ = upvalue_0
						end
					end
				end
			end
		end
	end
	L_2251_ = upvalue_0.CFrameFly
	L_2252_ = upvalue_0
	if not (L_2251_) then
		return
	end
	L_2251_ = upvalue_1.Character
	L_2252_ = upvalue_1
	if not (L_2251_) then
		return
	end
	L_2251_ = upvalue_1.Character:FindFirstChild("HumanoidRootPart")
	L_2252_ = upvalue_1.Character
	L_2253_ = "HumanoidRootPart"
	if not (L_2251_) then
		return
	end
	L_2251_ = upvalue_1.Character:FindFirstChild("Humanoid")
	L_2252_ = upvalue_1.Character
	L_2253_ = "Humanoid"
	if not (L_2251_) then
		return
	end
	L_2251_ = upvalue_1.Character.Humanoid
	L_2252_ = upvalue_1.Character.HumanoidRootPart
	L_2253_ = workspace.CurrentCamera
	L_2254_ = upvalue_1
	if not (L_2253_) then
		return
	end
	L_2255_ = game:GetService("UserInputService")
	L_2254_ = Vector3.zero
	L_2256_ = L_2255_:IsKeyDown(Enum.KeyCode.W)
	L_2257_ = L_2255_
	L_2258_ = Enum.KeyCode.W
	if L_2256_ then
		L_2254_ = (L_2254_ + L_2253_.CFrame.LookVector)
		L_2256_ = L_2253_.CFrame.LookVector
		L_2257_ = L_2253_.CFrame
	end
	L_2256_ = L_2255_:IsKeyDown(Enum.KeyCode.S)
	L_2257_ = L_2255_
	L_2258_ = Enum.KeyCode.S
	if L_2256_ then
		L_2254_ = (L_2254_ - L_2253_.CFrame.LookVector)
		L_2256_ = L_2253_.CFrame.LookVector
		L_2257_ = L_2253_.CFrame
	end
	L_2256_ = L_2255_:IsKeyDown(Enum.KeyCode.A)
	L_2257_ = L_2255_
	L_2258_ = Enum.KeyCode.A
	if L_2256_ then
		L_2254_ = (L_2254_ - L_2253_.CFrame.RightVector)
		L_2256_ = L_2253_.CFrame.RightVector
		L_2257_ = L_2253_.CFrame
	end
	L_2256_ = L_2255_:IsKeyDown(Enum.KeyCode.D)
	L_2257_ = L_2255_
	L_2258_ = Enum.KeyCode.D
	if L_2256_ then
		L_2254_ = (L_2254_ + L_2253_.CFrame.RightVector)
		L_2256_ = L_2253_.CFrame.RightVector
		L_2257_ = L_2253_.CFrame
	end
	L_2256_ = L_2255_:IsKeyDown(Enum.KeyCode.Space)
	L_2257_ = L_2255_
	L_2258_ = Enum.KeyCode.Space
	if L_2256_ then
		L_2254_ = (L_2254_ + Vector3.new(0, 1, 0))
		L_2256_ = Vector3.new(0, 1, 0)
		L_2257_ = 0
		L_2258_ = 1
		L_2259_ = 0
	end
	L_2256_ = L_2255_:IsKeyDown(Enum.KeyCode.LeftShift)
	L_2257_ = L_2255_
	L_2258_ = Enum.KeyCode.LeftShift
	if L_2256_ then
		L_2254_ = (L_2254_ - Vector3.new(0, 1, 0))
		L_2256_ = Vector3.new(0, 1, 0)
		L_2257_ = 0
		L_2258_ = 1
		L_2259_ = 0
	end
	L_2256_ = L_2254_.Magnitude
	L_2257_ = 0
	L_2264_ = (0 < L_2254_.Magnitude)
	if L_2264_ then
		L_2252_.CFrame = (L_2252_.CFrame + ((L_2254_.Unit * upvalue_0.TargetFlySpeed) * L_2250_arg0))
		L_2256_ = (L_2252_.CFrame + ((L_2254_.Unit * upvalue_0.TargetFlySpeed) * L_2250_arg0))
		L_2257_ = L_2252_.CFrame
		L_2258_ = ((L_2254_.Unit * upvalue_0.TargetFlySpeed) * L_2250_arg0)
		L_2259_ = (L_2254_.Unit * upvalue_0.TargetFlySpeed)
		L_2260_ = L_2254_.Unit
		L_2261_ = upvalue_0.TargetFlySpeed
		L_2262_ = upvalue_0
	end
	L_2256_ = L_2252_:FindFirstChild("IY_Fly_BV")
	L_2257_ = L_2252_
	L_2258_ = "IY_Fly_BV"
	if not (L_2256_) then
		return
	end
	L_2256_.Velocity = Vector3.zero
	L_2257_ = Vector3.zero
	return
end

L_1_.setupSpeedKeyboardEscape = function()
	local L_2265_, L_2266_, L_2267_, L_2268_, L_2269_, L_2270_, L_2271_, L_2272_, L_2273_, L_2274_, L_2275_, L_2276_, L_2277_, L_2278_, L_2279_, L_2280_
	local L_2281_, L_2282_, L_2283_, L_2284_, L_2285_, L_2286_, L_2287_, L_2288_, L_2289_, L_2290_, L_2291_, L_2292_, L_2293_, L_2294_, L_2295_, L_2296_
	local L_2297_, L_2298_, L_2299_, L_2300_, L_2301_, L_2302_, L_2303_, L_2304_, L_2305_, L_2306_, L_2307_, L_2308_, L_2309_, L_2310_, L_2311_, L_2312_
	local L_2313_, L_2314_
	L_2265_ = upvalue_0("Speed Keyboard Escape", "Speed Keyboard")
	L_2266_ = L_2265_:NewSection("Farming Station")
	L_2267_ = L_2265_:NewSection("Treadmill Settings")
	L_2268_ = L_2265_:NewSection("Aura Station")
	L_2269_ = L_2265_:NewSection("Shop Station")
	L_2270_ = L_2265_:NewSection("Movement")
	L_2271_ = L_2265_:NewSection("Utilities")
	L_2272_ = game:GetService("ReplicatedStorage")
	L_2273_ = game:GetService("Players")
	L_2274_ = game:GetService("Players").LocalPlayer
	L_2275_ = "Players"
	if not (L_2274_) then
		L_2274_ = L_2273_.PlayerAdded:Wait()
		L_2275_ = L_2273_.PlayerAdded
	end
	L_2275_ = game:GetService("TweenService")
	L_2276_ = game:GetService("RunService")
	L_2277_ = game:GetService("CollectionService")
	L_2278_ = getgenv()
	L_2279_ = getgenv().LuxyHub_State
	L_2280_ = getgenv()
	if not (L_2279_) then
		L_2279_ = {}
	end
	L_2278_.LuxyHub_State = L_2279_
	L_2278_ = getgenv().LuxyHub_State
	L_2278_.HubRunning = true
	L_2279_ = L_2278_.AutoStepFarm
	L_2280_ = L_2278_.AutoStepFarm
	if not (L_2279_) then
		L_2279_ = false
	end
	L_2278_.AutoStepFarm = L_2279_
	L_2279_ = L_2278_.AutoWinsFarm
	L_2280_ = L_2278_.AutoWinsFarm
	if not (L_2279_) then
		L_2279_ = false
	end
	L_2278_.AutoWinsFarm = L_2279_
	L_2279_ = L_2278_.SelectedWinTarget
	L_2280_ = L_2278_.SelectedWinTarget
	if not (L_2279_) then
		L_2279_ = "Win 500"
	end
	L_2278_.SelectedWinTarget = L_2279_
	L_2279_ = L_2278_.TargetTreadmill
	L_2280_ = L_2278_.TargetTreadmill
	if not (L_2279_) then
		L_2279_ = "Diamond"
	end
	L_2278_.TargetTreadmill = L_2279_
	L_2279_ = L_2278_.FreezePosition
	L_2280_ = L_2278_.FreezePosition
	if not (L_2279_) then
		L_2279_ = false
	end
	L_2278_.FreezePosition = L_2279_
	L_2279_ = L_2278_.AutoRebirth
	L_2280_ = L_2278_.AutoRebirth
	if not (L_2279_) then
		L_2279_ = false
	end
	L_2278_.AutoRebirth = L_2279_
	L_2279_ = L_2278_.TweenSpeed
	L_2280_ = L_2278_.TweenSpeed
	if not (L_2279_) then
		L_2279_ = 150
	end
	L_2278_.TweenSpeed = L_2279_
	L_2278_.WallState = "Unknown"
	L_2278_.WallDistance = 100
	L_2278_.LavaState = "Unknown"
	L_2278_.LavaDistance = 100
	L_2279_ = L_2278_.AutoBuyItems
	L_2280_ = L_2278_.AutoBuyItems
	if not (L_2279_) then
		L_2279_ = false
	end
	L_2278_.AutoBuyItems = L_2279_
	L_2279_ = L_2278_.TargetBuyItems
	if not (L_2279_) then
		L_2279_ = {}
		L_2279_[1] = "Common"
		L_2280_ = "Common"
	end
	L_2278_.TargetBuyItems = L_2279_
	L_2279_ = L_2278_.AutoEquipBest
	L_2280_ = L_2278_.AutoEquipBest
	if not (L_2279_) then
		L_2279_ = false
	end
	L_2278_.AutoEquipBest = L_2279_
	L_2278_.SelectedEquipType = "Best Items"
	L_2279_ = L_2278_.SelectedAura
	L_2280_ = L_2278_.SelectedAura
	if not (L_2279_) then
		L_2279_ = "GlowAura"
	end
	L_2278_.SelectedAura = L_2279_
	L_2279_ = L_2278_.CFrameSpeed
	L_2280_ = L_2278_.CFrameSpeed
	if not (L_2279_) then
		L_2279_ = false
	end
	L_2278_.CFrameSpeed = L_2279_
	L_2279_ = L_2278_.TargetWalkSpeed
	L_2280_ = L_2278_.TargetWalkSpeed
	if not (L_2279_) then
		L_2279_ = 16
	end
	L_2278_.TargetWalkSpeed = L_2279_
	L_2279_ = L_2278_.CFrameFly
	L_2280_ = L_2278_.CFrameFly
	if not (L_2279_) then
		L_2279_ = false
	end
	L_2278_.CFrameFly = L_2279_
	L_2279_ = L_2278_.TargetFlySpeed
	L_2280_ = L_2278_.TargetFlySpeed
	if not (L_2279_) then
		L_2279_ = 50
	end
	L_2278_.TargetFlySpeed = L_2279_
	L_2278_.BypassFunction = L_1_.BypassFunction
	L_2278_.UnlockInfinityTrail = L_1_.UnlockInfinityTrail
	L_2278_.UnlockAuraBypass = L_1_.UnlockAuraBypass
	L_2266_:NewToggle("Auto Run (Step Farm)", "Normal run training anywhere (Purple Pop-up)", L_1_.setAutoStepFarm)
	L_2279_ = {}
	L_2279_[1] = "Win 1"
	L_2279_[2] = "Win 3"
	L_2279_[3] = "Win 10"
	L_2279_[4] = "Win 20"
	L_2279_[5] = "Win 50"
	L_2279_[6] = "Win 100"
	L_2279_[7] = "Win 150"
	L_2279_[8] = "Win 300"
	L_2279_[9] = "Win 500"
	L_2279_[10] = "Win 1000"
	L_2279_[11] = "Win 2500"
	L_2280_ = {}
	L_2280_[1] = "Win 250k"
	L_2280_[2] = "Win 400k"
	L_2280_[3] = "Win 600k"
	L_2280_[4] = "Win 1M"
	L_2280_[5] = "Win 1.5M"
	L_2280_[6] = "Win 2.5M"
	L_2281_ = "Win 250k"
	L_2282_ = workspace:FindFirstChild("WORLD 2")
	L_2283_ = workspace
	L_2284_ = "WORLD 2"
	L_2285_ = "Win 1.5M"
	L_2286_ = "Win 2.5M"
	L_2287_ = "Win 300"
	L_2288_ = "Win 500"
	L_2289_ = "Win 1000"
	L_2290_ = "Win 2500"
	L_2313_ = nil
	L_2314_ = (workspace:FindFirstChild("WORLD 2") == nil)
	if L_2314_ then
		L_2281_ = false
	else
		L_2281_ = true
	end
	if L_2281_ then
		L_2282_ = L_2278_.SelectedWinTarget
		L_2283_ = L_2278_.SelectedWinTarget
		if not (L_2282_) then
			L_2282_ = "Win 250k"
		end
		L_2278_.SelectedWinTarget = L_2282_
	else
		L_2282_ = L_2278_.SelectedWinTarget
		L_2283_ = L_2278_.SelectedWinTarget
		if not (L_2282_) then
			L_2282_ = "Win 500"
		end
		L_2278_.SelectedWinTarget = L_2282_
	end
	L_2266_:NewDropdown("Select Win Target World 1", "Select world 1 win target block", L_2279_, L_1_.setWorld1WinTarget)
	L_2266_:NewDropdown("Select Win Target World 2", "Select world 2 win target block", L_2280_, L_1_.setWorld2WinTarget)
	L_2266_:NewPremiumToggle("Auto Farm Wins (Smart Tween)", "Farms wins automatically based on selected target", L_1_.setAutoWinsFarm)
	L_2282_ = _G
	L_2283_ = L_2278_.TweenSpeed
	L_2284_ = L_2278_.TweenSpeed
	L_2285_ = "Farms wins automatically based on selected target"
	L_2286_ = L_1_.setAutoWinsFarm
	L_2287_ = L_1_.setWorld2WinTarget
	if not (L_2283_) then
		L_2283_ = 150
	end
	L_2282_.TweenSpeed = L_2283_
	L_2266_:NewSlider("Tween Speed", "Speed of the auto wins teleport tween", 230, 50, L_1_.setTweenSpeed)
	L_2266_:NewPremiumToggle("Auto Rebirth", "Auto purchase rebirth when conditions met", L_1_.setAutoRebirth)
	L_2266_:NewToggle("Freeze Position", "Freeze character in place (Useful when on Treadmill)", L_1_.setFreezePosition)
	L_2286_ = {}
	L_2286_[1] = "Normal"
	L_2286_[2] = "Gold"
	L_2286_[3] = "Diamond"
	L_2286_[4] = "Candy"
	L_2286_[5] = "Admin"
	L_2267_:NewDropdown("Select Treadmill Type", "Select treadmill target type", L_2286_, L_1_.setTargetTreadmill)
	L_2267_:NewPremiumButton("Bypass Treadmill Access (Unlock)", "Unlocks access to premium treadmills", L_1_.runTreadmillBypass)
	L_2267_:NewPremiumButton("Unlock Infinity Trail", "Unlocks infinity trail boost", L_1_.runInfinityTrailUnlock)
	L_2286_ = {}
	L_2286_[1] = "GlowAura"
	L_2286_[2] = "Wind Aura"
	L_2286_[3] = "Water Aura"
	L_2286_[4] = "Fire Aura"
	L_2286_[5] = "Medal Aura"
	L_2268_:NewDropdown("Select Aura", "Select target aura", L_2286_, L_1_.setSelectedAura)
	L_2268_:NewButton("Buy Aura", "Purchase selected aura using wins", L_1_.buySelectedAura)
	L_2268_:NewButton("Equip Aura", "Fire equip remote for selected aura", L_1_.equipSelectedAura)
	L_2268_:NewToggle("Auto Equip Best Items", "Automatically equips your best items in inventory", L_1_.setAutoEquipBest)
	L_2286_ = {}
	L_2286_[1] = "Common"
	L_2286_[2] = "Uncommon"
	L_2286_[3] = "Rare"
	L_2286_[4] = "Epic"
	L_2269_:NewDropdown("Select Target Items", "Buy selected item tier (Common/Uncommon/Rare/Epic)", L_2286_, L_1_.setTargetBuyItem)
	L_2269_:NewToggle("Auto Buy Items", "Automatically buy selected items when restocked", L_1_.setAutoBuyItems)
	L_2271_:NewToggle("Anti AFK", "Completely bypasses standard Roblox idle kicks", L_1_.configureAntiAfk)
	L_2270_:NewToggle("Enable CFrame Speed", "Bypasses walkspeed anti-cheat checks", L_1_.setCFrameSpeed)
	L_2270_:NewSlider("WalkSpeed Value", "Target WalkSpeed using CFrame teleportation", 250, 16, L_1_.setTargetWalkSpeed)
	L_2270_:NewToggle("Enable CFrame Fly", "Fly around the map using CFrame adjustments", L_1_.setCFrameFly)
	L_2270_:NewSlider("Fly Speed Value", "Adjust speed of the fly bypass", 250, 16, L_1_.setTargetFlySpeed)
	task.spawn(L_1_.lifecycleWorkerA)
	task.spawn(L_1_.lifecycleWorkerB)
	L_2282_ = {}
	L_2282_[1] = Vector3.new(4, 7, 1)
	L_2282_[2] = Vector3.new(5, 6, 286)
	L_2282_[3] = Vector3.new(67, 6, 423)
	L_2282_[4] = Vector3.new(4, 6, 505)
	L_2282_[5] = Vector3.new(20, 6, 560)
	L_2282_[6] = Vector3.new(19, 74, 749)
	L_2282_[7] = Vector3.new(6, 74, 775)
	L_2282_[8] = Vector3.new(5, 75, 936)
	L_2282_[9] = Vector3.new(104, 75, 939)
	L_2282_[10] = Vector3.new(102, 75, 1009)
	L_2282_[11] = Vector3.new(7, 74, 1004)
	L_2282_[12] = Vector3.new(4, 75, 1109)
	L_2282_[13] = Vector3.new(4, 75, 1411)
	L_2282_[14] = Vector3.new(-38, 53, 1475)
	L_2282_[15] = Vector3.new(-534, 51, 1469)
	L_2282_[16] = Vector3.new(-1008, 52, 1466)
	L_2282_[17] = Vector3.new(-1088, 51, 1466)
	L_2282_[18] = Vector3.new(-1088, 51, 1466)
	L_2282_[19] = Vector3.new(-1090, 293, 1466)
	L_2282_[20] = Vector3.new(-1124, 293, 1466)
	L_2282_[21] = Vector3.new(-1215, 294, 1467)
	L_2282_[22] = Vector3.new(-1248, 302, 1467)
	L_2282_[23] = Vector3.new(-1339, 279, 1468)
	L_2282_[24] = Vector3.new(-1371, 280, 1469)
	L_2282_[25] = Vector3.new(-1424, 333, 1467)
	L_2282_[26] = Vector3.new(-1511, 334, 1466)
	L_2282_[27] = Vector3.new(-1559, 318, 1469)
	L_2282_[28] = Vector3.new(-1632, 318, 1467)
	L_2282_[29] = Vector3.new(-1742, 288, 1464)
	L_2282_[30] = Vector3.new(-1776, 288, 1466)
	L_2282_[31] = Vector3.new(-1827, 301, 1467)
	L_2282_[32] = Vector3.new(-1867, 315, 1466)
	L_2282_[33] = Vector3.new(-1936, 305, 1466)
	L_2282_[34] = Vector3.new(-2115, 303, 1471)
	L_2282_[35] = Vector3.new(-2185, 324, 1471)
	L_2282_[36] = Vector3.new(-2241, 312, 1467)
	L_2282_[37] = Vector3.new(-2312, 312, 1470)
	L_2282_[38] = Vector3.new(-2347, 324, 1474)
	L_2282_[39] = Vector3.new(-2410, 321, 1473)
	L_2282_[40] = Vector3.new(-2530, 320, 1472)
	L_2282_[41] = Vector3.new(-2591, 292, 1490)
	L_2282_[42] = Vector3.new(-2740, 292, 1483)
	L_2282_[43] = Vector3.new(-2793, 307, 1478)
	L_2282_[44] = Vector3.new(-2852, 282, 1473)
	L_2282_[45] = Vector3.new(-2887, 281, 1472)
	L_2282_[46] = Vector3.new(-2938, 295, 1468)
	L_2282_[47] = Vector3.new(-2970, 294, 1466)
	L_2282_[48] = Vector3.new(-3028, 294, 1465)
	L_2282_[49] = Vector3.new(-3075, 294, 1566)
	L_2282_[50] = Vector3.new(-3163, 294, 1613)
	L_2282_[51] = Vector3.new(-3433, 294, 1595)
	L_2282_[52] = Vector3.new(-3612, 294, 1467)
	L_2282_[53] = Vector3.new(-3949, 293, 1469)
	L_2282_[54] = Vector3.new(-4097, 294, 1466)
	L_2282_[55] = Vector3.new(-4195, 293, 1465)
	L_2282_[56] = Vector3.new(-4286, 292, 1465)
	L_2282_[57] = Vector3.new(-4302, 294, 1466)
	L_2282_[58] = Vector3.new(-4305, 340, 1466)
	L_2282_[59] = Vector3.new(-4316, 340, 1443)
	L_2282_[60] = Vector3.new(-4315, 341, 1340)
	L_2282_[61] = Vector3.new(-4314, 349, 1309)
	L_2282_[62] = Vector3.new(-4306, 348, 1302)
	L_2282_[63] = Vector3.new(-4304, 367, 1302)
	L_2282_[64] = Vector3.new(-4192, 367, 1301)
	L_2282_[65] = Vector3.new(-4061, 367, 1301)
	L_2282_[66] = Vector3.new(-4044, 367, 1303)
	L_2282_[67] = Vector3.new(-4023, 372, 1304)
	L_2282_[68] = Vector3.new(-4017, 389, 1304)
	L_2282_[69] = Vector3.new(-4012, 389, 1327)
	L_2282_[70] = Vector3.new(-4009, 389, 1425)
	L_2282_[71] = Vector3.new(-4009, 389, 1569)
	L_2282_[72] = Vector3.new(-4013, 391, 1607)
	L_2282_[73] = Vector3.new(-4125, 390, 1610)
	L_2282_[74] = Vector3.new(-4300, 390, 1610)
	L_2282_[75] = Vector3.new(-4351, 397, 1611)
	L_2282_[76] = Vector3.new(-4351, 397, 1594)
	L_2282_[77] = Vector3.new(-4350, 405, 1567)
	L_2282_[78] = Vector3.new(-4349, 403, 1460)
	L_2282_[79] = Vector3.new(-4349, 432, 1409)
	L_2282_[80] = Vector3.new(-4348, 432, 1391)
	L_2282_[81] = Vector3.new(-4251, 430, 1392)
	L_2282_[82] = Vector3.new(-4212, 441, 1394)
	L_2282_[83] = Vector3.new(-4126, 439, 1384)
	L_2282_[84] = Vector3.new(-4098, 451, 1411)
	L_2282_[85] = Vector3.new(-4062, 444, 1463)
	L_2282_[86] = Vector3.new(-4057, 456, 1500)
	L_2282_[87] = Vector3.new(-4082, 444, 1557)
	L_2282_[88] = Vector3.new(-4160, 444, 1571)
	L_2282_[89] = Vector3.new(-4255, 454, 1543)
	L_2282_[90] = Vector3.new(-4318, 472, 1540)
	L_2282_[91] = Vector3.new(-4330, 468, 1536)
	L_2282_[92] = Vector3.new(-4371, 468, 1532)
	L_2284_ = {}
	L_2284_.RouteIndex = 2
	L_2284_.BlockName = "WinBlock"
	L_2284_.MinTime = 0
	L_2283_ = {}
	L_2283_["Win 1"] = L_2284_
	L_2284_ = {}
	L_2284_.RouteIndex = 4
	L_2284_.BlockName = "WinBlock2"
	L_2284_.MinTime = 0
	L_2283_["Win 3"] = L_2284_
	L_2284_ = {}
	L_2284_.RouteIndex = 7
	L_2284_.BlockName = "WinBlock3"
	L_2284_.MinTime = 0
	L_2283_["Win 10"] = L_2284_
	L_2284_ = {}
	L_2284_.RouteIndex = 12
	L_2284_.BlockName = "WinBlock4"
	L_2284_.MinTime = 0
	L_2283_["Win 20"] = L_2284_
	L_2284_ = {}
	L_2284_.RouteIndex = 13
	L_2284_.BlockName = "WinBlock5"
	L_2284_.MinTime = 0
	L_2283_["Win 50"] = L_2284_
	L_2284_ = {}
	L_2284_.RouteIndex = 15
	L_2284_.BlockName = "WinBlock6"
	L_2284_.MinTime = 8
	L_2283_["Win 100"] = L_2284_
	L_2284_ = {}
	L_2284_.RouteIndex = 16
	L_2284_.BlockName = "WinBlock7"
	L_2284_.MinTime = 10
	L_2283_["Win 150"] = L_2284_
	L_2284_ = {}
	L_2284_.RouteIndex = 19
	L_2284_.BlockName = "WinBlock8"
	L_2284_.MinTime = 12
	L_2283_["Win 300"] = L_2284_
	L_2284_ = {}
	L_2284_.RouteIndex = 46
	L_2284_.BlockName = "WinBlock9"
	L_2284_.MinTime = 25
	L_2283_["Win 500"] = L_2284_
	L_2284_ = {}
	L_2284_.RouteIndex = 52
	L_2284_.BlockName = "WinBlock10"
	L_2284_.MinTime = 30
	L_2283_["Win 1000"] = L_2284_
	L_2284_ = {}
	L_2284_.RouteIndex = 91
	L_2284_.BlockName = "WinBlock11"
	L_2284_.MinTime = 45
	L_2283_["Win 2500"] = L_2284_
	L_2284_ = {}
	L_2284_[1] = Vector3.new(-401, 503, -171)
	L_2284_[2] = Vector3.new(-394, 503, 4)
	L_2284_[3] = Vector3.new(-399, 503, 53)
	L_2284_[4] = Vector3.new(-400, 501, 131)
	L_2284_[5] = Vector3.new(-397, 498, 194)
	L_2284_[6] = Vector3.new(-397, 498, 437)
	L_2284_[7] = Vector3.new(-375, 495, 464)
	L_2284_[8] = Vector3.new(-349, 497, 481)
	L_2284_[9] = Vector3.new(-345, 524, 568)
	L_2284_[10] = Vector3.new(-425, 524, 572)
	L_2284_[11] = Vector3.new(-462, 551, 475)
	L_2284_[12] = Vector3.new(-373, 551, 473)
	L_2284_[13] = Vector3.new(-349, 561, 515)
	L_2284_[14] = Vector3.new(-350, 581, 573)
	L_2284_[15] = Vector3.new(-446, 578, 572)
	L_2284_[16] = Vector3.new(-447, 607, 465)
	L_2284_[17] = Vector3.new(-400, 604, 470)
	L_2284_[18] = Vector3.new(-399, 605, 612)
	L_2284_[19] = Vector3.new(-401, 606, 670)
	L_2284_[20] = Vector3.new(-422, 606, 709)
	L_2284_[21] = Vector3.new(-421, 605, 742)
	L_2284_[22] = Vector3.new(-402, 606, 789)
	L_2284_[23] = Vector3.new(-402, 605, 842)
	L_2284_[24] = Vector3.new(-350, 612, 926)
	L_2284_[25] = Vector3.new(-320, 603, 1120)
	L_2284_[26] = Vector3.new(-390, 612, 1233)
	L_2284_[27] = Vector3.new(-401, 605, 1263)
	L_2284_[28] = Vector3.new(-405, 607, 1298)
	L_2284_[29] = Vector3.new(-403, 616, 1330)
	L_2284_[30] = Vector3.new(-400, 605, 1429)
	L_2284_[31] = Vector3.new(-388, 607, 1479)
	L_2284_[32] = Vector3.new(-360, 628, 1546)
	L_2284_[33] = Vector3.new(-360, 625, 1604)
	L_2284_[34] = Vector3.new(-360, 603, 1700)
	L_2284_[35] = Vector3.new(-362, 605, 1762)
	L_2284_[36] = Vector3.new(-363, 614, 1797)
	L_2284_[37] = Vector3.new(-393, 606, 1860)
	L_2284_[38] = Vector3.new(-397, 607, 1925)
	L_2284_[39] = Vector3.new(-398, 616, 1964)
	L_2284_[40] = Vector3.new(-402, 606, 2038)
	L_2284_[41] = Vector3.new(-403, 606, 2100)
	L_2284_[42] = Vector3.new(-404, 616, 2138)
	L_2284_[43] = Vector3.new(-403, 606, 2217)
	L_2284_[44] = Vector3.new(-403, 607, 2282)
	L_2284_[45] = Vector3.new(-404, 617, 2315)
	L_2284_[46] = Vector3.new(-405, 620, 2371)
	L_2284_[47] = Vector3.new(-403, 620, 2416)
	L_2286_ = {}
	L_2286_.RouteIndex = 5
	L_2286_.BlockName = "WinBlock16"
	L_2286_.MinTime = 0
	L_2285_ = {}
	L_2285_["Win 250k"] = L_2286_
	L_2286_ = {}
	L_2286_.RouteIndex = 6
	L_2286_.BlockName = "WinBlock17"
	L_2286_.MinTime = 0
	L_2285_["Win 400k"] = L_2286_
	L_2286_ = {}
	L_2286_.RouteIndex = 18
	L_2286_.BlockName = "WinBlock18"
	L_2286_.MinTime = 12
	L_2285_["Win 600k"] = L_2286_
	L_2286_ = {}
	L_2286_.RouteIndex = 23
	L_2286_.BlockName = "WinBlock19"
	L_2286_.MinTime = 15
	L_2285_["Win 1M"] = L_2286_
	L_2286_ = {}
	L_2286_.RouteIndex = 27
	L_2286_.BlockName = "WinBlock20"
	L_2286_.MinTime = 20
	L_2285_["Win 1.5M"] = L_2286_
	L_2286_ = {}
	L_2286_.RouteIndex = 47
	L_2286_.BlockName = "WinBlock21"
	L_2286_.MinTime = 30
	L_2285_["Win 2.5M"] = L_2286_
	L_2287_ = workspace:FindFirstChild("WORLD 2")
	L_2288_ = workspace
	L_2289_ = "WORLD 2"
	L_2290_ = Vector3.new(-397, 607, 1925)
	L_2291_ = Vector3.new(-398, 616, 1964)
	L_2292_ = Vector3.new(-402, 606, 2038)
	L_2293_ = Vector3.new(-403, 606, 2100)
	L_2294_ = Vector3.new(-404, 616, 2138)
	L_2295_ = Vector3.new(-403, 606, 2217)
	L_2296_ = Vector3.new(-403, 607, 2282)
	L_2297_ = Vector3.new(-404, 617, 2315)
	L_2298_ = Vector3.new(-405, 620, 2371)
	L_2299_ = select(1, Vector3.new(-403, 620, 2416))
	L_2300_ = -403
	L_2301_ = 620
	L_2302_ = 2416
	L_2303_ = 1546
	L_2313_ = nil
	L_2314_ = (workspace:FindFirstChild("WORLD 2") == nil)
	if L_2314_ then
		L_2286_ = false
	else
		L_2286_ = true
	end
	L_2278_.isWorld2 = L_2286_
	L_2287_ = L_2278_.isWorld2
	if L_2287_ then
		L_2286_ = L_2284_
		if not (L_2286_) then
			L_2286_ = L_2282_
		end
	else
		L_2286_ = L_2282_
	end
	L_2278_.CurrentRoute = L_2286_
	L_2287_ = L_2278_.isWorld2
	if L_2287_ then
		L_2286_ = L_2285_
		if L_2286_ then
			L_2278_.CurrentConfig = L_2286_
			L_2286_ = L_2272_:WaitForChild("Remotes", 10)
			task.spawn(L_1_.autoStepFarmWorker)
			task.spawn(L_1_.world1HazardStateWorker)
			L_2278_.World2WallState = "Unknown"
			L_2278_.World2LavaState = "Unknown"
			task.spawn(L_1_.world2WallStateWorker)
			task.spawn(L_1_.world2LavaStateWorker)
			task.spawn(L_1_.autoWinsRouteWorker)
			L_2309_ = {}
			L_2309_.Common = 2500
			L_2309_.Uncommon = 25000
			L_2309_.Rare = 250000
			L_2309_.Mysterious = 3500000
			task.spawn(L_1_.autoBuyItemsWorker)
			task.spawn(L_1_.autoEquipBestWorker)
			task.spawn(L_1_.autoRebirthWorker)
			L_2276_.RenderStepped:Connect(L_1_.updateCFrameMovement)

			return
		end
		L_2286_ = L_2283_
	else
		L_2286_ = L_2283_
	end
	L_2278_.CurrentConfig = L_2286_
	L_2286_ = L_2272_:WaitForChild("Remotes", 10)
	task.spawn(L_1_.autoStepFarmWorker)
	task.spawn(L_1_.world1HazardStateWorker)
	L_2278_.World2WallState = "Unknown"
	L_2278_.World2LavaState = "Unknown"
	task.spawn(L_1_.world2WallStateWorker)
	task.spawn(L_1_.world2LavaStateWorker)
	task.spawn(L_1_.autoWinsRouteWorker)
	L_2309_ = {}
	L_2309_.Common = 2500
	L_2309_.Uncommon = 25000
	L_2309_.Rare = 250000
	L_2309_.Mysterious = 3500000
	task.spawn(L_1_.autoBuyItemsWorker)
	task.spawn(L_1_.autoEquipBestWorker)
	task.spawn(L_1_.autoRebirthWorker)
	L_2276_.RenderStepped:Connect(L_1_.updateCFrameMovement)

	return
end

L_1_.main = function(...)
	local L_2315_, L_2316_, L_2317_, L_2318_, L_2319_, L_2320_, L_2321_, L_2322_, L_2323_, L_2324_, L_2325_, L_2326_, L_2327_, L_2328_, L_2329_, L_2330_
	local L_2331_, L_2332_, L_2333_, L_2334_, L_2335_, L_2336_, L_2337_, L_2338_, L_2339_, L_2340_, L_2341_, L_2342_, L_2343_, L_2344_, L_2345_, L_2346_
	local L_2347_, L_2348_, L_2349_, L_2350_, L_2351_, L_2352_, L_2353_, L_2354_, L_2355_, L_2356_, L_2357_, L_2358_, L_2359_, L_2360_, L_2361_, L_2362_
	local L_2363_, L_2364_, L_2365_, L_2366_, L_2367_, L_2368_
	L_2315_ = getgenv()
	L_2315_._premTag = L_1_.premiumTag
	L_2315_._isPremiumUser = L_1_.isPremiumUser
	L_2315_ = getgenv()
	L_2316_ = getgenv().__SnowyUIRuntime

	L_2316_ = {}

	L_2316_.corner = L_1_.createCorner
	L_2316_.stroke = L_1_.createStroke
	L_2316_.gradient = L_1_.createGradient
	L_2316_.shadow = L_1_.createShadow
	L_2316_.tw = L_1_.tween
	L_2315_.__SnowyUIRuntime = L_2316_
	L_2315_.corner = L_2316_.corner
	L_2315_.stroke = L_2316_.stroke
	L_2315_.gradient = L_2316_.gradient
	L_2315_.shadow = L_2316_.shadow
	L_2315_.tw = L_2316_.tw
	L_2315_ = getgenv()._nagPremium
	L_2316_ = getgenv()
	L_2317_ = L_2316_.tw

	L_2316_ = getgenv()
	L_2316_._nagPremium = L_1_._nagPremium
	L_2315_ = L_1_._nagPremium

	pcall(L_1_.callback_14)
	pcall(L_1_.callback_12)
	pcall(L_1_.callback_12)
	pcall(L_1_.callback_12)
	pcall(L_1_.callback_12)
	warn("[SnowyHub] Anti-detect stub installed (Delta-compatible).")
	pcall(L_1_.WindowWidth)
	L_2322_ = {}
	L_2322_.WindowWidth = 720
	L_2322_.WindowHeight = 520
	L_2322_.HeaderHeight = 48
	L_2322_.TabBarHeight = 44
	L_2322_.BannerHeight = 62
	L_2322_.Radius = 24
	L_2322_.RadiusSm = 16
	L_2322_.RadiusXs = 12
	L_2322_.RadiusPill = 999
	L_2322_.BgPrimary = Color3.fromRGB(18, 24, 64)
	L_2322_.BgSecondary = Color3.fromRGB(24, 32, 85)
	L_2322_.BgCard = Color3.fromRGB(35, 45, 110)
	L_2322_.BgCardHover = Color3.fromRGB(45, 60, 140)
	L_2322_.BgCardActive = Color3.fromRGB(40, 65, 160)
	L_2322_.BgHeader = Color3.fromRGB(14, 18, 50)
	L_2322_.BgInput = Color3.fromRGB(20, 28, 70)
	L_2322_.BgTabBar = Color3.fromRGB(20, 28, 70)
	L_2322_.Accent = Color3.fromRGB(85, 213, 254)
	L_2322_.AccentBright = Color3.fromRGB(135, 235, 255)
	L_2322_.AccentDark = Color3.fromRGB(50, 170, 220)
	L_2322_.AccentDim = Color3.fromRGB(30, 90, 130)
	L_2322_.AccentGlow = Color3.fromRGB(180, 240, 255)
	L_2322_.AccentSoft = Color3.fromRGB(100, 200, 255)
	L_2322_.Premium = Color3.fromRGB(255, 200, 50)
	L_2322_.PremiumDark = Color3.fromRGB(180, 130, 20)
	L_2322_.PremiumDim = Color3.fromRGB(50, 40, 10)
	L_2322_.BannerBg = Color3.fromRGB(15, 45, 100)
	L_2322_.BannerActive = Color3.fromRGB(25, 70, 150)
	L_2322_.TextPrimary = Color3.fromRGB(230, 245, 255)
	L_2322_.TextSecondary = Color3.fromRGB(160, 190, 230)
	L_2322_.TextMuted = Color3.fromRGB(80, 110, 160)
	L_2322_.TextDim = Color3.fromRGB(50, 70, 110)
	L_2322_.Border = Color3.fromRGB(30, 45, 100)
	L_2322_.BorderHi = Color3.fromRGB(60, 100, 220)
	L_2322_.Success = Color3.fromRGB(50, 220, 120)
	L_2322_.Error = Color3.fromRGB(255, 55, 75)
	L_2322_.Warning = Color3.fromRGB(255, 180, 50)
	L_2324_ = {}
	L_2324_.name = "BedWars"
	L_2324_.icon = utf8.char(128719)
	L_2325_ = {}
	L_2325_[1] = "bedwars"
	L_2325_[2] = "bed wars"
	L_2324_.aliases = L_2325_
	L_2325_ = {}
	L_2325_[1] = 6872265039
	L_2325_[2] = 6872274481
	L_2324_.placeIds = L_2325_
	L_2324_.features = 69
	L_2324_.img = "rbxassetid://6034281798"
	L_2325_ = {}
	L_2325_.name = "BedWars"
	L_2325_.icon = utf8.char(128719)
	L_2326_ = {}
	L_2326_[1] = "bedwars"
	L_2326_[2] = "bed wars"
	L_2325_.aliases = L_2326_
	L_2326_ = {}
	L_2326_[1] = 6872265039
	L_2326_[2] = 6872274481
	L_2325_.placeIds = L_2326_
	L_2325_.features = 69
	L_2325_.img = "rbxassetid://6034281798"
	L_2326_ = {}
	L_2326_.name = "Taxi Boss"
	L_2326_.icon = utf8.char(128661)
	L_2327_ = {}
	L_2327_[1] = "taxi boss"
	L_2327_[2] = "taxiboss"
	L_2327_[3] = "taxi"
	L_2326_.aliases = L_2327_
	L_2327_ = {}
	L_2327_[1] = 7305309231
	L_2326_.placeIds = L_2327_
	L_2326_.features = 40
	L_2326_.img = "rbxassetid://6034281798"
	L_2327_ = {}
	L_2327_.name = "BloxStrike"
	L_2327_.icon = utf8.char(127919)
	L_2328_ = {}
	L_2328_[1] = "bloxstrike"
	L_2328_[2] = "blox strike"
	L_2327_.aliases = L_2328_
	L_2328_ = {}
	L_2328_[1] = 114234929420007
	L_2327_.placeIds = L_2328_
	L_2327_.features = 45
	L_2327_.img = "rbxassetid://6034281798"
	L_2328_ = {}
	L_2328_.name = "Anime Expeditions"
	L_2328_.icon = utf8.char(9889)
	L_2329_ = {}
	L_2329_[1] = "anime expeditions"
	L_2329_[2] = "expeditions"
	L_2329_[3] = "anime expedition"
	L_2328_.aliases = L_2329_
	L_2329_ = {}
	L_2329_[1] = 84515722934860
	L_2328_.placeIds = L_2329_
	L_2328_.features = 40
	L_2328_.img = "rbxassetid://6034281798"
	L_2329_ = {}
	L_2329_.name = "+1 Pickaxe Swing Escape"
	L_2329_.icon = utf8.char(9935)
	L_2330_ = {}
	L_2330_[1] = "+1 pickaxe swing escape"
	L_2330_[2] = "pickaxe swing escape"
	L_2330_[3] = "pickaxe escape"
	L_2330_[4] = "pickaxe swing"
	L_2330_[5] = "pickaxe"
	L_2329_.aliases = L_2330_
	L_2330_ = {}
	L_2330_[1] = 82554996468034
	L_2329_.placeIds = L_2330_
	L_2329_.features = 20
	L_2329_.img = "rbxassetid://6034281798"
	L_2330_ = {}
	L_2330_.name = "Animal Hospital"
	L_2330_.icon = utf8.char(127973)
	L_2331_ = {}
	L_2331_[1] = "animal hospital"
	L_2331_[2] = "anomaly hospital"
	L_2331_[3] = "hospital"
	L_2330_.aliases = L_2331_
	L_2331_ = {}
	L_2331_[1] = 78515283254292
	L_2330_.placeIds = L_2331_
	L_2330_.features = 15
	L_2330_.img = "rbxassetid://6034281798"
	L_2331_ = {}
	L_2331_.name = "Merge a Nuke"
	L_2331_.icon = utf8.char(128163)
	L_2332_ = {}
	L_2332_[1] = "merge a nuke"
	L_2332_[2] = "merge a nuke!"
	L_2332_[3] = "nuke tycoon"
	L_2332_[4] = "merge nuke"
	L_2331_.aliases = L_2332_
	L_2332_ = {}
	L_2332_[1] = 128784467030899
	L_2332_[2] = 136423403372990
	L_2331_.placeIds = L_2332_
	L_2331_.features = 15
	L_2331_.img = "rbxassetid://6034281798"
	L_2332_ = {}
	L_2332_.name = "Arsenal"
	L_2332_.icon = utf8.char(127919)
	L_2333_ = {}
	L_2333_[1] = 286090429
	L_2333_[2] = 2133507413
	L_2332_.placeIds = L_2333_
	L_2332_.features = 20
	L_2332_.img = "rbxassetid://6034281798"
	L_2333_ = {}
	L_2333_.name = "Jujutsu Shenanigans"
	L_2333_.icon = utf8.char(9889)
	L_2334_ = {}
	L_2334_[1] = "jujutsu shenanigans"
	L_2334_[2] = "jujutsu"
	L_2334_[3] = "shenanigans"
	L_2333_.aliases = L_2334_
	L_2334_ = {}
	L_2334_[1] = 9391468976
	L_2333_.placeIds = L_2334_
	L_2334_ = {}
	L_2334_[1] = 3508322461
	L_2333_.universeIds = L_2334_
	L_2333_.features = 15
	L_2333_.img = "rbxassetid://6034281798"
	L_2334_ = {}
	L_2334_.name = "Abyss"
	L_2334_.icon = utf8.char(127754)
	L_2335_ = {}
	L_2335_[1] = 8841631016
	L_2335_[2] = 6499213745
	L_2334_.placeIds = L_2335_
	L_2334_.features = 22
	L_2334_.img = "rbxassetid://6034281798"
	L_2335_ = {}
	L_2335_.name = "Jailbreak"
	L_2335_.icon = utf8.char(128680)
	L_2336_ = {}
	L_2336_[1] = 606849621
	L_2335_.placeIds = L_2336_
	L_2335_.features = 50
	L_2335_.img = "rbxassetid://6034281798"
	L_2336_ = {}
	L_2336_.name = "Tsunami"
	L_2336_.icon = utf8.char(127754)
	L_2337_ = {}
	L_2337_[1] = 2456517837
	L_2337_[2] = 7456917583
	L_2336_.placeIds = L_2337_
	L_2336_.features = 30
	L_2336_.img = "rbxassetid://6034281798"
	L_2337_ = {}
	L_2337_.name = "Sniper Duels"
	L_2337_.icon = utf8.char(127919)
	L_2338_ = {}
	L_2338_[1] = 2957674229
	L_2338_[2] = 3519873232
	L_2338_[3] = 109397169461300
	L_2337_.placeIds = L_2338_
	L_2337_.features = 12
	L_2337_.img = "rbxassetid://6034281798"
	L_2338_ = {}
	L_2338_.name = "Swing Obby"
	L_2338_.icon = utf8.char(127906)
	L_2339_ = {}
	L_2339_[1] = 5334680521
	L_2338_.placeIds = L_2339_
	L_2338_.features = 10
	L_2338_.img = "rbxassetid://6034281798"
	L_2339_ = {}
	L_2339_.name = "Brookhaven"
	L_2339_.icon = utf8.char(127968)
	L_2340_ = {}
	L_2340_[1] = 4924922222
	L_2339_.placeIds = L_2340_
	L_2339_.features = 15
	L_2339_.img = "rbxassetid://6034281798"
	L_2323_ = {}
	L_2323_[1] = L_2324_
	L_2323_[2] = L_2325_
	L_2323_[3] = L_2326_
	L_2323_[4] = L_2327_
	L_2323_[5] = L_2328_
	L_2323_[6] = L_2329_
	L_2323_[7] = L_2330_
	L_2323_[8] = L_2331_
	L_2323_[9] = L_2332_
	L_2323_[10] = L_2333_
	L_2323_[11] = L_2334_
	L_2323_[12] = L_2335_
	L_2323_[13] = L_2336_
	L_2323_[14] = L_2337_
	L_2323_[15] = L_2338_
	L_2323_[16] = L_2339_
	L_2324_ = {}
	L_2324_.name = "99 Nights"
	L_2324_.icon = utf8.char(127769)
	L_2325_ = {}
	L_2325_[1] = 13271790403
	L_2325_[2] = 14502339080
	L_2324_.placeIds = L_2325_
	L_2324_.features = 28
	L_2324_.img = "rbxassetid://6034281798"
	L_2325_ = {}
	L_2325_.name = "Blox Fruits"
	L_2325_.icon = utf8.char(127822)
	L_2326_ = {}
	L_2326_[1] = "blox fruits"
	L_2326_[2] = "blox fruit"
	L_2326_[3] = "bloxfruits"
	L_2325_.aliases = L_2326_
	L_2326_ = {}
	L_2326_[1] = 2753915549
	L_2326_[2] = 4442272183
	L_2326_[3] = 7449423635
	L_2325_.placeIds = L_2326_
	L_2325_.features = 18
	L_2325_.img = "rbxassetid://6034281798"
	L_2326_ = {}
	L_2326_.name = "Pet Sim 99"
	L_2326_.icon = utf8.char(128062)
	L_2327_ = {}
	L_2327_[1] = "pet simulator 99"
	L_2327_[2] = "pet sim 99"
	L_2327_[3] = "petsim99"
	L_2326_.aliases = L_2327_
	L_2327_ = {}
	L_2327_[1] = 8737899170
	L_2327_[2] = 15532244896
	L_2327_[3] = 15588347101
	L_2326_.placeIds = L_2327_
	L_2327_ = {}
	L_2327_[1] = 3317771874
	L_2326_.universeIds = L_2327_
	L_2326_.features = 15
	L_2326_.img = "rbxassetid://6034281798"
	L_2327_ = {}
	L_2327_.name = "Bee Swarm"
	L_2327_.icon = utf8.char(128029)
	L_2328_ = {}
	L_2328_[1] = 1537690962
	L_2327_.placeIds = L_2328_
	L_2327_.features = 12
	L_2327_.img = "rbxassetid://6034281798"
	L_2328_ = {}
	L_2328_.name = "SAB"
	L_2328_.icon = utf8.char(129302)
	L_2329_ = {}
	L_2329_[1] = "steal a brainrot"
	L_2329_[2] = "sab"
	L_2328_.aliases = L_2329_
	L_2329_ = {}
	L_2329_[1] = 18668065096
	L_2329_[2] = 1234567890
	L_2329_[3] = 10495922230
	L_2329_[4] = 109983668079237
	L_2328_.placeIds = L_2329_
	L_2329_ = {}
	L_2329_[1] = 109983668079237
	L_2328_.universeIds = L_2329_
	L_2328_.features = 24
	L_2328_.img = "rbxassetid://6034281798"
	L_2329_ = {}
	L_2329_.name = "Ultimate Battlegrounds"
	L_2329_.icon = utf8.char(128298)
	L_2330_ = {}
	L_2330_[1] = 11815767793
	L_2329_.placeIds = L_2330_
	L_2329_.features = 18
	L_2329_.img = "rbxassetid://6034281798"
	L_2330_ = {}
	L_2330_.name = "Strongest Battlegrounds"
	L_2330_.icon = utf8.char(128293)
	L_2331_ = {}
	L_2331_[1] = 10495922230
	L_2330_.placeIds = L_2331_
	L_2330_.features = 15
	L_2330_.img = "rbxassetid://6034281798"
	L_2331_ = {}
	L_2331_.name = "Heroes Battlegrounds"
	L_2331_.icon = utf8.char(129464)
	L_2332_ = {}
	L_2332_[1] = 13076380114
	L_2331_.placeIds = L_2332_
	L_2331_.features = 16
	L_2331_.img = "rbxassetid://6034281798"
	L_2332_ = {}
	L_2332_.name = "Legend Battlegrounds"
	L_2332_.icon = utf8.char(128481)
	L_2333_ = {}
	L_2333_[1] = 15269951959
	L_2332_.placeIds = L_2333_
	L_2332_.features = 18
	L_2332_.img = "rbxassetid://6034281798"
	L_2333_ = {}
	L_2333_.name = "Jump for Brainrots"
	L_2333_.icon = utf8.char(129504)
	L_2334_ = {}
	L_2334_[1] = 139299356663913
	L_2333_.placeIds = L_2334_
	L_2333_.features = 12
	L_2333_.img = "rbxassetid://6034281798"
	L_2334_ = {}
	L_2334_.name = "+1 Jump Brainrot"
	L_2334_.icon = utf8.char(128095)
	L_2335_ = {}
	L_2335_[1] = 121192350097093
	L_2334_.placeIds = L_2335_
	L_2334_.features = 15
	L_2334_.img = "rbxassetid://6034281798"
	L_2335_ = {}
	L_2335_.name = "Grab Ores!"
	L_2335_.icon = utf8.char(9935)
	L_2336_ = {}
	L_2336_[1] = 82806856224736
	L_2335_.placeIds = L_2336_
	L_2335_.features = 45
	L_2335_.img = "rbxassetid://6034281798"
	L_2336_ = {}
	L_2336_.name = "Murderers VS Sheriffs"
	L_2336_.icon = utf8.char(128298)
	L_2337_ = {}
	L_2337_[1] = 135856908115931
	L_2336_.placeIds = L_2337_
	L_2336_.features = 22
	L_2336_.img = "rbxassetid://6034281798"
	L_2337_ = {}
	L_2337_.name = "Sailor Piece"
	L_2337_.icon = utf8.char(9875)
	L_2338_ = {}
	L_2338_[1] = "sailor piece"
	L_2338_[2] = "sailor peace"
	L_2337_.aliases = L_2338_
	L_2338_ = {}
	L_2338_[1] = 77747658251236
	L_2337_.placeIds = L_2338_
	L_2337_.features = 38
	L_2337_.img = "rbxassetid://6034281798"
	L_2338_ = {}
	L_2338_.name = "MM2"
	L_2338_.icon = utf8.char(128481)
	L_2339_ = {}
	L_2339_[1] = "murder mystery 2"
	L_2339_[2] = "mm2"
	L_2338_.aliases = L_2339_
	L_2339_ = {}
	L_2339_[1] = 142823291
	L_2339_[2] = 80005698042109
	L_2338_.placeIds = L_2339_
	L_2338_.features = 40
	L_2338_.img = "rbxassetid://6034281798"
	L_2339_ = {}
	L_2339_.name = "Kick a Lucky Block"
	L_2339_.icon = utf8.char(127808)
	L_2340_ = {}
	L_2340_[1] = "kick a lucky block"
	L_2340_[2] = "lucky block"
	L_2340_[3] = "kick lucky"
	L_2339_.aliases = L_2340_
	L_2340_ = {}
	L_2340_[1] = 16955097151
	L_2340_[2] = 89469502395769
	L_2339_.placeIds = L_2340_
	L_2340_ = {}
	L_2340_[1] = 89469502395769
	L_2339_.universeIds = L_2340_
	L_2339_.features = 30
	L_2339_.img = "rbxassetid://6034281798"
	L_2323_[17] = L_2324_
	L_2323_[18] = L_2325_
	L_2323_[19] = L_2326_
	L_2323_[20] = L_2327_
	L_2323_[21] = L_2328_
	L_2323_[22] = L_2329_
	L_2323_[23] = L_2330_
	L_2323_[24] = L_2331_
	L_2323_[25] = L_2332_
	L_2323_[26] = L_2333_
	L_2323_[27] = L_2334_
	L_2323_[28] = L_2335_
	L_2323_[29] = L_2336_
	L_2323_[30] = L_2337_
	L_2323_[31] = L_2338_
	L_2323_[32] = L_2339_
	L_2324_ = {}
	L_2324_.name = "Rivals"
	L_2324_.icon = utf8.char(128299)
	L_2325_ = {}
	L_2325_[1] = "rivals"
	L_2325_[2] = "rivals fps"
	L_2325_[3] = "matchmaking"
	L_2324_.aliases = L_2325_
	L_2325_ = {}
	L_2325_[1] = 17625359962
	L_2325_[2] = 14721849686
	L_2325_[3] = 117398147513099
	L_2324_.placeIds = L_2325_
	L_2325_ = {}
	L_2325_[1] = 6035872082
	L_2324_.universeIds = L_2325_
	L_2324_.features = 22
	L_2324_.img = "rbxassetid://6034281798"
	L_2325_ = {}
	L_2325_.name = "Speed Keyboard Escape"
	L_2325_.icon = utf8.char(9000)
	L_2326_ = {}
	L_2326_[1] = "speed keyboard escape"
	L_2326_[2] = "keyboard escape"
	L_2326_[3] = "1 speed keyboard escape"
	L_2326_[4] = "escape candy chocolate"
	L_2326_[5] = "1-speed-keyboard-escape"
	L_2326_[6] = "keyboard"
	L_2325_.aliases = L_2326_
	L_2326_ = {}
	L_2326_[1] = 95082159892680
	L_2325_.placeIds = L_2326_
	L_2325_.features = 16
	L_2325_.img = "rbxassetid://6034281798"
	L_2326_ = {}
	L_2326_.name = "Speed Monkey Escape"
	L_2326_.icon = utf8.char(128018)
	L_2327_ = {}
	L_2327_[1] = "speed monkey escape"
	L_2327_[2] = "monkey escape"
	L_2327_[3] = "1 speed monkey escape"
	L_2327_[4] = "monkey"
	L_2326_.aliases = L_2327_
	L_2327_ = {}
	L_2327_[1] = 114697347887839
	L_2326_.placeIds = L_2327_
	L_2326_.features = 20
	L_2326_.img = "rbxassetid://6034281798"
	L_2327_ = {}
	L_2327_.name = "Sell Lemons"
	L_2327_.icon = utf8.char(127819)
	L_2328_ = {}
	L_2328_[1] = "sell lemons"
	L_2328_[2] = "lemon tycoon"
	L_2328_[3] = "lemons"
	L_2327_.aliases = L_2328_
	L_2328_ = {}
	L_2328_[1] = 79268393072444
	L_2327_.placeIds = L_2328_
	L_2327_.features = 14
	L_2327_.img = "rbxassetid://6034281798"
	L_2328_ = {}
	L_2328_.name = "Demonology"
	L_2328_.icon = utf8.char(128123)
	L_2329_ = {}
	L_2329_[1] = "demonology"
	L_2329_[2] = "ghost hunter"
	L_2329_[3] = "demon"
	L_2328_.aliases = L_2329_
	L_2329_ = {}
	L_2329_[1] = 18199615050
	L_2328_.placeIds = L_2329_
	L_2328_.features = 12
	L_2328_.img = "rbxassetid://6034281798"
	L_2329_ = {}
	L_2329_.name = "Grow a Garden 2"
	L_2329_.icon = utf8.char(127793)
	L_2330_ = {}
	L_2330_[1] = "grow a garden 2"
	L_2330_[2] = "grow a garden"
	L_2330_[3] = "gag2"
	L_2330_[4] = "gag 2"
	L_2329_.aliases = L_2330_
	L_2330_ = {}
	L_2330_[1] = 97598239454123
	L_2330_[2] = 1588579651
	L_2330_[3] = 126884695634066
	L_2329_.placeIds = L_2330_
	L_2330_ = {}
	L_2330_[1] = 7436755782
	L_2329_.universeIds = L_2330_
	L_2329_.features = 25
	L_2329_.img = "rbxassetid://6034281798"
	L_2330_ = {}
	L_2330_.name = "Welcome to Bloxburg"
	L_2330_.icon = utf8.char(127968)
	L_2331_ = {}
	L_2331_[1] = "welcome to bloxburg"
	L_2331_[2] = "bloxburg"
	L_2330_.aliases = L_2331_
	L_2331_ = {}
	L_2331_[1] = 185655149
	L_2330_.placeIds = L_2331_
	L_2330_.features = 16
	L_2330_.img = "rbxassetid://6034281798"
	L_2331_ = {}
	L_2331_.name = "Adopt Me"
	L_2331_.icon = utf8.char(128054)
	L_2332_ = {}
	L_2332_[1] = "adopt me"
	L_2332_[2] = "adoptme"
	L_2331_.aliases = L_2332_
	L_2332_ = {}
	L_2332_[1] = 920587237
	L_2331_.placeIds = L_2332_
	L_2331_.features = 12
	L_2331_.img = "rbxassetid://6034281798"
	L_2332_ = {}
	L_2332_.name = "Dandy's World"
	L_2332_.icon = utf8.char(127912)
	L_2333_ = {}
	L_2333_[1] = "dandys world"
	L_2333_[2] = "dandy"
	L_2333_[3] = "dandys"
	L_2332_.aliases = L_2333_
	L_2333_ = {}
	L_2333_[1] = 16267229903
	L_2332_.placeIds = L_2333_
	L_2332_.features = 10
	L_2332_.img = "rbxassetid://6034281798"
	L_2333_ = {}
	L_2333_.name = "Blade Ball"
	L_2333_.icon = utf8.char(128298)
	L_2334_ = {}
	L_2334_[1] = "blade ball"
	L_2334_[2] = "bladeball"
	L_2334_[3] = "bb"
	L_2333_.aliases = L_2334_
	L_2334_ = {}
	L_2334_[1] = 13772394625
	L_2334_[2] = 14777999650
	L_2334_[3] = 15182888200
	L_2333_.placeIds = L_2334_
	L_2333_.features = 25
	L_2333_.img = "rbxassetid://6034281798"
	L_2334_ = {}
	L_2334_.name = "KAT"
	L_2334_.icon = utf8.char(128298)
	L_2335_ = {}
	L_2335_[1] = 621129760
	L_2334_.placeIds = L_2335_
	L_2335_ = {}
	L_2335_[1] = 228028122
	L_2334_.universeIds = L_2335_
	L_2334_.features = 11
	L_2334_.img = "rbxassetid://6034281798"
	L_2335_ = {}
	L_2335_.name = "One Scope"
	L_2335_.icon = utf8.char(127919)
	L_2336_ = {}
	L_2336_[1] = 135648408848758
	L_2335_.placeIds = L_2336_
	L_2335_.features = 7
	L_2335_.img = "rbxassetid://6034281798"
	L_2336_ = {}
	L_2336_.name = "Da Hood"
	L_2336_.icon = utf8.char(127968)
	L_2337_ = {}
	L_2337_[1] = "da hood"
	L_2337_[2] = "dahood"
	L_2337_[3] = "dh"
	L_2336_.aliases = L_2337_
	L_2337_ = {}
	L_2337_[1] = 2788229376
	L_2337_[2] = 105305881594005
	L_2337_[3] = 98343466176190
	L_2337_[4] = 93778920465645
	L_2337_[5] = 129449254792324
	L_2337_[6] = 122120252103378
	L_2337_[7] = 110917236678062
	L_2337_[8] = 130879446158509
	L_2336_.placeIds = L_2337_
	L_2336_.features = 120
	L_2336_.img = "rbxassetid://6034281798"
	L_2337_ = {}
	L_2337_.name = "Evade"
	L_2337_.icon = utf8.char(127939)
	L_2338_ = {}
	L_2338_[1] = "evade"
	L_2338_[2] = "rise"
	L_2337_.aliases = L_2338_
	L_2338_ = {}
	L_2338_[1] = 9872472334
	L_2337_.placeIds = L_2338_
	L_2337_.features = 45
	L_2337_.img = "rbxassetid://6034281798"
	L_2338_ = {}
	L_2338_.name = "Bridge Duel"
	L_2338_.icon = utf8.char(128481)
	L_2339_ = {}
	L_2339_[1] = "bridge duel"
	L_2339_[2] = "bridge duels"
	L_2339_[3] = "uoro"
	L_2338_.aliases = L_2339_
	L_2339_ = {}
	L_2339_[1] = 139566161526375
	L_2338_.placeIds = L_2339_
	L_2338_.features = 35
	L_2338_.img = "rbxassetid://6034281798"
	L_2339_ = {}
	L_2339_.name = "Drain the Lake"
	L_2339_.icon = utf8.char(128167)
	L_2340_ = {}
	L_2340_[1] = "drain the lake"
	L_2340_[2] = "drain lake"
	L_2339_.aliases = L_2340_
	L_2340_ = {}
	L_2340_[1] = 138381251771774
	L_2339_.placeIds = L_2340_
	L_2340_ = {}
	L_2340_[1] = 10267363348
	L_2339_.universeIds = L_2340_
	L_2339_.features = 9
	L_2339_.img = "rbxassetid://6034281798"
	L_2323_[33] = L_2324_
	L_2323_[34] = L_2325_
	L_2323_[35] = L_2326_
	L_2323_[36] = L_2327_
	L_2323_[37] = L_2328_
	L_2323_[38] = L_2329_
	L_2323_[39] = L_2330_
	L_2323_[40] = L_2331_
	L_2323_[41] = L_2332_
	L_2323_[42] = L_2333_
	L_2323_[43] = L_2334_
	L_2323_[44] = L_2335_
	L_2323_[45] = L_2336_
	L_2323_[46] = L_2337_
	L_2323_[47] = L_2338_
	L_2323_[48] = L_2339_
	L_2324_ = {}
	L_2324_.name = "Prison Life"
	L_2324_.icon = utf8.char(128680)
	L_2325_ = {}
	L_2325_[1] = "prison life"
	L_2325_[2] = "prison"
	L_2324_.aliases = L_2325_
	L_2325_ = {}
	L_2325_[1] = 155615604
	L_2324_.placeIds = L_2325_
	L_2325_ = {}
	L_2325_[1] = 73885730
	L_2324_.universeIds = L_2325_
	L_2324_.features = 9
	L_2324_.img = "rbxassetid://6034281798"
	L_2325_ = {}
	L_2325_.name = "Fish It"
	L_2325_.icon = utf8.char(128031)
	L_2326_ = {}
	L_2326_[1] = "fish it"
	L_2326_[2] = "fisch"
	L_2326_[3] = "fishit"
	L_2325_.aliases = L_2326_
	L_2326_ = {}
	L_2326_[1] = 121864768012064
	L_2326_[2] = 16732694052
	L_2326_[3] = 17445763782
	L_2325_.placeIds = L_2326_
	L_2325_.features = 25
	L_2325_.img = "rbxassetid://6034281798"
	L_2326_ = {}
	L_2326_.name = "Forsaken"
	L_2326_.icon = utf8.char(128128)
	L_2327_ = {}
	L_2327_[1] = "forsaken"
	L_2326_.aliases = L_2327_
	L_2327_ = {}
	L_2327_[1] = 18687417158
	L_2326_.placeIds = L_2327_
	L_2326_.features = 20
	L_2326_.img = "rbxassetid://6034281798"
	L_2327_ = {}
	L_2327_.name = "Volley Ball Legends"
	L_2327_.icon = utf8.char(127952)
	L_2340_ = {}
	L_2340_[1] = "volley ball legends"
	L_2340_[2] = "volleyball legends"
	L_2340_[3] = "volleyball"
	L_2340_[4] = "volley ball"
	L_2327_.aliases = L_2340_
	L_2340_ = {}
	L_2340_[1] = 73956553001240
	L_2327_.placeIds = L_2340_
	L_2327_.features = 20
	L_2327_.img = "rbxassetid://6034281798"
	L_2323_[49] = L_2324_
	L_2323_[50] = L_2325_
	L_2323_[51] = L_2326_
	L_2323_[52] = L_2327_
	L_2324_ = getgenv()
	L_2324_.SUPPORTED_GAMES = L_2323_
	L_2315_ = game:GetService("TweenService")
	L_2316_ = game:GetService("UserInputService")
	L_2317_ = game:GetService("RunService")
	L_2318_ = game:GetService("Players")
	L_2319_ = game:GetService("HttpService")
	L_2320_ = game:GetService("CoreGui")
	L_2321_ = game:GetService("Players").LocalPlayer
	L_2324_ = nil
	L_2325_ = tonumber(game.PlaceId)
	L_2326_ = game.PlaceId
	L_2328_ = 18687417158
	L_2329_ = 17445763782
	L_2340_ = "rbxassetid://6034281798"
	L_2341_ = 73956553001240
	L_2342_ = "volleyball legends"
	L_2343_ = "volleyball"
	L_2344_ = "volley ball"
	L_2345_ = 130879446158509

	L_2325_ = 0

	L_2326_ = tonumber(game.GameId)
	L_2327_ = game.GameId

	L_2326_ = 0

	pcall(L_1_.callback_41)
	L_2327_ = ""
	L_2328_ = ipairs
	L_2329_ = L_2323_
	L_2328_, L_2329_, L_2330_ = ipairs(L_2323_)

	L_2333_ = L_2332_.placeIds

	L_2333_ = ipairs
	L_2334_ = L_2332_.placeIds
	L_2333_, L_2334_, L_2335_ = ipairs(L_2332_.placeIds)

	L_2338_ = tonumber(L_2337_)
	L_2339_ = L_2337_
	L_2368_ = (L_2325_ == tonumber(L_2337_))

	L_2324_ = L_2332_

	L_2333_ = L_2332_.universeIds

	L_2333_ = ipairs
	L_2334_ = L_2332_.universeIds
	L_2333_, L_2334_, L_2335_ = ipairs(L_2332_.universeIds)

	L_2338_ = tonumber(L_2337_)
	L_2339_ = L_2337_
	L_2368_ = (L_2326_ == tonumber(L_2337_))

	L_2324_ = L_2332_

	L_2367_ = ""
	L_2368_ = (L_2327_ == "")

	L_2328_ = ipairs
	L_2329_ = L_2323_
	L_2328_, L_2329_, L_2330_ = ipairs(L_2323_)

	L_2333_ = L_2332_.name:lower()
	L_2334_ = L_2327_:find(L_2332_.name:lower(), 1, true)
	L_2335_ = L_2327_
	L_2336_ = L_2332_.name:lower()
	L_2337_ = 1
	L_2338_ = true

	L_2324_ = L_2332_

	L_2334_ = L_2332_.aliases

	L_2334_ = ipairs
	L_2335_ = L_2332_.aliases
	L_2334_, L_2335_, L_2336_ = ipairs(L_2332_.aliases)

	L_2339_ = L_2338_:lower()
	L_2340_ = #L_2338_:lower()
	L_2341_ = 3
	L_2368_ = (3 <= #L_2338_:lower())

	L_2340_ = L_2327_:find(L_2339_, 1, true)
	L_2341_ = L_2327_
	L_2342_ = L_2339_
	L_2343_ = 1
	L_2344_ = true

	L_2324_ = L_2332_

	L_2328_ = L_2327_:find("bedwars")
	L_2329_ = L_2327_
	L_2330_ = "bedwars"

	L_2328_ = L_2327_:find("bed wars")
	L_2329_ = L_2327_
	L_2330_ = "bed wars"

	L_2328_ = ipairs
	L_2329_ = L_2323_
	L_2328_, L_2329_, L_2330_ = ipairs(L_2323_)

	L_2333_ = L_2332_.name
	L_2367_ = "BedWars"
	L_2368_ = (L_2332_.name == "BedWars")

	L_2324_ = L_2332_

	L_2328_ = L_2327_:find("bedwars")
	L_2329_ = L_2327_
	L_2330_ = "bedwars"

	L_2328_ = L_2327_:find("bed wars")
	L_2329_ = L_2327_
	L_2330_ = "bed wars"

	L_2328_ = ipairs
	L_2329_ = L_2323_
	L_2328_, L_2329_, L_2330_ = ipairs(L_2323_)

	L_2333_ = L_2332_.name
	L_2367_ = "BedWars"
	L_2368_ = (L_2332_.name == "BedWars")

	L_2324_ = L_2332_

	L_2328_ = L_2327_:find("blox fruit")
	L_2329_ = L_2327_
	L_2330_ = "blox fruit"

	L_2328_ = L_2327_:find("bloxfruit")
	L_2329_ = L_2327_
	L_2330_ = "bloxfruit"

	L_2328_ = ipairs
	L_2329_ = L_2323_
	L_2328_, L_2329_, L_2330_ = ipairs(L_2323_)

	L_2333_ = L_2332_.name
	L_2367_ = "Blox Fruits"
	L_2368_ = (L_2332_.name == "Blox Fruits")

	L_2324_ = L_2332_

	L_2328_ = L_2327_:find("fish it")
	L_2329_ = L_2327_
	L_2330_ = "fish it"

	L_2328_ = L_2327_:find("fisch")
	L_2329_ = L_2327_
	L_2330_ = "fisch"

	L_2328_ = L_2327_:find("fishit")
	L_2329_ = L_2327_
	L_2330_ = "fishit"

	L_2328_ = ipairs
	L_2329_ = L_2323_
	L_2328_, L_2329_, L_2330_ = ipairs(L_2323_)

	L_2333_ = L_2332_.name
	L_2367_ = "Fish It"
	L_2368_ = (L_2332_.name == "Fish It")

	L_2324_ = L_2332_

	L_2328_ = L_2327_:find("steal a brainrot")
	L_2329_ = L_2327_
	L_2330_ = "steal a brainrot"

	L_2328_ = L_2327_:find("sab")
	L_2329_ = L_2327_
	L_2330_ = "sab"

	L_2328_ = ipairs
	L_2329_ = L_2323_
	L_2328_, L_2329_, L_2330_ = ipairs(L_2323_)

	L_2333_ = L_2332_.name
	L_2367_ = "SAB"
	L_2368_ = (L_2332_.name == "SAB")

	L_2324_ = L_2332_

	L_2328_ = L_2327_:find("forsaken")
	L_2329_ = L_2327_
	L_2330_ = "forsaken"

	L_2328_ = ipairs
	L_2329_ = L_2323_
	L_2328_, L_2329_, L_2330_ = ipairs(L_2323_)

	L_2333_ = L_2332_.name
	L_2367_ = "Forsaken"
	L_2368_ = (L_2332_.name == "Forsaken")

	L_2324_ = L_2332_

	L_2328_ = L_2327_:find("volley")
	L_2329_ = L_2327_
	L_2330_ = "volley"

	L_2328_ = ipairs
	L_2329_ = L_2323_
	L_2328_, L_2329_, L_2330_ = ipairs(L_2323_)

	L_2333_ = L_2332_.name
	L_2367_ = "Volley Ball Legends"
	L_2368_ = (L_2332_.name == "Volley Ball Legends")

	L_2324_ = L_2332_

	L_2328_ = L_2327_:find("speed keyboard")
	L_2329_ = L_2327_
	L_2330_ = "speed keyboard"

	L_2328_ = L_2327_:find("keyboard escape")
	L_2329_ = L_2327_
	L_2330_ = "keyboard escape"

	L_2328_ = ipairs
	L_2329_ = L_2323_
	L_2328_, L_2329_, L_2330_ = ipairs(L_2323_)

	L_2333_ = L_2332_.name
	L_2367_ = "Speed Keyboard Escape"
	L_2368_ = (L_2332_.name == "Speed Keyboard Escape")

	L_2324_ = L_2332_

	L_2328_ = L_2327_:find("speed monkey")
	L_2329_ = L_2327_
	L_2330_ = "speed monkey"

	L_2328_ = L_2327_:find("monkey escape")
	L_2329_ = L_2327_
	L_2330_ = "monkey escape"

	L_2328_ = L_2327_:find("monkey")
	L_2329_ = L_2327_
	L_2330_ = "monkey"

	L_2328_ = ipairs
	L_2329_ = L_2323_
	L_2328_, L_2329_, L_2330_ = ipairs(L_2323_)

	L_2333_ = L_2332_.name
	L_2367_ = "Speed Monkey Escape"
	L_2368_ = (L_2332_.name == "Speed Monkey Escape")

	L_2324_ = L_2332_

	L_2328_ = L_2327_:find("anime expedition")
	L_2329_ = L_2327_
	L_2330_ = "anime expedition"

	L_2328_ = L_2327_:find("expedition")
	L_2329_ = L_2327_
	L_2330_ = "expedition"

	L_2328_ = ipairs
	L_2329_ = L_2323_
	L_2328_, L_2329_, L_2330_ = ipairs(L_2323_)

	L_2333_ = L_2332_.name
	L_2367_ = "Anime Expeditions"
	L_2368_ = (L_2332_.name == "Anime Expeditions")

	L_2324_ = L_2332_

	L_2328_ = L_2327_:find("merge a nuke")
	L_2329_ = L_2327_
	L_2330_ = "merge a nuke"

	L_2328_ = L_2327_:find("merge nuke")
	L_2329_ = L_2327_
	L_2330_ = "merge nuke"

	L_2328_ = ipairs
	L_2329_ = L_2323_
	L_2328_, L_2329_, L_2330_ = ipairs(L_2323_)

	L_2333_ = L_2332_.name
	L_2367_ = "Merge a Nuke"
	L_2368_ = (L_2332_.name == "Merge a Nuke")

	L_2324_ = L_2332_

	L_2328_ = L_2327_:find("pickaxe")
	L_2329_ = L_2327_
	L_2330_ = "pickaxe"

	L_2328_ = ipairs
	L_2329_ = L_2323_
	L_2328_, L_2329_, L_2330_ = ipairs(L_2323_)

	L_2333_ = L_2332_.name
	L_2367_ = "+1 Pickaxe Swing Escape"
	L_2368_ = (L_2332_.name == "+1 Pickaxe Swing Escape")

	L_2324_ = L_2332_

	L_2328_ = L_2327_:find("grow a garden")
	L_2329_ = L_2327_
	L_2330_ = "grow a garden"

	L_2328_ = L_2327_:find("gag2")
	L_2329_ = L_2327_
	L_2330_ = "gag2"

	L_2328_ = ipairs
	L_2329_ = L_2323_
	L_2328_, L_2329_, L_2330_ = ipairs(L_2323_)

	L_2333_ = L_2332_.name
	L_2367_ = "Grow a Garden 2"
	L_2368_ = (L_2332_.name == "Grow a Garden 2")

	L_2324_ = L_2332_

	L_2328_ = L_2327_:find("animal hospital")
	L_2329_ = L_2327_
	L_2330_ = "animal hospital"

	L_2328_ = L_2327_:find("hospital")
	L_2329_ = L_2327_
	L_2330_ = "hospital"

	L_2328_ = ipairs
	L_2329_ = L_2323_
	L_2328_, L_2329_, L_2330_ = ipairs(L_2323_)

	L_2333_ = L_2332_.name
	L_2367_ = "Animal Hospital"
	L_2368_ = (L_2332_.name == "Animal Hospital")

	L_2324_ = L_2332_

	L_2328_ = L_2327_:find("prison life")
	L_2329_ = L_2327_
	L_2330_ = "prison life"

	L_2328_ = L_2327_:find("prison")
	L_2329_ = L_2327_
	L_2330_ = "prison"

	L_2328_ = ipairs
	L_2329_ = L_2323_
	L_2328_, L_2329_, L_2330_ = ipairs(L_2323_)

	L_2333_ = L_2332_.name
	L_2367_ = "Prison Life"
	L_2368_ = (L_2332_.name == "Prison Life")

	L_2324_ = L_2332_

	L_2328_ = L_2327_:find("da hood")
	L_2329_ = L_2327_
	L_2330_ = "da hood"

	L_2328_ = L_2327_:find("dahood")
	L_2329_ = L_2327_
	L_2330_ = "dahood"

	L_2328_ = ipairs
	L_2329_ = L_2323_
	L_2328_, L_2329_, L_2330_ = ipairs(L_2323_)

	L_2333_ = L_2332_.name
	L_2367_ = "Da Hood"
	L_2368_ = (L_2332_.name == "Da Hood")

	L_2324_ = L_2332_

	L_2328_ = L_2327_:find("bloxstrike")
	L_2329_ = L_2327_
	L_2330_ = "bloxstrike"

	L_2328_ = L_2327_:find("blox strike")
	L_2329_ = L_2327_
	L_2330_ = "blox strike"

	L_2328_ = ipairs
	L_2329_ = L_2323_
	L_2328_, L_2329_, L_2330_ = ipairs(L_2323_)

	L_2333_ = L_2332_.name
	L_2367_ = "BloxStrike"
	L_2368_ = (L_2332_.name == "BloxStrike")

	L_2324_ = L_2332_

	L_2328_ = L_2327_:find("taxi boss")
	L_2329_ = L_2327_
	L_2330_ = "taxi boss"

	L_2328_ = L_2327_:find("taxiboss")
	L_2329_ = L_2327_
	L_2330_ = "taxiboss"

	L_2328_ = ipairs
	L_2329_ = L_2323_
	L_2328_, L_2329_, L_2330_ = ipairs(L_2323_)

	L_2333_ = L_2332_.name
	L_2367_ = "Taxi Boss"
	L_2368_ = (L_2332_.name == "Taxi Boss")

	L_2324_ = L_2332_

	L_2328_ = L_2327_:find("evade")
	L_2329_ = L_2327_
	L_2330_ = "evade"

	L_2328_ = ipairs
	L_2329_ = L_2323_
	L_2328_, L_2329_, L_2330_ = ipairs(L_2323_)

	L_2333_ = L_2332_.name
	L_2367_ = "Evade"
	L_2368_ = (L_2332_.name == "Evade")

	L_2324_ = L_2332_

	pcall(L_1_.name)
	L_2328_ = pcall
	L_2329_ = L_1_.name

	L_2328_ = {}
	L_2328_.name = "Speed Keyboard Escape"
	L_2328_.features = 0
	L_2328_ = {}
	L_2328_.Notify = L_1_.Notify
	L_2336_ = {}
	L_2336_.CreateLib = L_1_.CreateLib
	L_2346_ = {}
	L_2346_.HubName = "Snowy Studios"
	L_2346_.AccentColor = Color3.fromRGB(0, 162, 255)
	L_2348_ = getgenv()
	L_2348_.Window = L_2336_.CreateLib(L_2346_.HubName, "Midnight")
	L_2324_ = L_2328_
	L_2329_ = nil
	L_2330_ = L_1_.callback_45
	L_2331_ = 0
	L_2332_ = nil
	L_2333_ = L_1_.callback_64
	L_2334_ = L_1_.callback_127()
	L_2335_ = L_1_.callback_128
	L_2337_ = game:GetService("Players").LocalPlayer
	L_2338_ = game:GetService("UserInputService")
	L_2339_ = game:GetService("ReplicatedStorage")
	L_2340_ = game:GetService("RunService")
	L_2341_ = workspace.CurrentCamera
	L_2342_ = L_1_.callback_152
	L_2343_ = L_1_.callback_153
	L_2344_ = L_1_.callback_154
	L_2345_ = L_1_.callback_155
	L_2347_ = L_1_.callback_156
	L_2348_ = getgenv().Window
	L_2349_ = getgenv()
	L_2350_ = L_2346_.HubName
	L_2351_ = "Midnight"

	L_2350_ = L_2324_.name

	L_2350_ = "Unknown"

	L_2351_ = {}
	L_2351_.nonce = L_2349_.__SnowyLaunchNonce
	L_2351_.game = L_2350_
	L_2351_.ui = true
	L_2351_.at = os.clock()
	L_2349_.__SnowyPayloadReady = L_2351_
	print("[SnowyHub] Payload UI ready: " .. tostring(L_2350_))
	L_2349_ = getgenv()
	L_2349_.SnowyLib = L_2328_
	L_2349_ = getgenv()
	L_2349_.Kavo = L_2336_
	L_2349_ = getgenv()
	L_2349_.notify = L_2347_
	task.defer(L_1_.gameTab)
	L_2351_ = getgenv()
	L_2351_.gameTab = L_1_.gameTab_183
	L_2349_ = {}
	L_2350_ = L_1_.gameTab_183
	L_2351_ = L_1_.callback_227
	L_2352_ = "[SnowyHub] Payload UI ready: " .. tostring(L_2350_)
	L_2353_ = "[SnowyHub] Payload UI ready: "
	L_2354_ = tostring(L_2350_)
	L_2355_ = L_2350_

	L_2352_ = getgenv()
	L_2352_.HomeTab = L_2348_:NewTab("Home")
	L_2352_ = getgenv()
	L_2352_.PlayerTab = L_2348_:NewTab("Player")
	L_2352_ = getgenv()
	L_2352_.VisualTab = L_2348_:NewTab("Visuals")
	L_2352_ = getgenv()
	L_2352_.UtilTab = L_2348_:NewTab("Utility")
	L_2352_ = getgenv()
	L_2352_.AimbotTab = L_2348_:NewTab("Aimbot")
	L_2352_ = getgenv()
	L_2352_.SettingsTab = L_2348_:NewTab("Settings")
	L_2352_ = getgenv()
	L_2352_.HomeSec = HomeTab:NewSection("Status")
	HomeSec:NewLabel(utf8.char(10052) .. " SNOWY HUB v6.0")
	L_2352_ = getgenv()
	L_2352_.PlayerSection = PlayerTab:NewSection("General")
	L_2352_ = getgenv()
	L_2352_.VisualSection = VisualTab:NewSection("ESP & Effects")
	L_2352_ = getgenv()
	L_2352_.UtilSection = UtilTab:NewSection("General Tools")
	L_2352_ = getgenv()
	L_2352_.AimbotSection = AimbotTab:NewSection("Combat Settings")
	L_2352_ = getgenv()
	L_2352_.UISec = SettingsTab:NewSection("Interface")
	L_2352_ = getgenv()
	L_2352_.InfoSec = SettingsTab:NewSection("Info")
	L_2352_ = getgenv()
	L_2352_.WalkSpeedValue = 16
	L_2352_ = getgenv()
	L_2352_.JumpPowerValue = 50
	L_2352_ = getgenv()
	L_2352_.GodModeEnabled = false
	L_2352_ = getgenv().PlayerModifierLoop
	L_2353_ = getgenv()
	L_2354_ = SettingsTab
	L_2355_ = "Info"
	L_2356_ = " SNOWY HUB v6.0"
	L_2357_ = utf8.char(10052)
	L_2358_ = 10052

	pcall(L_1_.PlayerModifierLoop)
	L_2352_ = getgenv()
	L_2352_.PlayerModifierLoop = nil
	L_2353_ = nil

	L_2353_ = game:GetService("RunService").RenderStepped
	L_2352_ = getgenv()
	L_2352_.PlayerModifierLoop = L_2353_:Connect(L_1_.callback_231)
	PlayerSection:NewSlider("WalkSpeed", "Changes player speed", 250, 16, L_1_.callback_232)
	PlayerSection:NewSlider("JumpPower", "Changes jump height", 250, 50, L_1_.callback_233)
	PlayerSection:NewSlider("Gravity", "Changes world gravity", 196, 0, L_1_.callback_234)
	PlayerSection:NewPremiumToggle("God Mode", "Instantly regenerates health", L_1_.callback_236)
	noclip = L_1_.enableNoclip
	clip = L_1_.disableNoclip
	PlayerSection:NewPremiumToggle("Noclip", "Walk through objects and walls", L_1_.callback_240)
	PlayerSection:NewPremiumToggle("Infinite Jump", "Jump in mid-air", L_1_.callback_242)
	VisualSection:NewSlider("Field of View", "Change camera FOV", 120, 70, L_1_.callback_243)
	VisualSection:NewToggle("Fullbright", "Removes shadows and darkness", L_1_.callback_244)
	VisualSection:NewPremiumToggle("Player ESP", "Highlights all players through walls", L_1_.callback_245)
	VisualSection:NewPremiumSlider("Hitbox Expander", "Make enemies easier to hit", 20, 2, L_1_.callback_248)
	UtilSection:NewButton("Give Btools", "Gives building tools to inventory", L_1_.callback_249)
	UtilSection:NewPremiumButton("Teleport to Random Player", "TPs you to a random user", L_1_.callback_250)
	UtilSection:NewButton("Rejoin Server", "Rejoins the same server", L_1_.callback_251)
	UtilSection:NewPremiumButton("Server Hop", "Joins a random new server", L_1_.callback_253)
	UtilSection:NewToggle("Anti-AFK", "Prevents Roblox disconnects", L_1_.callback_254)
	L_2356_ = {}
	L_2356_.Enabled = false
	L_2356_.ShowFOV = false
	L_2356_.FOVRadius = 80
	L_2356_.Smoothness = 0.5
	L_2356_.TeamCheck = true
	L_2356_.TargetPart = "Head"
	L_2357_ = Drawing.new("Circle")
	L_2357_.Position = Vector2.new((game.Workspace.CurrentCamera.ViewportSize.X / 2), (game.Workspace.CurrentCamera.ViewportSize.Y / 2))
	L_2357_.Radius = L_2356_.FOVRadius
	L_2357_.Filled = false
	L_2357_.Color = Color3.fromRGB(255, 255, 255)
	L_2357_.Visible = false
	L_2357_.Thickness = 1
	L_2359_ = game:GetService("RunService").RenderStepped
	L_2359_:Connect(L_1_.callback_256)
	AimbotSection:NewPremiumToggle("Enable Aimbot (Right Click)", "Locks onto targets in FOV", L_1_.callback_257)
	AimbotSection:NewToggle("Show FOV Circle", "Displays the aimbot radius", L_1_.callback_258)
	AimbotSection:NewSlider("FOV Size", "Target area size", 300, 20, L_1_.callback_259)
	AimbotSection:NewPremiumSlider("Aimbot Smoothness", "100=Instant, 1=Slow", 100, 1, L_1_.callback_260)
	AimbotSection:NewToggle("Team Check", "Ignores teammates", L_1_.callback_261)
	UISec:NewButton("Test Notification", "Test the notification system", L_1_.callback_262)
	UISec:NewButton("Test Premium Alert", "Premium-style notification", L_1_.callback_263)
	UISec:NewSlider("UI Opacity", "Adjust hub transparency", 8, 0, L_1_.callback_265)
	InfoSec:NewLabel("Right-click = Hold to aim (Aimbot)")
	InfoSec:NewLabel("Drag title bar to move")
	InfoSec:NewLabel("discord.gg/getsnowy")
	InfoSec:NewButton("Copy Discord", "Copy invite link", L_1_.callback_266)
	ScriptSec:NewButton("Reload Hub", "Destroys and reloads the UI", L_1_.callback_269)
	ScriptSec:NewLabel("SNOWY HUB v6.0 | Built by Snowy Studios")
	ScriptSec:NewLabel(tostring(#L_2323_) .. " Games Supported")

	L_2352_ = nil
	L_2353_ = nil
	L_2354_ = false
	L_2355_ = {}
	L_2358_ = L_1_.callback_255
	L_2359_ = 0
	L_2360_ = ScriptSec.NewLabel
	L_2361_ = ScriptSec
	L_2362_ = tostring(#L_2323_) .. " Games Supported"
	L_2363_ = tostring(#L_2323_)
	L_2364_ = " Games Supported"
	L_2365_ = tostring(#L_2323_)
	L_2366_ = #L_2323_

	L_2353_ = getgenv()
	L_2353_.HomeTab = L_1_.createFallbackGameTab()
	L_2353_ = getgenv()
	L_2353_.PlayerTab = L_1_.createFallbackGameTab()
	L_2353_ = getgenv()
	L_2353_.VisualTab = L_1_.createFallbackGameTab()
	L_2353_ = getgenv()
	L_2353_.UtilTab = L_1_.createFallbackGameTab()
	L_2353_ = getgenv()
	L_2353_.AimbotTab = L_1_.createFallbackGameTab()
	L_2353_ = getgenv()
	L_2353_.SettingsTab = L_1_.createFallbackGameTab()
	L_2354_ = getgenv()
	L_2354_.HomeSec = HomeTab:NewSection()
	L_2354_ = getgenv()
	L_2354_.PlayerSection = HomeTab:NewSection()
	L_2354_ = getgenv()
	L_2354_.VisualSection = HomeTab:NewSection()
	L_2354_ = getgenv()
	L_2354_.UtilSection = HomeTab:NewSection()
	L_2354_ = getgenv()
	L_2354_.AimbotSection = HomeTab:NewSection()
	L_2354_ = getgenv()
	L_2354_.UISec = HomeTab:NewSection()
	L_2354_ = getgenv()
	L_2354_.InfoSec = HomeTab:NewSection()
	L_2354_ = getgenv()
	L_2354_.ScriptSec = HomeTab:NewSection()
	L_2352_ = L_1_.createFallbackGameTab
	L_2353_ = HomeTab:NewSection()

	L_2352_ = L_2324_.name
	L_2367_ = "Speed Keyboard Escape"
	L_2368_ = (L_2324_.name == "Speed Keyboard Escape")

	pcall(L_1_.setupSpeedKeyboardEscape)
	L_2352_ = L_1_.setupSpeedKeyboardEscape
	L_2353_ = pcall
	L_2354_ = L_1_.setupSpeedKeyboardEscape

	do
		return
	end
end

return L_1_.main(...)
