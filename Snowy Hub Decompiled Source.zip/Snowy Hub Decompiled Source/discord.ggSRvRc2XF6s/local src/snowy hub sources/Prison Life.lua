local L_1_ = game:GetService("Players")
local L_2_ = game:GetService("RunService")
local L_3_ = game:GetService("UserInputService")
local L_4_ = game:GetService("TeleportService")
local L_5_ = game:GetService("HttpService")
local L_6_ = game:GetService("ReplicatedStorage")
local L_7_ = game:GetService("Workspace")
local L_8_ = game:GetService("Teams")

local L_9_ = L_1_.LocalPlayer

local function L_10_func()
	getgenv().PlayerModifierLoop:Disconnect()
end

local function L_11_func()
	local L_58_ = L_9_.Character
	if not L_58_ then
		return
	end
	local L_59_ = L_58_:FindFirstChild("Humanoid")
	if not L_59_ then
		return
	end

	if not L_58_:FindFirstChild("HumanoidRootPart") then
		return
	end
	if getgenv().GodModeEnabled then
		if L_59_.MaxHealth ~= math.huge then
			L_59_.MaxHealth = math.huge
		end
		if L_59_.Health ~= math.huge then
			L_59_.Health = math.huge
		end
		pcall(function()
			L_59_:SetStateEnabled(Enum.HumanoidStateType.Dead, false)
		end)
	end
end

local function L_12_func(L_60_arg0)
	pcall(L_11_func)
end

local function L_13_func(L_61_arg0)
	getgenv().WalkSpeedValue = L_61_arg0
	local L_62_ = L_9_.Character
	local L_63_ = L_62_ and L_62_:FindFirstChild("Humanoid")
	if L_63_ then
		L_62_.Humanoid.WalkSpeed = L_61_arg0
	end
end

local function L_14_func(L_64_arg0)
	getgenv().JumpPowerValue = L_64_arg0
	local L_65_ = L_9_.Character
	local L_66_ = L_65_ and L_65_:FindFirstChild("Humanoid")
	if L_66_ then
		L_65_.Humanoid.JumpPower = L_64_arg0
	end
end

local function L_15_func(L_67_arg0)
	game.Workspace.Gravity = L_67_arg0
end

local function L_16_func()
	local L_68_ = L_9_.Character
	local L_69_ = L_68_ and L_68_:FindFirstChild("Humanoid")
	if L_69_ then

		L_68_.Humanoid.MaxHealth = 100
		L_68_.Humanoid.Health = 100
		L_68_.Humanoid:SetStateEnabled(Enum.HumanoidStateType.Dead, true)
	end
end

local function L_17_func(L_70_arg0)
	getgenv().GodModeEnabled = L_70_arg0
	if not L_70_arg0 then
		pcall(L_16_func)
	end
end

local L_18_ = nil
local L_19_ = nil

local function L_20_func()
	if L_19_ ~= false then
		wait(0.21)
		return
	end
	local L_71_ = L_9_.Character
	if L_71_ then
		for L_72_forvar0, L_73_forvar1 in pairs(L_71_:GetDescendants()) do
			if L_73_forvar1:IsA("BasePart")
                and L_73_forvar1.CanCollide
                and L_73_forvar1.Name ~= floatName
            then
				L_73_forvar1.CanCollide = false
			end
		end
	end

	wait(0.21)
end

local function L_21_func()
	L_19_ = false
	L_18_ = L_2_.Stepped:Connect(L_20_func)
end

local function L_22_func()
	if L_18_ then
		L_18_:Disconnect()
	end
	L_19_ = true
end

local function L_23_func(L_74_arg0)
	if L_74_arg0 then
		L_21_func()
	else
		L_22_func()
	end
end

local L_24_ = false

local function L_25_func()
	if L_24_ then
		local L_75_ = L_9_.Character
		local L_76_ = L_75_ and L_75_:FindFirstChild("Humanoid")
		if L_76_ then

			L_75_.Humanoid:ChangeState("Jumping")
		end
	end
end

local function L_26_func(L_77_arg0)
	L_24_ = L_77_arg0

	L_3_.JumpRequest:Connect(L_25_func)
end

local function L_27_func(L_78_arg0)
	game.Workspace.CurrentCamera.FieldOfView = L_78_arg0
end

local function L_28_func(L_79_arg0)
	if L_79_arg0 then
		game.Lighting.Ambient = Color3.new(1, 1, 1)
		game.Lighting.ColorShift_Bottom = Color3.new(1, 1, 1)
		game.Lighting.ColorShift_Top = Color3.new(1, 1, 1)
		game.Lighting.GlobalShadows = false
	else

		game.Lighting.Ambient = Color3.fromRGB(128, 128, 128)
		game.Lighting.GlobalShadows = true
	end
end

local function L_29_func(L_80_arg0, L_81_arg1, L_82_arg2)
	if not L_80_arg0 then
		for L_83_forvar0, L_84_forvar1 in pairs(L_82_arg2) do
			if L_84_forvar1 and L_84_forvar1.Parent then
				L_84_forvar1:Destroy()
			end
		end

		return {}
	end
	for L_85_forvar0, L_86_forvar1 in pairs(L_1_:GetPlayers()) do
		if L_86_forvar1 ~= L_9_ and L_86_forvar1.Character then
			local L_87_ = Instance.new("Highlight")
			L_87_.Parent = L_86_forvar1.Character
			L_87_.FillColor = L_81_arg1.AccentColor

			L_87_.OutlineColor = L_81_arg1.SecondaryColor
			L_87_.FillTransparency = 0.5
			table.insert(L_82_arg2, L_87_)
		end
	end
	return L_82_arg2
end

local function L_30_func(L_88_arg0)
	local L_89_ = L_88_arg0.Character.HumanoidRootPart
	L_89_.Size = Vector3.new(_G.HeadSize, _G.HeadSize, _G.HeadSize)
	L_89_.Transparency = 0.7
	L_89_.BrickColor = BrickColor.new("Really blue")
	L_89_.Material = "Neon"
	L_89_.CanCollide = false
end

local function L_31_func()
	if not _G.Disabled then
		return
	end
	local L_90_ = game:GetService("Players")
	for L_91_forvar0, L_92_forvar1 in next, L_90_:GetPlayers() do
		if L_92_forvar1.Name ~= L_90_.LocalPlayer.Name then
			pcall(function()
				L_30_func(L_92_forvar1)
			end)
		end
	end
end

local function L_32_func(L_93_arg0)
	_G.HeadSize = L_93_arg0

	_G.Disabled = true
	game:GetService("RunService").RenderStepped:connect(L_31_func)
end

local function L_33_func()
	local L_94_ = L_9_.Backpack
	local L_95_ = Instance.new("HopperBin", L_94_)
	L_95_.BinType = "Clone"
	local L_96_ = Instance.new("HopperBin", L_94_)
	L_96_.BinType = "Hammer"
	local L_97_ = Instance.new("HopperBin", L_94_)
	L_97_.BinType = "Grab"
end

local function L_34_func()
	local L_98_ = L_1_:GetPlayers()
	if #L_98_ <= 1 then
		return
	end
	local L_99_
	repeat
		L_99_ = L_98_[math.random(1, #L_98_)]
	until L_99_.Name ~= L_9_.Name
	local L_100_ = L_99_.Character
	if not L_100_ then
		return
	end
	local L_101_ = L_100_:FindFirstChild("HumanoidRootPart")
	if not L_101_ then
		return
	end
	local L_102_ = L_9_.Character
	if not L_102_ then
		return
	end
	local L_103_ = L_102_:FindFirstChild("HumanoidRootPart")
	if not L_103_ then
		return
	end
	L_103_.CFrame = L_101_.CFrame * CFrame.new(0, 0, 3)
end

local function L_35_func()
	L_4_:TeleportToPlaceInstance(
        game.PlaceId,
        game.JobId,
        L_9_
    )
end

local function L_36_func(L_104_arg0, L_105_arg1)
	local L_106_ = L_105_arg1 and ("&cursor=" .. L_105_arg1) or ""
	return L_5_:JSONDecode(game:HttpGet(L_104_arg0 .. L_106_))
end

local function L_37_func()
	local L_107_ = game.PlaceId
	local L_108_ =
        "https://games.roblox.com/v1/games/"
        .. tostring(L_107_)
        .. "/servers/Public?sortOrder=Asc&limit=100"
	local L_109_ = nil
	local L_110_ = nil
	repeat
		local L_111_ = L_36_func(L_108_, L_109_)

		L_110_ = L_111_.data[1]
		L_109_ = L_111_.nextPageCursor
	until L_110_ ~= nil
	L_4_:TeleportToPlaceInstance(
        L_107_,
        L_110_.id,
        L_9_
    )
end

local function L_38_func(L_112_arg0)
	local L_113_ = getconnections or get_signal_cons
	if not L_112_arg0 or not L_113_ then
		return
	end
	for L_114_forvar0, L_115_forvar1 in pairs(L_113_(L_9_.Idled)) do
		if L_115_forvar1.Disable then
			L_115_forvar1.Disable(L_115_forvar1)
		elseif L_115_forvar1.Disconnect then
			L_115_forvar1.Disconnect(L_115_forvar1)
		end
	end
end

local function L_39_func(L_116_arg0)
	local L_117_ = L_116_arg0.FOVRadius
	local L_118_ = nil
	local L_119_ =
        game:GetService("UserInputService"):GetMouseLocation()
	for L_120_forvar0, L_121_forvar1 in pairs(L_1_:GetPlayers()) do
		if L_121_forvar1 == L_9_ then
			continue
		end
		local L_122_ = L_121_forvar1.Character
		if not L_122_ then
			continue
		end
		if not L_122_:FindFirstChild(L_116_arg0.TargetPart) then
			continue
		end
		local L_123_ = L_122_:FindFirstChild("Humanoid")
		if not L_123_ or L_123_.Health <= 0 then
			continue
		end

		if L_116_arg0.TeamCheck then
			local L_127_ = L_121_forvar1.Team == L_9_.Team

		end
		local L_124_, L_125_ =
            game.Workspace.CurrentCamera:WorldToViewportPoint(
                L_122_[L_116_arg0.TargetPart].Position
            )
		if not L_125_ then
			continue
		end
		local L_126_ =
            (
                Vector2.new(L_124_.X, L_124_.Y)
                - L_119_
            ).Magnitude
		if L_126_ < L_117_ then
			L_117_ = L_126_
			L_118_ = L_121_forvar1
		end
	end
	return L_118_
end

local function L_40_func(L_128_arg0, L_129_arg1)
	if L_128_arg0.ShowFOV then
		L_129_arg1.Position =
            game:GetService("UserInputService"):GetMouseLocation()
		L_129_arg1.Radius = L_128_arg0.FOVRadius
		L_129_arg1.Visible = true
	else
		L_129_arg1.Visible = false
	end
	if not L_128_arg0.Enabled then
		return
	end
	local L_130_ = game:GetService("UserInputService")
	if not L_130_:IsMouseButtonPressed(Enum.UserInputType.MouseButton2) then
		return
	end
	local L_131_ = L_39_func(L_128_arg0)
	if not L_131_ or not L_131_.Character then
		return
	end
	local L_132_ = L_131_.Character:FindFirstChild(L_128_arg0.TargetPart)
	if not L_132_ then
		return
	end
	local L_133_ = game.Workspace.CurrentCamera
	local L_134_ =
        CFrame.new(L_133_.CFrame.Position, L_132_.Position)
	L_133_.CFrame =
        L_133_.CFrame:Lerp(L_134_, L_128_arg0.Smoothness)
end

local function L_41_func(L_135_arg0, L_136_arg1, L_137_arg2)
	L_135_arg0:Notify(L_136_arg1, L_137_arg2, 3)
end

local function L_42_func(L_138_arg0, L_139_arg1, L_140_arg2)
	pcall(function()
		L_41_func(L_138_arg0, L_139_arg1, L_140_arg2)
	end)
end

local function L_43_func(
    L_141_arg0,
    L_142_arg1,
    L_143_arg2,
    L_144_arg3,
    L_145_arg4,
    L_146_arg5
)
	local L_147_ = L_141_arg0.Character
	local L_148_ =
        L_147_
        and L_147_:FindFirstChild("HumanoidRootPart")
	if not L_148_ then
		return
	end
	local L_149_ = L_142_arg1:FindFirstChild("Prison_ITEMS")
	local L_150_ =
        L_149_
        and L_142_arg1.Prison_ITEMS:FindFirstChild("giver")
	if not L_150_ then
		return
	end
	local L_151_ = L_150_:FindFirstChild(L_143_arg2)
	if not L_151_ then
		for L_157_forvar0, L_158_forvar1 in ipairs(L_150_:GetChildren()) do
			local L_159_ =
                L_158_forvar1.Name:lower():find(L_143_arg2:lower())
			if L_159_ or L_158_forvar1:FindFirstChild(L_144_arg3) then
				L_151_ = L_158_forvar1
				break
			end
		end
	end
	local L_152_ =
        L_151_
        and L_151_:FindFirstChild(L_144_arg3)
	if not L_152_ or not L_148_ then
		return
	end

	local L_153_ = L_148_.CFrame
	L_148_.CFrame = L_152_.CFrame
	task.wait(0.2)
	local L_154_ = {
		L_152_
	}
	local L_155_ = L_145_arg4:FindFirstChild("Remotes")
	local L_156_ =
        L_155_
        and L_145_arg4.Remotes:FindFirstChild("InteractWithItem")
	if L_156_ then
		L_156_:InvokeServer(unpack(L_154_))
	end
	task.wait(0.2)
	L_148_.CFrame = L_153_
	L_42_func(
        L_146_arg5,
        "Weapon Giver",
        "Successfully obtained " .. L_143_arg2 .. "!"
    )
end

local function L_44_func(L_160_arg0, L_161_arg1, L_162_arg2)
	pcall(function()
		L_43_func(
            L_9_,
            L_160_arg0,
            "MP5",
            "Meshes/MP5 (2)",
            L_161_arg1,
            L_162_arg2
        )
	end)
end

local function L_45_func(L_163_arg0, L_164_arg1, L_165_arg2)
	pcall(function()
		L_43_func(
            L_9_,
            L_163_arg0,
            "AK-47",
            "Meshes/AK47_7",
            L_164_arg1,
            L_165_arg2
        )
	end)
end

local function L_46_func(L_166_arg0, L_167_arg1, L_168_arg2)
	pcall(function()
		L_43_func(
            L_9_,
            L_166_arg0,
            "Remington 870",
            "Meshes/r870_2",
            L_167_arg1,
            L_168_arg2
        )
	end)
end

local function L_47_func(L_169_arg0, L_170_arg1)
	local L_171_ = L_9_.Character
	local L_172_ =
        L_171_
        and L_171_:FindFirstChild("HumanoidRootPart")
	local L_173_ = L_169_arg0:FindFirstChild("Criminals Spawn")
	local L_174_ =
        L_173_
        and L_169_arg0["Criminals Spawn"]:FindFirstChild("SpawnLocation")
	if not L_172_ or not L_174_ then
		return
	end
	local L_175_ = L_172_.CFrame
	L_172_.CFrame = L_174_.CFrame
	task.wait(2)
	L_172_.CFrame = L_175_
	L_42_func(
        L_170_arg1,
        "Teams",
        "Successfully changed team to Criminal!"
    )
end

local function L_48_func(L_176_arg0, L_177_arg1)
	local L_178_ = L_176_arg0:FindFirstChild("Remotes")
	local L_179_ =
        L_178_
        and L_176_arg0.Remotes:FindFirstChild("ArrestPlayer")
	if L_179_ then
		L_179_:InvokeServer(L_177_arg1, 1)
	end
end

local function L_49_func(
    L_180_arg0,
    L_181_arg1,
    L_182_arg2
)
	local L_183_ = L_180_arg0.Character
	local L_184_ =
        L_183_
        and L_183_:FindFirstChild("HumanoidRootPart")
	if not L_184_ then
		return
	end
	for L_185_forvar0, L_186_forvar1 in pairs(L_181_arg1:GetPlayers()) do
		if L_186_forvar1 ~= L_180_arg0 then
			local L_187_ = L_186_forvar1.Character
			local L_188_ =
                L_187_
                and L_187_:FindFirstChild("HumanoidRootPart")
			if L_188_
                and (L_184_.Position - L_188_.Position).Magnitude <= 30
            then

				pcall(function()
					L_48_func(L_182_arg2, L_186_forvar1)
				end)
			end
		end
	end
end

local function L_50_func(L_189_arg0, L_190_arg1)
	local L_191_ =
        L_189_arg0.Character
        or L_189_arg0.CharacterAdded:Wait()
	local L_192_ = L_191_:FindFirstChild("AntiJump")
	if L_192_ then
		L_191_.AntiJump:Destroy()
		print("Antijump Destroyed")
	end
	local L_193_ = L_190_arg1:FindFirstChild("BOUNDARY")
	if L_193_ then
		L_190_arg1.BOUNDARY:Destroy()
		print("Boundaries destroyed.")
	end
end

local function L_51_func(L_194_arg0, L_195_arg1)
	pcall(function()
		L_50_func(L_194_arg0, L_195_arg1)
	end)
	L_194_arg0.CharacterAdded:Connect(function(L_196_arg0)
		task.wait(0.5)
		pcall(function()
			local L_197_ = L_196_arg0:FindFirstChild("AntiJump")
			if L_197_ then
				L_196_arg0.AntiJump:Destroy()
				print("Antijump Destroyed")
			end
		end)
	end)
end

local L_52_ = nil

local function L_53_func(
    L_198_arg0,
    L_199_arg1,
    L_200_arg2,
    L_201_arg3,
    L_202_arg4,
    L_203_arg5
)
	L_199_arg1.ArrestAura = L_198_arg0
	if not L_198_arg0 then
		if L_52_ then
			L_52_:Disconnect()
			L_52_ = nil
		end
		return
	end
	L_52_ =
        L_200_arg2.Heartbeat:Connect(function()
		L_49_func(
                L_201_arg3,
                L_202_arg4,
                L_203_arg5
            )
	end)
end

local function L_54_func(L_204_arg0)
	local L_205_ = L_204_arg0.Character
	local L_206_ =
        L_205_
        and L_205_:FindFirstChildOfClass("Humanoid")
	if not L_206_ then
		return true
	end
	return L_206_.Health <= 0
end

local function L_55_func(
    L_207_arg0,
    L_208_arg1,
    L_209_arg2,
    L_210_arg3
)
	local L_211_ = L_207_arg0.Character
	local L_212_ =
        L_211_
        and L_211_:FindFirstChild("HumanoidRootPart")
	if not L_212_ then
		return
	end
	local L_213_ = game:GetService("Teams")
	local L_214_ = {}
	for L_215_forvar0, L_216_forvar1 in pairs(L_208_arg1:GetPlayers()) do
		if L_216_forvar1 ~= L_207_arg0 and L_216_forvar1.Team == L_213_.Criminals then
			table.insert(L_214_, L_216_forvar1)
		end
	end
	if #L_214_ == 0 then
		L_42_func(L_209_arg2, "Auto Arrest", "No criminals found online.")
		return
	end
	L_42_func(
        L_209_arg2,
        "Auto Arrest",
        "Arresting " .. tostring(#L_214_) .. " criminals..."
    )
	for L_217_forvar0, L_218_forvar1 in pairs(L_214_) do
		if L_54_func(L_207_arg0) then
			break
		end
		local L_219_ = L_218_forvar1.Character
		local L_220_ =
            L_219_
            and L_219_:FindFirstChild("HumanoidRootPart")
		if L_220_ then
			local L_221_ = tick()
			local L_222_ = false
			while (tick() - L_221_) < 3 and not L_222_ do
				if L_54_func(L_207_arg0) then
					return
				end
				L_212_.CFrame =
                    CFrame.new(
                        L_220_.Position
                            - L_220_.CFrame.LookVector * 3,
                        L_220_.Position
                    )
				pcall(function()
					local L_223_ =
                        L_210_arg3:FindFirstChild("Remotes")
					local L_224_ =
                        L_223_
                        and L_210_arg3.Remotes
                            :FindFirstChild("ArrestPlayer")
					if L_224_ then
						local L_225_ =
                            L_224_:InvokeServer(L_218_forvar1, 1)
						if L_225_ ~= nil then
							L_222_ = true
						end
					end
				end)
				if L_218_forvar1.Team ~= L_213_.Criminals then
					L_222_ = true
				end
				task.wait(0.05)
			end
			if L_54_func(L_207_arg0) then
				return
			end
			L_212_.CFrame = CFrame.new(872, 40, 2344)
			task.wait(20)
		end
	end
	L_42_func(L_209_arg2, "Auto Arrest", "Finished auto arrest cycle!")
end

local function L_56_func()
	local L_226_ =
        game:HttpGet(
            "https://raw.githubusercontent.com/Exunys/AirHub/main/AirHub.lua"
        )
	loadstring(L_226_)()
end

local function L_57_func()
	local L_227_ =
        game:HttpGet(
            "https://raw.githubusercontent.com/edgeiy/infiniteyield/master/source"
        )
	loadstring(L_227_)()
end

return {
	Universal = {
		SetWalkSpeed = L_13_func,
		SetJumpPower = L_14_func,
		SetGravity = L_15_func,
		SetGodMode = L_17_func,
		SetNoclip = L_23_func,
		SetInfiniteJump = L_26_func,
		SetCameraFOV = L_27_func,
		SetFullbright = L_28_func,
		SetPlayerESP = L_29_func,
		SetHitboxSize = L_32_func,
		GiveBtools = L_33_func,
		TeleportToRandomPlayer = L_34_func,
		RejoinServer = L_35_func,
		ServerHop = L_37_func,
		SetAntiAFK = L_38_func,
		FindClosestAimbotTarget = L_39_func,
		AimbotRenderStep = L_40_func,
	},
	PrisonLife = {
		SetupCleanup = L_51_func,
		GetMP5 = L_44_func,
		GetAK47 = L_45_func,
		GetRemington870 = L_46_func,
		BecomeCriminal = L_47_func,
		SetArrestAura = L_53_func,
		AutoArrestAll = L_55_func,
		LoadAirHubUnsafe = L_56_func,
		LoadInfiniteYieldUnsafe = L_57_func,
	},
}
