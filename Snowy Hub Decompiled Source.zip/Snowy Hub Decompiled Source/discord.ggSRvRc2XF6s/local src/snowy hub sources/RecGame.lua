local L_1_ = table.pack
local L_2_ = table.unpack
local L_3_ = getfenv
local L_4_ = setfenv

local L_5_
do
	local L_16_, L_17_ = pcall(function()
		if type(getgenv) == "function" then
			return getgenv()
		end
		if type(L_3_) == "function" then
			return L_3_(0)
		end
		return _G
	end)
	L_5_ = L_16_ and L_17_ or _G
end

local L_6_ = setmetatable({}, {
	__mode = "k"
})
local L_7_
local L_8_

local function L_9_func()
	return L_5_
end

L_7_ = function(L_18_arg0)
	if type(L_18_arg0) == "function" then
		local L_19_ = L_6_[L_18_arg0]
		if L_19_ ~= nil then
			return L_19_[1] or L_5_
		end
	end
	if L_18_arg0 == nil or type(L_18_arg0) == "number" then
		return L_5_
	end
	if type(L_3_) == "function" then
		local L_20_, L_21_ = pcall(L_3_, L_18_arg0)
		if L_20_ then
			return L_21_
		end
	end
	return L_5_
end

L_8_ = function(L_22_arg0, L_23_arg1)
	if type(L_22_arg0) == "function" then
		local L_24_ = L_6_[L_22_arg0]
		if L_24_ ~= nil then
			L_24_[1] = L_23_arg1
			return L_22_arg0
		end
	end
	if type(L_4_) == "function" then
		return L_4_(L_22_arg0, L_23_arg1)
	end
	return L_22_arg0
end

local function L_10_func(L_25_arg0, L_26_arg1)
	local L_27_ = L_25_arg0 and L_25_arg0[1] or nil
	if L_27_ ~= nil then
		return L_27_[L_26_arg1]
	end
	if L_26_arg1 == "getgenv" then
		return L_9_func
	end
	if L_26_arg1 == "getfenv" then
		return L_7_
	end
	if L_26_arg1 == "setfenv" then
		return L_8_
	end
	if L_26_arg1 == "_G" then
		return L_5_
	end
	return L_5_[L_26_arg1]
end

local function L_11_func(L_28_arg0, L_29_arg1, L_30_arg2)
	local L_31_ = L_28_arg0 and L_28_arg0[1] or nil
	if L_31_ ~= nil then
		L_31_[L_29_arg1] = L_30_arg2
	else
		L_5_[L_29_arg1] = L_30_arg2
	end
end

local function L_12_func(L_32_arg0, L_33_arg1, L_34_arg2, L_35_arg3)
	local L_36_ = L_32_arg0(L_34_arg2)
	local L_37_ = type(L_36_)
	local L_38_ = nil
	local L_39_ = nil
	local L_40_ = nil
	if L_37_ == "table" or L_37_ == "userdata" then
		L_38_ = getmetatable(L_36_)
		if type(L_38_) == "table" then
			L_39_ = L_38_.__iter
			L_40_ = L_38_.__call
		end
	end
	if L_39_ ~= nil then
		local L_43_ = L_1_(L_39_(L_36_))
		L_36_ = L_43_[1]
		if L_36_ == nil then
			error("recovered __iter returned nil iterator")
		end
		L_33_arg1(L_34_arg2, L_36_)
		L_33_arg1(L_34_arg2 + 1, L_43_[2])
		L_33_arg1(L_34_arg2 + 2, L_43_[3])
	end
	local L_41_
	if L_37_ == "table" and L_39_ == nil and L_40_ == nil then
		L_41_ = L_1_(next(L_36_, L_32_arg0(L_34_arg2 + 2)))
	else
		L_41_ = L_1_(L_36_(L_32_arg0(L_34_arg2 + 1), L_32_arg0(L_34_arg2 + 2)))
	end
	local L_42_ = L_41_[1]
	if L_42_ == nil then
		return false
	end
	L_33_arg1(L_34_arg2 + 2, L_42_)
	for L_44_forvar0 = 1, L_35_arg3 do
		L_33_arg1(L_34_arg2 + 2 + L_44_forvar0, L_41_[L_44_forvar0])
	end
	return true
end

local L_13_ = {}

local function L_14_func(L_45_arg0, L_46_arg1, L_47_arg2)
	local L_48_ = {
		L_46_arg1 and L_46_arg1[1] or nil
	}
	local L_49_
	L_49_ = function(...)
		return L_45_arg0(L_47_arg2, L_48_, ...)
	end
	L_6_[L_49_] = L_48_
	return L_49_
end

L_13_.fn_001_premTag = function(L_50_arg0, L_51_arg1, L_52_arg2, L_53_arg3, L_54_arg4)
	L_54_arg4 = L_52_arg2
	L_53_arg3 = L_10_func(L_51_arg1, "tostring")
	L_53_arg3 = L_53_arg3(L_54_arg4)
	return L_53_arg3
end

L_13_.fn_002_isPremiumUser = function(L_55_arg0, L_56_arg1, L_57_arg2)
	L_57_arg2 = true
	return L_57_arg2
end

L_13_.fn_003_corner = function(L_58_arg0, L_59_arg1, L_60_arg2, L_61_arg3, L_62_arg4, L_63_arg5, L_64_arg6, L_65_arg7, L_66_arg8, L_67_arg9, L_68_arg10, L_69_arg11)
	L_63_arg5 = L_61_arg3
	L_62_arg4 = L_10_func(L_59_arg1, "typeof")
	L_62_arg4 = L_62_arg4(L_63_arg5)
	L_68_arg10 = "Instance"
	L_69_arg11 = (L_62_arg4 == L_68_arg10)
	if L_69_arg11 then
		L_62_arg4 = L_10_func(L_59_arg1, "Instance")
		L_62_arg4 = L_62_arg4.new
		L_63_arg5 = "UICorner"
		L_62_arg4 = L_62_arg4(L_63_arg5)
		L_63_arg5 = L_10_func(L_59_arg1, "UDim")
		L_63_arg5 = L_63_arg5.new
		L_64_arg6 = 0
		L_67_arg9 = L_60_arg2
		L_66_arg8 = L_10_func(L_59_arg1, "tonumber")
		L_66_arg8 = L_66_arg8(L_67_arg9)
		L_65_arg7 = L_66_arg8
		if not L_65_arg7 then
			L_65_arg7 = 8
		end
		L_63_arg5 = L_63_arg5(L_64_arg6, L_65_arg7)
		L_62_arg4.CornerRadius = L_63_arg5
		L_62_arg4.Parent = L_61_arg3
		return L_62_arg4
	else
		L_62_arg4 = nil
		return L_62_arg4
	end
end

L_13_.fn_004_stroke = function(L_70_arg0, L_71_arg1, L_72_arg2, L_73_arg3, L_74_arg4, L_75_arg5, L_76_arg6, L_77_arg7, L_78_arg8, L_79_arg9, L_80_arg10, L_81_arg11)
	L_76_arg6 = L_74_arg4
	L_75_arg5 = L_10_func(L_71_arg1, "typeof")
	L_75_arg5 = L_75_arg5(L_76_arg6)
	L_80_arg10 = "Instance"
	L_81_arg11 = (L_75_arg5 == L_80_arg10)
	if L_81_arg11 then
		L_75_arg5 = L_10_func(L_71_arg1, "Instance")
		L_75_arg5 = L_75_arg5.new
		L_76_arg6 = "UIStroke"
		L_75_arg5 = L_75_arg5(L_76_arg6)
		L_76_arg6 = L_72_arg2
		if not L_76_arg6 then
			L_76_arg6 = L_10_func(L_71_arg1, "Color3")
			L_76_arg6 = L_76_arg6.fromRGB
			L_77_arg7 = 85
			L_78_arg8 = 213
			L_79_arg9 = 254
			L_76_arg6 = L_76_arg6(L_77_arg7, L_78_arg8, L_79_arg9)
		end
		L_75_arg5.Color = L_76_arg6
		L_78_arg8 = L_73_arg3
		L_77_arg7 = L_10_func(L_71_arg1, "tonumber")
		L_77_arg7 = L_77_arg7(L_78_arg8)
		L_76_arg6 = L_77_arg7
		if not L_76_arg6 then
			L_76_arg6 = 1
		end
		L_75_arg5.Thickness = L_76_arg6
		L_75_arg5.Parent = L_74_arg4
		return L_75_arg5
	else
		L_75_arg5 = nil
		return L_75_arg5
	end
end

L_13_.fn_005_gradient = function(L_82_arg0, L_83_arg1, L_84_arg2, L_85_arg3, L_86_arg4, L_87_arg5, L_88_arg6, L_89_arg7, L_90_arg8, L_91_arg9, L_92_arg10, L_93_arg11, L_94_arg12, L_95_arg13, L_96_arg14)
	L_89_arg7 = L_84_arg2
	L_88_arg6 = L_10_func(L_83_arg1, "typeof")
	L_88_arg6 = L_88_arg6(L_89_arg7)
	L_95_arg13 = "Instance"
	L_96_arg14 = (L_88_arg6 == L_95_arg13)
	if L_96_arg14 then
		L_88_arg6 = L_10_func(L_83_arg1, "Instance")
		L_88_arg6 = L_88_arg6.new
		L_89_arg7 = "UIGradient"
		L_88_arg6 = L_88_arg6(L_89_arg7)
		L_89_arg7 = L_10_func(L_83_arg1, "ColorSequence")
		L_89_arg7 = L_89_arg7.new
		L_90_arg8 = L_85_arg3
		if not L_90_arg8 then
			L_90_arg8 = L_10_func(L_83_arg1, "Color3")
			L_90_arg8 = L_90_arg8.fromRGB
			L_91_arg9 = 18
			L_92_arg10 = 24
			L_93_arg11 = 64
			L_90_arg8 = L_90_arg8(L_91_arg9, L_92_arg10, L_93_arg11)
		end
		L_91_arg9 = L_86_arg4
		if not L_91_arg9 then
			L_91_arg9 = L_85_arg3
			if not L_91_arg9 then
				L_91_arg9 = L_10_func(L_83_arg1, "Color3")
				L_91_arg9 = L_91_arg9.fromRGB
				L_92_arg10 = 24
				L_93_arg11 = 32
				L_94_arg12 = 85
				L_91_arg9 = L_91_arg9(L_92_arg10, L_93_arg11, L_94_arg12)
			end
		end
		L_89_arg7 = L_89_arg7(L_90_arg8, L_91_arg9)
		L_88_arg6.Color = L_89_arg7
		L_91_arg9 = L_87_arg5
		L_90_arg8 = L_10_func(L_83_arg1, "tonumber")
		L_90_arg8 = L_90_arg8(L_91_arg9)
		L_89_arg7 = L_90_arg8
		if not L_89_arg7 then
			L_89_arg7 = 0
		end
		L_88_arg6.Rotation = L_89_arg7
		L_88_arg6.Parent = L_84_arg2
		return L_88_arg6
	else
		L_88_arg6 = nil
		return L_88_arg6
	end
end

L_13_.fn_006_shadow = function(L_97_arg0, L_98_arg1, L_99_arg2, L_100_arg3, L_101_arg4, L_102_arg5, L_103_arg6, L_104_arg7, L_105_arg8, L_106_arg9, L_107_arg10)
	L_101_arg4 = L_99_arg2
	L_100_arg3 = L_10_func(L_98_arg1, "typeof")
	L_100_arg3 = L_100_arg3(L_101_arg4)
	L_106_arg9 = "Instance"
	L_107_arg10 = (L_100_arg3 == L_106_arg9)
	if L_107_arg10 then
		L_100_arg3 = L_10_func(L_98_arg1, "Instance")
		L_100_arg3 = L_100_arg3.new
		L_101_arg4 = "ImageLabel"
		L_100_arg3 = L_100_arg3(L_101_arg4)
		L_101_arg4 = "SnowyShadow"
		L_100_arg3.Name = L_101_arg4
		L_101_arg4 = 1
		L_100_arg3.BackgroundTransparency = L_101_arg4
		L_101_arg4 = L_10_func(L_98_arg1, "UDim2")
		L_101_arg4 = L_101_arg4.new
		L_102_arg5 = 0
		L_103_arg6 = -18
		L_104_arg7 = 0
		L_105_arg8 = -18
		L_101_arg4 = L_101_arg4(L_102_arg5, L_103_arg6, L_104_arg7, L_105_arg8)
		L_100_arg3.Position = L_101_arg4
		L_101_arg4 = L_10_func(L_98_arg1, "UDim2")
		L_101_arg4 = L_101_arg4.new
		L_102_arg5 = 1
		L_103_arg6 = 36
		L_104_arg7 = 1
		L_105_arg8 = 36
		L_101_arg4 = L_101_arg4(L_102_arg5, L_103_arg6, L_104_arg7, L_105_arg8)
		L_100_arg3.Size = L_101_arg4
		L_101_arg4 = "rbxassetid://6015897843"
		L_100_arg3.Image = L_101_arg4
		L_101_arg4 = L_10_func(L_98_arg1, "Color3")
		L_101_arg4 = L_101_arg4.new
		L_102_arg5 = 0
		L_103_arg6 = 0
		L_104_arg7 = 0
		L_101_arg4 = L_101_arg4(L_102_arg5, L_103_arg6, L_104_arg7)
		L_100_arg3.ImageColor3 = L_101_arg4
		L_101_arg4 = 0.42
		L_100_arg3.ImageTransparency = L_101_arg4
		L_101_arg4 = L_10_func(L_98_arg1, "Enum")
		L_101_arg4 = L_101_arg4.ScaleType
		L_101_arg4 = L_101_arg4.Slice
		L_100_arg3.ScaleType = L_101_arg4
		L_101_arg4 = L_10_func(L_98_arg1, "Rect")
		L_101_arg4 = L_101_arg4.new
		L_102_arg5 = 49
		L_103_arg6 = 49
		L_104_arg7 = 450
		L_105_arg8 = 450
		L_101_arg4 = L_101_arg4(L_102_arg5, L_103_arg6, L_104_arg7, L_105_arg8)
		L_100_arg3.SliceCenter = L_101_arg4
		L_101_arg4 = 0
		L_100_arg3.ZIndex = L_101_arg4
		L_100_arg3.Parent = L_99_arg2
		return L_100_arg3
	else
		L_100_arg3 = nil
		return L_100_arg3
	end
end

L_13_.fn_007_tw = function(L_108_arg0, L_109_arg1, L_110_arg2, L_111_arg3, L_112_arg4, L_113_arg5, L_114_arg6, L_115_arg7, L_116_arg8, L_117_arg9, L_118_arg10, L_119_arg11, L_120_arg12, L_121_arg13, L_122_arg14, L_123_arg15)
	L_116_arg8 = L_110_arg2
	L_115_arg7 = L_10_func(L_109_arg1, "typeof")
	L_115_arg7 = L_115_arg7(L_116_arg8)
	L_122_arg14 = "Instance"
	L_123_arg15 = (L_115_arg7 == L_122_arg14)
	if L_123_arg15 then
		L_116_arg8 = L_111_arg3
		L_115_arg7 = L_10_func(L_109_arg1, "type")
		L_115_arg7 = L_115_arg7(L_116_arg8)
		L_122_arg14 = "table"
		L_123_arg15 = (L_115_arg7 == L_122_arg14)
		if L_123_arg15 then
			L_115_arg7 = L_10_func(L_109_arg1, "game")
			L_117_arg9 = "TweenService"
			do
				local L_124_ = L_115_arg7;
				L_116_arg8 = L_124_;
				L_115_arg7 = L_124_.GetService
			end
			L_115_arg7 = L_115_arg7(L_116_arg8, L_117_arg9)
			L_117_arg9 = L_110_arg2
			L_118_arg10 = L_10_func(L_109_arg1, "TweenInfo")
			L_118_arg10 = L_118_arg10.new
			L_121_arg13 = L_112_arg4
			L_120_arg12 = L_10_func(L_109_arg1, "tonumber")
			L_120_arg12 = L_120_arg12(L_121_arg13)
			L_119_arg11 = L_120_arg12
			if not L_119_arg11 then
				L_119_arg11 = 0.2
			end
			L_120_arg12 = L_113_arg5
			if not L_120_arg12 then
				L_120_arg12 = L_10_func(L_109_arg1, "Enum")
				L_120_arg12 = L_120_arg12.EasingStyle
				L_120_arg12 = L_120_arg12.Quad
			end
			L_121_arg13 = L_114_arg6
			if not L_121_arg13 then
				L_121_arg13 = L_10_func(L_109_arg1, "Enum")
				L_121_arg13 = L_121_arg13.EasingDirection
				L_121_arg13 = L_121_arg13.Out
			end
			L_118_arg10 = L_118_arg10(L_119_arg11, L_120_arg12, L_121_arg13)
			L_119_arg11 = L_111_arg3
			do
				local L_125_ = L_115_arg7;
				L_116_arg8 = L_125_;
				L_115_arg7 = L_125_.Create
			end
			L_115_arg7 = L_115_arg7(L_116_arg8, L_117_arg9, L_118_arg10, L_119_arg11)
			do
				local L_126_ = L_115_arg7;
				L_117_arg9 = L_126_;
				L_116_arg8 = L_126_.Play
			end
			L_116_arg8(L_117_arg9)
			return L_115_arg7
		else
			L_115_arg7 = nil
			return L_115_arg7
		end
	end
	L_115_arg7 = nil
	return L_115_arg7
end

L_13_.fn_008_nagPremium = function(L_127_arg0, L_128_arg1, L_129_arg2)
	return
end

L_13_.fn_009_getGlobalG = function(L_130_arg0, L_131_arg1, L_132_arg2, L_133_arg3, L_134_arg4)
	L_133_arg3 = L_10_func(L_131_arg1, "_G")
	L_134_arg4 = L_130_arg0[1][1]
	L_132_arg2 = L_133_arg3[L_134_arg4]
	return L_132_arg2
end

L_13_.fn_010_getExecutorEnv = function(L_135_arg0, L_136_arg1, L_137_arg2, L_138_arg3, L_139_arg4)
	L_138_arg3 = L_10_func(L_136_arg1, "getgenv")
	L_138_arg3 = L_138_arg3()
	L_139_arg4 = L_135_arg0[1][1]
	L_137_arg2 = L_138_arg3[L_139_arg4]
	return L_137_arg2
end

L_13_.fn_011_resolveEnvironment = function(L_140_arg0, L_141_arg1, L_142_arg2, L_143_arg3, L_144_arg4, L_145_arg5, L_146_arg6, L_147_arg7, L_148_arg8, L_149_arg9)
	L_143_arg3 = L_10_func(L_141_arg1, "pcall")
	L_144_arg4 = L_14_func(L_13_.fn_009_getGlobalG, L_141_arg1, {
		{
			L_142_arg2
		}
	})
	L_143_arg3, L_144_arg4 = L_143_arg3(L_144_arg4)
	if L_143_arg3 then
		if not L_144_arg4 then
			L_145_arg5 = L_10_func(L_141_arg1, "pcall")
			L_146_arg6 = L_14_func(L_13_.fn_010_getExecutorEnv, L_141_arg1, {
				{
					L_142_arg2
				}
			})
			L_145_arg5, L_146_arg6 = L_145_arg5(L_146_arg6)
			if L_145_arg5 then
				if not L_146_arg6 then
					L_148_arg8 = L_10_func(L_141_arg1, "_ENV")
					if not L_148_arg8 then
						L_148_arg8 = L_10_func(L_141_arg1, "_G")
					end
					L_149_arg9 = L_142_arg2
					L_147_arg7 = L_10_func(L_141_arg1, "rawget")
					L_147_arg7 = L_147_arg7(L_148_arg8, L_149_arg9)
					return L_147_arg7
				else
					return L_146_arg6
				end
			end
			L_148_arg8 = L_10_func(L_141_arg1, "_ENV")
			if not L_148_arg8 then
				L_148_arg8 = L_10_func(L_141_arg1, "_G")
			end
			L_149_arg9 = L_142_arg2
			L_147_arg7 = L_10_func(L_141_arg1, "rawget")
			L_147_arg7 = L_147_arg7(L_148_arg8, L_149_arg9)
			return L_147_arg7
		else
			return L_144_arg4
		end
	end
	L_145_arg5 = L_10_func(L_141_arg1, "pcall")
	L_146_arg6 = L_14_func(L_13_.fn_010_getExecutorEnv, L_141_arg1, {
		{
			L_142_arg2
		}
	})
	L_145_arg5, L_146_arg6 = L_145_arg5(L_146_arg6)
	if L_145_arg5 then
		if not L_146_arg6 then
			L_148_arg8 = L_10_func(L_141_arg1, "_ENV")
			if not L_148_arg8 then
				L_148_arg8 = L_10_func(L_141_arg1, "_G")
			end
			L_149_arg9 = L_142_arg2
			L_147_arg7 = L_10_func(L_141_arg1, "rawget")
			L_147_arg7 = L_147_arg7(L_148_arg8, L_149_arg9)
			return L_147_arg7
		else
			return L_146_arg6
		end
	end
	L_148_arg8 = L_10_func(L_141_arg1, "_ENV")
	if not L_148_arg8 then
		L_148_arg8 = L_10_func(L_141_arg1, "_G")
	end
	L_149_arg9 = L_142_arg2
	L_147_arg7 = L_10_func(L_141_arg1, "rawget")
	L_147_arg7 = L_147_arg7(L_148_arg8, L_149_arg9)
	return L_147_arg7
end

L_13_.fn_012_probeExecutorGlobal = function(L_150_arg0, L_151_arg1, L_152_arg2, L_153_arg3, L_154_arg4)
	L_152_arg2 = L_10_func(L_151_arg1, "getgenv")
	L_152_arg2 = L_152_arg2()
	L_153_arg3 = L_150_arg0[1][1]
	L_154_arg4 = L_150_arg0[2][1]
	L_152_arg2[L_153_arg3] = L_154_arg4
	return
end

L_13_.fn_013_environmentHelper = function(L_155_arg0, L_156_arg1, L_157_arg2, L_158_arg3, L_159_arg4, L_160_arg5)
	L_159_arg4 = L_10_func(L_156_arg1, "pcall")
	L_160_arg5 = L_14_func(L_13_.fn_012_probeExecutorGlobal, L_156_arg1, {
		{
			L_157_arg2
		},
		{
			L_158_arg3
		}
	})
	L_159_arg4(L_160_arg5)
	return
end

L_13_.fn_014_installAntiDetectStubs = function(L_161_arg0, L_162_arg1, L_163_arg2, L_164_arg3, L_165_arg4)
	L_163_arg2 = L_10_func(L_162_arg1, "getgenv")
	L_163_arg2 = L_163_arg2()
	L_165_arg4 = L_10_func(L_162_arg1, "getgenv")
	L_165_arg4 = L_165_arg4()
	L_164_arg3 = L_165_arg4.__realGetRawMT
	if not L_164_arg3 then
		L_164_arg3 = L_161_arg0[1][1]
		L_165_arg4 = "getrawmetatable"
		L_164_arg3 = L_164_arg3(L_165_arg4)
	end
	L_163_arg2.__realGetRawMT = L_164_arg3
	L_163_arg2 = L_10_func(L_162_arg1, "getgenv")
	L_163_arg2 = L_163_arg2()
	L_165_arg4 = L_10_func(L_162_arg1, "getgenv")
	L_165_arg4 = L_165_arg4()
	L_164_arg3 = L_165_arg4.__realHookNamecall
	if not L_164_arg3 then
		L_164_arg3 = L_161_arg0[1][1]
		L_165_arg4 = "hookmetamethod"
		L_164_arg3 = L_164_arg3(L_165_arg4)
	end
	L_163_arg2.__realHookNamecall = L_164_arg3
	L_163_arg2 = L_10_func(L_162_arg1, "getgenv")
	L_163_arg2 = L_163_arg2()
	L_165_arg4 = L_10_func(L_162_arg1, "getgenv")
	L_165_arg4 = L_165_arg4()
	L_164_arg3 = L_165_arg4.__realNewCClosure
	if not L_164_arg3 then
		L_164_arg3 = L_161_arg0[1][1]
		L_165_arg4 = "newcclosure"
		L_164_arg3 = L_164_arg3(L_165_arg4)
	end
	L_163_arg2.__realNewCClosure = L_164_arg3
	return
end

L_13_.fn_015 = function(L_166_arg0, L_167_arg1, L_168_arg2)
	return
end

L_13_.fn_016_index = function(L_169_arg0, L_170_arg1, L_171_arg2)
	L_171_arg2 = L_14_func(L_13_.fn_015, L_170_arg1, {})
	return L_171_arg2
end

L_13_.fn_017_newindex = function(L_172_arg0, L_173_arg1, L_174_arg2)
	return
end

L_13_.fn_018_makeProxyTable = function(L_175_arg0, L_176_arg1, L_177_arg2, L_178_arg3, L_179_arg4, L_180_arg5, L_181_arg6)
	L_179_arg4 = {}
	L_180_arg5 = {}
	L_181_arg6 = L_14_func(L_13_.fn_016_index, L_176_arg1, {})
	L_180_arg5.__index = L_181_arg6
	L_181_arg6 = L_14_func(L_13_.fn_017_newindex, L_176_arg1, {})
	L_180_arg5.__newindex = L_181_arg6
	L_178_arg3 = L_10_func(L_176_arg1, "setmetatable")
	L_178_arg3 = L_178_arg3(L_179_arg4, L_180_arg5)
	return L_178_arg3
end

L_13_.fn_019 = function(L_182_arg0, L_183_arg1, L_184_arg2)
	L_184_arg2 = nil
	return L_184_arg2
end

L_13_.fn_020 = function(L_185_arg0, L_186_arg1, L_187_arg2, L_188_arg3, L_189_arg4, L_190_arg5)
	L_190_arg5 = L_14_func(L_13_.fn_019, L_186_arg1, {})
	return L_190_arg5
end

L_13_.fn_021 = function(L_191_arg0, L_192_arg1, L_193_arg2)
	return
end

L_13_.fn_022 = function(L_194_arg0, L_195_arg1, L_196_arg2, L_197_arg3)
	return L_196_arg2
end

L_13_.fn_023_setclipboard = function(L_198_arg0, L_199_arg1, L_200_arg2, L_201_arg3, L_202_arg4, L_203_arg5)
	L_201_arg3 = L_10_func(L_199_arg1, "Clipboard")
	L_203_arg5 = L_200_arg2
	do
		local L_204_ = L_201_arg3;
		L_202_arg4 = L_204_;
		L_201_arg3 = L_204_.set
	end
	L_201_arg3(L_202_arg4, L_203_arg5)
	return
end

L_13_.fn_024_setclipboard = function(L_205_arg0, L_206_arg1, L_207_arg2)
	return
end

L_13_.fn_025_mousePressCompat = function(L_208_arg0, L_209_arg1, L_210_arg2, L_211_arg3, L_212_arg4, L_213_arg5, L_214_arg6, L_215_arg7, L_216_arg8, L_217_arg9)
	L_210_arg2 = L_208_arg0[1][1]
	L_212_arg4 = 0
	L_213_arg5 = 0
	L_214_arg6 = 0
	L_215_arg7 = true
	L_216_arg8 = L_10_func(L_209_arg1, "game")
	L_217_arg9 = 1
	do
		local L_218_ = L_210_arg2;
		L_211_arg3 = L_218_;
		L_210_arg2 = L_218_.SendMouseButtonEvent
	end
	L_210_arg2(L_211_arg3, L_212_arg4, L_213_arg5, L_214_arg6, L_215_arg7, L_216_arg8, L_217_arg9)
	return
end

L_13_.fn_026_mouse1press = function(L_219_arg0, L_220_arg1, L_221_arg2, L_222_arg3)
	L_221_arg2 = L_10_func(L_220_arg1, "pcall")
	L_222_arg3 = L_14_func(L_13_.fn_025_mousePressCompat, L_220_arg1, {
		L_219_arg0[1]
	})
	L_221_arg2(L_222_arg3)
	return
end

L_13_.fn_027_mouseReleaseCompat = function(L_223_arg0, L_224_arg1, L_225_arg2, L_226_arg3, L_227_arg4, L_228_arg5, L_229_arg6, L_230_arg7, L_231_arg8, L_232_arg9)
	L_225_arg2 = L_223_arg0[1][1]
	L_227_arg4 = 0
	L_228_arg5 = 0
	L_229_arg6 = 0
	L_230_arg7 = false
	L_231_arg8 = L_10_func(L_224_arg1, "game")
	L_232_arg9 = 1
	do
		local L_233_ = L_225_arg2;
		L_226_arg3 = L_233_;
		L_225_arg2 = L_233_.SendMouseButtonEvent
	end
	L_225_arg2(L_226_arg3, L_227_arg4, L_228_arg5, L_229_arg6, L_230_arg7, L_231_arg8, L_232_arg9)
	return
end

L_13_.fn_028_mouse1release = function(L_234_arg0, L_235_arg1, L_236_arg2, L_237_arg3)
	L_236_arg2 = L_10_func(L_235_arg1, "pcall")
	L_237_arg3 = L_14_func(L_13_.fn_027_mouseReleaseCompat, L_235_arg1, {
		L_234_arg0[1]
	})
	L_236_arg2(L_237_arg3)
	return
end

L_13_.fn_029_Remove = function(L_238_arg0, L_239_arg1, L_240_arg2)
	return
end

L_13_.fn_030_Destroy = function(L_241_arg0, L_242_arg1, L_243_arg2)
	return
end

L_13_.fn_031_newindex = function(L_244_arg0, L_245_arg1, L_246_arg2)
	return
end

L_13_.fn_032 = function(L_247_arg0, L_248_arg1, L_249_arg2)
	return
end

L_13_.fn_033_index = function(L_250_arg0, L_251_arg1, L_252_arg2)
	L_252_arg2 = L_14_func(L_13_.fn_032, L_251_arg1, {})
	return L_252_arg2
end

L_13_.fn_034_new = function(L_253_arg0, L_254_arg1, L_255_arg2, L_256_arg3, L_257_arg4, L_258_arg5, L_259_arg6)
	L_257_arg4 = {}
	L_258_arg5 = false
	L_257_arg4.Visible = L_258_arg5
	L_258_arg5 = L_14_func(L_13_.fn_029_Remove, L_254_arg1, {})
	L_257_arg4.Remove = L_258_arg5
	L_258_arg5 = L_14_func(L_13_.fn_030_Destroy, L_254_arg1, {})
	L_257_arg4.Destroy = L_258_arg5
	L_258_arg5 = {}
	L_259_arg6 = L_14_func(L_13_.fn_031_newindex, L_254_arg1, {})
	L_258_arg5.__newindex = L_259_arg6
	L_259_arg6 = L_14_func(L_13_.fn_033_index, L_254_arg1, {})
	L_258_arg5.__index = L_259_arg6
	L_256_arg3 = L_10_func(L_254_arg1, "setmetatable")
	L_256_arg3 = L_256_arg3(L_257_arg4, L_258_arg5)
	return L_256_arg3
end

L_13_.fn_035_resolveDrawing = function(L_260_arg0, L_261_arg1, L_262_arg2, L_263_arg3)
	L_262_arg2 = L_10_func(L_261_arg1, "getgenv")
	L_262_arg2 = L_262_arg2()
	L_263_arg3 = L_260_arg0[1][1]
	L_262_arg2.Drawing = L_263_arg3
	return
end

L_13_.fn_036_resolveRequest = function(L_264_arg0, L_265_arg1, L_266_arg2, L_267_arg3)
	L_266_arg2 = L_10_func(L_265_arg1, "request")
	if L_266_arg2 then
		L_266_arg2 = L_10_func(L_265_arg1, "getgenv")
		L_266_arg2 = L_266_arg2()
		L_267_arg3 = L_10_func(L_265_arg1, "request")
		L_266_arg2.request = L_267_arg3
	end
	return
end

L_13_.fn_037_queue_on_teleport = function(L_268_arg0, L_269_arg1, L_270_arg2)
	return
end

L_13_.fn_038_gethui = function(L_271_arg0, L_272_arg1, ...)
	local L_273_ = L_1_(...)
	local L_274_ = L_273_.n
	local L_275_ = {}
	local L_276_ = {}
	local L_277_ = 2
	local L_278_ = 3
	for L_285_forvar0 = 0, L_278_ - 1 do
		L_275_[L_285_forvar0] = L_273_[L_285_forvar0 + 1]
	end
	local L_279_ = {
		n = math.max(0, L_274_ - L_278_)
	}
	for L_286_forvar0 = 1, L_279_.n do
		L_279_[L_286_forvar0] = L_273_[L_278_ + L_286_forvar0]
	end
	local L_280_ = L_274_
	local function L_281_func(L_287_arg0)
		local L_288_ = L_276_[L_287_arg0]
		if L_288_ ~= nil then
			return L_288_[1]
		end
		return L_275_[L_287_arg0]
	end
	local function L_282_func(L_289_arg0, L_290_arg1)
		local L_291_ = L_276_[L_289_arg0]
		if L_291_ ~= nil then
			L_291_[1] = L_290_arg1
		else
			L_275_[L_289_arg0] = L_290_arg1
		end
	end
	local function L_283_func(L_292_arg0)
		local L_293_ = L_276_[L_292_arg0]
		if L_293_ == nil then
			L_293_ = {
				L_275_[L_292_arg0]
			};
			L_276_[L_292_arg0] = L_293_
		end
		return L_293_
	end
	local function L_284_func(L_294_arg0, L_295_arg1)
		local L_296_ = {
			n = L_295_arg1
		}
		for L_297_forvar0 = 1, L_295_arg1 do
			L_296_[L_297_forvar0] = L_281_func(L_294_arg0 + L_297_forvar0 - 1)
		end
		return L_296_
	end

	L_282_func(0, L_10_func(L_272_arg1, "game"))
	L_282_func(2, "CoreGui")
	do
		local L_298_ = L_281_func(0)
		L_282_func(1, L_298_)
		L_282_func(0, L_298_["GetService"])
	end
	do
		local L_299_ = 2
		local L_300_ = L_284_func(1, L_299_)
		local L_301_ = L_1_(L_281_func(0)(L_2_(L_300_, 1, L_300_.n)))
		for L_302_forvar0 = 1, L_301_.n do
			L_282_func(0 + L_302_forvar0 - 1, L_301_[L_302_forvar0])
		end
		L_280_ = 0 + L_301_.n
	end
	do
		local L_303_ = L_280_ - 0
		if L_303_ <= 0 then
			return
		end
		local L_304_ = L_284_func(0, L_303_)
		return L_2_(L_304_, 1, L_304_.n)
	end
end

L_13_.fn_039_identifyexecutor = function(L_305_arg0, L_306_arg1, L_307_arg2, L_308_arg3)
	L_307_arg2 = "Unknown"
	L_308_arg3 = "0.0.0"
	return L_307_arg2, L_308_arg3
end

L_13_.fn_040_installCompatibilityAliases = function(L_309_arg0, L_310_arg1, ...)
	local L_311_ = L_10_func(L_310_arg1, "getgenv")
	local L_312_ = L_311_()
	local L_313_ = L_10_func(L_310_arg1, "pcall")
	if not L_10_func(L_310_arg1, "setclipboard") then
		local L_315_ = L_10_func(L_310_arg1, "toclipboard")
		local L_316_ = L_10_func(L_310_arg1, "Clipboard")
		if L_315_ then
			L_11_func(L_310_arg1, "setclipboard", L_315_)
		elseif L_316_ and L_316_.set then
			L_11_func(L_310_arg1, "setclipboard", L_14_func(L_13_.fn_023_setclipboard, L_310_arg1, {}))
		else
			L_11_func(L_310_arg1, "setclipboard", L_14_func(L_13_.fn_024_setclipboard, L_310_arg1, {}))
		end
	end
	if not L_10_func(L_310_arg1, "mouse1press") then
		local L_317_ = L_10_func(L_310_arg1, "game"):GetService("VirtualInputManager")
		L_312_.mouse1press = L_14_func(
            L_13_.fn_026_mouse1press, L_310_arg1, {
			{
				L_317_
			}
		}
        )
		L_312_.mouse1release = L_14_func(
            L_13_.fn_028_mouse1release, L_310_arg1, {
			{
				L_317_
			}
		}
        )
	end
	local L_314_ = L_312_.Drawing
	if not (L_314_ and type(L_314_) == "table" and L_314_.new) then
		L_314_ = {
			new = L_14_func(L_13_.fn_034_new, L_310_arg1, {}),
			Fonts = {
				UI = 0,
				System = 1,
				Plex = 2,
				Monospace = 3
			},
		}
		L_313_(L_14_func(L_13_.fn_035_resolveDrawing, L_310_arg1, {
			{
				L_314_
			}
		}))
	end
	if not L_10_func(L_310_arg1, "request") then
		local L_318_ = L_10_func(L_310_arg1, "syn")
		local L_319_ = L_10_func(L_310_arg1, "http")
		local L_320_ = (L_318_ and L_318_.request)
            or (L_319_ and L_319_.request)
            or L_10_func(L_310_arg1, "http_request")
		if L_320_ then
			L_11_func(L_310_arg1, "request", L_320_)
		end
	end
	L_313_(L_14_func(L_13_.fn_036_resolveRequest, L_310_arg1, {}))
	if not L_10_func(L_310_arg1, "queue_on_teleport") then
		L_312_.queue_on_teleport = L_14_func(L_13_.fn_037_queue_on_teleport, L_310_arg1, {})
	end
	if not L_10_func(L_310_arg1, "gethui") then
		L_312_.gethui = L_14_func(L_13_.fn_038_gethui, L_310_arg1, {})
	end
	if not L_10_func(L_310_arg1, "identifyexecutor") then
		L_312_.identifyexecutor = L_14_func(L_13_.fn_039_identifyexecutor, L_310_arg1, {})
	end
	return
end

L_13_.fn_041_detectGame = function(L_321_arg0, L_322_arg1, L_323_arg2, L_324_arg3, L_325_arg4)
	L_323_arg2 = L_10_func(L_322_arg1, "game")
	L_325_arg4 = "MarketplaceService"
	do
		local L_326_ = L_323_arg2;
		L_324_arg3 = L_326_;
		L_323_arg2 = L_326_.GetService
	end
	L_323_arg2 = L_323_arg2(L_324_arg3, L_325_arg4)
	L_325_arg4 = L_321_arg0[1][1]
	do
		local L_327_ = L_323_arg2;
		L_324_arg3 = L_327_;
		L_323_arg2 = L_327_.GetProductInfo
	end
	L_323_arg2 = L_323_arg2(L_324_arg3, L_325_arg4)
	if L_323_arg2 then
		L_324_arg3 = L_323_arg2.Name
		if L_324_arg3 then
			L_324_arg3 = L_323_arg2.Name
			do
				local L_328_ = L_324_arg3;
				L_325_arg4 = L_328_;
				L_324_arg3 = L_328_.lower
			end
			L_324_arg3 = L_324_arg3(L_325_arg4)
			L_321_arg0[2][1] = L_324_arg3
		end
	end
	return
end

L_13_.fn_042_detectBedWarsRemotes = function(L_329_arg0, L_330_arg1, ...)
	local L_331_ = L_10_func(L_330_arg1, "game")
	local L_332_ = L_331_:GetService("ReplicatedStorage")
	local L_333_ = L_10_func(L_330_arg1, "lplr")
	local L_334_ = L_10_func(L_330_arg1, "workspace")
	local L_335_ = L_329_arg0[1][1]
	local function L_336_func(L_340_arg0)
		for L_341_forvar0, L_342_forvar1 in ipairs(L_335_) do
			if L_342_forvar1.name == L_340_arg0 then
				L_329_arg0[2][1] = L_342_forvar1
				return
			end
		end
	end
	local L_337_ = L_332_:FindFirstChild("TS")
	if not L_337_ then
		L_337_ = L_333_.PlayerScripts:FindFirstChild("TS")
	end
	if L_337_ then
		L_336_func("BedWars")
		return
	end
	local L_338_ = L_332_:FindFirstChild("Remotes")
	if L_338_ and L_338_:FindFirstChild("CommF_") then
		L_336_func("Blox Fruits")
		return
	end
	local L_339_ = L_332_:FindFirstChild("events")
	if L_339_ and L_339_:FindFirstChild("reels") then
		L_336_func("Fish It")
		return
	end
	if L_332_:FindFirstChild("Forsaken") or L_334_:FindFirstChild("Forsaken") then
		L_336_func("Forsaken")
		return
	end
	if L_332_:FindFirstChild("Volleyball")
        or L_334_:FindFirstChild("Volleyball")
        or L_332_:FindFirstChild("Volley") then
		L_336_func("Volley Ball Legends")
		return
	end
	if L_332_:FindFirstChild("Brainrots") or L_334_:FindFirstChild("Brainrots") then
		L_336_func("SAB")
		return
	end
	if L_334_:FindFirstChild("Pickaxes") then
		L_336_func("+1 Pickaxe Swing Escape")
	end
	return
end

L_13_.fn_043_destroyInstanceSafe = function(L_343_arg0, L_344_arg1, L_345_arg2, L_346_arg3)
	L_345_arg2 = L_343_arg0[1][1]
	do
		local L_347_ = L_345_arg2;
		L_346_arg3 = L_347_;
		L_345_arg2 = L_347_.Destroy
	end
	L_345_arg2(L_346_arg3)
	return
end

L_13_.fn_044_delayedTween = function(L_348_arg0, L_349_arg1, L_350_arg2, L_351_arg3, L_352_arg4, L_353_arg5, L_354_arg6, L_355_arg7, L_356_arg8, L_357_arg9)
	L_350_arg2 = L_10_func(L_349_arg1, "tw")
	L_351_arg3 = L_348_arg0[1][1]
	L_352_arg4 = {}
	L_353_arg5 = L_10_func(L_349_arg1, "UDim2")
	L_353_arg5 = L_353_arg5.new
	L_354_arg6 = 1
	L_355_arg7 = 380
	L_356_arg8 = 1
	L_357_arg9 = -100
	L_353_arg5 = L_353_arg5(L_354_arg6, L_355_arg7, L_356_arg8, L_357_arg9)
	L_352_arg4.Position = L_353_arg5
	L_353_arg5 = 0.5
	L_352_arg4.BackgroundTransparency = L_353_arg5
	L_353_arg5 = 0.4
	L_350_arg2(L_351_arg3, L_352_arg4, L_353_arg5)
	L_350_arg2 = L_10_func(L_349_arg1, "task")
	L_350_arg2 = L_350_arg2.wait
	L_351_arg3 = 0.45
	L_350_arg2(L_351_arg3)
	L_350_arg2 = L_10_func(L_349_arg1, "pcall")
	L_351_arg3 = L_14_func(L_13_.fn_043_destroyInstanceSafe, L_349_arg1, {
		L_348_arg0[1]
	})
	L_350_arg2(L_351_arg3)
	return
end

L_13_.fn_045_createNotificationGui = function(L_358_arg0, L_359_arg1, L_360_arg2, L_361_arg3, L_362_arg4, L_363_arg5, L_364_arg6, L_365_arg7, L_366_arg8, L_367_arg9, L_368_arg10, L_369_arg11, L_370_arg12, L_371_arg13, L_372_arg14, L_373_arg15, L_374_arg16, L_375_arg17, L_376_arg18)
	L_362_arg4 = L_362_arg4
	if not L_362_arg4 then
		L_362_arg4 = 4
	end
	L_364_arg6 = L_358_arg0[1][1]
	if not L_364_arg6 then
		L_364_arg6 = L_10_func(L_359_arg1, "Instance")
		L_364_arg6 = L_364_arg6.new
		L_365_arg7 = "ScreenGui"
		L_366_arg8 = L_358_arg0[2][1]
		L_364_arg6 = L_364_arg6(L_365_arg7, L_366_arg8)
		L_365_arg7 = "SnowyNotifs"
		L_364_arg6.Name = L_365_arg7
		L_365_arg7 = L_10_func(L_359_arg1, "Enum")
		L_365_arg7 = L_365_arg7.ZIndexBehavior
		L_365_arg7 = L_365_arg7.Sibling
		L_364_arg6.ZIndexBehavior = L_365_arg7
		L_358_arg0[1][1] = L_364_arg6
	end
	L_364_arg6 = L_10_func(L_359_arg1, "Instance")
	L_364_arg6 = L_364_arg6.new
	L_365_arg7 = "Frame"
	L_366_arg8 = L_358_arg0[1][1]
	L_364_arg6 = L_364_arg6(L_365_arg7, L_366_arg8)
	L_365_arg7 = L_10_func(L_359_arg1, "UDim2")
	L_365_arg7 = L_365_arg7.new
	L_366_arg8 = 0
	L_367_arg9 = 340
	L_368_arg10 = 0
	L_369_arg11 = 80
	L_365_arg7 = L_365_arg7(L_366_arg8, L_367_arg9, L_368_arg10, L_369_arg11)
	L_364_arg6.Size = L_365_arg7
	L_365_arg7 = L_10_func(L_359_arg1, "UDim2")
	L_365_arg7 = L_365_arg7.new
	L_366_arg8 = 1
	L_367_arg9 = 360
	L_368_arg10 = 1
	L_369_arg11 = -100
	L_365_arg7 = L_365_arg7(L_366_arg8, L_367_arg9, L_368_arg10, L_369_arg11)
	L_364_arg6.Position = L_365_arg7
	L_366_arg8 = L_358_arg0[3][1]
	L_365_arg7 = L_366_arg8.BgCard
	L_364_arg6.BackgroundColor3 = L_365_arg7
	L_365_arg7 = 500
	L_364_arg6.ZIndex = L_365_arg7
	L_365_arg7 = L_10_func(L_359_arg1, "corner")
	L_367_arg9 = L_358_arg0[3][1]
	L_366_arg8 = L_367_arg9.RadiusSm
	L_367_arg9 = L_364_arg6
	L_365_arg7(L_366_arg8, L_367_arg9)
	L_365_arg7 = L_10_func(L_359_arg1, "stroke")
	if L_363_arg5 then
		L_367_arg9 = L_358_arg0[3][1]
		L_366_arg8 = L_367_arg9.Premium
		if not L_366_arg8 then
			L_367_arg9 = L_358_arg0[3][1]
			L_366_arg8 = L_367_arg9.Accent
		end
		L_367_arg9 = 1.5
		L_368_arg10 = L_364_arg6
		L_365_arg7(L_366_arg8, L_367_arg9, L_368_arg10)
		L_365_arg7 = L_10_func(L_359_arg1, "gradient")
		L_366_arg8 = L_364_arg6
		L_368_arg10 = L_358_arg0[3][1]
		L_367_arg9 = L_368_arg10.BgSecondary
		L_369_arg11 = L_358_arg0[3][1]
		L_368_arg10 = L_369_arg11.BgCard
		L_369_arg11 = 90
		L_365_arg7(L_366_arg8, L_367_arg9, L_368_arg10, L_369_arg11)
		L_365_arg7 = L_10_func(L_359_arg1, "Instance")
		L_365_arg7 = L_365_arg7.new
		L_366_arg8 = "Frame"
		L_367_arg9 = L_364_arg6
		L_365_arg7 = L_365_arg7(L_366_arg8, L_367_arg9)
		L_366_arg8 = L_10_func(L_359_arg1, "UDim2")
		L_366_arg8 = L_366_arg8.new
		L_367_arg9 = 0
		L_368_arg10 = 5
		L_369_arg11 = 0.6
		L_370_arg12 = 0
		L_366_arg8 = L_366_arg8(L_367_arg9, L_368_arg10, L_369_arg11, L_370_arg12)
		L_365_arg7.Size = L_366_arg8
		L_366_arg8 = L_10_func(L_359_arg1, "UDim2")
		L_366_arg8 = L_366_arg8.new
		L_367_arg9 = 0
		L_368_arg10 = 10
		L_369_arg11 = 0.2
		L_370_arg12 = 0
		L_366_arg8 = L_366_arg8(L_367_arg9, L_368_arg10, L_369_arg11, L_370_arg12)
		L_365_arg7.Position = L_366_arg8
		if L_363_arg5 then
			L_367_arg9 = L_358_arg0[3][1]
			L_366_arg8 = L_367_arg9.Premium
			if not L_366_arg8 then
				L_367_arg9 = L_358_arg0[3][1]
				L_366_arg8 = L_367_arg9.Accent
			end
			L_365_arg7.BackgroundColor3 = L_366_arg8
			L_366_arg8 = 0
			L_365_arg7.BorderSizePixel = L_366_arg8
			L_366_arg8 = 501
			L_365_arg7.ZIndex = L_366_arg8
			L_366_arg8 = L_10_func(L_359_arg1, "corner")
			L_368_arg10 = L_358_arg0[3][1]
			L_367_arg9 = L_368_arg10.RadiusPill
			L_368_arg10 = L_365_arg7
			L_366_arg8(L_367_arg9, L_368_arg10)
			L_366_arg8 = L_10_func(L_359_arg1, "Instance")
			L_366_arg8 = L_366_arg8.new
			L_367_arg9 = "TextLabel"
			L_368_arg10 = L_364_arg6
			L_366_arg8 = L_366_arg8(L_367_arg9, L_368_arg10)
			L_367_arg9 = L_10_func(L_359_arg1, "UDim2")
			L_367_arg9 = L_367_arg9.new
			L_368_arg10 = 1
			L_369_arg11 = -40
			L_370_arg12 = 0
			L_371_arg13 = 22
			L_367_arg9 = L_367_arg9(L_368_arg10, L_369_arg11, L_370_arg12, L_371_arg13)
			L_366_arg8.Size = L_367_arg9
			L_367_arg9 = L_10_func(L_359_arg1, "UDim2")
			L_367_arg9 = L_367_arg9.new
			L_368_arg10 = 0
			L_369_arg11 = 24
			L_370_arg12 = 0
			L_371_arg13 = 10
			L_367_arg9 = L_367_arg9(L_368_arg10, L_369_arg11, L_370_arg12, L_371_arg13)
			L_366_arg8.Position = L_367_arg9
			L_367_arg9 = 1
			L_366_arg8.BackgroundTransparency = L_367_arg9
			L_366_arg8.Text = L_360_arg2
			if L_363_arg5 then
				L_368_arg10 = L_358_arg0[3][1]
				L_367_arg9 = L_368_arg10.Premium
				if not L_367_arg9 then
					L_368_arg10 = L_358_arg0[3][1]
					L_367_arg9 = L_368_arg10.AccentBright
				end
				L_366_arg8.TextColor3 = L_367_arg9
				L_367_arg9 = L_10_func(L_359_arg1, "Enum")
				L_367_arg9 = L_367_arg9.Font
				L_367_arg9 = L_367_arg9.GothamBlack
				L_366_arg8.Font = L_367_arg9
				L_367_arg9 = 14
				L_366_arg8.TextSize = L_367_arg9
				L_367_arg9 = 501
				L_366_arg8.ZIndex = L_367_arg9
				L_367_arg9 = L_10_func(L_359_arg1, "Enum")
				L_367_arg9 = L_367_arg9.TextXAlignment
				L_367_arg9 = L_367_arg9.Left
				L_366_arg8.TextXAlignment = L_367_arg9
				L_367_arg9 = L_10_func(L_359_arg1, "Instance")
				L_367_arg9 = L_367_arg9.new
				L_368_arg10 = "TextLabel"
				L_369_arg11 = L_364_arg6
				L_367_arg9 = L_367_arg9(L_368_arg10, L_369_arg11)
				L_368_arg10 = L_10_func(L_359_arg1, "UDim2")
				L_368_arg10 = L_368_arg10.new
				L_369_arg11 = 1
				L_370_arg12 = -40
				L_371_arg13 = 0
				L_372_arg14 = 36
				L_368_arg10 = L_368_arg10(L_369_arg11, L_370_arg12, L_371_arg13, L_372_arg14)
				L_367_arg9.Size = L_368_arg10
				L_368_arg10 = L_10_func(L_359_arg1, "UDim2")
				L_368_arg10 = L_368_arg10.new
				L_369_arg11 = 0
				L_370_arg12 = 24
				L_371_arg13 = 0
				L_372_arg14 = 34
				L_368_arg10 = L_368_arg10(L_369_arg11, L_370_arg12, L_371_arg13, L_372_arg14)
				L_367_arg9.Position = L_368_arg10
				L_368_arg10 = 1
				L_367_arg9.BackgroundTransparency = L_368_arg10
				L_367_arg9.Text = L_361_arg3
				L_369_arg11 = L_358_arg0[3][1]
				L_368_arg10 = L_369_arg11.TextSecondary
				L_367_arg9.TextColor3 = L_368_arg10
				L_368_arg10 = L_10_func(L_359_arg1, "Enum")
				L_368_arg10 = L_368_arg10.Font
				L_368_arg10 = L_368_arg10.Gotham
				L_367_arg9.Font = L_368_arg10
				L_368_arg10 = 12
				L_367_arg9.TextSize = L_368_arg10
				L_368_arg10 = true
				L_367_arg9.TextWrapped = L_368_arg10
				L_368_arg10 = 501
				L_367_arg9.ZIndex = L_368_arg10
				L_368_arg10 = L_10_func(L_359_arg1, "Enum")
				L_368_arg10 = L_368_arg10.TextXAlignment
				L_368_arg10 = L_368_arg10.Left
				L_367_arg9.TextXAlignment = L_368_arg10
				L_368_arg10 = L_10_func(L_359_arg1, "Instance")
				L_368_arg10 = L_368_arg10.new
				L_369_arg11 = "Frame"
				L_370_arg12 = L_364_arg6
				L_368_arg10 = L_368_arg10(L_369_arg11, L_370_arg12)
				L_369_arg11 = L_10_func(L_359_arg1, "UDim2")
				L_369_arg11 = L_369_arg11.new
				L_370_arg12 = 1
				L_371_arg13 = -20
				L_372_arg14 = 0
				L_373_arg15 = 3
				L_369_arg11 = L_369_arg11(L_370_arg12, L_371_arg13, L_372_arg14, L_373_arg15)
				L_368_arg10.Size = L_369_arg11
				L_369_arg11 = L_10_func(L_359_arg1, "UDim2")
				L_369_arg11 = L_369_arg11.new
				L_370_arg12 = 0
				L_371_arg13 = 10
				L_372_arg14 = 1
				L_373_arg15 = -8
				L_369_arg11 = L_369_arg11(L_370_arg12, L_371_arg13, L_372_arg14, L_373_arg15)
				L_368_arg10.Position = L_369_arg11
				if L_363_arg5 then
					L_370_arg12 = L_358_arg0[3][1]
					L_369_arg11 = L_370_arg12.Premium
					if not L_369_arg11 then
						L_370_arg12 = L_358_arg0[3][1]
						L_369_arg11 = L_370_arg12.Accent
					end
					L_368_arg10.BackgroundColor3 = L_369_arg11
					L_369_arg11 = 501
					L_368_arg10.ZIndex = L_369_arg11
					L_369_arg11 = L_10_func(L_359_arg1, "corner")
					L_371_arg13 = L_358_arg0[3][1]
					L_370_arg12 = L_371_arg13.RadiusPill
					L_371_arg13 = L_368_arg10
					L_369_arg11(L_370_arg12, L_371_arg13)
					L_369_arg11 = L_10_func(L_359_arg1, "tw")
					L_370_arg12 = L_368_arg10
					L_371_arg13 = {}
					L_372_arg14 = L_10_func(L_359_arg1, "UDim2")
					L_372_arg14 = L_372_arg14.new
					L_373_arg15 = 0
					L_374_arg16 = 0
					L_375_arg17 = 0
					L_376_arg18 = 3
					L_372_arg14 = L_372_arg14(L_373_arg15, L_374_arg16, L_375_arg17, L_376_arg18)
					L_371_arg13.Size = L_372_arg14
					L_372_arg14 = L_362_arg4
					L_373_arg15 = L_10_func(L_359_arg1, "Enum")
					L_373_arg15 = L_373_arg15.EasingStyle
					L_373_arg15 = L_373_arg15.Linear
					L_369_arg11(L_370_arg12, L_371_arg13, L_372_arg14, L_373_arg15)
					L_369_arg11 = L_10_func(L_359_arg1, "tw")
					L_370_arg12 = L_364_arg6
					L_371_arg13 = {}
					L_372_arg14 = L_10_func(L_359_arg1, "UDim2")
					L_372_arg14 = L_372_arg14.new
					L_373_arg15 = 1
					L_374_arg16 = -360
					L_375_arg17 = 1
					L_376_arg18 = -100
					L_372_arg14 = L_372_arg14(L_373_arg15, L_374_arg16, L_375_arg17, L_376_arg18)
					L_371_arg13.Position = L_372_arg14
					L_372_arg14 = 0.5
					L_373_arg15 = L_10_func(L_359_arg1, "Enum")
					L_373_arg15 = L_373_arg15.EasingStyle
					L_373_arg15 = L_373_arg15.Back
					L_369_arg11(L_370_arg12, L_371_arg13, L_372_arg14, L_373_arg15)
					L_369_arg11 = L_10_func(L_359_arg1, "task")
					L_369_arg11 = L_369_arg11.delay
					L_370_arg12 = L_362_arg4
					L_371_arg13 = L_14_func(L_13_.fn_044_delayedTween, L_359_arg1, {
						{
							L_364_arg6
						}
					})
					L_369_arg11(L_370_arg12, L_371_arg13)
					return
				end
				L_370_arg12 = L_358_arg0[3][1]
				L_369_arg11 = L_370_arg12.Accent
				L_368_arg10.BackgroundColor3 = L_369_arg11
				L_369_arg11 = 501
				L_368_arg10.ZIndex = L_369_arg11
				L_369_arg11 = L_10_func(L_359_arg1, "corner")
				L_371_arg13 = L_358_arg0[3][1]
				L_370_arg12 = L_371_arg13.RadiusPill
				L_371_arg13 = L_368_arg10
				L_369_arg11(L_370_arg12, L_371_arg13)
				L_369_arg11 = L_10_func(L_359_arg1, "tw")
				L_370_arg12 = L_368_arg10
				L_371_arg13 = {}
				L_372_arg14 = L_10_func(L_359_arg1, "UDim2")
				L_372_arg14 = L_372_arg14.new
				L_373_arg15 = 0
				L_374_arg16 = 0
				L_375_arg17 = 0
				L_376_arg18 = 3
				L_372_arg14 = L_372_arg14(L_373_arg15, L_374_arg16, L_375_arg17, L_376_arg18)
				L_371_arg13.Size = L_372_arg14
				L_372_arg14 = L_362_arg4
				L_373_arg15 = L_10_func(L_359_arg1, "Enum")
				L_373_arg15 = L_373_arg15.EasingStyle
				L_373_arg15 = L_373_arg15.Linear
				L_369_arg11(L_370_arg12, L_371_arg13, L_372_arg14, L_373_arg15)
				L_369_arg11 = L_10_func(L_359_arg1, "tw")
				L_370_arg12 = L_364_arg6
				L_371_arg13 = {}
				L_372_arg14 = L_10_func(L_359_arg1, "UDim2")
				L_372_arg14 = L_372_arg14.new
				L_373_arg15 = 1
				L_374_arg16 = -360
				L_375_arg17 = 1
				L_376_arg18 = -100
				L_372_arg14 = L_372_arg14(L_373_arg15, L_374_arg16, L_375_arg17, L_376_arg18)
				L_371_arg13.Position = L_372_arg14
				L_372_arg14 = 0.5
				L_373_arg15 = L_10_func(L_359_arg1, "Enum")
				L_373_arg15 = L_373_arg15.EasingStyle
				L_373_arg15 = L_373_arg15.Back
				L_369_arg11(L_370_arg12, L_371_arg13, L_372_arg14, L_373_arg15)
				L_369_arg11 = L_10_func(L_359_arg1, "task")
				L_369_arg11 = L_369_arg11.delay
				L_370_arg12 = L_362_arg4
				L_371_arg13 = L_14_func(L_13_.fn_044_delayedTween, L_359_arg1, {
					{
						L_364_arg6
					}
				})
				L_369_arg11(L_370_arg12, L_371_arg13)
				return
			end
			L_368_arg10 = L_358_arg0[3][1]
			L_367_arg9 = L_368_arg10.AccentBright
			L_366_arg8.TextColor3 = L_367_arg9
			L_367_arg9 = L_10_func(L_359_arg1, "Enum")
			L_367_arg9 = L_367_arg9.Font
			L_367_arg9 = L_367_arg9.GothamBlack
			L_366_arg8.Font = L_367_arg9
			L_367_arg9 = 14
			L_366_arg8.TextSize = L_367_arg9
			L_367_arg9 = 501
			L_366_arg8.ZIndex = L_367_arg9
			L_367_arg9 = L_10_func(L_359_arg1, "Enum")
			L_367_arg9 = L_367_arg9.TextXAlignment
			L_367_arg9 = L_367_arg9.Left
			L_366_arg8.TextXAlignment = L_367_arg9
			L_367_arg9 = L_10_func(L_359_arg1, "Instance")
			L_367_arg9 = L_367_arg9.new
			L_368_arg10 = "TextLabel"
			L_369_arg11 = L_364_arg6
			L_367_arg9 = L_367_arg9(L_368_arg10, L_369_arg11)
			L_368_arg10 = L_10_func(L_359_arg1, "UDim2")
			L_368_arg10 = L_368_arg10.new
			L_369_arg11 = 1
			L_370_arg12 = -40
			L_371_arg13 = 0
			L_372_arg14 = 36
			L_368_arg10 = L_368_arg10(L_369_arg11, L_370_arg12, L_371_arg13, L_372_arg14)
			L_367_arg9.Size = L_368_arg10
			L_368_arg10 = L_10_func(L_359_arg1, "UDim2")
			L_368_arg10 = L_368_arg10.new
			L_369_arg11 = 0
			L_370_arg12 = 24
			L_371_arg13 = 0
			L_372_arg14 = 34
			L_368_arg10 = L_368_arg10(L_369_arg11, L_370_arg12, L_371_arg13, L_372_arg14)
			L_367_arg9.Position = L_368_arg10
			L_368_arg10 = 1
			L_367_arg9.BackgroundTransparency = L_368_arg10
			L_367_arg9.Text = L_361_arg3
			L_369_arg11 = L_358_arg0[3][1]
			L_368_arg10 = L_369_arg11.TextSecondary
			L_367_arg9.TextColor3 = L_368_arg10
			L_368_arg10 = L_10_func(L_359_arg1, "Enum")
			L_368_arg10 = L_368_arg10.Font
			L_368_arg10 = L_368_arg10.Gotham
			L_367_arg9.Font = L_368_arg10
			L_368_arg10 = 12
			L_367_arg9.TextSize = L_368_arg10
			L_368_arg10 = true
			L_367_arg9.TextWrapped = L_368_arg10
			L_368_arg10 = 501
			L_367_arg9.ZIndex = L_368_arg10
			L_368_arg10 = L_10_func(L_359_arg1, "Enum")
			L_368_arg10 = L_368_arg10.TextXAlignment
			L_368_arg10 = L_368_arg10.Left
			L_367_arg9.TextXAlignment = L_368_arg10
			L_368_arg10 = L_10_func(L_359_arg1, "Instance")
			L_368_arg10 = L_368_arg10.new
			L_369_arg11 = "Frame"
			L_370_arg12 = L_364_arg6
			L_368_arg10 = L_368_arg10(L_369_arg11, L_370_arg12)
			L_369_arg11 = L_10_func(L_359_arg1, "UDim2")
			L_369_arg11 = L_369_arg11.new
			L_370_arg12 = 1
			L_371_arg13 = -20
			L_372_arg14 = 0
			L_373_arg15 = 3
			L_369_arg11 = L_369_arg11(L_370_arg12, L_371_arg13, L_372_arg14, L_373_arg15)
			L_368_arg10.Size = L_369_arg11
			L_369_arg11 = L_10_func(L_359_arg1, "UDim2")
			L_369_arg11 = L_369_arg11.new
			L_370_arg12 = 0
			L_371_arg13 = 10
			L_372_arg14 = 1
			L_373_arg15 = -8
			L_369_arg11 = L_369_arg11(L_370_arg12, L_371_arg13, L_372_arg14, L_373_arg15)
			L_368_arg10.Position = L_369_arg11
			if L_363_arg5 then
				L_370_arg12 = L_358_arg0[3][1]
				L_369_arg11 = L_370_arg12.Premium
				if not L_369_arg11 then
					L_370_arg12 = L_358_arg0[3][1]
					L_369_arg11 = L_370_arg12.Accent
				end
				L_368_arg10.BackgroundColor3 = L_369_arg11
				L_369_arg11 = 501
				L_368_arg10.ZIndex = L_369_arg11
				L_369_arg11 = L_10_func(L_359_arg1, "corner")
				L_371_arg13 = L_358_arg0[3][1]
				L_370_arg12 = L_371_arg13.RadiusPill
				L_371_arg13 = L_368_arg10
				L_369_arg11(L_370_arg12, L_371_arg13)
				L_369_arg11 = L_10_func(L_359_arg1, "tw")
				L_370_arg12 = L_368_arg10
				L_371_arg13 = {}
				L_372_arg14 = L_10_func(L_359_arg1, "UDim2")
				L_372_arg14 = L_372_arg14.new
				L_373_arg15 = 0
				L_374_arg16 = 0
				L_375_arg17 = 0
				L_376_arg18 = 3
				L_372_arg14 = L_372_arg14(L_373_arg15, L_374_arg16, L_375_arg17, L_376_arg18)
				L_371_arg13.Size = L_372_arg14
				L_372_arg14 = L_362_arg4
				L_373_arg15 = L_10_func(L_359_arg1, "Enum")
				L_373_arg15 = L_373_arg15.EasingStyle
				L_373_arg15 = L_373_arg15.Linear
				L_369_arg11(L_370_arg12, L_371_arg13, L_372_arg14, L_373_arg15)
				L_369_arg11 = L_10_func(L_359_arg1, "tw")
				L_370_arg12 = L_364_arg6
				L_371_arg13 = {}
				L_372_arg14 = L_10_func(L_359_arg1, "UDim2")
				L_372_arg14 = L_372_arg14.new
				L_373_arg15 = 1
				L_374_arg16 = -360
				L_375_arg17 = 1
				L_376_arg18 = -100
				L_372_arg14 = L_372_arg14(L_373_arg15, L_374_arg16, L_375_arg17, L_376_arg18)
				L_371_arg13.Position = L_372_arg14
				L_372_arg14 = 0.5
				L_373_arg15 = L_10_func(L_359_arg1, "Enum")
				L_373_arg15 = L_373_arg15.EasingStyle
				L_373_arg15 = L_373_arg15.Back
				L_369_arg11(L_370_arg12, L_371_arg13, L_372_arg14, L_373_arg15)
				L_369_arg11 = L_10_func(L_359_arg1, "task")
				L_369_arg11 = L_369_arg11.delay
				L_370_arg12 = L_362_arg4
				L_371_arg13 = L_14_func(L_13_.fn_044_delayedTween, L_359_arg1, {
					{
						L_364_arg6
					}
				})
				L_369_arg11(L_370_arg12, L_371_arg13)
				return
			end
			L_370_arg12 = L_358_arg0[3][1]
			L_369_arg11 = L_370_arg12.Accent
			L_368_arg10.BackgroundColor3 = L_369_arg11
			L_369_arg11 = 501
			L_368_arg10.ZIndex = L_369_arg11
			L_369_arg11 = L_10_func(L_359_arg1, "corner")
			L_371_arg13 = L_358_arg0[3][1]
			L_370_arg12 = L_371_arg13.RadiusPill
			L_371_arg13 = L_368_arg10
			L_369_arg11(L_370_arg12, L_371_arg13)
			L_369_arg11 = L_10_func(L_359_arg1, "tw")
			L_370_arg12 = L_368_arg10
			L_371_arg13 = {}
			L_372_arg14 = L_10_func(L_359_arg1, "UDim2")
			L_372_arg14 = L_372_arg14.new
			L_373_arg15 = 0
			L_374_arg16 = 0
			L_375_arg17 = 0
			L_376_arg18 = 3
			L_372_arg14 = L_372_arg14(L_373_arg15, L_374_arg16, L_375_arg17, L_376_arg18)
			L_371_arg13.Size = L_372_arg14
			L_372_arg14 = L_362_arg4
			L_373_arg15 = L_10_func(L_359_arg1, "Enum")
			L_373_arg15 = L_373_arg15.EasingStyle
			L_373_arg15 = L_373_arg15.Linear
			L_369_arg11(L_370_arg12, L_371_arg13, L_372_arg14, L_373_arg15)
			L_369_arg11 = L_10_func(L_359_arg1, "tw")
			L_370_arg12 = L_364_arg6
			L_371_arg13 = {}
			L_372_arg14 = L_10_func(L_359_arg1, "UDim2")
			L_372_arg14 = L_372_arg14.new
			L_373_arg15 = 1
			L_374_arg16 = -360
			L_375_arg17 = 1
			L_376_arg18 = -100
			L_372_arg14 = L_372_arg14(L_373_arg15, L_374_arg16, L_375_arg17, L_376_arg18)
			L_371_arg13.Position = L_372_arg14
			L_372_arg14 = 0.5
			L_373_arg15 = L_10_func(L_359_arg1, "Enum")
			L_373_arg15 = L_373_arg15.EasingStyle
			L_373_arg15 = L_373_arg15.Back
			L_369_arg11(L_370_arg12, L_371_arg13, L_372_arg14, L_373_arg15)
			L_369_arg11 = L_10_func(L_359_arg1, "task")
			L_369_arg11 = L_369_arg11.delay
			L_370_arg12 = L_362_arg4
			L_371_arg13 = L_14_func(L_13_.fn_044_delayedTween, L_359_arg1, {
				{
					L_364_arg6
				}
			})
			L_369_arg11(L_370_arg12, L_371_arg13)
			return
		end
		L_367_arg9 = L_358_arg0[3][1]
		L_366_arg8 = L_367_arg9.Accent
		L_365_arg7.BackgroundColor3 = L_366_arg8
		L_366_arg8 = 0
		L_365_arg7.BorderSizePixel = L_366_arg8
		L_366_arg8 = 501
		L_365_arg7.ZIndex = L_366_arg8
		L_366_arg8 = L_10_func(L_359_arg1, "corner")
		L_368_arg10 = L_358_arg0[3][1]
		L_367_arg9 = L_368_arg10.RadiusPill
		L_368_arg10 = L_365_arg7
		L_366_arg8(L_367_arg9, L_368_arg10)
		L_366_arg8 = L_10_func(L_359_arg1, "Instance")
		L_366_arg8 = L_366_arg8.new
		L_367_arg9 = "TextLabel"
		L_368_arg10 = L_364_arg6
		L_366_arg8 = L_366_arg8(L_367_arg9, L_368_arg10)
		L_367_arg9 = L_10_func(L_359_arg1, "UDim2")
		L_367_arg9 = L_367_arg9.new
		L_368_arg10 = 1
		L_369_arg11 = -40
		L_370_arg12 = 0
		L_371_arg13 = 22
		L_367_arg9 = L_367_arg9(L_368_arg10, L_369_arg11, L_370_arg12, L_371_arg13)
		L_366_arg8.Size = L_367_arg9
		L_367_arg9 = L_10_func(L_359_arg1, "UDim2")
		L_367_arg9 = L_367_arg9.new
		L_368_arg10 = 0
		L_369_arg11 = 24
		L_370_arg12 = 0
		L_371_arg13 = 10
		L_367_arg9 = L_367_arg9(L_368_arg10, L_369_arg11, L_370_arg12, L_371_arg13)
		L_366_arg8.Position = L_367_arg9
		L_367_arg9 = 1
		L_366_arg8.BackgroundTransparency = L_367_arg9
		L_366_arg8.Text = L_360_arg2
		if L_363_arg5 then
			L_368_arg10 = L_358_arg0[3][1]
			L_367_arg9 = L_368_arg10.Premium
			if not L_367_arg9 then
				L_368_arg10 = L_358_arg0[3][1]
				L_367_arg9 = L_368_arg10.AccentBright
			end
			L_366_arg8.TextColor3 = L_367_arg9
			L_367_arg9 = L_10_func(L_359_arg1, "Enum")
			L_367_arg9 = L_367_arg9.Font
			L_367_arg9 = L_367_arg9.GothamBlack
			L_366_arg8.Font = L_367_arg9
			L_367_arg9 = 14
			L_366_arg8.TextSize = L_367_arg9
			L_367_arg9 = 501
			L_366_arg8.ZIndex = L_367_arg9
			L_367_arg9 = L_10_func(L_359_arg1, "Enum")
			L_367_arg9 = L_367_arg9.TextXAlignment
			L_367_arg9 = L_367_arg9.Left
			L_366_arg8.TextXAlignment = L_367_arg9
			L_367_arg9 = L_10_func(L_359_arg1, "Instance")
			L_367_arg9 = L_367_arg9.new
			L_368_arg10 = "TextLabel"
			L_369_arg11 = L_364_arg6
			L_367_arg9 = L_367_arg9(L_368_arg10, L_369_arg11)
			L_368_arg10 = L_10_func(L_359_arg1, "UDim2")
			L_368_arg10 = L_368_arg10.new
			L_369_arg11 = 1
			L_370_arg12 = -40
			L_371_arg13 = 0
			L_372_arg14 = 36
			L_368_arg10 = L_368_arg10(L_369_arg11, L_370_arg12, L_371_arg13, L_372_arg14)
			L_367_arg9.Size = L_368_arg10
			L_368_arg10 = L_10_func(L_359_arg1, "UDim2")
			L_368_arg10 = L_368_arg10.new
			L_369_arg11 = 0
			L_370_arg12 = 24
			L_371_arg13 = 0
			L_372_arg14 = 34
			L_368_arg10 = L_368_arg10(L_369_arg11, L_370_arg12, L_371_arg13, L_372_arg14)
			L_367_arg9.Position = L_368_arg10
			L_368_arg10 = 1
			L_367_arg9.BackgroundTransparency = L_368_arg10
			L_367_arg9.Text = L_361_arg3
			L_369_arg11 = L_358_arg0[3][1]
			L_368_arg10 = L_369_arg11.TextSecondary
			L_367_arg9.TextColor3 = L_368_arg10
			L_368_arg10 = L_10_func(L_359_arg1, "Enum")
			L_368_arg10 = L_368_arg10.Font
			L_368_arg10 = L_368_arg10.Gotham
			L_367_arg9.Font = L_368_arg10
			L_368_arg10 = 12
			L_367_arg9.TextSize = L_368_arg10
			L_368_arg10 = true
			L_367_arg9.TextWrapped = L_368_arg10
			L_368_arg10 = 501
			L_367_arg9.ZIndex = L_368_arg10
			L_368_arg10 = L_10_func(L_359_arg1, "Enum")
			L_368_arg10 = L_368_arg10.TextXAlignment
			L_368_arg10 = L_368_arg10.Left
			L_367_arg9.TextXAlignment = L_368_arg10
			L_368_arg10 = L_10_func(L_359_arg1, "Instance")
			L_368_arg10 = L_368_arg10.new
			L_369_arg11 = "Frame"
			L_370_arg12 = L_364_arg6
			L_368_arg10 = L_368_arg10(L_369_arg11, L_370_arg12)
			L_369_arg11 = L_10_func(L_359_arg1, "UDim2")
			L_369_arg11 = L_369_arg11.new
			L_370_arg12 = 1
			L_371_arg13 = -20
			L_372_arg14 = 0
			L_373_arg15 = 3
			L_369_arg11 = L_369_arg11(L_370_arg12, L_371_arg13, L_372_arg14, L_373_arg15)
			L_368_arg10.Size = L_369_arg11
			L_369_arg11 = L_10_func(L_359_arg1, "UDim2")
			L_369_arg11 = L_369_arg11.new
			L_370_arg12 = 0
			L_371_arg13 = 10
			L_372_arg14 = 1
			L_373_arg15 = -8
			L_369_arg11 = L_369_arg11(L_370_arg12, L_371_arg13, L_372_arg14, L_373_arg15)
			L_368_arg10.Position = L_369_arg11
			if L_363_arg5 then
				L_370_arg12 = L_358_arg0[3][1]
				L_369_arg11 = L_370_arg12.Premium
				if not L_369_arg11 then
					L_370_arg12 = L_358_arg0[3][1]
					L_369_arg11 = L_370_arg12.Accent
				end
				L_368_arg10.BackgroundColor3 = L_369_arg11
				L_369_arg11 = 501
				L_368_arg10.ZIndex = L_369_arg11
				L_369_arg11 = L_10_func(L_359_arg1, "corner")
				L_371_arg13 = L_358_arg0[3][1]
				L_370_arg12 = L_371_arg13.RadiusPill
				L_371_arg13 = L_368_arg10
				L_369_arg11(L_370_arg12, L_371_arg13)
				L_369_arg11 = L_10_func(L_359_arg1, "tw")
				L_370_arg12 = L_368_arg10
				L_371_arg13 = {}
				L_372_arg14 = L_10_func(L_359_arg1, "UDim2")
				L_372_arg14 = L_372_arg14.new
				L_373_arg15 = 0
				L_374_arg16 = 0
				L_375_arg17 = 0
				L_376_arg18 = 3
				L_372_arg14 = L_372_arg14(L_373_arg15, L_374_arg16, L_375_arg17, L_376_arg18)
				L_371_arg13.Size = L_372_arg14
				L_372_arg14 = L_362_arg4
				L_373_arg15 = L_10_func(L_359_arg1, "Enum")
				L_373_arg15 = L_373_arg15.EasingStyle
				L_373_arg15 = L_373_arg15.Linear
				L_369_arg11(L_370_arg12, L_371_arg13, L_372_arg14, L_373_arg15)
				L_369_arg11 = L_10_func(L_359_arg1, "tw")
				L_370_arg12 = L_364_arg6
				L_371_arg13 = {}
				L_372_arg14 = L_10_func(L_359_arg1, "UDim2")
				L_372_arg14 = L_372_arg14.new
				L_373_arg15 = 1
				L_374_arg16 = -360
				L_375_arg17 = 1
				L_376_arg18 = -100
				L_372_arg14 = L_372_arg14(L_373_arg15, L_374_arg16, L_375_arg17, L_376_arg18)
				L_371_arg13.Position = L_372_arg14
				L_372_arg14 = 0.5
				L_373_arg15 = L_10_func(L_359_arg1, "Enum")
				L_373_arg15 = L_373_arg15.EasingStyle
				L_373_arg15 = L_373_arg15.Back
				L_369_arg11(L_370_arg12, L_371_arg13, L_372_arg14, L_373_arg15)
				L_369_arg11 = L_10_func(L_359_arg1, "task")
				L_369_arg11 = L_369_arg11.delay
				L_370_arg12 = L_362_arg4
				L_371_arg13 = L_14_func(L_13_.fn_044_delayedTween, L_359_arg1, {
					{
						L_364_arg6
					}
				})
				L_369_arg11(L_370_arg12, L_371_arg13)
				return
			end
			L_370_arg12 = L_358_arg0[3][1]
			L_369_arg11 = L_370_arg12.Accent
			L_368_arg10.BackgroundColor3 = L_369_arg11
			L_369_arg11 = 501
			L_368_arg10.ZIndex = L_369_arg11
			L_369_arg11 = L_10_func(L_359_arg1, "corner")
			L_371_arg13 = L_358_arg0[3][1]
			L_370_arg12 = L_371_arg13.RadiusPill
			L_371_arg13 = L_368_arg10
			L_369_arg11(L_370_arg12, L_371_arg13)
			L_369_arg11 = L_10_func(L_359_arg1, "tw")
			L_370_arg12 = L_368_arg10
			L_371_arg13 = {}
			L_372_arg14 = L_10_func(L_359_arg1, "UDim2")
			L_372_arg14 = L_372_arg14.new
			L_373_arg15 = 0
			L_374_arg16 = 0
			L_375_arg17 = 0
			L_376_arg18 = 3
			L_372_arg14 = L_372_arg14(L_373_arg15, L_374_arg16, L_375_arg17, L_376_arg18)
			L_371_arg13.Size = L_372_arg14
			L_372_arg14 = L_362_arg4
			L_373_arg15 = L_10_func(L_359_arg1, "Enum")
			L_373_arg15 = L_373_arg15.EasingStyle
			L_373_arg15 = L_373_arg15.Linear
			L_369_arg11(L_370_arg12, L_371_arg13, L_372_arg14, L_373_arg15)
			L_369_arg11 = L_10_func(L_359_arg1, "tw")
			L_370_arg12 = L_364_arg6
			L_371_arg13 = {}
			L_372_arg14 = L_10_func(L_359_arg1, "UDim2")
			L_372_arg14 = L_372_arg14.new
			L_373_arg15 = 1
			L_374_arg16 = -360
			L_375_arg17 = 1
			L_376_arg18 = -100
			L_372_arg14 = L_372_arg14(L_373_arg15, L_374_arg16, L_375_arg17, L_376_arg18)
			L_371_arg13.Position = L_372_arg14
			L_372_arg14 = 0.5
			L_373_arg15 = L_10_func(L_359_arg1, "Enum")
			L_373_arg15 = L_373_arg15.EasingStyle
			L_373_arg15 = L_373_arg15.Back
			L_369_arg11(L_370_arg12, L_371_arg13, L_372_arg14, L_373_arg15)
			L_369_arg11 = L_10_func(L_359_arg1, "task")
			L_369_arg11 = L_369_arg11.delay
			L_370_arg12 = L_362_arg4
			L_371_arg13 = L_14_func(L_13_.fn_044_delayedTween, L_359_arg1, {
				{
					L_364_arg6
				}
			})
			L_369_arg11(L_370_arg12, L_371_arg13)
			return
		end
		L_368_arg10 = L_358_arg0[3][1]
		L_367_arg9 = L_368_arg10.AccentBright
		L_366_arg8.TextColor3 = L_367_arg9
		L_367_arg9 = L_10_func(L_359_arg1, "Enum")
		L_367_arg9 = L_367_arg9.Font
		L_367_arg9 = L_367_arg9.GothamBlack
		L_366_arg8.Font = L_367_arg9
		L_367_arg9 = 14
		L_366_arg8.TextSize = L_367_arg9
		L_367_arg9 = 501
		L_366_arg8.ZIndex = L_367_arg9
		L_367_arg9 = L_10_func(L_359_arg1, "Enum")
		L_367_arg9 = L_367_arg9.TextXAlignment
		L_367_arg9 = L_367_arg9.Left
		L_366_arg8.TextXAlignment = L_367_arg9
		L_367_arg9 = L_10_func(L_359_arg1, "Instance")
		L_367_arg9 = L_367_arg9.new
		L_368_arg10 = "TextLabel"
		L_369_arg11 = L_364_arg6
		L_367_arg9 = L_367_arg9(L_368_arg10, L_369_arg11)
		L_368_arg10 = L_10_func(L_359_arg1, "UDim2")
		L_368_arg10 = L_368_arg10.new
		L_369_arg11 = 1
		L_370_arg12 = -40
		L_371_arg13 = 0
		L_372_arg14 = 36
		L_368_arg10 = L_368_arg10(L_369_arg11, L_370_arg12, L_371_arg13, L_372_arg14)
		L_367_arg9.Size = L_368_arg10
		L_368_arg10 = L_10_func(L_359_arg1, "UDim2")
		L_368_arg10 = L_368_arg10.new
		L_369_arg11 = 0
		L_370_arg12 = 24
		L_371_arg13 = 0
		L_372_arg14 = 34
		L_368_arg10 = L_368_arg10(L_369_arg11, L_370_arg12, L_371_arg13, L_372_arg14)
		L_367_arg9.Position = L_368_arg10
		L_368_arg10 = 1
		L_367_arg9.BackgroundTransparency = L_368_arg10
		L_367_arg9.Text = L_361_arg3
		L_369_arg11 = L_358_arg0[3][1]
		L_368_arg10 = L_369_arg11.TextSecondary
		L_367_arg9.TextColor3 = L_368_arg10
		L_368_arg10 = L_10_func(L_359_arg1, "Enum")
		L_368_arg10 = L_368_arg10.Font
		L_368_arg10 = L_368_arg10.Gotham
		L_367_arg9.Font = L_368_arg10
		L_368_arg10 = 12
		L_367_arg9.TextSize = L_368_arg10
		L_368_arg10 = true
		L_367_arg9.TextWrapped = L_368_arg10
		L_368_arg10 = 501
		L_367_arg9.ZIndex = L_368_arg10
		L_368_arg10 = L_10_func(L_359_arg1, "Enum")
		L_368_arg10 = L_368_arg10.TextXAlignment
		L_368_arg10 = L_368_arg10.Left
		L_367_arg9.TextXAlignment = L_368_arg10
		L_368_arg10 = L_10_func(L_359_arg1, "Instance")
		L_368_arg10 = L_368_arg10.new
		L_369_arg11 = "Frame"
		L_370_arg12 = L_364_arg6
		L_368_arg10 = L_368_arg10(L_369_arg11, L_370_arg12)
		L_369_arg11 = L_10_func(L_359_arg1, "UDim2")
		L_369_arg11 = L_369_arg11.new
		L_370_arg12 = 1
		L_371_arg13 = -20
		L_372_arg14 = 0
		L_373_arg15 = 3
		L_369_arg11 = L_369_arg11(L_370_arg12, L_371_arg13, L_372_arg14, L_373_arg15)
		L_368_arg10.Size = L_369_arg11
		L_369_arg11 = L_10_func(L_359_arg1, "UDim2")
		L_369_arg11 = L_369_arg11.new
		L_370_arg12 = 0
		L_371_arg13 = 10
		L_372_arg14 = 1
		L_373_arg15 = -8
		L_369_arg11 = L_369_arg11(L_370_arg12, L_371_arg13, L_372_arg14, L_373_arg15)
		L_368_arg10.Position = L_369_arg11
		if L_363_arg5 then
			L_370_arg12 = L_358_arg0[3][1]
			L_369_arg11 = L_370_arg12.Premium
			if not L_369_arg11 then
				L_370_arg12 = L_358_arg0[3][1]
				L_369_arg11 = L_370_arg12.Accent
			end
			L_368_arg10.BackgroundColor3 = L_369_arg11
			L_369_arg11 = 501
			L_368_arg10.ZIndex = L_369_arg11
			L_369_arg11 = L_10_func(L_359_arg1, "corner")
			L_371_arg13 = L_358_arg0[3][1]
			L_370_arg12 = L_371_arg13.RadiusPill
			L_371_arg13 = L_368_arg10
			L_369_arg11(L_370_arg12, L_371_arg13)
			L_369_arg11 = L_10_func(L_359_arg1, "tw")
			L_370_arg12 = L_368_arg10
			L_371_arg13 = {}
			L_372_arg14 = L_10_func(L_359_arg1, "UDim2")
			L_372_arg14 = L_372_arg14.new
			L_373_arg15 = 0
			L_374_arg16 = 0
			L_375_arg17 = 0
			L_376_arg18 = 3
			L_372_arg14 = L_372_arg14(L_373_arg15, L_374_arg16, L_375_arg17, L_376_arg18)
			L_371_arg13.Size = L_372_arg14
			L_372_arg14 = L_362_arg4
			L_373_arg15 = L_10_func(L_359_arg1, "Enum")
			L_373_arg15 = L_373_arg15.EasingStyle
			L_373_arg15 = L_373_arg15.Linear
			L_369_arg11(L_370_arg12, L_371_arg13, L_372_arg14, L_373_arg15)
			L_369_arg11 = L_10_func(L_359_arg1, "tw")
			L_370_arg12 = L_364_arg6
			L_371_arg13 = {}
			L_372_arg14 = L_10_func(L_359_arg1, "UDim2")
			L_372_arg14 = L_372_arg14.new
			L_373_arg15 = 1
			L_374_arg16 = -360
			L_375_arg17 = 1
			L_376_arg18 = -100
			L_372_arg14 = L_372_arg14(L_373_arg15, L_374_arg16, L_375_arg17, L_376_arg18)
			L_371_arg13.Position = L_372_arg14
			L_372_arg14 = 0.5
			L_373_arg15 = L_10_func(L_359_arg1, "Enum")
			L_373_arg15 = L_373_arg15.EasingStyle
			L_373_arg15 = L_373_arg15.Back
			L_369_arg11(L_370_arg12, L_371_arg13, L_372_arg14, L_373_arg15)
			L_369_arg11 = L_10_func(L_359_arg1, "task")
			L_369_arg11 = L_369_arg11.delay
			L_370_arg12 = L_362_arg4
			L_371_arg13 = L_14_func(L_13_.fn_044_delayedTween, L_359_arg1, {
				{
					L_364_arg6
				}
			})
			L_369_arg11(L_370_arg12, L_371_arg13)
			return
		end
		L_370_arg12 = L_358_arg0[3][1]
		L_369_arg11 = L_370_arg12.Accent
		L_368_arg10.BackgroundColor3 = L_369_arg11
		L_369_arg11 = 501
		L_368_arg10.ZIndex = L_369_arg11
		L_369_arg11 = L_10_func(L_359_arg1, "corner")
		L_371_arg13 = L_358_arg0[3][1]
		L_370_arg12 = L_371_arg13.RadiusPill
		L_371_arg13 = L_368_arg10
		L_369_arg11(L_370_arg12, L_371_arg13)
		L_369_arg11 = L_10_func(L_359_arg1, "tw")
		L_370_arg12 = L_368_arg10
		L_371_arg13 = {}
		L_372_arg14 = L_10_func(L_359_arg1, "UDim2")
		L_372_arg14 = L_372_arg14.new
		L_373_arg15 = 0
		L_374_arg16 = 0
		L_375_arg17 = 0
		L_376_arg18 = 3
		L_372_arg14 = L_372_arg14(L_373_arg15, L_374_arg16, L_375_arg17, L_376_arg18)
		L_371_arg13.Size = L_372_arg14
		L_372_arg14 = L_362_arg4
		L_373_arg15 = L_10_func(L_359_arg1, "Enum")
		L_373_arg15 = L_373_arg15.EasingStyle
		L_373_arg15 = L_373_arg15.Linear
		L_369_arg11(L_370_arg12, L_371_arg13, L_372_arg14, L_373_arg15)
		L_369_arg11 = L_10_func(L_359_arg1, "tw")
		L_370_arg12 = L_364_arg6
		L_371_arg13 = {}
		L_372_arg14 = L_10_func(L_359_arg1, "UDim2")
		L_372_arg14 = L_372_arg14.new
		L_373_arg15 = 1
		L_374_arg16 = -360
		L_375_arg17 = 1
		L_376_arg18 = -100
		L_372_arg14 = L_372_arg14(L_373_arg15, L_374_arg16, L_375_arg17, L_376_arg18)
		L_371_arg13.Position = L_372_arg14
		L_372_arg14 = 0.5
		L_373_arg15 = L_10_func(L_359_arg1, "Enum")
		L_373_arg15 = L_373_arg15.EasingStyle
		L_373_arg15 = L_373_arg15.Back
		L_369_arg11(L_370_arg12, L_371_arg13, L_372_arg14, L_373_arg15)
		L_369_arg11 = L_10_func(L_359_arg1, "task")
		L_369_arg11 = L_369_arg11.delay
		L_370_arg12 = L_362_arg4
		L_371_arg13 = L_14_func(L_13_.fn_044_delayedTween, L_359_arg1, {
			{
				L_364_arg6
			}
		})
		L_369_arg11(L_370_arg12, L_371_arg13)
		return
	end
	L_367_arg9 = L_358_arg0[3][1]
	L_366_arg8 = L_367_arg9.Accent
	L_367_arg9 = 1.5
	L_368_arg10 = L_364_arg6
	L_365_arg7(L_366_arg8, L_367_arg9, L_368_arg10)
	L_365_arg7 = L_10_func(L_359_arg1, "gradient")
	L_366_arg8 = L_364_arg6
	L_368_arg10 = L_358_arg0[3][1]
	L_367_arg9 = L_368_arg10.BgSecondary
	L_369_arg11 = L_358_arg0[3][1]
	L_368_arg10 = L_369_arg11.BgCard
	L_369_arg11 = 90
	L_365_arg7(L_366_arg8, L_367_arg9, L_368_arg10, L_369_arg11)
	L_365_arg7 = L_10_func(L_359_arg1, "Instance")
	L_365_arg7 = L_365_arg7.new
	L_366_arg8 = "Frame"
	L_367_arg9 = L_364_arg6
	L_365_arg7 = L_365_arg7(L_366_arg8, L_367_arg9)
	L_366_arg8 = L_10_func(L_359_arg1, "UDim2")
	L_366_arg8 = L_366_arg8.new
	L_367_arg9 = 0
	L_368_arg10 = 5
	L_369_arg11 = 0.6
	L_370_arg12 = 0
	L_366_arg8 = L_366_arg8(L_367_arg9, L_368_arg10, L_369_arg11, L_370_arg12)
	L_365_arg7.Size = L_366_arg8
	L_366_arg8 = L_10_func(L_359_arg1, "UDim2")
	L_366_arg8 = L_366_arg8.new
	L_367_arg9 = 0
	L_368_arg10 = 10
	L_369_arg11 = 0.2
	L_370_arg12 = 0
	L_366_arg8 = L_366_arg8(L_367_arg9, L_368_arg10, L_369_arg11, L_370_arg12)
	L_365_arg7.Position = L_366_arg8
	if L_363_arg5 then
		L_367_arg9 = L_358_arg0[3][1]
		L_366_arg8 = L_367_arg9.Premium
		if not L_366_arg8 then
			L_367_arg9 = L_358_arg0[3][1]
			L_366_arg8 = L_367_arg9.Accent
		end
		L_365_arg7.BackgroundColor3 = L_366_arg8
		L_366_arg8 = 0
		L_365_arg7.BorderSizePixel = L_366_arg8
		L_366_arg8 = 501
		L_365_arg7.ZIndex = L_366_arg8
		L_366_arg8 = L_10_func(L_359_arg1, "corner")
		L_368_arg10 = L_358_arg0[3][1]
		L_367_arg9 = L_368_arg10.RadiusPill
		L_368_arg10 = L_365_arg7
		L_366_arg8(L_367_arg9, L_368_arg10)
		L_366_arg8 = L_10_func(L_359_arg1, "Instance")
		L_366_arg8 = L_366_arg8.new
		L_367_arg9 = "TextLabel"
		L_368_arg10 = L_364_arg6
		L_366_arg8 = L_366_arg8(L_367_arg9, L_368_arg10)
		L_367_arg9 = L_10_func(L_359_arg1, "UDim2")
		L_367_arg9 = L_367_arg9.new
		L_368_arg10 = 1
		L_369_arg11 = -40
		L_370_arg12 = 0
		L_371_arg13 = 22
		L_367_arg9 = L_367_arg9(L_368_arg10, L_369_arg11, L_370_arg12, L_371_arg13)
		L_366_arg8.Size = L_367_arg9
		L_367_arg9 = L_10_func(L_359_arg1, "UDim2")
		L_367_arg9 = L_367_arg9.new
		L_368_arg10 = 0
		L_369_arg11 = 24
		L_370_arg12 = 0
		L_371_arg13 = 10
		L_367_arg9 = L_367_arg9(L_368_arg10, L_369_arg11, L_370_arg12, L_371_arg13)
		L_366_arg8.Position = L_367_arg9
		L_367_arg9 = 1
		L_366_arg8.BackgroundTransparency = L_367_arg9
		L_366_arg8.Text = L_360_arg2
		if L_363_arg5 then
			L_368_arg10 = L_358_arg0[3][1]
			L_367_arg9 = L_368_arg10.Premium
			if not L_367_arg9 then
				L_368_arg10 = L_358_arg0[3][1]
				L_367_arg9 = L_368_arg10.AccentBright
			end
			L_366_arg8.TextColor3 = L_367_arg9
			L_367_arg9 = L_10_func(L_359_arg1, "Enum")
			L_367_arg9 = L_367_arg9.Font
			L_367_arg9 = L_367_arg9.GothamBlack
			L_366_arg8.Font = L_367_arg9
			L_367_arg9 = 14
			L_366_arg8.TextSize = L_367_arg9
			L_367_arg9 = 501
			L_366_arg8.ZIndex = L_367_arg9
			L_367_arg9 = L_10_func(L_359_arg1, "Enum")
			L_367_arg9 = L_367_arg9.TextXAlignment
			L_367_arg9 = L_367_arg9.Left
			L_366_arg8.TextXAlignment = L_367_arg9
			L_367_arg9 = L_10_func(L_359_arg1, "Instance")
			L_367_arg9 = L_367_arg9.new
			L_368_arg10 = "TextLabel"
			L_369_arg11 = L_364_arg6
			L_367_arg9 = L_367_arg9(L_368_arg10, L_369_arg11)
			L_368_arg10 = L_10_func(L_359_arg1, "UDim2")
			L_368_arg10 = L_368_arg10.new
			L_369_arg11 = 1
			L_370_arg12 = -40
			L_371_arg13 = 0
			L_372_arg14 = 36
			L_368_arg10 = L_368_arg10(L_369_arg11, L_370_arg12, L_371_arg13, L_372_arg14)
			L_367_arg9.Size = L_368_arg10
			L_368_arg10 = L_10_func(L_359_arg1, "UDim2")
			L_368_arg10 = L_368_arg10.new
			L_369_arg11 = 0
			L_370_arg12 = 24
			L_371_arg13 = 0
			L_372_arg14 = 34
			L_368_arg10 = L_368_arg10(L_369_arg11, L_370_arg12, L_371_arg13, L_372_arg14)
			L_367_arg9.Position = L_368_arg10
			L_368_arg10 = 1
			L_367_arg9.BackgroundTransparency = L_368_arg10
			L_367_arg9.Text = L_361_arg3
			L_369_arg11 = L_358_arg0[3][1]
			L_368_arg10 = L_369_arg11.TextSecondary
			L_367_arg9.TextColor3 = L_368_arg10
			L_368_arg10 = L_10_func(L_359_arg1, "Enum")
			L_368_arg10 = L_368_arg10.Font
			L_368_arg10 = L_368_arg10.Gotham
			L_367_arg9.Font = L_368_arg10
			L_368_arg10 = 12
			L_367_arg9.TextSize = L_368_arg10
			L_368_arg10 = true
			L_367_arg9.TextWrapped = L_368_arg10
			L_368_arg10 = 501
			L_367_arg9.ZIndex = L_368_arg10
			L_368_arg10 = L_10_func(L_359_arg1, "Enum")
			L_368_arg10 = L_368_arg10.TextXAlignment
			L_368_arg10 = L_368_arg10.Left
			L_367_arg9.TextXAlignment = L_368_arg10
			L_368_arg10 = L_10_func(L_359_arg1, "Instance")
			L_368_arg10 = L_368_arg10.new
			L_369_arg11 = "Frame"
			L_370_arg12 = L_364_arg6
			L_368_arg10 = L_368_arg10(L_369_arg11, L_370_arg12)
			L_369_arg11 = L_10_func(L_359_arg1, "UDim2")
			L_369_arg11 = L_369_arg11.new
			L_370_arg12 = 1
			L_371_arg13 = -20
			L_372_arg14 = 0
			L_373_arg15 = 3
			L_369_arg11 = L_369_arg11(L_370_arg12, L_371_arg13, L_372_arg14, L_373_arg15)
			L_368_arg10.Size = L_369_arg11
			L_369_arg11 = L_10_func(L_359_arg1, "UDim2")
			L_369_arg11 = L_369_arg11.new
			L_370_arg12 = 0
			L_371_arg13 = 10
			L_372_arg14 = 1
			L_373_arg15 = -8
			L_369_arg11 = L_369_arg11(L_370_arg12, L_371_arg13, L_372_arg14, L_373_arg15)
			L_368_arg10.Position = L_369_arg11
			if L_363_arg5 then
				L_370_arg12 = L_358_arg0[3][1]
				L_369_arg11 = L_370_arg12.Premium
				if not L_369_arg11 then
					L_370_arg12 = L_358_arg0[3][1]
					L_369_arg11 = L_370_arg12.Accent
				end
				L_368_arg10.BackgroundColor3 = L_369_arg11
				L_369_arg11 = 501
				L_368_arg10.ZIndex = L_369_arg11
				L_369_arg11 = L_10_func(L_359_arg1, "corner")
				L_371_arg13 = L_358_arg0[3][1]
				L_370_arg12 = L_371_arg13.RadiusPill
				L_371_arg13 = L_368_arg10
				L_369_arg11(L_370_arg12, L_371_arg13)
				L_369_arg11 = L_10_func(L_359_arg1, "tw")
				L_370_arg12 = L_368_arg10
				L_371_arg13 = {}
				L_372_arg14 = L_10_func(L_359_arg1, "UDim2")
				L_372_arg14 = L_372_arg14.new
				L_373_arg15 = 0
				L_374_arg16 = 0
				L_375_arg17 = 0
				L_376_arg18 = 3
				L_372_arg14 = L_372_arg14(L_373_arg15, L_374_arg16, L_375_arg17, L_376_arg18)
				L_371_arg13.Size = L_372_arg14
				L_372_arg14 = L_362_arg4
				L_373_arg15 = L_10_func(L_359_arg1, "Enum")
				L_373_arg15 = L_373_arg15.EasingStyle
				L_373_arg15 = L_373_arg15.Linear
				L_369_arg11(L_370_arg12, L_371_arg13, L_372_arg14, L_373_arg15)
				L_369_arg11 = L_10_func(L_359_arg1, "tw")
				L_370_arg12 = L_364_arg6
				L_371_arg13 = {}
				L_372_arg14 = L_10_func(L_359_arg1, "UDim2")
				L_372_arg14 = L_372_arg14.new
				L_373_arg15 = 1
				L_374_arg16 = -360
				L_375_arg17 = 1
				L_376_arg18 = -100
				L_372_arg14 = L_372_arg14(L_373_arg15, L_374_arg16, L_375_arg17, L_376_arg18)
				L_371_arg13.Position = L_372_arg14
				L_372_arg14 = 0.5
				L_373_arg15 = L_10_func(L_359_arg1, "Enum")
				L_373_arg15 = L_373_arg15.EasingStyle
				L_373_arg15 = L_373_arg15.Back
				L_369_arg11(L_370_arg12, L_371_arg13, L_372_arg14, L_373_arg15)
				L_369_arg11 = L_10_func(L_359_arg1, "task")
				L_369_arg11 = L_369_arg11.delay
				L_370_arg12 = L_362_arg4
				L_371_arg13 = L_14_func(L_13_.fn_044_delayedTween, L_359_arg1, {
					{
						L_364_arg6
					}
				})
				L_369_arg11(L_370_arg12, L_371_arg13)
				return
			end
			L_370_arg12 = L_358_arg0[3][1]
			L_369_arg11 = L_370_arg12.Accent
			L_368_arg10.BackgroundColor3 = L_369_arg11
			L_369_arg11 = 501
			L_368_arg10.ZIndex = L_369_arg11
			L_369_arg11 = L_10_func(L_359_arg1, "corner")
			L_371_arg13 = L_358_arg0[3][1]
			L_370_arg12 = L_371_arg13.RadiusPill
			L_371_arg13 = L_368_arg10
			L_369_arg11(L_370_arg12, L_371_arg13)
			L_369_arg11 = L_10_func(L_359_arg1, "tw")
			L_370_arg12 = L_368_arg10
			L_371_arg13 = {}
			L_372_arg14 = L_10_func(L_359_arg1, "UDim2")
			L_372_arg14 = L_372_arg14.new
			L_373_arg15 = 0
			L_374_arg16 = 0
			L_375_arg17 = 0
			L_376_arg18 = 3
			L_372_arg14 = L_372_arg14(L_373_arg15, L_374_arg16, L_375_arg17, L_376_arg18)
			L_371_arg13.Size = L_372_arg14
			L_372_arg14 = L_362_arg4
			L_373_arg15 = L_10_func(L_359_arg1, "Enum")
			L_373_arg15 = L_373_arg15.EasingStyle
			L_373_arg15 = L_373_arg15.Linear
			L_369_arg11(L_370_arg12, L_371_arg13, L_372_arg14, L_373_arg15)
			L_369_arg11 = L_10_func(L_359_arg1, "tw")
			L_370_arg12 = L_364_arg6
			L_371_arg13 = {}
			L_372_arg14 = L_10_func(L_359_arg1, "UDim2")
			L_372_arg14 = L_372_arg14.new
			L_373_arg15 = 1
			L_374_arg16 = -360
			L_375_arg17 = 1
			L_376_arg18 = -100
			L_372_arg14 = L_372_arg14(L_373_arg15, L_374_arg16, L_375_arg17, L_376_arg18)
			L_371_arg13.Position = L_372_arg14
			L_372_arg14 = 0.5
			L_373_arg15 = L_10_func(L_359_arg1, "Enum")
			L_373_arg15 = L_373_arg15.EasingStyle
			L_373_arg15 = L_373_arg15.Back
			L_369_arg11(L_370_arg12, L_371_arg13, L_372_arg14, L_373_arg15)
			L_369_arg11 = L_10_func(L_359_arg1, "task")
			L_369_arg11 = L_369_arg11.delay
			L_370_arg12 = L_362_arg4
			L_371_arg13 = L_14_func(L_13_.fn_044_delayedTween, L_359_arg1, {
				{
					L_364_arg6
				}
			})
			L_369_arg11(L_370_arg12, L_371_arg13)
			return
		end
		L_368_arg10 = L_358_arg0[3][1]
		L_367_arg9 = L_368_arg10.AccentBright
		L_366_arg8.TextColor3 = L_367_arg9
		L_367_arg9 = L_10_func(L_359_arg1, "Enum")
		L_367_arg9 = L_367_arg9.Font
		L_367_arg9 = L_367_arg9.GothamBlack
		L_366_arg8.Font = L_367_arg9
		L_367_arg9 = 14
		L_366_arg8.TextSize = L_367_arg9
		L_367_arg9 = 501
		L_366_arg8.ZIndex = L_367_arg9
		L_367_arg9 = L_10_func(L_359_arg1, "Enum")
		L_367_arg9 = L_367_arg9.TextXAlignment
		L_367_arg9 = L_367_arg9.Left
		L_366_arg8.TextXAlignment = L_367_arg9
		L_367_arg9 = L_10_func(L_359_arg1, "Instance")
		L_367_arg9 = L_367_arg9.new
		L_368_arg10 = "TextLabel"
		L_369_arg11 = L_364_arg6
		L_367_arg9 = L_367_arg9(L_368_arg10, L_369_arg11)
		L_368_arg10 = L_10_func(L_359_arg1, "UDim2")
		L_368_arg10 = L_368_arg10.new
		L_369_arg11 = 1
		L_370_arg12 = -40
		L_371_arg13 = 0
		L_372_arg14 = 36
		L_368_arg10 = L_368_arg10(L_369_arg11, L_370_arg12, L_371_arg13, L_372_arg14)
		L_367_arg9.Size = L_368_arg10
		L_368_arg10 = L_10_func(L_359_arg1, "UDim2")
		L_368_arg10 = L_368_arg10.new
		L_369_arg11 = 0
		L_370_arg12 = 24
		L_371_arg13 = 0
		L_372_arg14 = 34
		L_368_arg10 = L_368_arg10(L_369_arg11, L_370_arg12, L_371_arg13, L_372_arg14)
		L_367_arg9.Position = L_368_arg10
		L_368_arg10 = 1
		L_367_arg9.BackgroundTransparency = L_368_arg10
		L_367_arg9.Text = L_361_arg3
		L_369_arg11 = L_358_arg0[3][1]
		L_368_arg10 = L_369_arg11.TextSecondary
		L_367_arg9.TextColor3 = L_368_arg10
		L_368_arg10 = L_10_func(L_359_arg1, "Enum")
		L_368_arg10 = L_368_arg10.Font
		L_368_arg10 = L_368_arg10.Gotham
		L_367_arg9.Font = L_368_arg10
		L_368_arg10 = 12
		L_367_arg9.TextSize = L_368_arg10
		L_368_arg10 = true
		L_367_arg9.TextWrapped = L_368_arg10
		L_368_arg10 = 501
		L_367_arg9.ZIndex = L_368_arg10
		L_368_arg10 = L_10_func(L_359_arg1, "Enum")
		L_368_arg10 = L_368_arg10.TextXAlignment
		L_368_arg10 = L_368_arg10.Left
		L_367_arg9.TextXAlignment = L_368_arg10
		L_368_arg10 = L_10_func(L_359_arg1, "Instance")
		L_368_arg10 = L_368_arg10.new
		L_369_arg11 = "Frame"
		L_370_arg12 = L_364_arg6
		L_368_arg10 = L_368_arg10(L_369_arg11, L_370_arg12)
		L_369_arg11 = L_10_func(L_359_arg1, "UDim2")
		L_369_arg11 = L_369_arg11.new
		L_370_arg12 = 1
		L_371_arg13 = -20
		L_372_arg14 = 0
		L_373_arg15 = 3
		L_369_arg11 = L_369_arg11(L_370_arg12, L_371_arg13, L_372_arg14, L_373_arg15)
		L_368_arg10.Size = L_369_arg11
		L_369_arg11 = L_10_func(L_359_arg1, "UDim2")
		L_369_arg11 = L_369_arg11.new
		L_370_arg12 = 0
		L_371_arg13 = 10
		L_372_arg14 = 1
		L_373_arg15 = -8
		L_369_arg11 = L_369_arg11(L_370_arg12, L_371_arg13, L_372_arg14, L_373_arg15)
		L_368_arg10.Position = L_369_arg11
		if L_363_arg5 then
			L_370_arg12 = L_358_arg0[3][1]
			L_369_arg11 = L_370_arg12.Premium
			if not L_369_arg11 then
				L_370_arg12 = L_358_arg0[3][1]
				L_369_arg11 = L_370_arg12.Accent
			end
			L_368_arg10.BackgroundColor3 = L_369_arg11
			L_369_arg11 = 501
			L_368_arg10.ZIndex = L_369_arg11
			L_369_arg11 = L_10_func(L_359_arg1, "corner")
			L_371_arg13 = L_358_arg0[3][1]
			L_370_arg12 = L_371_arg13.RadiusPill
			L_371_arg13 = L_368_arg10
			L_369_arg11(L_370_arg12, L_371_arg13)
			L_369_arg11 = L_10_func(L_359_arg1, "tw")
			L_370_arg12 = L_368_arg10
			L_371_arg13 = {}
			L_372_arg14 = L_10_func(L_359_arg1, "UDim2")
			L_372_arg14 = L_372_arg14.new
			L_373_arg15 = 0
			L_374_arg16 = 0
			L_375_arg17 = 0
			L_376_arg18 = 3
			L_372_arg14 = L_372_arg14(L_373_arg15, L_374_arg16, L_375_arg17, L_376_arg18)
			L_371_arg13.Size = L_372_arg14
			L_372_arg14 = L_362_arg4
			L_373_arg15 = L_10_func(L_359_arg1, "Enum")
			L_373_arg15 = L_373_arg15.EasingStyle
			L_373_arg15 = L_373_arg15.Linear
			L_369_arg11(L_370_arg12, L_371_arg13, L_372_arg14, L_373_arg15)
			L_369_arg11 = L_10_func(L_359_arg1, "tw")
			L_370_arg12 = L_364_arg6
			L_371_arg13 = {}
			L_372_arg14 = L_10_func(L_359_arg1, "UDim2")
			L_372_arg14 = L_372_arg14.new
			L_373_arg15 = 1
			L_374_arg16 = -360
			L_375_arg17 = 1
			L_376_arg18 = -100
			L_372_arg14 = L_372_arg14(L_373_arg15, L_374_arg16, L_375_arg17, L_376_arg18)
			L_371_arg13.Position = L_372_arg14
			L_372_arg14 = 0.5
			L_373_arg15 = L_10_func(L_359_arg1, "Enum")
			L_373_arg15 = L_373_arg15.EasingStyle
			L_373_arg15 = L_373_arg15.Back
			L_369_arg11(L_370_arg12, L_371_arg13, L_372_arg14, L_373_arg15)
			L_369_arg11 = L_10_func(L_359_arg1, "task")
			L_369_arg11 = L_369_arg11.delay
			L_370_arg12 = L_362_arg4
			L_371_arg13 = L_14_func(L_13_.fn_044_delayedTween, L_359_arg1, {
				{
					L_364_arg6
				}
			})
			L_369_arg11(L_370_arg12, L_371_arg13)
			return
		end
		L_370_arg12 = L_358_arg0[3][1]
		L_369_arg11 = L_370_arg12.Accent
		L_368_arg10.BackgroundColor3 = L_369_arg11
		L_369_arg11 = 501
		L_368_arg10.ZIndex = L_369_arg11
		L_369_arg11 = L_10_func(L_359_arg1, "corner")
		L_371_arg13 = L_358_arg0[3][1]
		L_370_arg12 = L_371_arg13.RadiusPill
		L_371_arg13 = L_368_arg10
		L_369_arg11(L_370_arg12, L_371_arg13)
		L_369_arg11 = L_10_func(L_359_arg1, "tw")
		L_370_arg12 = L_368_arg10
		L_371_arg13 = {}
		L_372_arg14 = L_10_func(L_359_arg1, "UDim2")
		L_372_arg14 = L_372_arg14.new
		L_373_arg15 = 0
		L_374_arg16 = 0
		L_375_arg17 = 0
		L_376_arg18 = 3
		L_372_arg14 = L_372_arg14(L_373_arg15, L_374_arg16, L_375_arg17, L_376_arg18)
		L_371_arg13.Size = L_372_arg14
		L_372_arg14 = L_362_arg4
		L_373_arg15 = L_10_func(L_359_arg1, "Enum")
		L_373_arg15 = L_373_arg15.EasingStyle
		L_373_arg15 = L_373_arg15.Linear
		L_369_arg11(L_370_arg12, L_371_arg13, L_372_arg14, L_373_arg15)
		L_369_arg11 = L_10_func(L_359_arg1, "tw")
		L_370_arg12 = L_364_arg6
		L_371_arg13 = {}
		L_372_arg14 = L_10_func(L_359_arg1, "UDim2")
		L_372_arg14 = L_372_arg14.new
		L_373_arg15 = 1
		L_374_arg16 = -360
		L_375_arg17 = 1
		L_376_arg18 = -100
		L_372_arg14 = L_372_arg14(L_373_arg15, L_374_arg16, L_375_arg17, L_376_arg18)
		L_371_arg13.Position = L_372_arg14
		L_372_arg14 = 0.5
		L_373_arg15 = L_10_func(L_359_arg1, "Enum")
		L_373_arg15 = L_373_arg15.EasingStyle
		L_373_arg15 = L_373_arg15.Back
		L_369_arg11(L_370_arg12, L_371_arg13, L_372_arg14, L_373_arg15)
		L_369_arg11 = L_10_func(L_359_arg1, "task")
		L_369_arg11 = L_369_arg11.delay
		L_370_arg12 = L_362_arg4
		L_371_arg13 = L_14_func(L_13_.fn_044_delayedTween, L_359_arg1, {
			{
				L_364_arg6
			}
		})
		L_369_arg11(L_370_arg12, L_371_arg13)
		return
	end
	L_367_arg9 = L_358_arg0[3][1]
	L_366_arg8 = L_367_arg9.Accent
	L_365_arg7.BackgroundColor3 = L_366_arg8
	L_366_arg8 = 0
	L_365_arg7.BorderSizePixel = L_366_arg8
	L_366_arg8 = 501
	L_365_arg7.ZIndex = L_366_arg8
	L_366_arg8 = L_10_func(L_359_arg1, "corner")
	L_368_arg10 = L_358_arg0[3][1]
	L_367_arg9 = L_368_arg10.RadiusPill
	L_368_arg10 = L_365_arg7
	L_366_arg8(L_367_arg9, L_368_arg10)
	L_366_arg8 = L_10_func(L_359_arg1, "Instance")
	L_366_arg8 = L_366_arg8.new
	L_367_arg9 = "TextLabel"
	L_368_arg10 = L_364_arg6
	L_366_arg8 = L_366_arg8(L_367_arg9, L_368_arg10)
	L_367_arg9 = L_10_func(L_359_arg1, "UDim2")
	L_367_arg9 = L_367_arg9.new
	L_368_arg10 = 1
	L_369_arg11 = -40
	L_370_arg12 = 0
	L_371_arg13 = 22
	L_367_arg9 = L_367_arg9(L_368_arg10, L_369_arg11, L_370_arg12, L_371_arg13)
	L_366_arg8.Size = L_367_arg9
	L_367_arg9 = L_10_func(L_359_arg1, "UDim2")
	L_367_arg9 = L_367_arg9.new
	L_368_arg10 = 0
	L_369_arg11 = 24
	L_370_arg12 = 0
	L_371_arg13 = 10
	L_367_arg9 = L_367_arg9(L_368_arg10, L_369_arg11, L_370_arg12, L_371_arg13)
	L_366_arg8.Position = L_367_arg9
	L_367_arg9 = 1
	L_366_arg8.BackgroundTransparency = L_367_arg9
	L_366_arg8.Text = L_360_arg2
	if L_363_arg5 then
		L_368_arg10 = L_358_arg0[3][1]
		L_367_arg9 = L_368_arg10.Premium
		if not L_367_arg9 then
			L_368_arg10 = L_358_arg0[3][1]
			L_367_arg9 = L_368_arg10.AccentBright
		end
		L_366_arg8.TextColor3 = L_367_arg9
		L_367_arg9 = L_10_func(L_359_arg1, "Enum")
		L_367_arg9 = L_367_arg9.Font
		L_367_arg9 = L_367_arg9.GothamBlack
		L_366_arg8.Font = L_367_arg9
		L_367_arg9 = 14
		L_366_arg8.TextSize = L_367_arg9
		L_367_arg9 = 501
		L_366_arg8.ZIndex = L_367_arg9
		L_367_arg9 = L_10_func(L_359_arg1, "Enum")
		L_367_arg9 = L_367_arg9.TextXAlignment
		L_367_arg9 = L_367_arg9.Left
		L_366_arg8.TextXAlignment = L_367_arg9
		L_367_arg9 = L_10_func(L_359_arg1, "Instance")
		L_367_arg9 = L_367_arg9.new
		L_368_arg10 = "TextLabel"
		L_369_arg11 = L_364_arg6
		L_367_arg9 = L_367_arg9(L_368_arg10, L_369_arg11)
		L_368_arg10 = L_10_func(L_359_arg1, "UDim2")
		L_368_arg10 = L_368_arg10.new
		L_369_arg11 = 1
		L_370_arg12 = -40
		L_371_arg13 = 0
		L_372_arg14 = 36
		L_368_arg10 = L_368_arg10(L_369_arg11, L_370_arg12, L_371_arg13, L_372_arg14)
		L_367_arg9.Size = L_368_arg10
		L_368_arg10 = L_10_func(L_359_arg1, "UDim2")
		L_368_arg10 = L_368_arg10.new
		L_369_arg11 = 0
		L_370_arg12 = 24
		L_371_arg13 = 0
		L_372_arg14 = 34
		L_368_arg10 = L_368_arg10(L_369_arg11, L_370_arg12, L_371_arg13, L_372_arg14)
		L_367_arg9.Position = L_368_arg10
		L_368_arg10 = 1
		L_367_arg9.BackgroundTransparency = L_368_arg10
		L_367_arg9.Text = L_361_arg3
		L_369_arg11 = L_358_arg0[3][1]
		L_368_arg10 = L_369_arg11.TextSecondary
		L_367_arg9.TextColor3 = L_368_arg10
		L_368_arg10 = L_10_func(L_359_arg1, "Enum")
		L_368_arg10 = L_368_arg10.Font
		L_368_arg10 = L_368_arg10.Gotham
		L_367_arg9.Font = L_368_arg10
		L_368_arg10 = 12
		L_367_arg9.TextSize = L_368_arg10
		L_368_arg10 = true
		L_367_arg9.TextWrapped = L_368_arg10
		L_368_arg10 = 501
		L_367_arg9.ZIndex = L_368_arg10
		L_368_arg10 = L_10_func(L_359_arg1, "Enum")
		L_368_arg10 = L_368_arg10.TextXAlignment
		L_368_arg10 = L_368_arg10.Left
		L_367_arg9.TextXAlignment = L_368_arg10
		L_368_arg10 = L_10_func(L_359_arg1, "Instance")
		L_368_arg10 = L_368_arg10.new
		L_369_arg11 = "Frame"
		L_370_arg12 = L_364_arg6
		L_368_arg10 = L_368_arg10(L_369_arg11, L_370_arg12)
		L_369_arg11 = L_10_func(L_359_arg1, "UDim2")
		L_369_arg11 = L_369_arg11.new
		L_370_arg12 = 1
		L_371_arg13 = -20
		L_372_arg14 = 0
		L_373_arg15 = 3
		L_369_arg11 = L_369_arg11(L_370_arg12, L_371_arg13, L_372_arg14, L_373_arg15)
		L_368_arg10.Size = L_369_arg11
		L_369_arg11 = L_10_func(L_359_arg1, "UDim2")
		L_369_arg11 = L_369_arg11.new
		L_370_arg12 = 0
		L_371_arg13 = 10
		L_372_arg14 = 1
		L_373_arg15 = -8
		L_369_arg11 = L_369_arg11(L_370_arg12, L_371_arg13, L_372_arg14, L_373_arg15)
		L_368_arg10.Position = L_369_arg11
		if L_363_arg5 then
			L_370_arg12 = L_358_arg0[3][1]
			L_369_arg11 = L_370_arg12.Premium
			if not L_369_arg11 then
				L_370_arg12 = L_358_arg0[3][1]
				L_369_arg11 = L_370_arg12.Accent
			end
			L_368_arg10.BackgroundColor3 = L_369_arg11
			L_369_arg11 = 501
			L_368_arg10.ZIndex = L_369_arg11
			L_369_arg11 = L_10_func(L_359_arg1, "corner")
			L_371_arg13 = L_358_arg0[3][1]
			L_370_arg12 = L_371_arg13.RadiusPill
			L_371_arg13 = L_368_arg10
			L_369_arg11(L_370_arg12, L_371_arg13)
			L_369_arg11 = L_10_func(L_359_arg1, "tw")
			L_370_arg12 = L_368_arg10
			L_371_arg13 = {}
			L_372_arg14 = L_10_func(L_359_arg1, "UDim2")
			L_372_arg14 = L_372_arg14.new
			L_373_arg15 = 0
			L_374_arg16 = 0
			L_375_arg17 = 0
			L_376_arg18 = 3
			L_372_arg14 = L_372_arg14(L_373_arg15, L_374_arg16, L_375_arg17, L_376_arg18)
			L_371_arg13.Size = L_372_arg14
			L_372_arg14 = L_362_arg4
			L_373_arg15 = L_10_func(L_359_arg1, "Enum")
			L_373_arg15 = L_373_arg15.EasingStyle
			L_373_arg15 = L_373_arg15.Linear
			L_369_arg11(L_370_arg12, L_371_arg13, L_372_arg14, L_373_arg15)
			L_369_arg11 = L_10_func(L_359_arg1, "tw")
			L_370_arg12 = L_364_arg6
			L_371_arg13 = {}
			L_372_arg14 = L_10_func(L_359_arg1, "UDim2")
			L_372_arg14 = L_372_arg14.new
			L_373_arg15 = 1
			L_374_arg16 = -360
			L_375_arg17 = 1
			L_376_arg18 = -100
			L_372_arg14 = L_372_arg14(L_373_arg15, L_374_arg16, L_375_arg17, L_376_arg18)
			L_371_arg13.Position = L_372_arg14
			L_372_arg14 = 0.5
			L_373_arg15 = L_10_func(L_359_arg1, "Enum")
			L_373_arg15 = L_373_arg15.EasingStyle
			L_373_arg15 = L_373_arg15.Back
			L_369_arg11(L_370_arg12, L_371_arg13, L_372_arg14, L_373_arg15)
			L_369_arg11 = L_10_func(L_359_arg1, "task")
			L_369_arg11 = L_369_arg11.delay
			L_370_arg12 = L_362_arg4
			L_371_arg13 = L_14_func(L_13_.fn_044_delayedTween, L_359_arg1, {
				{
					L_364_arg6
				}
			})
			L_369_arg11(L_370_arg12, L_371_arg13)
			return
		end
		L_370_arg12 = L_358_arg0[3][1]
		L_369_arg11 = L_370_arg12.Accent
		L_368_arg10.BackgroundColor3 = L_369_arg11
		L_369_arg11 = 501
		L_368_arg10.ZIndex = L_369_arg11
		L_369_arg11 = L_10_func(L_359_arg1, "corner")
		L_371_arg13 = L_358_arg0[3][1]
		L_370_arg12 = L_371_arg13.RadiusPill
		L_371_arg13 = L_368_arg10
		L_369_arg11(L_370_arg12, L_371_arg13)
		L_369_arg11 = L_10_func(L_359_arg1, "tw")
		L_370_arg12 = L_368_arg10
		L_371_arg13 = {}
		L_372_arg14 = L_10_func(L_359_arg1, "UDim2")
		L_372_arg14 = L_372_arg14.new
		L_373_arg15 = 0
		L_374_arg16 = 0
		L_375_arg17 = 0
		L_376_arg18 = 3
		L_372_arg14 = L_372_arg14(L_373_arg15, L_374_arg16, L_375_arg17, L_376_arg18)
		L_371_arg13.Size = L_372_arg14
		L_372_arg14 = L_362_arg4
		L_373_arg15 = L_10_func(L_359_arg1, "Enum")
		L_373_arg15 = L_373_arg15.EasingStyle
		L_373_arg15 = L_373_arg15.Linear
		L_369_arg11(L_370_arg12, L_371_arg13, L_372_arg14, L_373_arg15)
		L_369_arg11 = L_10_func(L_359_arg1, "tw")
		L_370_arg12 = L_364_arg6
		L_371_arg13 = {}
		L_372_arg14 = L_10_func(L_359_arg1, "UDim2")
		L_372_arg14 = L_372_arg14.new
		L_373_arg15 = 1
		L_374_arg16 = -360
		L_375_arg17 = 1
		L_376_arg18 = -100
		L_372_arg14 = L_372_arg14(L_373_arg15, L_374_arg16, L_375_arg17, L_376_arg18)
		L_371_arg13.Position = L_372_arg14
		L_372_arg14 = 0.5
		L_373_arg15 = L_10_func(L_359_arg1, "Enum")
		L_373_arg15 = L_373_arg15.EasingStyle
		L_373_arg15 = L_373_arg15.Back
		L_369_arg11(L_370_arg12, L_371_arg13, L_372_arg14, L_373_arg15)
		L_369_arg11 = L_10_func(L_359_arg1, "task")
		L_369_arg11 = L_369_arg11.delay
		L_370_arg12 = L_362_arg4
		L_371_arg13 = L_14_func(L_13_.fn_044_delayedTween, L_359_arg1, {
			{
				L_364_arg6
			}
		})
		L_369_arg11(L_370_arg12, L_371_arg13)
		return
	end
	L_368_arg10 = L_358_arg0[3][1]
	L_367_arg9 = L_368_arg10.AccentBright
	L_366_arg8.TextColor3 = L_367_arg9
	L_367_arg9 = L_10_func(L_359_arg1, "Enum")
	L_367_arg9 = L_367_arg9.Font
	L_367_arg9 = L_367_arg9.GothamBlack
	L_366_arg8.Font = L_367_arg9
	L_367_arg9 = 14
	L_366_arg8.TextSize = L_367_arg9
	L_367_arg9 = 501
	L_366_arg8.ZIndex = L_367_arg9
	L_367_arg9 = L_10_func(L_359_arg1, "Enum")
	L_367_arg9 = L_367_arg9.TextXAlignment
	L_367_arg9 = L_367_arg9.Left
	L_366_arg8.TextXAlignment = L_367_arg9
	L_367_arg9 = L_10_func(L_359_arg1, "Instance")
	L_367_arg9 = L_367_arg9.new
	L_368_arg10 = "TextLabel"
	L_369_arg11 = L_364_arg6
	L_367_arg9 = L_367_arg9(L_368_arg10, L_369_arg11)
	L_368_arg10 = L_10_func(L_359_arg1, "UDim2")
	L_368_arg10 = L_368_arg10.new
	L_369_arg11 = 1
	L_370_arg12 = -40
	L_371_arg13 = 0
	L_372_arg14 = 36
	L_368_arg10 = L_368_arg10(L_369_arg11, L_370_arg12, L_371_arg13, L_372_arg14)
	L_367_arg9.Size = L_368_arg10
	L_368_arg10 = L_10_func(L_359_arg1, "UDim2")
	L_368_arg10 = L_368_arg10.new
	L_369_arg11 = 0
	L_370_arg12 = 24
	L_371_arg13 = 0
	L_372_arg14 = 34
	L_368_arg10 = L_368_arg10(L_369_arg11, L_370_arg12, L_371_arg13, L_372_arg14)
	L_367_arg9.Position = L_368_arg10
	L_368_arg10 = 1
	L_367_arg9.BackgroundTransparency = L_368_arg10
	L_367_arg9.Text = L_361_arg3
	L_369_arg11 = L_358_arg0[3][1]
	L_368_arg10 = L_369_arg11.TextSecondary
	L_367_arg9.TextColor3 = L_368_arg10
	L_368_arg10 = L_10_func(L_359_arg1, "Enum")
	L_368_arg10 = L_368_arg10.Font
	L_368_arg10 = L_368_arg10.Gotham
	L_367_arg9.Font = L_368_arg10
	L_368_arg10 = 12
	L_367_arg9.TextSize = L_368_arg10
	L_368_arg10 = true
	L_367_arg9.TextWrapped = L_368_arg10
	L_368_arg10 = 501
	L_367_arg9.ZIndex = L_368_arg10
	L_368_arg10 = L_10_func(L_359_arg1, "Enum")
	L_368_arg10 = L_368_arg10.TextXAlignment
	L_368_arg10 = L_368_arg10.Left
	L_367_arg9.TextXAlignment = L_368_arg10
	L_368_arg10 = L_10_func(L_359_arg1, "Instance")
	L_368_arg10 = L_368_arg10.new
	L_369_arg11 = "Frame"
	L_370_arg12 = L_364_arg6
	L_368_arg10 = L_368_arg10(L_369_arg11, L_370_arg12)
	L_369_arg11 = L_10_func(L_359_arg1, "UDim2")
	L_369_arg11 = L_369_arg11.new
	L_370_arg12 = 1
	L_371_arg13 = -20
	L_372_arg14 = 0
	L_373_arg15 = 3
	L_369_arg11 = L_369_arg11(L_370_arg12, L_371_arg13, L_372_arg14, L_373_arg15)
	L_368_arg10.Size = L_369_arg11
	L_369_arg11 = L_10_func(L_359_arg1, "UDim2")
	L_369_arg11 = L_369_arg11.new
	L_370_arg12 = 0
	L_371_arg13 = 10
	L_372_arg14 = 1
	L_373_arg15 = -8
	L_369_arg11 = L_369_arg11(L_370_arg12, L_371_arg13, L_372_arg14, L_373_arg15)
	L_368_arg10.Position = L_369_arg11
	if L_363_arg5 then
		L_370_arg12 = L_358_arg0[3][1]
		L_369_arg11 = L_370_arg12.Premium
		if not L_369_arg11 then
			L_370_arg12 = L_358_arg0[3][1]
			L_369_arg11 = L_370_arg12.Accent
		end
		L_368_arg10.BackgroundColor3 = L_369_arg11
		L_369_arg11 = 501
		L_368_arg10.ZIndex = L_369_arg11
		L_369_arg11 = L_10_func(L_359_arg1, "corner")
		L_371_arg13 = L_358_arg0[3][1]
		L_370_arg12 = L_371_arg13.RadiusPill
		L_371_arg13 = L_368_arg10
		L_369_arg11(L_370_arg12, L_371_arg13)
		L_369_arg11 = L_10_func(L_359_arg1, "tw")
		L_370_arg12 = L_368_arg10
		L_371_arg13 = {}
		L_372_arg14 = L_10_func(L_359_arg1, "UDim2")
		L_372_arg14 = L_372_arg14.new
		L_373_arg15 = 0
		L_374_arg16 = 0
		L_375_arg17 = 0
		L_376_arg18 = 3
		L_372_arg14 = L_372_arg14(L_373_arg15, L_374_arg16, L_375_arg17, L_376_arg18)
		L_371_arg13.Size = L_372_arg14
		L_372_arg14 = L_362_arg4
		L_373_arg15 = L_10_func(L_359_arg1, "Enum")
		L_373_arg15 = L_373_arg15.EasingStyle
		L_373_arg15 = L_373_arg15.Linear
		L_369_arg11(L_370_arg12, L_371_arg13, L_372_arg14, L_373_arg15)
		L_369_arg11 = L_10_func(L_359_arg1, "tw")
		L_370_arg12 = L_364_arg6
		L_371_arg13 = {}
		L_372_arg14 = L_10_func(L_359_arg1, "UDim2")
		L_372_arg14 = L_372_arg14.new
		L_373_arg15 = 1
		L_374_arg16 = -360
		L_375_arg17 = 1
		L_376_arg18 = -100
		L_372_arg14 = L_372_arg14(L_373_arg15, L_374_arg16, L_375_arg17, L_376_arg18)
		L_371_arg13.Position = L_372_arg14
		L_372_arg14 = 0.5
		L_373_arg15 = L_10_func(L_359_arg1, "Enum")
		L_373_arg15 = L_373_arg15.EasingStyle
		L_373_arg15 = L_373_arg15.Back
		L_369_arg11(L_370_arg12, L_371_arg13, L_372_arg14, L_373_arg15)
		L_369_arg11 = L_10_func(L_359_arg1, "task")
		L_369_arg11 = L_369_arg11.delay
		L_370_arg12 = L_362_arg4
		L_371_arg13 = L_14_func(L_13_.fn_044_delayedTween, L_359_arg1, {
			{
				L_364_arg6
			}
		})
		L_369_arg11(L_370_arg12, L_371_arg13)
		return
	end
	L_370_arg12 = L_358_arg0[3][1]
	L_369_arg11 = L_370_arg12.Accent
	L_368_arg10.BackgroundColor3 = L_369_arg11
	L_369_arg11 = 501
	L_368_arg10.ZIndex = L_369_arg11
	L_369_arg11 = L_10_func(L_359_arg1, "corner")
	L_371_arg13 = L_358_arg0[3][1]
	L_370_arg12 = L_371_arg13.RadiusPill
	L_371_arg13 = L_368_arg10
	L_369_arg11(L_370_arg12, L_371_arg13)
	L_369_arg11 = L_10_func(L_359_arg1, "tw")
	L_370_arg12 = L_368_arg10
	L_371_arg13 = {}
	L_372_arg14 = L_10_func(L_359_arg1, "UDim2")
	L_372_arg14 = L_372_arg14.new
	L_373_arg15 = 0
	L_374_arg16 = 0
	L_375_arg17 = 0
	L_376_arg18 = 3
	L_372_arg14 = L_372_arg14(L_373_arg15, L_374_arg16, L_375_arg17, L_376_arg18)
	L_371_arg13.Size = L_372_arg14
	L_372_arg14 = L_362_arg4
	L_373_arg15 = L_10_func(L_359_arg1, "Enum")
	L_373_arg15 = L_373_arg15.EasingStyle
	L_373_arg15 = L_373_arg15.Linear
	L_369_arg11(L_370_arg12, L_371_arg13, L_372_arg14, L_373_arg15)
	L_369_arg11 = L_10_func(L_359_arg1, "tw")
	L_370_arg12 = L_364_arg6
	L_371_arg13 = {}
	L_372_arg14 = L_10_func(L_359_arg1, "UDim2")
	L_372_arg14 = L_372_arg14.new
	L_373_arg15 = 1
	L_374_arg16 = -360
	L_375_arg17 = 1
	L_376_arg18 = -100
	L_372_arg14 = L_372_arg14(L_373_arg15, L_374_arg16, L_375_arg17, L_376_arg18)
	L_371_arg13.Position = L_372_arg14
	L_372_arg14 = 0.5
	L_373_arg15 = L_10_func(L_359_arg1, "Enum")
	L_373_arg15 = L_373_arg15.EasingStyle
	L_373_arg15 = L_373_arg15.Back
	L_369_arg11(L_370_arg12, L_371_arg13, L_372_arg14, L_373_arg15)
	L_369_arg11 = L_10_func(L_359_arg1, "task")
	L_369_arg11 = L_369_arg11.delay
	L_370_arg12 = L_362_arg4
	L_371_arg13 = L_14_func(L_13_.fn_044_delayedTween, L_359_arg1, {
		{
			L_364_arg6
		}
	})
	L_369_arg11(L_370_arg12, L_371_arg13)
	return
end

L_13_.fn_046_Notify = function(L_377_arg0, L_378_arg1, L_379_arg2, L_380_arg3, L_381_arg4, L_382_arg5, L_383_arg6, L_384_arg7, L_385_arg8, L_386_arg9, L_387_arg10, L_388_arg11, L_389_arg12)
	L_384_arg7 = L_10_func(L_378_arg1, "task")
	L_384_arg7 = L_384_arg7.spawn
	L_385_arg8 = L_377_arg0[1][1]
	L_386_arg9 = L_380_arg3
	L_387_arg10 = L_381_arg4
	L_388_arg11 = L_382_arg5
	L_389_arg12 = L_383_arg6
	L_384_arg7(L_385_arg8, L_386_arg9, L_387_arg10, L_388_arg11, L_389_arg12)
	return
end

L_13_.fn_047_destroyNotification = function(L_390_arg0, L_391_arg1, L_392_arg2, L_393_arg3)
	L_392_arg2 = L_390_arg0[1][1]
	do
		local L_394_ = L_392_arg2;
		L_393_arg3 = L_394_;
		L_392_arg2 = L_394_.Destroy
	end
	L_392_arg2(L_393_arg3)
	return
end

L_13_.fn_048_protectGuiSyn = function(L_395_arg0, L_396_arg1, L_397_arg2, L_398_arg3)
	L_397_arg2 = L_10_func(L_396_arg1, "syn")
	L_397_arg2 = L_397_arg2.protect_gui
	L_398_arg3 = L_395_arg0[1][1]
	L_397_arg2(L_398_arg3)
	L_397_arg2 = L_395_arg0[1][1]
	L_398_arg3 = L_395_arg0[2][1]
	L_397_arg2.Parent = L_398_arg3
	L_397_arg2 = true
	L_395_arg0[3][1] = L_397_arg2
	return
end

L_13_.fn_049_parentToHiddenUi = function(L_399_arg0, L_400_arg1, L_401_arg2, L_402_arg3)
	L_401_arg2 = L_399_arg0[1][1]
	L_402_arg3 = L_10_func(L_400_arg1, "gethui")
	L_402_arg3 = L_402_arg3()
	L_401_arg2.Parent = L_402_arg3
	L_401_arg2 = true
	L_399_arg0[2][1] = L_401_arg2
	return
end

L_13_.fn_050_parentToHiddenGui = function(L_403_arg0, L_404_arg1, L_405_arg2, L_406_arg3)
	L_405_arg2 = L_403_arg0[1][1]
	L_406_arg3 = L_10_func(L_404_arg1, "get_hidden_gui")
	L_406_arg3 = L_406_arg3()
	L_405_arg2.Parent = L_406_arg3
	L_405_arg2 = true
	L_403_arg0[2][1] = L_405_arg2
	return
end

L_13_.fn_051_parentToPlayerGui = function(L_407_arg0, L_408_arg1, L_409_arg2, L_410_arg3, L_411_arg4, L_412_arg5)
	L_409_arg2 = L_407_arg0[1][1]
	L_411_arg4 = L_407_arg0[2][1]
	do
		local L_413_ = L_411_arg4;
		L_412_arg5 = L_413_;
		L_411_arg4 = L_413_.IsStudio
	end
	L_411_arg4 = L_411_arg4(L_412_arg5)
	if L_411_arg4 then
		L_411_arg4 = L_407_arg0[3][1]
		L_410_arg3 = L_411_arg4.PlayerGui
		if not L_410_arg3 then
			L_410_arg3 = L_407_arg0[4][1]
		end
		L_409_arg2.Parent = L_410_arg3
		return
	end
	L_410_arg3 = L_407_arg0[4][1]
	L_409_arg2.Parent = L_410_arg3
	return
end

L_13_.fn_052_showTween = function(L_414_arg0, L_415_arg1, L_416_arg2, L_417_arg3, L_418_arg4, L_419_arg5, L_420_arg6, L_421_arg7, L_422_arg8, L_423_arg9)
	L_416_arg2 = L_10_func(L_415_arg1, "tw")
	L_417_arg3 = L_414_arg0[1][1]
	L_418_arg4 = {}
	L_419_arg5 = L_10_func(L_415_arg1, "UDim2")
	L_419_arg5 = L_419_arg5.new
	L_420_arg6 = 1
	L_421_arg7 = -52
	L_422_arg8 = 0
	L_423_arg9 = 46
	L_419_arg5 = L_419_arg5(L_420_arg6, L_421_arg7, L_422_arg8, L_423_arg9)
	L_418_arg4.Size = L_419_arg5
	L_419_arg5 = 0.15
	L_416_arg2(L_417_arg3, L_418_arg4, L_419_arg5)
	return
end

L_13_.fn_053_hideTween = function(L_424_arg0, L_425_arg1, L_426_arg2, L_427_arg3, L_428_arg4, L_429_arg5, L_430_arg6, L_431_arg7, L_432_arg8, L_433_arg9)
	L_426_arg2 = L_10_func(L_425_arg1, "tw")
	L_427_arg3 = L_424_arg0[1][1]
	L_428_arg4 = {}
	L_429_arg5 = L_10_func(L_425_arg1, "UDim2")
	L_429_arg5 = L_429_arg5.new
	L_430_arg6 = 1
	L_431_arg7 = -60
	L_432_arg8 = 0
	L_433_arg9 = 44
	L_429_arg5 = L_429_arg5(L_430_arg6, L_431_arg7, L_432_arg8, L_433_arg9)
	L_428_arg4.Size = L_429_arg5
	L_429_arg5 = 0.15
	L_426_arg2(L_427_arg3, L_428_arg4, L_429_arg5)
	return
end

L_13_.fn_054_copyPricingSetClipboard = function(L_434_arg0, L_435_arg1, L_436_arg2, L_437_arg3)
	L_436_arg2 = L_10_func(L_435_arg1, "setclipboard")
	if L_436_arg2 then
		L_436_arg2 = L_10_func(L_435_arg1, "setclipboard")
		L_437_arg3 = "https://getsnowy.xyz/pricing"
		L_436_arg2(L_437_arg3)
		L_436_arg2 = true
		L_434_arg0[1][1] = L_436_arg2
	end
	return
end

L_13_.fn_055_copyPricingToClipboard = function(L_438_arg0, L_439_arg1, L_440_arg2, L_441_arg3)
	L_440_arg2 = L_10_func(L_439_arg1, "toclipboard")
	L_441_arg3 = "https://getsnowy.xyz/pricing"
	L_440_arg2(L_441_arg3)
	L_440_arg2 = true
	L_438_arg0[1][1] = L_440_arg2
	return
end

L_13_.fn_056_buildPremiumNag = function(L_442_arg0, L_443_arg1, L_444_arg2, L_445_arg3, L_446_arg4, L_447_arg5, L_448_arg6)
	L_444_arg2 = L_442_arg0[1][1]
	L_446_arg4 = "\226\156\166  "
	L_447_arg5 = "getsnowy.xyz/pricing"
	L_448_arg6 = "    \226\128\162  Click to copy"
	L_445_arg3 = L_446_arg4 .. L_447_arg5 .. L_448_arg6
	L_444_arg2.Text = L_445_arg3
	L_444_arg2 = L_10_func(L_443_arg1, "tw")
	L_445_arg3 = L_442_arg0[1][1]
	L_446_arg4 = {}
	L_448_arg6 = L_442_arg0[2][1]
	L_447_arg5 = L_448_arg6.Premium
	L_446_arg4.BackgroundColor3 = L_447_arg5
	L_447_arg5 = 0.2
	L_444_arg2(L_445_arg3, L_446_arg4, L_447_arg5)
	return
end

L_13_.fn_057 = function(L_449_arg0, L_450_arg1, L_451_arg2, L_452_arg3)
	L_451_arg2 = L_10_func(L_450_arg1, "pcall")
	L_452_arg3 = L_14_func(L_13_.fn_056_buildPremiumNag, L_450_arg1, {
		L_449_arg0[1],
		L_449_arg0[2]
	})
	L_451_arg2(L_452_arg3)
	return
end

L_13_.fn_058_showPricingCopied = function(L_453_arg0, L_454_arg1, ...)
	local L_455_ = {
		false
	}
	local L_456_ = L_10_func(L_454_arg1, "pcall")
	L_456_(L_14_func(L_13_.fn_054_copyPricingSetClipboard, L_454_arg1, {
		L_455_
	}))
	if not L_455_[1] then
		L_456_(L_14_func(L_13_.fn_055_copyPricingToClipboard, L_454_arg1, {
			L_455_
		}))
	end
	local L_457_ = L_453_arg0[1][1]
	local L_458_ = L_453_arg0[2][1]
	if L_455_[1] then
		L_457_.Text = "✔  Copied  https://getsnowy.xyz/pricing"
	else
		L_457_.Text = "Visit getsnowy.xyz/pricing"
	end
	L_10_func(L_454_arg1, "tw")(L_457_, {
		BackgroundColor3 = L_458_.Success
	}, 0.15)
	L_10_func(L_454_arg1, "task").delay(
        1.4,
        L_14_func(L_13_.fn_057, L_454_arg1, {
		L_453_arg0[1],
		L_453_arg0[2]
	})
    )
	return
end

L_13_.fn_059_destroyPremiumNag = function(L_459_arg0, L_460_arg1, L_461_arg2, L_462_arg3)
	L_461_arg2 = L_459_arg0[1][1]
	do
		local L_463_ = L_461_arg2;
		L_462_arg3 = L_463_;
		L_461_arg2 = L_463_.Destroy
	end
	L_461_arg2(L_462_arg3)
	return
end

L_13_.fn_060 = function(L_464_arg0, L_465_arg1, L_466_arg2, L_467_arg3, L_468_arg4, L_469_arg5)
	L_466_arg2 = L_10_func(L_465_arg1, "pcall")
	L_467_arg3 = L_14_func(L_13_.fn_059_destroyPremiumNag, L_465_arg1, {
		L_464_arg0[1]
	})
	L_466_arg2(L_467_arg3)
	L_466_arg2 = L_464_arg0[2][1]
	L_467_arg3 = L_464_arg0[1][1]
	L_469_arg5 = (L_466_arg2 == L_467_arg3)
	if L_469_arg5 then
		L_466_arg2 = nil
		L_464_arg0[2][1] = L_466_arg2
	end
	return
end

L_13_.fn_061_animatePremiumNag = function(L_470_arg0, L_471_arg1, L_472_arg2, L_473_arg3, L_474_arg4, L_475_arg5, L_476_arg6, L_477_arg7)
	L_473_arg3 = L_470_arg0[1][1]
	L_472_arg2 = L_473_arg3.Parent
	if L_472_arg2 then
		L_472_arg2 = L_10_func(L_471_arg1, "tw")
		L_473_arg3 = L_470_arg0[2][1]
		L_474_arg4 = {}
		L_475_arg5 = 1
		L_474_arg4.BackgroundTransparency = L_475_arg5
		L_475_arg5 = 0.2
		L_472_arg2(L_473_arg3, L_474_arg4, L_475_arg5)
		L_472_arg2 = L_10_func(L_471_arg1, "tw")
		L_473_arg3 = L_470_arg0[3][1]
		L_474_arg4 = {}
		L_475_arg5 = L_10_func(L_471_arg1, "UDim2")
		L_475_arg5 = L_475_arg5.fromOffset
		L_476_arg6 = 0
		L_477_arg7 = 0
		L_475_arg5 = L_475_arg5(L_476_arg6, L_477_arg7)
		L_474_arg4.Size = L_475_arg5
		L_475_arg5 = 0.18
		L_476_arg6 = L_10_func(L_471_arg1, "Enum")
		L_476_arg6 = L_476_arg6.EasingStyle
		L_476_arg6 = L_476_arg6.Back
		L_477_arg7 = L_10_func(L_471_arg1, "Enum")
		L_477_arg7 = L_477_arg7.EasingDirection
		L_477_arg7 = L_477_arg7.In
		L_472_arg2(L_473_arg3, L_474_arg4, L_475_arg5, L_476_arg6, L_477_arg7)
		L_472_arg2 = L_10_func(L_471_arg1, "task")
		L_472_arg2 = L_472_arg2.delay
		L_473_arg3 = 0.22
		L_474_arg4 = L_14_func(L_13_.fn_060, L_471_arg1, {
			L_470_arg0[1],
			L_470_arg0[4]
		})
		L_472_arg2(L_473_arg3, L_474_arg4)
		return
	else
		return
	end
end

L_13_.fn_062 = function(L_478_arg0, L_479_arg1, L_480_arg2, L_481_arg3, L_482_arg4, L_483_arg5)
	L_480_arg2 = L_478_arg0[1][1]
	L_481_arg3 = L_478_arg0[2][1]
	L_483_arg5 = (L_480_arg2 == L_481_arg3)
	if L_483_arg5 then
		L_480_arg2 = L_478_arg0[3][1]
		L_480_arg2()
	end
	return
end

L_13_.fn_063_showPremiumLockedModal = function(L_484_arg0, L_485_arg1, ...)
	local L_486_ = L_484_arg0[1][1]
	local L_487_ = L_484_arg0[2][1]
	local L_488_ = L_484_arg0[3][1]
	local L_489_ = L_484_arg0[4][1]
	local L_490_ = L_484_arg0[5]
	local L_491_ = L_484_arg0[6][1]
	local L_492_ = L_10_func(L_485_arg1, "tostring")
	local L_493_ = L_10_func(L_485_arg1, "pcall")
	local L_494_ = L_10_func(L_485_arg1, "Instance")
	local L_495_ = L_10_func(L_485_arg1, "Enum")
	local L_496_ = L_10_func(L_485_arg1, "UDim2")
	local L_497_ = L_10_func(L_485_arg1, "UDim")
	local L_498_ = L_10_func(L_485_arg1, "Vector2")
	local L_499_ = L_10_func(L_485_arg1, "Color3")
	local L_500_ = L_10_func(L_485_arg1, "task")
	local L_501_ = L_10_func(L_485_arg1, "tw")
	local L_502_ = L_10_func(L_485_arg1, "corner")
	local L_503_ = L_10_func(L_485_arg1, "stroke")
	local L_504_ = L_10_func(L_485_arg1, "gradient")
	local L_505_ = L_10_func(L_485_arg1, "shadow")
	local L_506_ = L_486_ and L_492_(L_486_) or "That feature"
	local L_507_ = L_494_.new("ScreenGui")
	L_507_.Name = "SnowyPremiumModal"
	L_507_.ZIndexBehavior = L_495_.ZIndexBehavior.Sibling
	L_507_.IgnoreGuiInset = true
	L_507_.ResetOnSpawn = false
	L_507_.DisplayOrder = 2147483647

	local L_508_ = {
		false
	}
	if not L_487_:IsStudio() then
		local L_528_ = L_10_func(L_485_arg1, "syn")
		if L_528_ and L_528_.protect_gui then
			L_493_(L_14_func(
                L_13_.fn_048_protectGuiSyn,
                L_485_arg1,
                {
				{
					L_507_
				},
				L_484_arg0[3],
				L_508_
			}
            ))
		end
		if not L_508_[1] and L_10_func(L_485_arg1, "gethui") then
			L_493_(L_14_func(
                L_13_.fn_049_parentToHiddenUi,
                L_485_arg1,
                {
				{
					L_507_
				},
				L_508_
			}
            ))
		end
		if not L_508_[1] and L_10_func(L_485_arg1, "get_hidden_gui") then
			L_493_(L_14_func(
                L_13_.fn_050_parentToHiddenGui,
                L_485_arg1,
                {
				{
					L_507_
				},
				L_508_
			}
            ))
		end
	end
	if not L_508_[1] then
		L_493_(L_14_func(
            L_13_.fn_051_parentToPlayerGui,
            L_485_arg1,
            {
			{
				L_507_
			},
			L_484_arg0[2],
			L_484_arg0[4],
			L_484_arg0[3]
		}
        ))
	end
	L_490_[1] = L_507_
	local L_509_ = L_494_.new("TextButton", L_507_)
	L_509_.Name = "Backdrop"
	L_509_.Size = L_496_.fromScale(1, 1)
	L_509_.BackgroundColor3 = L_499_.new(0, 0, 0)
	L_509_.BackgroundTransparency = 1
	L_509_.BorderSizePixel = 0
	L_509_.AutoButtonColor = false
	L_509_.Text = ""
	L_509_.ZIndex = 9000
	L_501_(L_509_, {
		BackgroundTransparency = 0.45
	}, 0.2)
	local L_510_ = L_494_.new("Frame", L_507_)
	L_510_.Name = "Card"
	L_510_.AnchorPoint = L_498_.new(0.5, 0.5)
	L_510_.Position = L_496_.fromScale(0.5, 0.5)
	L_510_.Size = L_496_.fromOffset(0, 0)
	L_510_.BackgroundColor3 = L_491_.BgCard
	L_510_.BorderSizePixel = 0
	L_510_.ZIndex = 9010
	L_510_.ClipsDescendants = true
	L_502_(18, L_510_)
	L_503_(L_491_.Premium, 2, L_510_)
	L_504_(L_510_, L_491_.BgSecondary, L_491_.BgCard, 125)
	L_505_(L_510_)
	local L_511_ = L_494_.new("Frame", L_510_)
	L_511_.Size = L_496_.new(1, 0, 0, 4)
	L_511_.BackgroundColor3 = L_491_.Premium
	L_511_.BorderSizePixel = 0
	L_511_.ZIndex = 9011
	L_504_(L_511_, L_491_.PremiumDark, L_491_.Premium, 0)
	local L_512_ = L_494_.new("Frame", L_510_)
	L_512_.Name = "LockContainer"
	L_512_.Size = L_496_.new(0, 68, 0, 68)
	L_512_.Position = L_496_.new(0.5, -34, 0, 28)
	L_512_.BackgroundColor3 = L_491_.PremiumDim
	L_512_.BorderSizePixel = 0
	L_512_.ZIndex = 9012
	L_502_(999, L_512_)
	L_503_(L_491_.Premium, 2, L_512_)
	local L_513_ = L_494_.new("Frame", L_512_)
	L_513_.Name = "Shackle"
	L_513_.Size = L_496_.new(0, 26, 0, 26)
	L_513_.Position = L_496_.new(0.5, -13, 0.5, -23)
	L_513_.BackgroundTransparency = 1
	L_513_.ZIndex = 9013
	local L_514_ = L_494_.new("UICorner", L_513_)
	L_514_.CornerRadius = L_497_.new(0.5, 0)
	local L_515_ = L_494_.new("UIStroke", L_513_)
	L_515_.Color = L_491_.Premium
	L_515_.Thickness = 3
	L_515_.ApplyStrokeMode = L_495_.ApplyStrokeMode.Border
	local L_516_ = L_494_.new("Frame", L_512_)
	L_516_.Name = "Body"
	L_516_.Size = L_496_.new(0, 34, 0, 26)
	L_516_.Position = L_496_.new(0.5, -17, 0.5, -7)
	L_516_.BackgroundColor3 = L_491_.Premium
	L_516_.BorderSizePixel = 0
	L_516_.ZIndex = 9014
	local L_517_ = L_494_.new("UICorner", L_516_)
	L_517_.CornerRadius = L_497_.new(0, 4)
	local L_518_ = L_494_.new("Frame", L_516_)
	L_518_.Name = "KeyholeCircle"
	L_518_.Size = L_496_.new(0, 6, 0, 6)
	L_518_.Position = L_496_.new(0.5, -3, 0.3, 0)
	L_518_.BackgroundColor3 = L_491_.BgCard
	L_518_.BorderSizePixel = 0
	L_518_.ZIndex = 9015
	local L_519_ = L_494_.new("UICorner", L_518_)
	L_519_.CornerRadius = L_497_.new(1, 0)
	local L_520_ = L_494_.new("Frame", L_516_)
	L_520_.Name = "KeyholeLine"
	L_520_.Size = L_496_.new(0, 3, 0, 8)
	L_520_.Position = L_496_.new(0.5, -1.5, 0.3, 4)
	L_520_.BackgroundColor3 = L_491_.BgCard
	L_520_.BorderSizePixel = 0
	L_520_.ZIndex = 9015
	local L_521_ = L_494_.new("UICorner", L_520_)
	L_521_.CornerRadius = L_497_.new(0, 1)
	local L_522_ = L_494_.new("TextLabel", L_510_)
	L_522_.Size = L_496_.new(1, -30, 0, 28)
	L_522_.Position = L_496_.new(0, 15, 0, 106)
	L_522_.BackgroundTransparency = 1
	L_522_.Text = "PREMIUM FEATURE"
	L_522_.TextColor3 = L_491_.Premium
	L_522_.Font = L_495_.Font.GothamBlack
	L_522_.TextSize = 20
	L_522_.ZIndex = 9012
	local L_523_ = L_494_.new("TextLabel", L_510_)
	L_523_.Size = L_496_.new(1, -30, 0, 22)
	L_523_.Position = L_496_.new(0, 15, 0, 136)
	L_523_.BackgroundTransparency = 1
	L_523_.Text = "“" .. L_506_ .. "” is locked."
	L_523_.TextColor3 = L_491_.TextPrimary
	L_523_.Font = L_495_.Font.GothamSemibold
	L_523_.TextSize = 14
	L_523_.TextTruncate = L_495_.TextTruncate.AtEnd
	L_523_.ZIndex = 9012
	local L_524_ = L_494_.new("TextLabel", L_510_)
	L_524_.Size = L_496_.new(1, -30, 0, 20)
	L_524_.Position = L_496_.new(0, 15, 0, 160)
	L_524_.BackgroundTransparency = 1
	L_524_.Text = "Unlock every Snowy Premium feature at"
	L_524_.TextColor3 = L_491_.TextSecondary
	L_524_.Font = L_495_.Font.Gotham
	L_524_.TextSize = 12
	L_524_.ZIndex = 9012
	local L_525_ = L_494_.new("TextButton", L_510_)
	L_525_.Size = L_496_.new(1, -60, 0, 44)
	L_525_.Position = L_496_.new(0, 30, 0, 188)
	L_525_.BackgroundColor3 = L_491_.Premium
	L_525_.BorderSizePixel = 0
	L_525_.AutoButtonColor = false
	L_525_.Text = "✦  getsnowy.xyz/pricing    •  Click to copy"
	L_525_.TextColor3 = L_499_.fromRGB(20, 15, 0)
	L_525_.Font = L_495_.Font.GothamBlack
	L_525_.TextSize = 15
	L_525_.ZIndex = 9012
	L_502_(10, L_525_)
	L_503_(L_491_.PremiumDark, 1, L_525_)
	L_504_(L_525_, L_491_.Premium, L_491_.PremiumDark, 90)
	L_525_.MouseEnter:Connect(L_14_func(
        L_13_.fn_052_showTween, L_485_arg1, {
		{
			L_525_
		}
	}
    ))
	L_525_.MouseLeave:Connect(L_14_func(
        L_13_.fn_053_hideTween, L_485_arg1, {
		{
			L_525_
		}
	}
    ))
	L_525_.Activated:Connect(L_14_func(
        L_13_.fn_058_showPricingCopied, L_485_arg1, {
		{
			L_525_
		},
		L_484_arg0[6]
	}
    ))
	local L_526_ = L_494_.new("TextButton", L_510_)
	L_526_.Size = L_496_.new(1, -60, 0, 32)
	L_526_.Position = L_496_.new(0, 30, 0, 242)
	L_526_.BackgroundColor3 = L_491_.BgInput
	L_526_.BorderSizePixel = 0
	L_526_.AutoButtonColor = false
	L_526_.Text = "Maybe later"
	L_526_.TextColor3 = L_491_.TextSecondary
	L_526_.Font = L_495_.Font.GothamMedium
	L_526_.TextSize = 13
	L_526_.ZIndex = 9012
	L_502_(8, L_526_)
	L_503_(L_491_.Border, 1, L_526_)
	local L_527_ = L_14_func(
        L_13_.fn_061_animatePremiumNag,
        L_485_arg1,
        {
		{
			L_507_
		},
		{
			L_509_
		},
		{
			L_510_
		},
		L_490_
	}
    )
	L_526_.Activated:Connect(L_527_)
	L_509_.Activated:Connect(L_527_)
	L_510_.Size = L_496_.fromOffset(0, 0)
	L_501_(
        L_510_,
        {
		Size = L_496_.fromOffset(400, 300)
	},
        0.35,
        L_495_.EasingStyle.Back,
        L_495_.EasingDirection.Out
    )
	L_500_.delay(7, L_14_func(
        L_13_.fn_062,
        L_485_arg1,
        {
		L_490_,
		{
			L_507_
		},
		{
			L_527_
		}
	}
    ))
end

L_13_.fn_064_premiumLockedAction = function(L_529_arg0, L_530_arg1, L_531_arg2, L_532_arg3, L_533_arg4, L_534_arg5, L_535_arg6, L_536_arg7, L_537_arg8, L_538_arg9, L_539_arg10, L_540_arg11, L_541_arg12, L_542_arg13, L_543_arg14, L_544_arg15)
	L_532_arg3 = L_10_func(L_530_arg1, "tick")
	L_532_arg3 = L_532_arg3()
	L_534_arg5 = L_529_arg0[1][1]
	L_533_arg4 = L_532_arg3 - L_534_arg5
	L_534_arg5 = 1.2
	L_544_arg15 = (L_533_arg4 < L_534_arg5)
	if not L_544_arg15 then
		L_529_arg0[1][1] = L_532_arg3
		L_533_arg4 = L_529_arg0[2][1]
		if L_533_arg4 then
			L_533_arg4 = L_10_func(L_530_arg1, "pcall")
			L_534_arg5 = L_14_func(L_13_.fn_047_destroyNotification, L_530_arg1, {
				L_529_arg0[2]
			})
			L_533_arg4(L_534_arg5)
			L_533_arg4 = nil
			L_529_arg0[2][1] = L_533_arg4
		end
		L_533_arg4 = L_10_func(L_530_arg1, "pcall")
		L_534_arg5 = L_14_func(L_13_.fn_063_showPremiumLockedModal, L_530_arg1, {
			{
				L_531_arg2
			},
			L_529_arg0[3],
			L_529_arg0[4],
			L_529_arg0[5],
			L_529_arg0[2],
			L_529_arg0[6]
		})
		L_533_arg4, L_534_arg5 = L_533_arg4(L_534_arg5)
		if not L_533_arg4 then
			if L_531_arg2 then
				L_536_arg7 = "'"
				L_540_arg11 = L_531_arg2
				L_539_arg10 = L_10_func(L_530_arg1, "tostring")
				L_539_arg10 = L_539_arg10(L_540_arg11)
				L_537_arg8 = L_539_arg10
				L_538_arg9 = "'"
				L_535_arg6 = L_536_arg7 .. L_537_arg8 .. L_538_arg9
				if not L_535_arg6 then
					L_535_arg6 = "That feature"
				end
				L_536_arg7 = L_529_arg0[7][1]
				L_538_arg9 = "\226\156\166  PREMIUM LOCKED"
				L_540_arg11 = L_535_arg6
				L_541_arg12 = " is locked to Snowy Premium. Upgrade at "
				L_542_arg13 = "getsnowy.xyz/pricing"
				L_539_arg10 = L_540_arg11 .. L_541_arg12 .. L_542_arg13
				L_540_arg11 = 5
				L_541_arg12 = true
				do
					local L_545_ = L_536_arg7;
					L_537_arg8 = L_545_;
					L_536_arg7 = L_545_.Notify
				end
				L_536_arg7(L_537_arg8, L_538_arg9, L_539_arg10, L_540_arg11, L_541_arg12)
				return
			end
			L_535_arg6 = "That feature"
			L_536_arg7 = L_529_arg0[7][1]
			L_538_arg9 = "\226\156\166  PREMIUM LOCKED"
			L_540_arg11 = L_535_arg6
			L_541_arg12 = " is locked to Snowy Premium. Upgrade at "
			L_542_arg13 = "getsnowy.xyz/pricing"
			L_539_arg10 = L_540_arg11 .. L_541_arg12 .. L_542_arg13
			L_540_arg11 = 5
			L_541_arg12 = true
			do
				local L_546_ = L_536_arg7;
				L_537_arg8 = L_546_;
				L_536_arg7 = L_546_.Notify
			end
			L_536_arg7(L_537_arg8, L_538_arg9, L_539_arg10, L_540_arg11, L_541_arg12)
		end
		return
	else
		return
	end
end

L_13_.fn_065_iterateNext = function(L_547_arg0, L_548_arg1, ...)
	local L_549_, L_550_ = ...
	local L_551_ = L_10_func(L_548_arg1, "Instance").new(L_549_)
	for L_552_forvar0, L_553_forvar1 in next, L_550_ do
		if L_552_forvar0 ~= "Parent" then
			L_551_[L_552_forvar0] = L_553_forvar1
		end
	end
	L_551_.Parent = L_550_.Parent
	return L_551_
end

L_13_.fn_066_playTween = function(L_554_arg0, L_555_arg1, L_556_arg2, L_557_arg3, L_558_arg4, L_559_arg5, L_560_arg6, L_561_arg7, L_562_arg8, L_563_arg9, L_564_arg10, L_565_arg11)
	L_559_arg5 = L_554_arg0[1][1]
	L_561_arg7 = L_556_arg2
	L_562_arg8 = L_10_func(L_555_arg1, "TweenInfo")
	L_562_arg8 = L_562_arg8.new
	L_563_arg9 = L_557_arg3
	L_564_arg10 = L_10_func(L_555_arg1, "Enum")
	L_564_arg10 = L_564_arg10.EasingStyle
	L_564_arg10 = L_564_arg10.Quart
	L_565_arg11 = L_10_func(L_555_arg1, "Enum")
	L_565_arg11 = L_565_arg11.EasingDirection
	L_565_arg11 = L_565_arg11.Out
	L_562_arg8 = L_562_arg8(L_563_arg9, L_564_arg10, L_565_arg11)
	L_563_arg9 = L_558_arg4
	do
		local L_566_ = L_559_arg5;
		L_560_arg6 = L_566_;
		L_559_arg5 = L_566_.Create
	end
	L_559_arg5 = L_559_arg5(L_560_arg6, L_561_arg7, L_562_arg8, L_563_arg9)
	do
		local L_567_ = L_559_arg5;
		L_560_arg6 = L_567_;
		L_559_arg5 = L_567_.Play
	end
	L_559_arg5(L_560_arg6)
	return
end

L_13_.fn_067_dragInputBegan = function(L_568_arg0, L_569_arg1, L_570_arg2, L_571_arg3, L_572_arg4, L_573_arg5, L_574_arg6)
	L_571_arg3 = L_570_arg2.UserInputType
	L_572_arg4 = L_10_func(L_569_arg1, "Enum")
	L_572_arg4 = L_572_arg4.UserInputType
	L_572_arg4 = L_572_arg4.MouseButton1
	L_574_arg6 = (L_571_arg3 == L_572_arg4)
	if not L_574_arg6 then
		L_571_arg3 = L_570_arg2.UserInputType
		L_572_arg4 = L_10_func(L_569_arg1, "Enum")
		L_572_arg4 = L_572_arg4.UserInputType
		L_572_arg4 = L_572_arg4.Touch
		L_574_arg6 = (L_571_arg3 == L_572_arg4)
		if L_574_arg6 then
			L_572_arg4 = L_568_arg0[1][1]
			L_571_arg3 = L_572_arg4._blockDrag
			if not L_571_arg3 then
				L_571_arg3 = true
				L_568_arg0[2][1] = L_571_arg3
				L_571_arg3 = false
				L_568_arg0[3][1] = L_571_arg3
				L_571_arg3 = L_570_arg2.Position
				L_568_arg0[4][1] = L_571_arg3
				L_572_arg4 = L_568_arg0[6][1]
				L_571_arg3 = L_572_arg4.Position
				L_568_arg0[5][1] = L_571_arg3
			end
		end
		return
	end
	L_572_arg4 = L_568_arg0[1][1]
	L_571_arg3 = L_572_arg4._blockDrag
	if not L_571_arg3 then
		L_571_arg3 = true
		L_568_arg0[2][1] = L_571_arg3
		L_571_arg3 = false
		L_568_arg0[3][1] = L_571_arg3
		L_571_arg3 = L_570_arg2.Position
		L_568_arg0[4][1] = L_571_arg3
		L_572_arg4 = L_568_arg0[6][1]
		L_571_arg3 = L_572_arg4.Position
		L_568_arg0[5][1] = L_571_arg3
	end
	return
end

L_13_.fn_068_dragInputEnded = function(L_575_arg0, L_576_arg1, L_577_arg2, L_578_arg3, L_579_arg4, L_580_arg5, L_581_arg6)
	L_578_arg3 = L_577_arg2.UserInputType
	L_579_arg4 = L_10_func(L_576_arg1, "Enum")
	L_579_arg4 = L_579_arg4.UserInputType
	L_579_arg4 = L_579_arg4.MouseButton1
	L_581_arg6 = (L_578_arg3 == L_579_arg4)
	if not L_581_arg6 then
		L_578_arg3 = L_577_arg2.UserInputType
		L_579_arg4 = L_10_func(L_576_arg1, "Enum")
		L_579_arg4 = L_579_arg4.UserInputType
		L_579_arg4 = L_579_arg4.Touch
		L_581_arg6 = (L_578_arg3 == L_579_arg4)
		if L_581_arg6 then
			L_578_arg3 = false
			L_575_arg0[1][1] = L_578_arg3
		end
		return
	end
	L_578_arg3 = false
	L_575_arg0[1][1] = L_578_arg3
	return
end

L_13_.fn_069_dragInputChanged = function(L_582_arg0, L_583_arg1, L_584_arg2, L_585_arg3, L_586_arg4, L_587_arg5, L_588_arg6, L_589_arg7, L_590_arg8, L_591_arg9, L_592_arg10, L_593_arg11, L_594_arg12, L_595_arg13, L_596_arg14)
	L_585_arg3 = L_582_arg0[1][1]
	if L_585_arg3 then
		L_585_arg3 = L_584_arg2.UserInputType
		L_586_arg4 = L_10_func(L_583_arg1, "Enum")
		L_586_arg4 = L_586_arg4.UserInputType
		L_586_arg4 = L_586_arg4.MouseMovement
		L_596_arg14 = (L_585_arg3 == L_586_arg4)
		if not L_596_arg14 then
			L_585_arg3 = L_584_arg2.UserInputType
			L_586_arg4 = L_10_func(L_583_arg1, "Enum")
			L_586_arg4 = L_586_arg4.UserInputType
			L_586_arg4 = L_586_arg4.Touch
			L_596_arg14 = (L_585_arg3 == L_586_arg4)
			if L_596_arg14 then
				L_586_arg4 = L_584_arg2.Position
				L_587_arg5 = L_582_arg0[2][1]
				L_585_arg3 = L_586_arg4 - L_587_arg5
				L_586_arg4 = L_582_arg0[3][1]
				if not L_586_arg4 then
					L_587_arg5 = L_585_arg3.X
					L_586_arg4 = L_10_func(L_583_arg1, "math")
					L_586_arg4 = L_586_arg4.abs
					L_586_arg4 = L_586_arg4(L_587_arg5)
					L_587_arg5 = 4
					L_596_arg14 = (L_587_arg5 <= L_586_arg4)
					if not L_596_arg14 then
						L_587_arg5 = L_585_arg3.Y
						L_586_arg4 = L_10_func(L_583_arg1, "math")
						L_586_arg4 = L_586_arg4.abs
						L_586_arg4 = L_586_arg4(L_587_arg5)
						L_587_arg5 = 4
						L_596_arg14 = (L_587_arg5 <= L_586_arg4)
						if L_596_arg14 then
							L_586_arg4 = true
							L_582_arg0[3][1] = L_586_arg4
						end
						L_586_arg4 = L_582_arg0[3][1]
						if L_586_arg4 then
							L_586_arg4 = L_582_arg0[4][1]
							L_587_arg5 = L_10_func(L_583_arg1, "UDim2")
							L_587_arg5 = L_587_arg5.new
							L_590_arg8 = L_582_arg0[5][1]
							L_589_arg7 = L_590_arg8.X
							L_588_arg6 = L_589_arg7.Scale
							L_592_arg10 = L_582_arg0[5][1]
							L_591_arg9 = L_592_arg10.X
							L_590_arg8 = L_591_arg9.Offset
							L_591_arg9 = L_585_arg3.X
							L_589_arg7 = L_590_arg8 + L_591_arg9
							L_592_arg10 = L_582_arg0[5][1]
							L_591_arg9 = L_592_arg10.Y
							L_590_arg8 = L_591_arg9.Scale
							L_594_arg12 = L_582_arg0[5][1]
							L_593_arg11 = L_594_arg12.Y
							L_592_arg10 = L_593_arg11.Offset
							L_593_arg11 = L_585_arg3.Y
							L_591_arg9 = L_592_arg10 + L_593_arg11
							L_587_arg5 = L_587_arg5(L_588_arg6, L_589_arg7, L_590_arg8, L_591_arg9)
							L_586_arg4.Position = L_587_arg5
						end
						return
					end
					L_586_arg4 = true
					L_582_arg0[3][1] = L_586_arg4
				end
				L_586_arg4 = L_582_arg0[3][1]
				if L_586_arg4 then
					L_586_arg4 = L_582_arg0[4][1]
					L_587_arg5 = L_10_func(L_583_arg1, "UDim2")
					L_587_arg5 = L_587_arg5.new
					L_590_arg8 = L_582_arg0[5][1]
					L_589_arg7 = L_590_arg8.X
					L_588_arg6 = L_589_arg7.Scale
					L_592_arg10 = L_582_arg0[5][1]
					L_591_arg9 = L_592_arg10.X
					L_590_arg8 = L_591_arg9.Offset
					L_591_arg9 = L_585_arg3.X
					L_589_arg7 = L_590_arg8 + L_591_arg9
					L_592_arg10 = L_582_arg0[5][1]
					L_591_arg9 = L_592_arg10.Y
					L_590_arg8 = L_591_arg9.Scale
					L_594_arg12 = L_582_arg0[5][1]
					L_593_arg11 = L_594_arg12.Y
					L_592_arg10 = L_593_arg11.Offset
					L_593_arg11 = L_585_arg3.Y
					L_591_arg9 = L_592_arg10 + L_593_arg11
					L_587_arg5 = L_587_arg5(L_588_arg6, L_589_arg7, L_590_arg8, L_591_arg9)
					L_586_arg4.Position = L_587_arg5
				end
			end
			return
		end
		L_586_arg4 = L_584_arg2.Position
		L_587_arg5 = L_582_arg0[2][1]
		L_585_arg3 = L_586_arg4 - L_587_arg5
		L_586_arg4 = L_582_arg0[3][1]
		if not L_586_arg4 then
			L_587_arg5 = L_585_arg3.X
			L_586_arg4 = L_10_func(L_583_arg1, "math")
			L_586_arg4 = L_586_arg4.abs
			L_586_arg4 = L_586_arg4(L_587_arg5)
			L_587_arg5 = 4
			L_596_arg14 = (L_587_arg5 <= L_586_arg4)
			if not L_596_arg14 then
				L_587_arg5 = L_585_arg3.Y
				L_586_arg4 = L_10_func(L_583_arg1, "math")
				L_586_arg4 = L_586_arg4.abs
				L_586_arg4 = L_586_arg4(L_587_arg5)
				L_587_arg5 = 4
				L_596_arg14 = (L_587_arg5 <= L_586_arg4)
				if L_596_arg14 then
					L_586_arg4 = true
					L_582_arg0[3][1] = L_586_arg4
				end
				L_586_arg4 = L_582_arg0[3][1]
				if L_586_arg4 then
					L_586_arg4 = L_582_arg0[4][1]
					L_587_arg5 = L_10_func(L_583_arg1, "UDim2")
					L_587_arg5 = L_587_arg5.new
					L_590_arg8 = L_582_arg0[5][1]
					L_589_arg7 = L_590_arg8.X
					L_588_arg6 = L_589_arg7.Scale
					L_592_arg10 = L_582_arg0[5][1]
					L_591_arg9 = L_592_arg10.X
					L_590_arg8 = L_591_arg9.Offset
					L_591_arg9 = L_585_arg3.X
					L_589_arg7 = L_590_arg8 + L_591_arg9
					L_592_arg10 = L_582_arg0[5][1]
					L_591_arg9 = L_592_arg10.Y
					L_590_arg8 = L_591_arg9.Scale
					L_594_arg12 = L_582_arg0[5][1]
					L_593_arg11 = L_594_arg12.Y
					L_592_arg10 = L_593_arg11.Offset
					L_593_arg11 = L_585_arg3.Y
					L_591_arg9 = L_592_arg10 + L_593_arg11
					L_587_arg5 = L_587_arg5(L_588_arg6, L_589_arg7, L_590_arg8, L_591_arg9)
					L_586_arg4.Position = L_587_arg5
				end
				return
			end
			L_586_arg4 = true
			L_582_arg0[3][1] = L_586_arg4
		end
		L_586_arg4 = L_582_arg0[3][1]
		if L_586_arg4 then
			L_586_arg4 = L_582_arg0[4][1]
			L_587_arg5 = L_10_func(L_583_arg1, "UDim2")
			L_587_arg5 = L_587_arg5.new
			L_590_arg8 = L_582_arg0[5][1]
			L_589_arg7 = L_590_arg8.X
			L_588_arg6 = L_589_arg7.Scale
			L_592_arg10 = L_582_arg0[5][1]
			L_591_arg9 = L_592_arg10.X
			L_590_arg8 = L_591_arg9.Offset
			L_591_arg9 = L_585_arg3.X
			L_589_arg7 = L_590_arg8 + L_591_arg9
			L_592_arg10 = L_582_arg0[5][1]
			L_591_arg9 = L_592_arg10.Y
			L_590_arg8 = L_591_arg9.Scale
			L_594_arg12 = L_582_arg0[5][1]
			L_593_arg11 = L_594_arg12.Y
			L_592_arg10 = L_593_arg11.Offset
			L_593_arg11 = L_585_arg3.Y
			L_591_arg9 = L_592_arg10 + L_593_arg11
			L_587_arg5 = L_587_arg5(L_588_arg6, L_589_arg7, L_590_arg8, L_591_arg9)
			L_586_arg4.Position = L_587_arg5
		end
	end
	return
end

L_13_.fn_070 = function(L_597_arg0, L_598_arg1, L_599_arg2, L_600_arg3)
	L_599_arg2 = L_597_arg0[1][1]
	L_600_arg3 = false
	L_597_arg0[1][1] = L_600_arg3
	return L_599_arg2
end

L_13_.fn_071_MakeDraggable = function(L_601_arg0, L_602_arg1, ...)
	local L_603_, L_604_, L_605_ = ...
	L_605_ = L_605_ or L_604_
	local L_606_ = {
		L_605_
	}
	local L_607_ = {
		false
	}
	local L_608_ = {
		false
	}
	local L_609_ = {
		nil
	}
	local L_610_ = {
		nil
	}
	L_604_.InputBegan:Connect(L_14_func(
        L_13_.fn_067_dragInputBegan,
        L_602_arg1,
        {
		L_601_arg0[1],
		L_607_,
		L_608_,
		L_609_,
		L_610_,
		L_606_
	}
    ))
	L_604_.InputEnded:Connect(L_14_func(
        L_13_.fn_068_dragInputEnded,
        L_602_arg1,
        {
		L_607_
	}
    ))
	L_601_arg0[2][1].InputChanged:Connect(L_14_func(
        L_13_.fn_069_dragInputChanged,
        L_602_arg1,
        {
		L_607_,
		L_609_,
		L_608_,
		L_606_,
		L_610_
	}
    ))
	return L_14_func(L_13_.fn_070, L_602_arg1, {
		L_608_
	})
end

L_13_.fn_072_GetIcon = function(L_611_arg0, L_612_arg1, L_613_arg2, L_614_arg3, L_615_arg4, L_616_arg5)
	L_616_arg5 = L_611_arg0[1][1]
	L_615_arg4 = L_616_arg5[L_614_arg3]
	if not L_615_arg4 then
		L_616_arg5 = L_611_arg0[1][1]
		L_615_arg4 = L_616_arg5.home
	end
	return L_615_arg4
end

L_13_.fn_073_makeGuid = function(L_617_arg0, L_618_arg1, ...)
	local L_619_ = L_1_(...)
	local L_620_ = L_619_.n
	local L_621_ = {}
	local L_622_ = {}
	local L_623_ = 3
	local L_624_ = 4
	for L_631_forvar0 = 0, L_624_ - 1 do
		L_621_[L_631_forvar0] = L_619_[L_631_forvar0 + 1]
	end
	local L_625_ = {
		n = math.max(0, L_620_ - L_624_)
	}
	for L_632_forvar0 = 1, L_625_.n do
		L_625_[L_632_forvar0] = L_619_[L_624_ + L_632_forvar0]
	end
	local L_626_ = L_620_
	local function L_627_func(L_633_arg0)
		local L_634_ = L_622_[L_633_arg0]
		if L_634_ ~= nil then
			return L_634_[1]
		end
		return L_621_[L_633_arg0]
	end
	local function L_628_func(L_635_arg0, L_636_arg1)
		local L_637_ = L_622_[L_635_arg0]
		if L_637_ ~= nil then
			L_637_[1] = L_636_arg1
		else
			L_621_[L_635_arg0] = L_636_arg1
		end
	end
	local function L_629_func(L_638_arg0)
		local L_639_ = L_622_[L_638_arg0]
		if L_639_ == nil then
			L_639_ = {
				L_621_[L_638_arg0]
			};
			L_622_[L_638_arg0] = L_639_
		end
		return L_639_
	end
	local function L_630_func(L_640_arg0, L_641_arg1)
		local L_642_ = {
			n = L_641_arg1
		}
		for L_643_forvar0 = 1, L_641_arg1 do
			L_642_[L_643_forvar0] = L_627_func(L_640_arg0 + L_643_forvar0 - 1)
		end
		return L_642_
	end

	L_628_func(0, L_10_func(L_618_arg1, "game"))
	L_628_func(2, "HttpService")
	do
		local L_644_ = L_627_func(0)
		L_628_func(1, L_644_)
		L_628_func(0, L_644_["GetService"])
	end
	do
		local L_645_ = 2
		local L_646_ = L_630_func(1, L_645_)
		local L_647_ = L_1_(L_627_func(0)(L_2_(L_646_, 1, L_646_.n)))
		for L_648_forvar0 = 1, 1 do
			L_628_func(0 + L_648_forvar0 - 1, L_647_[L_648_forvar0])
		end
	end
	L_628_func(2, false)
	do
		local L_649_ = L_627_func(0)
		L_628_func(1, L_649_)
		L_628_func(0, L_649_["GenerateGUID"])
	end
	do
		local L_650_ = 2
		local L_651_ = L_630_func(1, L_650_)
		local L_652_ = L_1_(L_627_func(0)(L_2_(L_651_, 1, L_651_.n)))
		for L_653_forvar0 = 1, 1 do
			L_628_func(0 + L_653_forvar0 - 1, L_652_[L_653_forvar0])
		end
	end
	L_628_func(2, 1)
	L_628_func(3, 8)
	do
		local L_654_ = L_627_func(0)
		L_628_func(1, L_654_)
		L_628_func(0, L_654_["sub"])
	end
	do
		local L_655_ = 3
		local L_656_ = L_630_func(1, L_655_)
		local L_657_ = L_1_(L_627_func(0)(L_2_(L_656_, 1, L_656_.n)))
		for L_658_forvar0 = 1, L_657_.n do
			L_628_func(0 + L_658_forvar0 - 1, L_657_[L_658_forvar0])
		end
		L_626_ = 0 + L_657_.n
	end
	do
		local L_659_ = L_626_ - 0
		if L_659_ <= 0 then
			return
		end
		local L_660_ = L_630_func(0, L_659_)
		return L_2_(L_660_, 1, L_660_.n)
	end
end

L_13_.fn_074_protectWindowGui = function(L_661_arg0, L_662_arg1, L_663_arg2, L_664_arg3)
	L_663_arg2 = L_10_func(L_662_arg1, "syn")
	L_663_arg2 = L_663_arg2.protect_gui
	L_664_arg3 = L_661_arg0[1][1]
	L_663_arg2(L_664_arg3)
	L_663_arg2 = L_661_arg0[1][1]
	L_664_arg3 = L_661_arg0[2][1]
	L_663_arg2.Parent = L_664_arg3
	L_663_arg2 = true
	L_661_arg0[3][1] = L_663_arg2
	return
end

L_13_.fn_075_parentWindowGetHui = function(L_665_arg0, L_666_arg1, L_667_arg2, L_668_arg3)
	L_667_arg2 = L_665_arg0[1][1]
	L_668_arg3 = L_10_func(L_666_arg1, "gethui")
	L_668_arg3 = L_668_arg3()
	L_667_arg2.Parent = L_668_arg3
	L_667_arg2 = true
	L_665_arg0[2][1] = L_667_arg2
	return
end

L_13_.fn_076_parentWindowHiddenGui = function(L_669_arg0, L_670_arg1, L_671_arg2, L_672_arg3)
	L_671_arg2 = L_669_arg0[1][1]
	L_672_arg3 = L_10_func(L_670_arg1, "get_hidden_gui")
	L_672_arg3 = L_672_arg3()
	L_671_arg2.Parent = L_672_arg3
	L_671_arg2 = true
	L_669_arg0[2][1] = L_671_arg2
	return
end

L_13_.fn_077_cleanupExistingGui = function(L_673_arg0, L_674_arg1, L_675_arg2, L_676_arg3, L_677_arg4)
	L_676_arg3 = L_10_func(L_674_arg1, "getgenv")
	L_676_arg3 = L_676_arg3()
	L_677_arg4 = L_673_arg0[1][1]
	L_675_arg2 = L_676_arg3[L_677_arg4]
	do
		local L_678_ = L_675_arg2;
		L_676_arg3 = L_678_;
		L_675_arg2 = L_678_.Destroy
	end
	L_675_arg2(L_676_arg3)
	return
end

L_13_.fn_078_cancelTweenIfDetached = function(L_679_arg0, L_680_arg1, L_681_arg2, L_682_arg3, L_683_arg4)
	L_681_arg2 = L_679_arg0[1][1]
	L_683_arg4 = L_10_func(L_680_arg1, "game")
	do
		local L_684_ = L_681_arg2;
		L_682_arg3 = L_684_;
		L_681_arg2 = L_684_.IsDescendantOf
	end
	L_681_arg2 = L_681_arg2(L_682_arg3, L_683_arg4)
	if not L_681_arg2 then
		L_681_arg2 = L_679_arg0[2][1]
		do
			local L_685_ = L_681_arg2;
			L_682_arg3 = L_685_;
			L_681_arg2 = L_685_.Cancel
		end
		L_681_arg2(L_682_arg3)
	end
	return
end

L_13_.fn_079_fadeImage = function(L_686_arg0, L_687_arg1, L_688_arg2, L_689_arg3, L_690_arg4, L_691_arg5, L_692_arg6, L_693_arg7, L_694_arg8)
	L_688_arg2 = L_10_func(L_687_arg1, "TweenInfo")
	L_688_arg2 = L_688_arg2.new
	L_689_arg3 = 2
	L_690_arg4 = L_10_func(L_687_arg1, "Enum")
	L_690_arg4 = L_690_arg4.EasingStyle
	L_690_arg4 = L_690_arg4.Quad
	L_691_arg5 = L_10_func(L_687_arg1, "Enum")
	L_691_arg5 = L_691_arg5.EasingDirection
	L_691_arg5 = L_691_arg5.InOut
	L_692_arg6 = -1
	L_693_arg7 = true
	L_688_arg2 = L_688_arg2(L_689_arg3, L_690_arg4, L_691_arg5, L_692_arg6, L_693_arg7)
	L_689_arg3 = L_686_arg0[1][1]
	L_691_arg5 = L_686_arg0[2][1]
	L_692_arg6 = L_688_arg2
	L_693_arg7 = {}
	L_694_arg8 = 0.8
	L_693_arg7.ImageTransparency = L_694_arg8
	do
		local L_695_ = L_689_arg3;
		L_690_arg4 = L_695_;
		L_689_arg3 = L_695_.Create
	end
	L_689_arg3 = L_689_arg3(L_690_arg4, L_691_arg5, L_692_arg6, L_693_arg7)
	do
		local L_696_ = L_689_arg3;
		L_691_arg5 = L_696_;
		L_690_arg4 = L_696_.Play
	end
	L_690_arg4(L_691_arg5)
	L_691_arg5 = L_686_arg0[3][1]
	L_690_arg4 = L_691_arg5.AncestryChanged
	L_692_arg6 = L_14_func(L_13_.fn_078_cancelTweenIfDetached, L_687_arg1, {
		L_686_arg0[3],
		{
			L_689_arg3
		}
	})
	do
		local L_697_ = L_690_arg4;
		L_691_arg5 = L_697_;
		L_690_arg4 = L_697_.Connect
	end
	L_690_arg4(L_691_arg5, L_692_arg6)
	return
end

L_13_.fn_080_loadPlayerThumbnail = function(L_698_arg0, L_699_arg1, L_700_arg2, L_701_arg3, L_702_arg4, L_703_arg5, L_704_arg6)
	L_700_arg2 = L_698_arg0[1][1]
	L_703_arg5 = L_698_arg0[2][1]
	L_702_arg4 = L_703_arg5.UserId
	L_703_arg5 = L_10_func(L_699_arg1, "Enum")
	L_703_arg5 = L_703_arg5.ThumbnailType
	L_703_arg5 = L_703_arg5.HeadShot
	L_704_arg6 = L_10_func(L_699_arg1, "Enum")
	L_704_arg6 = L_704_arg6.ThumbnailSize
	L_704_arg6 = L_704_arg6.Size100x100
	do
		local L_705_ = L_700_arg2;
		L_701_arg3 = L_705_;
		L_700_arg2 = L_705_.GetUserThumbnailAsync
	end
	L_700_arg2, L_701_arg3 = L_700_arg2(L_701_arg3, L_702_arg4, L_703_arg5, L_704_arg6)
	if L_701_arg3 then
		L_702_arg4 = L_698_arg0[3][1]
		L_702_arg4.Image = L_700_arg2
	end
	return
end

L_13_.fn_081 = function(L_706_arg0, L_707_arg1, L_708_arg2, L_709_arg3)
	L_708_arg2 = L_10_func(L_707_arg1, "pcall")
	L_709_arg3 = L_14_func(L_13_.fn_080_loadPlayerThumbnail, L_707_arg1, {
		L_706_arg0[1],
		L_706_arg0[2],
		L_706_arg0[3]
	})
	L_708_arg2(L_709_arg3)
	return
end

L_13_.fn_082_destroyWindow = function(L_710_arg0, L_711_arg1, L_712_arg2, L_713_arg3)
	L_712_arg2 = L_710_arg0[1][1]
	L_712_arg2 = L_712_arg2()
	if not L_712_arg2 then
		L_712_arg2 = L_710_arg0[2][1]
		do
			local L_714_ = L_712_arg2;
			L_713_arg3 = L_714_;
			L_712_arg2 = L_714_.Destroy
		end
		L_712_arg2(L_713_arg3)
	end
	return
end

L_13_.fn_083_animateAccent = function(L_715_arg0, L_716_arg1, L_717_arg2, L_718_arg3, L_719_arg4, L_720_arg5, L_721_arg6, L_722_arg7, L_723_arg8, L_724_arg9, L_725_arg10)
	L_717_arg2 = L_715_arg0[1][1]
	L_718_arg3 = {}
	L_720_arg5 = L_715_arg0[2][1]
	L_719_arg4 = L_720_arg5.Accent
	L_718_arg3.TextColor3 = L_719_arg4
	L_719_arg4 = L_715_arg0[3][1]
	L_721_arg6 = L_717_arg2
	L_722_arg7 = L_10_func(L_716_arg1, "TweenInfo")
	L_722_arg7 = L_722_arg7.new
	L_723_arg8 = 0.15
	L_724_arg9 = L_10_func(L_716_arg1, "Enum")
	L_724_arg9 = L_724_arg9.EasingStyle
	L_724_arg9 = L_724_arg9.Quart
	L_725_arg10 = L_10_func(L_716_arg1, "Enum")
	L_725_arg10 = L_725_arg10.EasingDirection
	L_725_arg10 = L_725_arg10.Out
	L_722_arg7 = L_722_arg7(L_723_arg8, L_724_arg9, L_725_arg10)
	L_723_arg8 = L_718_arg3
	do
		local L_726_ = L_719_arg4;
		L_720_arg5 = L_726_;
		L_719_arg4 = L_726_.Create
	end
	L_719_arg4 = L_719_arg4(L_720_arg5, L_721_arg6, L_722_arg7, L_723_arg8)
	do
		local L_727_ = L_719_arg4;
		L_720_arg5 = L_727_;
		L_719_arg4 = L_727_.Play
	end
	L_719_arg4(L_720_arg5)
	return
end

L_13_.fn_084_animateControl = function(L_728_arg0, L_729_arg1, L_730_arg2, L_731_arg3, L_732_arg4, L_733_arg5, L_734_arg6, L_735_arg7, L_736_arg8, L_737_arg9, L_738_arg10)
	L_730_arg2 = L_728_arg0[1][1]
	L_731_arg3 = {}
	L_732_arg4 = L_10_func(L_729_arg1, "Color3")
	L_732_arg4 = L_732_arg4.new
	L_733_arg5 = 1
	L_734_arg6 = 1
	L_735_arg7 = 1
	L_732_arg4 = L_732_arg4(L_733_arg5, L_734_arg6, L_735_arg7)
	L_731_arg3.TextColor3 = L_732_arg4
	L_732_arg4 = L_728_arg0[2][1]
	L_734_arg6 = L_730_arg2
	L_735_arg7 = L_10_func(L_729_arg1, "TweenInfo")
	L_735_arg7 = L_735_arg7.new
	L_736_arg8 = 0.15
	L_737_arg9 = L_10_func(L_729_arg1, "Enum")
	L_737_arg9 = L_737_arg9.EasingStyle
	L_737_arg9 = L_737_arg9.Quart
	L_738_arg10 = L_10_func(L_729_arg1, "Enum")
	L_738_arg10 = L_738_arg10.EasingDirection
	L_738_arg10 = L_738_arg10.Out
	L_735_arg7 = L_735_arg7(L_736_arg8, L_737_arg9, L_738_arg10)
	L_736_arg8 = L_731_arg3
	do
		local L_739_ = L_732_arg4;
		L_733_arg5 = L_739_;
		L_732_arg4 = L_739_.Create
	end
	L_732_arg4 = L_732_arg4(L_733_arg5, L_734_arg6, L_735_arg7, L_736_arg8)
	do
		local L_740_ = L_732_arg4;
		L_733_arg5 = L_740_;
		L_732_arg4 = L_740_.Play
	end
	L_732_arg4(L_733_arg5)
	return
end

L_13_.fn_085_animateError = function(L_741_arg0, L_742_arg1, L_743_arg2, L_744_arg3, L_745_arg4, L_746_arg5, L_747_arg6, L_748_arg7, L_749_arg8, L_750_arg9, L_751_arg10)
	L_743_arg2 = L_741_arg0[1][1]
	L_744_arg3 = {}
	L_746_arg5 = L_741_arg0[2][1]
	L_745_arg4 = L_746_arg5.Error
	L_744_arg3.TextColor3 = L_745_arg4
	L_745_arg4 = L_741_arg0[3][1]
	L_747_arg6 = L_743_arg2
	L_748_arg7 = L_10_func(L_742_arg1, "TweenInfo")
	L_748_arg7 = L_748_arg7.new
	L_749_arg8 = 0.15
	L_750_arg9 = L_10_func(L_742_arg1, "Enum")
	L_750_arg9 = L_750_arg9.EasingStyle
	L_750_arg9 = L_750_arg9.Quart
	L_751_arg10 = L_10_func(L_742_arg1, "Enum")
	L_751_arg10 = L_751_arg10.EasingDirection
	L_751_arg10 = L_751_arg10.Out
	L_748_arg7 = L_748_arg7(L_749_arg8, L_750_arg9, L_751_arg10)
	L_749_arg8 = L_744_arg3
	do
		local L_752_ = L_745_arg4;
		L_746_arg5 = L_752_;
		L_745_arg4 = L_752_.Create
	end
	L_745_arg4 = L_745_arg4(L_746_arg5, L_747_arg6, L_748_arg7, L_749_arg8)
	do
		local L_753_ = L_745_arg4;
		L_746_arg5 = L_753_;
		L_745_arg4 = L_753_.Play
	end
	L_745_arg4(L_746_arg5)
	return
end

L_13_.fn_086_animateControl2 = function(L_754_arg0, L_755_arg1, L_756_arg2, L_757_arg3, L_758_arg4, L_759_arg5, L_760_arg6, L_761_arg7, L_762_arg8, L_763_arg9, L_764_arg10)
	L_756_arg2 = L_754_arg0[1][1]
	L_757_arg3 = {}
	L_758_arg4 = L_10_func(L_755_arg1, "Color3")
	L_758_arg4 = L_758_arg4.new
	L_759_arg5 = 1
	L_760_arg6 = 1
	L_761_arg7 = 1
	L_758_arg4 = L_758_arg4(L_759_arg5, L_760_arg6, L_761_arg7)
	L_757_arg3.TextColor3 = L_758_arg4
	L_758_arg4 = L_754_arg0[2][1]
	L_760_arg6 = L_756_arg2
	L_761_arg7 = L_10_func(L_755_arg1, "TweenInfo")
	L_761_arg7 = L_761_arg7.new
	L_762_arg8 = 0.15
	L_763_arg9 = L_10_func(L_755_arg1, "Enum")
	L_763_arg9 = L_763_arg9.EasingStyle
	L_763_arg9 = L_763_arg9.Quart
	L_764_arg10 = L_10_func(L_755_arg1, "Enum")
	L_764_arg10 = L_764_arg10.EasingDirection
	L_764_arg10 = L_764_arg10.Out
	L_761_arg7 = L_761_arg7(L_762_arg8, L_763_arg9, L_764_arg10)
	L_762_arg8 = L_757_arg3
	do
		local L_765_ = L_758_arg4;
		L_759_arg5 = L_765_;
		L_758_arg4 = L_765_.Create
	end
	L_758_arg4 = L_758_arg4(L_759_arg5, L_760_arg6, L_761_arg7, L_762_arg8)
	do
		local L_766_ = L_758_arg4;
		L_759_arg5 = L_766_;
		L_758_arg4 = L_766_.Play
	end
	L_758_arg4(L_759_arg5)
	return
end

L_13_.fn_087_touchOrClick = function(L_767_arg0, L_768_arg1, L_769_arg2, L_770_arg3, L_771_arg4, L_772_arg5, L_773_arg6, L_774_arg7, L_775_arg8)
	L_770_arg3 = L_769_arg2.UserInputType
	L_771_arg4 = L_10_func(L_768_arg1, "Enum")
	L_771_arg4 = L_771_arg4.UserInputType
	L_771_arg4 = L_771_arg4.Touch
	L_775_arg8 = (L_770_arg3 == L_771_arg4)
	if not L_775_arg8 then
		L_770_arg3 = L_769_arg2.UserInputType
		L_771_arg4 = L_10_func(L_768_arg1, "Enum")
		L_771_arg4 = L_771_arg4.UserInputType
		L_771_arg4 = L_771_arg4.MouseButton1
		L_775_arg8 = (L_770_arg3 == L_771_arg4)
		if L_775_arg8 then
			L_770_arg3 = L_767_arg0[1][1]
			L_770_arg3 = L_770_arg3()
			if not L_770_arg3 then
				L_770_arg3 = L_767_arg0[2][1]
				L_773_arg6 = L_767_arg0[2][1]
				L_772_arg5 = L_773_arg6.Visible
				L_771_arg4 = not L_772_arg5
				L_770_arg3.Visible = L_771_arg4
			end
		end
		return
	end
	L_770_arg3 = L_767_arg0[1][1]
	L_770_arg3 = L_770_arg3()
	if not L_770_arg3 then
		L_770_arg3 = L_767_arg0[2][1]
		L_773_arg6 = L_767_arg0[2][1]
		L_772_arg5 = L_773_arg6.Visible
		L_771_arg4 = not L_772_arg5
		L_770_arg3.Visible = L_771_arg4
	end
	return
end

L_13_.fn_088_rightShiftToggle = function(L_776_arg0, L_777_arg1, L_778_arg2, L_779_arg3, L_780_arg4, L_781_arg5, L_782_arg6, L_783_arg7, L_784_arg8)
	L_779_arg3 = L_778_arg2.KeyCode
	L_780_arg4 = L_10_func(L_777_arg1, "Enum")
	L_780_arg4 = L_780_arg4.KeyCode
	L_780_arg4 = L_780_arg4.RightShift
	L_784_arg8 = (L_779_arg3 == L_780_arg4)
	if L_784_arg8 then
		L_779_arg3 = L_776_arg0[1][1]
		L_782_arg6 = L_776_arg0[1][1]
		L_781_arg5 = L_782_arg6.Visible
		L_780_arg4 = not L_781_arg5
		L_779_arg3.Visible = L_780_arg4
	end
	return
end

L_13_.fn_089_cancelDetachedTween = function(L_785_arg0, L_786_arg1, L_787_arg2, L_788_arg3, L_789_arg4)
	L_787_arg2 = L_785_arg0[1][1]
	L_789_arg4 = L_10_func(L_786_arg1, "game")
	do
		local L_790_ = L_787_arg2;
		L_788_arg3 = L_790_;
		L_787_arg2 = L_790_.IsDescendantOf
	end
	L_787_arg2 = L_787_arg2(L_788_arg3, L_789_arg4)
	if not L_787_arg2 then
		L_787_arg2 = L_785_arg0[2][1]
		do
			local L_791_ = L_787_arg2;
			L_788_arg3 = L_791_;
			L_787_arg2 = L_791_.Cancel
		end
		L_787_arg2(L_788_arg3)
	end
	return
end

L_13_.fn_090_fadeWindowImage = function(L_792_arg0, L_793_arg1, L_794_arg2, L_795_arg3, L_796_arg4, L_797_arg5, L_798_arg6, L_799_arg7, L_800_arg8)
	L_794_arg2 = L_10_func(L_793_arg1, "TweenInfo")
	L_794_arg2 = L_794_arg2.new
	L_795_arg3 = 1.6
	L_796_arg4 = L_10_func(L_793_arg1, "Enum")
	L_796_arg4 = L_796_arg4.EasingStyle
	L_796_arg4 = L_796_arg4.Quad
	L_797_arg5 = L_10_func(L_793_arg1, "Enum")
	L_797_arg5 = L_797_arg5.EasingDirection
	L_797_arg5 = L_797_arg5.InOut
	L_798_arg6 = -1
	L_799_arg7 = true
	L_794_arg2 = L_794_arg2(L_795_arg3, L_796_arg4, L_797_arg5, L_798_arg6, L_799_arg7)
	L_795_arg3 = L_792_arg0[1][1]
	L_797_arg5 = L_792_arg0[2][1]
	L_798_arg6 = L_794_arg2
	L_799_arg7 = {}
	L_800_arg8 = 0.85
	L_799_arg7.ImageTransparency = L_800_arg8
	do
		local L_801_ = L_795_arg3;
		L_796_arg4 = L_801_;
		L_795_arg3 = L_801_.Create
	end
	L_795_arg3 = L_795_arg3(L_796_arg4, L_797_arg5, L_798_arg6, L_799_arg7)
	do
		local L_802_ = L_795_arg3;
		L_797_arg5 = L_802_;
		L_796_arg4 = L_802_.Play
	end
	L_796_arg4(L_797_arg5)
	L_797_arg5 = L_792_arg0[3][1]
	L_796_arg4 = L_797_arg5.AncestryChanged
	L_798_arg6 = L_14_func(L_13_.fn_089_cancelDetachedTween, L_793_arg1, {
		L_792_arg0[3],
		{
			L_795_arg3
		}
	})
	do
		local L_803_ = L_796_arg4;
		L_797_arg5 = L_803_;
		L_796_arg4 = L_803_.Connect
	end
	L_796_arg4(L_797_arg5, L_798_arg6)
	return
end

L_13_.fn_091_animateTab = function(L_804_arg0, L_805_arg1, L_806_arg2, L_807_arg3, L_808_arg4, L_809_arg5, L_810_arg6, L_811_arg7, L_812_arg8, L_813_arg9, L_814_arg10)
	L_806_arg2 = L_804_arg0[1][1]
	if not L_806_arg2 then
		L_806_arg2 = true
		L_804_arg0[1][1] = L_806_arg2
		L_806_arg2 = L_804_arg0[2][1]
		L_807_arg3 = false
		L_806_arg2.Visible = L_807_arg3
		L_806_arg2 = L_804_arg0[3][1]
		L_807_arg3 = true
		L_806_arg2.Visible = L_807_arg3
		L_806_arg2 = L_804_arg0[3][1]
		L_807_arg3 = L_10_func(L_805_arg1, "UDim2")
		L_807_arg3 = L_807_arg3.new
		L_808_arg4 = 0
		L_809_arg5 = 0
		L_810_arg6 = 0
		L_811_arg7 = 0
		L_807_arg3 = L_807_arg3(L_808_arg4, L_809_arg5, L_810_arg6, L_811_arg7)
		L_806_arg2.Size = L_807_arg3
		L_806_arg2 = L_804_arg0[3][1]
		L_807_arg3 = {}
		L_808_arg4 = L_10_func(L_805_arg1, "UDim2")
		L_808_arg4 = L_808_arg4.new
		L_809_arg5 = 0
		L_810_arg6 = 170
		L_811_arg7 = 0
		L_812_arg8 = 46
		L_808_arg4 = L_808_arg4(L_809_arg5, L_810_arg6, L_811_arg7, L_812_arg8)
		L_807_arg3.Size = L_808_arg4
		L_808_arg4 = L_804_arg0[4][1]
		L_810_arg6 = L_806_arg2
		L_811_arg7 = L_10_func(L_805_arg1, "TweenInfo")
		L_811_arg7 = L_811_arg7.new
		L_812_arg8 = 0.35
		L_813_arg9 = L_10_func(L_805_arg1, "Enum")
		L_813_arg9 = L_813_arg9.EasingStyle
		L_813_arg9 = L_813_arg9.Quart
		L_814_arg10 = L_10_func(L_805_arg1, "Enum")
		L_814_arg10 = L_814_arg10.EasingDirection
		L_814_arg10 = L_814_arg10.Out
		L_811_arg7 = L_811_arg7(L_812_arg8, L_813_arg9, L_814_arg10)
		L_812_arg8 = L_807_arg3
		do
			local L_815_ = L_808_arg4;
			L_809_arg5 = L_815_;
			L_808_arg4 = L_815_.Create
		end
		L_808_arg4 = L_808_arg4(L_809_arg5, L_810_arg6, L_811_arg7, L_812_arg8)
		do
			local L_816_ = L_808_arg4;
			L_809_arg5 = L_816_;
			L_808_arg4 = L_816_.Play
		end
		L_808_arg4(L_809_arg5)
		return
	else
		return
	end
end

L_13_.fn_092 = function(L_817_arg0, L_818_arg1, L_819_arg2, L_820_arg3)
	L_819_arg2 = L_817_arg0[1][1]
	L_820_arg3 = false
	L_819_arg2.Visible = L_820_arg3
	return
end

L_13_.fn_093_delayedAnimation = function(L_821_arg0, L_822_arg1, L_823_arg2, L_824_arg3, L_825_arg4, L_826_arg5, L_827_arg6, L_828_arg7, L_829_arg8, L_830_arg9, L_831_arg10)
	L_823_arg2 = L_821_arg0[1][1]
	if L_823_arg2 then
		L_823_arg2 = false
		L_821_arg0[1][1] = L_823_arg2
		L_823_arg2 = L_821_arg0[2][1]
		L_824_arg3 = {}
		L_825_arg4 = L_10_func(L_822_arg1, "UDim2")
		L_825_arg4 = L_825_arg4.new
		L_826_arg5 = 0
		L_827_arg6 = 0
		L_828_arg7 = 0
		L_829_arg8 = 0
		L_825_arg4 = L_825_arg4(L_826_arg5, L_827_arg6, L_828_arg7, L_829_arg8)
		L_824_arg3.Size = L_825_arg4
		L_825_arg4 = L_821_arg0[3][1]
		L_827_arg6 = L_823_arg2
		L_828_arg7 = L_10_func(L_822_arg1, "TweenInfo")
		L_828_arg7 = L_828_arg7.new
		L_829_arg8 = 0.25
		L_830_arg9 = L_10_func(L_822_arg1, "Enum")
		L_830_arg9 = L_830_arg9.EasingStyle
		L_830_arg9 = L_830_arg9.Quart
		L_831_arg10 = L_10_func(L_822_arg1, "Enum")
		L_831_arg10 = L_831_arg10.EasingDirection
		L_831_arg10 = L_831_arg10.Out
		L_828_arg7 = L_828_arg7(L_829_arg8, L_830_arg9, L_831_arg10)
		L_829_arg8 = L_824_arg3
		do
			local L_832_ = L_825_arg4;
			L_826_arg5 = L_832_;
			L_825_arg4 = L_832_.Create
		end
		L_825_arg4 = L_825_arg4(L_826_arg5, L_827_arg6, L_828_arg7, L_829_arg8)
		do
			local L_833_ = L_825_arg4;
			L_826_arg5 = L_833_;
			L_825_arg4 = L_833_.Play
		end
		L_825_arg4(L_826_arg5)
		L_823_arg2 = L_10_func(L_822_arg1, "task")
		L_823_arg2 = L_823_arg2.delay
		L_824_arg3 = 0.26
		L_825_arg4 = L_14_func(L_13_.fn_092, L_822_arg1, {
			L_821_arg0[2]
		})
		L_823_arg2(L_824_arg3, L_825_arg4)
		L_823_arg2 = L_821_arg0[4][1]
		L_824_arg3 = true
		L_823_arg2.Visible = L_824_arg3
		return
	else
		return
	end
end

L_13_.fn_094 = function(L_834_arg0, L_835_arg1, L_836_arg2)
	L_836_arg2 = L_834_arg0[1][1]
	L_836_arg2 = L_836_arg2()
	if not L_836_arg2 then
		L_836_arg2 = L_834_arg0[2][1]
		L_836_arg2()
	end
	return
end

L_13_.fn_095_Select = function(L_837_arg0, L_838_arg1, ...)
	local L_839_ = L_837_arg0[1][1]
	local L_840_ = L_837_arg0[2][1]
	local L_841_ = L_837_arg0[3][1]
	local L_842_ = L_837_arg0[4][1]
	local L_843_ = L_837_arg0[5][1]
	local L_844_ = L_837_arg0[6][1]
	local L_845_ = L_837_arg0[7][1]
	local L_846_ = L_837_arg0[8][1]
	local L_847_ = L_10_func(L_838_arg1, "TweenInfo")
	local L_848_ = L_10_func(L_838_arg1, "Enum")
	local L_849_ = L_10_func(L_838_arg1, "Color3")
	local function L_850_func(L_851_arg0, L_852_arg1)
		L_840_:Create(
            L_851_arg0,
            L_847_.new(0.25, L_848_.EasingStyle.Quart, L_848_.EasingDirection.Out),
            L_852_arg1
        ):Play()
	end
	for L_853_forvar0, L_854_forvar1 in next, L_839_:GetChildren() do
		if L_854_forvar1:IsA("ImageButton") then
			local L_855_ = L_854_forvar1:FindFirstChild("Indicator")
			if L_855_ then
				L_850_func(L_855_, {
					BackgroundTransparency = 1
				})
			end
			local L_856_ = L_854_forvar1:FindFirstChild("Icon")
			if L_856_ then
				L_850_func(L_856_, {
					ImageColor3 = L_849_.fromRGB(140, 140, 140)
				})
			end
			for L_857_forvar0, L_858_forvar1 in next, L_854_forvar1:GetChildren() do
				if L_858_forvar1:IsA("Frame") and L_858_forvar1.Name ~= "Indicator" then
					L_850_func(L_858_forvar1, {
						BackgroundTransparency = 1
					})
				end
			end
		end
	end
	if L_841_.Current then
		for L_859_forvar0, L_860_forvar1 in next, L_841_.Current.Tab.SubTabs do
			L_860_forvar1.Btn.Visible = false
			L_860_forvar1.Page.Visible = false
		end
	end
	L_841_.Current = {
		Tab = L_842_
	}
	L_850_func(L_843_, {
		ImageColor3 = L_844_.Accent
	})
	L_850_func(L_845_, {
		BackgroundTransparency = 0
	})
	L_850_func(L_846_, {
		BackgroundTransparency = 0.85
	})
	for L_861_forvar0, L_862_forvar1 in next, L_842_.SubTabs do
		L_862_forvar1.Btn.Visible = true
	end
	if L_842_.CurrentST then
		L_842_.CurrentST:Select()
		return
	end
	if L_842_.SubTabs[1] then
		L_842_.SubTabs[1]:Select()
	end
	return
end

L_13_.fn_096_selectTabInternal = function(L_863_arg0, L_864_arg1, L_865_arg2, L_866_arg3)
	L_865_arg2 = L_863_arg0[1][1]
	do
		local L_867_ = L_865_arg2;
		L_866_arg3 = L_867_;
		L_865_arg2 = L_867_.Select
	end
	L_865_arg2(L_866_arg3)
	return
end

L_13_.fn_097_SetVisible = function(L_868_arg0, L_869_arg1, L_870_arg2, L_871_arg3, L_872_arg4)
	L_872_arg4 = L_868_arg0[1][1]
	L_872_arg4.Visible = L_871_arg3
	return
end

L_13_.fn_098_Select = function(L_873_arg0, L_874_arg1, L_875_arg2, L_876_arg3, L_877_arg4, L_878_arg5, L_879_arg6, L_880_arg7, L_881_arg8, L_882_arg9, L_883_arg10, L_884_arg11)
	L_877_arg4 = L_873_arg0[1][1]
	L_876_arg3 = L_877_arg4.CurrentST
	if L_876_arg3 then
		L_878_arg5 = L_873_arg0[1][1]
		L_877_arg4 = L_878_arg5.CurrentST
		L_876_arg3 = L_877_arg4.Page
		L_877_arg4 = false
		L_876_arg3.Visible = L_877_arg4
		L_879_arg6 = L_873_arg0[1][1]
		L_878_arg5 = L_879_arg6.CurrentST
		L_877_arg4 = L_878_arg5.Btn
		L_876_arg3 = L_877_arg4.Label
		L_877_arg4 = {}
		L_878_arg5 = L_10_func(L_874_arg1, "Color3")
		L_878_arg5 = L_878_arg5.fromRGB
		L_879_arg6 = 160
		L_880_arg7 = 160
		L_881_arg8 = 160
		L_878_arg5 = L_878_arg5(L_879_arg6, L_880_arg7, L_881_arg8)
		L_877_arg4.TextColor3 = L_878_arg5
		L_878_arg5 = L_873_arg0[2][1]
		L_880_arg7 = L_876_arg3
		L_881_arg8 = L_10_func(L_874_arg1, "TweenInfo")
		L_881_arg8 = L_881_arg8.new
		L_882_arg9 = 0.2
		L_883_arg10 = L_10_func(L_874_arg1, "Enum")
		L_883_arg10 = L_883_arg10.EasingStyle
		L_883_arg10 = L_883_arg10.Quart
		L_884_arg11 = L_10_func(L_874_arg1, "Enum")
		L_884_arg11 = L_884_arg11.EasingDirection
		L_884_arg11 = L_884_arg11.Out
		L_881_arg8 = L_881_arg8(L_882_arg9, L_883_arg10, L_884_arg11)
		L_882_arg9 = L_877_arg4
		do
			local L_885_ = L_878_arg5;
			L_879_arg6 = L_885_;
			L_878_arg5 = L_885_.Create
		end
		L_878_arg5 = L_878_arg5(L_879_arg6, L_880_arg7, L_881_arg8, L_882_arg9)
		do
			local L_886_ = L_878_arg5;
			L_879_arg6 = L_886_;
			L_878_arg5 = L_886_.Play
		end
		L_878_arg5(L_879_arg6)
		L_879_arg6 = L_873_arg0[1][1]
		L_878_arg5 = L_879_arg6.CurrentST
		L_877_arg4 = L_878_arg5.Btn
		L_876_arg3 = L_877_arg4.Icon
		L_877_arg4 = {}
		L_878_arg5 = L_10_func(L_874_arg1, "Color3")
		L_878_arg5 = L_878_arg5.fromRGB
		L_879_arg6 = 160
		L_880_arg7 = 160
		L_881_arg8 = 160
		L_878_arg5 = L_878_arg5(L_879_arg6, L_880_arg7, L_881_arg8)
		L_877_arg4.ImageColor3 = L_878_arg5
		L_878_arg5 = L_873_arg0[2][1]
		L_880_arg7 = L_876_arg3
		L_881_arg8 = L_10_func(L_874_arg1, "TweenInfo")
		L_881_arg8 = L_881_arg8.new
		L_882_arg9 = 0.2
		L_883_arg10 = L_10_func(L_874_arg1, "Enum")
		L_883_arg10 = L_883_arg10.EasingStyle
		L_883_arg10 = L_883_arg10.Quart
		L_884_arg11 = L_10_func(L_874_arg1, "Enum")
		L_884_arg11 = L_884_arg11.EasingDirection
		L_884_arg11 = L_884_arg11.Out
		L_881_arg8 = L_881_arg8(L_882_arg9, L_883_arg10, L_884_arg11)
		L_882_arg9 = L_877_arg4
		do
			local L_887_ = L_878_arg5;
			L_879_arg6 = L_887_;
			L_878_arg5 = L_887_.Create
		end
		L_878_arg5 = L_878_arg5(L_879_arg6, L_880_arg7, L_881_arg8, L_882_arg9)
		do
			local L_888_ = L_878_arg5;
			L_879_arg6 = L_888_;
			L_878_arg5 = L_888_.Play
		end
		L_878_arg5(L_879_arg6)
		L_878_arg5 = L_873_arg0[1][1]
		L_877_arg4 = L_878_arg5.CurrentST
		L_876_arg3 = L_877_arg4.Btn
		L_878_arg5 = "Frame"
		do
			local L_889_ = L_876_arg3;
			L_877_arg4 = L_889_;
			L_876_arg3 = L_889_.FindFirstChildOfClass
		end
		L_876_arg3 = L_876_arg3(L_877_arg4, L_878_arg5)
		if L_876_arg3 then
			L_877_arg4 = {}
			L_878_arg5 = 1
			L_877_arg4.BackgroundTransparency = L_878_arg5
			L_878_arg5 = L_873_arg0[2][1]
			L_880_arg7 = L_876_arg3
			L_881_arg8 = L_10_func(L_874_arg1, "TweenInfo")
			L_881_arg8 = L_881_arg8.new
			L_882_arg9 = 0.2
			L_883_arg10 = L_10_func(L_874_arg1, "Enum")
			L_883_arg10 = L_883_arg10.EasingStyle
			L_883_arg10 = L_883_arg10.Quart
			L_884_arg11 = L_10_func(L_874_arg1, "Enum")
			L_884_arg11 = L_884_arg11.EasingDirection
			L_884_arg11 = L_884_arg11.Out
			L_881_arg8 = L_881_arg8(L_882_arg9, L_883_arg10, L_884_arg11)
			L_882_arg9 = L_877_arg4
			do
				local L_890_ = L_878_arg5;
				L_879_arg6 = L_890_;
				L_878_arg5 = L_890_.Create
			end
			L_878_arg5 = L_878_arg5(L_879_arg6, L_880_arg7, L_881_arg8, L_882_arg9)
			do
				local L_891_ = L_878_arg5;
				L_879_arg6 = L_891_;
				L_878_arg5 = L_891_.Play
			end
			L_878_arg5(L_879_arg6)
		end
	end
	L_876_arg3 = L_873_arg0[1][1]
	L_877_arg4 = L_873_arg0[3][1]
	L_876_arg3.CurrentST = L_877_arg4
	L_876_arg3 = L_873_arg0[4][1]
	L_877_arg4 = true
	L_876_arg3.Visible = L_877_arg4
	L_876_arg3 = L_873_arg0[5][1]
	L_877_arg4 = {}
	L_878_arg5 = L_10_func(L_874_arg1, "Color3")
	L_878_arg5 = L_878_arg5.new
	L_879_arg6 = 1
	L_880_arg7 = 1
	L_881_arg8 = 1
	L_878_arg5 = L_878_arg5(L_879_arg6, L_880_arg7, L_881_arg8)
	L_877_arg4.TextColor3 = L_878_arg5
	L_878_arg5 = L_873_arg0[2][1]
	L_880_arg7 = L_876_arg3
	L_881_arg8 = L_10_func(L_874_arg1, "TweenInfo")
	L_881_arg8 = L_881_arg8.new
	L_882_arg9 = 0.2
	L_883_arg10 = L_10_func(L_874_arg1, "Enum")
	L_883_arg10 = L_883_arg10.EasingStyle
	L_883_arg10 = L_883_arg10.Quart
	L_884_arg11 = L_10_func(L_874_arg1, "Enum")
	L_884_arg11 = L_884_arg11.EasingDirection
	L_884_arg11 = L_884_arg11.Out
	L_881_arg8 = L_881_arg8(L_882_arg9, L_883_arg10, L_884_arg11)
	L_882_arg9 = L_877_arg4
	do
		local L_892_ = L_878_arg5;
		L_879_arg6 = L_892_;
		L_878_arg5 = L_892_.Create
	end
	L_878_arg5 = L_878_arg5(L_879_arg6, L_880_arg7, L_881_arg8, L_882_arg9)
	do
		local L_893_ = L_878_arg5;
		L_879_arg6 = L_893_;
		L_878_arg5 = L_893_.Play
	end
	L_878_arg5(L_879_arg6)
	L_876_arg3 = L_873_arg0[6][1]
	L_877_arg4 = {}
	L_879_arg6 = L_873_arg0[7][1]
	L_878_arg5 = L_879_arg6.Accent
	L_877_arg4.ImageColor3 = L_878_arg5
	L_878_arg5 = L_873_arg0[2][1]
	L_880_arg7 = L_876_arg3
	L_881_arg8 = L_10_func(L_874_arg1, "TweenInfo")
	L_881_arg8 = L_881_arg8.new
	L_882_arg9 = 0.2
	L_883_arg10 = L_10_func(L_874_arg1, "Enum")
	L_883_arg10 = L_883_arg10.EasingStyle
	L_883_arg10 = L_883_arg10.Quart
	L_884_arg11 = L_10_func(L_874_arg1, "Enum")
	L_884_arg11 = L_884_arg11.EasingDirection
	L_884_arg11 = L_884_arg11.Out
	L_881_arg8 = L_881_arg8(L_882_arg9, L_883_arg10, L_884_arg11)
	L_882_arg9 = L_877_arg4
	do
		local L_894_ = L_878_arg5;
		L_879_arg6 = L_894_;
		L_878_arg5 = L_894_.Create
	end
	L_878_arg5 = L_878_arg5(L_879_arg6, L_880_arg7, L_881_arg8, L_882_arg9)
	do
		local L_895_ = L_878_arg5;
		L_879_arg6 = L_895_;
		L_878_arg5 = L_895_.Play
	end
	L_878_arg5(L_879_arg6)
	L_876_arg3 = L_873_arg0[8][1]
	L_877_arg4 = {}
	L_878_arg5 = 0
	L_877_arg4.BackgroundTransparency = L_878_arg5
	L_878_arg5 = L_873_arg0[2][1]
	L_880_arg7 = L_876_arg3
	L_881_arg8 = L_10_func(L_874_arg1, "TweenInfo")
	L_881_arg8 = L_881_arg8.new
	L_882_arg9 = 0.2
	L_883_arg10 = L_10_func(L_874_arg1, "Enum")
	L_883_arg10 = L_883_arg10.EasingStyle
	L_883_arg10 = L_883_arg10.Quart
	L_884_arg11 = L_10_func(L_874_arg1, "Enum")
	L_884_arg11 = L_884_arg11.EasingDirection
	L_884_arg11 = L_884_arg11.Out
	L_881_arg8 = L_881_arg8(L_882_arg9, L_883_arg10, L_884_arg11)
	L_882_arg9 = L_877_arg4
	do
		local L_896_ = L_878_arg5;
		L_879_arg6 = L_896_;
		L_878_arg5 = L_896_.Create
	end
	L_878_arg5 = L_878_arg5(L_879_arg6, L_880_arg7, L_881_arg8, L_882_arg9)
	do
		local L_897_ = L_878_arg5;
		L_879_arg6 = L_897_;
		L_878_arg5 = L_897_.Play
	end
	L_878_arg5(L_879_arg6)
	return
end

L_13_.fn_099_selectSubTabInternal = function(L_898_arg0, L_899_arg1, L_900_arg2, L_901_arg3)
	L_900_arg2 = L_898_arg0[1][1]
	do
		local L_902_ = L_900_arg2;
		L_901_arg3 = L_902_;
		L_900_arg2 = L_902_.Select
	end
	L_900_arg2(L_901_arg3)
	return
end

L_13_.fn_100_animateToggleAccent = function(L_903_arg0, L_904_arg1, ...)
	local L_905_ = L_903_arg0[1][1]
	local L_906_ = L_903_arg0[2][1]
	local L_907_ = L_903_arg0[3][1]
	local L_908_ = L_903_arg0[4][1]
	local L_909_ = L_903_arg0[5][1]
	local L_910_ = L_903_arg0[6][1]
	local L_911_ = L_903_arg0[7][1]
	local L_912_ = L_10_func(L_904_arg1, "Color3")
	local L_913_ = L_10_func(L_904_arg1, "UDim2")
	local L_914_ = L_10_func(L_904_arg1, "TweenInfo")
	local L_915_ = L_10_func(L_904_arg1, "Enum")
	local L_916_ = L_914_.new(0.2, L_915_.EasingStyle.Quart, L_915_.EasingDirection.Out)
	local L_917_ = L_912_.fromRGB(35, 35, 35)
	local L_918_ = L_912_.fromRGB(225, 225, 225)
	local L_919_ = L_906_ and L_907_.Accent or nil
	L_908_:Create(L_905_, L_916_, {
		BackgroundColor3 = L_919_ or L_917_,
	}):Play()
	L_908_:Create(L_909_, L_916_, {
		Position = L_906_
            and L_913_.new(1, -16, 0.5, -7)
            or L_913_.new(0, 2, 0.5, -7),
	}):Play()
	L_908_:Create(L_910_, L_916_, {
		TextColor3 = L_919_ or L_918_,
	}):Play()
	if L_911_ then
		L_911_(L_906_)
	end
end

L_13_.fn_101_toggleInputBegan = function(L_920_arg0, L_921_arg1, ...)
	local L_922_ = ...
	local L_923_ = L_10_func(L_921_arg1, "Enum")
	local L_924_ = L_922_.UserInputType
	if L_924_ == L_923_.UserInputType.MouseButton1
        or L_924_ == L_923_.UserInputType.Touch
    then
		L_920_arg0[1][1] = not L_920_arg0[1][1]
		L_920_arg0[2][1]()
	end
end

L_13_.fn_102_Set = function(L_925_arg0, L_926_arg1, ...)
	local L_927_, L_928_ = ...
	L_925_arg0[1][1] = L_928_
	L_925_arg0[2][1]()
end

L_13_.fn_103_CreateToggle = function(L_929_arg0, L_930_arg1, ...)
	local L_931_, L_932_, L_933_, L_934_ = ...
	local L_935_ = L_929_arg0[1][1]
	local L_936_ = L_10_func(L_930_arg1, "Instance")
	local L_937_ = L_10_func(L_930_arg1, "Color3")
	local L_938_ = L_10_func(L_930_arg1, "UDim2")
	local L_939_ = L_10_func(L_930_arg1, "UDim")
	local L_940_ = L_10_func(L_930_arg1, "Vector2")
	local L_941_ = L_936_.new("Frame")
	L_941_.Parent = L_935_
	L_941_.BackgroundColor3 = L_937_.fromRGB(13, 13, 13)
	L_941_.Size = L_938_.new(1, 0, 0, 42)
	local L_942_ = L_936_.new("UICorner")
	L_942_.CornerRadius = L_939_.new(0, 6)
	L_942_.Parent = L_941_
	local L_943_ = L_936_.new("TextLabel")
	L_943_.Parent = L_941_
	L_943_.BackgroundTransparency = 1
	L_943_.Position = L_938_.new(0, 12, 0, 0)
	L_943_.Size = L_938_.new(1, -64, 1, 0)
	L_943_.Font = "Gotham"
	L_943_.Text = L_932_
	L_943_.TextColor3 = L_937_.fromRGB(225, 225, 225)
	L_943_.TextSize = 14
	L_943_.TextXAlignment = "Left"
	local L_944_ = L_936_.new("Frame")
	L_944_.Parent = L_941_
	L_944_.AnchorPoint = L_940_.new(1, 0.5)
	L_944_.BackgroundColor3 = L_937_.fromRGB(35, 35, 35)
	L_944_.Position = L_938_.new(1, -12, 0.5, 0)
	L_944_.Size = L_938_.new(0, 36, 0, 18)
	local L_945_ = L_936_.new("UICorner")
	L_945_.CornerRadius = L_939_.new(1, 0)
	L_945_.Parent = L_944_
	local L_946_ = L_936_.new("Frame")
	L_946_.Parent = L_944_
	L_946_.BackgroundColor3 = L_937_.new(1, 1, 1)
	L_946_.Position = L_938_.new(0, 2, 0.5, -7)
	L_946_.Size = L_938_.new(0, 14, 0, 14)
	local L_947_ = L_936_.new("UICorner")
	L_947_.CornerRadius = L_939_.new(1, 0)
	L_947_.Parent = L_946_

	local L_948_ = {
		L_933_ or false
	}
	local L_949_ = L_14_func(
        L_13_.fn_100_animateToggleAccent,
        L_930_arg1,
        {
		{
			L_944_
		},
		L_948_,
		L_929_arg0[2],
		L_929_arg0[3],
		{
			L_946_
		},
		{
			L_943_
		},
		{
			L_934_
		},
	}
    )
	L_941_.InputBegan:Connect(L_14_func(
        L_13_.fn_101_toggleInputBegan,
        L_930_arg1,
        {
		L_948_,
		{
			L_949_
		}
	}
    ))
	L_949_()
	return {
		Set = L_14_func(
            L_13_.fn_102_Set,
            L_930_arg1,
            {
			L_948_,
			{
				L_949_
			}
		}
        ),
	}
end

L_13_.fn_104 = function(L_950_arg0, L_951_arg1, L_952_arg2)
	L_952_arg2 = L_950_arg0[1][1]
	if L_952_arg2 then
		L_952_arg2 = L_950_arg0[1][1]
		L_952_arg2()
	end
	return
end

L_13_.fn_105_CreateButton = function(L_953_arg0, L_954_arg1, ...)
	local L_955_, L_956_, L_957_ = ...
	local L_958_ = L_10_func(L_954_arg1, "Instance")
	local L_959_ = L_10_func(L_954_arg1, "Color3")
	local L_960_ = L_10_func(L_954_arg1, "UDim2")
	local L_961_ = L_10_func(L_954_arg1, "UDim")
	local L_962_ = L_958_.new("TextButton")
	L_962_.Parent = L_953_arg0[1][1]
	L_962_.BackgroundColor3 = L_959_.fromRGB(13, 13, 13)
	L_962_.Size = L_960_.new(1, 0, 0, 42)
	L_962_.Text = ""
	L_962_.AutoButtonColor = false
	local L_963_ = L_958_.new("UICorner")
	L_963_.CornerRadius = L_961_.new(0, 6)
	L_963_.Parent = L_962_
	local L_964_ = L_958_.new("TextLabel")
	L_964_.Parent = L_962_
	L_964_.BackgroundTransparency = 1
	L_964_.Size = L_960_.new(1, 0, 1, 0)
	L_964_.Font = "Gotham"
	L_964_.Text = L_956_
	L_964_.TextColor3 = L_959_.fromRGB(225, 225, 225)
	L_964_.TextSize = 14
	L_962_.Activated:Connect(L_14_func(
        L_13_.fn_104,
        L_954_arg1,
        {
		{
			L_957_
		}
	}
    ))
	return L_962_
end

L_13_.fn_106_sliderFromMouse = function(L_965_arg0, L_966_arg1, ...)
	local L_967_ = ...
	local L_968_ = L_965_arg0[1][1]
	local L_969_ = L_965_arg0[2][1]
	local L_970_ = L_965_arg0[3][1]
	local L_971_ = L_965_arg0[4][1]
	local L_972_ = L_965_arg0[5][1]
	local L_973_ = L_965_arg0[6][1]
	local L_974_ = L_10_func(L_966_arg1, "math")
	local L_975_ = L_10_func(L_966_arg1, "UDim2")
	local L_976_ = L_10_func(L_966_arg1, "tostring")
	local L_977_ = L_967_.Position.X - L_968_.AbsolutePosition.X
	local L_978_ = L_974_.clamp(L_977_ / L_968_.AbsoluteSize.X, 0, 1)
	local L_979_ = L_974_.floor(L_969_ + (L_970_ - L_969_) * L_978_)
	L_971_.Size = L_975_.new(L_978_, 0, 1, 0)
	L_972_.Text = L_976_(L_979_)
	L_973_(L_979_)
end

L_13_.fn_107_sliderInputBegan = function(L_980_arg0, L_981_arg1, ...)
	local L_982_ = ...
	local L_983_ = L_10_func(L_981_arg1, "Enum")
	local L_984_ = L_982_.UserInputType
	if L_984_ == L_983_.UserInputType.MouseButton1
        or L_984_ == L_983_.UserInputType.Touch
    then
		L_980_arg0[1][1] = true
		L_980_arg0[2][1](L_982_)
	end
end

L_13_.fn_108_sliderInputEnded = function(L_985_arg0, L_986_arg1, ...)
	local L_987_ = ...
	local L_988_ = L_10_func(L_986_arg1, "Enum")
	local L_989_ = L_987_.UserInputType
	if L_989_ == L_988_.UserInputType.MouseButton1
        or L_989_ == L_988_.UserInputType.Touch
    then
		L_985_arg0[1][1] = false
	end
end

L_13_.fn_109_sliderInputChanged = function(L_990_arg0, L_991_arg1, ...)
	local L_992_ = ...
	if not L_990_arg0[1][1] then
		return
	end
	local L_993_ = L_10_func(L_991_arg1, "Enum")
	local L_994_ = L_992_.UserInputType
	if L_994_ == L_993_.UserInputType.MouseMovement
        or L_994_ == L_993_.UserInputType.Touch
    then
		L_990_arg0[2][1](L_992_)
	end
end

L_13_.fn_110_Set = function(L_995_arg0, L_996_arg1, ...)
	local L_997_, L_998_ = ...
	local L_999_ = L_995_arg0[1][1]
	local L_1000_ = L_995_arg0[2][1]
	local L_1001_ = L_995_arg0[3][1]
	local L_1002_ = L_995_arg0[4][1]
	local L_1003_ = L_995_arg0[5][1]
	local L_1004_ = L_10_func(L_996_arg1, "UDim2")
	local L_1005_ = L_10_func(L_996_arg1, "tostring")
	local L_1006_ = (L_998_ - L_999_) / (L_1000_ - L_999_)
	L_1001_.Size = L_1004_.new(L_1006_, 0, 1, 0)
	L_1002_.Text = L_1005_(L_998_)
	L_1003_(L_998_)
end

L_13_.fn_111_CreateSlider = function(L_1007_arg0, L_1008_arg1, ...)
	local L_1009_, L_1010_, L_1011_, L_1012_, L_1013_, L_1014_ = ...
	local L_1015_ = L_1007_arg0[1][1]
	local L_1016_ = L_1007_arg0[2][1]
	local L_1017_ = L_1007_arg0[3][1]
	local L_1018_ = L_10_func(L_1008_arg1, "Instance")
	local L_1019_ = L_10_func(L_1008_arg1, "Color3")
	local L_1020_ = L_10_func(L_1008_arg1, "UDim2")
	local L_1021_ = L_10_func(L_1008_arg1, "UDim")
	local L_1022_ = L_10_func(L_1008_arg1, "Vector2")
	local L_1023_ = L_10_func(L_1008_arg1, "tostring")
	local L_1024_ = L_1018_.new("Frame")
	L_1024_.Parent = L_1015_
	L_1024_.BackgroundColor3 = L_1019_.fromRGB(13, 13, 13)
	L_1024_.Size = L_1020_.new(1, 0, 0, 50)
	local L_1025_ = L_1018_.new("UICorner")
	L_1025_.CornerRadius = L_1021_.new(0, 6)
	L_1025_.Parent = L_1024_
	local L_1026_ = L_1018_.new("TextLabel")
	L_1026_.Parent = L_1024_
	L_1026_.BackgroundTransparency = 1
	L_1026_.Position = L_1020_.new(0, 12, 0, 0)
	L_1026_.Size = L_1020_.new(1, -64, 0, 28)
	L_1026_.Font = "Gotham"
	L_1026_.Text = L_1010_
	L_1026_.TextColor3 = L_1019_.fromRGB(225, 225, 225)
	L_1026_.TextSize = 14
	L_1026_.TextXAlignment = "Left"
	local L_1027_ = L_1018_.new("TextLabel")
	L_1027_.Parent = L_1024_
	L_1027_.BackgroundTransparency = 1
	L_1027_.Position = L_1020_.new(1, -60, 0, 0)
	L_1027_.Size = L_1020_.new(0, 48, 0, 24)
	L_1027_.Font = "GothamBold"
	L_1027_.Text = L_1023_(L_1013_)
	L_1027_.TextColor3 = L_1016_.Accent
	L_1027_.TextSize = 13
	L_1027_.TextXAlignment = "Right"
	local L_1028_ = L_1018_.new("Frame")
	L_1028_.Parent = L_1024_
	L_1028_.BackgroundColor3 = L_1019_.fromRGB(35, 35, 35)
	L_1028_.Position = L_1020_.new(0, 12, 0, 32)
	L_1028_.Size = L_1020_.new(1, -24, 0, 6)
	local L_1029_ = L_1018_.new("UICorner")
	L_1029_.CornerRadius = L_1021_.new(1, 0)
	L_1029_.Parent = L_1028_
	local L_1030_ = L_1018_.new("Frame")
	L_1030_.Parent = L_1028_
	L_1030_.BackgroundColor3 = L_1016_.Accent
	L_1030_.Size = L_1020_.new((L_1013_ - L_1011_) / (L_1012_ - L_1011_), 0, 1, 0)
	local L_1031_ = L_1018_.new("UICorner")
	L_1031_.CornerRadius = L_1021_.new(1, 0)
	L_1031_.Parent = L_1030_
	local L_1032_ = L_1018_.new("Frame")
	L_1032_.Parent = L_1030_
	L_1032_.AnchorPoint = L_1022_.new(1, 0.5)
	L_1032_.BackgroundColor3 = L_1019_.new(1, 1, 1)
	L_1032_.Position = L_1020_.new(1, 0, 0.5, 0)
	L_1032_.Size = L_1020_.new(0, 12, 0, 12)
	local L_1033_ = L_1018_.new("UICorner")
	L_1033_.CornerRadius = L_1021_.new(1, 0)
	L_1033_.Parent = L_1032_
	local L_1034_ = {
		false
	}
	local L_1035_ = L_14_func(
        L_13_.fn_106_sliderFromMouse,
        L_1008_arg1,
        {
		{
			L_1028_
		},
		{
			L_1011_
		},
		{
			L_1012_
		},
		{
			L_1030_
		},
		{
			L_1027_
		},
		{
			L_1014_
		}
	}
    )
	L_1028_.InputBegan:Connect(L_14_func(
        L_13_.fn_107_sliderInputBegan,
        L_1008_arg1,
        {
		L_1034_,
		{
			L_1035_
		}
	}
    ))
	L_1017_.InputEnded:Connect(L_14_func(
        L_13_.fn_108_sliderInputEnded,
        L_1008_arg1,
        {
		L_1034_
	}
    ))
	L_1017_.InputChanged:Connect(L_14_func(
        L_13_.fn_109_sliderInputChanged,
        L_1008_arg1,
        {
		L_1034_,
		{
			L_1035_
		}
	}
    ))
	return {
		Set = L_14_func(
            L_13_.fn_110_Set,
            L_1008_arg1,
            {
			{
				L_1011_
			},
			{
				L_1012_
			},
			{
				L_1030_
			},
			{
				L_1027_
			},
			{
				L_1014_
			}
		}
        ),
	}
end

L_13_.fn_112_updateDropdownLabel = function(L_1036_arg0, L_1037_arg1, ...)
	local L_1038_ = L_1036_arg0[1][1]
	local L_1039_ = L_1036_arg0[2][1]
	local L_1040_ = L_1036_arg0[3][1]
	local L_1041_ = L_1036_arg0[4]
	local L_1042_ = L_1036_arg0[5][1]
	local L_1043_ = L_1036_arg0[6][1]
	local L_1044_ = L_1036_arg0[7][1]
	local L_1045_ = L_1036_arg0[8][1]
	local L_1046_ = L_10_func(L_1037_arg1, "tostring")
	local L_1047_ = L_10_func(L_1037_arg1, "UDim2")
	local L_1048_ = L_10_func(L_1037_arg1, "TweenInfo")
	local L_1049_ = L_10_func(L_1037_arg1, "Enum")
	L_1038_.Text = L_1039_ .. ": " .. L_1046_(L_1040_)
	L_1041_[1] = false
	L_1042_.Text = "▼"
	L_1044_:Create(
        L_1043_,
        L_1048_.new(0.25, L_1049_.EasingStyle.Quart, L_1049_.EasingDirection.Out),
        {
		Size = L_1047_.new(1, 0, 0, 42)
	}
    ):Play()
	if L_1045_ then
		L_1045_(L_1040_)
	end
end

L_13_.fn_113_clearDropdownOptions = function(L_1050_arg0, L_1051_arg1, ...)
	local L_1052_ = ...
	local L_1053_ = L_1050_arg0[1][1]
	local L_1054_ = L_10_func(L_1051_arg1, "Instance")
	local L_1055_ = L_10_func(L_1051_arg1, "Color3")
	local L_1056_ = L_10_func(L_1051_arg1, "UDim2")
	local L_1057_ = L_10_func(L_1051_arg1, "UDim")
	local L_1058_ = L_10_func(L_1051_arg1, "tostring")
	for L_1059_forvar0, L_1060_forvar1 in next, L_1053_:GetChildren() do
		if L_1060_forvar1:IsA("TextButton") then
			L_1060_forvar1:Destroy()
		end
	end
	for L_1061_forvar0, L_1062_forvar1 in next, L_1052_ do
		local L_1063_ = L_1054_.new("TextButton")
		L_1063_.Parent = L_1053_
		L_1063_.BackgroundColor3 = L_1055_.fromRGB(22, 22, 22)
		L_1063_.Size = L_1056_.new(1, 0, 0, 28)
		L_1063_.Font = "Gotham"
		L_1063_.Text = L_1058_(L_1062_forvar1)
		L_1063_.TextColor3 = L_1055_.fromRGB(200, 200, 200)
		L_1063_.TextSize = 13
		L_1063_.AutoButtonColor = true
		local L_1064_ = L_1054_.new("UICorner")
		L_1064_.CornerRadius = L_1057_.new(0, 4)
		L_1064_.Parent = L_1063_
		L_1063_.Activated:Connect(L_14_func(
            L_13_.fn_112_updateDropdownLabel,
            L_1051_arg1,
            {
			L_1050_arg0[2],
			L_1050_arg0[3],
			{
				L_1062_forvar1
			},
			L_1050_arg0[4],
			L_1050_arg0[5],
			L_1050_arg0[6],
			L_1050_arg0[7],
			L_1050_arg0[8]
		}
        ))
	end
end

L_13_.fn_114_dropdownInput = function(L_1065_arg0, L_1066_arg1, ...)
	local L_1067_ = ...
	local L_1068_ = L_1065_arg0[1][1]
	local L_1069_ = L_1065_arg0[2]
	local L_1070_ = L_1065_arg0[3][1]
	local L_1071_ = L_1065_arg0[4][1]
	local L_1072_ = L_1065_arg0[5][1]
	local L_1073_ = L_10_func(L_1066_arg1, "Enum")
	local L_1074_ = L_1067_.UserInputType
	if L_1074_ ~= L_1073_.UserInputType.MouseButton1
        and L_1074_ ~= L_1073_.UserInputType.Touch
    then
		return
	end

	if L_1067_.Position.Y >= L_1068_.AbsolutePosition.Y + 42 then
		return
	end
	L_1069_[1] = not L_1069_[1]
	L_1070_.Text = L_1069_[1] and "▲" or "▼"
	local L_1075_ = 42
	if L_1069_[1] then
		L_1075_ = 42 + L_1071_.UIListLayout.AbsoluteContentSize.Y + 8
	end
	local L_1076_ = L_10_func(L_1066_arg1, "UDim2")
	local L_1077_ = L_10_func(L_1066_arg1, "TweenInfo")
	L_1072_:Create(
        L_1068_,
        L_1077_.new(0.25, L_1073_.EasingStyle.Quart, L_1073_.EasingDirection.Out),
        {
		Size = L_1076_.new(1, 0, 0, L_1075_)
	}
    ):Play()
end

L_13_.fn_115_Refresh = function(L_1078_arg0, L_1079_arg1, ...)
	local L_1080_, L_1081_ = ...
	L_1078_arg0[1][1](L_1081_)
end

L_13_.fn_116_CreateDropdown = function(L_1082_arg0, L_1083_arg1, ...)
	local L_1084_, L_1085_, L_1086_, L_1087_, L_1088_ = ...
	local L_1089_ = L_1082_arg0[1][1]
	local L_1090_ = L_1082_arg0[2][1]
	local L_1091_ = L_1082_arg0[3][1]
	local L_1092_ = L_10_func(L_1083_arg1, "Instance")
	local L_1093_ = L_10_func(L_1083_arg1, "Color3")
	local L_1094_ = L_10_func(L_1083_arg1, "UDim2")
	local L_1095_ = L_10_func(L_1083_arg1, "UDim")
	local L_1096_ = L_10_func(L_1083_arg1, "tostring")
	local L_1097_ = L_1092_.new("Frame")
	L_1097_.Parent = L_1089_
	L_1097_.BackgroundColor3 = L_1093_.fromRGB(13, 13, 13)
	L_1097_.Size = L_1094_.new(1, 0, 0, 42)
	L_1097_.ClipsDescendants = true
	local L_1098_ = L_1092_.new("UICorner")
	L_1098_.CornerRadius = L_1095_.new(0, 6)
	L_1098_.Parent = L_1097_
	local L_1099_ = L_1092_.new("UIStroke")
	L_1099_.Color = L_1093_.fromRGB(28, 28, 36)
	L_1099_.Thickness = 1
	L_1099_.Parent = L_1097_
	local L_1100_ = L_1092_.new("TextLabel")
	L_1100_.Parent = L_1097_
	L_1100_.BackgroundTransparency = 1
	L_1100_.Position = L_1094_.new(0, 12, 0, 0)
	L_1100_.Size = L_1094_.new(1, -52, 0, 42)
	L_1100_.Font = "Gotham"
	L_1100_.Text = L_1087_
        and (L_1085_ .. ": " .. L_1096_(L_1087_))
        or (L_1085_ .. ": Select Option")
	L_1100_.TextColor3 = L_1093_.fromRGB(225, 225, 225)
	L_1100_.TextSize = 13
	L_1100_.TextXAlignment = "Left"
	local L_1101_ = L_1092_.new("TextLabel")
	L_1101_.Parent = L_1097_
	L_1101_.BackgroundTransparency = 1
	L_1101_.Position = L_1094_.new(1, -38, 0, 0)
	L_1101_.Size = L_1094_.new(0, 28, 0, 42)
	L_1101_.Font = "GothamBold"
	L_1101_.Text = "▼"
	L_1101_.TextColor3 = L_1090_.Accent or L_1093_.fromRGB(0, 162, 255)
	L_1101_.TextSize = 16
	local L_1102_ = L_1092_.new("Frame")
	L_1102_.Parent = L_1097_
	L_1102_.BackgroundTransparency = 1
	L_1102_.Position = L_1094_.new(0, 6, 0, 42)
	L_1102_.Size = L_1094_.new(1, -12, 0, 0)
	local L_1103_ = L_1092_.new("UIListLayout")
	L_1103_.Padding = L_1095_.new(0, 3)
	L_1103_.Parent = L_1102_
	local L_1104_ = {
		false
	}
	local L_1105_ = L_14_func(
        L_13_.fn_113_clearDropdownOptions,
        L_1083_arg1,
        {
		{
			L_1102_
		},
		{
			L_1100_
		},
		{
			L_1085_
		},
		L_1104_,
		{
			L_1101_
		},
		{
			L_1097_
		},
		L_1082_arg0[3],
		{
			L_1088_
		},
	}
    )
	L_1105_(L_1086_)
	L_1097_.InputBegan:Connect(L_14_func(
        L_13_.fn_114_dropdownInput,
        L_1083_arg1,
        {
		{
			L_1097_
		},
		L_1104_,
		{
			L_1101_
		},
		{
			L_1102_
		},
		L_1082_arg0[3]
	}
    ))
	return {
		Refresh = L_14_func(
            L_13_.fn_115_Refresh,
            L_1083_arg1,
            {
			{
				L_1105_
			}
		}
        ),
	}
end

L_13_.fn_117_Set = function(L_1106_arg0, L_1107_arg1, L_1108_arg2, L_1109_arg3, L_1110_arg4, L_1111_arg5, L_1112_arg6, L_1113_arg7, L_1114_arg8)
	L_1110_arg4 = L_1106_arg0[1][1]
	L_1113_arg7 = "^\226\148\128\226\148\128%s*"
	L_1114_arg8 = ""
	do
		local L_1115_ = L_1109_arg3;
		L_1112_arg6 = L_1115_;
		L_1111_arg5 = L_1115_.gsub
	end
	L_1111_arg5 = L_1111_arg5(L_1112_arg6, L_1113_arg7, L_1114_arg8)
	L_1113_arg7 = "%s*\226\148\128\226\148\128$"
	L_1114_arg8 = ""
	do
		local L_1116_ = L_1111_arg5;
		L_1112_arg6 = L_1116_;
		L_1111_arg5 = L_1116_.gsub
	end
	L_1111_arg5 = L_1111_arg5(L_1112_arg6, L_1113_arg7, L_1114_arg8)
	L_1110_arg4.Text = L_1111_arg5
	return
end

L_13_.fn_118_Set = function(L_1117_arg0, L_1118_arg1, L_1119_arg2, L_1120_arg3, L_1121_arg4)
	L_1121_arg4 = L_1117_arg0[1][1]
	L_1121_arg4.Text = L_1120_arg3
	return
end

L_13_.fn_119_CreateLabel = function(L_1122_arg0, L_1123_arg1, ...)
	local L_1124_, L_1125_ = ...
	local L_1126_ = L_1122_arg0[1][1]
	local L_1127_ = L_1122_arg0[2][1]
	local L_1128_ = L_10_func(L_1123_arg1, "Instance")
	local L_1129_ = L_10_func(L_1123_arg1, "UDim2")
	local L_1130_ = L_10_func(L_1123_arg1, "UDim")
	local L_1131_ = L_10_func(L_1123_arg1, "Color3")
	local L_1132_ = L_1125_:sub(1, 2) == "──" or L_1125_:sub(1, 1) == "✦"
	if L_1132_ then
		local L_1136_ = L_1125_:gsub("^──%s*", ""):gsub("%s*──$", "")
		local L_1137_ = L_1128_.new("Frame")
		L_1137_.Parent = L_1126_
		L_1137_.BackgroundTransparency = 1
		L_1137_.Size = L_1129_.new(1, 0, 0, 26)
		local L_1138_ = L_1128_.new("TextLabel")
		L_1138_.Parent = L_1137_
		L_1138_.BackgroundTransparency = 1
		L_1138_.Position = L_1129_.new(0, 4, 0, 4)
		L_1138_.Size = L_1129_.new(1, -8, 1, -4)
		L_1138_.Font = "GothamBold"
		L_1138_.Text = L_1136_
		L_1138_.TextColor3 = L_1127_.Accent or L_1131_.fromRGB(0, 162, 255)
		L_1138_.TextSize = 12
		L_1138_.TextXAlignment = "Left"
		return {
			Set = L_14_func(L_13_.fn_117_Set, L_1123_arg1, {
				{
					L_1138_
				}
			}),
		}
	end
	local L_1133_ = L_1128_.new("Frame")
	L_1133_.Parent = L_1126_
	L_1133_.BackgroundColor3 = L_1131_.fromRGB(13, 13, 13)
	L_1133_.Size = L_1129_.new(1, 0, 0, 32)
	local L_1134_ = L_1128_.new("UICorner")
	L_1134_.CornerRadius = L_1130_.new(0, 6)
	L_1134_.Parent = L_1133_
	local L_1135_ = L_1128_.new("TextLabel")
	L_1135_.Parent = L_1133_
	L_1135_.BackgroundTransparency = 1
	L_1135_.Position = L_1129_.new(0, 12, 0, 0)
	L_1135_.Size = L_1129_.new(1, -24, 1, 0)
	L_1135_.Font = "Gotham"
	L_1135_.Text = L_1125_
	L_1135_.TextColor3 = L_1131_.fromRGB(180, 180, 180)
	L_1135_.TextSize = 13
	L_1135_.TextXAlignment = "Left"
	return {
		Set = L_14_func(L_13_.fn_118_Set, L_1123_arg1, {
			{
				L_1135_
			}
		}),
	}
end

L_13_.fn_120 = function(L_1139_arg0, L_1140_arg1, L_1141_arg2, L_1142_arg3, L_1143_arg4, L_1144_arg5)
	L_1142_arg3 = L_1139_arg0[1][1]
	if L_1142_arg3 then
		L_1142_arg3 = L_1139_arg0[1][1]
		L_1144_arg5 = L_1139_arg0[2][1]
		L_1143_arg4 = L_1144_arg5.Text
		L_1142_arg3(L_1143_arg4)
	end
	return
end

L_13_.fn_121_Set = function(L_1145_arg0, L_1146_arg1, L_1147_arg2, L_1148_arg3, L_1149_arg4, L_1150_arg5, L_1151_arg6)
	L_1149_arg4 = L_1145_arg0[1][1]
	L_1151_arg6 = L_1148_arg3
	L_1150_arg5 = L_10_func(L_1146_arg1, "tostring")
	L_1150_arg5 = L_1150_arg5(L_1151_arg6)
	L_1149_arg4.Text = L_1150_arg5
	return
end

L_13_.fn_122_CreateInput = function(L_1152_arg0, L_1153_arg1, ...)
	local L_1154_, L_1155_, L_1156_, L_1157_ = ...
	local L_1158_ = L_1152_arg0[1][1]
	local L_1159_ = L_10_func(L_1153_arg1, "Instance")
	local L_1160_ = L_10_func(L_1153_arg1, "UDim2")
	local L_1161_ = L_10_func(L_1153_arg1, "UDim")
	local L_1162_ = L_10_func(L_1153_arg1, "Color3")
	local L_1163_ = L_1159_.new("Frame")
	L_1163_.Parent = L_1158_
	L_1163_.BackgroundColor3 = L_1162_.fromRGB(13, 13, 13)
	L_1163_.Size = L_1160_.new(1, 0, 0, 42)
	local L_1164_ = L_1159_.new("UICorner")
	L_1164_.CornerRadius = L_1161_.new(0, 6)
	L_1164_.Parent = L_1163_
	local L_1165_ = L_1159_.new("UIStroke")
	L_1165_.Color = L_1162_.fromRGB(28, 28, 36)
	L_1165_.Thickness = 1
	L_1165_.Parent = L_1163_
	local L_1166_ = L_1159_.new("TextLabel")
	L_1166_.Parent = L_1163_
	L_1166_.BackgroundTransparency = 1
	L_1166_.Position = L_1160_.new(0, 12, 0, 0)
	L_1166_.Size = L_1160_.new(0.4, -12, 1, 0)
	L_1166_.Font = "Gotham"
	L_1166_.Text = L_1155_
	L_1166_.TextColor3 = L_1162_.fromRGB(225, 225, 225)
	L_1166_.TextSize = 13
	L_1166_.TextXAlignment = "Left"
	local L_1167_ = L_1159_.new("TextBox")
	L_1167_.Parent = L_1163_
	L_1167_.BackgroundColor3 = L_1162_.fromRGB(22, 22, 22)
	L_1167_.Position = L_1160_.new(0.4, 0, 0.15, 0)
	L_1167_.Size = L_1160_.new(0.6, -12, 0.7, 0)
	L_1167_.Font = "Gotham"
	L_1167_.Text = L_1156_ or ""
	L_1167_.TextColor3 = L_1162_.fromRGB(255, 255, 255)
	L_1167_.PlaceholderText = L_1156_ or "Type here..."
	L_1167_.TextSize = 13
	L_1167_.ClearTextOnFocus = false
	local L_1168_ = L_1159_.new("UICorner")
	L_1168_.CornerRadius = L_1161_.new(0, 4)
	L_1168_.Parent = L_1167_
	L_1167_.FocusLost:Connect(L_14_func(
        L_13_.fn_120,
        L_1153_arg1,
        {
		{
			L_1157_
		},
		{
			L_1167_
		}
	}
    ))
	return {
		Set = L_14_func(L_13_.fn_121_Set, L_1153_arg1, {
			{
				L_1167_
			}
		}),
	}
end

L_13_.fn_123_CreateSection = function(L_1169_arg0, L_1170_arg1, ...)
	local L_1171_, L_1172_ = ...
	local L_1173_ = L_1169_arg0[1][1]
	local L_1174_ = L_10_func(L_1170_arg1, "Instance")
	local L_1175_ = L_10_func(L_1170_arg1, "UDim2")
	local L_1176_ = L_10_func(L_1170_arg1, "UDim")
	local L_1177_ = L_10_func(L_1170_arg1, "Color3")
	local L_1178_ = L_1174_.new("Frame")
	L_1178_.Parent = L_1173_
	L_1178_.BackgroundColor3 = L_1177_.fromRGB(16, 16, 16)
	L_1178_.Size = L_1175_.new(1, 0, 0, 24)
	local L_1179_ = L_1174_.new("UICorner")
	L_1179_.CornerRadius = L_1176_.new(0, 6)
	L_1179_.Parent = L_1178_
	local L_1180_ = L_1174_.new("TextLabel")
	L_1180_.Parent = L_1178_
	L_1180_.BackgroundTransparency = 1
	L_1180_.Position = L_1175_.new(0, 12, 0, 0)
	L_1180_.Size = L_1175_.new(1, -12, 1, 0)
	L_1180_.Font = "GothamBold"
	L_1180_.Text = L_1172_:upper()
	L_1180_.TextColor3 = L_1177_.fromRGB(190, 190, 190)
	L_1180_.TextSize = 10
	L_1180_.TextXAlignment = "Left"
	local L_1181_ = L_1174_.new("Frame")
	L_1181_.Parent = L_1173_
	L_1181_.BackgroundTransparency = 1
	L_1181_.Size = L_1175_.new(1, 0, 0, 0)
	L_1181_.AutomaticSize = "Y"
	local L_1182_ = L_1174_.new("UIListLayout")
	L_1182_.Padding = L_1176_.new(0, 4)
	L_1182_.Parent = L_1181_
	return {
		CreateToggle = L_14_func(
            L_13_.fn_103_CreateToggle, L_1170_arg1, {
			{
				L_1181_
			},
			L_1169_arg0[2],
			L_1169_arg0[3]
		}
        ),
		CreateButton = L_14_func(
            L_13_.fn_105_CreateButton, L_1170_arg1, {
			{
				L_1181_
			}
		}
        ),
		CreateSlider = L_14_func(
            L_13_.fn_111_CreateSlider, L_1170_arg1, {
			{
				L_1181_
			},
			L_1169_arg0[2],
			L_1169_arg0[4]
		}
        ),
		CreateDropdown = L_14_func(
            L_13_.fn_116_CreateDropdown, L_1170_arg1, {
			{
				L_1181_
			},
			L_1169_arg0[2],
			L_1169_arg0[3]
		}
        ),
		CreateLabel = L_14_func(
            L_13_.fn_119_CreateLabel, L_1170_arg1, {
			{
				L_1181_
			},
			L_1169_arg0[2]
		}
        ),
		CreateInput = L_14_func(
            L_13_.fn_122_CreateInput, L_1170_arg1, {
			{
				L_1181_
			}
		}
        ),
	}
end

L_13_.fn_124_CreateSubTab = function(L_1183_arg0, L_1184_arg1, ...)
	local L_1185_, L_1186_, L_1187_ = ...
	local L_1188_ = L_1183_arg0[1][1]
	local L_1189_ = L_1183_arg0[2][1]
	local L_1190_ = L_1183_arg0[3][1]
	local L_1191_ = L_1183_arg0[4][1]
	local L_1192_ = L_1183_arg0[5][1]
	local L_1193_ = L_1183_arg0[6][1]
	local L_1194_ = L_10_func(L_1184_arg1, "Instance")
	local L_1195_ = L_10_func(L_1184_arg1, "UDim2")
	local L_1196_ = L_10_func(L_1184_arg1, "UDim")
	local L_1197_ = L_10_func(L_1184_arg1, "Vector2")
	local L_1198_ = L_10_func(L_1184_arg1, "Color3")
	local L_1199_ = L_10_func(L_1184_arg1, "Enum")
	local L_1200_ = L_10_func(L_1184_arg1, "table")
	local L_1201_ = L_1188_:GetIcon(L_1187_ or "layout")
	local L_1202_ = L_1194_.new("Frame")
	L_1202_.Parent = L_1189_
	L_1202_.BackgroundTransparency = 1
	L_1202_.Size = L_1195_.new(0, 0, 1, 0)
	L_1202_.AutomaticSize = "X"
	L_1202_.Visible = false
	local L_1203_ = L_1194_.new("TextButton")
	L_1203_.Parent = L_1202_
	L_1203_.BackgroundTransparency = 1
	L_1203_.Size = L_1195_.new(1, 0, 1, 0)
	L_1203_.Text = ""
	local L_1204_ = L_1194_.new("ImageLabel")
	L_1204_.Name = "Icon"
	L_1204_.Parent = L_1202_
	L_1204_.BackgroundTransparency = 1
	L_1204_.Position = L_1195_.new(0, 0, 0.5, -10)
	L_1204_.Size = L_1195_.new(0, 20, 0, 20)
	L_1204_.Image = "rbxassetid://" .. L_1201_[1]
	L_1204_.ImageRectSize = L_1197_.new(L_1201_[2], L_1201_[3])
	L_1204_.ImageRectOffset = L_1197_.new(L_1201_[4], L_1201_[5])
	L_1204_.ImageColor3 = L_1198_.fromRGB(160, 160, 160)
	L_1204_.ScaleType = L_1199_.ScaleType.Fit
	local L_1205_ = L_1194_.new("TextLabel")
	L_1205_.Name = "Label"
	L_1205_.Parent = L_1202_
	L_1205_.BackgroundTransparency = 1
	L_1205_.Position = L_1195_.new(0, 22, 0, 0)
	L_1205_.Size = L_1195_.new(0, 0, 1, 0)
	L_1205_.AutomaticSize = "X"
	L_1205_.Font = "Gotham"
	L_1205_.Text = L_1186_
	L_1205_.TextColor3 = L_1198_.fromRGB(160, 160, 160)
	L_1205_.TextSize = 13
	local L_1206_ = L_1194_.new("Frame")
	L_1206_.Parent = L_1202_
	L_1206_.BackgroundColor3 = L_1188_.Accent
	L_1206_.BackgroundTransparency = 1
	L_1206_.BorderSizePixel = 0
	L_1206_.Position = L_1195_.new(0, 0, 1, -2)
	L_1206_.Size = L_1195_.new(1, 0, 0, 2)
	local L_1207_ = L_1194_.new("ScrollingFrame")
	L_1207_.Parent = L_1190_
	L_1207_.BackgroundTransparency = 1
	L_1207_.BorderSizePixel = 0
	L_1207_.Size = L_1195_.new(1, 0, 1, 0)
	L_1207_.Visible = false
	L_1207_.ScrollBarThickness = 2
	L_1207_.ScrollBarImageColor3 = L_1188_.Accent
	L_1207_.CanvasSize = L_1195_.new(0, 0, 0, 0)
	L_1207_.AutomaticCanvasSize = "Y"
	local L_1208_ = L_1194_.new("UIListLayout")
	L_1208_.Parent = L_1207_
	L_1208_.Padding = L_1196_.new(0, 6)
	L_1208_.HorizontalAlignment = "Center"
	local L_1209_ = L_1194_.new("UIPadding")
	L_1209_.Parent = L_1207_
	L_1209_.PaddingTop = L_1196_.new(0, 10)
	L_1209_.PaddingLeft = L_1196_.new(0, 18)
	L_1209_.PaddingRight = L_1196_.new(0, 18)
	local L_1210_ = {
		Page = L_1207_,
		Btn = L_1202_,
	}
	L_1210_.Select = L_14_func(
        L_13_.fn_098_Select,
        L_1184_arg1,
        {
		L_1183_arg0[4],
		L_1183_arg0[5],
		{
			L_1210_
		},
		{
			L_1207_
		},
		{
			L_1205_
		},
		{
			L_1204_
		},
		L_1183_arg0[1],
		{
			L_1206_
		},
	}
    )
	L_1203_.Activated:Connect(L_14_func(
        L_13_.fn_099_selectSubTabInternal,
        L_1184_arg1,
        {
		{
			L_1210_
		}
	}
    ))
	L_1200_.insert(L_1191_.SubTabs, L_1210_)
	if L_1193_.Current
        and L_1193_.Current.Tab == L_1191_
        and not L_1191_.CurrentST
    then
		L_1202_.Visible = true
		L_1210_:Select()
	end
	L_1210_.CreateSection = L_14_func(
        L_13_.fn_123_CreateSection,
        L_1184_arg1,
        {
		{
			L_1207_
		},
		L_1183_arg0[1],
		L_1183_arg0[5],
		L_1183_arg0[7]
	}
    )
	return L_1210_
end

L_13_.fn_125_CreateTab = function(L_1211_arg0, L_1212_arg1, ...)
	local L_1213_, L_1214_, L_1215_ = ...
	local L_1216_ = L_1211_arg0[1][1]
	local L_1217_ = L_1211_arg0[2][1]
	local L_1218_ = L_1211_arg0[3][1]
	local L_1219_ = L_1211_arg0[4][1]
	local L_1220_ = L_10_func(L_1212_arg1, "Instance")
	local L_1221_ = L_10_func(L_1212_arg1, "UDim2")
	local L_1222_ = L_10_func(L_1212_arg1, "UDim")
	local L_1223_ = L_10_func(L_1212_arg1, "Vector2")
	local L_1224_ = L_10_func(L_1212_arg1, "Color3")
	local L_1225_ = L_10_func(L_1212_arg1, "Enum")
	local L_1226_ = L_1220_.new("ImageButton")
	L_1226_.Name = L_1214_ .. "Tab"
	L_1226_.Parent = L_1216_
	L_1226_.BackgroundTransparency = 1
	L_1226_.Size = L_1221_.new(1, 0, 0, 50)
	local L_1227_ = L_1220_.new("Frame")
	L_1227_.Parent = L_1226_
	L_1227_.BackgroundColor3 = L_1224_.fromRGB(30, 30, 30)
	L_1227_.BackgroundTransparency = 1
	L_1227_.BorderSizePixel = 0
	L_1227_.Size = L_1221_.new(1, 0, 1, 0)
	local L_1228_ = L_1220_.new("UICorner")
	L_1228_.CornerRadius = L_1222_.new(0, 6)
	L_1228_.Parent = L_1227_
	local L_1229_ = L_1220_.new("Frame")
	L_1229_.Name = "Indicator"
	L_1229_.Parent = L_1226_
	L_1229_.BackgroundColor3 = L_1217_.Accent
	L_1229_.BorderSizePixel = 0
	L_1229_.Position = L_1221_.new(0, 0, 0.5, -12)
	L_1229_.Size = L_1221_.new(0, 3, 0, 24)
	L_1229_.BackgroundTransparency = 1
	L_1229_.ZIndex = 5
	local L_1230_ = L_1220_.new("UICorner")
	L_1230_.CornerRadius = L_1222_.new(1, 0)
	L_1230_.Parent = L_1229_
	local L_1231_ = L_1217_:GetIcon(L_1215_ or "home")
	local L_1232_ = L_1220_.new("ImageLabel")
	L_1232_.Name = "Icon"
	L_1232_.Parent = L_1226_
	L_1232_.BackgroundTransparency = 1
	L_1232_.Position = L_1221_.new(0.5, -18, 0.5, -18)
	L_1232_.Size = L_1221_.new(0, 36, 0, 36)
	L_1232_.Image = "rbxassetid://" .. L_1231_[1]
	L_1232_.ImageRectSize = L_1223_.new(L_1231_[2], L_1231_[3])
	L_1232_.ImageRectOffset = L_1223_.new(L_1231_[4], L_1231_[5])
	L_1232_.ImageColor3 = L_1224_.fromRGB(140, 140, 140)
	L_1232_.ScaleType = L_1225_.ScaleType.Fit
	L_1232_.ZIndex = 6
	local L_1233_ = {
		SubTabs = {},
		CurrentST = nil,
	}
	L_1233_.Select = L_14_func(
        L_13_.fn_095_Select,
        L_1212_arg1,
        {
		L_1211_arg0[1],
		L_1211_arg0[3],
		L_1211_arg0[4],
		{
			L_1233_
		},
		{
			L_1232_
		},
		L_1211_arg0[2],
		{
			L_1229_
		},
		{
			L_1227_
		},
	}
    )
	L_1226_.Activated:Connect(L_14_func(
        L_13_.fn_096_selectTabInternal,
        L_1212_arg1,
        {
		{
			L_1233_
		}
	}
    ))
	L_1233_.SetVisible = L_14_func(
        L_13_.fn_097_SetVisible,
        L_1212_arg1,
        {
		{
			L_1226_
		}
	}
    )
	L_1233_.CreateSubTab = L_14_func(
        L_13_.fn_124_CreateSubTab,
        L_1212_arg1,
        {
		L_1211_arg0[2],
		L_1211_arg0[5],
		L_1211_arg0[6],
		{
			L_1233_
		},
		L_1211_arg0[3],
		L_1211_arg0[4],
		L_1211_arg0[7]
	}
    )
	local L_1234_ = L_10_func(L_1212_arg1, "Window")
	L_1234_.Tabs[L_1214_] = L_1233_
	if not L_1219_.Current then
		L_1233_:Select()
	end
	return L_1233_
end

L_13_.fn_126_CreateWindow = function(L_1235_arg0, L_1236_arg1, ...)
	local L_1237_, L_1238_ = ...
	local L_1239_ = L_1235_arg0[1][1]
	local L_1240_ = L_1235_arg0[2][1]
	local L_1241_ = L_1235_arg0[3][1]
	local L_1242_ = L_1235_arg0[4][1]
	local L_1243_ = L_1235_arg0[5][1]
	local L_1244_ = L_1235_arg0[6][1]
	local L_1245_ = L_1235_arg0[7][1]
	local L_1246_ = L_1235_arg0[8][1]
	local L_1247_ = L_1235_arg0[9][1]
	local L_1248_ = L_10_func(L_1236_arg1, "Instance")
	local L_1249_ = L_10_func(L_1236_arg1, "UDim2")
	local L_1250_ = L_10_func(L_1236_arg1, "UDim")
	local L_1251_ = L_10_func(L_1236_arg1, "Vector2")
	local L_1252_ = L_10_func(L_1236_arg1, "Color3")
	local L_1253_ = L_10_func(L_1236_arg1, "ColorSequence")
	local L_1254_ = L_10_func(L_1236_arg1, "Rect")
	local L_1255_ = L_10_func(L_1236_arg1, "Enum")
	local L_1256_ = L_10_func(L_1236_arg1, "task")
	local L_1257_ = L_10_func(L_1236_arg1, "pcall")
	local L_1258_ = L_10_func(L_1236_arg1, "tostring")
	local L_1259_ = L_10_func(L_1236_arg1, "math")

	local L_1260_, L_1261_ = L_1257_(L_14_func(
        L_13_.fn_073_makeGuid, L_1236_arg1, {}
    ))
	local L_1262_ = (L_1260_ and L_1261_) or L_1258_(L_1259_.random(10000000, 90000000))
	local L_1263_ = L_1248_.new("ScreenGui")
	L_1263_.Name = L_1262_
	L_1263_.ResetOnSpawn = false

	local L_1264_ = {
		false
	}
	if not L_1239_:IsStudio() then
		local L_1311_ = L_10_func(L_1236_arg1, "syn")
		if L_1311_ and L_1311_.protect_gui then
			L_1257_(L_14_func(
                L_13_.fn_074_protectWindowGui,
                L_1236_arg1,
                {
				{
					L_1263_
				},
				L_1235_arg0[2],
				L_1264_
			}
            ))
		end
		if not L_1264_[1] and L_10_func(L_1236_arg1, "gethui") then
			L_1257_(L_14_func(
                L_13_.fn_075_parentWindowGetHui,
                L_1236_arg1,
                {
				{
					L_1263_
				},
				L_1264_
			}
            ))
		end
		if not L_1264_[1] and L_10_func(L_1236_arg1, "get_hidden_gui") then
			L_1257_(L_14_func(
                L_13_.fn_076_parentWindowHiddenGui,
                L_1236_arg1,
                {
				{
					L_1263_
				},
				L_1264_
			}
            ))
		end
	end
	if not L_1264_[1] then
		L_1263_.Parent = L_1239_:IsStudio() and L_1241_.PlayerGui or L_1240_
	end
	local L_1265_ = L_10_func(L_1236_arg1, "getgenv")
	if L_1265_ then
		local L_1312_ = "_h_" .. L_1262_
		local L_1313_ = L_1265_()
		if L_1313_[L_1312_] then
			L_1257_(L_14_func(
                L_13_.fn_077_cleanupExistingGui,
                L_1236_arg1,
                {
				{
					L_1312_
				}
			}
            ))
		end
		L_1313_[L_1312_] = L_1263_
	end
	local L_1266_ = L_1248_.new("Frame")
	L_1266_.Parent = L_1263_
	L_1266_.BackgroundColor3 = L_1242_.BgPrimary
	L_1266_.Position = L_1249_.new(0.5, -300, 0.5, -220)
	L_1266_.Size = L_1249_.new(0, 600, 0, 440)
	L_1266_.ClipsDescendants = true
	L_1266_.Visible = true
	local L_1267_ = L_1248_.new("UICorner")
	L_1267_.CornerRadius = L_1250_.new(0, 10)
	L_1267_.Parent = L_1266_
	local L_1268_ = L_1248_.new("ImageLabel")
	L_1268_.Name = "Glow"
	L_1268_.Parent = L_1266_
	L_1268_.ZIndex = 0
	L_1268_.BackgroundTransparency = 1
	L_1268_.Position = L_1249_.new(0, -25, 0, -25)
	L_1268_.Size = L_1249_.new(1, 50, 1, 50)
	L_1268_.Image = "rbxassetid://6015667320"
	L_1268_.ImageColor3 = L_1242_.Accent
	L_1268_.ImageTransparency = 0.5
	L_1268_.ScaleType = L_1255_.ScaleType.Slice
	L_1268_.SliceCenter = L_1254_.new(49, 49, 450, 450)
	local L_1269_ = L_1248_.new("UIStroke")
	L_1269_.Color = L_1242_.Border
	L_1269_.Thickness = 1
	L_1269_.ApplyStrokeMode = L_1255_.ApplyStrokeMode.Border
	L_1269_.LineJoinMode = L_1255_.LineJoinMode.Round
	L_1269_.Parent = L_1266_
	L_1256_.spawn(L_14_func(
        L_13_.fn_079_fadeImage,
        L_1236_arg1,
        {
		L_1235_arg0[5],
		{
			L_1268_
		},
		{
			L_1266_
		}
	}
    ))

	local L_1270_ = L_1248_.new("Frame")
	L_1270_.Parent = L_1266_
	L_1270_.BackgroundColor3 = L_1242_.BgSecondary
	L_1270_.Size = L_1249_.new(0, 65, 1, 0)
	local L_1271_ = L_1248_.new("UICorner")
	L_1271_.CornerRadius = L_1250_.new(0, 10)
	L_1271_.Parent = L_1270_
	local L_1272_ = L_1248_.new("Frame")
	L_1272_.Parent = L_1270_
	L_1272_.BackgroundColor3 = L_1242_.BgSecondary
	L_1272_.BorderSizePixel = 0
	L_1272_.AnchorPoint = L_1251_.new(1, 0)
	L_1272_.Position = L_1249_.new(1, 0, 0, 0)
	L_1272_.Size = L_1249_.new(0, 15, 1, 0)
	local L_1273_ = L_1248_.new("UIStroke")
	L_1273_.Color = L_1242_.Border
	L_1273_.ApplyStrokeMode = "Border"
	L_1273_.Parent = L_1270_
	local L_1274_ = L_1248_.new("Frame")
	L_1274_.Name = "Branding"
	L_1274_.Parent = L_1270_
	L_1274_.BackgroundTransparency = 1
	L_1274_.Size = L_1249_.new(1, 0, 0, 65)
	local L_1275_ = L_1248_.new("ImageLabel")
	L_1275_.Parent = L_1274_
	L_1275_.BackgroundTransparency = 1
	L_1275_.AnchorPoint = L_1251_.new(0.5, 0.5)
	L_1275_.Position = L_1249_.new(0.5, 0, 0.5, 0)
	L_1275_.Size = L_1249_.new(0, 42, 0, 42)
	L_1275_.Image = "rbxassetid://123802801726537"
	L_1275_.ScaleType = L_1255_.ScaleType.Fit
	local L_1276_ = L_1248_.new("Frame")
	L_1276_.Parent = L_1274_
	L_1276_.BackgroundColor3 = L_1252_.fromRGB(35, 35, 35)
	L_1276_.BorderSizePixel = 0
	L_1276_.Position = L_1249_.new(0, 10, 1, -1)
	L_1276_.Size = L_1249_.new(1, -20, 0, 1)
	local L_1277_ = L_1248_.new("ScrollingFrame")
	L_1277_.Parent = L_1270_
	L_1277_.BackgroundTransparency = 1
	L_1277_.Position = L_1249_.new(0, 0, 0, 65)
	L_1277_.Size = L_1249_.new(1, 0, 1, -135)
	L_1277_.CanvasSize = L_1249_.new(0, 0, 0, 0)
	L_1277_.AutomaticCanvasSize = "Y"
	L_1277_.ScrollBarThickness = 1
	L_1277_.ScrollBarImageTransparency = 1
	L_1277_.ScrollingDirection = "Y"
	local L_1278_ = L_1248_.new("UIListLayout")
	L_1278_.Parent = L_1277_
	L_1278_.HorizontalAlignment = "Center"
	L_1278_.Padding = L_1250_.new(0, 8)

	local L_1279_ = L_1248_.new("Frame")
	L_1279_.Name = "Profile"
	L_1279_.Parent = L_1270_
	L_1279_.BackgroundTransparency = 1
	L_1279_.AnchorPoint = L_1251_.new(0, 1)
	L_1279_.Position = L_1249_.new(0, 0, 1, 0)
	L_1279_.Size = L_1249_.new(1, 0, 0, 70)
	local L_1280_ = L_1248_.new("Frame")
	L_1280_.Parent = L_1279_
	L_1280_.BackgroundColor3 = L_1252_.fromRGB(35, 35, 35)
	L_1280_.BorderSizePixel = 0
	L_1280_.Position = L_1249_.new(0, 10, 0, 0)
	L_1280_.Size = L_1249_.new(1, -20, 0, 1)
	local L_1281_ = L_1248_.new("Frame")
	L_1281_.Parent = L_1279_
	L_1281_.BackgroundColor3 = L_1252_.fromRGB(30, 30, 30)
	L_1281_.AnchorPoint = L_1251_.new(0.5, 0.5)
	L_1281_.Position = L_1249_.new(0.5, 0, 0.5, 0)
	L_1281_.Size = L_1249_.new(0, 44, 0, 44)
	local L_1282_ = L_1248_.new("UICorner")
	L_1282_.CornerRadius = L_1250_.new(1, 0)
	L_1282_.Parent = L_1281_
	local L_1283_ = L_1248_.new("UIStroke")
	L_1283_.Color = L_1242_.Border
	L_1283_.Thickness = 1
	L_1283_.Parent = L_1281_
	local L_1284_ = L_1248_.new("ImageLabel")
	L_1284_.Parent = L_1281_
	L_1284_.BackgroundTransparency = 1
	L_1284_.Size = L_1249_.new(1, 0, 1, 0)
	L_1284_.Image = ""
	local L_1285_ = L_1248_.new("UICorner")
	L_1285_.CornerRadius = L_1250_.new(1, 0)
	L_1285_.Parent = L_1284_
	L_1256_.spawn(L_14_func(
        L_13_.fn_081,
        L_1236_arg1,
        {
		L_1235_arg0[6],
		L_1235_arg0[3],
		{
			L_1284_
		}
	}
    ))

	local L_1286_ = L_1248_.new("Frame")
	L_1286_.Parent = L_1266_
	L_1286_.BackgroundTransparency = 1
	L_1286_.Position = L_1249_.new(0, 65, 0, 0)
	L_1286_.Size = L_1249_.new(1, -65, 1, 0)
	local L_1287_ = L_1248_.new("Frame")
	L_1287_.Name = "DragBar"
	L_1287_.Parent = L_1266_
	L_1287_.BackgroundTransparency = 1
	L_1287_.Size = L_1249_.new(1, 0, 0, 48)
	L_1287_.ZIndex = 0
	local L_1288_ = L_1248_.new("Frame")
	L_1288_.Name = "DragSide"
	L_1288_.Parent = L_1270_
	L_1288_.BackgroundTransparency = 1
	L_1288_.Size = L_1249_.new(1, 0, 0, 65)
	L_1288_.ZIndex = 11

	local L_1289_ = L_1245_:MakeDraggable(L_1287_, L_1266_)
	L_1245_:MakeDraggable(L_1288_, L_1266_)
	local L_1290_ = L_1248_.new("Frame")
	L_1290_.Parent = L_1286_
	L_1290_.BackgroundTransparency = 1
	L_1290_.Size = L_1249_.new(1, 0, 0, 48)
	local L_1291_ = L_1248_.new("TextLabel")
	L_1291_.Parent = L_1290_
	L_1291_.BackgroundTransparency = 1
	L_1291_.Position = L_1249_.new(0, 16, 0, 0)
	L_1291_.Size = L_1249_.new(0, 180, 1, 0)
	L_1291_.Font = "GothamBold"
	L_1291_.Text = L_1238_ or "Snowy Studios"
	L_1291_.TextColor3 = L_1252_.new(1, 1, 1)
	L_1291_.TextSize = 18
	L_1291_.TextXAlignment = "Left"
	local L_1292_ = L_1248_.new("TextButton")
	L_1292_.Name = "CloseBtn"
	L_1292_.Parent = L_1290_
	L_1292_.AnchorPoint = L_1251_.new(1, 0.5)
	L_1292_.BackgroundTransparency = 1
	L_1292_.Position = L_1249_.new(1, -12, 0.5, 0)
	L_1292_.Size = L_1249_.new(0, 24, 0, 24)
	L_1292_.Font = "GothamBold"
	L_1292_.Text = "X"
	L_1292_.TextColor3 = L_1252_.new(1, 1, 1)
	L_1292_.TextSize = 13
	L_1292_.AutoButtonColor = false
	L_1292_.ZIndex = 12
	L_1292_.Activated:Connect(L_14_func(
        L_13_.fn_082_destroyWindow,
        L_1236_arg1,
        {
		{
			L_1289_
		},
		{
			L_1263_
		}
	}
    ))
	local L_1293_ = L_1248_.new("TextButton")
	L_1293_.Name = "MinBtn"
	L_1293_.Parent = L_1290_
	L_1293_.AnchorPoint = L_1251_.new(1, 0.5)
	L_1293_.BackgroundTransparency = 1
	L_1293_.Position = L_1249_.new(1, -42, 0.5, 0)
	L_1293_.Size = L_1249_.new(0, 24, 0, 24)
	L_1293_.Font = "GothamBold"
	L_1293_.Text = "–"
	L_1293_.TextColor3 = L_1252_.new(1, 1, 1)
	L_1293_.TextSize = 22
	L_1293_.AutoButtonColor = false
	L_1293_.ZIndex = 12
	L_1293_.MouseEnter:Connect(L_14_func(
        L_13_.fn_083_animateAccent, L_1236_arg1, {
		{
			L_1293_
		},
		L_1235_arg0[4],
		L_1235_arg0[5]
	}
    ))
	L_1293_.MouseLeave:Connect(L_14_func(
        L_13_.fn_084_animateControl, L_1236_arg1, {
		{
			L_1293_
		},
		L_1235_arg0[5]
	}
    ))
	L_1292_.MouseEnter:Connect(L_14_func(
        L_13_.fn_085_animateError, L_1236_arg1, {
		{
			L_1292_
		},
		L_1235_arg0[4],
		L_1235_arg0[5]
	}
    ))
	L_1292_.MouseLeave:Connect(L_14_func(
        L_13_.fn_086_animateControl2, L_1236_arg1, {
		{
			L_1292_
		},
		L_1235_arg0[5]
	}
    ))
	local L_1294_ = L_1248_.new("Frame")
	L_1294_.Parent = L_1290_
	L_1294_.BackgroundTransparency = 1
	L_1294_.Position = L_1249_.new(0, 200, 0, 0)
	L_1294_.Size = L_1249_.new(1, -240, 1, 0)
	local L_1295_ = L_1248_.new("UIListLayout")
	L_1295_.Parent = L_1294_
	L_1295_.FillDirection = "Horizontal"
	L_1295_.Padding = L_1250_.new(0, 18)
	L_1295_.VerticalAlignment = "Center"
	local L_1296_ = L_1248_.new("Frame")
	L_1296_.Parent = L_1290_
	L_1296_.BackgroundColor3 = L_1242_.Border
	L_1296_.BorderSizePixel = 0
	L_1296_.Position = L_1249_.new(0, 0, 1, -1)
	L_1296_.Size = L_1249_.new(1, 0, 0, 1)
	local L_1297_ = L_1248_.new("Frame")
	L_1297_.Name = "MainFolder"
	L_1297_.Parent = L_1286_
	L_1297_.BackgroundTransparency = 1
	local L_1298_ = L_1246_ and 92 or 48
	L_1297_.Position = L_1249_.new(0, 0, 0, L_1298_)
	L_1297_.Size = L_1249_.new(1, 0, 1, -L_1298_)

	if L_1247_.TouchEnabled then
		local L_1314_ = L_1248_.new("ImageButton")
		L_1314_.Name = "MobileToggle"
		L_1314_.Parent = L_1263_
		L_1314_.BackgroundColor3 = L_1242_.BgSecondary
		L_1314_.Position = L_1249_.new(1, -60, 1, -60)
		L_1314_.Size = L_1249_.new(0, 44, 0, 44)
		L_1314_.Image = ""
		L_1314_.AutoButtonColor = false
		L_1314_.ZIndex = 100
		local L_1315_ = L_1248_.new("UICorner")
		L_1315_.CornerRadius = L_1250_.new(0, 10)
		L_1315_.Parent = L_1314_
		local L_1316_ = L_1248_.new("UIStroke")
		L_1316_.Color = L_1245_.Accent
		L_1316_.Thickness = 2
		L_1316_.Parent = L_1314_
		local L_1317_ = L_1248_.new("ImageLabel")
		L_1317_.Parent = L_1314_
		L_1317_.BackgroundTransparency = 1
		L_1317_.Position = L_1249_.new(0.5, -14, 0.5, -14)
		L_1317_.Size = L_1249_.new(0, 28, 0, 28)
		L_1317_.Image = "rbxassetid://123802801726537"
		L_1317_.ScaleType = L_1255_.ScaleType.Fit
		L_1317_.ZIndex = 101
		local L_1318_ = L_1245_:MakeDraggable(L_1314_)
		L_1314_.InputEnded:Connect(L_14_func(
            L_13_.fn_087_touchOrClick,
            L_1236_arg1,
            {
			{
				L_1318_
			},
			{
				L_1266_
			}
		}
        ))
	end
	L_1247_.InputBegan:Connect(L_14_func(
        L_13_.fn_088_rightShiftToggle,
        L_1236_arg1,
        {
		{
			L_1266_
		}
	}
    ))

	local L_1299_ = L_1248_.new("ImageButton")
	L_1299_.Name = "SnowyMarketBubble"
	L_1299_.Parent = L_1263_
	L_1299_.AnchorPoint = L_1251_.new(0, 0)
	L_1299_.Position = L_1249_.new(0, 30, 0, 30)
	L_1299_.Size = L_1249_.new(0, 0, 0, 0)
	L_1299_.BackgroundColor3 = L_1242_.BgCard
	L_1299_.BorderSizePixel = 0
	L_1299_.AutoButtonColor = false
	L_1299_.Image = ""
	L_1299_.Visible = false
	L_1299_.ZIndex = 200
	local L_1300_ = L_1248_.new("UICorner")
	L_1300_.CornerRadius = L_1250_.new(1, 0)
	L_1300_.Parent = L_1299_
	local L_1301_ = L_1248_.new("UIStroke")
	L_1301_.Color = L_1242_.Accent
	L_1301_.Thickness = 2
	L_1301_.Parent = L_1299_
	local L_1302_ = L_1248_.new("UIGradient")
	L_1302_.Color = L_1253_.new(L_1242_.BgSecondary, L_1242_.BgCard)
	L_1302_.Rotation = 125
	L_1302_.Parent = L_1299_
	local L_1303_ = L_1248_.new("ImageLabel")
	L_1303_.Parent = L_1299_
	L_1303_.BackgroundTransparency = 1
	L_1303_.Position = L_1249_.new(0, -15, 0, -15)
	L_1303_.Size = L_1249_.new(1, 30, 1, 30)
	L_1303_.Image = "rbxassetid://6015667320"
	L_1303_.ImageColor3 = L_1242_.Accent
	L_1303_.ImageTransparency = 0.55
	L_1303_.ScaleType = L_1255_.ScaleType.Slice
	L_1303_.SliceCenter = L_1254_.new(49, 49, 450, 450)
	L_1303_.ZIndex = 199
	local L_1304_ = L_1248_.new("ImageLabel")
	L_1304_.Parent = L_1299_
	L_1304_.BackgroundTransparency = 1
	L_1304_.AnchorPoint = L_1251_.new(0.5, 0.5)
	L_1304_.Position = L_1249_.new(0, 26, 0.5, 0)
	L_1304_.Size = L_1249_.new(0, 30, 0, 30)
	L_1304_.Image = "rbxassetid://123802801726537"
	L_1304_.ScaleType = L_1255_.ScaleType.Fit
	L_1304_.ZIndex = 201
	local L_1305_ = L_1248_.new("TextLabel")
	L_1305_.Parent = L_1299_
	L_1305_.BackgroundTransparency = 1
	L_1305_.Position = L_1249_.new(0, 52, 0, 0)
	L_1305_.Size = L_1249_.new(1, -64, 1, 0)
	L_1305_.Font = L_1255_.Font.GothamBlack
	L_1305_.Text = "Snowy Studios"
	L_1305_.TextColor3 = L_1252_.new(1, 1, 1)
	L_1305_.TextSize = 15
	L_1305_.TextXAlignment = L_1255_.TextXAlignment.Left
	L_1305_.ZIndex = 201
	local L_1306_ = L_1248_.new("UIGradient")
	L_1306_.Color = L_1253_.new(L_1242_.AccentGlow, L_1242_.AccentBright)
	L_1306_.Parent = L_1305_
	L_1245_:MakeDraggable(L_1299_)
	L_1256_.spawn(L_14_func(
        L_13_.fn_090_fadeWindowImage,
        L_1236_arg1,
        {
		L_1235_arg0[5],
		{
			L_1303_
		},
		{
			L_1299_
		}
	}
    ))
	local L_1307_ = {
		false
	}
	local L_1308_ = L_14_func(
        L_13_.fn_091_animateTab,
        L_1236_arg1,
        {
		L_1307_,
		{
			L_1266_
		},
		{
			L_1299_
		},
		L_1235_arg0[5]
	}
    )
	local L_1309_ = L_14_func(
        L_13_.fn_093_delayedAnimation,
        L_1236_arg1,
        {
		L_1307_,
		{
			L_1299_
		},
		L_1235_arg0[5],
		{
			L_1266_
		}
	}
    )
	L_1293_.Activated:Connect(L_14_func(
        L_13_.fn_094,
        L_1236_arg1,
        {
		{
			L_1289_
		},
		{
			L_1308_
		}
	}
    ))
	L_1299_.Activated:Connect(L_1309_)
	local L_1310_ = {
		Current = nil,
		MainContainer = L_1286_,
	}
	L_1310_.CreateTab = L_14_func(
        L_13_.fn_125_CreateTab,
        L_1236_arg1,
        {
		{
			L_1277_
		},
		L_1235_arg0[7],
		L_1235_arg0[5],
		{
			L_1310_
		},
		{
			L_1294_
		},
		{
			L_1297_
		},
		L_1235_arg0[9],
	}
    )
	return L_1310_
end

L_13_.fn_127_snowyUiLibrary = function(L_1319_arg0, L_1320_arg1, ...)
	local L_1321_ = L_1_(...)
	local L_1322_ = L_1321_.n
	local L_1323_ = {}
	local L_1324_ = {}
	local L_1325_ = 14
	local L_1326_ = 14
	for L_1333_forvar0 = 0, L_1326_ - 1 do
		L_1323_[L_1333_forvar0] = L_1321_[L_1333_forvar0 + 1]
	end
	local L_1327_ = {
		n = math.max(0, L_1322_ - L_1326_)
	}
	for L_1334_forvar0 = 1, L_1327_.n do
		L_1327_[L_1334_forvar0] = L_1321_[L_1326_ + L_1334_forvar0]
	end
	local L_1328_ = L_1322_
	local function L_1329_func(L_1335_arg0)
		local L_1336_ = L_1324_[L_1335_arg0]
		if L_1336_ ~= nil then
			return L_1336_[1]
		end
		return L_1323_[L_1335_arg0]
	end
	local function L_1330_func(L_1337_arg0, L_1338_arg1)
		local L_1339_ = L_1324_[L_1337_arg0]
		if L_1339_ ~= nil then
			L_1339_[1] = L_1338_arg1
		else
			L_1323_[L_1337_arg0] = L_1338_arg1
		end
	end
	local function L_1331_func(L_1340_arg0)
		local L_1341_ = L_1324_[L_1340_arg0]
		if L_1341_ == nil then
			L_1341_ = {
				L_1323_[L_1340_arg0]
			};
			L_1324_[L_1340_arg0] = L_1341_
		end
		return L_1341_
	end
	local function L_1332_func(L_1342_arg0, L_1343_arg1)
		local L_1344_ = {
			n = L_1343_arg1
		}
		for L_1345_forvar0 = 1, L_1343_arg1 do
			L_1344_[L_1345_forvar0] = L_1329_func(L_1342_arg0 + L_1345_forvar0 - 1)
		end
		return L_1344_
	end

	L_1330_func(0, L_10_func(L_1320_arg1, "game"))
	L_1330_func(2, "UserInputService")
	do
		local L_1346_ = L_1329_func(0)
		L_1330_func(1, L_1346_)
		L_1330_func(0, L_1346_["GetService"])
	end
	do
		local L_1347_ = 2
		local L_1348_ = L_1332_func(1, L_1347_)
		local L_1349_ = L_1_(L_1329_func(0)(L_2_(L_1348_, 1, L_1348_.n)))
		for L_1350_forvar0 = 1, 1 do
			L_1330_func(0 + L_1350_forvar0 - 1, L_1349_[L_1350_forvar0])
		end
	end
	L_1330_func(1, L_10_func(L_1320_arg1, "game"))
	L_1330_func(3, "TweenService")
	do
		local L_1351_ = L_1329_func(1)
		L_1330_func(2, L_1351_)
		L_1330_func(1, L_1351_["GetService"])
	end
	do
		local L_1352_ = 2
		local L_1353_ = L_1332_func(2, L_1352_)
		local L_1354_ = L_1_(L_1329_func(1)(L_2_(L_1353_, 1, L_1353_.n)))
		for L_1355_forvar0 = 1, 1 do
			L_1330_func(1 + L_1355_forvar0 - 1, L_1354_[L_1355_forvar0])
		end
	end
	L_1330_func(2, L_10_func(L_1320_arg1, "game"))
	L_1330_func(4, "RunService")
	do
		local L_1356_ = L_1329_func(2)
		L_1330_func(3, L_1356_)
		L_1330_func(2, L_1356_["GetService"])
	end
	do
		local L_1357_ = 2
		local L_1358_ = L_1332_func(3, L_1357_)
		local L_1359_ = L_1_(L_1329_func(2)(L_2_(L_1358_, 1, L_1358_.n)))
		for L_1360_forvar0 = 1, 1 do
			L_1330_func(2 + L_1360_forvar0 - 1, L_1359_[L_1360_forvar0])
		end
	end
	L_1330_func(3, L_10_func(L_1320_arg1, "game"))
	L_1330_func(5, "CoreGui")
	do
		local L_1361_ = L_1329_func(3)
		L_1330_func(4, L_1361_)
		L_1330_func(3, L_1361_["GetService"])
	end
	do
		local L_1362_ = 2
		local L_1363_ = L_1332_func(4, L_1362_)
		local L_1364_ = L_1_(L_1329_func(3)(L_2_(L_1363_, 1, L_1363_.n)))
		for L_1365_forvar0 = 1, 1 do
			L_1330_func(3 + L_1365_forvar0 - 1, L_1364_[L_1365_forvar0])
		end
	end
	L_1330_func(4, L_10_func(L_1320_arg1, "game"))
	L_1330_func(6, "Players")
	do
		local L_1366_ = L_1329_func(4)
		L_1330_func(5, L_1366_)
		L_1330_func(4, L_1366_["GetService"])
	end
	do
		local L_1367_ = 2
		local L_1368_ = L_1332_func(5, L_1367_)
		local L_1369_ = L_1_(L_1329_func(4)(L_2_(L_1368_, 1, L_1368_.n)))
		for L_1370_forvar0 = 1, 1 do
			L_1330_func(4 + L_1370_forvar0 - 1, L_1369_[L_1370_forvar0])
		end
	end
	L_1330_func(5, L_1329_func(4)["LocalPlayer"])
	L_1330_func(6, {})
	L_1330_func(7, true)
	L_1329_func(6)["Toggled"] = L_1329_func(7)
	L_1330_func(7, L_10_func(L_1320_arg1, "Color3"))
	L_1330_func(7, L_1329_func(7)["fromRGB"])
	L_1330_func(8, 0)
	L_1330_func(9, 162)
	L_1330_func(10, 255)
	do
		local L_1371_ = 3
		local L_1372_ = L_1332_func(8, L_1371_)
		local L_1373_ = L_1_(L_1329_func(7)(L_2_(L_1372_, 1, L_1372_.n)))
		for L_1374_forvar0 = 1, 1 do
			L_1330_func(7 + L_1374_forvar0 - 1, L_1373_[L_1374_forvar0])
		end
	end
	L_1329_func(6)["Accent"] = L_1329_func(7)
	L_1330_func(7, false)
	L_1329_func(6)["_blockDrag"] = L_1329_func(7)
	L_1330_func(7, {})
	L_1330_func(8, {})
	L_1330_func(9, 16898613509)
	L_1330_func(10, 48)
	L_1330_func(11, 48)
	L_1330_func(12, 820)
	L_1330_func(13, 147)
	do
		local L_1375_ = 5
		local L_1376_ = L_1329_func(8)
		for L_1377_forvar0 = 0, L_1375_ - 1 do
			L_1376_[1 + L_1377_forvar0] = L_1329_func(9 + L_1377_forvar0)
		end
	end
	L_1329_func(7)["home"] = L_1329_func(8)
	L_1330_func(8, {})
	L_1330_func(9, 16898613353)
	L_1330_func(10, 48)
	L_1330_func(11, 48)
	L_1330_func(12, 967)
	L_1330_func(13, 306)
	do
		local L_1378_ = 5
		local L_1379_ = L_1329_func(8)
		for L_1380_forvar0 = 0, L_1378_ - 1 do
			L_1379_[1 + L_1380_forvar0] = L_1329_func(9 + L_1380_forvar0)
		end
	end
	L_1329_func(7)["flame"] = L_1329_func(8)
	L_1330_func(8, {})
	L_1330_func(9, 16898613777)
	L_1330_func(10, 48)
	L_1330_func(11, 48)
	L_1330_func(12, 771)
	L_1330_func(13, 257)
	do
		local L_1381_ = 5
		local L_1382_ = L_1329_func(8)
		for L_1383_forvar0 = 0, L_1381_ - 1 do
			L_1382_[1 + L_1383_forvar0] = L_1329_func(9 + L_1383_forvar0)
		end
	end
	L_1329_func(7)["settings"] = L_1329_func(8)
	L_1330_func(8, {})
	L_1330_func(9, 16898613869)
	L_1330_func(10, 48)
	L_1330_func(11, 48)
	L_1330_func(12, 661)
	L_1330_func(13, 869)
	do
		local L_1384_ = 5
		local L_1385_ = L_1329_func(8)
		for L_1386_forvar0 = 0, L_1384_ - 1 do
			L_1385_[1 + L_1386_forvar0] = L_1329_func(9 + L_1386_forvar0)
		end
	end
	L_1329_func(7)["account"] = L_1329_func(8)
	L_1330_func(8, {})
	L_1330_func(9, 16898613353)
	L_1330_func(10, 48)
	L_1330_func(11, 48)
	L_1330_func(12, 771)
	L_1330_func(13, 563)
	do
		local L_1387_ = 5
		local L_1388_ = L_1329_func(8)
		for L_1389_forvar0 = 0, L_1387_ - 1 do
			L_1388_[1 + L_1389_forvar0] = L_1329_func(9 + L_1389_forvar0)
		end
	end
	L_1329_func(7)["eye"] = L_1329_func(8)
	L_1330_func(8, {})
	L_1330_func(9, 16898613613)
	L_1330_func(10, 48)
	L_1330_func(11, 48)
	L_1330_func(12, 820)
	L_1330_func(13, 257)
	do
		local L_1390_ = 5
		local L_1391_ = L_1329_func(8)
		for L_1392_forvar0 = 0, L_1390_ - 1 do
			L_1391_[1 + L_1392_forvar0] = L_1329_func(9 + L_1392_forvar0)
		end
	end
	L_1329_func(7)["map-pin"] = L_1329_func(8)
	L_1330_func(8, {})
	L_1330_func(9, 16898612629)
	L_1330_func(10, 48)
	L_1330_func(11, 48)
	L_1330_func(12, 967)
	L_1330_func(13, 710)
	do
		local L_1393_ = 5
		local L_1394_ = L_1329_func(8)
		for L_1395_forvar0 = 0, L_1393_ - 1 do
			L_1394_[1 + L_1395_forvar0] = L_1329_func(9 + L_1395_forvar0)
		end
	end
	L_1329_func(7)["bar-chart-2"] = L_1329_func(8)
	L_1330_func(8, {})
	L_1330_func(9, 16898613777)
	L_1330_func(10, 48)
	L_1330_func(11, 48)
	L_1330_func(12, 967)
	L_1330_func(13, 759)
	do
		local L_1396_ = 5
		local L_1397_ = L_1329_func(8)
		for L_1398_forvar0 = 0, L_1396_ - 1 do
			L_1397_[1 + L_1398_forvar0] = L_1329_func(9 + L_1398_forvar0)
		end
	end
	L_1329_func(7)["swords"] = L_1329_func(8)
	L_1330_func(8, {})
	L_1330_func(9, 16898613869)
	L_1330_func(10, 48)
	L_1330_func(11, 48)
	L_1330_func(12, 661)
	L_1330_func(13, 869)
	do
		local L_1399_ = 5
		local L_1400_ = L_1329_func(8)
		for L_1401_forvar0 = 0, L_1399_ - 1 do
			L_1400_[1 + L_1401_forvar0] = L_1329_func(9 + L_1401_forvar0)
		end
	end
	L_1329_func(7)["user"] = L_1329_func(8)
	L_1330_func(8, {})
	L_1330_func(9, 16898613777)
	L_1330_func(10, 48)
	L_1330_func(11, 48)
	L_1330_func(12, 869)
	L_1330_func(13, 0)
	do
		local L_1402_ = 5
		local L_1403_ = L_1329_func(8)
		for L_1404_forvar0 = 0, L_1402_ - 1 do
			L_1403_[1 + L_1404_forvar0] = L_1329_func(9 + L_1404_forvar0)
		end
	end
	L_1329_func(7)["shield"] = L_1329_func(8)
	L_1330_func(8, {})
	L_1330_func(9, 16898613869)
	L_1330_func(10, 48)
	L_1330_func(11, 48)
	L_1330_func(12, 918)
	L_1330_func(13, 906)
	do
		local L_1405_ = 5
		local L_1406_ = L_1329_func(8)
		for L_1407_forvar0 = 0, L_1405_ - 1 do
			L_1406_[1 + L_1407_forvar0] = L_1329_func(9 + L_1407_forvar0)
		end
	end
	L_1329_func(7)["zap"] = L_1329_func(8)
	L_1330_func(8, {})
	L_1330_func(9, 16898613869)
	L_1330_func(10, 48)
	L_1330_func(11, 48)
	L_1330_func(12, 514)
	L_1330_func(13, 771)
	do
		local L_1408_ = 5
		local L_1409_ = L_1329_func(8)
		for L_1410_forvar0 = 0, L_1408_ - 1 do
			L_1409_[1 + L_1410_forvar0] = L_1329_func(9 + L_1410_forvar0)
		end
	end
	L_1329_func(7)["target"] = L_1329_func(8)
	L_1330_func(8, {})
	L_1330_func(9, 16898613509)
	L_1330_func(10, 48)
	L_1330_func(11, 48)
	L_1330_func(12, 771)
	L_1330_func(13, 563)
	do
		local L_1411_ = 5
		local L_1412_ = L_1329_func(8)
		for L_1413_forvar0 = 0, L_1411_ - 1 do
			L_1412_[1 + L_1413_forvar0] = L_1329_func(9 + L_1413_forvar0)
		end
	end
	L_1329_func(7)["globe"] = L_1329_func(8)
	L_1330_func(8, {})
	L_1330_func(9, 16898613509)
	L_1330_func(10, 48)
	L_1330_func(11, 48)
	L_1330_func(12, 967)
	L_1330_func(13, 612)
	do
		local L_1414_ = 5
		local L_1415_ = L_1329_func(8)
		for L_1416_forvar0 = 0, L_1414_ - 1 do
			L_1415_[1 + L_1416_forvar0] = L_1329_func(9 + L_1416_forvar0)
		end
	end
	L_1329_func(7)["layout"] = L_1329_func(8)
	L_1330_func(8, {})
	L_1330_func(9, 16898613699)
	L_1330_func(10, 48)
	L_1330_func(11, 48)
	L_1330_func(12, 918)
	L_1330_func(13, 857)
	do
		local L_1417_ = 5
		local L_1418_ = L_1329_func(8)
		for L_1419_forvar0 = 0, L_1417_ - 1 do
			L_1418_[1 + L_1419_forvar0] = L_1329_func(9 + L_1419_forvar0)
		end
	end
	L_1329_func(7)["search"] = L_1329_func(8)
	L_1330_func(8, {})
	L_1330_func(9, 16898613699)
	L_1330_func(10, 48)
	L_1330_func(11, 48)
	L_1330_func(12, 918)
	L_1330_func(13, 453)
	do
		local L_1420_ = 5
		local L_1421_ = L_1329_func(8)
		for L_1422_forvar0 = 0, L_1420_ - 1 do
			L_1421_[1 + L_1422_forvar0] = L_1329_func(9 + L_1422_forvar0)
		end
	end
	L_1329_func(7)["save"] = L_1329_func(8)
	L_1330_func(8, {})
	L_1330_func(9, 16898613777)
	L_1330_func(10, 48)
	L_1330_func(11, 48)
	L_1330_func(12, 404)
	L_1330_func(13, 771)
	do
		local L_1423_ = 5
		local L_1424_ = L_1329_func(8)
		for L_1425_forvar0 = 0, L_1423_ - 1 do
			L_1424_[1 + L_1425_forvar0] = L_1329_func(9 + L_1425_forvar0)
		end
	end
	L_1329_func(7)["sliders"] = L_1329_func(8)
	do
		local L_1426_ = {}
		local L_1427_ = {
			L_1320_arg1 and L_1320_arg1[1] or nil
		}
		local L_1428_
		L_1428_ = function(...)
			return L_13_.fn_065_iterateNext(L_1426_, L_1427_, ...)
		end
		L_6_[L_1428_] = L_1427_
		L_1330_func(8, L_1428_)
	end
	do
		local L_1429_ = {}
		L_1429_[1] = {
			L_1329_func(1)
		}
		local L_1430_ = {
			L_1320_arg1 and L_1320_arg1[1] or nil
		}
		local L_1431_
		L_1431_ = function(...)
			return L_13_.fn_066_playTween(L_1429_, L_1430_, ...)
		end
		L_6_[L_1431_] = L_1430_
		L_1330_func(9, L_1431_)
	end
	do
		local L_1432_ = {}
		L_1432_[1] = {
			L_1329_func(6)
		}
		L_1432_[2] = {
			L_1329_func(0)
		}
		local L_1433_ = {
			L_1320_arg1 and L_1320_arg1[1] or nil
		}
		local L_1434_
		L_1434_ = function(...)
			return L_13_.fn_071_MakeDraggable(L_1432_, L_1433_, ...)
		end
		L_6_[L_1434_] = L_1433_
		L_1330_func(10, L_1434_)
	end
	L_1329_func(6)["MakeDraggable"] = L_1329_func(10)
	do
		local L_1435_ = {}
		L_1435_[1] = {
			L_1329_func(7)
		}
		local L_1436_ = {
			L_1320_arg1 and L_1320_arg1[1] or nil
		}
		local L_1437_
		L_1437_ = function(...)
			return L_13_.fn_072_GetIcon(L_1435_, L_1436_, ...)
		end
		L_6_[L_1437_] = L_1436_
		L_1330_func(10, L_1437_)
	end
	L_1329_func(6)["GetIcon"] = L_1329_func(10)
	do
		local L_1438_ = {}
		L_1438_[1] = {
			L_1329_func(2)
		}
		L_1438_[2] = {
			L_1329_func(3)
		}
		L_1438_[3] = {
			L_1329_func(5)
		}
		L_1438_[4] = L_1319_arg0[1]
		L_1438_[5] = {
			L_1329_func(1)
		}
		L_1438_[6] = {
			L_1329_func(4)
		}
		L_1438_[7] = {
			L_1329_func(6)
		}
		L_1438_[8] = L_1319_arg0[2]
		L_1438_[9] = {
			L_1329_func(0)
		}
		local L_1439_ = {
			L_1320_arg1 and L_1320_arg1[1] or nil
		}
		local L_1440_
		L_1440_ = function(...)
			return L_13_.fn_126_CreateWindow(L_1438_, L_1439_, ...)
		end
		L_6_[L_1440_] = L_1439_
		L_1330_func(10, L_1440_)
	end
	L_1329_func(6)["CreateWindow"] = L_1329_func(10)
	do
		local L_1441_ = L_1332_func(6, 1);
		return L_2_(L_1441_, 1, L_1441_.n)
	end
end

L_13_.fn_128_normalizeOptions = function(L_1442_arg0, L_1443_arg1, L_1444_arg2, L_1445_arg3, L_1446_arg4, L_1447_arg5, L_1448_arg6, L_1449_arg7, L_1450_arg8, L_1451_arg9, L_1452_arg10, L_1453_arg11, L_1454_arg12)
	L_1447_arg5 = nil
	L_1448_arg6 = nil
	L_1449_arg7 = nil
	L_1451_arg9 = L_1444_arg2
	L_1450_arg8 = L_10_func(L_1443_arg1, "type")
	L_1450_arg8 = L_1450_arg8(L_1451_arg9)
	L_1453_arg11 = "table"
	L_1454_arg12 = (L_1450_arg8 == L_1453_arg11)
	if not L_1454_arg12 then
		L_1447_arg5 = L_1445_arg3
		L_1448_arg6 = nil
		L_1449_arg7 = L_1446_arg4
	else
		L_1447_arg5 = L_1444_arg2
		L_1452_arg10 = L_1445_arg3
		L_1451_arg9 = L_10_func(L_1443_arg1, "type")
		L_1451_arg9 = L_1451_arg9(L_1452_arg10)
		L_1453_arg11 = "string"
		L_1454_arg12 = (L_1451_arg9 == L_1453_arg11)
		if L_1454_arg12 then
			L_1450_arg8 = L_1445_arg3
			if not L_1450_arg8 then
				L_1450_arg8 = nil
			end
			L_1448_arg6 = L_1450_arg8
			L_1452_arg10 = L_1445_arg3
			L_1451_arg9 = L_10_func(L_1443_arg1, "type")
			L_1451_arg9 = L_1451_arg9(L_1452_arg10)
			L_1453_arg11 = "function"
			L_1454_arg12 = (L_1451_arg9 == L_1453_arg11)
			if L_1454_arg12 then
				L_1450_arg8 = L_1445_arg3
				if not L_1450_arg8 then
					L_1450_arg8 = L_1446_arg4
				end
				L_1449_arg7 = L_1450_arg8
				L_1450_arg8 = L_1447_arg5
				if not L_1450_arg8 then
					L_1450_arg8 = {}
				end
				L_1451_arg9 = L_1448_arg6
				L_1452_arg10 = L_1449_arg7
				return L_1450_arg8, L_1451_arg9, L_1452_arg10
			end
			L_1450_arg8 = L_1446_arg4
			L_1449_arg7 = L_1450_arg8
			L_1450_arg8 = L_1447_arg5
			if not L_1450_arg8 then
				L_1450_arg8 = {}
			end
			L_1451_arg9 = L_1448_arg6
			L_1452_arg10 = L_1449_arg7
			return L_1450_arg8, L_1451_arg9, L_1452_arg10
		end
		L_1450_arg8 = nil
		L_1448_arg6 = L_1450_arg8
		L_1452_arg10 = L_1445_arg3
		L_1451_arg9 = L_10_func(L_1443_arg1, "type")
		L_1451_arg9 = L_1451_arg9(L_1452_arg10)
		L_1453_arg11 = "function"
		L_1454_arg12 = (L_1451_arg9 == L_1453_arg11)
		if L_1454_arg12 then
			L_1450_arg8 = L_1445_arg3
			if not L_1450_arg8 then
				L_1450_arg8 = L_1446_arg4
			end
			L_1449_arg7 = L_1450_arg8
			L_1450_arg8 = L_1447_arg5
			if not L_1450_arg8 then
				L_1450_arg8 = {}
			end
			L_1451_arg9 = L_1448_arg6
			L_1452_arg10 = L_1449_arg7
			return L_1450_arg8, L_1451_arg9, L_1452_arg10
		end
		L_1450_arg8 = L_1446_arg4
		L_1449_arg7 = L_1450_arg8
	end
	L_1450_arg8 = L_1447_arg5
	if not L_1450_arg8 then
		L_1450_arg8 = {}
	end
	L_1451_arg9 = L_1448_arg6
	L_1452_arg10 = L_1449_arg7
	return L_1450_arg8, L_1451_arg9, L_1452_arg10
end

L_13_.fn_129_NewToggle = function(L_1455_arg0, L_1456_arg1, ...)
	local L_1457_ = L_1_(...)
	local L_1458_ = L_1457_.n
	local L_1459_ = {}
	local L_1460_ = {}
	local L_1461_ = 8
	local L_1462_ = 9
	for L_1469_forvar0 = 0, L_1462_ - 1 do
		L_1459_[L_1469_forvar0] = L_1457_[L_1469_forvar0 + 1]
	end
	local L_1463_ = {
		n = math.max(0, L_1458_ - L_1462_)
	}
	for L_1470_forvar0 = 1, L_1463_.n do
		L_1463_[L_1470_forvar0] = L_1457_[L_1462_ + L_1470_forvar0]
	end
	local L_1464_ = L_1458_
	local function L_1465_func(L_1471_arg0)
		local L_1472_ = L_1460_[L_1471_arg0]
		if L_1472_ ~= nil then
			return L_1472_[1]
		end
		return L_1459_[L_1471_arg0]
	end
	local function L_1466_func(L_1473_arg0, L_1474_arg1)
		local L_1475_ = L_1460_[L_1473_arg0]
		if L_1475_ ~= nil then
			L_1475_[1] = L_1474_arg1
		else
			L_1459_[L_1473_arg0] = L_1474_arg1
		end
	end
	local function L_1467_func(L_1476_arg0)
		local L_1477_ = L_1460_[L_1476_arg0]
		if L_1477_ == nil then
			L_1477_ = {
				L_1459_[L_1476_arg0]
			};
			L_1460_[L_1476_arg0] = L_1477_
		end
		return L_1477_
	end
	local function L_1468_func(L_1478_arg0, L_1479_arg1)
		local L_1480_ = {
			n = L_1479_arg1
		}
		for L_1481_forvar0 = 1, L_1479_arg1 do
			L_1480_[L_1481_forvar0] = L_1465_func(L_1478_arg0 + L_1481_forvar0 - 1)
		end
		return L_1480_
	end

	L_1466_func(4, L_1455_arg0[1][1])
	L_1466_func(6, L_1465_func(1))
	L_1466_func(7, false)
	L_1466_func(8, L_1465_func(3))
	do
		local L_1482_ = L_1465_func(4)
		L_1466_func(5, L_1482_)
		L_1466_func(4, L_1482_["CreateToggle"])
	end
	do
		local L_1483_ = 4
		local L_1484_ = L_1468_func(5, L_1483_)
		local L_1485_ = L_1_(L_1465_func(4)(L_2_(L_1484_, 1, L_1484_.n)))
		for L_1486_forvar0 = 1, L_1485_.n do
			L_1466_func(4 + L_1486_forvar0 - 1, L_1485_[L_1486_forvar0])
		end
		L_1464_ = 4 + L_1485_.n
	end
	do
		local L_1487_ = L_1464_ - 4
		if L_1487_ <= 0 then
			return
		end
		local L_1488_ = L_1468_func(4, L_1487_)
		return L_2_(L_1488_, 1, L_1488_.n)
	end
end

L_13_.fn_130_NewSlider = function(L_1489_arg0, L_1490_arg1, ...)
	local L_1491_ = L_1_(...)
	local L_1492_ = L_1491_.n
	local L_1493_ = {}
	local L_1494_ = {}
	local L_1495_ = 12
	local L_1496_ = 13
	for L_1503_forvar0 = 0, L_1496_ - 1 do
		L_1493_[L_1503_forvar0] = L_1491_[L_1503_forvar0 + 1]
	end
	local L_1497_ = {
		n = math.max(0, L_1492_ - L_1496_)
	}
	for L_1504_forvar0 = 1, L_1497_.n do
		L_1497_[L_1504_forvar0] = L_1491_[L_1496_ + L_1504_forvar0]
	end
	local L_1498_ = L_1492_
	local function L_1499_func(L_1505_arg0)
		local L_1506_ = L_1494_[L_1505_arg0]
		if L_1506_ ~= nil then
			return L_1506_[1]
		end
		return L_1493_[L_1505_arg0]
	end
	local function L_1500_func(L_1507_arg0, L_1508_arg1)
		local L_1509_ = L_1494_[L_1507_arg0]
		if L_1509_ ~= nil then
			L_1509_[1] = L_1508_arg1
		else
			L_1493_[L_1507_arg0] = L_1508_arg1
		end
	end
	local function L_1501_func(L_1510_arg0)
		local L_1511_ = L_1494_[L_1510_arg0]
		if L_1511_ == nil then
			L_1511_ = {
				L_1493_[L_1510_arg0]
			};
			L_1494_[L_1510_arg0] = L_1511_
		end
		return L_1511_
	end
	local function L_1502_func(L_1512_arg0, L_1513_arg1)
		local L_1514_ = {
			n = L_1513_arg1
		}
		for L_1515_forvar0 = 1, L_1513_arg1 do
			L_1514_[L_1515_forvar0] = L_1499_func(L_1512_arg0 + L_1515_forvar0 - 1)
		end
		return L_1514_
	end

	L_1500_func(6, L_1489_arg0[1][1])
	L_1500_func(8, L_1499_func(1))
	L_1500_func(9, L_1499_func(4))
	L_1500_func(10, L_1499_func(3))
	L_1500_func(11, L_1499_func(4))
	L_1500_func(12, L_1499_func(5))
	do
		local L_1516_ = L_1499_func(6)
		L_1500_func(7, L_1516_)
		L_1500_func(6, L_1516_["CreateSlider"])
	end
	do
		local L_1517_ = 6
		local L_1518_ = L_1502_func(7, L_1517_)
		local L_1519_ = L_1_(L_1499_func(6)(L_2_(L_1518_, 1, L_1518_.n)))
		for L_1520_forvar0 = 1, L_1519_.n do
			L_1500_func(6 + L_1520_forvar0 - 1, L_1519_[L_1520_forvar0])
		end
		L_1498_ = 6 + L_1519_.n
	end
	do
		local L_1521_ = L_1498_ - 6
		if L_1521_ <= 0 then
			return
		end
		local L_1522_ = L_1502_func(6, L_1521_)
		return L_2_(L_1522_, 1, L_1522_.n)
	end
end

L_13_.fn_131_NewButton = function(L_1523_arg0, L_1524_arg1, ...)
	local L_1525_ = L_1_(...)
	local L_1526_ = L_1525_.n
	local L_1527_ = {}
	local L_1528_ = {}
	local L_1529_ = 7
	local L_1530_ = 8
	for L_1537_forvar0 = 0, L_1530_ - 1 do
		L_1527_[L_1537_forvar0] = L_1525_[L_1537_forvar0 + 1]
	end
	local L_1531_ = {
		n = math.max(0, L_1526_ - L_1530_)
	}
	for L_1538_forvar0 = 1, L_1531_.n do
		L_1531_[L_1538_forvar0] = L_1525_[L_1530_ + L_1538_forvar0]
	end
	local L_1532_ = L_1526_
	local function L_1533_func(L_1539_arg0)
		local L_1540_ = L_1528_[L_1539_arg0]
		if L_1540_ ~= nil then
			return L_1540_[1]
		end
		return L_1527_[L_1539_arg0]
	end
	local function L_1534_func(L_1541_arg0, L_1542_arg1)
		local L_1543_ = L_1528_[L_1541_arg0]
		if L_1543_ ~= nil then
			L_1543_[1] = L_1542_arg1
		else
			L_1527_[L_1541_arg0] = L_1542_arg1
		end
	end
	local function L_1535_func(L_1544_arg0)
		local L_1545_ = L_1528_[L_1544_arg0]
		if L_1545_ == nil then
			L_1545_ = {
				L_1527_[L_1544_arg0]
			};
			L_1528_[L_1544_arg0] = L_1545_
		end
		return L_1545_
	end
	local function L_1536_func(L_1546_arg0, L_1547_arg1)
		local L_1548_ = {
			n = L_1547_arg1
		}
		for L_1549_forvar0 = 1, L_1547_arg1 do
			L_1548_[L_1549_forvar0] = L_1533_func(L_1546_arg0 + L_1549_forvar0 - 1)
		end
		return L_1548_
	end

	L_1534_func(4, L_1523_arg0[1][1])
	L_1534_func(6, L_1533_func(1))
	L_1534_func(7, L_1533_func(3))
	do
		local L_1550_ = L_1533_func(4)
		L_1534_func(5, L_1550_)
		L_1534_func(4, L_1550_["CreateButton"])
	end
	do
		local L_1551_ = 3
		local L_1552_ = L_1536_func(5, L_1551_)
		local L_1553_ = L_1_(L_1533_func(4)(L_2_(L_1552_, 1, L_1552_.n)))
		for L_1554_forvar0 = 1, L_1553_.n do
			L_1534_func(4 + L_1554_forvar0 - 1, L_1553_[L_1554_forvar0])
		end
		L_1532_ = 4 + L_1553_.n
	end
	do
		local L_1555_ = L_1532_ - 4
		if L_1555_ <= 0 then
			return
		end
		local L_1556_ = L_1536_func(4, L_1555_)
		return L_2_(L_1556_, 1, L_1556_.n)
	end
end

L_13_.fn_132_NewDropdown = function(L_1557_arg0, L_1558_arg1, ...)
	local L_1559_ = L_1_(...)
	local L_1560_ = L_1559_.n
	local L_1561_ = {}
	local L_1562_ = {}
	local L_1563_ = 13
	local L_1564_ = 14
	for L_1571_forvar0 = 0, L_1564_ - 1 do
		L_1561_[L_1571_forvar0] = L_1559_[L_1571_forvar0 + 1]
	end
	local L_1565_ = {
		n = math.max(0, L_1560_ - L_1564_)
	}
	for L_1572_forvar0 = 1, L_1565_.n do
		L_1565_[L_1572_forvar0] = L_1559_[L_1564_ + L_1572_forvar0]
	end
	local L_1566_ = L_1560_
	local function L_1567_func(L_1573_arg0)
		local L_1574_ = L_1562_[L_1573_arg0]
		if L_1574_ ~= nil then
			return L_1574_[1]
		end
		return L_1561_[L_1573_arg0]
	end
	local function L_1568_func(L_1575_arg0, L_1576_arg1)
		local L_1577_ = L_1562_[L_1575_arg0]
		if L_1577_ ~= nil then
			L_1577_[1] = L_1576_arg1
		else
			L_1561_[L_1575_arg0] = L_1576_arg1
		end
	end
	local function L_1569_func(L_1578_arg0)
		local L_1579_ = L_1562_[L_1578_arg0]
		if L_1579_ == nil then
			L_1579_ = {
				L_1561_[L_1578_arg0]
			};
			L_1562_[L_1578_arg0] = L_1579_
		end
		return L_1579_
	end
	local function L_1570_func(L_1580_arg0, L_1581_arg1)
		local L_1582_ = {
			n = L_1581_arg1
		}
		for L_1583_forvar0 = 1, L_1581_arg1 do
			L_1582_[L_1583_forvar0] = L_1567_func(L_1580_arg0 + L_1583_forvar0 - 1)
		end
		return L_1582_
	end

	L_1568_func(5, L_1557_arg0[1][1])
	L_1568_func(6, L_1567_func(2))
	L_1568_func(7, L_1567_func(3))
	L_1568_func(8, L_1567_func(4))
	do
		local L_1584_ = 3
		local L_1585_ = L_1570_func(6, L_1584_)
		local L_1586_ = L_1_(L_1567_func(5)(L_2_(L_1585_, 1, L_1585_.n)))
		for L_1587_forvar0 = 1, 3 do
			L_1568_func(5 + L_1587_forvar0 - 1, L_1586_[L_1587_forvar0])
		end
	end
	L_1568_func(8, L_1557_arg0[2][1])
	L_1568_func(10, L_1567_func(1))
	L_1568_func(11, L_1567_func(5))
	L_1568_func(12, L_1567_func(6))
	L_1568_func(13, L_1567_func(7))
	do
		local L_1588_ = L_1567_func(8)
		L_1568_func(9, L_1588_)
		L_1568_func(8, L_1588_["CreateDropdown"])
	end
	do
		local L_1589_ = 5
		local L_1590_ = L_1570_func(9, L_1589_)
		local L_1591_ = L_1_(L_1567_func(8)(L_2_(L_1590_, 1, L_1590_.n)))
		for L_1592_forvar0 = 1, L_1591_.n do
			L_1568_func(8 + L_1592_forvar0 - 1, L_1591_[L_1592_forvar0])
		end
		L_1566_ = 8 + L_1591_.n
	end
	do
		local L_1593_ = L_1566_ - 8
		if L_1593_ <= 0 then
			return
		end
		local L_1594_ = L_1570_func(8, L_1593_)
		return L_2_(L_1594_, 1, L_1594_.n)
	end
end

L_13_.fn_133_NewLabel = function(L_1595_arg0, L_1596_arg1, ...)
	local L_1597_ = L_1_(...)
	local L_1598_ = L_1597_.n
	local L_1599_ = {}
	local L_1600_ = {}
	local L_1601_ = 4
	local L_1602_ = 5
	for L_1609_forvar0 = 0, L_1602_ - 1 do
		L_1599_[L_1609_forvar0] = L_1597_[L_1609_forvar0 + 1]
	end
	local L_1603_ = {
		n = math.max(0, L_1598_ - L_1602_)
	}
	for L_1610_forvar0 = 1, L_1603_.n do
		L_1603_[L_1610_forvar0] = L_1597_[L_1602_ + L_1610_forvar0]
	end
	local L_1604_ = L_1598_
	local function L_1605_func(L_1611_arg0)
		local L_1612_ = L_1600_[L_1611_arg0]
		if L_1612_ ~= nil then
			return L_1612_[1]
		end
		return L_1599_[L_1611_arg0]
	end
	local function L_1606_func(L_1613_arg0, L_1614_arg1)
		local L_1615_ = L_1600_[L_1613_arg0]
		if L_1615_ ~= nil then
			L_1615_[1] = L_1614_arg1
		else
			L_1599_[L_1613_arg0] = L_1614_arg1
		end
	end
	local function L_1607_func(L_1616_arg0)
		local L_1617_ = L_1600_[L_1616_arg0]
		if L_1617_ == nil then
			L_1617_ = {
				L_1599_[L_1616_arg0]
			};
			L_1600_[L_1616_arg0] = L_1617_
		end
		return L_1617_
	end
	local function L_1608_func(L_1618_arg0, L_1619_arg1)
		local L_1620_ = {
			n = L_1619_arg1
		}
		for L_1621_forvar0 = 1, L_1619_arg1 do
			L_1620_[L_1621_forvar0] = L_1605_func(L_1618_arg0 + L_1621_forvar0 - 1)
		end
		return L_1620_
	end

	L_1606_func(2, L_1595_arg0[1][1])
	L_1606_func(4, L_1605_func(1))
	do
		local L_1622_ = L_1605_func(2)
		L_1606_func(3, L_1622_)
		L_1606_func(2, L_1622_["CreateLabel"])
	end
	do
		local L_1623_ = 2
		local L_1624_ = L_1608_func(3, L_1623_)
		local L_1625_ = L_1_(L_1605_func(2)(L_2_(L_1624_, 1, L_1624_.n)))
		for L_1626_forvar0 = 1, L_1625_.n do
			L_1606_func(2 + L_1626_forvar0 - 1, L_1625_[L_1626_forvar0])
		end
		L_1604_ = 2 + L_1625_.n
	end
	do
		local L_1627_ = L_1604_ - 2
		if L_1627_ <= 0 then
			return
		end
		local L_1628_ = L_1608_func(2, L_1627_)
		return L_2_(L_1628_, 1, L_1628_.n)
	end
end

L_13_.fn_134_NewInput = function(L_1629_arg0, L_1630_arg1, ...)
	local L_1631_ = L_1_(...)
	local L_1632_ = L_1631_.n
	local L_1633_ = {}
	local L_1634_ = {}
	local L_1635_ = 8
	local L_1636_ = 9
	for L_1643_forvar0 = 0, L_1636_ - 1 do
		L_1633_[L_1643_forvar0] = L_1631_[L_1643_forvar0 + 1]
	end
	local L_1637_ = {
		n = math.max(0, L_1632_ - L_1636_)
	}
	for L_1644_forvar0 = 1, L_1637_.n do
		L_1637_[L_1644_forvar0] = L_1631_[L_1636_ + L_1644_forvar0]
	end
	local L_1638_ = L_1632_
	local function L_1639_func(L_1645_arg0)
		local L_1646_ = L_1634_[L_1645_arg0]
		if L_1646_ ~= nil then
			return L_1646_[1]
		end
		return L_1633_[L_1645_arg0]
	end
	local function L_1640_func(L_1647_arg0, L_1648_arg1)
		local L_1649_ = L_1634_[L_1647_arg0]
		if L_1649_ ~= nil then
			L_1649_[1] = L_1648_arg1
		else
			L_1633_[L_1647_arg0] = L_1648_arg1
		end
	end
	local function L_1641_func(L_1650_arg0)
		local L_1651_ = L_1634_[L_1650_arg0]
		if L_1651_ == nil then
			L_1651_ = {
				L_1633_[L_1650_arg0]
			};
			L_1634_[L_1650_arg0] = L_1651_
		end
		return L_1651_
	end
	local function L_1642_func(L_1652_arg0, L_1653_arg1)
		local L_1654_ = {
			n = L_1653_arg1
		}
		for L_1655_forvar0 = 1, L_1653_arg1 do
			L_1654_[L_1655_forvar0] = L_1639_func(L_1652_arg0 + L_1655_forvar0 - 1)
		end
		return L_1654_
	end

	L_1640_func(4, L_1629_arg0[1][1])
	L_1640_func(6, L_1639_func(1))
	L_1640_func(7, L_1639_func(2))
	L_1640_func(8, L_1639_func(3))
	do
		local L_1656_ = L_1639_func(4)
		L_1640_func(5, L_1656_)
		L_1640_func(4, L_1656_["CreateInput"])
	end
	do
		local L_1657_ = 4
		local L_1658_ = L_1642_func(5, L_1657_)
		local L_1659_ = L_1_(L_1639_func(4)(L_2_(L_1658_, 1, L_1658_.n)))
		for L_1660_forvar0 = 1, L_1659_.n do
			L_1640_func(4 + L_1660_forvar0 - 1, L_1659_[L_1660_forvar0])
		end
		L_1638_ = 4 + L_1659_.n
	end
	do
		local L_1661_ = L_1638_ - 4
		if L_1661_ <= 0 then
			return
		end
		local L_1662_ = L_1642_func(4, L_1661_)
		return L_2_(L_1662_, 1, L_1662_.n)
	end
end

L_13_.fn_135_NewTitle = function(L_1663_arg0, L_1664_arg1, ...)
	local L_1665_ = L_1_(...)
	local L_1666_ = L_1665_.n
	local L_1667_ = {}
	local L_1668_ = {}
	local L_1669_ = 6
	local L_1670_ = 7
	for L_1677_forvar0 = 0, L_1670_ - 1 do
		L_1667_[L_1677_forvar0] = L_1665_[L_1677_forvar0 + 1]
	end
	local L_1671_ = {
		n = math.max(0, L_1666_ - L_1670_)
	}
	for L_1678_forvar0 = 1, L_1671_.n do
		L_1671_[L_1678_forvar0] = L_1665_[L_1670_ + L_1678_forvar0]
	end
	local L_1672_ = L_1666_
	local function L_1673_func(L_1679_arg0)
		local L_1680_ = L_1668_[L_1679_arg0]
		if L_1680_ ~= nil then
			return L_1680_[1]
		end
		return L_1667_[L_1679_arg0]
	end
	local function L_1674_func(L_1681_arg0, L_1682_arg1)
		local L_1683_ = L_1668_[L_1681_arg0]
		if L_1683_ ~= nil then
			L_1683_[1] = L_1682_arg1
		else
			L_1667_[L_1681_arg0] = L_1682_arg1
		end
	end
	local function L_1675_func(L_1684_arg0)
		local L_1685_ = L_1668_[L_1684_arg0]
		if L_1685_ == nil then
			L_1685_ = {
				L_1667_[L_1684_arg0]
			};
			L_1668_[L_1684_arg0] = L_1685_
		end
		return L_1685_
	end
	local function L_1676_func(L_1686_arg0, L_1687_arg1)
		local L_1688_ = {
			n = L_1687_arg1
		}
		for L_1689_forvar0 = 1, L_1687_arg1 do
			L_1688_[L_1689_forvar0] = L_1673_func(L_1686_arg0 + L_1689_forvar0 - 1)
		end
		return L_1688_
	end

	L_1674_func(2, L_1663_arg0[1][1])
	L_1674_func(5, "\226\156\166 ")
	L_1674_func(6, L_1673_func(1))
	do
		local L_1690_ = L_1673_func(6)
		for L_1691_forvar0 = 5, 5, -1 do
			L_1690_ = L_1673_func(L_1691_forvar0) .. L_1690_
		end
		L_1674_func(4, L_1690_)
	end
	do
		local L_1692_ = L_1673_func(2)
		L_1674_func(3, L_1692_)
		L_1674_func(2, L_1692_["CreateLabel"])
	end
	do
		local L_1693_ = 2
		local L_1694_ = L_1676_func(3, L_1693_)
		local L_1695_ = L_1_(L_1673_func(2)(L_2_(L_1694_, 1, L_1694_.n)))
		for L_1696_forvar0 = 1, L_1695_.n do
			L_1674_func(2 + L_1696_forvar0 - 1, L_1695_[L_1696_forvar0])
		end
		L_1672_ = 2 + L_1695_.n
	end
	do
		local L_1697_ = L_1672_ - 2
		if L_1697_ <= 0 then
			return
		end
		local L_1698_ = L_1676_func(2, L_1697_)
		return L_2_(L_1698_, 1, L_1698_.n)
	end
end

L_13_.fn_136_NewSection = function(L_1699_arg0, L_1700_arg1, L_1701_arg2, L_1702_arg3)
	L_1702_arg3 = L_1699_arg0[1][1]
	return L_1702_arg3
end

L_13_.fn_137_legacySet = function(L_1703_arg0, L_1704_arg1, L_1705_arg2, L_1706_arg3, L_1707_arg4)
	L_1705_arg2 = L_1703_arg0[1][1]
	L_1707_arg4 = false
	do
		local L_1708_ = L_1705_arg2;
		L_1706_arg3 = L_1708_;
		L_1705_arg2 = L_1708_.Set
	end
	L_1705_arg2(L_1706_arg3, L_1707_arg4)
	return
end

L_13_.fn_138_deferredWait = function(L_1709_arg0, L_1710_arg1, L_1711_arg2, L_1712_arg3)
	L_1711_arg2 = L_10_func(L_1710_arg1, "pcall")
	L_1712_arg3 = L_14_func(L_13_.fn_137_legacySet, L_1710_arg1, {
		L_1709_arg0[1]
	})
	L_1711_arg2(L_1712_arg3)
	L_1711_arg2 = L_10_func(L_1710_arg1, "task")
	L_1711_arg2 = L_1711_arg2.wait
	L_1711_arg2()
	L_1711_arg2 = false
	L_1709_arg0[2][1] = L_1711_arg2
	return
end

L_13_.fn_139_deferredPremiumCheck = function(L_1713_arg0, L_1714_arg1, L_1715_arg2, L_1716_arg3, L_1717_arg4)
	L_1716_arg3 = L_1713_arg0[1][1]
	if not L_1716_arg3 then
		L_1716_arg3 = L_10_func(L_1714_arg1, "_isPremiumUser")
		L_1716_arg3 = L_1716_arg3()
		if not L_1716_arg3 then
			if L_1715_arg2 then
				L_1716_arg3 = L_1713_arg0[3][1]
				L_1717_arg4 = L_1713_arg0[4][1]
				L_1716_arg3(L_1717_arg4)
				L_1716_arg3 = true
				L_1713_arg0[1][1] = L_1716_arg3
				L_1716_arg3 = L_10_func(L_1714_arg1, "task")
				L_1716_arg3 = L_1716_arg3.defer
				L_1717_arg4 = L_14_func(L_13_.fn_138_deferredWait, L_1714_arg1, {
					L_1713_arg0[5],
					L_1713_arg0[1]
				})
				L_1716_arg3(L_1717_arg4)
			end
		else
			L_1716_arg3 = L_1713_arg0[2][1]
			if not L_1716_arg3 then
				return
			else
				L_1716_arg3 = L_1713_arg0[2][1]
				L_1717_arg4 = L_1715_arg2
				L_1716_arg3(L_1717_arg4)
				return
			end
		end
		return
	else
		return
	end
end

L_13_.fn_140_NewPremiumToggle = function(L_1718_arg0, L_1719_arg1, ...)
	local L_1720_ = L_1_(...)
	local L_1721_ = L_1720_.n
	local L_1722_ = {}
	local L_1723_ = {}
	local L_1724_ = 10
	local L_1725_ = 11
	for L_1732_forvar0 = 0, L_1725_ - 1 do
		L_1722_[L_1732_forvar0] = L_1720_[L_1732_forvar0 + 1]
	end
	local L_1726_ = {
		n = math.max(0, L_1721_ - L_1725_)
	}
	for L_1733_forvar0 = 1, L_1726_.n do
		L_1726_[L_1733_forvar0] = L_1720_[L_1725_ + L_1733_forvar0]
	end
	local L_1727_ = L_1721_
	local function L_1728_func(L_1734_arg0)
		local L_1735_ = L_1723_[L_1734_arg0]
		if L_1735_ ~= nil then
			return L_1735_[1]
		end
		return L_1722_[L_1734_arg0]
	end
	local function L_1729_func(L_1736_arg0, L_1737_arg1)
		local L_1738_ = L_1723_[L_1736_arg0]
		if L_1738_ ~= nil then
			L_1738_[1] = L_1737_arg1
		else
			L_1722_[L_1736_arg0] = L_1737_arg1
		end
	end
	local function L_1730_func(L_1739_arg0)
		local L_1740_ = L_1723_[L_1739_arg0]
		if L_1740_ == nil then
			L_1740_ = {
				L_1722_[L_1739_arg0]
			};
			L_1723_[L_1739_arg0] = L_1740_
		end
		return L_1740_
	end
	local function L_1731_func(L_1741_arg0, L_1742_arg1)
		local L_1743_ = {
			n = L_1742_arg1
		}
		for L_1744_forvar0 = 1, L_1742_arg1 do
			L_1743_[L_1744_forvar0] = L_1728_func(L_1741_arg0 + L_1744_forvar0 - 1)
		end
		return L_1743_
	end

	L_1729_func(4, nil)
	L_1729_func(5, false)
	L_1729_func(6, L_1718_arg0[1][1])
	L_1729_func(8, L_10_func(L_1719_arg1, "_premTag"))
	L_1729_func(9, L_1728_func(1))
	do
		local L_1745_ = 1
		local L_1746_ = L_1731_func(9, L_1745_)
		local L_1747_ = L_1_(L_1728_func(8)(L_2_(L_1746_, 1, L_1746_.n)))
		for L_1748_forvar0 = 1, 1 do
			L_1729_func(8 + L_1748_forvar0 - 1, L_1747_[L_1748_forvar0])
		end
	end
	L_1729_func(9, false)
	do
		local L_1749_ = {}
		L_1749_[1] = L_1730_func(5)
		L_1749_[2] = {
			L_1728_func(3)
		}
		L_1749_[3] = L_1718_arg0[2]
		L_1749_[4] = {
			L_1728_func(1)
		}
		L_1749_[5] = L_1730_func(4)
		local L_1750_ = {
			L_1719_arg1 and L_1719_arg1[1] or nil
		}
		local L_1751_
		L_1751_ = function(...)
			return L_13_.fn_139_deferredPremiumCheck(L_1749_, L_1750_, ...)
		end
		L_6_[L_1751_] = L_1750_
		L_1729_func(10, L_1751_)
	end
	do
		local L_1752_ = L_1728_func(6)
		L_1729_func(7, L_1752_)
		L_1729_func(6, L_1752_["CreateToggle"])
	end
	do
		local L_1753_ = 4
		local L_1754_ = L_1731_func(7, L_1753_)
		local L_1755_ = L_1_(L_1728_func(6)(L_2_(L_1754_, 1, L_1754_.n)))
		for L_1756_forvar0 = 1, 1 do
			L_1729_func(6 + L_1756_forvar0 - 1, L_1755_[L_1756_forvar0])
		end
	end
	L_1729_func(4, L_1728_func(6))
	for L_1757_forvar0 = 4, L_1724_ do
		local L_1758_ = L_1723_[L_1757_forvar0]
		if L_1758_ ~= nil then
			L_1722_[L_1757_forvar0] = L_1758_[1]
			L_1723_[L_1757_forvar0] = nil
		end
	end
	do
		local L_1759_ = L_1731_func(4, 1);
		return L_2_(L_1759_, 1, L_1759_.n)
	end
end

L_13_.fn_141_premiumToggleGate = function(L_1760_arg0, L_1761_arg1, L_1762_arg2, L_1763_arg3)
	L_1762_arg2 = L_10_func(L_1761_arg1, "_isPremiumUser")
	L_1762_arg2 = L_1762_arg2()
	if not L_1762_arg2 then
		L_1762_arg2 = L_1760_arg0[2][1]
		L_1763_arg3 = L_1760_arg0[3][1]
		L_1762_arg2(L_1763_arg3)
	else
		L_1762_arg2 = L_1760_arg0[1][1]
		if not L_1762_arg2 then
			return
		else
			L_1762_arg2 = L_1760_arg0[1][1]
			L_1762_arg2()
			return
		end
	end
	return
end

L_13_.fn_142_NewPremiumButton = function(L_1764_arg0, L_1765_arg1, ...)
	local L_1766_ = L_1_(...)
	local L_1767_ = L_1766_.n
	local L_1768_ = {}
	local L_1769_ = {}
	local L_1770_ = 7
	local L_1771_ = 8
	for L_1778_forvar0 = 0, L_1771_ - 1 do
		L_1768_[L_1778_forvar0] = L_1766_[L_1778_forvar0 + 1]
	end
	local L_1772_ = {
		n = math.max(0, L_1767_ - L_1771_)
	}
	for L_1779_forvar0 = 1, L_1772_.n do
		L_1772_[L_1779_forvar0] = L_1766_[L_1771_ + L_1779_forvar0]
	end
	local L_1773_ = L_1767_
	local function L_1774_func(L_1780_arg0)
		local L_1781_ = L_1769_[L_1780_arg0]
		if L_1781_ ~= nil then
			return L_1781_[1]
		end
		return L_1768_[L_1780_arg0]
	end
	local function L_1775_func(L_1782_arg0, L_1783_arg1)
		local L_1784_ = L_1769_[L_1782_arg0]
		if L_1784_ ~= nil then
			L_1784_[1] = L_1783_arg1
		else
			L_1768_[L_1782_arg0] = L_1783_arg1
		end
	end
	local function L_1776_func(L_1785_arg0)
		local L_1786_ = L_1769_[L_1785_arg0]
		if L_1786_ == nil then
			L_1786_ = {
				L_1768_[L_1785_arg0]
			};
			L_1769_[L_1785_arg0] = L_1786_
		end
		return L_1786_
	end
	local function L_1777_func(L_1787_arg0, L_1788_arg1)
		local L_1789_ = {
			n = L_1788_arg1
		}
		for L_1790_forvar0 = 1, L_1788_arg1 do
			L_1789_[L_1790_forvar0] = L_1774_func(L_1787_arg0 + L_1790_forvar0 - 1)
		end
		return L_1789_
	end

	L_1775_func(4, L_1764_arg0[1][1])
	L_1775_func(6, L_10_func(L_1765_arg1, "_premTag"))
	L_1775_func(7, L_1774_func(1))
	do
		local L_1791_ = 1
		local L_1792_ = L_1777_func(7, L_1791_)
		local L_1793_ = L_1_(L_1774_func(6)(L_2_(L_1792_, 1, L_1792_.n)))
		for L_1794_forvar0 = 1, 1 do
			L_1775_func(6 + L_1794_forvar0 - 1, L_1793_[L_1794_forvar0])
		end
	end
	do
		local L_1795_ = {}
		L_1795_[1] = {
			L_1774_func(3)
		}
		L_1795_[2] = L_1764_arg0[2]
		L_1795_[3] = {
			L_1774_func(1)
		}
		local L_1796_ = {
			L_1765_arg1 and L_1765_arg1[1] or nil
		}
		local L_1797_
		L_1797_ = function(...)
			return L_13_.fn_141_premiumToggleGate(L_1795_, L_1796_, ...)
		end
		L_6_[L_1797_] = L_1796_
		L_1775_func(7, L_1797_)
	end
	do
		local L_1798_ = L_1774_func(4)
		L_1775_func(5, L_1798_)
		L_1775_func(4, L_1798_["CreateButton"])
	end
	do
		local L_1799_ = 3
		local L_1800_ = L_1777_func(5, L_1799_)
		local L_1801_ = L_1_(L_1774_func(4)(L_2_(L_1800_, 1, L_1800_.n)))
		for L_1802_forvar0 = 1, L_1801_.n do
			L_1775_func(4 + L_1802_forvar0 - 1, L_1801_[L_1802_forvar0])
		end
		L_1773_ = 4 + L_1801_.n
	end
	do
		local L_1803_ = L_1773_ - 4
		if L_1803_ <= 0 then
			return
		end
		local L_1804_ = L_1777_func(4, L_1803_)
		return L_2_(L_1804_, 1, L_1804_.n)
	end
end

L_13_.fn_143_premiumButtonGate = function(L_1805_arg0, L_1806_arg1, L_1807_arg2, L_1808_arg3, L_1809_arg4)
	L_1808_arg3 = L_10_func(L_1806_arg1, "_isPremiumUser")
	L_1808_arg3 = L_1808_arg3()
	if not L_1808_arg3 then
		L_1808_arg3 = L_1805_arg0[2][1]
		L_1809_arg4 = L_1805_arg0[3][1]
		L_1808_arg3(L_1809_arg4)
	else
		L_1808_arg3 = L_1805_arg0[1][1]
		if not L_1808_arg3 then
			return
		else
			L_1808_arg3 = L_1805_arg0[1][1]
			L_1809_arg4 = L_1807_arg2
			L_1808_arg3(L_1809_arg4)
			return
		end
	end
	return
end

L_13_.fn_144_NewPremiumSlider = function(L_1810_arg0, L_1811_arg1, ...)
	local L_1812_, L_1813_, L_1814_, L_1815_, L_1816_, L_1817_ = ...
	local L_1818_ = L_1810_arg0[1][1]
	local L_1819_ = L_10_func(L_1811_arg1, "_premTag")(L_1813_)
	local L_1820_ = L_1816_ or 0
	local L_1821_ = L_1815_ or 100
	local L_1822_ = L_1816_ or 0
	local L_1823_ = L_14_func(
        L_13_.fn_143_premiumButtonGate,
        L_1811_arg1,
        {
		{
			L_1817_
		},
		L_1810_arg0[2],
		{
			L_1813_
		}
	}
    )
	return L_1818_:CreateSlider(L_1819_, L_1820_, L_1821_, L_1822_, L_1823_)
end

L_13_.fn_145_premiumSliderGate = function(L_1824_arg0, L_1825_arg1, L_1826_arg2, L_1827_arg3, L_1828_arg4)
	L_1827_arg3 = L_10_func(L_1825_arg1, "_isPremiumUser")
	L_1827_arg3 = L_1827_arg3()
	if not L_1827_arg3 then
		L_1827_arg3 = L_1824_arg0[2][1]
		L_1828_arg4 = L_1824_arg0[3][1]
		L_1827_arg3(L_1828_arg4)
	else
		L_1827_arg3 = L_1824_arg0[1][1]
		if not L_1827_arg3 then
			return
		else
			L_1827_arg3 = L_1824_arg0[1][1]
			L_1828_arg4 = L_1826_arg2
			L_1827_arg3(L_1828_arg4)
			return
		end
	end
	return
end

L_13_.fn_146_NewPremiumDropdown = function(L_1829_arg0, L_1830_arg1, ...)
	local L_1831_ = L_1_(...)
	local L_1832_ = L_1831_.n
	local L_1833_ = {}
	local L_1834_ = {}
	local L_1835_ = 13
	local L_1836_ = 14
	for L_1843_forvar0 = 0, L_1836_ - 1 do
		L_1833_[L_1843_forvar0] = L_1831_[L_1843_forvar0 + 1]
	end
	local L_1837_ = {
		n = math.max(0, L_1832_ - L_1836_)
	}
	for L_1844_forvar0 = 1, L_1837_.n do
		L_1837_[L_1844_forvar0] = L_1831_[L_1836_ + L_1844_forvar0]
	end
	local L_1838_ = L_1832_
	local function L_1839_func(L_1845_arg0)
		local L_1846_ = L_1834_[L_1845_arg0]
		if L_1846_ ~= nil then
			return L_1846_[1]
		end
		return L_1833_[L_1845_arg0]
	end
	local function L_1840_func(L_1847_arg0, L_1848_arg1)
		local L_1849_ = L_1834_[L_1847_arg0]
		if L_1849_ ~= nil then
			L_1849_[1] = L_1848_arg1
		else
			L_1833_[L_1847_arg0] = L_1848_arg1
		end
	end
	local function L_1841_func(L_1850_arg0)
		local L_1851_ = L_1834_[L_1850_arg0]
		if L_1851_ == nil then
			L_1851_ = {
				L_1833_[L_1850_arg0]
			};
			L_1834_[L_1850_arg0] = L_1851_
		end
		return L_1851_
	end
	local function L_1842_func(L_1852_arg0, L_1853_arg1)
		local L_1854_ = {
			n = L_1853_arg1
		}
		for L_1855_forvar0 = 1, L_1853_arg1 do
			L_1854_[L_1855_forvar0] = L_1839_func(L_1852_arg0 + L_1855_forvar0 - 1)
		end
		return L_1854_
	end

	L_1840_func(5, L_1829_arg0[1][1])
	L_1840_func(6, L_1839_func(2))
	L_1840_func(7, L_1839_func(3))
	L_1840_func(8, L_1839_func(4))
	do
		local L_1856_ = 3
		local L_1857_ = L_1842_func(6, L_1856_)
		local L_1858_ = L_1_(L_1839_func(5)(L_2_(L_1857_, 1, L_1857_.n)))
		for L_1859_forvar0 = 1, 3 do
			L_1840_func(5 + L_1859_forvar0 - 1, L_1858_[L_1859_forvar0])
		end
	end
	L_1840_func(8, L_1829_arg0[2][1])
	L_1840_func(10, L_10_func(L_1830_arg1, "_premTag"))
	L_1840_func(11, L_1839_func(1))
	do
		local L_1860_ = 1
		local L_1861_ = L_1842_func(11, L_1860_)
		local L_1862_ = L_1_(L_1839_func(10)(L_2_(L_1861_, 1, L_1861_.n)))
		for L_1863_forvar0 = 1, 1 do
			L_1840_func(10 + L_1863_forvar0 - 1, L_1862_[L_1863_forvar0])
		end
	end
	L_1840_func(11, L_1839_func(5))
	L_1840_func(12, L_1839_func(6))
	do
		local L_1864_ = {}
		L_1864_[1] = {
			L_1839_func(7)
		}
		L_1864_[2] = L_1829_arg0[3]
		L_1864_[3] = {
			L_1839_func(1)
		}
		local L_1865_ = {
			L_1830_arg1 and L_1830_arg1[1] or nil
		}
		local L_1866_
		L_1866_ = function(...)
			return L_13_.fn_145_premiumSliderGate(L_1864_, L_1865_, ...)
		end
		L_6_[L_1866_] = L_1865_
		L_1840_func(13, L_1866_)
	end
	do
		local L_1867_ = L_1839_func(8)
		L_1840_func(9, L_1867_)
		L_1840_func(8, L_1867_["CreateDropdown"])
	end
	do
		local L_1868_ = 5
		local L_1869_ = L_1842_func(9, L_1868_)
		local L_1870_ = L_1_(L_1839_func(8)(L_2_(L_1869_, 1, L_1869_.n)))
		for L_1871_forvar0 = 1, L_1870_.n do
			L_1840_func(8 + L_1871_forvar0 - 1, L_1870_[L_1871_forvar0])
		end
		L_1838_ = 8 + L_1870_.n
	end
	do
		local L_1872_ = L_1838_ - 8
		if L_1872_ <= 0 then
			return
		end
		local L_1873_ = L_1842_func(8, L_1872_)
		return L_2_(L_1873_, 1, L_1873_.n)
	end
end

L_13_.fn_147_NewSection = function(L_1874_arg0, L_1875_arg1, L_1876_arg2, L_1877_arg3, L_1878_arg4, L_1879_arg5, L_1880_arg6, L_1881_arg7, L_1882_arg8, L_1883_arg9, L_1884_arg10)
	L_1878_arg4 = "layout"
	L_1879_arg5 = L_1877_arg3
	if not L_1879_arg5 then
		L_1879_arg5 = ""
	end
	do
		local L_1885_ = L_1879_arg5;
		L_1880_arg6 = L_1885_;
		L_1879_arg5 = L_1885_.lower
	end
	L_1879_arg5 = L_1879_arg5(L_1880_arg6)
	L_1882_arg8 = "combat"
	L_1883_arg9 = 1
	L_1884_arg10 = true
	do
		local L_1886_ = L_1879_arg5;
		L_1881_arg7 = L_1886_;
		L_1880_arg6 = L_1886_.find
	end
	L_1880_arg6 = L_1880_arg6(L_1881_arg7, L_1882_arg8, L_1883_arg9, L_1884_arg10)
	if not L_1880_arg6 then
		L_1882_arg8 = "visual"
		L_1883_arg9 = 1
		L_1884_arg10 = true
		do
			local L_1887_ = L_1879_arg5;
			L_1881_arg7 = L_1887_;
			L_1880_arg6 = L_1887_.find
		end
		L_1880_arg6 = L_1880_arg6(L_1881_arg7, L_1882_arg8, L_1883_arg9, L_1884_arg10)
		if not L_1880_arg6 then
			L_1882_arg8 = "main"
			L_1883_arg9 = 1
			L_1884_arg10 = true
			do
				local L_1888_ = L_1879_arg5;
				L_1881_arg7 = L_1888_;
				L_1880_arg6 = L_1888_.find
			end
			L_1880_arg6 = L_1880_arg6(L_1881_arg7, L_1882_arg8, L_1883_arg9, L_1884_arg10)
			if not L_1880_arg6 then
				L_1882_arg8 = "home"
				L_1883_arg9 = 1
				L_1884_arg10 = true
				do
					local L_1889_ = L_1879_arg5;
					L_1881_arg7 = L_1889_;
					L_1880_arg6 = L_1889_.find
				end
				L_1880_arg6 = L_1880_arg6(L_1881_arg7, L_1882_arg8, L_1883_arg9, L_1884_arg10)
				if not L_1880_arg6 then
					L_1882_arg8 = "setting"
					L_1883_arg9 = 1
					L_1884_arg10 = true
					do
						local L_1890_ = L_1879_arg5;
						L_1881_arg7 = L_1890_;
						L_1880_arg6 = L_1890_.find
					end
					L_1880_arg6 = L_1880_arg6(L_1881_arg7, L_1882_arg8, L_1883_arg9, L_1884_arg10)
					if not L_1880_arg6 then
						L_1882_arg8 = "config"
						L_1883_arg9 = 1
						L_1884_arg10 = true
						do
							local L_1891_ = L_1879_arg5;
							L_1881_arg7 = L_1891_;
							L_1880_arg6 = L_1891_.find
						end
						L_1880_arg6 = L_1880_arg6(L_1881_arg7, L_1882_arg8, L_1883_arg9, L_1884_arg10)
						if L_1880_arg6 then
							L_1878_arg4 = "settings"
						end
						L_1880_arg6 = L_1876_arg2.ActualTab
						L_1882_arg8 = L_1877_arg3
						if not L_1882_arg8 then
							L_1882_arg8 = "Main"
						end
						L_1883_arg9 = L_1878_arg4
						do
							local L_1892_ = L_1880_arg6;
							L_1881_arg7 = L_1892_;
							L_1880_arg6 = L_1892_.CreateSubTab
						end
						L_1880_arg6 = L_1880_arg6(L_1881_arg7, L_1882_arg8, L_1883_arg9)
						L_1883_arg9 = L_1877_arg3
						if not L_1883_arg9 then
							L_1883_arg9 = "Main"
						end
						do
							local L_1893_ = L_1880_arg6;
							L_1882_arg8 = L_1893_;
							L_1881_arg7 = L_1893_.CreateSection
						end
						L_1881_arg7 = L_1881_arg7(L_1882_arg8, L_1883_arg9)
						L_1882_arg8 = {}
						L_1883_arg9 = L_14_func(L_13_.fn_129_NewToggle, L_1875_arg1, {
							{
								L_1881_arg7
							}
						})
						L_1882_arg8.NewToggle = L_1883_arg9
						L_1883_arg9 = L_14_func(L_13_.fn_130_NewSlider, L_1875_arg1, {
							{
								L_1881_arg7
							}
						})
						L_1882_arg8.NewSlider = L_1883_arg9
						L_1883_arg9 = L_14_func(L_13_.fn_131_NewButton, L_1875_arg1, {
							{
								L_1881_arg7
							}
						})
						L_1882_arg8.NewButton = L_1883_arg9
						L_1883_arg9 = L_14_func(L_13_.fn_132_NewDropdown, L_1875_arg1, {
							L_1874_arg0[1],
							{
								L_1881_arg7
							}
						})
						L_1882_arg8.NewDropdown = L_1883_arg9
						L_1883_arg9 = L_14_func(L_13_.fn_133_NewLabel, L_1875_arg1, {
							{
								L_1881_arg7
							}
						})
						L_1882_arg8.NewLabel = L_1883_arg9
						L_1883_arg9 = L_14_func(L_13_.fn_134_NewInput, L_1875_arg1, {
							{
								L_1881_arg7
							}
						})
						L_1882_arg8.NewInput = L_1883_arg9
						L_1883_arg9 = L_14_func(L_13_.fn_135_NewTitle, L_1875_arg1, {
							{
								L_1881_arg7
							}
						})
						L_1882_arg8.NewTitle = L_1883_arg9
						L_1883_arg9 = L_14_func(L_13_.fn_136_NewSection, L_1875_arg1, {
							{
								L_1881_arg7
							}
						})
						L_1882_arg8.NewSection = L_1883_arg9
						L_1883_arg9 = L_14_func(L_13_.fn_140_NewPremiumToggle, L_1875_arg1, {
							{
								L_1881_arg7
							},
							L_1874_arg0[2]
						})
						L_1882_arg8.NewPremiumToggle = L_1883_arg9
						L_1883_arg9 = L_14_func(L_13_.fn_142_NewPremiumButton, L_1875_arg1, {
							{
								L_1881_arg7
							},
							L_1874_arg0[2]
						})
						L_1882_arg8.NewPremiumButton = L_1883_arg9
						L_1883_arg9 = L_14_func(L_13_.fn_144_NewPremiumSlider, L_1875_arg1, {
							{
								L_1881_arg7
							},
							L_1874_arg0[2]
						})
						L_1882_arg8.NewPremiumSlider = L_1883_arg9
						L_1883_arg9 = L_14_func(L_13_.fn_146_NewPremiumDropdown, L_1875_arg1, {
							L_1874_arg0[1],
							{
								L_1881_arg7
							},
							L_1874_arg0[2]
						})
						L_1882_arg8.NewPremiumDropdown = L_1883_arg9
						return L_1882_arg8
					end
					L_1878_arg4 = "settings"
				else
					L_1878_arg4 = "home"
				end
				L_1880_arg6 = L_1876_arg2.ActualTab
				L_1882_arg8 = L_1877_arg3
				if not L_1882_arg8 then
					L_1882_arg8 = "Main"
				end
				L_1883_arg9 = L_1878_arg4
				do
					local L_1894_ = L_1880_arg6;
					L_1881_arg7 = L_1894_;
					L_1880_arg6 = L_1894_.CreateSubTab
				end
				L_1880_arg6 = L_1880_arg6(L_1881_arg7, L_1882_arg8, L_1883_arg9)
				L_1883_arg9 = L_1877_arg3
				if not L_1883_arg9 then
					L_1883_arg9 = "Main"
				end
				do
					local L_1895_ = L_1880_arg6;
					L_1882_arg8 = L_1895_;
					L_1881_arg7 = L_1895_.CreateSection
				end
				L_1881_arg7 = L_1881_arg7(L_1882_arg8, L_1883_arg9)
				L_1882_arg8 = {}
				L_1883_arg9 = L_14_func(L_13_.fn_129_NewToggle, L_1875_arg1, {
					{
						L_1881_arg7
					}
				})
				L_1882_arg8.NewToggle = L_1883_arg9
				L_1883_arg9 = L_14_func(L_13_.fn_130_NewSlider, L_1875_arg1, {
					{
						L_1881_arg7
					}
				})
				L_1882_arg8.NewSlider = L_1883_arg9
				L_1883_arg9 = L_14_func(L_13_.fn_131_NewButton, L_1875_arg1, {
					{
						L_1881_arg7
					}
				})
				L_1882_arg8.NewButton = L_1883_arg9
				L_1883_arg9 = L_14_func(L_13_.fn_132_NewDropdown, L_1875_arg1, {
					L_1874_arg0[1],
					{
						L_1881_arg7
					}
				})
				L_1882_arg8.NewDropdown = L_1883_arg9
				L_1883_arg9 = L_14_func(L_13_.fn_133_NewLabel, L_1875_arg1, {
					{
						L_1881_arg7
					}
				})
				L_1882_arg8.NewLabel = L_1883_arg9
				L_1883_arg9 = L_14_func(L_13_.fn_134_NewInput, L_1875_arg1, {
					{
						L_1881_arg7
					}
				})
				L_1882_arg8.NewInput = L_1883_arg9
				L_1883_arg9 = L_14_func(L_13_.fn_135_NewTitle, L_1875_arg1, {
					{
						L_1881_arg7
					}
				})
				L_1882_arg8.NewTitle = L_1883_arg9
				L_1883_arg9 = L_14_func(L_13_.fn_136_NewSection, L_1875_arg1, {
					{
						L_1881_arg7
					}
				})
				L_1882_arg8.NewSection = L_1883_arg9
				L_1883_arg9 = L_14_func(L_13_.fn_140_NewPremiumToggle, L_1875_arg1, {
					{
						L_1881_arg7
					},
					L_1874_arg0[2]
				})
				L_1882_arg8.NewPremiumToggle = L_1883_arg9
				L_1883_arg9 = L_14_func(L_13_.fn_142_NewPremiumButton, L_1875_arg1, {
					{
						L_1881_arg7
					},
					L_1874_arg0[2]
				})
				L_1882_arg8.NewPremiumButton = L_1883_arg9
				L_1883_arg9 = L_14_func(L_13_.fn_144_NewPremiumSlider, L_1875_arg1, {
					{
						L_1881_arg7
					},
					L_1874_arg0[2]
				})
				L_1882_arg8.NewPremiumSlider = L_1883_arg9
				L_1883_arg9 = L_14_func(L_13_.fn_146_NewPremiumDropdown, L_1875_arg1, {
					L_1874_arg0[1],
					{
						L_1881_arg7
					},
					L_1874_arg0[2]
				})
				L_1882_arg8.NewPremiumDropdown = L_1883_arg9
				return L_1882_arg8
			end
			L_1878_arg4 = "home"
		else
			L_1878_arg4 = "eye"
		end
	else
		L_1878_arg4 = "swords"
	end
	L_1880_arg6 = L_1876_arg2.ActualTab
	L_1882_arg8 = L_1877_arg3
	if not L_1882_arg8 then
		L_1882_arg8 = "Main"
	end
	L_1883_arg9 = L_1878_arg4
	do
		local L_1896_ = L_1880_arg6;
		L_1881_arg7 = L_1896_;
		L_1880_arg6 = L_1896_.CreateSubTab
	end
	L_1880_arg6 = L_1880_arg6(L_1881_arg7, L_1882_arg8, L_1883_arg9)
	L_1883_arg9 = L_1877_arg3
	if not L_1883_arg9 then
		L_1883_arg9 = "Main"
	end
	do
		local L_1897_ = L_1880_arg6;
		L_1882_arg8 = L_1897_;
		L_1881_arg7 = L_1897_.CreateSection
	end
	L_1881_arg7 = L_1881_arg7(L_1882_arg8, L_1883_arg9)
	L_1882_arg8 = {}
	L_1883_arg9 = L_14_func(L_13_.fn_129_NewToggle, L_1875_arg1, {
		{
			L_1881_arg7
		}
	})
	L_1882_arg8.NewToggle = L_1883_arg9
	L_1883_arg9 = L_14_func(L_13_.fn_130_NewSlider, L_1875_arg1, {
		{
			L_1881_arg7
		}
	})
	L_1882_arg8.NewSlider = L_1883_arg9
	L_1883_arg9 = L_14_func(L_13_.fn_131_NewButton, L_1875_arg1, {
		{
			L_1881_arg7
		}
	})
	L_1882_arg8.NewButton = L_1883_arg9
	L_1883_arg9 = L_14_func(L_13_.fn_132_NewDropdown, L_1875_arg1, {
		L_1874_arg0[1],
		{
			L_1881_arg7
		}
	})
	L_1882_arg8.NewDropdown = L_1883_arg9
	L_1883_arg9 = L_14_func(L_13_.fn_133_NewLabel, L_1875_arg1, {
		{
			L_1881_arg7
		}
	})
	L_1882_arg8.NewLabel = L_1883_arg9
	L_1883_arg9 = L_14_func(L_13_.fn_134_NewInput, L_1875_arg1, {
		{
			L_1881_arg7
		}
	})
	L_1882_arg8.NewInput = L_1883_arg9
	L_1883_arg9 = L_14_func(L_13_.fn_135_NewTitle, L_1875_arg1, {
		{
			L_1881_arg7
		}
	})
	L_1882_arg8.NewTitle = L_1883_arg9
	L_1883_arg9 = L_14_func(L_13_.fn_136_NewSection, L_1875_arg1, {
		{
			L_1881_arg7
		}
	})
	L_1882_arg8.NewSection = L_1883_arg9
	L_1883_arg9 = L_14_func(L_13_.fn_140_NewPremiumToggle, L_1875_arg1, {
		{
			L_1881_arg7
		},
		L_1874_arg0[2]
	})
	L_1882_arg8.NewPremiumToggle = L_1883_arg9
	L_1883_arg9 = L_14_func(L_13_.fn_142_NewPremiumButton, L_1875_arg1, {
		{
			L_1881_arg7
		},
		L_1874_arg0[2]
	})
	L_1882_arg8.NewPremiumButton = L_1883_arg9
	L_1883_arg9 = L_14_func(L_13_.fn_144_NewPremiumSlider, L_1875_arg1, {
		{
			L_1881_arg7
		},
		L_1874_arg0[2]
	})
	L_1882_arg8.NewPremiumSlider = L_1883_arg9
	L_1883_arg9 = L_14_func(L_13_.fn_146_NewPremiumDropdown, L_1875_arg1, {
		L_1874_arg0[1],
		{
			L_1881_arg7
		},
		L_1874_arg0[2]
	})
	L_1882_arg8.NewPremiumDropdown = L_1883_arg9
	return L_1882_arg8
end

L_13_.fn_148_HideTabButton = function(L_1898_arg0, L_1899_arg1, L_1900_arg2, L_1901_arg3, L_1902_arg4, L_1903_arg5)
	L_1901_arg3 = L_1900_arg2.ActualTab
	L_1903_arg5 = false
	do
		local L_1904_ = L_1901_arg3;
		L_1902_arg4 = L_1904_;
		L_1901_arg3 = L_1904_.SetVisible
	end
	L_1901_arg3(L_1902_arg4, L_1903_arg5)
	return
end

L_13_.fn_149_Select = function(L_1905_arg0, L_1906_arg1, L_1907_arg2, L_1908_arg3, L_1909_arg4)
	L_1908_arg3 = L_1907_arg2.ActualTab
	do
		local L_1910_ = L_1908_arg3;
		L_1909_arg4 = L_1910_;
		L_1908_arg3 = L_1910_.Select
	end
	L_1908_arg3(L_1909_arg4)
	return
end

L_13_.fn_150_NewTab = function(L_1911_arg0, L_1912_arg1, L_1913_arg2, L_1914_arg3, L_1915_arg4, L_1916_arg5, L_1917_arg6, L_1918_arg7, L_1919_arg8, L_1920_arg9, L_1921_arg10)
	L_1915_arg4 = "home"
	do
		local L_1922_ = L_1914_arg3;
		L_1917_arg6 = L_1922_;
		L_1916_arg5 = L_1922_.lower
	end
	L_1916_arg5 = L_1916_arg5(L_1917_arg6)
	L_1919_arg8 = "aim"
	L_1920_arg9 = 1
	L_1921_arg10 = true
	do
		local L_1923_ = L_1916_arg5;
		L_1918_arg7 = L_1923_;
		L_1917_arg6 = L_1923_.find
	end
	L_1917_arg6 = L_1917_arg6(L_1918_arg7, L_1919_arg8, L_1920_arg9, L_1921_arg10)
	if not L_1917_arg6 then
		L_1919_arg8 = "combat"
		L_1920_arg9 = 1
		L_1921_arg10 = true
		do
			local L_1924_ = L_1916_arg5;
			L_1918_arg7 = L_1924_;
			L_1917_arg6 = L_1924_.find
		end
		L_1917_arg6 = L_1917_arg6(L_1918_arg7, L_1919_arg8, L_1920_arg9, L_1921_arg10)
		if not L_1917_arg6 then
			L_1919_arg8 = "kill"
			L_1920_arg9 = 1
			L_1921_arg10 = true
			do
				local L_1925_ = L_1916_arg5;
				L_1918_arg7 = L_1925_;
				L_1917_arg6 = L_1925_.find
			end
			L_1917_arg6 = L_1917_arg6(L_1918_arg7, L_1919_arg8, L_1920_arg9, L_1921_arg10)
			if not L_1917_arg6 then
				L_1919_arg8 = "gun"
				L_1920_arg9 = 1
				L_1921_arg10 = true
				do
					local L_1926_ = L_1916_arg5;
					L_1918_arg7 = L_1926_;
					L_1917_arg6 = L_1926_.find
				end
				L_1917_arg6 = L_1917_arg6(L_1918_arg7, L_1919_arg8, L_1920_arg9, L_1921_arg10)
				if not L_1917_arg6 then
					L_1919_arg8 = "player"
					L_1920_arg9 = 1
					L_1921_arg10 = true
					do
						local L_1927_ = L_1916_arg5;
						L_1918_arg7 = L_1927_;
						L_1917_arg6 = L_1927_.find
					end
					L_1917_arg6 = L_1917_arg6(L_1918_arg7, L_1919_arg8, L_1920_arg9, L_1921_arg10)
					if not L_1917_arg6 then
						L_1919_arg8 = "user"
						L_1920_arg9 = 1
						L_1921_arg10 = true
						do
							local L_1928_ = L_1916_arg5;
							L_1918_arg7 = L_1928_;
							L_1917_arg6 = L_1928_.find
						end
						L_1917_arg6 = L_1917_arg6(L_1918_arg7, L_1919_arg8, L_1920_arg9, L_1921_arg10)
						if not L_1917_arg6 then
							L_1919_arg8 = "char"
							L_1920_arg9 = 1
							L_1921_arg10 = true
							do
								local L_1929_ = L_1916_arg5;
								L_1918_arg7 = L_1929_;
								L_1917_arg6 = L_1929_.find
							end
							L_1917_arg6 = L_1917_arg6(L_1918_arg7, L_1919_arg8, L_1920_arg9, L_1921_arg10)
							if not L_1917_arg6 then
								L_1919_arg8 = "move"
								L_1920_arg9 = 1
								L_1921_arg10 = true
								do
									local L_1930_ = L_1916_arg5;
									L_1918_arg7 = L_1930_;
									L_1917_arg6 = L_1930_.find
								end
								L_1917_arg6 = L_1917_arg6(L_1918_arg7, L_1919_arg8, L_1920_arg9, L_1921_arg10)
								if not L_1917_arg6 then
									L_1919_arg8 = "visual"
									L_1920_arg9 = 1
									L_1921_arg10 = true
									do
										local L_1931_ = L_1916_arg5;
										L_1918_arg7 = L_1931_;
										L_1917_arg6 = L_1931_.find
									end
									L_1917_arg6 = L_1917_arg6(L_1918_arg7, L_1919_arg8, L_1920_arg9, L_1921_arg10)
									if not L_1917_arg6 then
										L_1919_arg8 = "esp"
										L_1920_arg9 = 1
										L_1921_arg10 = true
										do
											local L_1932_ = L_1916_arg5;
											L_1918_arg7 = L_1932_;
											L_1917_arg6 = L_1932_.find
										end
										L_1917_arg6 = L_1917_arg6(L_1918_arg7, L_1919_arg8, L_1920_arg9, L_1921_arg10)
										if not L_1917_arg6 then
											L_1919_arg8 = "eye"
											L_1920_arg9 = 1
											L_1921_arg10 = true
											do
												local L_1933_ = L_1916_arg5;
												L_1918_arg7 = L_1933_;
												L_1917_arg6 = L_1933_.find
											end
											L_1917_arg6 = L_1917_arg6(L_1918_arg7, L_1919_arg8, L_1920_arg9, L_1921_arg10)
											if not L_1917_arg6 then
												L_1919_arg8 = "render"
												L_1920_arg9 = 1
												L_1921_arg10 = true
												do
													local L_1934_ = L_1916_arg5;
													L_1918_arg7 = L_1934_;
													L_1917_arg6 = L_1934_.find
												end
												L_1917_arg6 = L_1917_arg6(L_1918_arg7, L_1919_arg8, L_1920_arg9, L_1921_arg10)
												if not L_1917_arg6 then
													L_1919_arg8 = "setting"
													L_1920_arg9 = 1
													L_1921_arg10 = true
													do
														local L_1935_ = L_1916_arg5;
														L_1918_arg7 = L_1935_;
														L_1917_arg6 = L_1935_.find
													end
													L_1917_arg6 = L_1917_arg6(L_1918_arg7, L_1919_arg8, L_1920_arg9, L_1921_arg10)
													if not L_1917_arg6 then
														L_1919_arg8 = "config"
														L_1920_arg9 = 1
														L_1921_arg10 = true
														do
															local L_1936_ = L_1916_arg5;
															L_1918_arg7 = L_1936_;
															L_1917_arg6 = L_1936_.find
														end
														L_1917_arg6 = L_1917_arg6(L_1918_arg7, L_1919_arg8, L_1920_arg9, L_1921_arg10)
														if not L_1917_arg6 then
															L_1919_arg8 = "ui"
															L_1920_arg9 = 1
															L_1921_arg10 = true
															do
																local L_1937_ = L_1916_arg5;
																L_1918_arg7 = L_1937_;
																L_1917_arg6 = L_1937_.find
															end
															L_1917_arg6 = L_1917_arg6(L_1918_arg7, L_1919_arg8, L_1920_arg9, L_1921_arg10)
															if not L_1917_arg6 then
																L_1919_arg8 = "util"
																L_1920_arg9 = 1
																L_1921_arg10 = true
																do
																	local L_1938_ = L_1916_arg5;
																	L_1918_arg7 = L_1938_;
																	L_1917_arg6 = L_1938_.find
																end
																L_1917_arg6 = L_1917_arg6(L_1918_arg7, L_1919_arg8, L_1920_arg9, L_1921_arg10)
																if not L_1917_arg6 then
																	L_1919_arg8 = "misc"
																	L_1920_arg9 = 1
																	L_1921_arg10 = true
																	do
																		local L_1939_ = L_1916_arg5;
																		L_1918_arg7 = L_1939_;
																		L_1917_arg6 = L_1939_.find
																	end
																	L_1917_arg6 = L_1917_arg6(L_1918_arg7, L_1919_arg8, L_1920_arg9, L_1921_arg10)
																	if not L_1917_arg6 then
																		L_1919_arg8 = "tool"
																		L_1920_arg9 = 1
																		L_1921_arg10 = true
																		do
																			local L_1940_ = L_1916_arg5;
																			L_1918_arg7 = L_1940_;
																			L_1917_arg6 = L_1940_.find
																		end
																		L_1917_arg6 = L_1917_arg6(L_1918_arg7, L_1919_arg8, L_1920_arg9, L_1921_arg10)
																		if not L_1917_arg6 then
																			L_1919_arg8 = "game"
																			L_1920_arg9 = 1
																			L_1921_arg10 = true
																			do
																				local L_1941_ = L_1916_arg5;
																				L_1918_arg7 = L_1941_;
																				L_1917_arg6 = L_1941_.find
																			end
																			L_1917_arg6 = L_1917_arg6(L_1918_arg7, L_1919_arg8, L_1920_arg9, L_1921_arg10)
																			if not L_1917_arg6 then
																				L_1919_arg8 = "hub"
																				L_1920_arg9 = 1
																				L_1921_arg10 = true
																				do
																					local L_1942_ = L_1916_arg5;
																					L_1918_arg7 = L_1942_;
																					L_1917_arg6 = L_1942_.find
																				end
																				L_1917_arg6 = L_1917_arg6(L_1918_arg7, L_1919_arg8, L_1920_arg9, L_1921_arg10)
																				if not L_1917_arg6 then
																					L_1919_arg8 = "main"
																					L_1920_arg9 = 1
																					L_1921_arg10 = true
																					do
																						local L_1943_ = L_1916_arg5;
																						L_1918_arg7 = L_1943_;
																						L_1917_arg6 = L_1943_.find
																					end
																					L_1917_arg6 = L_1917_arg6(L_1918_arg7, L_1919_arg8, L_1920_arg9, L_1921_arg10)
																					if L_1917_arg6 then
																						L_1915_arg4 = "layout"
																					end
																					L_1917_arg6 = L_1911_arg0[1][1]
																					L_1919_arg8 = L_1914_arg3
																					L_1920_arg9 = L_1915_arg4
																					do
																						local L_1944_ = L_1917_arg6;
																						L_1918_arg7 = L_1944_;
																						L_1917_arg6 = L_1944_.CreateTab
																					end
																					L_1917_arg6 = L_1917_arg6(L_1918_arg7, L_1919_arg8, L_1920_arg9)
																					L_1918_arg7 = {}
																					L_1918_arg7.ActualTab = L_1917_arg6
																					L_1919_arg8 = L_14_func(L_13_.fn_147_NewSection, L_1912_arg1, {
																						L_1911_arg0[2],
																						L_1911_arg0[3]
																					})
																					L_1918_arg7.NewSection = L_1919_arg8
																					L_1919_arg8 = L_14_func(L_13_.fn_148_HideTabButton, L_1912_arg1, {})
																					L_1918_arg7.HideTabButton = L_1919_arg8
																					L_1919_arg8 = L_14_func(L_13_.fn_149_Select, L_1912_arg1, {})
																					L_1918_arg7.Select = L_1919_arg8
																					return L_1918_arg7
																				end
																			end
																			L_1915_arg4 = "layout"
																		else
																			L_1915_arg4 = "sliders"
																		end
																		L_1917_arg6 = L_1911_arg0[1][1]
																		L_1919_arg8 = L_1914_arg3
																		L_1920_arg9 = L_1915_arg4
																		do
																			local L_1945_ = L_1917_arg6;
																			L_1918_arg7 = L_1945_;
																			L_1917_arg6 = L_1945_.CreateTab
																		end
																		L_1917_arg6 = L_1917_arg6(L_1918_arg7, L_1919_arg8, L_1920_arg9)
																		L_1918_arg7 = {}
																		L_1918_arg7.ActualTab = L_1917_arg6
																		L_1919_arg8 = L_14_func(L_13_.fn_147_NewSection, L_1912_arg1, {
																			L_1911_arg0[2],
																			L_1911_arg0[3]
																		})
																		L_1918_arg7.NewSection = L_1919_arg8
																		L_1919_arg8 = L_14_func(L_13_.fn_148_HideTabButton, L_1912_arg1, {})
																		L_1918_arg7.HideTabButton = L_1919_arg8
																		L_1919_arg8 = L_14_func(L_13_.fn_149_Select, L_1912_arg1, {})
																		L_1918_arg7.Select = L_1919_arg8
																		return L_1918_arg7
																	end
																end
																L_1915_arg4 = "sliders"
															else
																L_1915_arg4 = "settings"
															end
															L_1917_arg6 = L_1911_arg0[1][1]
															L_1919_arg8 = L_1914_arg3
															L_1920_arg9 = L_1915_arg4
															do
																local L_1946_ = L_1917_arg6;
																L_1918_arg7 = L_1946_;
																L_1917_arg6 = L_1946_.CreateTab
															end
															L_1917_arg6 = L_1917_arg6(L_1918_arg7, L_1919_arg8, L_1920_arg9)
															L_1918_arg7 = {}
															L_1918_arg7.ActualTab = L_1917_arg6
															L_1919_arg8 = L_14_func(L_13_.fn_147_NewSection, L_1912_arg1, {
																L_1911_arg0[2],
																L_1911_arg0[3]
															})
															L_1918_arg7.NewSection = L_1919_arg8
															L_1919_arg8 = L_14_func(L_13_.fn_148_HideTabButton, L_1912_arg1, {})
															L_1918_arg7.HideTabButton = L_1919_arg8
															L_1919_arg8 = L_14_func(L_13_.fn_149_Select, L_1912_arg1, {})
															L_1918_arg7.Select = L_1919_arg8
															return L_1918_arg7
														end
													end
													L_1915_arg4 = "settings"
												else
													L_1915_arg4 = "eye"
												end
												L_1917_arg6 = L_1911_arg0[1][1]
												L_1919_arg8 = L_1914_arg3
												L_1920_arg9 = L_1915_arg4
												do
													local L_1947_ = L_1917_arg6;
													L_1918_arg7 = L_1947_;
													L_1917_arg6 = L_1947_.CreateTab
												end
												L_1917_arg6 = L_1917_arg6(L_1918_arg7, L_1919_arg8, L_1920_arg9)
												L_1918_arg7 = {}
												L_1918_arg7.ActualTab = L_1917_arg6
												L_1919_arg8 = L_14_func(L_13_.fn_147_NewSection, L_1912_arg1, {
													L_1911_arg0[2],
													L_1911_arg0[3]
												})
												L_1918_arg7.NewSection = L_1919_arg8
												L_1919_arg8 = L_14_func(L_13_.fn_148_HideTabButton, L_1912_arg1, {})
												L_1918_arg7.HideTabButton = L_1919_arg8
												L_1919_arg8 = L_14_func(L_13_.fn_149_Select, L_1912_arg1, {})
												L_1918_arg7.Select = L_1919_arg8
												return L_1918_arg7
											end
										end
									end
									L_1915_arg4 = "eye"
								else
									L_1915_arg4 = "user"
								end
								L_1917_arg6 = L_1911_arg0[1][1]
								L_1919_arg8 = L_1914_arg3
								L_1920_arg9 = L_1915_arg4
								do
									local L_1948_ = L_1917_arg6;
									L_1918_arg7 = L_1948_;
									L_1917_arg6 = L_1948_.CreateTab
								end
								L_1917_arg6 = L_1917_arg6(L_1918_arg7, L_1919_arg8, L_1920_arg9)
								L_1918_arg7 = {}
								L_1918_arg7.ActualTab = L_1917_arg6
								L_1919_arg8 = L_14_func(L_13_.fn_147_NewSection, L_1912_arg1, {
									L_1911_arg0[2],
									L_1911_arg0[3]
								})
								L_1918_arg7.NewSection = L_1919_arg8
								L_1919_arg8 = L_14_func(L_13_.fn_148_HideTabButton, L_1912_arg1, {})
								L_1918_arg7.HideTabButton = L_1919_arg8
								L_1919_arg8 = L_14_func(L_13_.fn_149_Select, L_1912_arg1, {})
								L_1918_arg7.Select = L_1919_arg8
								return L_1918_arg7
							end
						end
					end
					L_1915_arg4 = "user"
				else
					L_1915_arg4 = "target"
				end
				L_1917_arg6 = L_1911_arg0[1][1]
				L_1919_arg8 = L_1914_arg3
				L_1920_arg9 = L_1915_arg4
				do
					local L_1949_ = L_1917_arg6;
					L_1918_arg7 = L_1949_;
					L_1917_arg6 = L_1949_.CreateTab
				end
				L_1917_arg6 = L_1917_arg6(L_1918_arg7, L_1919_arg8, L_1920_arg9)
				L_1918_arg7 = {}
				L_1918_arg7.ActualTab = L_1917_arg6
				L_1919_arg8 = L_14_func(L_13_.fn_147_NewSection, L_1912_arg1, {
					L_1911_arg0[2],
					L_1911_arg0[3]
				})
				L_1918_arg7.NewSection = L_1919_arg8
				L_1919_arg8 = L_14_func(L_13_.fn_148_HideTabButton, L_1912_arg1, {})
				L_1918_arg7.HideTabButton = L_1919_arg8
				L_1919_arg8 = L_14_func(L_13_.fn_149_Select, L_1912_arg1, {})
				L_1918_arg7.Select = L_1919_arg8
				return L_1918_arg7
			end
		end
	end
	L_1915_arg4 = "target"
	L_1917_arg6 = L_1911_arg0[1][1]
	L_1919_arg8 = L_1914_arg3
	L_1920_arg9 = L_1915_arg4
	do
		local L_1950_ = L_1917_arg6;
		L_1918_arg7 = L_1950_;
		L_1917_arg6 = L_1950_.CreateTab
	end
	L_1917_arg6 = L_1917_arg6(L_1918_arg7, L_1919_arg8, L_1920_arg9)
	L_1918_arg7 = {}
	L_1918_arg7.ActualTab = L_1917_arg6
	L_1919_arg8 = L_14_func(L_13_.fn_147_NewSection, L_1912_arg1, {
		L_1911_arg0[2],
		L_1911_arg0[3]
	})
	L_1918_arg7.NewSection = L_1919_arg8
	L_1919_arg8 = L_14_func(L_13_.fn_148_HideTabButton, L_1912_arg1, {})
	L_1918_arg7.HideTabButton = L_1919_arg8
	L_1919_arg8 = L_14_func(L_13_.fn_149_Select, L_1912_arg1, {})
	L_1918_arg7.Select = L_1919_arg8
	return L_1918_arg7
end

L_13_.fn_151_CreateLib = function(L_1951_arg0, L_1952_arg1, L_1953_arg2, L_1954_arg3, L_1955_arg4, L_1956_arg5, L_1957_arg6)
	L_1955_arg4 = L_1951_arg0[1][1]
	L_1957_arg6 = L_1953_arg2
	do
		local L_1958_ = L_1955_arg4;
		L_1956_arg5 = L_1958_;
		L_1955_arg4 = L_1958_.CreateWindow
	end
	L_1955_arg4 = L_1955_arg4(L_1956_arg5, L_1957_arg6)
	L_1956_arg5 = {}
	L_1957_arg6 = {}
	L_1956_arg5.Tabs = L_1957_arg6
	L_1956_arg5.Window = L_1955_arg4
	L_1957_arg6 = L_14_func(L_13_.fn_150_NewTab, L_1952_arg1, {
		{
			L_1955_arg4
		},
		L_1951_arg0[2],
		L_1951_arg0[3]
	})
	L_1956_arg5.NewTab = L_1957_arg6
	return L_1956_arg5
end

L_13_.fn_152_getCharacter = function(L_1959_arg0, L_1960_arg1, L_1961_arg2, L_1962_arg3)
	L_1962_arg3 = L_1959_arg0[1][1]
	L_1961_arg2 = L_1962_arg3.Character
	return L_1961_arg2
end

L_13_.fn_153_getHumanoid = function(L_1963_arg0, L_1964_arg1, L_1965_arg2, L_1966_arg3, L_1967_arg4, L_1968_arg5)
	L_1966_arg3 = L_1963_arg0[1][1]
	L_1965_arg2 = L_1966_arg3.Character
	L_1966_arg3 = L_1965_arg2
	if L_1966_arg3 then
		L_1968_arg5 = "Humanoid"
		do
			local L_1969_ = L_1965_arg2;
			L_1967_arg4 = L_1969_;
			L_1966_arg3 = L_1969_.FindFirstChildWhichIsA
		end
		L_1966_arg3 = L_1966_arg3(L_1967_arg4, L_1968_arg5)
	end
	return L_1966_arg3
end

L_13_.fn_154_getRootPart = function(L_1970_arg0, L_1971_arg1, L_1972_arg2, L_1973_arg3, L_1974_arg4, L_1975_arg5)
	L_1973_arg3 = L_1970_arg0[1][1]
	L_1972_arg2 = L_1973_arg3.Character
	L_1973_arg3 = L_1972_arg2
	if L_1973_arg3 then
		L_1975_arg5 = "HumanoidRootPart"
		do
			local L_1976_ = L_1972_arg2;
			L_1974_arg4 = L_1976_;
			L_1973_arg3 = L_1976_.FindFirstChild
		end
		L_1973_arg3 = L_1973_arg3(L_1974_arg4, L_1975_arg5)
	end
	return L_1973_arg3
end

L_13_.fn_155_packVarargs = function(L_1977_arg0, L_1978_arg1, ...)
	local L_1979_ = {
		...
	}
	local L_1980_ = L_10_func(L_1978_arg1, "workspace")
	for L_1981_forvar0, L_1982_forvar1 in pairs(L_1980_:GetDescendants()) do
		for L_1983_forvar0, L_1984_forvar1 in pairs(L_1979_) do
			if L_1982_forvar1.Name:lower() == L_1984_forvar1:lower()
                and (L_1982_forvar1:IsA("IntValue") or L_1982_forvar1:IsA("NumberValue")) then
				return L_1982_forvar1
			end
		end
	end
	return nil
end

L_13_.fn_156_notifyWrapper = function(L_1985_arg0, L_1986_arg1, L_1987_arg2, L_1988_arg3, L_1989_arg4, L_1990_arg5, L_1991_arg6, L_1992_arg7, L_1993_arg8, L_1994_arg9, L_1995_arg10)
	L_1990_arg5 = L_1985_arg0[1][1]
	L_1992_arg7 = L_1987_arg2
	L_1993_arg8 = L_1988_arg3
	L_1994_arg9 = L_1989_arg4
	L_1995_arg10 = false
	do
		local L_1996_ = L_1990_arg5;
		L_1991_arg6 = L_1996_;
		L_1990_arg5 = L_1996_.Notify
	end
	L_1990_arg5(L_1991_arg6, L_1992_arg7, L_1993_arg8, L_1994_arg9, L_1995_arg10)
	return
end

L_13_.fn_157_removeLoadingOverlay = function(L_1997_arg0, L_1998_arg1, L_1999_arg2, L_2000_arg3, L_2001_arg4)
	L_2000_arg3 = L_10_func(L_1998_arg1, "getgenv")
	L_2000_arg3 = L_2000_arg3()
	L_1999_arg2 = L_2000_arg3.__SnowyLoadingOverlay
	if L_1999_arg2 then
		do
			local L_2002_ = L_1999_arg2;
			L_2001_arg4 = L_2002_;
			L_2000_arg3 = L_2002_.Destroy
		end
		L_2000_arg3(L_2001_arg4)
		L_2000_arg3 = L_10_func(L_1998_arg1, "getgenv")
		L_2000_arg3 = L_2000_arg3()
		L_2001_arg4 = nil
		L_2000_arg3.__SnowyLoadingOverlay = L_2001_arg4
	end
	return
end

L_13_.fn_158 = function(L_2003_arg0, L_2004_arg1, L_2005_arg2, L_2006_arg3)
	L_2005_arg2 = L_10_func(L_2004_arg1, "pcall")
	L_2006_arg3 = L_14_func(L_13_.fn_157_removeLoadingOverlay, L_2004_arg1, {})
	L_2005_arg2(L_2006_arg3)
	return
end

L_13_.fn_159_NewToggle = function(L_2007_arg0, L_2008_arg1, L_2009_arg2)
	return
end

L_13_.fn_160_NewSection = function(L_2010_arg0, L_2011_arg1, L_2012_arg2)
	L_2012_arg2 = L_2010_arg0[1][1]
	return L_2012_arg2
end

L_13_.fn_161_NewSection = function(L_2013_arg0, L_2014_arg1, L_2015_arg2)
	L_2015_arg2 = L_2013_arg0[1][1]
	return L_2015_arg2
end

L_13_.fn_162_buildMainFeaturesTab = function(L_2016_arg0, L_2017_arg1, L_2018_arg2, L_2019_arg3, L_2020_arg4, L_2021_arg5, L_2022_arg6, L_2023_arg7, L_2024_arg8)
	L_2021_arg5 = L_2016_arg0[1][1]
	L_2020_arg4 = L_2021_arg5[L_2018_arg2]
	if not L_2020_arg4 then
		L_2021_arg5 = L_2016_arg0[3][1]
		L_2020_arg4 = L_2021_arg5.Window
		L_2022_arg6 = L_2018_arg2
		L_2023_arg7 = L_2019_arg3
		if not L_2023_arg7 then
			L_2023_arg7 = "layout"
		end
		do
			local L_2025_ = L_2020_arg4;
			L_2021_arg5 = L_2025_;
			L_2020_arg4 = L_2025_.CreateTab
		end
		L_2020_arg4 = L_2020_arg4(L_2021_arg5, L_2022_arg6, L_2023_arg7)
		L_2023_arg7 = "Main"
		L_2024_arg8 = "layout"
		do
			local L_2026_ = L_2020_arg4;
			L_2022_arg6 = L_2026_;
			L_2021_arg5 = L_2026_.CreateSubTab
		end
		L_2021_arg5 = L_2021_arg5(L_2022_arg6, L_2023_arg7, L_2024_arg8)
		L_2024_arg8 = "Features"
		do
			local L_2027_ = L_2021_arg5;
			L_2023_arg7 = L_2027_;
			L_2022_arg6 = L_2027_.CreateSection
		end
		L_2022_arg6 = L_2022_arg6(L_2023_arg7, L_2024_arg8)
		L_2023_arg7 = L_2016_arg0[1][1]
		L_2023_arg7[L_2018_arg2] = L_2020_arg4
		L_2023_arg7 = L_2016_arg0[2][1]
		L_2023_arg7[L_2018_arg2] = L_2022_arg6
		return L_2022_arg6
	else
		L_2021_arg5 = L_2016_arg0[2][1]
		L_2020_arg4 = L_2021_arg5[L_2018_arg2]
		return L_2020_arg4
	end
end

L_13_.fn_163_NewToggle = function(L_2028_arg0, L_2029_arg1, ...)
	local L_2030_ = L_1_(...)
	local L_2031_ = L_2030_.n
	local L_2032_ = {}
	local L_2033_ = {}
	local L_2034_ = 8
	local L_2035_ = 9
	for L_2042_forvar0 = 0, L_2035_ - 1 do
		L_2032_[L_2042_forvar0] = L_2030_[L_2042_forvar0 + 1]
	end
	local L_2036_ = {
		n = math.max(0, L_2031_ - L_2035_)
	}
	for L_2043_forvar0 = 1, L_2036_.n do
		L_2036_[L_2043_forvar0] = L_2030_[L_2035_ + L_2043_forvar0]
	end
	local L_2037_ = L_2031_
	local function L_2038_func(L_2044_arg0)
		local L_2045_ = L_2033_[L_2044_arg0]
		if L_2045_ ~= nil then
			return L_2045_[1]
		end
		return L_2032_[L_2044_arg0]
	end
	local function L_2039_func(L_2046_arg0, L_2047_arg1)
		local L_2048_ = L_2033_[L_2046_arg0]
		if L_2048_ ~= nil then
			L_2048_[1] = L_2047_arg1
		else
			L_2032_[L_2046_arg0] = L_2047_arg1
		end
	end
	local function L_2040_func(L_2049_arg0)
		local L_2050_ = L_2033_[L_2049_arg0]
		if L_2050_ == nil then
			L_2050_ = {
				L_2032_[L_2049_arg0]
			};
			L_2033_[L_2049_arg0] = L_2050_
		end
		return L_2050_
	end
	local function L_2041_func(L_2051_arg0, L_2052_arg1)
		local L_2053_ = {
			n = L_2052_arg1
		}
		for L_2054_forvar0 = 1, L_2052_arg1 do
			L_2053_[L_2054_forvar0] = L_2038_func(L_2051_arg0 + L_2054_forvar0 - 1)
		end
		return L_2053_
	end

	L_2039_func(4, L_2028_arg0[1][1])
	L_2039_func(6, L_2038_func(1))
	L_2039_func(7, false)
	L_2039_func(8, L_2038_func(3))
	do
		local L_2055_ = L_2038_func(4)
		L_2039_func(5, L_2055_)
		L_2039_func(4, L_2055_["CreateToggle"])
	end
	do
		local L_2056_ = 4
		local L_2057_ = L_2041_func(5, L_2056_)
		local L_2058_ = L_1_(L_2038_func(4)(L_2_(L_2057_, 1, L_2057_.n)))
		for L_2059_forvar0 = 1, L_2058_.n do
			L_2039_func(4 + L_2059_forvar0 - 1, L_2058_[L_2059_forvar0])
		end
		L_2037_ = 4 + L_2058_.n
	end
	do
		local L_2060_ = L_2037_ - 4
		if L_2060_ <= 0 then
			return
		end
		local L_2061_ = L_2041_func(4, L_2060_)
		return L_2_(L_2061_, 1, L_2061_.n)
	end
end

L_13_.fn_164_NewButton = function(L_2062_arg0, L_2063_arg1, ...)
	local L_2064_ = L_1_(...)
	local L_2065_ = L_2064_.n
	local L_2066_ = {}
	local L_2067_ = {}
	local L_2068_ = 7
	local L_2069_ = 8
	for L_2076_forvar0 = 0, L_2069_ - 1 do
		L_2066_[L_2076_forvar0] = L_2064_[L_2076_forvar0 + 1]
	end
	local L_2070_ = {
		n = math.max(0, L_2065_ - L_2069_)
	}
	for L_2077_forvar0 = 1, L_2070_.n do
		L_2070_[L_2077_forvar0] = L_2064_[L_2069_ + L_2077_forvar0]
	end
	local L_2071_ = L_2065_
	local function L_2072_func(L_2078_arg0)
		local L_2079_ = L_2067_[L_2078_arg0]
		if L_2079_ ~= nil then
			return L_2079_[1]
		end
		return L_2066_[L_2078_arg0]
	end
	local function L_2073_func(L_2080_arg0, L_2081_arg1)
		local L_2082_ = L_2067_[L_2080_arg0]
		if L_2082_ ~= nil then
			L_2082_[1] = L_2081_arg1
		else
			L_2066_[L_2080_arg0] = L_2081_arg1
		end
	end
	local function L_2074_func(L_2083_arg0)
		local L_2084_ = L_2067_[L_2083_arg0]
		if L_2084_ == nil then
			L_2084_ = {
				L_2066_[L_2083_arg0]
			};
			L_2067_[L_2083_arg0] = L_2084_
		end
		return L_2084_
	end
	local function L_2075_func(L_2085_arg0, L_2086_arg1)
		local L_2087_ = {
			n = L_2086_arg1
		}
		for L_2088_forvar0 = 1, L_2086_arg1 do
			L_2087_[L_2088_forvar0] = L_2072_func(L_2085_arg0 + L_2088_forvar0 - 1)
		end
		return L_2087_
	end

	L_2073_func(4, L_2062_arg0[1][1])
	L_2073_func(6, L_2072_func(1))
	L_2073_func(7, L_2072_func(3))
	do
		local L_2089_ = L_2072_func(4)
		L_2073_func(5, L_2089_)
		L_2073_func(4, L_2089_["CreateButton"])
	end
	do
		local L_2090_ = 3
		local L_2091_ = L_2075_func(5, L_2090_)
		local L_2092_ = L_1_(L_2072_func(4)(L_2_(L_2091_, 1, L_2091_.n)))
		for L_2093_forvar0 = 1, L_2092_.n do
			L_2073_func(4 + L_2093_forvar0 - 1, L_2092_[L_2093_forvar0])
		end
		L_2071_ = 4 + L_2092_.n
	end
	do
		local L_2094_ = L_2071_ - 4
		if L_2094_ <= 0 then
			return
		end
		local L_2095_ = L_2075_func(4, L_2094_)
		return L_2_(L_2095_, 1, L_2095_.n)
	end
end

L_13_.fn_165_NewSlider = function(L_2096_arg0, L_2097_arg1, ...)
	local L_2098_, L_2099_, L_2100_, L_2101_, L_2102_, L_2103_ = ...
	local L_2104_ = L_2096_arg0[1][1]
	local L_2105_ = L_2102_ or 0
	local L_2106_ = L_2101_ or 100
	local L_2107_ = L_2102_ or 0
	return L_2104_:CreateSlider(L_2099_, L_2105_, L_2106_, L_2107_, L_2103_)
end

L_13_.fn_166_NewDropdown = function(L_2108_arg0, L_2109_arg1, ...)
	local L_2110_ = L_1_(...)
	local L_2111_ = L_2110_.n
	local L_2112_ = {}
	local L_2113_ = {}
	local L_2114_ = 13
	local L_2115_ = 14
	for L_2122_forvar0 = 0, L_2115_ - 1 do
		L_2112_[L_2122_forvar0] = L_2110_[L_2122_forvar0 + 1]
	end
	local L_2116_ = {
		n = math.max(0, L_2111_ - L_2115_)
	}
	for L_2123_forvar0 = 1, L_2116_.n do
		L_2116_[L_2123_forvar0] = L_2110_[L_2115_ + L_2123_forvar0]
	end
	local L_2117_ = L_2111_
	local function L_2118_func(L_2124_arg0)
		local L_2125_ = L_2113_[L_2124_arg0]
		if L_2125_ ~= nil then
			return L_2125_[1]
		end
		return L_2112_[L_2124_arg0]
	end
	local function L_2119_func(L_2126_arg0, L_2127_arg1)
		local L_2128_ = L_2113_[L_2126_arg0]
		if L_2128_ ~= nil then
			L_2128_[1] = L_2127_arg1
		else
			L_2112_[L_2126_arg0] = L_2127_arg1
		end
	end
	local function L_2120_func(L_2129_arg0)
		local L_2130_ = L_2113_[L_2129_arg0]
		if L_2130_ == nil then
			L_2130_ = {
				L_2112_[L_2129_arg0]
			};
			L_2113_[L_2129_arg0] = L_2130_
		end
		return L_2130_
	end
	local function L_2121_func(L_2131_arg0, L_2132_arg1)
		local L_2133_ = {
			n = L_2132_arg1
		}
		for L_2134_forvar0 = 1, L_2132_arg1 do
			L_2133_[L_2134_forvar0] = L_2118_func(L_2131_arg0 + L_2134_forvar0 - 1)
		end
		return L_2133_
	end

	L_2119_func(5, L_2108_arg0[1][1])
	L_2119_func(6, L_2118_func(2))
	L_2119_func(7, L_2118_func(3))
	L_2119_func(8, L_2118_func(4))
	do
		local L_2135_ = 3
		local L_2136_ = L_2121_func(6, L_2135_)
		local L_2137_ = L_1_(L_2118_func(5)(L_2_(L_2136_, 1, L_2136_.n)))
		for L_2138_forvar0 = 1, 3 do
			L_2119_func(5 + L_2138_forvar0 - 1, L_2137_[L_2138_forvar0])
		end
	end
	L_2119_func(8, L_2108_arg0[2][1])
	L_2119_func(10, L_2118_func(1))
	L_2119_func(11, L_2118_func(5))
	L_2119_func(12, L_2118_func(6))
	L_2119_func(13, L_2118_func(7))
	do
		local L_2139_ = L_2118_func(8)
		L_2119_func(9, L_2139_)
		L_2119_func(8, L_2139_["CreateDropdown"])
	end
	do
		local L_2140_ = 5
		local L_2141_ = L_2121_func(9, L_2140_)
		local L_2142_ = L_1_(L_2118_func(8)(L_2_(L_2141_, 1, L_2141_.n)))
		for L_2143_forvar0 = 1, L_2142_.n do
			L_2119_func(8 + L_2143_forvar0 - 1, L_2142_[L_2143_forvar0])
		end
		L_2117_ = 8 + L_2142_.n
	end
	do
		local L_2144_ = L_2117_ - 8
		if L_2144_ <= 0 then
			return
		end
		local L_2145_ = L_2121_func(8, L_2144_)
		return L_2_(L_2145_, 1, L_2145_.n)
	end
end

L_13_.fn_167_NewLabel = function(L_2146_arg0, L_2147_arg1, ...)
	local L_2148_ = L_1_(...)
	local L_2149_ = L_2148_.n
	local L_2150_ = {}
	local L_2151_ = {}
	local L_2152_ = 4
	local L_2153_ = 5
	for L_2160_forvar0 = 0, L_2153_ - 1 do
		L_2150_[L_2160_forvar0] = L_2148_[L_2160_forvar0 + 1]
	end
	local L_2154_ = {
		n = math.max(0, L_2149_ - L_2153_)
	}
	for L_2161_forvar0 = 1, L_2154_.n do
		L_2154_[L_2161_forvar0] = L_2148_[L_2153_ + L_2161_forvar0]
	end
	local L_2155_ = L_2149_
	local function L_2156_func(L_2162_arg0)
		local L_2163_ = L_2151_[L_2162_arg0]
		if L_2163_ ~= nil then
			return L_2163_[1]
		end
		return L_2150_[L_2162_arg0]
	end
	local function L_2157_func(L_2164_arg0, L_2165_arg1)
		local L_2166_ = L_2151_[L_2164_arg0]
		if L_2166_ ~= nil then
			L_2166_[1] = L_2165_arg1
		else
			L_2150_[L_2164_arg0] = L_2165_arg1
		end
	end
	local function L_2158_func(L_2167_arg0)
		local L_2168_ = L_2151_[L_2167_arg0]
		if L_2168_ == nil then
			L_2168_ = {
				L_2150_[L_2167_arg0]
			};
			L_2151_[L_2167_arg0] = L_2168_
		end
		return L_2168_
	end
	local function L_2159_func(L_2169_arg0, L_2170_arg1)
		local L_2171_ = {
			n = L_2170_arg1
		}
		for L_2172_forvar0 = 1, L_2170_arg1 do
			L_2171_[L_2172_forvar0] = L_2156_func(L_2169_arg0 + L_2172_forvar0 - 1)
		end
		return L_2171_
	end

	L_2157_func(2, L_2146_arg0[1][1])
	L_2157_func(4, L_2156_func(1))
	do
		local L_2173_ = L_2156_func(2)
		L_2157_func(3, L_2173_)
		L_2157_func(2, L_2173_["CreateLabel"])
	end
	do
		local L_2174_ = 2
		local L_2175_ = L_2159_func(3, L_2174_)
		local L_2176_ = L_1_(L_2156_func(2)(L_2_(L_2175_, 1, L_2175_.n)))
		for L_2177_forvar0 = 1, L_2176_.n do
			L_2157_func(2 + L_2177_forvar0 - 1, L_2176_[L_2177_forvar0])
		end
		L_2155_ = 2 + L_2176_.n
	end
	do
		local L_2178_ = L_2155_ - 2
		if L_2178_ <= 0 then
			return
		end
		local L_2179_ = L_2159_func(2, L_2178_)
		return L_2_(L_2179_, 1, L_2179_.n)
	end
end

L_13_.fn_168_NewInput = function(L_2180_arg0, L_2181_arg1, ...)
	local L_2182_ = L_1_(...)
	local L_2183_ = L_2182_.n
	local L_2184_ = {}
	local L_2185_ = {}
	local L_2186_ = 8
	local L_2187_ = 9
	for L_2194_forvar0 = 0, L_2187_ - 1 do
		L_2184_[L_2194_forvar0] = L_2182_[L_2194_forvar0 + 1]
	end
	local L_2188_ = {
		n = math.max(0, L_2183_ - L_2187_)
	}
	for L_2195_forvar0 = 1, L_2188_.n do
		L_2188_[L_2195_forvar0] = L_2182_[L_2187_ + L_2195_forvar0]
	end
	local L_2189_ = L_2183_
	local function L_2190_func(L_2196_arg0)
		local L_2197_ = L_2185_[L_2196_arg0]
		if L_2197_ ~= nil then
			return L_2197_[1]
		end
		return L_2184_[L_2196_arg0]
	end
	local function L_2191_func(L_2198_arg0, L_2199_arg1)
		local L_2200_ = L_2185_[L_2198_arg0]
		if L_2200_ ~= nil then
			L_2200_[1] = L_2199_arg1
		else
			L_2184_[L_2198_arg0] = L_2199_arg1
		end
	end
	local function L_2192_func(L_2201_arg0)
		local L_2202_ = L_2185_[L_2201_arg0]
		if L_2202_ == nil then
			L_2202_ = {
				L_2184_[L_2201_arg0]
			};
			L_2185_[L_2201_arg0] = L_2202_
		end
		return L_2202_
	end
	local function L_2193_func(L_2203_arg0, L_2204_arg1)
		local L_2205_ = {
			n = L_2204_arg1
		}
		for L_2206_forvar0 = 1, L_2204_arg1 do
			L_2205_[L_2206_forvar0] = L_2190_func(L_2203_arg0 + L_2206_forvar0 - 1)
		end
		return L_2205_
	end

	L_2191_func(4, L_2180_arg0[1][1])
	L_2191_func(6, L_2190_func(1))
	L_2191_func(7, L_2190_func(2))
	L_2191_func(8, L_2190_func(3))
	do
		local L_2207_ = L_2190_func(4)
		L_2191_func(5, L_2207_)
		L_2191_func(4, L_2207_["CreateInput"])
	end
	do
		local L_2208_ = 4
		local L_2209_ = L_2193_func(5, L_2208_)
		local L_2210_ = L_1_(L_2190_func(4)(L_2_(L_2209_, 1, L_2209_.n)))
		for L_2211_forvar0 = 1, L_2210_.n do
			L_2191_func(4 + L_2211_forvar0 - 1, L_2210_[L_2211_forvar0])
		end
		L_2189_ = 4 + L_2210_.n
	end
	do
		local L_2212_ = L_2189_ - 4
		if L_2212_ <= 0 then
			return
		end
		local L_2213_ = L_2193_func(4, L_2212_)
		return L_2_(L_2213_, 1, L_2213_.n)
	end
end

L_13_.fn_169_NewTitle = function(L_2214_arg0, L_2215_arg1, ...)
	local L_2216_ = L_1_(...)
	local L_2217_ = L_2216_.n
	local L_2218_ = {}
	local L_2219_ = {}
	local L_2220_ = 6
	local L_2221_ = 7
	for L_2228_forvar0 = 0, L_2221_ - 1 do
		L_2218_[L_2228_forvar0] = L_2216_[L_2228_forvar0 + 1]
	end
	local L_2222_ = {
		n = math.max(0, L_2217_ - L_2221_)
	}
	for L_2229_forvar0 = 1, L_2222_.n do
		L_2222_[L_2229_forvar0] = L_2216_[L_2221_ + L_2229_forvar0]
	end
	local L_2223_ = L_2217_
	local function L_2224_func(L_2230_arg0)
		local L_2231_ = L_2219_[L_2230_arg0]
		if L_2231_ ~= nil then
			return L_2231_[1]
		end
		return L_2218_[L_2230_arg0]
	end
	local function L_2225_func(L_2232_arg0, L_2233_arg1)
		local L_2234_ = L_2219_[L_2232_arg0]
		if L_2234_ ~= nil then
			L_2234_[1] = L_2233_arg1
		else
			L_2218_[L_2232_arg0] = L_2233_arg1
		end
	end
	local function L_2226_func(L_2235_arg0)
		local L_2236_ = L_2219_[L_2235_arg0]
		if L_2236_ == nil then
			L_2236_ = {
				L_2218_[L_2235_arg0]
			};
			L_2219_[L_2235_arg0] = L_2236_
		end
		return L_2236_
	end
	local function L_2227_func(L_2237_arg0, L_2238_arg1)
		local L_2239_ = {
			n = L_2238_arg1
		}
		for L_2240_forvar0 = 1, L_2238_arg1 do
			L_2239_[L_2240_forvar0] = L_2224_func(L_2237_arg0 + L_2240_forvar0 - 1)
		end
		return L_2239_
	end

	L_2225_func(2, L_2214_arg0[1][1])
	L_2225_func(5, "\226\156\166 ")
	L_2225_func(6, L_2224_func(1))
	do
		local L_2241_ = L_2224_func(6)
		for L_2242_forvar0 = 5, 5, -1 do
			L_2241_ = L_2224_func(L_2242_forvar0) .. L_2241_
		end
		L_2225_func(4, L_2241_)
	end
	do
		local L_2243_ = L_2224_func(2)
		L_2225_func(3, L_2243_)
		L_2225_func(2, L_2243_["CreateLabel"])
	end
	do
		local L_2244_ = 2
		local L_2245_ = L_2227_func(3, L_2244_)
		local L_2246_ = L_1_(L_2224_func(2)(L_2_(L_2245_, 1, L_2245_.n)))
		for L_2247_forvar0 = 1, L_2246_.n do
			L_2225_func(2 + L_2247_forvar0 - 1, L_2246_[L_2247_forvar0])
		end
		L_2223_ = 2 + L_2246_.n
	end
	do
		local L_2248_ = L_2223_ - 2
		if L_2248_ <= 0 then
			return
		end
		local L_2249_ = L_2227_func(2, L_2248_)
		return L_2_(L_2249_, 1, L_2249_.n)
	end
end

L_13_.fn_170_NewSection = function(L_2250_arg0, L_2251_arg1, L_2252_arg2, L_2253_arg3)
	L_2253_arg3 = L_2250_arg0[1][1]
	return L_2253_arg3
end

L_13_.fn_171_compatSet = function(L_2254_arg0, L_2255_arg1, L_2256_arg2, L_2257_arg3, L_2258_arg4)
	L_2256_arg2 = L_2254_arg0[1][1]
	L_2258_arg4 = false
	do
		local L_2259_ = L_2256_arg2;
		L_2257_arg3 = L_2259_;
		L_2256_arg2 = L_2259_.Set
	end
	L_2256_arg2(L_2257_arg3, L_2258_arg4)
	return
end

L_13_.fn_172_compatDeferredWait = function(L_2260_arg0, L_2261_arg1, L_2262_arg2, L_2263_arg3)
	L_2262_arg2 = L_10_func(L_2261_arg1, "pcall")
	L_2263_arg3 = L_14_func(L_13_.fn_171_compatSet, L_2261_arg1, {
		L_2260_arg0[1]
	})
	L_2262_arg2(L_2263_arg3)
	L_2262_arg2 = L_10_func(L_2261_arg1, "task")
	L_2262_arg2 = L_2262_arg2.wait
	L_2262_arg2()
	L_2262_arg2 = false
	L_2260_arg0[2][1] = L_2262_arg2
	return
end

L_13_.fn_173_compatPremiumCheck = function(L_2264_arg0, L_2265_arg1, L_2266_arg2, L_2267_arg3, L_2268_arg4)
	L_2267_arg3 = L_2264_arg0[1][1]
	if not L_2267_arg3 then
		L_2267_arg3 = L_10_func(L_2265_arg1, "_isPremiumUser")
		L_2267_arg3 = L_2267_arg3()
		if not L_2267_arg3 then
			if L_2266_arg2 then
				L_2267_arg3 = L_2264_arg0[3][1]
				L_2268_arg4 = L_2264_arg0[4][1]
				L_2267_arg3(L_2268_arg4)
				L_2267_arg3 = true
				L_2264_arg0[1][1] = L_2267_arg3
				L_2267_arg3 = L_10_func(L_2265_arg1, "task")
				L_2267_arg3 = L_2267_arg3.defer
				L_2268_arg4 = L_14_func(L_13_.fn_172_compatDeferredWait, L_2265_arg1, {
					L_2264_arg0[5],
					L_2264_arg0[1]
				})
				L_2267_arg3(L_2268_arg4)
			end
		else
			L_2267_arg3 = L_2264_arg0[2][1]
			if not L_2267_arg3 then
				return
			else
				L_2267_arg3 = L_2264_arg0[2][1]
				L_2268_arg4 = L_2266_arg2
				L_2267_arg3(L_2268_arg4)
				return
			end
		end
		return
	else
		return
	end
end

L_13_.fn_174_NewPremiumToggle = function(L_2269_arg0, L_2270_arg1, ...)
	local L_2271_ = L_1_(...)
	local L_2272_ = L_2271_.n
	local L_2273_ = {}
	local L_2274_ = {}
	local L_2275_ = 10
	local L_2276_ = 11
	for L_2283_forvar0 = 0, L_2276_ - 1 do
		L_2273_[L_2283_forvar0] = L_2271_[L_2283_forvar0 + 1]
	end
	local L_2277_ = {
		n = math.max(0, L_2272_ - L_2276_)
	}
	for L_2284_forvar0 = 1, L_2277_.n do
		L_2277_[L_2284_forvar0] = L_2271_[L_2276_ + L_2284_forvar0]
	end
	local L_2278_ = L_2272_
	local function L_2279_func(L_2285_arg0)
		local L_2286_ = L_2274_[L_2285_arg0]
		if L_2286_ ~= nil then
			return L_2286_[1]
		end
		return L_2273_[L_2285_arg0]
	end
	local function L_2280_func(L_2287_arg0, L_2288_arg1)
		local L_2289_ = L_2274_[L_2287_arg0]
		if L_2289_ ~= nil then
			L_2289_[1] = L_2288_arg1
		else
			L_2273_[L_2287_arg0] = L_2288_arg1
		end
	end
	local function L_2281_func(L_2290_arg0)
		local L_2291_ = L_2274_[L_2290_arg0]
		if L_2291_ == nil then
			L_2291_ = {
				L_2273_[L_2290_arg0]
			};
			L_2274_[L_2290_arg0] = L_2291_
		end
		return L_2291_
	end
	local function L_2282_func(L_2292_arg0, L_2293_arg1)
		local L_2294_ = {
			n = L_2293_arg1
		}
		for L_2295_forvar0 = 1, L_2293_arg1 do
			L_2294_[L_2295_forvar0] = L_2279_func(L_2292_arg0 + L_2295_forvar0 - 1)
		end
		return L_2294_
	end

	L_2280_func(4, nil)
	L_2280_func(5, false)
	L_2280_func(6, L_2269_arg0[1][1])
	L_2280_func(8, L_10_func(L_2270_arg1, "_premTag"))
	L_2280_func(9, L_2279_func(1))
	do
		local L_2296_ = 1
		local L_2297_ = L_2282_func(9, L_2296_)
		local L_2298_ = L_1_(L_2279_func(8)(L_2_(L_2297_, 1, L_2297_.n)))
		for L_2299_forvar0 = 1, 1 do
			L_2280_func(8 + L_2299_forvar0 - 1, L_2298_[L_2299_forvar0])
		end
	end
	L_2280_func(9, false)
	do
		local L_2300_ = {}
		L_2300_[1] = L_2281_func(5)
		L_2300_[2] = {
			L_2279_func(3)
		}
		L_2300_[3] = L_2269_arg0[2]
		L_2300_[4] = {
			L_2279_func(1)
		}
		L_2300_[5] = L_2281_func(4)
		local L_2301_ = {
			L_2270_arg1 and L_2270_arg1[1] or nil
		}
		local L_2302_
		L_2302_ = function(...)
			return L_13_.fn_173_compatPremiumCheck(L_2300_, L_2301_, ...)
		end
		L_6_[L_2302_] = L_2301_
		L_2280_func(10, L_2302_)
	end
	do
		local L_2303_ = L_2279_func(6)
		L_2280_func(7, L_2303_)
		L_2280_func(6, L_2303_["CreateToggle"])
	end
	do
		local L_2304_ = 4
		local L_2305_ = L_2282_func(7, L_2304_)
		local L_2306_ = L_1_(L_2279_func(6)(L_2_(L_2305_, 1, L_2305_.n)))
		for L_2307_forvar0 = 1, 1 do
			L_2280_func(6 + L_2307_forvar0 - 1, L_2306_[L_2307_forvar0])
		end
	end
	L_2280_func(4, L_2279_func(6))
	for L_2308_forvar0 = 4, L_2275_ do
		local L_2309_ = L_2274_[L_2308_forvar0]
		if L_2309_ ~= nil then
			L_2273_[L_2308_forvar0] = L_2309_[1]
			L_2274_[L_2308_forvar0] = nil
		end
	end
	do
		local L_2310_ = L_2282_func(4, 1);
		return L_2_(L_2310_, 1, L_2310_.n)
	end
end

L_13_.fn_175_compatPremiumToggleGate = function(L_2311_arg0, L_2312_arg1, L_2313_arg2, L_2314_arg3)
	L_2313_arg2 = L_10_func(L_2312_arg1, "_isPremiumUser")
	L_2313_arg2 = L_2313_arg2()
	if not L_2313_arg2 then
		L_2313_arg2 = L_2311_arg0[2][1]
		L_2314_arg3 = L_2311_arg0[3][1]
		L_2313_arg2(L_2314_arg3)
	else
		L_2313_arg2 = L_2311_arg0[1][1]
		if not L_2313_arg2 then
			return
		else
			L_2313_arg2 = L_2311_arg0[1][1]
			L_2313_arg2()
			return
		end
	end
	return
end

L_13_.fn_176_NewPremiumButton = function(L_2315_arg0, L_2316_arg1, ...)
	local L_2317_ = L_1_(...)
	local L_2318_ = L_2317_.n
	local L_2319_ = {}
	local L_2320_ = {}
	local L_2321_ = 7
	local L_2322_ = 8
	for L_2329_forvar0 = 0, L_2322_ - 1 do
		L_2319_[L_2329_forvar0] = L_2317_[L_2329_forvar0 + 1]
	end
	local L_2323_ = {
		n = math.max(0, L_2318_ - L_2322_)
	}
	for L_2330_forvar0 = 1, L_2323_.n do
		L_2323_[L_2330_forvar0] = L_2317_[L_2322_ + L_2330_forvar0]
	end
	local L_2324_ = L_2318_
	local function L_2325_func(L_2331_arg0)
		local L_2332_ = L_2320_[L_2331_arg0]
		if L_2332_ ~= nil then
			return L_2332_[1]
		end
		return L_2319_[L_2331_arg0]
	end
	local function L_2326_func(L_2333_arg0, L_2334_arg1)
		local L_2335_ = L_2320_[L_2333_arg0]
		if L_2335_ ~= nil then
			L_2335_[1] = L_2334_arg1
		else
			L_2319_[L_2333_arg0] = L_2334_arg1
		end
	end
	local function L_2327_func(L_2336_arg0)
		local L_2337_ = L_2320_[L_2336_arg0]
		if L_2337_ == nil then
			L_2337_ = {
				L_2319_[L_2336_arg0]
			};
			L_2320_[L_2336_arg0] = L_2337_
		end
		return L_2337_
	end
	local function L_2328_func(L_2338_arg0, L_2339_arg1)
		local L_2340_ = {
			n = L_2339_arg1
		}
		for L_2341_forvar0 = 1, L_2339_arg1 do
			L_2340_[L_2341_forvar0] = L_2325_func(L_2338_arg0 + L_2341_forvar0 - 1)
		end
		return L_2340_
	end

	L_2326_func(4, L_2315_arg0[1][1])
	L_2326_func(6, L_10_func(L_2316_arg1, "_premTag"))
	L_2326_func(7, L_2325_func(1))
	do
		local L_2342_ = 1
		local L_2343_ = L_2328_func(7, L_2342_)
		local L_2344_ = L_1_(L_2325_func(6)(L_2_(L_2343_, 1, L_2343_.n)))
		for L_2345_forvar0 = 1, 1 do
			L_2326_func(6 + L_2345_forvar0 - 1, L_2344_[L_2345_forvar0])
		end
	end
	do
		local L_2346_ = {}
		L_2346_[1] = {
			L_2325_func(3)
		}
		L_2346_[2] = L_2315_arg0[2]
		L_2346_[3] = {
			L_2325_func(1)
		}
		local L_2347_ = {
			L_2316_arg1 and L_2316_arg1[1] or nil
		}
		local L_2348_
		L_2348_ = function(...)
			return L_13_.fn_175_compatPremiumToggleGate(L_2346_, L_2347_, ...)
		end
		L_6_[L_2348_] = L_2347_
		L_2326_func(7, L_2348_)
	end
	do
		local L_2349_ = L_2325_func(4)
		L_2326_func(5, L_2349_)
		L_2326_func(4, L_2349_["CreateButton"])
	end
	do
		local L_2350_ = 3
		local L_2351_ = L_2328_func(5, L_2350_)
		local L_2352_ = L_1_(L_2325_func(4)(L_2_(L_2351_, 1, L_2351_.n)))
		for L_2353_forvar0 = 1, L_2352_.n do
			L_2326_func(4 + L_2353_forvar0 - 1, L_2352_[L_2353_forvar0])
		end
		L_2324_ = 4 + L_2352_.n
	end
	do
		local L_2354_ = L_2324_ - 4
		if L_2354_ <= 0 then
			return
		end
		local L_2355_ = L_2328_func(4, L_2354_)
		return L_2_(L_2355_, 1, L_2355_.n)
	end
end

L_13_.fn_177_compatPremiumButtonGate = function(L_2356_arg0, L_2357_arg1, L_2358_arg2, L_2359_arg3, L_2360_arg4)
	L_2359_arg3 = L_10_func(L_2357_arg1, "_isPremiumUser")
	L_2359_arg3 = L_2359_arg3()
	if not L_2359_arg3 then
		L_2359_arg3 = L_2356_arg0[2][1]
		L_2360_arg4 = L_2356_arg0[3][1]
		L_2359_arg3(L_2360_arg4)
	else
		L_2359_arg3 = L_2356_arg0[1][1]
		if not L_2359_arg3 then
			return
		else
			L_2359_arg3 = L_2356_arg0[1][1]
			L_2360_arg4 = L_2358_arg2
			L_2359_arg3(L_2360_arg4)
			return
		end
	end
	return
end

L_13_.fn_178_NewPremiumSlider = function(L_2361_arg0, L_2362_arg1, ...)
	local L_2363_, L_2364_, L_2365_, L_2366_, L_2367_, L_2368_ = ...
	local L_2369_ = L_2361_arg0[1][1]
	local L_2370_ = L_10_func(L_2362_arg1, "_premTag")(L_2364_)
	local L_2371_ = L_2367_ or 0
	local L_2372_ = L_2366_ or 100
	local L_2373_ = L_2367_ or 0
	local L_2374_ = L_14_func(
        L_13_.fn_177_compatPremiumButtonGate,
        L_2362_arg1,
        {
		{
			L_2368_
		},
		L_2361_arg0[2],
		{
			L_2364_
		}
	}
    )
	return L_2369_:CreateSlider(L_2370_, L_2371_, L_2372_, L_2373_, L_2374_)
end

L_13_.fn_179_compatPremiumSliderGate = function(L_2375_arg0, L_2376_arg1, L_2377_arg2, L_2378_arg3, L_2379_arg4)
	L_2378_arg3 = L_10_func(L_2376_arg1, "_isPremiumUser")
	L_2378_arg3 = L_2378_arg3()
	if not L_2378_arg3 then
		L_2378_arg3 = L_2375_arg0[2][1]
		L_2379_arg4 = L_2375_arg0[3][1]
		L_2378_arg3(L_2379_arg4)
	else
		L_2378_arg3 = L_2375_arg0[1][1]
		if not L_2378_arg3 then
			return
		else
			L_2378_arg3 = L_2375_arg0[1][1]
			L_2379_arg4 = L_2377_arg2
			L_2378_arg3(L_2379_arg4)
			return
		end
	end
	return
end

L_13_.fn_180_NewPremiumDropdown = function(L_2380_arg0, L_2381_arg1, ...)
	local L_2382_ = L_1_(...)
	local L_2383_ = L_2382_.n
	local L_2384_ = {}
	local L_2385_ = {}
	local L_2386_ = 13
	local L_2387_ = 14
	for L_2394_forvar0 = 0, L_2387_ - 1 do
		L_2384_[L_2394_forvar0] = L_2382_[L_2394_forvar0 + 1]
	end
	local L_2388_ = {
		n = math.max(0, L_2383_ - L_2387_)
	}
	for L_2395_forvar0 = 1, L_2388_.n do
		L_2388_[L_2395_forvar0] = L_2382_[L_2387_ + L_2395_forvar0]
	end
	local L_2389_ = L_2383_
	local function L_2390_func(L_2396_arg0)
		local L_2397_ = L_2385_[L_2396_arg0]
		if L_2397_ ~= nil then
			return L_2397_[1]
		end
		return L_2384_[L_2396_arg0]
	end
	local function L_2391_func(L_2398_arg0, L_2399_arg1)
		local L_2400_ = L_2385_[L_2398_arg0]
		if L_2400_ ~= nil then
			L_2400_[1] = L_2399_arg1
		else
			L_2384_[L_2398_arg0] = L_2399_arg1
		end
	end
	local function L_2392_func(L_2401_arg0)
		local L_2402_ = L_2385_[L_2401_arg0]
		if L_2402_ == nil then
			L_2402_ = {
				L_2384_[L_2401_arg0]
			};
			L_2385_[L_2401_arg0] = L_2402_
		end
		return L_2402_
	end
	local function L_2393_func(L_2403_arg0, L_2404_arg1)
		local L_2405_ = {
			n = L_2404_arg1
		}
		for L_2406_forvar0 = 1, L_2404_arg1 do
			L_2405_[L_2406_forvar0] = L_2390_func(L_2403_arg0 + L_2406_forvar0 - 1)
		end
		return L_2405_
	end

	L_2391_func(5, L_2380_arg0[1][1])
	L_2391_func(6, L_2390_func(2))
	L_2391_func(7, L_2390_func(3))
	L_2391_func(8, L_2390_func(4))
	do
		local L_2407_ = 3
		local L_2408_ = L_2393_func(6, L_2407_)
		local L_2409_ = L_1_(L_2390_func(5)(L_2_(L_2408_, 1, L_2408_.n)))
		for L_2410_forvar0 = 1, 3 do
			L_2391_func(5 + L_2410_forvar0 - 1, L_2409_[L_2410_forvar0])
		end
	end
	L_2391_func(8, L_2380_arg0[2][1])
	L_2391_func(10, L_10_func(L_2381_arg1, "_premTag"))
	L_2391_func(11, L_2390_func(1))
	do
		local L_2411_ = 1
		local L_2412_ = L_2393_func(11, L_2411_)
		local L_2413_ = L_1_(L_2390_func(10)(L_2_(L_2412_, 1, L_2412_.n)))
		for L_2414_forvar0 = 1, 1 do
			L_2391_func(10 + L_2414_forvar0 - 1, L_2413_[L_2414_forvar0])
		end
	end
	L_2391_func(11, L_2390_func(5))
	L_2391_func(12, L_2390_func(6))
	do
		local L_2415_ = {}
		L_2415_[1] = {
			L_2390_func(7)
		}
		L_2415_[2] = L_2380_arg0[3]
		L_2415_[3] = {
			L_2390_func(1)
		}
		local L_2416_ = {
			L_2381_arg1 and L_2381_arg1[1] or nil
		}
		local L_2417_
		L_2417_ = function(...)
			return L_13_.fn_179_compatPremiumSliderGate(L_2415_, L_2416_, ...)
		end
		L_6_[L_2417_] = L_2416_
		L_2391_func(13, L_2417_)
	end
	do
		local L_2418_ = L_2390_func(8)
		L_2391_func(9, L_2418_)
		L_2391_func(8, L_2418_["CreateDropdown"])
	end
	do
		local L_2419_ = 5
		local L_2420_ = L_2393_func(9, L_2419_)
		local L_2421_ = L_1_(L_2390_func(8)(L_2_(L_2420_, 1, L_2420_.n)))
		for L_2422_forvar0 = 1, L_2421_.n do
			L_2391_func(8 + L_2422_forvar0 - 1, L_2421_[L_2422_forvar0])
		end
		L_2389_ = 8 + L_2421_.n
	end
	do
		local L_2423_ = L_2389_ - 8
		if L_2423_ <= 0 then
			return
		end
		local L_2424_ = L_2393_func(8, L_2423_)
		return L_2_(L_2424_, 1, L_2424_.n)
	end
end

L_13_.fn_181_NewSection = function(L_2425_arg0, L_2426_arg1, L_2427_arg2, L_2428_arg3, L_2429_arg4, L_2430_arg5, L_2431_arg6, L_2432_arg7, L_2433_arg8, L_2434_arg9, L_2435_arg10, L_2436_arg11, L_2437_arg12, L_2438_arg13, L_2439_arg14, L_2440_arg15)
	L_2429_arg4 = L_2428_arg3
	if not L_2429_arg4 then
		L_2429_arg4 = "General"
	end
	do
		local L_2441_ = L_2429_arg4;
		L_2431_arg6 = L_2441_;
		L_2430_arg5 = L_2441_.lower
	end
	L_2430_arg5 = L_2430_arg5(L_2431_arg6)
	L_2431_arg6 = "General"
	L_2432_arg7 = "globe"
	L_2435_arg10 = "free feat"
	do
		local L_2442_ = L_2430_arg5;
		L_2434_arg9 = L_2442_;
		L_2433_arg8 = L_2442_.find
	end
	L_2433_arg8 = L_2433_arg8(L_2434_arg9, L_2435_arg10)
	if not L_2433_arg8 then
		L_2435_arg10 = "premium feat"
		do
			local L_2443_ = L_2430_arg5;
			L_2434_arg9 = L_2443_;
			L_2433_arg8 = L_2443_.find
		end
		L_2433_arg8 = L_2433_arg8(L_2434_arg9, L_2435_arg10)
		if not L_2433_arg8 then
			L_2435_arg10 = "combat"
			do
				local L_2444_ = L_2430_arg5;
				L_2434_arg9 = L_2444_;
				L_2433_arg8 = L_2444_.find
			end
			L_2433_arg8 = L_2433_arg8(L_2434_arg9, L_2435_arg10)
			if not L_2433_arg8 then
				L_2435_arg10 = "aimbot"
				do
					local L_2445_ = L_2430_arg5;
					L_2434_arg9 = L_2445_;
					L_2433_arg8 = L_2445_.find
				end
				L_2433_arg8 = L_2433_arg8(L_2434_arg9, L_2435_arg10)
				if not L_2433_arg8 then
					L_2435_arg10 = "aim"
					do
						local L_2446_ = L_2430_arg5;
						L_2434_arg9 = L_2446_;
						L_2433_arg8 = L_2446_.find
					end
					L_2433_arg8 = L_2433_arg8(L_2434_arg9, L_2435_arg10)
					if not L_2433_arg8 then
						L_2435_arg10 = "weapon"
						do
							local L_2447_ = L_2430_arg5;
							L_2434_arg9 = L_2447_;
							L_2433_arg8 = L_2447_.find
						end
						L_2433_arg8 = L_2433_arg8(L_2434_arg9, L_2435_arg10)
						if not L_2433_arg8 then
							L_2435_arg10 = "gun"
							do
								local L_2448_ = L_2430_arg5;
								L_2434_arg9 = L_2448_;
								L_2433_arg8 = L_2448_.find
							end
							L_2433_arg8 = L_2433_arg8(L_2434_arg9, L_2435_arg10)
							if not L_2433_arg8 then
								L_2435_arg10 = "silent"
								do
									local L_2449_ = L_2430_arg5;
									L_2434_arg9 = L_2449_;
									L_2433_arg8 = L_2449_.find
								end
								L_2433_arg8 = L_2433_arg8(L_2434_arg9, L_2435_arg10)
								if not L_2433_arg8 then
									L_2435_arg10 = "aura"
									do
										local L_2450_ = L_2430_arg5;
										L_2434_arg9 = L_2450_;
										L_2433_arg8 = L_2450_.find
									end
									L_2433_arg8 = L_2433_arg8(L_2434_arg9, L_2435_arg10)
									if not L_2433_arg8 then
										L_2435_arg10 = "esp"
										do
											local L_2451_ = L_2430_arg5;
											L_2434_arg9 = L_2451_;
											L_2433_arg8 = L_2451_.find
										end
										L_2433_arg8 = L_2433_arg8(L_2434_arg9, L_2435_arg10)
										if not L_2433_arg8 then
											L_2435_arg10 = "visual"
											do
												local L_2452_ = L_2430_arg5;
												L_2434_arg9 = L_2452_;
												L_2433_arg8 = L_2452_.find
											end
											L_2433_arg8 = L_2433_arg8(L_2434_arg9, L_2435_arg10)
											if not L_2433_arg8 then
												L_2435_arg10 = "wallhack"
												do
													local L_2453_ = L_2430_arg5;
													L_2434_arg9 = L_2453_;
													L_2433_arg8 = L_2453_.find
												end
												L_2433_arg8 = L_2433_arg8(L_2434_arg9, L_2435_arg10)
												if not L_2433_arg8 then
													L_2435_arg10 = "radar"
													do
														local L_2454_ = L_2430_arg5;
														L_2434_arg9 = L_2454_;
														L_2433_arg8 = L_2454_.find
													end
													L_2433_arg8 = L_2433_arg8(L_2434_arg9, L_2435_arg10)
													if not L_2433_arg8 then
														L_2435_arg10 = "chams"
														do
															local L_2455_ = L_2430_arg5;
															L_2434_arg9 = L_2455_;
															L_2433_arg8 = L_2455_.find
														end
														L_2433_arg8 = L_2433_arg8(L_2434_arg9, L_2435_arg10)
														if not L_2433_arg8 then
															L_2435_arg10 = "render"
															do
																local L_2456_ = L_2430_arg5;
																L_2434_arg9 = L_2456_;
																L_2433_arg8 = L_2456_.find
															end
															L_2433_arg8 = L_2433_arg8(L_2434_arg9, L_2435_arg10)
															if not L_2433_arg8 then
																L_2435_arg10 = "move"
																do
																	local L_2457_ = L_2430_arg5;
																	L_2434_arg9 = L_2457_;
																	L_2433_arg8 = L_2457_.find
																end
																L_2433_arg8 = L_2433_arg8(L_2434_arg9, L_2435_arg10)
																if not L_2433_arg8 then
																	L_2435_arg10 = "fly"
																	do
																		local L_2458_ = L_2430_arg5;
																		L_2434_arg9 = L_2458_;
																		L_2433_arg8 = L_2458_.find
																	end
																	L_2433_arg8 = L_2433_arg8(L_2434_arg9, L_2435_arg10)
																	if not L_2433_arg8 then
																		L_2435_arg10 = "speed"
																		do
																			local L_2459_ = L_2430_arg5;
																			L_2434_arg9 = L_2459_;
																			L_2433_arg8 = L_2459_.find
																		end
																		L_2433_arg8 = L_2433_arg8(L_2434_arg9, L_2435_arg10)
																		if not L_2433_arg8 then
																			L_2435_arg10 = "noclip"
																			do
																				local L_2460_ = L_2430_arg5;
																				L_2434_arg9 = L_2460_;
																				L_2433_arg8 = L_2460_.find
																			end
																			L_2433_arg8 = L_2433_arg8(L_2434_arg9, L_2435_arg10)
																			if not L_2433_arg8 then
																				L_2435_arg10 = "jump"
																				do
																					local L_2461_ = L_2430_arg5;
																					L_2434_arg9 = L_2461_;
																					L_2433_arg8 = L_2461_.find
																				end
																				L_2433_arg8 = L_2433_arg8(L_2434_arg9, L_2435_arg10)
																				if not L_2433_arg8 then
																					L_2435_arg10 = "travel"
																					do
																						local L_2462_ = L_2430_arg5;
																						L_2434_arg9 = L_2462_;
																						L_2433_arg8 = L_2462_.find
																					end
																					L_2433_arg8 = L_2433_arg8(L_2434_arg9, L_2435_arg10)
																					if not L_2433_arg8 then
																						L_2435_arg10 = "tp"
																						do
																							local L_2463_ = L_2430_arg5;
																							L_2434_arg9 = L_2463_;
																							L_2433_arg8 = L_2463_.find
																						end
																						L_2433_arg8 = L_2433_arg8(L_2434_arg9, L_2435_arg10)
																						if not L_2433_arg8 then
																							L_2435_arg10 = "teleport"
																							do
																								local L_2464_ = L_2430_arg5;
																								L_2434_arg9 = L_2464_;
																								L_2433_arg8 = L_2464_.find
																							end
																							L_2433_arg8 = L_2433_arg8(L_2434_arg9, L_2435_arg10)
																							if not L_2433_arg8 then
																								L_2435_arg10 = "farm"
																								do
																									local L_2465_ = L_2430_arg5;
																									L_2434_arg9 = L_2465_;
																									L_2433_arg8 = L_2465_.find
																								end
																								L_2433_arg8 = L_2433_arg8(L_2434_arg9, L_2435_arg10)
																								if not L_2433_arg8 then
																									L_2435_arg10 = "auto"
																									do
																										local L_2466_ = L_2430_arg5;
																										L_2434_arg9 = L_2466_;
																										L_2433_arg8 = L_2466_.find
																									end
																									L_2433_arg8 = L_2433_arg8(L_2434_arg9, L_2435_arg10)
																									if not L_2433_arg8 then
																										L_2435_arg10 = "fish"
																										do
																											local L_2467_ = L_2430_arg5;
																											L_2434_arg9 = L_2467_;
																											L_2433_arg8 = L_2467_.find
																										end
																										L_2433_arg8 = L_2433_arg8(L_2434_arg9, L_2435_arg10)
																										if not L_2433_arg8 then
																											L_2435_arg10 = "chest"
																											do
																												local L_2468_ = L_2430_arg5;
																												L_2434_arg9 = L_2468_;
																												L_2433_arg8 = L_2468_.find
																											end
																											L_2433_arg8 = L_2433_arg8(L_2434_arg9, L_2435_arg10)
																											if not L_2433_arg8 then
																												L_2435_arg10 = "collect"
																												do
																													local L_2469_ = L_2430_arg5;
																													L_2434_arg9 = L_2469_;
																													L_2433_arg8 = L_2469_.find
																												end
																												L_2433_arg8 = L_2433_arg8(L_2434_arg9, L_2435_arg10)
																												if not L_2433_arg8 then
																													L_2435_arg10 = "resource"
																													do
																														local L_2470_ = L_2430_arg5;
																														L_2434_arg9 = L_2470_;
																														L_2433_arg8 = L_2470_.find
																													end
																													L_2433_arg8 = L_2433_arg8(L_2434_arg9, L_2435_arg10)
																													if not L_2433_arg8 then
																														L_2435_arg10 = "survival"
																														do
																															local L_2471_ = L_2430_arg5;
																															L_2434_arg9 = L_2471_;
																															L_2433_arg8 = L_2471_.find
																														end
																														L_2433_arg8 = L_2433_arg8(L_2434_arg9, L_2435_arg10)
																														if not L_2433_arg8 then
																															L_2435_arg10 = "god"
																															do
																																local L_2472_ = L_2430_arg5;
																																L_2434_arg9 = L_2472_;
																																L_2433_arg8 = L_2472_.find
																															end
																															L_2433_arg8 = L_2433_arg8(L_2434_arg9, L_2435_arg10)
																															if not L_2433_arg8 then
																																L_2435_arg10 = "oxygen"
																																do
																																	local L_2473_ = L_2430_arg5;
																																	L_2434_arg9 = L_2473_;
																																	L_2433_arg8 = L_2473_.find
																																end
																																L_2433_arg8 = L_2433_arg8(L_2434_arg9, L_2435_arg10)
																																if not L_2433_arg8 then
																																	L_2435_arg10 = "survive"
																																	do
																																		local L_2474_ = L_2430_arg5;
																																		L_2434_arg9 = L_2474_;
																																		L_2433_arg8 = L_2474_.find
																																	end
																																	L_2433_arg8 = L_2433_arg8(L_2434_arg9, L_2435_arg10)
																																	if not L_2433_arg8 then
																																		L_2435_arg10 = "anti"
																																		do
																																			local L_2475_ = L_2430_arg5;
																																			L_2434_arg9 = L_2475_;
																																			L_2433_arg8 = L_2475_.find
																																		end
																																		L_2433_arg8 = L_2433_arg8(L_2434_arg9, L_2435_arg10)
																																		if not L_2433_arg8 then
																																			L_2435_arg10 = "troll"
																																			do
																																				local L_2476_ = L_2430_arg5;
																																				L_2434_arg9 = L_2476_;
																																				L_2433_arg8 = L_2476_.find
																																			end
																																			L_2433_arg8 = L_2433_arg8(L_2434_arg9, L_2435_arg10)
																																			if not L_2433_arg8 then
																																				L_2435_arg10 = "rage"
																																				do
																																					local L_2477_ = L_2430_arg5;
																																					L_2434_arg9 = L_2477_;
																																					L_2433_arg8 = L_2477_.find
																																				end
																																				L_2433_arg8 = L_2433_arg8(L_2434_arg9, L_2435_arg10)
																																				if not L_2433_arg8 then
																																					L_2435_arg10 = "hitbox"
																																					do
																																						local L_2478_ = L_2430_arg5;
																																						L_2434_arg9 = L_2478_;
																																						L_2433_arg8 = L_2478_.find
																																					end
																																					L_2433_arg8 = L_2433_arg8(L_2434_arg9, L_2435_arg10)
																																					if not L_2433_arg8 then
																																						L_2435_arg10 = "misc"
																																						do
																																							local L_2479_ = L_2430_arg5;
																																							L_2434_arg9 = L_2479_;
																																							L_2433_arg8 = L_2479_.find
																																						end
																																						L_2433_arg8 = L_2433_arg8(L_2434_arg9, L_2435_arg10)
																																						if not L_2433_arg8 then
																																							L_2435_arg10 = "util"
																																							do
																																								local L_2480_ = L_2430_arg5;
																																								L_2434_arg9 = L_2480_;
																																								L_2433_arg8 = L_2480_.find
																																							end
																																							L_2433_arg8 = L_2433_arg8(L_2434_arg9, L_2435_arg10)
																																							if not L_2433_arg8 then
																																								L_2435_arg10 = "extra"
																																								do
																																									local L_2481_ = L_2430_arg5;
																																									L_2434_arg9 = L_2481_;
																																									L_2433_arg8 = L_2481_.find
																																								end
																																								L_2433_arg8 = L_2433_arg8(L_2434_arg9, L_2435_arg10)
																																								if not L_2433_arg8 then
																																									L_2435_arg10 = "general"
																																									do
																																										local L_2482_ = L_2430_arg5;
																																										L_2434_arg9 = L_2482_;
																																										L_2433_arg8 = L_2482_.find
																																									end
																																									L_2433_arg8 = L_2433_arg8(L_2434_arg9, L_2435_arg10)
																																									if not L_2433_arg8 then
																																										L_2435_arg10 = "server"
																																										do
																																											local L_2483_ = L_2430_arg5;
																																											L_2434_arg9 = L_2483_;
																																											L_2433_arg8 = L_2483_.find
																																										end
																																										L_2433_arg8 = L_2433_arg8(L_2434_arg9, L_2435_arg10)
																																										if not L_2433_arg8 then
																																											L_2435_arg10 = "economy"
																																											do
																																												local L_2484_ = L_2430_arg5;
																																												L_2434_arg9 = L_2484_;
																																												L_2433_arg8 = L_2484_.find
																																											end
																																											L_2433_arg8 = L_2433_arg8(L_2434_arg9, L_2435_arg10)
																																											if not L_2433_arg8 then
																																												L_2435_arg10 = "money"
																																												do
																																													local L_2485_ = L_2430_arg5;
																																													L_2434_arg9 = L_2485_;
																																													L_2433_arg8 = L_2485_.find
																																												end
																																												L_2433_arg8 = L_2433_arg8(L_2434_arg9, L_2435_arg10)
																																												if not L_2433_arg8 then
																																													L_2435_arg10 = "shop"
																																													do
																																														local L_2486_ = L_2430_arg5;
																																														L_2434_arg9 = L_2486_;
																																														L_2433_arg8 = L_2486_.find
																																													end
																																													L_2433_arg8 = L_2433_arg8(L_2434_arg9, L_2435_arg10)
																																													if not L_2433_arg8 then
																																														L_2435_arg10 = "belt"
																																														do
																																															local L_2487_ = L_2430_arg5;
																																															L_2434_arg9 = L_2487_;
																																															L_2433_arg8 = L_2487_.find
																																														end
																																														L_2433_arg8 = L_2433_arg8(L_2434_arg9, L_2435_arg10)
																																														if not L_2433_arg8 then
																																															L_2435_arg10 = "tank"
																																															do
																																																local L_2488_ = L_2430_arg5;
																																																L_2434_arg9 = L_2488_;
																																																L_2433_arg8 = L_2488_.find
																																															end
																																															L_2433_arg8 = L_2433_arg8(L_2434_arg9, L_2435_arg10)
																																															if not L_2433_arg8 then
																																																L_2435_arg10 = "slot"
																																																do
																																																	local L_2489_ = L_2430_arg5;
																																																	L_2434_arg9 = L_2489_;
																																																	L_2433_arg8 = L_2489_.find
																																																end
																																																L_2433_arg8 = L_2433_arg8(L_2434_arg9, L_2435_arg10)
																																																if L_2433_arg8 then
																																																	L_2431_arg6 = "Slots"
																																																	L_2432_arg7 = "layout"
																																																end
																																															else
																																																L_2431_arg6 = "Tanks"
																																																L_2432_arg7 = "layout"
																																															end
																																														else
																																															L_2431_arg6 = "Belts"
																																															L_2432_arg7 = "layout"
																																														end
																																													else
																																														L_2431_arg6 = "Economy"
																																														L_2432_arg7 = "bar-chart-2"
																																													end
																																													L_2434_arg9 = L_2431_arg6
																																													L_2435_arg10 = L_2432_arg7
																																													L_2437_arg12 = L_2425_arg0[1][1]
																																													L_2436_arg11 = L_2437_arg12[L_2434_arg9]
																																													if not L_2436_arg11 then
																																														L_2437_arg12 = L_2425_arg0[3][1]
																																														L_2436_arg11 = L_2437_arg12.Window
																																														L_2438_arg13 = L_2434_arg9
																																														L_2439_arg14 = L_2435_arg10
																																														if not L_2439_arg14 then
																																															L_2439_arg14 = "layout"
																																														end
																																														do
																																															local L_2490_ = L_2436_arg11;
																																															L_2437_arg12 = L_2490_;
																																															L_2436_arg11 = L_2490_.CreateTab
																																														end
																																														L_2436_arg11 = L_2436_arg11(L_2437_arg12, L_2438_arg13, L_2439_arg14)
																																														L_2439_arg14 = "Main"
																																														L_2440_arg15 = "layout"
																																														do
																																															local L_2491_ = L_2436_arg11;
																																															L_2438_arg13 = L_2491_;
																																															L_2437_arg12 = L_2491_.CreateSubTab
																																														end
																																														L_2437_arg12 = L_2437_arg12(L_2438_arg13, L_2439_arg14, L_2440_arg15)
																																														L_2440_arg15 = "Features"
																																														do
																																															local L_2492_ = L_2437_arg12;
																																															L_2439_arg14 = L_2492_;
																																															L_2438_arg13 = L_2492_.CreateSection
																																														end
																																														L_2438_arg13 = L_2438_arg13(L_2439_arg14, L_2440_arg15)
																																														L_2439_arg14 = L_2425_arg0[1][1]
																																														L_2439_arg14[L_2434_arg9] = L_2436_arg11
																																														L_2439_arg14 = L_2425_arg0[2][1]
																																														L_2439_arg14[L_2434_arg9] = L_2438_arg13
																																														L_2433_arg8 = L_2438_arg13
																																													else
																																														L_2436_arg11 = L_2425_arg0[2][1]
																																														L_2433_arg8 = L_2436_arg11[L_2434_arg9]
																																													end
																																													L_2437_arg12 = "\226\148\128\226\148\128 "
																																													L_2438_arg13 = L_2429_arg4
																																													L_2439_arg14 = " \226\148\128\226\148\128"
																																													L_2436_arg11 = L_2437_arg12 .. L_2438_arg13 .. L_2439_arg14
																																													do
																																														local L_2493_ = L_2433_arg8;
																																														L_2435_arg10 = L_2493_;
																																														L_2434_arg9 = L_2493_.CreateLabel
																																													end
																																													L_2434_arg9(L_2435_arg10, L_2436_arg11)
																																													L_2434_arg9 = {}
																																													L_2435_arg10 = L_14_func(L_13_.fn_163_NewToggle, L_2426_arg1, {
																																														{
																																															L_2433_arg8
																																														}
																																													})
																																													L_2434_arg9.NewToggle = L_2435_arg10
																																													L_2435_arg10 = L_14_func(L_13_.fn_164_NewButton, L_2426_arg1, {
																																														{
																																															L_2433_arg8
																																														}
																																													})
																																													L_2434_arg9.NewButton = L_2435_arg10
																																													L_2435_arg10 = L_14_func(L_13_.fn_165_NewSlider, L_2426_arg1, {
																																														{
																																															L_2433_arg8
																																														}
																																													})
																																													L_2434_arg9.NewSlider = L_2435_arg10
																																													L_2435_arg10 = L_14_func(L_13_.fn_166_NewDropdown, L_2426_arg1, {
																																														L_2425_arg0[4],
																																														{
																																															L_2433_arg8
																																														}
																																													})
																																													L_2434_arg9.NewDropdown = L_2435_arg10
																																													L_2435_arg10 = L_14_func(L_13_.fn_167_NewLabel, L_2426_arg1, {
																																														{
																																															L_2433_arg8
																																														}
																																													})
																																													L_2434_arg9.NewLabel = L_2435_arg10
																																													L_2435_arg10 = L_14_func(L_13_.fn_168_NewInput, L_2426_arg1, {
																																														{
																																															L_2433_arg8
																																														}
																																													})
																																													L_2434_arg9.NewInput = L_2435_arg10
																																													L_2435_arg10 = L_14_func(L_13_.fn_169_NewTitle, L_2426_arg1, {
																																														{
																																															L_2433_arg8
																																														}
																																													})
																																													L_2434_arg9.NewTitle = L_2435_arg10
																																													L_2435_arg10 = L_14_func(L_13_.fn_170_NewSection, L_2426_arg1, {
																																														{
																																															L_2433_arg8
																																														}
																																													})
																																													L_2434_arg9.NewSection = L_2435_arg10
																																													L_2435_arg10 = L_14_func(L_13_.fn_174_NewPremiumToggle, L_2426_arg1, {
																																														{
																																															L_2433_arg8
																																														},
																																														L_2425_arg0[5]
																																													})
																																													L_2434_arg9.NewPremiumToggle = L_2435_arg10
																																													L_2435_arg10 = L_14_func(L_13_.fn_176_NewPremiumButton, L_2426_arg1, {
																																														{
																																															L_2433_arg8
																																														},
																																														L_2425_arg0[5]
																																													})
																																													L_2434_arg9.NewPremiumButton = L_2435_arg10
																																													L_2435_arg10 = L_14_func(L_13_.fn_178_NewPremiumSlider, L_2426_arg1, {
																																														{
																																															L_2433_arg8
																																														},
																																														L_2425_arg0[5]
																																													})
																																													L_2434_arg9.NewPremiumSlider = L_2435_arg10
																																													L_2435_arg10 = L_14_func(L_13_.fn_180_NewPremiumDropdown, L_2426_arg1, {
																																														L_2425_arg0[4],
																																														{
																																															L_2433_arg8
																																														},
																																														L_2425_arg0[5]
																																													})
																																													L_2434_arg9.NewPremiumDropdown = L_2435_arg10
																																													return L_2434_arg9
																																												end
																																											end
																																											L_2431_arg6 = "Economy"
																																											L_2432_arg7 = "bar-chart-2"
																																										else
																																											L_2431_arg6 = "Utility"
																																											L_2432_arg7 = "sliders"
																																										end
																																										L_2434_arg9 = L_2431_arg6
																																										L_2435_arg10 = L_2432_arg7
																																										L_2437_arg12 = L_2425_arg0[1][1]
																																										L_2436_arg11 = L_2437_arg12[L_2434_arg9]
																																										if not L_2436_arg11 then
																																											L_2437_arg12 = L_2425_arg0[3][1]
																																											L_2436_arg11 = L_2437_arg12.Window
																																											L_2438_arg13 = L_2434_arg9
																																											L_2439_arg14 = L_2435_arg10
																																											if not L_2439_arg14 then
																																												L_2439_arg14 = "layout"
																																											end
																																											do
																																												local L_2494_ = L_2436_arg11;
																																												L_2437_arg12 = L_2494_;
																																												L_2436_arg11 = L_2494_.CreateTab
																																											end
																																											L_2436_arg11 = L_2436_arg11(L_2437_arg12, L_2438_arg13, L_2439_arg14)
																																											L_2439_arg14 = "Main"
																																											L_2440_arg15 = "layout"
																																											do
																																												local L_2495_ = L_2436_arg11;
																																												L_2438_arg13 = L_2495_;
																																												L_2437_arg12 = L_2495_.CreateSubTab
																																											end
																																											L_2437_arg12 = L_2437_arg12(L_2438_arg13, L_2439_arg14, L_2440_arg15)
																																											L_2440_arg15 = "Features"
																																											do
																																												local L_2496_ = L_2437_arg12;
																																												L_2439_arg14 = L_2496_;
																																												L_2438_arg13 = L_2496_.CreateSection
																																											end
																																											L_2438_arg13 = L_2438_arg13(L_2439_arg14, L_2440_arg15)
																																											L_2439_arg14 = L_2425_arg0[1][1]
																																											L_2439_arg14[L_2434_arg9] = L_2436_arg11
																																											L_2439_arg14 = L_2425_arg0[2][1]
																																											L_2439_arg14[L_2434_arg9] = L_2438_arg13
																																											L_2433_arg8 = L_2438_arg13
																																										else
																																											L_2436_arg11 = L_2425_arg0[2][1]
																																											L_2433_arg8 = L_2436_arg11[L_2434_arg9]
																																										end
																																										L_2437_arg12 = "\226\148\128\226\148\128 "
																																										L_2438_arg13 = L_2429_arg4
																																										L_2439_arg14 = " \226\148\128\226\148\128"
																																										L_2436_arg11 = L_2437_arg12 .. L_2438_arg13 .. L_2439_arg14
																																										do
																																											local L_2497_ = L_2433_arg8;
																																											L_2435_arg10 = L_2497_;
																																											L_2434_arg9 = L_2497_.CreateLabel
																																										end
																																										L_2434_arg9(L_2435_arg10, L_2436_arg11)
																																										L_2434_arg9 = {}
																																										L_2435_arg10 = L_14_func(L_13_.fn_163_NewToggle, L_2426_arg1, {
																																											{
																																												L_2433_arg8
																																											}
																																										})
																																										L_2434_arg9.NewToggle = L_2435_arg10
																																										L_2435_arg10 = L_14_func(L_13_.fn_164_NewButton, L_2426_arg1, {
																																											{
																																												L_2433_arg8
																																											}
																																										})
																																										L_2434_arg9.NewButton = L_2435_arg10
																																										L_2435_arg10 = L_14_func(L_13_.fn_165_NewSlider, L_2426_arg1, {
																																											{
																																												L_2433_arg8
																																											}
																																										})
																																										L_2434_arg9.NewSlider = L_2435_arg10
																																										L_2435_arg10 = L_14_func(L_13_.fn_166_NewDropdown, L_2426_arg1, {
																																											L_2425_arg0[4],
																																											{
																																												L_2433_arg8
																																											}
																																										})
																																										L_2434_arg9.NewDropdown = L_2435_arg10
																																										L_2435_arg10 = L_14_func(L_13_.fn_167_NewLabel, L_2426_arg1, {
																																											{
																																												L_2433_arg8
																																											}
																																										})
																																										L_2434_arg9.NewLabel = L_2435_arg10
																																										L_2435_arg10 = L_14_func(L_13_.fn_168_NewInput, L_2426_arg1, {
																																											{
																																												L_2433_arg8
																																											}
																																										})
																																										L_2434_arg9.NewInput = L_2435_arg10
																																										L_2435_arg10 = L_14_func(L_13_.fn_169_NewTitle, L_2426_arg1, {
																																											{
																																												L_2433_arg8
																																											}
																																										})
																																										L_2434_arg9.NewTitle = L_2435_arg10
																																										L_2435_arg10 = L_14_func(L_13_.fn_170_NewSection, L_2426_arg1, {
																																											{
																																												L_2433_arg8
																																											}
																																										})
																																										L_2434_arg9.NewSection = L_2435_arg10
																																										L_2435_arg10 = L_14_func(L_13_.fn_174_NewPremiumToggle, L_2426_arg1, {
																																											{
																																												L_2433_arg8
																																											},
																																											L_2425_arg0[5]
																																										})
																																										L_2434_arg9.NewPremiumToggle = L_2435_arg10
																																										L_2435_arg10 = L_14_func(L_13_.fn_176_NewPremiumButton, L_2426_arg1, {
																																											{
																																												L_2433_arg8
																																											},
																																											L_2425_arg0[5]
																																										})
																																										L_2434_arg9.NewPremiumButton = L_2435_arg10
																																										L_2435_arg10 = L_14_func(L_13_.fn_178_NewPremiumSlider, L_2426_arg1, {
																																											{
																																												L_2433_arg8
																																											},
																																											L_2425_arg0[5]
																																										})
																																										L_2434_arg9.NewPremiumSlider = L_2435_arg10
																																										L_2435_arg10 = L_14_func(L_13_.fn_180_NewPremiumDropdown, L_2426_arg1, {
																																											L_2425_arg0[4],
																																											{
																																												L_2433_arg8
																																											},
																																											L_2425_arg0[5]
																																										})
																																										L_2434_arg9.NewPremiumDropdown = L_2435_arg10
																																										return L_2434_arg9
																																									end
																																								end
																																							end
																																						end
																																						L_2431_arg6 = "Utility"
																																						L_2432_arg7 = "sliders"
																																					else
																																						L_2431_arg6 = "Rage"
																																						L_2432_arg7 = "flame"
																																					end
																																					L_2434_arg9 = L_2431_arg6
																																					L_2435_arg10 = L_2432_arg7
																																					L_2437_arg12 = L_2425_arg0[1][1]
																																					L_2436_arg11 = L_2437_arg12[L_2434_arg9]
																																					if not L_2436_arg11 then
																																						L_2437_arg12 = L_2425_arg0[3][1]
																																						L_2436_arg11 = L_2437_arg12.Window
																																						L_2438_arg13 = L_2434_arg9
																																						L_2439_arg14 = L_2435_arg10
																																						if not L_2439_arg14 then
																																							L_2439_arg14 = "layout"
																																						end
																																						do
																																							local L_2498_ = L_2436_arg11;
																																							L_2437_arg12 = L_2498_;
																																							L_2436_arg11 = L_2498_.CreateTab
																																						end
																																						L_2436_arg11 = L_2436_arg11(L_2437_arg12, L_2438_arg13, L_2439_arg14)
																																						L_2439_arg14 = "Main"
																																						L_2440_arg15 = "layout"
																																						do
																																							local L_2499_ = L_2436_arg11;
																																							L_2438_arg13 = L_2499_;
																																							L_2437_arg12 = L_2499_.CreateSubTab
																																						end
																																						L_2437_arg12 = L_2437_arg12(L_2438_arg13, L_2439_arg14, L_2440_arg15)
																																						L_2440_arg15 = "Features"
																																						do
																																							local L_2500_ = L_2437_arg12;
																																							L_2439_arg14 = L_2500_;
																																							L_2438_arg13 = L_2500_.CreateSection
																																						end
																																						L_2438_arg13 = L_2438_arg13(L_2439_arg14, L_2440_arg15)
																																						L_2439_arg14 = L_2425_arg0[1][1]
																																						L_2439_arg14[L_2434_arg9] = L_2436_arg11
																																						L_2439_arg14 = L_2425_arg0[2][1]
																																						L_2439_arg14[L_2434_arg9] = L_2438_arg13
																																						L_2433_arg8 = L_2438_arg13
																																					else
																																						L_2436_arg11 = L_2425_arg0[2][1]
																																						L_2433_arg8 = L_2436_arg11[L_2434_arg9]
																																					end
																																					L_2437_arg12 = "\226\148\128\226\148\128 "
																																					L_2438_arg13 = L_2429_arg4
																																					L_2439_arg14 = " \226\148\128\226\148\128"
																																					L_2436_arg11 = L_2437_arg12 .. L_2438_arg13 .. L_2439_arg14
																																					do
																																						local L_2501_ = L_2433_arg8;
																																						L_2435_arg10 = L_2501_;
																																						L_2434_arg9 = L_2501_.CreateLabel
																																					end
																																					L_2434_arg9(L_2435_arg10, L_2436_arg11)
																																					L_2434_arg9 = {}
																																					L_2435_arg10 = L_14_func(L_13_.fn_163_NewToggle, L_2426_arg1, {
																																						{
																																							L_2433_arg8
																																						}
																																					})
																																					L_2434_arg9.NewToggle = L_2435_arg10
																																					L_2435_arg10 = L_14_func(L_13_.fn_164_NewButton, L_2426_arg1, {
																																						{
																																							L_2433_arg8
																																						}
																																					})
																																					L_2434_arg9.NewButton = L_2435_arg10
																																					L_2435_arg10 = L_14_func(L_13_.fn_165_NewSlider, L_2426_arg1, {
																																						{
																																							L_2433_arg8
																																						}
																																					})
																																					L_2434_arg9.NewSlider = L_2435_arg10
																																					L_2435_arg10 = L_14_func(L_13_.fn_166_NewDropdown, L_2426_arg1, {
																																						L_2425_arg0[4],
																																						{
																																							L_2433_arg8
																																						}
																																					})
																																					L_2434_arg9.NewDropdown = L_2435_arg10
																																					L_2435_arg10 = L_14_func(L_13_.fn_167_NewLabel, L_2426_arg1, {
																																						{
																																							L_2433_arg8
																																						}
																																					})
																																					L_2434_arg9.NewLabel = L_2435_arg10
																																					L_2435_arg10 = L_14_func(L_13_.fn_168_NewInput, L_2426_arg1, {
																																						{
																																							L_2433_arg8
																																						}
																																					})
																																					L_2434_arg9.NewInput = L_2435_arg10
																																					L_2435_arg10 = L_14_func(L_13_.fn_169_NewTitle, L_2426_arg1, {
																																						{
																																							L_2433_arg8
																																						}
																																					})
																																					L_2434_arg9.NewTitle = L_2435_arg10
																																					L_2435_arg10 = L_14_func(L_13_.fn_170_NewSection, L_2426_arg1, {
																																						{
																																							L_2433_arg8
																																						}
																																					})
																																					L_2434_arg9.NewSection = L_2435_arg10
																																					L_2435_arg10 = L_14_func(L_13_.fn_174_NewPremiumToggle, L_2426_arg1, {
																																						{
																																							L_2433_arg8
																																						},
																																						L_2425_arg0[5]
																																					})
																																					L_2434_arg9.NewPremiumToggle = L_2435_arg10
																																					L_2435_arg10 = L_14_func(L_13_.fn_176_NewPremiumButton, L_2426_arg1, {
																																						{
																																							L_2433_arg8
																																						},
																																						L_2425_arg0[5]
																																					})
																																					L_2434_arg9.NewPremiumButton = L_2435_arg10
																																					L_2435_arg10 = L_14_func(L_13_.fn_178_NewPremiumSlider, L_2426_arg1, {
																																						{
																																							L_2433_arg8
																																						},
																																						L_2425_arg0[5]
																																					})
																																					L_2434_arg9.NewPremiumSlider = L_2435_arg10
																																					L_2435_arg10 = L_14_func(L_13_.fn_180_NewPremiumDropdown, L_2426_arg1, {
																																						L_2425_arg0[4],
																																						{
																																							L_2433_arg8
																																						},
																																						L_2425_arg0[5]
																																					})
																																					L_2434_arg9.NewPremiumDropdown = L_2435_arg10
																																					return L_2434_arg9
																																				end
																																			end
																																			L_2431_arg6 = "Rage"
																																			L_2432_arg7 = "flame"
																																		else
																																			L_2431_arg6 = "Survival"
																																			L_2432_arg7 = "shield"
																																		end
																																		L_2434_arg9 = L_2431_arg6
																																		L_2435_arg10 = L_2432_arg7
																																		L_2437_arg12 = L_2425_arg0[1][1]
																																		L_2436_arg11 = L_2437_arg12[L_2434_arg9]
																																		if not L_2436_arg11 then
																																			L_2437_arg12 = L_2425_arg0[3][1]
																																			L_2436_arg11 = L_2437_arg12.Window
																																			L_2438_arg13 = L_2434_arg9
																																			L_2439_arg14 = L_2435_arg10
																																			if not L_2439_arg14 then
																																				L_2439_arg14 = "layout"
																																			end
																																			do
																																				local L_2502_ = L_2436_arg11;
																																				L_2437_arg12 = L_2502_;
																																				L_2436_arg11 = L_2502_.CreateTab
																																			end
																																			L_2436_arg11 = L_2436_arg11(L_2437_arg12, L_2438_arg13, L_2439_arg14)
																																			L_2439_arg14 = "Main"
																																			L_2440_arg15 = "layout"
																																			do
																																				local L_2503_ = L_2436_arg11;
																																				L_2438_arg13 = L_2503_;
																																				L_2437_arg12 = L_2503_.CreateSubTab
																																			end
																																			L_2437_arg12 = L_2437_arg12(L_2438_arg13, L_2439_arg14, L_2440_arg15)
																																			L_2440_arg15 = "Features"
																																			do
																																				local L_2504_ = L_2437_arg12;
																																				L_2439_arg14 = L_2504_;
																																				L_2438_arg13 = L_2504_.CreateSection
																																			end
																																			L_2438_arg13 = L_2438_arg13(L_2439_arg14, L_2440_arg15)
																																			L_2439_arg14 = L_2425_arg0[1][1]
																																			L_2439_arg14[L_2434_arg9] = L_2436_arg11
																																			L_2439_arg14 = L_2425_arg0[2][1]
																																			L_2439_arg14[L_2434_arg9] = L_2438_arg13
																																			L_2433_arg8 = L_2438_arg13
																																		else
																																			L_2436_arg11 = L_2425_arg0[2][1]
																																			L_2433_arg8 = L_2436_arg11[L_2434_arg9]
																																		end
																																		L_2437_arg12 = "\226\148\128\226\148\128 "
																																		L_2438_arg13 = L_2429_arg4
																																		L_2439_arg14 = " \226\148\128\226\148\128"
																																		L_2436_arg11 = L_2437_arg12 .. L_2438_arg13 .. L_2439_arg14
																																		do
																																			local L_2505_ = L_2433_arg8;
																																			L_2435_arg10 = L_2505_;
																																			L_2434_arg9 = L_2505_.CreateLabel
																																		end
																																		L_2434_arg9(L_2435_arg10, L_2436_arg11)
																																		L_2434_arg9 = {}
																																		L_2435_arg10 = L_14_func(L_13_.fn_163_NewToggle, L_2426_arg1, {
																																			{
																																				L_2433_arg8
																																			}
																																		})
																																		L_2434_arg9.NewToggle = L_2435_arg10
																																		L_2435_arg10 = L_14_func(L_13_.fn_164_NewButton, L_2426_arg1, {
																																			{
																																				L_2433_arg8
																																			}
																																		})
																																		L_2434_arg9.NewButton = L_2435_arg10
																																		L_2435_arg10 = L_14_func(L_13_.fn_165_NewSlider, L_2426_arg1, {
																																			{
																																				L_2433_arg8
																																			}
																																		})
																																		L_2434_arg9.NewSlider = L_2435_arg10
																																		L_2435_arg10 = L_14_func(L_13_.fn_166_NewDropdown, L_2426_arg1, {
																																			L_2425_arg0[4],
																																			{
																																				L_2433_arg8
																																			}
																																		})
																																		L_2434_arg9.NewDropdown = L_2435_arg10
																																		L_2435_arg10 = L_14_func(L_13_.fn_167_NewLabel, L_2426_arg1, {
																																			{
																																				L_2433_arg8
																																			}
																																		})
																																		L_2434_arg9.NewLabel = L_2435_arg10
																																		L_2435_arg10 = L_14_func(L_13_.fn_168_NewInput, L_2426_arg1, {
																																			{
																																				L_2433_arg8
																																			}
																																		})
																																		L_2434_arg9.NewInput = L_2435_arg10
																																		L_2435_arg10 = L_14_func(L_13_.fn_169_NewTitle, L_2426_arg1, {
																																			{
																																				L_2433_arg8
																																			}
																																		})
																																		L_2434_arg9.NewTitle = L_2435_arg10
																																		L_2435_arg10 = L_14_func(L_13_.fn_170_NewSection, L_2426_arg1, {
																																			{
																																				L_2433_arg8
																																			}
																																		})
																																		L_2434_arg9.NewSection = L_2435_arg10
																																		L_2435_arg10 = L_14_func(L_13_.fn_174_NewPremiumToggle, L_2426_arg1, {
																																			{
																																				L_2433_arg8
																																			},
																																			L_2425_arg0[5]
																																		})
																																		L_2434_arg9.NewPremiumToggle = L_2435_arg10
																																		L_2435_arg10 = L_14_func(L_13_.fn_176_NewPremiumButton, L_2426_arg1, {
																																			{
																																				L_2433_arg8
																																			},
																																			L_2425_arg0[5]
																																		})
																																		L_2434_arg9.NewPremiumButton = L_2435_arg10
																																		L_2435_arg10 = L_14_func(L_13_.fn_178_NewPremiumSlider, L_2426_arg1, {
																																			{
																																				L_2433_arg8
																																			},
																																			L_2425_arg0[5]
																																		})
																																		L_2434_arg9.NewPremiumSlider = L_2435_arg10
																																		L_2435_arg10 = L_14_func(L_13_.fn_180_NewPremiumDropdown, L_2426_arg1, {
																																			L_2425_arg0[4],
																																			{
																																				L_2433_arg8
																																			},
																																			L_2425_arg0[5]
																																		})
																																		L_2434_arg9.NewPremiumDropdown = L_2435_arg10
																																		return L_2434_arg9
																																	end
																																end
																															end
																														end
																														L_2431_arg6 = "Survival"
																														L_2432_arg7 = "shield"
																													else
																														L_2431_arg6 = "AutoFarm"
																														L_2432_arg7 = "zap"
																													end
																													L_2434_arg9 = L_2431_arg6
																													L_2435_arg10 = L_2432_arg7
																													L_2437_arg12 = L_2425_arg0[1][1]
																													L_2436_arg11 = L_2437_arg12[L_2434_arg9]
																													if not L_2436_arg11 then
																														L_2437_arg12 = L_2425_arg0[3][1]
																														L_2436_arg11 = L_2437_arg12.Window
																														L_2438_arg13 = L_2434_arg9
																														L_2439_arg14 = L_2435_arg10
																														if not L_2439_arg14 then
																															L_2439_arg14 = "layout"
																														end
																														do
																															local L_2506_ = L_2436_arg11;
																															L_2437_arg12 = L_2506_;
																															L_2436_arg11 = L_2506_.CreateTab
																														end
																														L_2436_arg11 = L_2436_arg11(L_2437_arg12, L_2438_arg13, L_2439_arg14)
																														L_2439_arg14 = "Main"
																														L_2440_arg15 = "layout"
																														do
																															local L_2507_ = L_2436_arg11;
																															L_2438_arg13 = L_2507_;
																															L_2437_arg12 = L_2507_.CreateSubTab
																														end
																														L_2437_arg12 = L_2437_arg12(L_2438_arg13, L_2439_arg14, L_2440_arg15)
																														L_2440_arg15 = "Features"
																														do
																															local L_2508_ = L_2437_arg12;
																															L_2439_arg14 = L_2508_;
																															L_2438_arg13 = L_2508_.CreateSection
																														end
																														L_2438_arg13 = L_2438_arg13(L_2439_arg14, L_2440_arg15)
																														L_2439_arg14 = L_2425_arg0[1][1]
																														L_2439_arg14[L_2434_arg9] = L_2436_arg11
																														L_2439_arg14 = L_2425_arg0[2][1]
																														L_2439_arg14[L_2434_arg9] = L_2438_arg13
																														L_2433_arg8 = L_2438_arg13
																													else
																														L_2436_arg11 = L_2425_arg0[2][1]
																														L_2433_arg8 = L_2436_arg11[L_2434_arg9]
																													end
																													L_2437_arg12 = "\226\148\128\226\148\128 "
																													L_2438_arg13 = L_2429_arg4
																													L_2439_arg14 = " \226\148\128\226\148\128"
																													L_2436_arg11 = L_2437_arg12 .. L_2438_arg13 .. L_2439_arg14
																													do
																														local L_2509_ = L_2433_arg8;
																														L_2435_arg10 = L_2509_;
																														L_2434_arg9 = L_2509_.CreateLabel
																													end
																													L_2434_arg9(L_2435_arg10, L_2436_arg11)
																													L_2434_arg9 = {}
																													L_2435_arg10 = L_14_func(L_13_.fn_163_NewToggle, L_2426_arg1, {
																														{
																															L_2433_arg8
																														}
																													})
																													L_2434_arg9.NewToggle = L_2435_arg10
																													L_2435_arg10 = L_14_func(L_13_.fn_164_NewButton, L_2426_arg1, {
																														{
																															L_2433_arg8
																														}
																													})
																													L_2434_arg9.NewButton = L_2435_arg10
																													L_2435_arg10 = L_14_func(L_13_.fn_165_NewSlider, L_2426_arg1, {
																														{
																															L_2433_arg8
																														}
																													})
																													L_2434_arg9.NewSlider = L_2435_arg10
																													L_2435_arg10 = L_14_func(L_13_.fn_166_NewDropdown, L_2426_arg1, {
																														L_2425_arg0[4],
																														{
																															L_2433_arg8
																														}
																													})
																													L_2434_arg9.NewDropdown = L_2435_arg10
																													L_2435_arg10 = L_14_func(L_13_.fn_167_NewLabel, L_2426_arg1, {
																														{
																															L_2433_arg8
																														}
																													})
																													L_2434_arg9.NewLabel = L_2435_arg10
																													L_2435_arg10 = L_14_func(L_13_.fn_168_NewInput, L_2426_arg1, {
																														{
																															L_2433_arg8
																														}
																													})
																													L_2434_arg9.NewInput = L_2435_arg10
																													L_2435_arg10 = L_14_func(L_13_.fn_169_NewTitle, L_2426_arg1, {
																														{
																															L_2433_arg8
																														}
																													})
																													L_2434_arg9.NewTitle = L_2435_arg10
																													L_2435_arg10 = L_14_func(L_13_.fn_170_NewSection, L_2426_arg1, {
																														{
																															L_2433_arg8
																														}
																													})
																													L_2434_arg9.NewSection = L_2435_arg10
																													L_2435_arg10 = L_14_func(L_13_.fn_174_NewPremiumToggle, L_2426_arg1, {
																														{
																															L_2433_arg8
																														},
																														L_2425_arg0[5]
																													})
																													L_2434_arg9.NewPremiumToggle = L_2435_arg10
																													L_2435_arg10 = L_14_func(L_13_.fn_176_NewPremiumButton, L_2426_arg1, {
																														{
																															L_2433_arg8
																														},
																														L_2425_arg0[5]
																													})
																													L_2434_arg9.NewPremiumButton = L_2435_arg10
																													L_2435_arg10 = L_14_func(L_13_.fn_178_NewPremiumSlider, L_2426_arg1, {
																														{
																															L_2433_arg8
																														},
																														L_2425_arg0[5]
																													})
																													L_2434_arg9.NewPremiumSlider = L_2435_arg10
																													L_2435_arg10 = L_14_func(L_13_.fn_180_NewPremiumDropdown, L_2426_arg1, {
																														L_2425_arg0[4],
																														{
																															L_2433_arg8
																														},
																														L_2425_arg0[5]
																													})
																													L_2434_arg9.NewPremiumDropdown = L_2435_arg10
																													return L_2434_arg9
																												end
																											end
																										end
																									end
																								end
																								L_2431_arg6 = "AutoFarm"
																								L_2432_arg7 = "zap"
																							else
																								L_2431_arg6 = "Movement"
																								L_2432_arg7 = "bar-chart-2"
																							end
																							L_2434_arg9 = L_2431_arg6
																							L_2435_arg10 = L_2432_arg7
																							L_2437_arg12 = L_2425_arg0[1][1]
																							L_2436_arg11 = L_2437_arg12[L_2434_arg9]
																							if not L_2436_arg11 then
																								L_2437_arg12 = L_2425_arg0[3][1]
																								L_2436_arg11 = L_2437_arg12.Window
																								L_2438_arg13 = L_2434_arg9
																								L_2439_arg14 = L_2435_arg10
																								if not L_2439_arg14 then
																									L_2439_arg14 = "layout"
																								end
																								do
																									local L_2510_ = L_2436_arg11;
																									L_2437_arg12 = L_2510_;
																									L_2436_arg11 = L_2510_.CreateTab
																								end
																								L_2436_arg11 = L_2436_arg11(L_2437_arg12, L_2438_arg13, L_2439_arg14)
																								L_2439_arg14 = "Main"
																								L_2440_arg15 = "layout"
																								do
																									local L_2511_ = L_2436_arg11;
																									L_2438_arg13 = L_2511_;
																									L_2437_arg12 = L_2511_.CreateSubTab
																								end
																								L_2437_arg12 = L_2437_arg12(L_2438_arg13, L_2439_arg14, L_2440_arg15)
																								L_2440_arg15 = "Features"
																								do
																									local L_2512_ = L_2437_arg12;
																									L_2439_arg14 = L_2512_;
																									L_2438_arg13 = L_2512_.CreateSection
																								end
																								L_2438_arg13 = L_2438_arg13(L_2439_arg14, L_2440_arg15)
																								L_2439_arg14 = L_2425_arg0[1][1]
																								L_2439_arg14[L_2434_arg9] = L_2436_arg11
																								L_2439_arg14 = L_2425_arg0[2][1]
																								L_2439_arg14[L_2434_arg9] = L_2438_arg13
																								L_2433_arg8 = L_2438_arg13
																							else
																								L_2436_arg11 = L_2425_arg0[2][1]
																								L_2433_arg8 = L_2436_arg11[L_2434_arg9]
																							end
																							L_2437_arg12 = "\226\148\128\226\148\128 "
																							L_2438_arg13 = L_2429_arg4
																							L_2439_arg14 = " \226\148\128\226\148\128"
																							L_2436_arg11 = L_2437_arg12 .. L_2438_arg13 .. L_2439_arg14
																							do
																								local L_2513_ = L_2433_arg8;
																								L_2435_arg10 = L_2513_;
																								L_2434_arg9 = L_2513_.CreateLabel
																							end
																							L_2434_arg9(L_2435_arg10, L_2436_arg11)
																							L_2434_arg9 = {}
																							L_2435_arg10 = L_14_func(L_13_.fn_163_NewToggle, L_2426_arg1, {
																								{
																									L_2433_arg8
																								}
																							})
																							L_2434_arg9.NewToggle = L_2435_arg10
																							L_2435_arg10 = L_14_func(L_13_.fn_164_NewButton, L_2426_arg1, {
																								{
																									L_2433_arg8
																								}
																							})
																							L_2434_arg9.NewButton = L_2435_arg10
																							L_2435_arg10 = L_14_func(L_13_.fn_165_NewSlider, L_2426_arg1, {
																								{
																									L_2433_arg8
																								}
																							})
																							L_2434_arg9.NewSlider = L_2435_arg10
																							L_2435_arg10 = L_14_func(L_13_.fn_166_NewDropdown, L_2426_arg1, {
																								L_2425_arg0[4],
																								{
																									L_2433_arg8
																								}
																							})
																							L_2434_arg9.NewDropdown = L_2435_arg10
																							L_2435_arg10 = L_14_func(L_13_.fn_167_NewLabel, L_2426_arg1, {
																								{
																									L_2433_arg8
																								}
																							})
																							L_2434_arg9.NewLabel = L_2435_arg10
																							L_2435_arg10 = L_14_func(L_13_.fn_168_NewInput, L_2426_arg1, {
																								{
																									L_2433_arg8
																								}
																							})
																							L_2434_arg9.NewInput = L_2435_arg10
																							L_2435_arg10 = L_14_func(L_13_.fn_169_NewTitle, L_2426_arg1, {
																								{
																									L_2433_arg8
																								}
																							})
																							L_2434_arg9.NewTitle = L_2435_arg10
																							L_2435_arg10 = L_14_func(L_13_.fn_170_NewSection, L_2426_arg1, {
																								{
																									L_2433_arg8
																								}
																							})
																							L_2434_arg9.NewSection = L_2435_arg10
																							L_2435_arg10 = L_14_func(L_13_.fn_174_NewPremiumToggle, L_2426_arg1, {
																								{
																									L_2433_arg8
																								},
																								L_2425_arg0[5]
																							})
																							L_2434_arg9.NewPremiumToggle = L_2435_arg10
																							L_2435_arg10 = L_14_func(L_13_.fn_176_NewPremiumButton, L_2426_arg1, {
																								{
																									L_2433_arg8
																								},
																								L_2425_arg0[5]
																							})
																							L_2434_arg9.NewPremiumButton = L_2435_arg10
																							L_2435_arg10 = L_14_func(L_13_.fn_178_NewPremiumSlider, L_2426_arg1, {
																								{
																									L_2433_arg8
																								},
																								L_2425_arg0[5]
																							})
																							L_2434_arg9.NewPremiumSlider = L_2435_arg10
																							L_2435_arg10 = L_14_func(L_13_.fn_180_NewPremiumDropdown, L_2426_arg1, {
																								L_2425_arg0[4],
																								{
																									L_2433_arg8
																								},
																								L_2425_arg0[5]
																							})
																							L_2434_arg9.NewPremiumDropdown = L_2435_arg10
																							return L_2434_arg9
																						end
																					end
																				end
																			end
																		end
																	end
																end
																L_2431_arg6 = "Movement"
																L_2432_arg7 = "bar-chart-2"
															else
																L_2431_arg6 = "Visuals"
																L_2432_arg7 = "eye"
															end
															L_2434_arg9 = L_2431_arg6
															L_2435_arg10 = L_2432_arg7
															L_2437_arg12 = L_2425_arg0[1][1]
															L_2436_arg11 = L_2437_arg12[L_2434_arg9]
															if not L_2436_arg11 then
																L_2437_arg12 = L_2425_arg0[3][1]
																L_2436_arg11 = L_2437_arg12.Window
																L_2438_arg13 = L_2434_arg9
																L_2439_arg14 = L_2435_arg10
																if not L_2439_arg14 then
																	L_2439_arg14 = "layout"
																end
																do
																	local L_2514_ = L_2436_arg11;
																	L_2437_arg12 = L_2514_;
																	L_2436_arg11 = L_2514_.CreateTab
																end
																L_2436_arg11 = L_2436_arg11(L_2437_arg12, L_2438_arg13, L_2439_arg14)
																L_2439_arg14 = "Main"
																L_2440_arg15 = "layout"
																do
																	local L_2515_ = L_2436_arg11;
																	L_2438_arg13 = L_2515_;
																	L_2437_arg12 = L_2515_.CreateSubTab
																end
																L_2437_arg12 = L_2437_arg12(L_2438_arg13, L_2439_arg14, L_2440_arg15)
																L_2440_arg15 = "Features"
																do
																	local L_2516_ = L_2437_arg12;
																	L_2439_arg14 = L_2516_;
																	L_2438_arg13 = L_2516_.CreateSection
																end
																L_2438_arg13 = L_2438_arg13(L_2439_arg14, L_2440_arg15)
																L_2439_arg14 = L_2425_arg0[1][1]
																L_2439_arg14[L_2434_arg9] = L_2436_arg11
																L_2439_arg14 = L_2425_arg0[2][1]
																L_2439_arg14[L_2434_arg9] = L_2438_arg13
																L_2433_arg8 = L_2438_arg13
															else
																L_2436_arg11 = L_2425_arg0[2][1]
																L_2433_arg8 = L_2436_arg11[L_2434_arg9]
															end
															L_2437_arg12 = "\226\148\128\226\148\128 "
															L_2438_arg13 = L_2429_arg4
															L_2439_arg14 = " \226\148\128\226\148\128"
															L_2436_arg11 = L_2437_arg12 .. L_2438_arg13 .. L_2439_arg14
															do
																local L_2517_ = L_2433_arg8;
																L_2435_arg10 = L_2517_;
																L_2434_arg9 = L_2517_.CreateLabel
															end
															L_2434_arg9(L_2435_arg10, L_2436_arg11)
															L_2434_arg9 = {}
															L_2435_arg10 = L_14_func(L_13_.fn_163_NewToggle, L_2426_arg1, {
																{
																	L_2433_arg8
																}
															})
															L_2434_arg9.NewToggle = L_2435_arg10
															L_2435_arg10 = L_14_func(L_13_.fn_164_NewButton, L_2426_arg1, {
																{
																	L_2433_arg8
																}
															})
															L_2434_arg9.NewButton = L_2435_arg10
															L_2435_arg10 = L_14_func(L_13_.fn_165_NewSlider, L_2426_arg1, {
																{
																	L_2433_arg8
																}
															})
															L_2434_arg9.NewSlider = L_2435_arg10
															L_2435_arg10 = L_14_func(L_13_.fn_166_NewDropdown, L_2426_arg1, {
																L_2425_arg0[4],
																{
																	L_2433_arg8
																}
															})
															L_2434_arg9.NewDropdown = L_2435_arg10
															L_2435_arg10 = L_14_func(L_13_.fn_167_NewLabel, L_2426_arg1, {
																{
																	L_2433_arg8
																}
															})
															L_2434_arg9.NewLabel = L_2435_arg10
															L_2435_arg10 = L_14_func(L_13_.fn_168_NewInput, L_2426_arg1, {
																{
																	L_2433_arg8
																}
															})
															L_2434_arg9.NewInput = L_2435_arg10
															L_2435_arg10 = L_14_func(L_13_.fn_169_NewTitle, L_2426_arg1, {
																{
																	L_2433_arg8
																}
															})
															L_2434_arg9.NewTitle = L_2435_arg10
															L_2435_arg10 = L_14_func(L_13_.fn_170_NewSection, L_2426_arg1, {
																{
																	L_2433_arg8
																}
															})
															L_2434_arg9.NewSection = L_2435_arg10
															L_2435_arg10 = L_14_func(L_13_.fn_174_NewPremiumToggle, L_2426_arg1, {
																{
																	L_2433_arg8
																},
																L_2425_arg0[5]
															})
															L_2434_arg9.NewPremiumToggle = L_2435_arg10
															L_2435_arg10 = L_14_func(L_13_.fn_176_NewPremiumButton, L_2426_arg1, {
																{
																	L_2433_arg8
																},
																L_2425_arg0[5]
															})
															L_2434_arg9.NewPremiumButton = L_2435_arg10
															L_2435_arg10 = L_14_func(L_13_.fn_178_NewPremiumSlider, L_2426_arg1, {
																{
																	L_2433_arg8
																},
																L_2425_arg0[5]
															})
															L_2434_arg9.NewPremiumSlider = L_2435_arg10
															L_2435_arg10 = L_14_func(L_13_.fn_180_NewPremiumDropdown, L_2426_arg1, {
																L_2425_arg0[4],
																{
																	L_2433_arg8
																},
																L_2425_arg0[5]
															})
															L_2434_arg9.NewPremiumDropdown = L_2435_arg10
															return L_2434_arg9
														end
													end
												end
											end
										end
										L_2431_arg6 = "Visuals"
										L_2432_arg7 = "eye"
									else
										L_2431_arg6 = "Combat"
										L_2432_arg7 = "swords"
									end
									L_2434_arg9 = L_2431_arg6
									L_2435_arg10 = L_2432_arg7
									L_2437_arg12 = L_2425_arg0[1][1]
									L_2436_arg11 = L_2437_arg12[L_2434_arg9]
									if not L_2436_arg11 then
										L_2437_arg12 = L_2425_arg0[3][1]
										L_2436_arg11 = L_2437_arg12.Window
										L_2438_arg13 = L_2434_arg9
										L_2439_arg14 = L_2435_arg10
										if not L_2439_arg14 then
											L_2439_arg14 = "layout"
										end
										do
											local L_2518_ = L_2436_arg11;
											L_2437_arg12 = L_2518_;
											L_2436_arg11 = L_2518_.CreateTab
										end
										L_2436_arg11 = L_2436_arg11(L_2437_arg12, L_2438_arg13, L_2439_arg14)
										L_2439_arg14 = "Main"
										L_2440_arg15 = "layout"
										do
											local L_2519_ = L_2436_arg11;
											L_2438_arg13 = L_2519_;
											L_2437_arg12 = L_2519_.CreateSubTab
										end
										L_2437_arg12 = L_2437_arg12(L_2438_arg13, L_2439_arg14, L_2440_arg15)
										L_2440_arg15 = "Features"
										do
											local L_2520_ = L_2437_arg12;
											L_2439_arg14 = L_2520_;
											L_2438_arg13 = L_2520_.CreateSection
										end
										L_2438_arg13 = L_2438_arg13(L_2439_arg14, L_2440_arg15)
										L_2439_arg14 = L_2425_arg0[1][1]
										L_2439_arg14[L_2434_arg9] = L_2436_arg11
										L_2439_arg14 = L_2425_arg0[2][1]
										L_2439_arg14[L_2434_arg9] = L_2438_arg13
										L_2433_arg8 = L_2438_arg13
									else
										L_2436_arg11 = L_2425_arg0[2][1]
										L_2433_arg8 = L_2436_arg11[L_2434_arg9]
									end
									L_2437_arg12 = "\226\148\128\226\148\128 "
									L_2438_arg13 = L_2429_arg4
									L_2439_arg14 = " \226\148\128\226\148\128"
									L_2436_arg11 = L_2437_arg12 .. L_2438_arg13 .. L_2439_arg14
									do
										local L_2521_ = L_2433_arg8;
										L_2435_arg10 = L_2521_;
										L_2434_arg9 = L_2521_.CreateLabel
									end
									L_2434_arg9(L_2435_arg10, L_2436_arg11)
									L_2434_arg9 = {}
									L_2435_arg10 = L_14_func(L_13_.fn_163_NewToggle, L_2426_arg1, {
										{
											L_2433_arg8
										}
									})
									L_2434_arg9.NewToggle = L_2435_arg10
									L_2435_arg10 = L_14_func(L_13_.fn_164_NewButton, L_2426_arg1, {
										{
											L_2433_arg8
										}
									})
									L_2434_arg9.NewButton = L_2435_arg10
									L_2435_arg10 = L_14_func(L_13_.fn_165_NewSlider, L_2426_arg1, {
										{
											L_2433_arg8
										}
									})
									L_2434_arg9.NewSlider = L_2435_arg10
									L_2435_arg10 = L_14_func(L_13_.fn_166_NewDropdown, L_2426_arg1, {
										L_2425_arg0[4],
										{
											L_2433_arg8
										}
									})
									L_2434_arg9.NewDropdown = L_2435_arg10
									L_2435_arg10 = L_14_func(L_13_.fn_167_NewLabel, L_2426_arg1, {
										{
											L_2433_arg8
										}
									})
									L_2434_arg9.NewLabel = L_2435_arg10
									L_2435_arg10 = L_14_func(L_13_.fn_168_NewInput, L_2426_arg1, {
										{
											L_2433_arg8
										}
									})
									L_2434_arg9.NewInput = L_2435_arg10
									L_2435_arg10 = L_14_func(L_13_.fn_169_NewTitle, L_2426_arg1, {
										{
											L_2433_arg8
										}
									})
									L_2434_arg9.NewTitle = L_2435_arg10
									L_2435_arg10 = L_14_func(L_13_.fn_170_NewSection, L_2426_arg1, {
										{
											L_2433_arg8
										}
									})
									L_2434_arg9.NewSection = L_2435_arg10
									L_2435_arg10 = L_14_func(L_13_.fn_174_NewPremiumToggle, L_2426_arg1, {
										{
											L_2433_arg8
										},
										L_2425_arg0[5]
									})
									L_2434_arg9.NewPremiumToggle = L_2435_arg10
									L_2435_arg10 = L_14_func(L_13_.fn_176_NewPremiumButton, L_2426_arg1, {
										{
											L_2433_arg8
										},
										L_2425_arg0[5]
									})
									L_2434_arg9.NewPremiumButton = L_2435_arg10
									L_2435_arg10 = L_14_func(L_13_.fn_178_NewPremiumSlider, L_2426_arg1, {
										{
											L_2433_arg8
										},
										L_2425_arg0[5]
									})
									L_2434_arg9.NewPremiumSlider = L_2435_arg10
									L_2435_arg10 = L_14_func(L_13_.fn_180_NewPremiumDropdown, L_2426_arg1, {
										L_2425_arg0[4],
										{
											L_2433_arg8
										},
										L_2425_arg0[5]
									})
									L_2434_arg9.NewPremiumDropdown = L_2435_arg10
									return L_2434_arg9
								end
							end
						end
					end
				end
			end
			L_2431_arg6 = "Combat"
			L_2432_arg7 = "swords"
		else
			L_2431_arg6 = "Premium"
			L_2432_arg7 = "zap"
		end
	else
		L_2431_arg6 = "Free"
		L_2432_arg7 = "home"
	end
	L_2434_arg9 = L_2431_arg6
	L_2435_arg10 = L_2432_arg7
	L_2437_arg12 = L_2425_arg0[1][1]
	L_2436_arg11 = L_2437_arg12[L_2434_arg9]
	if not L_2436_arg11 then
		L_2437_arg12 = L_2425_arg0[3][1]
		L_2436_arg11 = L_2437_arg12.Window
		L_2438_arg13 = L_2434_arg9
		L_2439_arg14 = L_2435_arg10
		if not L_2439_arg14 then
			L_2439_arg14 = "layout"
		end
		do
			local L_2522_ = L_2436_arg11;
			L_2437_arg12 = L_2522_;
			L_2436_arg11 = L_2522_.CreateTab
		end
		L_2436_arg11 = L_2436_arg11(L_2437_arg12, L_2438_arg13, L_2439_arg14)
		L_2439_arg14 = "Main"
		L_2440_arg15 = "layout"
		do
			local L_2523_ = L_2436_arg11;
			L_2438_arg13 = L_2523_;
			L_2437_arg12 = L_2523_.CreateSubTab
		end
		L_2437_arg12 = L_2437_arg12(L_2438_arg13, L_2439_arg14, L_2440_arg15)
		L_2440_arg15 = "Features"
		do
			local L_2524_ = L_2437_arg12;
			L_2439_arg14 = L_2524_;
			L_2438_arg13 = L_2524_.CreateSection
		end
		L_2438_arg13 = L_2438_arg13(L_2439_arg14, L_2440_arg15)
		L_2439_arg14 = L_2425_arg0[1][1]
		L_2439_arg14[L_2434_arg9] = L_2436_arg11
		L_2439_arg14 = L_2425_arg0[2][1]
		L_2439_arg14[L_2434_arg9] = L_2438_arg13
		L_2433_arg8 = L_2438_arg13
	else
		L_2436_arg11 = L_2425_arg0[2][1]
		L_2433_arg8 = L_2436_arg11[L_2434_arg9]
	end
	L_2437_arg12 = "\226\148\128\226\148\128 "
	L_2438_arg13 = L_2429_arg4
	L_2439_arg14 = " \226\148\128\226\148\128"
	L_2436_arg11 = L_2437_arg12 .. L_2438_arg13 .. L_2439_arg14
	do
		local L_2525_ = L_2433_arg8;
		L_2435_arg10 = L_2525_;
		L_2434_arg9 = L_2525_.CreateLabel
	end
	L_2434_arg9(L_2435_arg10, L_2436_arg11)
	L_2434_arg9 = {}
	L_2435_arg10 = L_14_func(L_13_.fn_163_NewToggle, L_2426_arg1, {
		{
			L_2433_arg8
		}
	})
	L_2434_arg9.NewToggle = L_2435_arg10
	L_2435_arg10 = L_14_func(L_13_.fn_164_NewButton, L_2426_arg1, {
		{
			L_2433_arg8
		}
	})
	L_2434_arg9.NewButton = L_2435_arg10
	L_2435_arg10 = L_14_func(L_13_.fn_165_NewSlider, L_2426_arg1, {
		{
			L_2433_arg8
		}
	})
	L_2434_arg9.NewSlider = L_2435_arg10
	L_2435_arg10 = L_14_func(L_13_.fn_166_NewDropdown, L_2426_arg1, {
		L_2425_arg0[4],
		{
			L_2433_arg8
		}
	})
	L_2434_arg9.NewDropdown = L_2435_arg10
	L_2435_arg10 = L_14_func(L_13_.fn_167_NewLabel, L_2426_arg1, {
		{
			L_2433_arg8
		}
	})
	L_2434_arg9.NewLabel = L_2435_arg10
	L_2435_arg10 = L_14_func(L_13_.fn_168_NewInput, L_2426_arg1, {
		{
			L_2433_arg8
		}
	})
	L_2434_arg9.NewInput = L_2435_arg10
	L_2435_arg10 = L_14_func(L_13_.fn_169_NewTitle, L_2426_arg1, {
		{
			L_2433_arg8
		}
	})
	L_2434_arg9.NewTitle = L_2435_arg10
	L_2435_arg10 = L_14_func(L_13_.fn_170_NewSection, L_2426_arg1, {
		{
			L_2433_arg8
		}
	})
	L_2434_arg9.NewSection = L_2435_arg10
	L_2435_arg10 = L_14_func(L_13_.fn_174_NewPremiumToggle, L_2426_arg1, {
		{
			L_2433_arg8
		},
		L_2425_arg0[5]
	})
	L_2434_arg9.NewPremiumToggle = L_2435_arg10
	L_2435_arg10 = L_14_func(L_13_.fn_176_NewPremiumButton, L_2426_arg1, {
		{
			L_2433_arg8
		},
		L_2425_arg0[5]
	})
	L_2434_arg9.NewPremiumButton = L_2435_arg10
	L_2435_arg10 = L_14_func(L_13_.fn_178_NewPremiumSlider, L_2426_arg1, {
		{
			L_2433_arg8
		},
		L_2425_arg0[5]
	})
	L_2434_arg9.NewPremiumSlider = L_2435_arg10
	L_2435_arg10 = L_14_func(L_13_.fn_180_NewPremiumDropdown, L_2426_arg1, {
		L_2425_arg0[4],
		{
			L_2433_arg8
		},
		L_2425_arg0[5]
	})
	L_2434_arg9.NewPremiumDropdown = L_2435_arg10
	return L_2434_arg9
end

L_13_.fn_182_NewToggle = function(L_2526_arg0, L_2527_arg1, L_2528_arg2)
	return
end

L_13_.fn_183_legacyApiAdapter = function(L_2529_arg0, L_2530_arg1, L_2531_arg2, L_2532_arg3, L_2533_arg4, L_2534_arg5, L_2535_arg6, L_2536_arg7, L_2537_arg8, L_2538_arg9, L_2539_arg10)
	L_2533_arg4 = L_2529_arg0[1][1]
	if L_2533_arg4 then
		L_2534_arg5 = L_2529_arg0[1][1]
		L_2533_arg4 = L_2534_arg5.name
		do
			local L_2540_ = L_2533_arg4;
			L_2534_arg5 = L_2540_;
			L_2533_arg4 = L_2540_.lower
		end
		L_2533_arg4 = L_2533_arg4(L_2534_arg5)
		do
			local L_2541_ = L_2531_arg2;
			L_2535_arg6 = L_2541_;
			L_2534_arg5 = L_2541_.lower
		end
		L_2534_arg5 = L_2534_arg5(L_2535_arg6)
		L_2539_arg10 = (L_2533_arg4 == L_2534_arg5)
		if L_2539_arg10 then
			L_2533_arg4 = {}
			L_2534_arg5 = {}
			L_2535_arg6 = L_14_func(L_13_.fn_162_buildMainFeaturesTab, L_2530_arg1, {
				{
					L_2533_arg4
				},
				{
					L_2534_arg5
				},
				L_2529_arg0[2]
			})
			L_2536_arg7 = {}
			L_2537_arg8 = L_14_func(L_13_.fn_181_NewSection, L_2530_arg1, {
				{
					L_2533_arg4
				},
				{
					L_2534_arg5
				},
				L_2529_arg0[2],
				L_2529_arg0[3],
				L_2529_arg0[4]
			})
			L_2536_arg7.NewSection = L_2537_arg8
			L_2537_arg8 = L_14_func(L_13_.fn_182_NewToggle, L_2530_arg1, {})
			L_2536_arg7.NewToggle = L_2537_arg8
			L_2536_arg7.NewButton = L_2537_arg8
			L_2536_arg7.NewSlider = L_2537_arg8
			return L_2536_arg7
		else
			L_2533_arg4 = L_14_func(L_13_.fn_159_NewToggle, L_2530_arg1, {})
			L_2534_arg5 = {}
			L_2534_arg5.NewToggle = L_2533_arg4
			L_2534_arg5.NewButton = L_2533_arg4
			L_2534_arg5.NewSlider = L_2533_arg4
			L_2534_arg5.NewDropdown = L_2533_arg4
			L_2534_arg5.NewLabel = L_2533_arg4
			L_2534_arg5.NewPremiumToggle = L_2533_arg4
			L_2534_arg5.NewPremiumButton = L_2533_arg4
			L_2534_arg5.NewPremiumSlider = L_2533_arg4
			L_2534_arg5.NewPremiumDropdown = L_2533_arg4
			L_2535_arg6 = L_14_func(L_13_.fn_160_NewSection, L_2530_arg1, {
				{
					L_2534_arg5
				}
			})
			L_2534_arg5.NewSection = L_2535_arg6
			L_2535_arg6 = {}
			L_2536_arg7 = L_14_func(L_13_.fn_161_NewSection, L_2530_arg1, {
				{
					L_2534_arg5
				}
			})
			L_2535_arg6.NewSection = L_2536_arg7
			L_2535_arg6.NewToggle = L_2533_arg4
			L_2535_arg6.NewButton = L_2533_arg4
			L_2535_arg6.NewSlider = L_2533_arg4
			L_2535_arg6.NewDropdown = L_2533_arg4
			L_2535_arg6.NewPremiumToggle = L_2533_arg4
			L_2535_arg6.NewPremiumButton = L_2533_arg4
			L_2535_arg6.NewPremiumSlider = L_2533_arg4
			L_2535_arg6.NewPremiumDropdown = L_2533_arg4
			return L_2535_arg6
		end
	end
	L_2533_arg4 = L_14_func(L_13_.fn_159_NewToggle, L_2530_arg1, {})
	L_2534_arg5 = {}
	L_2534_arg5.NewToggle = L_2533_arg4
	L_2534_arg5.NewButton = L_2533_arg4
	L_2534_arg5.NewSlider = L_2533_arg4
	L_2534_arg5.NewDropdown = L_2533_arg4
	L_2534_arg5.NewLabel = L_2533_arg4
	L_2534_arg5.NewPremiumToggle = L_2533_arg4
	L_2534_arg5.NewPremiumButton = L_2533_arg4
	L_2534_arg5.NewPremiumSlider = L_2533_arg4
	L_2534_arg5.NewPremiumDropdown = L_2533_arg4
	L_2535_arg6 = L_14_func(L_13_.fn_160_NewSection, L_2530_arg1, {
		{
			L_2534_arg5
		}
	})
	L_2534_arg5.NewSection = L_2535_arg6
	L_2535_arg6 = {}
	L_2536_arg7 = L_14_func(L_13_.fn_161_NewSection, L_2530_arg1, {
		{
			L_2534_arg5
		}
	})
	L_2535_arg6.NewSection = L_2536_arg7
	L_2535_arg6.NewToggle = L_2533_arg4
	L_2535_arg6.NewButton = L_2533_arg4
	L_2535_arg6.NewSlider = L_2533_arg4
	L_2535_arg6.NewDropdown = L_2533_arg4
	L_2535_arg6.NewPremiumToggle = L_2533_arg4
	L_2535_arg6.NewPremiumButton = L_2533_arg4
	L_2535_arg6.NewPremiumSlider = L_2533_arg4
	L_2535_arg6.NewPremiumDropdown = L_2533_arg4
	return L_2535_arg6
end

L_13_.fn_184_isPremiumFeatureName = function(L_2542_arg0, L_2543_arg1, ...)
	local L_2544_, L_2545_ = ...
	L_2544_ = (L_2544_ or ""):lower()
	L_2545_ = (L_2545_ or ""):lower()
	local L_2546_ = {
		"auto",
		"farm",
		"kill",
		"aura",
		"tp",
		"teleport",
		"fly",
		"speed",
		"click",
		"mansion",
		"oil",
		"ship",
		"airdrop",
		"rob",
		"npc",
		"turret",
		"glider",
		"items",
		"give",
	}
	for L_2547_forvar0, L_2548_forvar1 in ipairs(L_2546_) do
		if L_2544_:find(L_2548_forvar1, 1, true) or L_2545_:find(L_2548_forvar1, 1, true) then
			return true
		end
	end
	return false
end

L_13_.fn_185_AddSection = function(L_2549_arg0, L_2550_arg1, L_2551_arg2, L_2552_arg3)
	return L_2551_arg2
end

L_13_.fn_186_AddButton = function(L_2553_arg0, L_2554_arg1, L_2555_arg2, L_2556_arg3, L_2557_arg4, L_2558_arg5, L_2559_arg6, L_2560_arg7, L_2561_arg8, L_2562_arg9)
	L_2557_arg4 = L_2553_arg0[1][1]
	L_2558_arg5 = L_2556_arg3.Title
	if not L_2558_arg5 then
		L_2558_arg5 = L_2556_arg3.Name
	end
	L_2559_arg6 = L_2556_arg3.Description
	if not L_2559_arg6 then
		L_2559_arg6 = L_2556_arg3.Desc
	end
	L_2557_arg4 = L_2557_arg4(L_2558_arg5, L_2559_arg6)
	if not L_2557_arg4 then
		L_2558_arg5 = L_2553_arg0[3][1]
		L_2560_arg7 = L_2556_arg3.Title
		if not L_2560_arg7 then
			L_2560_arg7 = L_2556_arg3.Name
			if not L_2560_arg7 then
				L_2560_arg7 = "Button"
			end
		end
		L_2561_arg8 = L_2556_arg3.Description
		if not L_2561_arg8 then
			L_2561_arg8 = L_2556_arg3.Desc
			if not L_2561_arg8 then
				L_2561_arg8 = ""
			end
		end
		L_2562_arg9 = L_2556_arg3.Callback
		do
			local L_2563_ = L_2558_arg5;
			L_2559_arg6 = L_2563_;
			L_2558_arg5 = L_2563_.NewButton
		end
		L_2558_arg5(L_2559_arg6, L_2560_arg7, L_2561_arg8, L_2562_arg9)
		return
	else
		L_2558_arg5 = L_2553_arg0[2][1]
		L_2560_arg7 = L_2556_arg3.Title
		if not L_2560_arg7 then
			L_2560_arg7 = L_2556_arg3.Name
			if not L_2560_arg7 then
				L_2560_arg7 = "Button"
			end
		end
		L_2561_arg8 = L_2556_arg3.Description
		if not L_2561_arg8 then
			L_2561_arg8 = L_2556_arg3.Desc
			if not L_2561_arg8 then
				L_2561_arg8 = ""
			end
		end
		L_2562_arg9 = L_2556_arg3.Callback
		do
			local L_2564_ = L_2558_arg5;
			L_2559_arg6 = L_2564_;
			L_2558_arg5 = L_2564_.NewPremiumButton
		end
		L_2558_arg5(L_2559_arg6, L_2560_arg7, L_2561_arg8, L_2562_arg9)
		return
	end
end

L_13_.fn_187 = function(L_2565_arg0, L_2566_arg1, L_2567_arg2, L_2568_arg3)
	L_2567_arg2 = L_2565_arg0[1][1]
	L_2568_arg3 = L_2565_arg0[2][1]
	L_2567_arg2(L_2568_arg3)
	return
end

L_13_.fn_188 = function(L_2569_arg0, L_2570_arg1, L_2571_arg2, L_2572_arg3, L_2573_arg4)
	L_2572_arg3 = L_2569_arg0[1][1]
	if L_2572_arg3 then
		L_2572_arg3 = L_10_func(L_2570_arg1, "pcall")
		L_2573_arg4 = L_14_func(L_13_.fn_187, L_2570_arg1, {
			L_2569_arg0[1],
			{
				L_2571_arg2
			}
		})
		L_2572_arg3(L_2573_arg4)
	end
	return
end

L_13_.fn_189 = function(L_2574_arg0, L_2575_arg1, L_2576_arg2, L_2577_arg3)
	L_2576_arg2 = L_2574_arg0[1][1]
	L_2577_arg3 = L_2574_arg0[2][1]
	L_2576_arg2(L_2577_arg3)
	return
end

L_13_.fn_190 = function(L_2578_arg0, L_2579_arg1, L_2580_arg2, L_2581_arg3, L_2582_arg4)
	L_2581_arg3 = L_2578_arg0[1][1]
	if L_2581_arg3 then
		L_2581_arg3 = L_10_func(L_2579_arg1, "pcall")
		L_2582_arg4 = L_14_func(L_13_.fn_189, L_2579_arg1, {
			L_2578_arg0[1],
			{
				L_2580_arg2
			}
		})
		L_2581_arg3(L_2582_arg4)
	end
	return
end

L_13_.fn_191_controlSet = function(L_2583_arg0, L_2584_arg1, L_2585_arg2, L_2586_arg3, L_2587_arg4)
	L_2585_arg2 = L_2583_arg0[1][1]
	L_2587_arg4 = L_2583_arg0[2][1]
	do
		local L_2588_ = L_2585_arg2;
		L_2586_arg3 = L_2588_;
		L_2585_arg2 = L_2588_.Set
	end
	L_2585_arg2(L_2586_arg3, L_2587_arg4)
	return
end

L_13_.fn_192_OnChanged = function(L_2589_arg0, L_2590_arg1, L_2591_arg2, L_2592_arg3, L_2593_arg4)
	L_2589_arg0[1][1] = L_2592_arg3
	L_2593_arg4 = L_2589_arg0[2][1]
	return L_2593_arg4
end

L_13_.fn_193_toggleSet = function(L_2594_arg0, L_2595_arg1, L_2596_arg2, L_2597_arg3, L_2598_arg4)
	L_2596_arg2 = L_2594_arg0[1][1]
	L_2598_arg4 = L_2594_arg0[2][1]
	do
		local L_2599_ = L_2596_arg2;
		L_2597_arg3 = L_2599_;
		L_2596_arg2 = L_2599_.Set
	end
	L_2596_arg2(L_2597_arg3, L_2598_arg4)
	return
end

L_13_.fn_194_SetValue = function(L_2600_arg0, L_2601_arg1, L_2602_arg2, L_2603_arg3, L_2604_arg4, L_2605_arg5)
	L_2604_arg4 = L_10_func(L_2601_arg1, "pcall")
	L_2605_arg5 = L_14_func(L_13_.fn_193_toggleSet, L_2601_arg1, {
		L_2600_arg0[1],
		{
			L_2603_arg3
		}
	})
	L_2604_arg4(L_2605_arg5)
	return
end

L_13_.fn_195_AddToggle = function(L_2606_arg0, L_2607_arg1, ...)
	local L_2608_, L_2609_, L_2610_ = ...
	local L_2611_ = L_2610_ or L_2609_
	local L_2612_ = L_2611_.Title or L_2611_.Name or "Toggle"
	local L_2613_ = L_2611_.Description or L_2611_.Desc or ""
	local L_2614_ = {
		L_2611_.Callback
	}
	local L_2615_ = L_2611_.Default or false
	local L_2616_ = L_2606_arg0[1][1](L_2612_, L_2613_)
	local L_2617_ = {
		nil
	}
	if L_2616_ then
		L_2617_[1] = L_2606_arg0[2][1]:NewPremiumToggle(
            L_2612_,
            L_2613_,
            L_14_func(L_13_.fn_188, L_2607_arg1, {
			L_2614_
		})
        )
	else
		L_2617_[1] = L_2606_arg0[3][1]:NewToggle(
            L_2612_,
            L_2613_,
            L_14_func(L_13_.fn_190, L_2607_arg1, {
			L_2614_
		})
        )
	end
	local L_2618_ = L_2617_[1]
	if L_2615_ and L_2618_ and L_2618_.Set then
		L_10_func(L_2607_arg1, "pcall")(L_14_func(
            L_13_.fn_191_controlSet, L_2607_arg1, {
			L_2617_,
			{
				L_2615_
			}
		}
        ))
	end
	local L_2619_ = {}
	L_2619_.OnChanged = L_14_func(L_13_.fn_192_OnChanged, L_2607_arg1, {
		L_2614_,
		{
			L_2619_
		}
	})
	L_2619_.SetValue = L_14_func(L_13_.fn_194_SetValue, L_2607_arg1, {
		L_2617_
	})
	return L_2619_
end

L_13_.fn_196 = function(L_2620_arg0, L_2621_arg1, L_2622_arg2, L_2623_arg3)
	L_2622_arg2 = L_2620_arg0[1][1]
	L_2623_arg3 = L_2620_arg0[2][1]
	L_2622_arg2(L_2623_arg3)
	return
end

L_13_.fn_197 = function(L_2624_arg0, L_2625_arg1, L_2626_arg2, L_2627_arg3, L_2628_arg4)
	L_2627_arg3 = L_2624_arg0[1][1]
	if L_2627_arg3 then
		L_2627_arg3 = L_10_func(L_2625_arg1, "pcall")
		L_2628_arg4 = L_14_func(L_13_.fn_196, L_2625_arg1, {
			L_2624_arg0[1],
			{
				L_2626_arg2
			}
		})
		L_2627_arg3(L_2628_arg4)
	end
	return
end

L_13_.fn_198 = function(L_2629_arg0, L_2630_arg1, L_2631_arg2, L_2632_arg3)
	L_2631_arg2 = L_2629_arg0[1][1]
	L_2632_arg3 = L_2629_arg0[2][1]
	L_2631_arg2(L_2632_arg3)
	return
end

L_13_.fn_199 = function(L_2633_arg0, L_2634_arg1, L_2635_arg2, L_2636_arg3, L_2637_arg4)
	L_2636_arg3 = L_2633_arg0[1][1]
	if L_2636_arg3 then
		L_2636_arg3 = L_10_func(L_2634_arg1, "pcall")
		L_2637_arg4 = L_14_func(L_13_.fn_198, L_2634_arg1, {
			L_2633_arg0[1],
			{
				L_2635_arg2
			}
		})
		L_2636_arg3(L_2637_arg4)
	end
	return
end

L_13_.fn_200_sliderSet = function(L_2638_arg0, L_2639_arg1, L_2640_arg2, L_2641_arg3, L_2642_arg4)
	L_2640_arg2 = L_2638_arg0[1][1]
	L_2642_arg4 = L_2638_arg0[2][1]
	do
		local L_2643_ = L_2640_arg2;
		L_2641_arg3 = L_2643_;
		L_2640_arg2 = L_2643_.Set
	end
	L_2640_arg2(L_2641_arg3, L_2642_arg4)
	return
end

L_13_.fn_201_OnChanged = function(L_2644_arg0, L_2645_arg1, L_2646_arg2, L_2647_arg3, L_2648_arg4)
	L_2644_arg0[1][1] = L_2647_arg3
	L_2648_arg4 = L_2644_arg0[2][1]
	return L_2648_arg4
end

L_13_.fn_202_dropdownSet = function(L_2649_arg0, L_2650_arg1, L_2651_arg2, L_2652_arg3, L_2653_arg4)
	L_2651_arg2 = L_2649_arg0[1][1]
	L_2653_arg4 = L_2649_arg0[2][1]
	do
		local L_2654_ = L_2651_arg2;
		L_2652_arg3 = L_2654_;
		L_2651_arg2 = L_2654_.Set
	end
	L_2651_arg2(L_2652_arg3, L_2653_arg4)
	return
end

L_13_.fn_203_SetValue = function(L_2655_arg0, L_2656_arg1, L_2657_arg2, L_2658_arg3, L_2659_arg4, L_2660_arg5)
	L_2659_arg4 = L_10_func(L_2656_arg1, "pcall")
	L_2660_arg5 = L_14_func(L_13_.fn_202_dropdownSet, L_2656_arg1, {
		L_2655_arg0[1],
		{
			L_2658_arg3
		}
	})
	L_2659_arg4(L_2660_arg5)
	return
end

L_13_.fn_204_AddSlider = function(L_2661_arg0, L_2662_arg1, ...)
	local L_2663_, L_2664_, L_2665_ = ...
	local L_2666_ = L_2665_ or L_2664_
	local L_2667_ = L_2666_.Title or L_2666_.Name or "Slider"
	local L_2668_ = L_2666_.Description or L_2666_.Desc or ""
	local L_2669_ = {
		L_2666_.Callback
	}
	local L_2670_ = L_2666_.Min or 0
	local L_2671_ = L_2666_.Max or 100
	local L_2672_ = L_2666_.Default or L_2670_
	local L_2673_ = L_2661_arg0[1][1](L_2667_, L_2668_)
	local L_2674_ = {
		nil
	}
	if L_2673_ then
		L_2674_[1] = L_2661_arg0[2][1]:NewPremiumSlider(
            L_2667_,
            L_2668_,
            L_2671_,
            L_2670_,
            L_14_func(L_13_.fn_197, L_2662_arg1, {
			L_2669_
		})
        )
	else
		L_2674_[1] = L_2661_arg0[3][1]:NewSlider(
            L_2667_,
            L_2668_,
            L_2671_,
            L_2670_,
            L_14_func(L_13_.fn_199, L_2662_arg1, {
			L_2669_
		})
        )
	end
	local L_2675_ = L_2674_[1]
	if L_2672_ and L_2675_ and L_2675_.Set then
		L_10_func(L_2662_arg1, "pcall")(L_14_func(
            L_13_.fn_200_sliderSet, L_2662_arg1, {
			L_2674_,
			{
				L_2672_
			}
		}
        ))
	end
	local L_2676_ = {}
	L_2676_.OnChanged = L_14_func(L_13_.fn_201_OnChanged, L_2662_arg1, {
		L_2669_,
		{
			L_2676_
		}
	})
	L_2676_.SetValue = L_14_func(L_13_.fn_203_SetValue, L_2662_arg1, {
		L_2674_
	})
	return L_2676_
end

L_13_.fn_205 = function(L_2677_arg0, L_2678_arg1, L_2679_arg2, L_2680_arg3)
	L_2679_arg2 = L_2677_arg0[1][1]
	L_2680_arg3 = L_2677_arg0[2][1]
	L_2679_arg2(L_2680_arg3)
	return
end

L_13_.fn_206 = function(L_2681_arg0, L_2682_arg1, L_2683_arg2, L_2684_arg3, L_2685_arg4)
	L_2684_arg3 = L_2681_arg0[1][1]
	if L_2684_arg3 then
		L_2684_arg3 = L_10_func(L_2682_arg1, "pcall")
		L_2685_arg4 = L_14_func(L_13_.fn_205, L_2682_arg1, {
			L_2681_arg0[1],
			{
				L_2683_arg2
			}
		})
		L_2684_arg3(L_2685_arg4)
	end
	return
end

L_13_.fn_207 = function(L_2686_arg0, L_2687_arg1, L_2688_arg2, L_2689_arg3)
	L_2688_arg2 = L_2686_arg0[1][1]
	L_2689_arg3 = L_2686_arg0[2][1]
	L_2688_arg2(L_2689_arg3)
	return
end

L_13_.fn_208 = function(L_2690_arg0, L_2691_arg1, L_2692_arg2, L_2693_arg3, L_2694_arg4)
	L_2693_arg3 = L_2690_arg0[1][1]
	if L_2693_arg3 then
		L_2693_arg3 = L_10_func(L_2691_arg1, "pcall")
		L_2694_arg4 = L_14_func(L_13_.fn_207, L_2691_arg1, {
			L_2690_arg0[1],
			{
				L_2692_arg2
			}
		})
		L_2693_arg3(L_2694_arg4)
	end
	return
end

L_13_.fn_209_keybindSet = function(L_2695_arg0, L_2696_arg1, L_2697_arg2, L_2698_arg3, L_2699_arg4)
	L_2697_arg2 = L_2695_arg0[1][1]
	L_2699_arg4 = L_2695_arg0[2][1]
	do
		local L_2700_ = L_2697_arg2;
		L_2698_arg3 = L_2700_;
		L_2697_arg2 = L_2700_.Set
	end
	L_2697_arg2(L_2698_arg3, L_2699_arg4)
	return
end

L_13_.fn_210_OnChanged = function(L_2701_arg0, L_2702_arg1, L_2703_arg2, L_2704_arg3, L_2705_arg4)
	L_2701_arg0[1][1] = L_2704_arg3
	L_2705_arg4 = L_2701_arg0[2][1]
	return L_2705_arg4
end

L_13_.fn_211_colorSet = function(L_2706_arg0, L_2707_arg1, L_2708_arg2, L_2709_arg3, L_2710_arg4)
	L_2708_arg2 = L_2706_arg0[1][1]
	L_2710_arg4 = L_2706_arg0[2][1]
	do
		local L_2711_ = L_2708_arg2;
		L_2709_arg3 = L_2711_;
		L_2708_arg2 = L_2711_.Set
	end
	L_2708_arg2(L_2709_arg3, L_2710_arg4)
	return
end

L_13_.fn_212_SetValue = function(L_2712_arg0, L_2713_arg1, L_2714_arg2, L_2715_arg3, L_2716_arg4, L_2717_arg5)
	L_2716_arg4 = L_10_func(L_2713_arg1, "pcall")
	L_2717_arg5 = L_14_func(L_13_.fn_211_colorSet, L_2713_arg1, {
		L_2712_arg0[1],
		{
			L_2715_arg3
		}
	})
	L_2716_arg4(L_2717_arg5)
	return
end

L_13_.fn_213_AddDropdown = function(L_2718_arg0, L_2719_arg1, ...)
	local L_2720_, L_2721_, L_2722_ = ...
	local L_2723_ = L_2722_ or L_2721_
	local L_2724_ = L_2723_.Title or L_2723_.Name or "Dropdown"
	local L_2725_ = L_2723_.Description or L_2723_.Desc or ""
	local L_2726_ = {
		L_2723_.Callback
	}
	local L_2727_ = L_2723_.Values or L_2723_.List or {}
	local L_2728_ = L_2723_.Default
	local L_2729_ = L_2718_arg0[1][1](L_2724_, L_2725_)
	local L_2730_ = {
		nil
	}
	if L_2729_ then
		L_2730_[1] = L_2718_arg0[2][1]:NewPremiumDropdown(
            L_2724_,
            L_2725_,
            L_2727_,
            L_14_func(L_13_.fn_206, L_2719_arg1, {
			L_2726_
		})
        )
	else
		L_2730_[1] = L_2718_arg0[3][1]:NewDropdown(
            L_2724_,
            L_2725_,
            L_2727_,
            L_14_func(L_13_.fn_208, L_2719_arg1, {
			L_2726_
		})
        )
	end
	local L_2731_ = L_2730_[1]
	if L_2728_ and L_2731_ and L_2731_.Set then
		L_10_func(L_2719_arg1, "pcall")(L_14_func(
            L_13_.fn_209_keybindSet, L_2719_arg1, {
			L_2730_,
			{
				L_2728_
			}
		}
        ))
	end
	local L_2732_ = {}
	L_2732_.OnChanged = L_14_func(L_13_.fn_210_OnChanged, L_2719_arg1, {
		L_2726_,
		{
			L_2732_
		}
	})
	L_2732_.SetValue = L_14_func(L_13_.fn_212_SetValue, L_2719_arg1, {
		L_2730_
	})
	return L_2732_
end

L_13_.fn_214_AddLabel = function(L_2733_arg0, L_2734_arg1, L_2735_arg2, L_2736_arg3, L_2737_arg4, L_2738_arg5, L_2739_arg6)
	L_2737_arg4 = L_2733_arg0[1][1]
	L_2739_arg6 = L_2736_arg3
	do
		local L_2740_ = L_2737_arg4;
		L_2738_arg5 = L_2740_;
		L_2737_arg4 = L_2740_.NewLabel
	end
	L_2737_arg4(L_2738_arg5, L_2739_arg6)
	return
end

L_13_.fn_215_AddParagraph = function(L_2741_arg0, L_2742_arg1, L_2743_arg2, L_2744_arg3, L_2745_arg4, L_2746_arg5, L_2747_arg6, L_2748_arg7, L_2749_arg8, L_2750_arg9, L_2751_arg10)
	L_2745_arg4 = L_2741_arg0[1][1]
	L_2751_arg10 = L_2744_arg3.Title
	L_2748_arg7 = L_2751_arg10
	if not L_2748_arg7 then
		L_2748_arg7 = ""
	end
	L_2749_arg8 = ": "
	L_2751_arg10 = L_2744_arg3.Content
	L_2750_arg9 = L_2751_arg10
	if not L_2750_arg9 then
		L_2750_arg9 = ""
	end
	L_2747_arg6 = L_2748_arg7 .. L_2749_arg8 .. L_2750_arg9
	do
		local L_2752_ = L_2745_arg4;
		L_2746_arg5 = L_2752_;
		L_2745_arg4 = L_2752_.NewLabel
	end
	L_2745_arg4(L_2746_arg5, L_2747_arg6)
	return
end

L_13_.fn_216_OnChanged = function(L_2753_arg0, L_2754_arg1, L_2755_arg2, L_2756_arg3)
	return L_2755_arg2
end

L_13_.fn_217_SetValue = function(L_2757_arg0, L_2758_arg1, L_2759_arg2, L_2760_arg3)
	return
end

L_13_.fn_218_AddKeybind = function(L_2761_arg0, L_2762_arg1, L_2763_arg2, L_2764_arg3, L_2765_arg4, L_2766_arg5, L_2767_arg6)
	L_2766_arg5 = {}
	L_2767_arg6 = L_14_func(L_13_.fn_216_OnChanged, L_2762_arg1, {})
	L_2766_arg5.OnChanged = L_2767_arg6
	L_2767_arg6 = L_14_func(L_13_.fn_217_SetValue, L_2762_arg1, {})
	L_2766_arg5.SetValue = L_2767_arg6
	return L_2766_arg5
end

L_13_.fn_219_OnChanged = function(L_2768_arg0, L_2769_arg1, L_2770_arg2, L_2771_arg3)
	return L_2770_arg2
end

L_13_.fn_220_SetValue = function(L_2772_arg0, L_2773_arg1, L_2774_arg2, L_2775_arg3)
	return
end

L_13_.fn_221_AddColorpicker = function(L_2776_arg0, L_2777_arg1, L_2778_arg2, L_2779_arg3, L_2780_arg4, L_2781_arg5, L_2782_arg6)
	L_2781_arg5 = {}
	L_2782_arg6 = L_14_func(L_13_.fn_219_OnChanged, L_2777_arg1, {})
	L_2781_arg5.OnChanged = L_2782_arg6
	L_2782_arg6 = L_14_func(L_13_.fn_220_SetValue, L_2777_arg1, {})
	L_2781_arg5.SetValue = L_2782_arg6
	return L_2781_arg5
end

L_13_.fn_222_AddTab = function(L_2783_arg0, L_2784_arg1, L_2785_arg2, L_2786_arg3, L_2787_arg4, L_2788_arg5)
	L_2787_arg4 = {}
	L_2788_arg5 = L_14_func(L_13_.fn_185_AddSection, L_2784_arg1, {})
	L_2787_arg4.AddSection = L_2788_arg5
	L_2788_arg5 = L_14_func(L_13_.fn_186_AddButton, L_2784_arg1, {
		L_2783_arg0[1],
		L_2783_arg0[2],
		L_2783_arg0[3]
	})
	L_2787_arg4.AddButton = L_2788_arg5
	L_2788_arg5 = L_14_func(L_13_.fn_195_AddToggle, L_2784_arg1, {
		L_2783_arg0[1],
		L_2783_arg0[2],
		L_2783_arg0[3]
	})
	L_2787_arg4.AddToggle = L_2788_arg5
	L_2788_arg5 = L_14_func(L_13_.fn_204_AddSlider, L_2784_arg1, {
		L_2783_arg0[1],
		L_2783_arg0[2],
		L_2783_arg0[3]
	})
	L_2787_arg4.AddSlider = L_2788_arg5
	L_2788_arg5 = L_14_func(L_13_.fn_213_AddDropdown, L_2784_arg1, {
		L_2783_arg0[1],
		L_2783_arg0[2],
		L_2783_arg0[3]
	})
	L_2787_arg4.AddDropdown = L_2788_arg5
	L_2788_arg5 = L_14_func(L_13_.fn_214_AddLabel, L_2784_arg1, {
		L_2783_arg0[3]
	})
	L_2787_arg4.AddLabel = L_2788_arg5
	L_2788_arg5 = L_14_func(L_13_.fn_215_AddParagraph, L_2784_arg1, {
		L_2783_arg0[3]
	})
	L_2787_arg4.AddParagraph = L_2788_arg5
	L_2788_arg5 = L_14_func(L_13_.fn_218_AddKeybind, L_2784_arg1, {})
	L_2787_arg4.AddKeybind = L_2788_arg5
	L_2788_arg5 = L_14_func(L_13_.fn_221_AddColorpicker, L_2784_arg1, {})
	L_2787_arg4.AddColorpicker = L_2788_arg5
	return L_2787_arg4
end

L_13_.fn_223_SelectTab = function(L_2789_arg0, L_2790_arg1, L_2791_arg2, L_2792_arg3)
	return
end

L_13_.fn_224_CreateWindow = function(L_2793_arg0, L_2794_arg1, L_2795_arg2, L_2796_arg3, L_2797_arg4, L_2798_arg5)
	L_2797_arg4 = {}
	L_2798_arg5 = L_14_func(L_13_.fn_222_AddTab, L_2794_arg1, {
		L_2793_arg0[1],
		L_2793_arg0[2],
		L_2793_arg0[3]
	})
	L_2797_arg4.AddTab = L_2798_arg5
	L_2798_arg5 = L_14_func(L_13_.fn_223_SelectTab, L_2794_arg1, {})
	L_2797_arg4.SelectTab = L_2798_arg5
	return L_2797_arg4
end

L_13_.fn_225_notify = function(L_2799_arg0, L_2800_arg1, L_2801_arg2, L_2802_arg3, L_2803_arg4, L_2804_arg5, L_2805_arg6, L_2806_arg7, L_2807_arg8)
	L_2801_arg2 = L_2799_arg0[1][1]
	L_2805_arg6 = L_2799_arg0[2][1]
	L_2804_arg5 = L_2805_arg6.Title
	L_2803_arg4 = L_2804_arg5
	if not L_2803_arg4 then
		L_2803_arg4 = "Notification"
	end
	L_2805_arg6 = L_2799_arg0[2][1]
	L_2804_arg5 = L_2805_arg6.Content
	if not L_2804_arg5 then
		L_2805_arg6 = L_2799_arg0[2][1]
		L_2804_arg5 = L_2805_arg6.Text
		if not L_2804_arg5 then
			L_2804_arg5 = ""
		end
	end
	L_2807_arg8 = L_2799_arg0[2][1]
	L_2806_arg7 = L_2807_arg8.Duration
	L_2805_arg6 = L_2806_arg7
	if not L_2805_arg6 then
		L_2805_arg6 = 3
	end
	do
		local L_2808_ = L_2801_arg2;
		L_2802_arg3 = L_2808_;
		L_2801_arg2 = L_2808_.Notify
	end
	L_2801_arg2(L_2802_arg3, L_2803_arg4, L_2804_arg5, L_2805_arg6)
	return
end

L_13_.fn_226_Notify = function(L_2809_arg0, L_2810_arg1, L_2811_arg2, L_2812_arg3, L_2813_arg4, L_2814_arg5)
	L_2813_arg4 = L_10_func(L_2810_arg1, "pcall")
	L_2814_arg5 = L_14_func(L_13_.fn_225_notify, L_2810_arg1, {
		L_2809_arg0[1],
		{
			L_2812_arg3
		}
	})
	L_2813_arg4(L_2814_arg5)
	return
end

L_13_.fn_227_buildFreePremiumSections = function(L_2815_arg0, L_2816_arg1, L_2817_arg2, L_2818_arg3, L_2819_arg4, L_2820_arg5, L_2821_arg6, L_2822_arg7, L_2823_arg8)
	L_2818_arg3 = L_2815_arg0[1][1]
	L_2819_arg4 = L_2817_arg2
	L_2820_arg5 = L_2817_arg2
	L_2818_arg3 = L_2818_arg3(L_2819_arg4, L_2820_arg5)
	L_2819_arg4 = {}
	L_2822_arg7 = "Free Features"
	do
		local L_2824_ = L_2818_arg3;
		L_2821_arg6 = L_2824_;
		L_2820_arg5 = L_2824_.NewSection
	end
	L_2820_arg5 = L_2820_arg5(L_2821_arg6, L_2822_arg7)
	L_2823_arg8 = "Premium Features"
	do
		local L_2825_ = L_2818_arg3;
		L_2822_arg7 = L_2825_;
		L_2821_arg6 = L_2825_.NewSection
	end
	L_2821_arg6 = L_2821_arg6(L_2822_arg7, L_2823_arg8)
	L_2822_arg7 = L_14_func(L_13_.fn_184_isPremiumFeatureName, L_2816_arg1, {})
	L_2823_arg8 = L_14_func(L_13_.fn_224_CreateWindow, L_2816_arg1, {
		{
			L_2822_arg7
		},
		{
			L_2821_arg6
		},
		{
			L_2820_arg5
		}
	})
	L_2819_arg4.CreateWindow = L_2823_arg8
	L_2823_arg8 = L_14_func(L_13_.fn_226_Notify, L_2816_arg1, {
		L_2815_arg0[2]
	})
	L_2819_arg4.Notify = L_2823_arg8
	return L_2819_arg4
end

L_13_.fn_228_stopPlayerModifierLoop = function(L_2826_arg0, L_2827_arg1, L_2828_arg2, L_2829_arg3)
	L_2829_arg3 = L_10_func(L_2827_arg1, "getgenv")
	L_2829_arg3 = L_2829_arg3()
	L_2828_arg2 = L_2829_arg3.PlayerModifierLoop
	do
		local L_2830_ = L_2828_arg2;
		L_2829_arg3 = L_2830_;
		L_2828_arg2 = L_2830_.Disconnect
	end
	L_2828_arg2(L_2829_arg3)
	return
end

L_13_.fn_229_disableDeadState = function(L_2831_arg0, L_2832_arg1, L_2833_arg2, L_2834_arg3, L_2835_arg4, L_2836_arg5)
	L_2833_arg2 = L_2831_arg0[1][1]
	L_2835_arg4 = L_10_func(L_2832_arg1, "Enum")
	L_2835_arg4 = L_2835_arg4.HumanoidStateType
	L_2835_arg4 = L_2835_arg4.Dead
	L_2836_arg5 = false
	do
		local L_2837_ = L_2833_arg2;
		L_2834_arg3 = L_2837_;
		L_2833_arg2 = L_2837_.SetStateEnabled
	end
	L_2833_arg2(L_2834_arg3, L_2835_arg4, L_2836_arg5)
	return
end

L_13_.fn_230_applyGodMode = function(L_2838_arg0, L_2839_arg1, L_2840_arg2, L_2841_arg3, L_2842_arg4, L_2843_arg5, L_2844_arg6, L_2845_arg7)
	L_2841_arg3 = L_10_func(L_2839_arg1, "game")
	L_2841_arg3 = L_2841_arg3.Players
	L_2841_arg3 = L_2841_arg3.LocalPlayer
	L_2840_arg2 = L_2841_arg3.Character
	if L_2840_arg2 then
		L_2843_arg5 = "Humanoid"
		do
			local L_2846_ = L_2840_arg2;
			L_2842_arg4 = L_2846_;
			L_2841_arg3 = L_2846_.FindFirstChild
		end
		L_2841_arg3 = L_2841_arg3(L_2842_arg4, L_2843_arg5)
		if L_2841_arg3 then
			L_2843_arg5 = "HumanoidRootPart"
			do
				local L_2847_ = L_2840_arg2;
				L_2842_arg4 = L_2847_;
				L_2841_arg3 = L_2847_.FindFirstChild
			end
			L_2841_arg3 = L_2841_arg3(L_2842_arg4, L_2843_arg5)
			if L_2841_arg3 then
				L_2841_arg3 = L_2840_arg2.Humanoid
				L_2843_arg5 = L_10_func(L_2839_arg1, "getgenv")
				L_2843_arg5 = L_2843_arg5()
				L_2842_arg4 = L_2843_arg5.GodModeEnabled
				if L_2842_arg4 then
					L_2842_arg4 = L_2841_arg3.MaxHealth
					L_2844_arg6 = (math.huge)
					L_2845_arg7 = (L_2842_arg4 == L_2844_arg6)
					if not L_2845_arg7 then
						L_2842_arg4 = (math.huge)
						L_2841_arg3.MaxHealth = L_2842_arg4
					end
					L_2842_arg4 = L_2841_arg3.Health
					L_2844_arg6 = (math.huge)
					L_2845_arg7 = (L_2842_arg4 == L_2844_arg6)
					if not L_2845_arg7 then
						L_2842_arg4 = (math.huge)
						L_2841_arg3.Health = L_2842_arg4
					end
					L_2842_arg4 = L_10_func(L_2839_arg1, "pcall")
					L_2843_arg5 = L_14_func(L_13_.fn_229_disableDeadState, L_2839_arg1, {
						{
							L_2841_arg3
						}
					})
					L_2842_arg4(L_2843_arg5)
				end
			end
		end
	end
	return
end

L_13_.fn_231 = function(L_2848_arg0, L_2849_arg1, L_2850_arg2, L_2851_arg3, L_2852_arg4)
	L_2851_arg3 = L_10_func(L_2849_arg1, "pcall")
	L_2852_arg4 = L_14_func(L_13_.fn_230_applyGodMode, L_2849_arg1, {})
	L_2851_arg3(L_2852_arg4)
	return
end

L_13_.fn_232_applyWalkSpeed = function(L_2853_arg0, L_2854_arg1, L_2855_arg2, L_2856_arg3, L_2857_arg4, L_2858_arg5)
	L_2856_arg3 = L_10_func(L_2854_arg1, "getgenv")
	L_2856_arg3 = L_2856_arg3()
	L_2856_arg3.WalkSpeedValue = L_2855_arg2
	L_2857_arg4 = L_10_func(L_2854_arg1, "game")
	L_2857_arg4 = L_2857_arg4.Players
	L_2857_arg4 = L_2857_arg4.LocalPlayer
	L_2856_arg3 = L_2857_arg4.Character
	if L_2856_arg3 then
		L_2857_arg4 = L_10_func(L_2854_arg1, "game")
		L_2857_arg4 = L_2857_arg4.Players
		L_2857_arg4 = L_2857_arg4.LocalPlayer
		L_2856_arg3 = L_2857_arg4.Character
		L_2858_arg5 = "Humanoid"
		do
			local L_2859_ = L_2856_arg3;
			L_2857_arg4 = L_2859_;
			L_2856_arg3 = L_2859_.FindFirstChild
		end
		L_2856_arg3 = L_2856_arg3(L_2857_arg4, L_2858_arg5)
		if L_2856_arg3 then
			L_2858_arg5 = L_10_func(L_2854_arg1, "game")
			L_2858_arg5 = L_2858_arg5.Players
			L_2858_arg5 = L_2858_arg5.LocalPlayer
			L_2857_arg4 = L_2858_arg5.Character
			L_2856_arg3 = L_2857_arg4.Humanoid
			L_2856_arg3.WalkSpeed = L_2855_arg2
		end
	end
	return
end

L_13_.fn_233_applyJumpPower = function(L_2860_arg0, L_2861_arg1, L_2862_arg2, L_2863_arg3, L_2864_arg4, L_2865_arg5)
	L_2863_arg3 = L_10_func(L_2861_arg1, "getgenv")
	L_2863_arg3 = L_2863_arg3()
	L_2863_arg3.JumpPowerValue = L_2862_arg2
	L_2864_arg4 = L_10_func(L_2861_arg1, "game")
	L_2864_arg4 = L_2864_arg4.Players
	L_2864_arg4 = L_2864_arg4.LocalPlayer
	L_2863_arg3 = L_2864_arg4.Character
	if L_2863_arg3 then
		L_2864_arg4 = L_10_func(L_2861_arg1, "game")
		L_2864_arg4 = L_2864_arg4.Players
		L_2864_arg4 = L_2864_arg4.LocalPlayer
		L_2863_arg3 = L_2864_arg4.Character
		L_2865_arg5 = "Humanoid"
		do
			local L_2866_ = L_2863_arg3;
			L_2864_arg4 = L_2866_;
			L_2863_arg3 = L_2866_.FindFirstChild
		end
		L_2863_arg3 = L_2863_arg3(L_2864_arg4, L_2865_arg5)
		if L_2863_arg3 then
			L_2865_arg5 = L_10_func(L_2861_arg1, "game")
			L_2865_arg5 = L_2865_arg5.Players
			L_2865_arg5 = L_2865_arg5.LocalPlayer
			L_2864_arg4 = L_2865_arg5.Character
			L_2863_arg3 = L_2864_arg4.Humanoid
			L_2863_arg3.JumpPower = L_2862_arg2
		end
	end
	return
end

L_13_.fn_234_applyGravity = function(L_2867_arg0, L_2868_arg1, L_2869_arg2, L_2870_arg3)
	L_2870_arg3 = L_10_func(L_2868_arg1, "game")
	L_2870_arg3 = L_2870_arg3.Workspace
	L_2870_arg3.Gravity = L_2869_arg2
	return
end

L_13_.fn_235_healCharacter = function(L_2871_arg0, L_2872_arg1, L_2873_arg2, L_2874_arg3, L_2875_arg4, L_2876_arg5, L_2877_arg6)
	L_2874_arg3 = L_10_func(L_2872_arg1, "game")
	L_2874_arg3 = L_2874_arg3.Players
	L_2874_arg3 = L_2874_arg3.LocalPlayer
	L_2873_arg2 = L_2874_arg3.Character
	if L_2873_arg2 then
		L_2876_arg5 = "Humanoid"
		do
			local L_2878_ = L_2873_arg2;
			L_2875_arg4 = L_2878_;
			L_2874_arg3 = L_2878_.FindFirstChild
		end
		L_2874_arg3 = L_2874_arg3(L_2875_arg4, L_2876_arg5)
		if L_2874_arg3 then
			L_2874_arg3 = L_2873_arg2.Humanoid
			L_2875_arg4 = 100
			L_2874_arg3.MaxHealth = L_2875_arg4
			L_2874_arg3 = L_2873_arg2.Humanoid
			L_2875_arg4 = 100
			L_2874_arg3.Health = L_2875_arg4
			L_2874_arg3 = L_2873_arg2.Humanoid
			L_2876_arg5 = L_10_func(L_2872_arg1, "Enum")
			L_2876_arg5 = L_2876_arg5.HumanoidStateType
			L_2876_arg5 = L_2876_arg5.Dead
			L_2877_arg6 = true
			do
				local L_2879_ = L_2874_arg3;
				L_2875_arg4 = L_2879_;
				L_2874_arg3 = L_2879_.SetStateEnabled
			end
			L_2874_arg3(L_2875_arg4, L_2876_arg5, L_2877_arg6)
		end
	end
	return
end

L_13_.fn_236_setGodMode = function(L_2880_arg0, L_2881_arg1, L_2882_arg2, L_2883_arg3, L_2884_arg4)
	L_2883_arg3 = L_10_func(L_2881_arg1, "getgenv")
	L_2883_arg3 = L_2883_arg3()
	L_2883_arg3.GodModeEnabled = L_2882_arg2
	if not L_2882_arg2 then
		L_2883_arg3 = L_10_func(L_2881_arg1, "pcall")
		L_2884_arg4 = L_14_func(L_13_.fn_235_healCharacter, L_2881_arg1, {})
		L_2883_arg3(L_2884_arg4)
	end
	return
end

L_13_.fn_237_applyNoclipToCharacter = function(L_2885_arg0, L_2886_arg1, ...)
	local L_2887_ = L_2885_arg0[1][1]
	local L_2888_ = L_10_func(L_2886_arg1, "game")
	if L_2887_ == false then
		local L_2889_ = L_2888_.Players.LocalPlayer.Character
		if L_2889_ ~= nil then
			local L_2890_ = L_10_func(L_2886_arg1, "floatName")
			for L_2891_forvar0, L_2892_forvar1 in pairs(L_2889_:GetDescendants()) do
				if L_2892_forvar1:IsA("BasePart")
                    and L_2892_forvar1.CanCollide
                    and L_2892_forvar1.Name ~= L_2890_ then
					L_2892_forvar1.CanCollide = false
				end
			end
		end
	end
	L_10_func(L_2886_arg1, "wait")(0.21)
	return
end

L_13_.fn_238_noclip = function(L_2893_arg0, L_2894_arg1, L_2895_arg2, L_2896_arg3, L_2897_arg4, L_2898_arg5, L_2899_arg6)
	L_2895_arg2 = false
	L_2893_arg0[1][1] = L_2895_arg2
	L_2895_arg2 = L_14_func(L_13_.fn_237_applyNoclipToCharacter, L_2894_arg1, {
		L_2893_arg0[1]
	})
	L_2897_arg4 = L_10_func(L_2894_arg1, "game")
	L_2899_arg6 = "RunService"
	do
		local L_2900_ = L_2897_arg4;
		L_2898_arg5 = L_2900_;
		L_2897_arg4 = L_2900_.GetService
	end
	L_2897_arg4 = L_2897_arg4(L_2898_arg5, L_2899_arg6)
	L_2896_arg3 = L_2897_arg4.Stepped
	L_2898_arg5 = L_2895_arg2
	do
		local L_2901_ = L_2896_arg3;
		L_2897_arg4 = L_2901_;
		L_2896_arg3 = L_2901_.Connect
	end
	L_2896_arg3 = L_2896_arg3(L_2897_arg4, L_2898_arg5)
	L_2893_arg0[2][1] = L_2896_arg3
	return
end

L_13_.fn_239_clip = function(L_2902_arg0, L_2903_arg1, L_2904_arg2, L_2905_arg3)
	L_2904_arg2 = L_2902_arg0[1][1]
	if L_2904_arg2 then
		L_2904_arg2 = L_2902_arg0[1][1]
		do
			local L_2906_ = L_2904_arg2;
			L_2905_arg3 = L_2906_;
			L_2904_arg2 = L_2906_.Disconnect
		end
		L_2904_arg2(L_2905_arg3)
	end
	L_2904_arg2 = true
	L_2902_arg0[2][1] = L_2904_arg2
	return
end

L_13_.fn_240 = function(L_2907_arg0, L_2908_arg1, L_2909_arg2, L_2910_arg3)
	if not L_2909_arg2 then
		L_2910_arg3 = L_10_func(L_2908_arg1, "clip")
		L_2910_arg3()
		return
	else
		L_2910_arg3 = L_10_func(L_2908_arg1, "noclip")
		L_2910_arg3()
		return
	end
end

L_13_.fn_241_forceJump = function(L_2911_arg0, L_2912_arg1, L_2913_arg2, L_2914_arg3, L_2915_arg4)
	L_2913_arg2 = L_2911_arg0[1][1]
	if L_2913_arg2 then
		L_2914_arg3 = L_10_func(L_2912_arg1, "game")
		L_2914_arg3 = L_2914_arg3.Players
		L_2914_arg3 = L_2914_arg3.LocalPlayer
		L_2913_arg2 = L_2914_arg3.Character
		if L_2913_arg2 then
			L_2914_arg3 = L_10_func(L_2912_arg1, "game")
			L_2914_arg3 = L_2914_arg3.Players
			L_2914_arg3 = L_2914_arg3.LocalPlayer
			L_2913_arg2 = L_2914_arg3.Character
			L_2915_arg4 = "Humanoid"
			do
				local L_2916_ = L_2913_arg2;
				L_2914_arg3 = L_2916_;
				L_2913_arg2 = L_2916_.FindFirstChild
			end
			L_2913_arg2 = L_2913_arg2(L_2914_arg3, L_2915_arg4)
			if L_2913_arg2 then
				L_2915_arg4 = L_10_func(L_2912_arg1, "game")
				L_2915_arg4 = L_2915_arg4.Players
				L_2915_arg4 = L_2915_arg4.LocalPlayer
				L_2914_arg3 = L_2915_arg4.Character
				L_2913_arg2 = L_2914_arg3.Humanoid
				L_2915_arg4 = "Jumping"
				do
					local L_2917_ = L_2913_arg2;
					L_2914_arg3 = L_2917_;
					L_2913_arg2 = L_2917_.ChangeState
				end
				L_2913_arg2(L_2914_arg3, L_2915_arg4)
			end
		end
	end
	return
end

L_13_.fn_242_bindInfiniteJump = function(L_2918_arg0, L_2919_arg1, L_2920_arg2, L_2921_arg3, L_2922_arg4, L_2923_arg5, L_2924_arg6)
	L_2918_arg0[1][1] = L_2920_arg2
	L_2922_arg4 = L_10_func(L_2919_arg1, "game")
	L_2924_arg6 = "UserInputService"
	do
		local L_2925_ = L_2922_arg4;
		L_2923_arg5 = L_2925_;
		L_2922_arg4 = L_2925_.GetService
	end
	L_2922_arg4 = L_2922_arg4(L_2923_arg5, L_2924_arg6)
	L_2921_arg3 = L_2922_arg4.JumpRequest
	L_2923_arg5 = L_14_func(L_13_.fn_241_forceJump, L_2919_arg1, {
		L_2918_arg0[1]
	})
	do
		local L_2926_ = L_2921_arg3;
		L_2922_arg4 = L_2926_;
		L_2921_arg3 = L_2926_.Connect
	end
	L_2921_arg3(L_2922_arg4, L_2923_arg5)
	return
end

L_13_.fn_243_setCameraFov = function(L_2927_arg0, L_2928_arg1, L_2929_arg2, L_2930_arg3)
	L_2930_arg3 = L_10_func(L_2928_arg1, "game")
	L_2930_arg3 = L_2930_arg3.Workspace
	L_2930_arg3 = L_2930_arg3.CurrentCamera
	L_2930_arg3.FieldOfView = L_2929_arg2
	return
end

L_13_.fn_244_applyFullbright = function(L_2931_arg0, L_2932_arg1, L_2933_arg2, L_2934_arg3, L_2935_arg4, L_2936_arg5, L_2937_arg6, L_2938_arg7)
	if not L_2933_arg2 then
		L_2934_arg3 = L_10_func(L_2932_arg1, "game")
		L_2934_arg3 = L_2934_arg3.Lighting
		L_2935_arg4 = L_10_func(L_2932_arg1, "Color3")
		L_2935_arg4 = L_2935_arg4.fromRGB
		L_2936_arg5 = 128
		L_2937_arg6 = 128
		L_2938_arg7 = 128
		L_2935_arg4 = L_2935_arg4(L_2936_arg5, L_2937_arg6, L_2938_arg7)
		L_2934_arg3.Ambient = L_2935_arg4
		L_2934_arg3 = L_10_func(L_2932_arg1, "game")
		L_2934_arg3 = L_2934_arg3.Lighting
		L_2935_arg4 = true
		L_2934_arg3.GlobalShadows = L_2935_arg4
		return
	else
		L_2934_arg3 = L_10_func(L_2932_arg1, "game")
		L_2934_arg3 = L_2934_arg3.Lighting
		L_2935_arg4 = L_10_func(L_2932_arg1, "Color3")
		L_2935_arg4 = L_2935_arg4.new
		L_2936_arg5 = 1
		L_2937_arg6 = 1
		L_2938_arg7 = 1
		L_2935_arg4 = L_2935_arg4(L_2936_arg5, L_2937_arg6, L_2938_arg7)
		L_2934_arg3.Ambient = L_2935_arg4
		L_2934_arg3 = L_10_func(L_2932_arg1, "game")
		L_2934_arg3 = L_2934_arg3.Lighting
		L_2935_arg4 = L_10_func(L_2932_arg1, "Color3")
		L_2935_arg4 = L_2935_arg4.new
		L_2936_arg5 = 1
		L_2937_arg6 = 1
		L_2938_arg7 = 1
		L_2935_arg4 = L_2935_arg4(L_2936_arg5, L_2937_arg6, L_2938_arg7)
		L_2934_arg3.ColorShift_Bottom = L_2935_arg4
		L_2934_arg3 = L_10_func(L_2932_arg1, "game")
		L_2934_arg3 = L_2934_arg3.Lighting
		L_2935_arg4 = L_10_func(L_2932_arg1, "Color3")
		L_2935_arg4 = L_2935_arg4.new
		L_2936_arg5 = 1
		L_2937_arg6 = 1
		L_2938_arg7 = 1
		L_2935_arg4 = L_2935_arg4(L_2936_arg5, L_2937_arg6, L_2938_arg7)
		L_2934_arg3.ColorShift_Top = L_2935_arg4
		L_2934_arg3 = L_10_func(L_2932_arg1, "game")
		L_2934_arg3 = L_2934_arg3.Lighting
		L_2935_arg4 = false
		L_2934_arg3.GlobalShadows = L_2935_arg4
		return
	end
end

L_13_.fn_245_applyPlayerHighlights = function(L_2939_arg0, L_2940_arg1, ...)
	local L_2941_ = ...
	local L_2942_ = L_10_func(L_2940_arg1, "game")
	local L_2943_ = L_2942_.Players
	local L_2944_ = L_2939_arg0[1][1]
	local L_2945_ = L_2939_arg0[2][1]
	if L_2941_ then
		for L_2946_forvar0, L_2947_forvar1 in pairs(L_2943_:GetPlayers()) do
			if L_2947_forvar1 ~= L_2943_.LocalPlayer and L_2947_forvar1.Character then
				local L_2948_ = L_10_func(L_2940_arg1, "Instance").new("Highlight")
				L_2948_.Parent = L_2947_forvar1.Character
				L_2948_.FillColor = L_2944_.AccentColor
				L_2948_.OutlineColor = L_2944_.SecondaryColor
				L_2948_.FillTransparency = 0.5
				table.insert(L_2945_, L_2948_)
			end
		end
		return
	end
	for L_2949_forvar0, L_2950_forvar1 in pairs(L_2945_) do
		if L_2950_forvar1 and L_2950_forvar1.Parent then
			L_2950_forvar1:Destroy()
		end
	end
	L_2939_arg0[2][1] = {}
	return
end

L_13_.fn_246_applyHitbox = function(L_2951_arg0, L_2952_arg1, L_2953_arg2, L_2954_arg3, L_2955_arg4, L_2956_arg5, L_2957_arg6, L_2958_arg7)
	L_2955_arg4 = L_2951_arg0[1][1]
	L_2954_arg3 = L_2955_arg4.Character
	L_2953_arg2 = L_2954_arg3.HumanoidRootPart
	L_2954_arg3 = L_10_func(L_2952_arg1, "Vector3")
	L_2954_arg3 = L_2954_arg3.new
	L_2956_arg5 = L_10_func(L_2952_arg1, "_G")
	L_2955_arg4 = L_2956_arg5.HeadSize
	L_2957_arg6 = L_10_func(L_2952_arg1, "_G")
	L_2956_arg5 = L_2957_arg6.HeadSize
	L_2958_arg7 = L_10_func(L_2952_arg1, "_G")
	L_2957_arg6 = L_2958_arg7.HeadSize
	L_2954_arg3 = L_2954_arg3(L_2955_arg4, L_2956_arg5, L_2957_arg6)
	L_2953_arg2.Size = L_2954_arg3
	L_2955_arg4 = L_2951_arg0[1][1]
	L_2954_arg3 = L_2955_arg4.Character
	L_2953_arg2 = L_2954_arg3.HumanoidRootPart
	L_2954_arg3 = 0.7
	L_2953_arg2.Transparency = L_2954_arg3
	L_2955_arg4 = L_2951_arg0[1][1]
	L_2954_arg3 = L_2955_arg4.Character
	L_2953_arg2 = L_2954_arg3.HumanoidRootPart
	L_2954_arg3 = L_10_func(L_2952_arg1, "BrickColor")
	L_2954_arg3 = L_2954_arg3.new
	L_2955_arg4 = "Really blue"
	L_2954_arg3 = L_2954_arg3(L_2955_arg4)
	L_2953_arg2.BrickColor = L_2954_arg3
	L_2955_arg4 = L_2951_arg0[1][1]
	L_2954_arg3 = L_2955_arg4.Character
	L_2953_arg2 = L_2954_arg3.HumanoidRootPart
	L_2954_arg3 = "Neon"
	L_2953_arg2.Material = L_2954_arg3
	L_2955_arg4 = L_2951_arg0[1][1]
	L_2954_arg3 = L_2955_arg4.Character
	L_2953_arg2 = L_2954_arg3.HumanoidRootPart
	L_2954_arg3 = false
	L_2953_arg2.CanCollide = L_2954_arg3
	return
end

L_13_.fn_247_updateHitboxes = function(L_2959_arg0, L_2960_arg1, ...)
	local L_2961_ = L_10_func(L_2960_arg1, "_G")
	if not L_2961_.Disabled then
		return
	end
	local L_2962_ = L_10_func(L_2960_arg1, "game")
	local L_2963_ = L_2962_:GetService("Players")
	local L_2964_ = L_2963_.LocalPlayer
	for L_2965_forvar0, L_2966_forvar1 in next, L_2963_:GetPlayers() do
		if L_2966_forvar1.Name ~= L_2964_.Name then
			local L_2967_ = L_14_func(
                L_13_.fn_246_applyHitbox,
                L_2960_arg1,
                {
				{
					L_2966_forvar1
				}
			}
            )
			L_10_func(L_2960_arg1, "pcall")(L_2967_)
		end
	end
	return
end

L_13_.fn_248_startHitboxLoop = function(L_2968_arg0, L_2969_arg1, L_2970_arg2, L_2971_arg3, L_2972_arg4, L_2973_arg5, L_2974_arg6)
	L_2971_arg3 = L_10_func(L_2969_arg1, "_G")
	L_2971_arg3.HeadSize = L_2970_arg2
	L_2971_arg3 = L_10_func(L_2969_arg1, "_G")
	L_2972_arg4 = true
	L_2971_arg3.Disabled = L_2972_arg4
	L_2972_arg4 = L_10_func(L_2969_arg1, "game")
	L_2974_arg6 = "RunService"
	do
		local L_2975_ = L_2972_arg4;
		L_2973_arg5 = L_2975_;
		L_2972_arg4 = L_2975_.GetService
	end
	L_2972_arg4 = L_2972_arg4(L_2973_arg5, L_2974_arg6)
	L_2971_arg3 = L_2972_arg4.RenderStepped
	L_2973_arg5 = L_14_func(L_13_.fn_247_updateHitboxes, L_2969_arg1, {})
	do
		local L_2976_ = L_2971_arg3;
		L_2972_arg4 = L_2976_;
		L_2971_arg3 = L_2976_.connect
	end
	L_2971_arg3(L_2972_arg4, L_2973_arg5)
	return
end

L_13_.fn_249_giveBuildingTools = function(L_2977_arg0, L_2978_arg1, L_2979_arg2, L_2980_arg3, L_2981_arg4, L_2982_arg5, L_2983_arg6, L_2984_arg7)
	L_2979_arg2 = L_10_func(L_2978_arg1, "Instance")
	L_2979_arg2 = L_2979_arg2.new
	L_2980_arg3 = "HopperBin"
	L_2982_arg5 = L_10_func(L_2978_arg1, "game")
	L_2982_arg5 = L_2982_arg5.Players
	L_2982_arg5 = L_2982_arg5.LocalPlayer
	L_2981_arg4 = L_2982_arg5.Backpack
	L_2979_arg2 = L_2979_arg2(L_2980_arg3, L_2981_arg4)
	L_2980_arg3 = "Clone"
	L_2979_arg2.BinType = L_2980_arg3
	L_2980_arg3 = L_10_func(L_2978_arg1, "Instance")
	L_2980_arg3 = L_2980_arg3.new
	L_2981_arg4 = "HopperBin"
	L_2983_arg6 = L_10_func(L_2978_arg1, "game")
	L_2983_arg6 = L_2983_arg6.Players
	L_2983_arg6 = L_2983_arg6.LocalPlayer
	L_2982_arg5 = L_2983_arg6.Backpack
	L_2980_arg3 = L_2980_arg3(L_2981_arg4, L_2982_arg5)
	L_2981_arg4 = "Hammer"
	L_2980_arg3.BinType = L_2981_arg4
	L_2981_arg4 = L_10_func(L_2978_arg1, "Instance")
	L_2981_arg4 = L_2981_arg4.new
	L_2982_arg5 = "HopperBin"
	L_2984_arg7 = L_10_func(L_2978_arg1, "game")
	L_2984_arg7 = L_2984_arg7.Players
	L_2984_arg7 = L_2984_arg7.LocalPlayer
	L_2983_arg6 = L_2984_arg7.Backpack
	L_2981_arg4 = L_2981_arg4(L_2982_arg5, L_2983_arg6)
	L_2982_arg5 = "Grab"
	L_2981_arg4.BinType = L_2982_arg5
	return
end

L_13_.fn_250_teleportRandomPlayer = function(L_2985_arg0, L_2986_arg1, ...)
	local L_2987_ = L_10_func(L_2986_arg1, "game")
	local L_2988_ = L_2987_.Players:GetPlayers()
	if #L_2988_ <= 1 then
		return
	end

	local L_2989_ = math.random(1, #L_2988_)
	local L_2990_ = L_2987_.Players.LocalPlayer
	local L_2991_
	repeat
		L_2991_ = L_2988_[math.random(1, #L_2988_)]
	until L_2991_.Name ~= L_2990_.Name
	local L_2992_ = L_2991_.Character
	if not L_2992_ then
		return
	end
	local L_2993_ = L_2992_:FindFirstChild("HumanoidRootPart")
	if not L_2993_ then
		return
	end
	local L_2994_ = L_2990_.Character
	if not L_2994_ then
		return
	end
	local L_2995_ = L_2994_:FindFirstChild("HumanoidRootPart")
	if not L_2995_ then
		return
	end
	L_2995_.CFrame = L_2993_.CFrame * L_10_func(L_2986_arg1, "CFrame").new(0, 0, 3)
	return
end

L_13_.fn_251_rejoinServer = function(L_2996_arg0, L_2997_arg1, L_2998_arg2, L_2999_arg3, L_3000_arg4, L_3001_arg5, L_3002_arg6)
	L_2998_arg2 = L_10_func(L_2997_arg1, "game")
	L_3000_arg4 = "TeleportService"
	do
		local L_3003_ = L_2998_arg2;
		L_2999_arg3 = L_3003_;
		L_2998_arg2 = L_3003_.GetService
	end
	L_2998_arg2 = L_2998_arg2(L_2999_arg3, L_3000_arg4)
	L_3000_arg4 = L_10_func(L_2997_arg1, "game")
	L_3000_arg4 = L_3000_arg4.PlaceId
	L_3001_arg5 = L_10_func(L_2997_arg1, "game")
	L_3001_arg5 = L_3001_arg5.JobId
	L_3002_arg6 = L_10_func(L_2997_arg1, "game")
	L_3002_arg6 = L_3002_arg6.Players
	L_3002_arg6 = L_3002_arg6.LocalPlayer
	do
		local L_3004_ = L_2998_arg2;
		L_2999_arg3 = L_3004_;
		L_2998_arg2 = L_3004_.TeleportToPlaceInstance
	end
	L_2998_arg2(L_2999_arg3, L_3000_arg4, L_3001_arg5, L_3002_arg6)
	return
end

L_13_.fn_252_fetchServerPage = function(L_3005_arg0, L_3006_arg1, ...)
	local L_3007_ = ...
	local L_3008_ = L_10_func(L_3006_arg1, "game")
	local L_3009_ = L_3005_arg0[1][1]
	local L_3010_ = L_3005_arg0[2][1]
	local L_3011_ = L_3007_ and ("&cursor=" .. L_3007_) or ""
	local L_3012_ = L_3008_:HttpGet(L_3009_ .. L_3011_)
	return L_3010_:JSONDecode(L_3012_)
end

L_13_.fn_253_serverHop = function(L_3013_arg0, L_3014_arg1, ...)
	local L_3015_ = L_10_func(L_3014_arg1, "game")
	local L_3016_ = L_3015_:GetService("HttpService")
	local L_3017_ = L_3015_:GetService("TeleportService")
	local L_3018_ = L_3015_.PlaceId
	local L_3019_ = "https://games.roblox.com/v1/games/"
        .. tostring(L_3018_)
        .. "/servers/Public?sortOrder=Asc&limit=100"
	local L_3020_
	local L_3021_
	repeat
		local L_3022_ = L_3021_ and ("&cursor=" .. L_3021_) or ""
		local L_3023_ = L_3016_:JSONDecode(L_3015_:HttpGet(L_3019_ .. L_3022_))
		L_3020_ = L_3023_.data[1]
		L_3021_ = L_3023_.nextPageCursor
	until L_3020_
	L_3017_:TeleportToPlaceInstance(L_3018_, L_3020_.id, L_3015_.Players.LocalPlayer)
	return
end

L_13_.fn_254_installAntiAfk = function(L_3024_arg0, L_3025_arg1, ...)
	local L_3026_ = ...
	local L_3027_ = L_10_func(L_3025_arg1, "getconnections")
        or L_10_func(L_3025_arg1, "get_signal_cons")
	if not L_3026_ or not L_3027_ then
		return
	end
	local L_3028_ = L_10_func(L_3025_arg1, "game")
	for L_3029_forvar0, L_3030_forvar1 in pairs(L_3027_(L_3028_.Players.LocalPlayer.Idled)) do
		if L_3030_forvar1.Disable then
			L_3030_forvar1:Disable()
		elseif L_3030_forvar1.Disconnect then
			L_3030_forvar1:Disconnect()
		end
	end
	return
end

L_13_.fn_255_findAimTarget = function(L_3031_arg0, L_3032_arg1, ...)
	local L_3033_ = L_3031_arg0[1][1]
	local L_3034_ = L_10_func(L_3032_arg1, "game")
	local L_3035_ = L_3034_.Players.LocalPlayer
	local L_3036_ = L_3034_:GetService("UserInputService"):GetMouseLocation()
	local L_3037_ = L_3033_.FOVRadius
	local L_3038_ = nil
	for L_3039_forvar0, L_3040_forvar1 in pairs(L_3034_.Players:GetPlayers()) do
		if L_3040_forvar1 ~= L_3035_ then
			local L_3041_ = L_3040_forvar1.Character
			if L_3041_ then
				local L_3042_ = L_3041_:FindFirstChild(L_3033_.TargetPart)
				local L_3043_ = L_3041_:FindFirstChild("Humanoid")
				if L_3042_ and L_3043_ and L_3043_.Health > 0 then

					if L_3033_.TeamCheck then
						local L_3046_ = L_3040_forvar1.Team == L_3035_.Team
					end
					local L_3044_, L_3045_ = L_3034_.Workspace.CurrentCamera:WorldToViewportPoint(L_3042_.Position)
					if L_3045_ then
						local L_3047_ = L_10_func(L_3032_arg1, "Vector2").new(L_3044_.X, L_3044_.Y)
						local L_3048_ = (L_3047_ - L_3036_).Magnitude
						if L_3048_ < L_3037_ then
							L_3037_ = L_3048_
							L_3038_ = L_3040_forvar1
						end
					end
				end
			end
		end
	end
	return L_3038_
end

L_13_.fn_256_updateFovCircle = function(L_3049_arg0, L_3050_arg1, L_3051_arg2, L_3052_arg3, L_3053_arg4, L_3054_arg5, L_3055_arg6, L_3056_arg7, L_3057_arg8, L_3058_arg9, L_3059_arg10)
	L_3052_arg3 = L_3049_arg0[1][1]
	L_3051_arg2 = L_3052_arg3.ShowFOV
	if not L_3051_arg2 then
		L_3051_arg2 = L_3049_arg0[2][1]
		L_3052_arg3 = false
		L_3051_arg2.Visible = L_3052_arg3
	else
		L_3051_arg2 = L_3049_arg0[2][1]
		L_3052_arg3 = L_10_func(L_3050_arg1, "game")
		L_3054_arg5 = "UserInputService"
		do
			local L_3060_ = L_3052_arg3;
			L_3053_arg4 = L_3060_;
			L_3052_arg3 = L_3060_.GetService
		end
		L_3052_arg3 = L_3052_arg3(L_3053_arg4, L_3054_arg5)
		do
			local L_3061_ = L_3052_arg3;
			L_3053_arg4 = L_3061_;
			L_3052_arg3 = L_3061_.GetMouseLocation
		end
		L_3052_arg3 = L_3052_arg3(L_3053_arg4)
		L_3051_arg2.Position = L_3052_arg3
		L_3051_arg2 = L_3049_arg0[2][1]
		L_3053_arg4 = L_3049_arg0[1][1]
		L_3052_arg3 = L_3053_arg4.FOVRadius
		L_3051_arg2.Radius = L_3052_arg3
		L_3051_arg2 = L_3049_arg0[2][1]
		L_3052_arg3 = true
		L_3051_arg2.Visible = L_3052_arg3
	end
	L_3052_arg3 = L_3049_arg0[1][1]
	L_3051_arg2 = L_3052_arg3.Enabled
	if L_3051_arg2 then
		L_3051_arg2 = L_10_func(L_3050_arg1, "game")
		L_3053_arg4 = "UserInputService"
		do
			local L_3062_ = L_3051_arg2;
			L_3052_arg3 = L_3062_;
			L_3051_arg2 = L_3062_.GetService
		end
		L_3051_arg2 = L_3051_arg2(L_3052_arg3, L_3053_arg4)
		L_3053_arg4 = L_10_func(L_3050_arg1, "Enum")
		L_3053_arg4 = L_3053_arg4.UserInputType
		L_3053_arg4 = L_3053_arg4.MouseButton2
		do
			local L_3063_ = L_3051_arg2;
			L_3052_arg3 = L_3063_;
			L_3051_arg2 = L_3063_.IsMouseButtonPressed
		end
		L_3051_arg2 = L_3051_arg2(L_3052_arg3, L_3053_arg4)
		if L_3051_arg2 then
			L_3051_arg2 = L_3049_arg0[3][1]
			L_3051_arg2 = L_3051_arg2()
			if L_3051_arg2 then
				L_3052_arg3 = L_3051_arg2.Character
				if L_3052_arg3 then
					L_3052_arg3 = L_3051_arg2.Character
					L_3055_arg6 = L_3049_arg0[1][1]
					L_3054_arg5 = L_3055_arg6.TargetPart
					do
						local L_3064_ = L_3052_arg3;
						L_3053_arg4 = L_3064_;
						L_3052_arg3 = L_3064_.FindFirstChild
					end
					L_3052_arg3 = L_3052_arg3(L_3053_arg4, L_3054_arg5)
					if L_3052_arg3 then
						L_3052_arg3 = L_10_func(L_3050_arg1, "game")
						L_3052_arg3 = L_3052_arg3.Workspace
						L_3052_arg3 = L_3052_arg3.CurrentCamera
						L_3053_arg4 = L_10_func(L_3050_arg1, "CFrame")
						L_3053_arg4 = L_3053_arg4.new
						L_3055_arg6 = L_3052_arg3.CFrame
						L_3054_arg5 = L_3055_arg6.Position
						L_3057_arg8 = L_3051_arg2.Character
						L_3059_arg10 = L_3049_arg0[1][1]
						L_3058_arg9 = L_3059_arg10.TargetPart
						L_3056_arg7 = L_3057_arg8[L_3058_arg9]
						L_3055_arg6 = L_3056_arg7.Position
						L_3053_arg4 = L_3053_arg4(L_3054_arg5, L_3055_arg6)
						L_3054_arg5 = L_3052_arg3.CFrame
						L_3056_arg7 = L_3053_arg4
						L_3058_arg9 = L_3049_arg0[1][1]
						L_3057_arg8 = L_3058_arg9.Smoothness
						do
							local L_3065_ = L_3054_arg5;
							L_3055_arg6 = L_3065_;
							L_3054_arg5 = L_3065_.Lerp
						end
						L_3054_arg5 = L_3054_arg5(L_3055_arg6, L_3056_arg7, L_3057_arg8)
						L_3052_arg3.CFrame = L_3054_arg5
					end
				end
			end
		end
	end
	return
end

L_13_.fn_257_setAimEnabled = function(L_3066_arg0, L_3067_arg1, L_3068_arg2, L_3069_arg3)
	L_3069_arg3 = L_3066_arg0[1][1]
	L_3069_arg3.Enabled = L_3068_arg2
	return
end

L_13_.fn_258_setShowFov = function(L_3070_arg0, L_3071_arg1, L_3072_arg2, L_3073_arg3)
	L_3073_arg3 = L_3070_arg0[1][1]
	L_3073_arg3.ShowFOV = L_3072_arg2
	return
end

L_13_.fn_259_setFovRadius = function(L_3074_arg0, L_3075_arg1, L_3076_arg2, L_3077_arg3)
	L_3077_arg3 = L_3074_arg0[1][1]
	L_3077_arg3.FOVRadius = L_3076_arg2
	return
end

L_13_.fn_260_setAimSmoothness = function(L_3078_arg0, L_3079_arg1, L_3080_arg2, L_3081_arg3, L_3082_arg4)
	L_3081_arg3 = L_3078_arg0[1][1]
	L_3082_arg4 = L_3080_arg2 / 100
	L_3081_arg3.Smoothness = L_3082_arg4
	return
end

L_13_.fn_261_setTeamCheck = function(L_3083_arg0, L_3084_arg1, L_3085_arg2, L_3086_arg3)
	L_3086_arg3 = L_3083_arg0[1][1]
	L_3086_arg3.TeamCheck = L_3085_arg2
	return
end

L_13_.fn_262_testNotification = function(L_3087_arg0, L_3088_arg1, L_3089_arg2, L_3090_arg3, L_3091_arg4, L_3092_arg5, L_3093_arg6, L_3094_arg7)
	L_3089_arg2 = L_3087_arg0[1][1]
	L_3091_arg4 = "Test"
	L_3092_arg5 = "Notifications are working!"
	L_3093_arg6 = 4
	L_3094_arg7 = false
	do
		local L_3095_ = L_3089_arg2;
		L_3090_arg3 = L_3095_;
		L_3089_arg2 = L_3095_.Notify
	end
	L_3089_arg2(L_3090_arg3, L_3091_arg4, L_3092_arg5, L_3093_arg6, L_3094_arg7)
	return
end

L_13_.fn_263_testPremiumNotification = function(L_3096_arg0, L_3097_arg1, L_3098_arg2, L_3099_arg3, L_3100_arg4, L_3101_arg5, L_3102_arg6, L_3103_arg7)
	L_3098_arg2 = L_3096_arg0[1][1]
	L_3100_arg4 = "Premium Alert"
	L_3101_arg5 = "This is how premium alerts look!"
	L_3102_arg6 = 4
	L_3103_arg7 = true
	do
		local L_3104_ = L_3098_arg2;
		L_3099_arg3 = L_3104_;
		L_3098_arg2 = L_3104_.Notify
	end
	L_3098_arg2(L_3099_arg3, L_3100_arg4, L_3101_arg5, L_3102_arg6, L_3103_arg7)
	return
end

L_13_.fn_264_cleanupOldHubGuis = function(L_3105_arg0, L_3106_arg1, ...)
	local L_3107_ = L_3105_arg0[1][1]
	local L_3108_ = L_10_func(L_3106_arg1, "getgenv")
	local L_3109_ = L_10_func(L_3106_arg1, "typeof")
	for L_3110_forvar0, L_3111_forvar1 in pairs(L_3108_()) do
		if type(L_3110_forvar0) == "string"
            and L_3110_forvar0:sub(1, 3) == "_h_"
            and L_3109_(L_3111_forvar1) == "Instance"
            and L_3111_forvar1:IsA("ScreenGui") then
			local L_3112_ = L_3111_forvar1:FindFirstChild("Main")
			if L_3112_ then
				L_3112_.BackgroundTransparency = L_3107_
			end
		end
	end
	return
end

L_13_.fn_265 = function(L_3113_arg0, L_3114_arg1, L_3115_arg2, L_3116_arg3, L_3117_arg4)
	L_3116_arg3 = L_3115_arg2 / 10
	L_3113_arg0[1][1] = L_3116_arg3
	L_3116_arg3 = L_10_func(L_3114_arg1, "pcall")
	L_3117_arg4 = L_14_func(L_13_.fn_264_cleanupOldHubGuis, L_3114_arg1, {
		L_3113_arg0[1]
	})
	L_3116_arg3(L_3117_arg4)
	return
end

L_13_.fn_266_copyDiscord = function(L_3118_arg0, L_3119_arg1, L_3120_arg2, L_3121_arg3, L_3122_arg4, L_3123_arg5, L_3124_arg6, L_3125_arg7)
	L_3120_arg2 = L_10_func(L_3119_arg1, "setclipboard")
	if L_3120_arg2 then
		L_3120_arg2 = L_10_func(L_3119_arg1, "setclipboard")
		L_3121_arg3 = "https://discord.gg/getsnowy"
		L_3120_arg2(L_3121_arg3)
	end
	L_3120_arg2 = L_3118_arg0[1][1]
	L_3122_arg4 = "Copied!"
	L_3123_arg5 = "Discord link copied."
	L_3124_arg6 = 3
	L_3125_arg7 = false
	do
		local L_3126_ = L_3120_arg2;
		L_3121_arg3 = L_3126_;
		L_3120_arg2 = L_3126_.Notify
	end
	L_3120_arg2(L_3121_arg3, L_3122_arg4, L_3123_arg5, L_3124_arg6, L_3125_arg7)
	return
end

L_13_.fn_267_destroyHubUi = function(L_3127_arg0, L_3128_arg1, L_3129_arg2, L_3130_arg3)
	L_3129_arg2 = L_3127_arg0[1][1]
	do
		local L_3131_ = L_3129_arg2;
		L_3130_arg3 = L_3131_;
		L_3129_arg2 = L_3131_.Destroy
	end
	L_3129_arg2(L_3130_arg3)
	return
end

L_13_.fn_268_cleanupReloadGuis = function(L_3132_arg0, L_3133_arg1, ...)
	local L_3134_ = L_10_func(L_3133_arg1, "getgenv")
	local L_3135_ = L_3134_()
	local L_3136_ = L_10_func(L_3133_arg1, "typeof")
	for L_3137_forvar0, L_3138_forvar1 in pairs(L_3135_) do
		if type(L_3137_forvar0) == "string"
            and L_3137_forvar0:sub(1, 3) == "_h_"
            and L_3136_(L_3138_forvar1) == "Instance"
            and L_3138_forvar1:IsA("ScreenGui") then
			L_10_func(L_3133_arg1, "pcall")(function()
				L_3138_forvar1:Destroy()
			end)
			L_3135_[L_3137_forvar0] = nil
		end
	end
	return
end

L_13_.fn_269_reloadHubUi = function(L_3139_arg0, L_3140_arg1, L_3141_arg2, L_3142_arg3, L_3143_arg4, L_3144_arg5, L_3145_arg6, L_3146_arg7)
	L_3141_arg2 = L_10_func(L_3140_arg1, "pcall")
	L_3142_arg3 = L_14_func(L_13_.fn_268_cleanupReloadGuis, L_3140_arg1, {})
	L_3141_arg2(L_3142_arg3)
	L_3141_arg2 = L_10_func(L_3140_arg1, "task")
	L_3141_arg2 = L_3141_arg2.wait
	L_3142_arg3 = 0.1
	L_3141_arg2(L_3142_arg3)
	L_3141_arg2 = L_10_func(L_3140_arg1, "getgenv")
	L_3141_arg2 = L_3141_arg2()
	L_3143_arg4 = L_3139_arg0[1][1]
	L_3142_arg3 = L_3143_arg4.CreateLib
	L_3144_arg5 = L_3139_arg0[2][1]
	L_3143_arg4 = L_3144_arg5.HubName
	L_3144_arg5 = "Midnight"
	L_3142_arg3 = L_3142_arg3(L_3143_arg4, L_3144_arg5)
	L_3141_arg2.Window = L_3142_arg3
	L_3141_arg2 = L_3139_arg0[3][1]
	L_3143_arg4 = "Reloaded"
	L_3144_arg5 = "Hub UI restarted."
	L_3145_arg6 = 3
	L_3146_arg7 = false
	do
		local L_3147_ = L_3141_arg2;
		L_3142_arg3 = L_3147_;
		L_3141_arg2 = L_3147_.Notify
	end
	L_3141_arg2(L_3142_arg3, L_3143_arg4, L_3144_arg5, L_3145_arg6, L_3146_arg7)
	return
end

L_13_.fn_270_NewToggle = function(L_3148_arg0, L_3149_arg1, L_3150_arg2)
	return
end

L_13_.fn_271_NewSection = function(L_3151_arg0, L_3152_arg1, L_3153_arg2)
	L_3153_arg2 = L_3151_arg0[1][1]
	return L_3153_arg2
end

L_13_.fn_272_NewSection = function(L_3154_arg0, L_3155_arg1, L_3156_arg2)
	L_3156_arg2 = L_3154_arg0[1][1]
	return L_3156_arg2
end

L_13_.fn_273 = function(L_3157_arg0, L_3158_arg1, L_3159_arg2, L_3160_arg3, L_3161_arg4, L_3162_arg5)
	L_3159_arg2 = L_14_func(L_13_.fn_270_NewToggle, L_3158_arg1, {})
	L_3160_arg3 = {}
	L_3160_arg3.NewToggle = L_3159_arg2
	L_3160_arg3.NewButton = L_3159_arg2
	L_3160_arg3.NewSlider = L_3159_arg2
	L_3160_arg3.NewDropdown = L_3159_arg2
	L_3160_arg3.NewLabel = L_3159_arg2
	L_3160_arg3.NewPremiumToggle = L_3159_arg2
	L_3160_arg3.NewPremiumButton = L_3159_arg2
	L_3160_arg3.NewPremiumSlider = L_3159_arg2
	L_3160_arg3.NewPremiumDropdown = L_3159_arg2
	L_3161_arg4 = L_14_func(L_13_.fn_271_NewSection, L_3158_arg1, {
		{
			L_3160_arg3
		}
	})
	L_3160_arg3.NewSection = L_3161_arg4
	L_3161_arg4 = {}
	L_3162_arg5 = L_14_func(L_13_.fn_272_NewSection, L_3158_arg1, {
		{
			L_3160_arg3
		}
	})
	L_3161_arg4.NewSection = L_3162_arg5
	L_3161_arg4.HideTabButton = L_3159_arg2
	L_3161_arg4.Select = L_3159_arg2
	L_3162_arg5 = {}
	L_3162_arg5.SetVisible = L_3159_arg2
	L_3161_arg4.ActualTab = L_3162_arg5
	return L_3161_arg4
end

L_13_.fn_274_resolveMainEvent = function(L_3163_arg0, L_3164_arg1, L_3165_arg2, L_3166_arg3, L_3167_arg4, L_3168_arg5)
	L_3165_arg2 = L_10_func(L_3164_arg1, "game")
	L_3167_arg4 = "ReplicatedStorage"
	do
		local L_3169_ = L_3165_arg2;
		L_3166_arg3 = L_3169_;
		L_3165_arg2 = L_3169_.GetService
	end
	L_3165_arg2 = L_3165_arg2(L_3166_arg3, L_3167_arg4)
	L_3168_arg5 = "MainEvent"
	do
		local L_3170_ = L_3165_arg2;
		L_3167_arg4 = L_3170_;
		L_3166_arg3 = L_3170_.FindFirstChild
	end
	L_3166_arg3 = L_3166_arg3(L_3167_arg4, L_3168_arg5)
	if not L_3166_arg3 then
		L_3168_arg5 = "Remotes"
		do
			local L_3171_ = L_3165_arg2;
			L_3167_arg4 = L_3171_;
			L_3166_arg3 = L_3171_.FindFirstChild
		end
		L_3166_arg3 = L_3166_arg3(L_3167_arg4, L_3168_arg5)
		if L_3166_arg3 then
			L_3166_arg3 = L_3165_arg2.Remotes
			L_3168_arg5 = "MainEvent"
			do
				local L_3172_ = L_3166_arg3;
				L_3167_arg4 = L_3172_;
				L_3166_arg3 = L_3172_.FindFirstChild
			end
			L_3166_arg3 = L_3166_arg3(L_3167_arg4, L_3168_arg5)
		end
	end
	L_3163_arg0[1][1] = L_3166_arg3
	return
end

L_13_.fn_275_stopFly = function(L_3173_arg0, L_3174_arg1, L_3175_arg2, L_3176_arg3, L_3177_arg4)
	L_3175_arg2 = L_3173_arg0[1][1]
	if L_3175_arg2 then
		L_3175_arg2 = L_3173_arg0[1][1]
		do
			local L_3178_ = L_3175_arg2;
			L_3176_arg3 = L_3178_;
			L_3175_arg2 = L_3178_.Destroy
		end
		L_3175_arg2(L_3176_arg3)
		L_3175_arg2 = nil
		L_3173_arg0[1][1] = L_3175_arg2
	end
	L_3175_arg2 = L_3173_arg0[2][1]
	if L_3175_arg2 then
		L_3175_arg2 = L_3173_arg0[2][1]
		do
			local L_3179_ = L_3175_arg2;
			L_3176_arg3 = L_3179_;
			L_3175_arg2 = L_3179_.Destroy
		end
		L_3175_arg2(L_3176_arg3)
		L_3175_arg2 = nil
		L_3173_arg0[2][1] = L_3175_arg2
	end
	L_3176_arg3 = L_3173_arg0[3][1]
	L_3175_arg2 = L_3176_arg3.Character
	if L_3175_arg2 then
		L_3176_arg3 = L_3173_arg0[3][1]
		L_3175_arg2 = L_3176_arg3.Character
		L_3177_arg4 = "Humanoid"
		do
			local L_3180_ = L_3175_arg2;
			L_3176_arg3 = L_3180_;
			L_3175_arg2 = L_3180_.FindFirstChildOfClass
		end
		L_3175_arg2 = L_3175_arg2(L_3176_arg3, L_3177_arg4)
		if L_3175_arg2 then
			L_3176_arg3 = L_3173_arg0[3][1]
			L_3175_arg2 = L_3176_arg3.Character
			L_3177_arg4 = "Humanoid"
			do
				local L_3181_ = L_3175_arg2;
				L_3176_arg3 = L_3181_;
				L_3175_arg2 = L_3181_.FindFirstChildOfClass
			end
			L_3175_arg2 = L_3175_arg2(L_3176_arg3, L_3177_arg4)
			L_3176_arg3 = false
			L_3175_arg2.PlatformStand = L_3176_arg3
		end
	end
	return
end

L_13_.fn_276_startFly = function(L_3182_arg0, L_3183_arg1, L_3184_arg2, L_3185_arg3, L_3186_arg4, L_3187_arg5, L_3188_arg6, L_3189_arg7, L_3190_arg8, L_3191_arg9)
	L_3184_arg2 = L_3182_arg0[1][1]
	L_3184_arg2()
	L_3185_arg3 = L_3182_arg0[2][1]
	L_3184_arg2 = L_3185_arg3.Character
	L_3185_arg3 = L_3184_arg2
	if L_3185_arg3 then
		L_3187_arg5 = "HumanoidRootPart"
		do
			local L_3192_ = L_3184_arg2;
			L_3186_arg4 = L_3192_;
			L_3185_arg3 = L_3192_.FindFirstChild
		end
		L_3185_arg3 = L_3185_arg3(L_3186_arg4, L_3187_arg5)
	end
	L_3186_arg4 = L_3184_arg2
	if L_3186_arg4 then
		L_3188_arg6 = "Humanoid"
		do
			local L_3193_ = L_3184_arg2;
			L_3187_arg5 = L_3193_;
			L_3186_arg4 = L_3193_.FindFirstChildOfClass
		end
		L_3186_arg4 = L_3186_arg4(L_3187_arg5, L_3188_arg6)
	end
	if L_3185_arg3 then
		if L_3186_arg4 then
			L_3187_arg5 = true
			L_3186_arg4.PlatformStand = L_3187_arg5
			L_3187_arg5 = L_10_func(L_3183_arg1, "Instance")
			L_3187_arg5 = L_3187_arg5.new
			L_3188_arg6 = "BodyVelocity"
			L_3187_arg5 = L_3187_arg5(L_3188_arg6)
			L_3182_arg0[3][1] = L_3187_arg5
			L_3187_arg5 = L_3182_arg0[3][1]
			L_3188_arg6 = L_10_func(L_3183_arg1, "Vector3")
			L_3188_arg6 = L_3188_arg6.new
			L_3189_arg7 = 9000000000
			L_3190_arg8 = 9000000000
			L_3191_arg9 = 9000000000
			L_3188_arg6 = L_3188_arg6(L_3189_arg7, L_3190_arg8, L_3191_arg9)
			L_3187_arg5.MaxForce = L_3188_arg6
			L_3187_arg5 = L_3182_arg0[3][1]
			L_3188_arg6 = L_10_func(L_3183_arg1, "Vector3")
			L_3188_arg6 = L_3188_arg6.zero
			L_3187_arg5.Velocity = L_3188_arg6
			L_3187_arg5 = L_3182_arg0[3][1]
			L_3187_arg5.Parent = L_3185_arg3
			L_3187_arg5 = L_10_func(L_3183_arg1, "Instance")
			L_3187_arg5 = L_3187_arg5.new
			L_3188_arg6 = "BodyGyro"
			L_3187_arg5 = L_3187_arg5(L_3188_arg6)
			L_3182_arg0[4][1] = L_3187_arg5
			L_3187_arg5 = L_3182_arg0[4][1]
			L_3188_arg6 = L_10_func(L_3183_arg1, "Vector3")
			L_3188_arg6 = L_3188_arg6.new
			L_3189_arg7 = 9000000000
			L_3190_arg8 = 9000000000
			L_3191_arg9 = 9000000000
			L_3188_arg6 = L_3188_arg6(L_3189_arg7, L_3190_arg8, L_3191_arg9)
			L_3187_arg5.MaxTorque = L_3188_arg6
			L_3187_arg5 = L_3182_arg0[4][1]
			L_3188_arg6 = L_3185_arg3.CFrame
			L_3187_arg5.CFrame = L_3188_arg6
			L_3187_arg5 = L_3182_arg0[4][1]
			L_3187_arg5.Parent = L_3185_arg3
			return
		else
			return
		end
	end
	return
end

L_13_.fn_277_applyDaHoodMovement = function(L_3194_arg0, L_3195_arg1, L_3196_arg2, L_3197_arg3, L_3198_arg4, L_3199_arg5, L_3200_arg6, L_3201_arg7, L_3202_arg8, L_3203_arg9, L_3204_arg10, L_3205_arg11, L_3206_arg12)
	L_3196_arg2 = L_3194_arg0[1][1]
	if L_3196_arg2 then
		L_3197_arg3 = L_3194_arg0[1][1]
		L_3196_arg2 = L_3197_arg3.name
		L_3205_arg11 = "Da Hood"
		L_3206_arg12 = (L_3196_arg2 == L_3205_arg11)
		if L_3206_arg12 then
			L_3197_arg3 = L_3194_arg0[2][1]
			L_3196_arg2 = L_3197_arg3.Character
			L_3197_arg3 = L_3196_arg2
			if L_3197_arg3 then
				L_3199_arg5 = "Humanoid"
				do
					local L_3207_ = L_3196_arg2;
					L_3198_arg4 = L_3207_;
					L_3197_arg3 = L_3207_.FindFirstChildOfClass
				end
				L_3197_arg3 = L_3197_arg3(L_3198_arg4, L_3199_arg5)
			end
			L_3198_arg4 = L_3196_arg2
			if L_3198_arg4 then
				L_3200_arg6 = "HumanoidRootPart"
				do
					local L_3208_ = L_3196_arg2;
					L_3199_arg5 = L_3208_;
					L_3198_arg4 = L_3208_.FindFirstChild
				end
				L_3198_arg4 = L_3198_arg4(L_3199_arg5, L_3200_arg6)
			end
			if L_3196_arg2 then
				if L_3197_arg3 then
					if L_3198_arg4 then
						L_3200_arg6 = L_3194_arg0[3][1]
						L_3199_arg5 = L_3200_arg6.WS
						L_3205_arg11 = 16
						L_3206_arg12 = (L_3199_arg5 == L_3205_arg11)
						if not L_3206_arg12 then
							L_3200_arg6 = L_3194_arg0[3][1]
							L_3199_arg5 = L_3200_arg6.WS
							L_3197_arg3.WalkSpeed = L_3199_arg5
						end
						L_3200_arg6 = L_3194_arg0[3][1]
						L_3199_arg5 = L_3200_arg6.JP
						L_3205_arg11 = 50
						L_3206_arg12 = (L_3199_arg5 == L_3205_arg11)
						if not L_3206_arg12 then
							L_3200_arg6 = L_3194_arg0[3][1]
							L_3199_arg5 = L_3200_arg6.JP
							L_3197_arg3.JumpPower = L_3199_arg5
							L_3199_arg5 = true
							L_3197_arg3.UseJumpPower = L_3199_arg5
						end
						L_3200_arg6 = L_3194_arg0[3][1]
						L_3199_arg5 = L_3200_arg6.Fly
						if not L_3199_arg5 then
							L_3199_arg5 = L_3194_arg0[9][1]
							L_3199_arg5()
							return
						else
							L_3199_arg5 = L_3194_arg0[4][1]
							if L_3199_arg5 then
								L_3200_arg6 = L_3194_arg0[4][1]
								L_3199_arg5 = L_3200_arg6.Parent
								L_3206_arg12 = (L_3199_arg5 == L_3198_arg4)
								if not L_3206_arg12 then
									L_3199_arg5 = L_3194_arg0[5][1]
									L_3199_arg5()
								end
								L_3199_arg5 = L_3194_arg0[6][1]
								L_3201_arg7 = L_3194_arg0[7][1]
								L_3200_arg6 = L_3201_arg7.CFrame
								L_3199_arg5.CFrame = L_3200_arg6
								L_3199_arg5 = L_10_func(L_3195_arg1, "Vector3")
								L_3199_arg5 = L_3199_arg5.zero
								L_3200_arg6 = L_3194_arg0[8][1]
								L_3202_arg8 = L_10_func(L_3195_arg1, "Enum")
								L_3202_arg8 = L_3202_arg8.KeyCode
								L_3202_arg8 = L_3202_arg8.W
								do
									local L_3209_ = L_3200_arg6;
									L_3201_arg7 = L_3209_;
									L_3200_arg6 = L_3209_.IsKeyDown
								end
								L_3200_arg6 = L_3200_arg6(L_3201_arg7, L_3202_arg8)
								if L_3200_arg6 then
									L_3202_arg8 = L_3194_arg0[7][1]
									L_3201_arg7 = L_3202_arg8.CFrame
									L_3200_arg6 = L_3201_arg7.LookVector
									L_3199_arg5 = L_3199_arg5 + L_3200_arg6
								end
								L_3200_arg6 = L_3194_arg0[8][1]
								L_3202_arg8 = L_10_func(L_3195_arg1, "Enum")
								L_3202_arg8 = L_3202_arg8.KeyCode
								L_3202_arg8 = L_3202_arg8.S
								do
									local L_3210_ = L_3200_arg6;
									L_3201_arg7 = L_3210_;
									L_3200_arg6 = L_3210_.IsKeyDown
								end
								L_3200_arg6 = L_3200_arg6(L_3201_arg7, L_3202_arg8)
								if L_3200_arg6 then
									L_3202_arg8 = L_3194_arg0[7][1]
									L_3201_arg7 = L_3202_arg8.CFrame
									L_3200_arg6 = L_3201_arg7.LookVector
									L_3199_arg5 = L_3199_arg5 - L_3200_arg6
								end
								L_3200_arg6 = L_3194_arg0[8][1]
								L_3202_arg8 = L_10_func(L_3195_arg1, "Enum")
								L_3202_arg8 = L_3202_arg8.KeyCode
								L_3202_arg8 = L_3202_arg8.A
								do
									local L_3211_ = L_3200_arg6;
									L_3201_arg7 = L_3211_;
									L_3200_arg6 = L_3211_.IsKeyDown
								end
								L_3200_arg6 = L_3200_arg6(L_3201_arg7, L_3202_arg8)
								if L_3200_arg6 then
									L_3202_arg8 = L_3194_arg0[7][1]
									L_3201_arg7 = L_3202_arg8.CFrame
									L_3200_arg6 = L_3201_arg7.RightVector
									L_3199_arg5 = L_3199_arg5 - L_3200_arg6
								end
								L_3200_arg6 = L_3194_arg0[8][1]
								L_3202_arg8 = L_10_func(L_3195_arg1, "Enum")
								L_3202_arg8 = L_3202_arg8.KeyCode
								L_3202_arg8 = L_3202_arg8.D
								do
									local L_3212_ = L_3200_arg6;
									L_3201_arg7 = L_3212_;
									L_3200_arg6 = L_3212_.IsKeyDown
								end
								L_3200_arg6 = L_3200_arg6(L_3201_arg7, L_3202_arg8)
								if L_3200_arg6 then
									L_3202_arg8 = L_3194_arg0[7][1]
									L_3201_arg7 = L_3202_arg8.CFrame
									L_3200_arg6 = L_3201_arg7.RightVector
									L_3199_arg5 = L_3199_arg5 + L_3200_arg6
								end
								L_3200_arg6 = L_3194_arg0[8][1]
								L_3202_arg8 = L_10_func(L_3195_arg1, "Enum")
								L_3202_arg8 = L_3202_arg8.KeyCode
								L_3202_arg8 = L_3202_arg8.Space
								do
									local L_3213_ = L_3200_arg6;
									L_3201_arg7 = L_3213_;
									L_3200_arg6 = L_3213_.IsKeyDown
								end
								L_3200_arg6 = L_3200_arg6(L_3201_arg7, L_3202_arg8)
								if L_3200_arg6 then
									L_3200_arg6 = L_10_func(L_3195_arg1, "Vector3")
									L_3200_arg6 = L_3200_arg6.new
									L_3201_arg7 = 0
									L_3202_arg8 = 1
									L_3203_arg9 = 0
									L_3200_arg6 = L_3200_arg6(L_3201_arg7, L_3202_arg8, L_3203_arg9)
									L_3199_arg5 = L_3199_arg5 + L_3200_arg6
								end
								L_3200_arg6 = L_3194_arg0[8][1]
								L_3202_arg8 = L_10_func(L_3195_arg1, "Enum")
								L_3202_arg8 = L_3202_arg8.KeyCode
								L_3202_arg8 = L_3202_arg8.LeftShift
								do
									local L_3214_ = L_3200_arg6;
									L_3201_arg7 = L_3214_;
									L_3200_arg6 = L_3214_.IsKeyDown
								end
								L_3200_arg6 = L_3200_arg6(L_3201_arg7, L_3202_arg8)
								if L_3200_arg6 then
									L_3200_arg6 = L_10_func(L_3195_arg1, "Vector3")
									L_3200_arg6 = L_3200_arg6.new
									L_3201_arg7 = 0
									L_3202_arg8 = 1
									L_3203_arg9 = 0
									L_3200_arg6 = L_3200_arg6(L_3201_arg7, L_3202_arg8, L_3203_arg9)
									L_3199_arg5 = L_3199_arg5 - L_3200_arg6
								end
								L_3200_arg6 = L_3194_arg0[4][1]
								L_3202_arg8 = L_3199_arg5.Unit
								L_3204_arg10 = L_3194_arg0[3][1]
								L_3203_arg9 = L_3204_arg10.FlySpeed
								L_3201_arg7 = L_3202_arg8 * L_3203_arg9
								L_3200_arg6.Velocity = L_3201_arg7
								return
							end
							L_3199_arg5 = L_3194_arg0[5][1]
							L_3199_arg5()
							L_3199_arg5 = L_3194_arg0[6][1]
							L_3201_arg7 = L_3194_arg0[7][1]
							L_3200_arg6 = L_3201_arg7.CFrame
							L_3199_arg5.CFrame = L_3200_arg6
							L_3199_arg5 = L_10_func(L_3195_arg1, "Vector3")
							L_3199_arg5 = L_3199_arg5.zero
							L_3200_arg6 = L_3194_arg0[8][1]
							L_3202_arg8 = L_10_func(L_3195_arg1, "Enum")
							L_3202_arg8 = L_3202_arg8.KeyCode
							L_3202_arg8 = L_3202_arg8.W
							do
								local L_3215_ = L_3200_arg6;
								L_3201_arg7 = L_3215_;
								L_3200_arg6 = L_3215_.IsKeyDown
							end
							L_3200_arg6 = L_3200_arg6(L_3201_arg7, L_3202_arg8)
							if L_3200_arg6 then
								L_3202_arg8 = L_3194_arg0[7][1]
								L_3201_arg7 = L_3202_arg8.CFrame
								L_3200_arg6 = L_3201_arg7.LookVector
								L_3199_arg5 = L_3199_arg5 + L_3200_arg6
							end
							L_3200_arg6 = L_3194_arg0[8][1]
							L_3202_arg8 = L_10_func(L_3195_arg1, "Enum")
							L_3202_arg8 = L_3202_arg8.KeyCode
							L_3202_arg8 = L_3202_arg8.S
							do
								local L_3216_ = L_3200_arg6;
								L_3201_arg7 = L_3216_;
								L_3200_arg6 = L_3216_.IsKeyDown
							end
							L_3200_arg6 = L_3200_arg6(L_3201_arg7, L_3202_arg8)
							if L_3200_arg6 then
								L_3202_arg8 = L_3194_arg0[7][1]
								L_3201_arg7 = L_3202_arg8.CFrame
								L_3200_arg6 = L_3201_arg7.LookVector
								L_3199_arg5 = L_3199_arg5 - L_3200_arg6
							end
							L_3200_arg6 = L_3194_arg0[8][1]
							L_3202_arg8 = L_10_func(L_3195_arg1, "Enum")
							L_3202_arg8 = L_3202_arg8.KeyCode
							L_3202_arg8 = L_3202_arg8.A
							do
								local L_3217_ = L_3200_arg6;
								L_3201_arg7 = L_3217_;
								L_3200_arg6 = L_3217_.IsKeyDown
							end
							L_3200_arg6 = L_3200_arg6(L_3201_arg7, L_3202_arg8)
							if L_3200_arg6 then
								L_3202_arg8 = L_3194_arg0[7][1]
								L_3201_arg7 = L_3202_arg8.CFrame
								L_3200_arg6 = L_3201_arg7.RightVector
								L_3199_arg5 = L_3199_arg5 - L_3200_arg6
							end
							L_3200_arg6 = L_3194_arg0[8][1]
							L_3202_arg8 = L_10_func(L_3195_arg1, "Enum")
							L_3202_arg8 = L_3202_arg8.KeyCode
							L_3202_arg8 = L_3202_arg8.D
							do
								local L_3218_ = L_3200_arg6;
								L_3201_arg7 = L_3218_;
								L_3200_arg6 = L_3218_.IsKeyDown
							end
							L_3200_arg6 = L_3200_arg6(L_3201_arg7, L_3202_arg8)
							if L_3200_arg6 then
								L_3202_arg8 = L_3194_arg0[7][1]
								L_3201_arg7 = L_3202_arg8.CFrame
								L_3200_arg6 = L_3201_arg7.RightVector
								L_3199_arg5 = L_3199_arg5 + L_3200_arg6
							end
							L_3200_arg6 = L_3194_arg0[8][1]
							L_3202_arg8 = L_10_func(L_3195_arg1, "Enum")
							L_3202_arg8 = L_3202_arg8.KeyCode
							L_3202_arg8 = L_3202_arg8.Space
							do
								local L_3219_ = L_3200_arg6;
								L_3201_arg7 = L_3219_;
								L_3200_arg6 = L_3219_.IsKeyDown
							end
							L_3200_arg6 = L_3200_arg6(L_3201_arg7, L_3202_arg8)
							if L_3200_arg6 then
								L_3200_arg6 = L_10_func(L_3195_arg1, "Vector3")
								L_3200_arg6 = L_3200_arg6.new
								L_3201_arg7 = 0
								L_3202_arg8 = 1
								L_3203_arg9 = 0
								L_3200_arg6 = L_3200_arg6(L_3201_arg7, L_3202_arg8, L_3203_arg9)
								L_3199_arg5 = L_3199_arg5 + L_3200_arg6
							end
							L_3200_arg6 = L_3194_arg0[8][1]
							L_3202_arg8 = L_10_func(L_3195_arg1, "Enum")
							L_3202_arg8 = L_3202_arg8.KeyCode
							L_3202_arg8 = L_3202_arg8.LeftShift
							do
								local L_3220_ = L_3200_arg6;
								L_3201_arg7 = L_3220_;
								L_3200_arg6 = L_3220_.IsKeyDown
							end
							L_3200_arg6 = L_3200_arg6(L_3201_arg7, L_3202_arg8)
							if L_3200_arg6 then
								L_3200_arg6 = L_10_func(L_3195_arg1, "Vector3")
								L_3200_arg6 = L_3200_arg6.new
								L_3201_arg7 = 0
								L_3202_arg8 = 1
								L_3203_arg9 = 0
								L_3200_arg6 = L_3200_arg6(L_3201_arg7, L_3202_arg8, L_3203_arg9)
								L_3199_arg5 = L_3199_arg5 - L_3200_arg6
							end
							L_3200_arg6 = L_3194_arg0[4][1]
							L_3202_arg8 = L_3199_arg5.Unit
							L_3204_arg10 = L_3194_arg0[3][1]
							L_3203_arg9 = L_3204_arg10.FlySpeed
							L_3201_arg7 = L_3202_arg8 * L_3203_arg9
							L_3200_arg6.Velocity = L_3201_arg7
							return
						end
					else
						return
					end
				end
			end
			return
		else
			return
		end
	end
	return
end

L_13_.fn_278_findSilentAimTarget = function(L_3221_arg0, L_3222_arg1, ...)
	local L_3223_ = L_3221_arg0[1][1]
	local L_3224_ = L_3221_arg0[2][1]
	local L_3225_ = L_3221_arg0[3][1]
	local L_3226_ = L_3221_arg0[4][1]
	local L_3227_ = L_3221_arg0[5][1]
	local L_3228_ = nil
	local L_3229_ = L_3223_.SilentAimFOV
	local L_3230_ = L_3224_:GetMouseLocation()
	for L_3231_forvar0, L_3232_forvar1 in ipairs(L_3225_:GetPlayers()) do
		if L_3232_forvar1 ~= L_3226_ then
			local L_3233_ = L_3232_forvar1.Character
			if L_3233_ then
				local L_3234_ = L_3233_:FindFirstChild("HumanoidRootPart")
				local L_3235_ = L_3233_:FindFirstChildOfClass("Humanoid")
				if L_3234_ and L_3235_ and L_3235_.Health > 0 then
					local L_3236_, L_3237_ = L_3227_:WorldToViewportPoint(L_3234_.Position)
					if L_3237_ then
						local L_3238_ = L_10_func(L_3222_arg1, "Vector2").new(L_3236_.X, L_3236_.Y)
						local L_3239_ = (L_3238_ - L_3230_).Magnitude
						if L_3239_ < L_3229_ then
							L_3228_ = L_3234_
							L_3229_ = L_3239_
						end
					end
				end
			end
		end
	end
	return L_3228_
end

L_13_.fn_279_installSilentAimHook = function(L_3240_arg0, L_3241_arg1, ...)
	local L_3242_, L_3243_ = ...
	local L_3244_ = L_3240_arg0[1][1]
	if L_3244_.SilentAim
        and not L_10_func(L_3241_arg1, "checkcaller")()
        and L_3243_ == "Hit"
        and L_3242_.ClassName == "Mouse" then
		local L_3245_ = L_3240_arg0[2][1]()
		if L_3245_ then
			return L_3245_.CFrame
		end
	end
	return L_3240_arg0[3][1](L_3242_, L_3243_)
end

L_13_.fn_280_updateCamLock = function(L_3246_arg0, L_3247_arg1, L_3248_arg2, L_3249_arg3, L_3250_arg4, L_3251_arg5, L_3252_arg6, L_3253_arg7)
	L_3249_arg3 = L_3246_arg0[1][1]
	L_3248_arg2 = L_3249_arg3.CamLock
	if L_3248_arg2 then
		L_3248_arg2 = L_3246_arg0[2][1]
		L_3250_arg4 = L_10_func(L_3247_arg1, "Enum")
		L_3250_arg4 = L_3250_arg4.UserInputType
		L_3250_arg4 = L_3250_arg4.MouseButton2
		do
			local L_3254_ = L_3248_arg2;
			L_3249_arg3 = L_3254_;
			L_3248_arg2 = L_3254_.IsMouseButtonPressed
		end
		L_3248_arg2 = L_3248_arg2(L_3249_arg3, L_3250_arg4)
		if L_3248_arg2 then
			L_3248_arg2 = L_3246_arg0[3][1]
			L_3248_arg2 = L_3248_arg2()
			if L_3248_arg2 then
				L_3249_arg3 = L_3246_arg0[4][1]
				L_3250_arg4 = L_10_func(L_3247_arg1, "CFrame")
				L_3250_arg4 = L_3250_arg4.new
				L_3253_arg7 = L_3246_arg0[4][1]
				L_3252_arg6 = L_3253_arg7.CFrame
				L_3251_arg5 = L_3252_arg6.Position
				L_3252_arg6 = L_3248_arg2.Position
				L_3250_arg4 = L_3250_arg4(L_3251_arg5, L_3252_arg6)
				L_3249_arg3.CFrame = L_3250_arg4
			end
		end
	end
	L_3248_arg2 = L_3246_arg0[5][1]
	L_3249_arg3 = L_3246_arg0[2][1]
	do
		local L_3255_ = L_3249_arg3;
		L_3250_arg4 = L_3255_;
		L_3249_arg3 = L_3255_.GetMouseLocation
	end
	L_3249_arg3 = L_3249_arg3(L_3250_arg4)
	L_3248_arg2.Position = L_3249_arg3
	L_3248_arg2 = L_3246_arg0[5][1]
	L_3250_arg4 = L_3246_arg0[1][1]
	L_3249_arg3 = L_3250_arg4.SilentAimFOV
	L_3248_arg2.Radius = L_3249_arg3
	L_3248_arg2 = L_3246_arg0[5][1]
	L_3250_arg4 = L_3246_arg0[1][1]
	L_3249_arg3 = L_3250_arg4.SilentAim
	L_3248_arg2.Visible = L_3249_arg3
	return
end

L_13_.fn_281_teleportToTarget = function(L_3256_arg0, L_3257_arg1, L_3258_arg2, L_3259_arg3, L_3260_arg4, L_3261_arg5)
	L_3260_arg4 = L_3256_arg0[1][1]
	L_3259_arg3 = L_3260_arg4.Character
	if L_3259_arg3 then
		L_3260_arg4 = L_3256_arg0[1][1]
		L_3259_arg3 = L_3260_arg4.Character
		L_3261_arg5 = "HumanoidRootPart"
		do
			local L_3262_ = L_3259_arg3;
			L_3260_arg4 = L_3262_;
			L_3259_arg3 = L_3262_.FindFirstChild
		end
		L_3259_arg3 = L_3259_arg3(L_3260_arg4, L_3261_arg5)
		if L_3259_arg3 then
			L_3261_arg5 = L_3256_arg0[1][1]
			L_3260_arg4 = L_3261_arg5.Character
			L_3259_arg3 = L_3260_arg4.HumanoidRootPart
			L_3259_arg3.CFrame = L_3258_arg2
		end
	end
	return
end

L_13_.fn_282_setSilentAim = function(L_3263_arg0, L_3264_arg1, L_3265_arg2, L_3266_arg3)
	L_3266_arg3 = L_3263_arg0[1][1]
	L_3266_arg3.SilentAim = L_3265_arg2
	return
end

L_13_.fn_283_setSilentAimFov = function(L_3267_arg0, L_3268_arg1, L_3269_arg2, L_3270_arg3)
	L_3270_arg3 = L_3267_arg0[1][1]
	L_3270_arg3.SilentAimFOV = L_3269_arg2
	return
end

L_13_.fn_284_setCamLock = function(L_3271_arg0, L_3272_arg1, L_3273_arg2, L_3274_arg3)
	L_3274_arg3 = L_3271_arg0[1][1]
	L_3274_arg3.CamLock = L_3273_arg2
	return
end

L_13_.fn_285_setDaHoodWalkSpeed = function(L_3275_arg0, L_3276_arg1, L_3277_arg2, L_3278_arg3)
	L_3278_arg3 = L_3275_arg0[1][1]
	L_3278_arg3.WS = L_3277_arg2
	return
end

L_13_.fn_286_setDaHoodJumpPower = function(L_3279_arg0, L_3280_arg1, L_3281_arg2, L_3282_arg3)
	L_3282_arg3 = L_3279_arg0[1][1]
	L_3282_arg3.JP = L_3281_arg2
	return
end

L_13_.fn_287_setFly = function(L_3283_arg0, L_3284_arg1, L_3285_arg2, L_3286_arg3)
	L_3286_arg3 = L_3283_arg0[1][1]
	L_3286_arg3.Fly = L_3285_arg2
	return
end

L_13_.fn_288_setFlySpeed = function(L_3287_arg0, L_3288_arg1, L_3289_arg2, L_3290_arg3)
	L_3290_arg3 = L_3287_arg0[1][1]
	L_3290_arg3.FlySpeed = L_3289_arg2
	return
end

L_13_.fn_289_teleportDaHood = function(L_3291_arg0, L_3292_arg1, L_3293_arg2, L_3294_arg3, L_3295_arg4, L_3296_arg5)
	L_3293_arg2 = L_3291_arg0[1][1]
	L_3295_arg4 = L_3291_arg0[2][1]
	L_3294_arg3 = L_3295_arg4.Character
	if L_3294_arg3 then
		L_3295_arg4 = L_3291_arg0[2][1]
		L_3294_arg3 = L_3295_arg4.Character
		L_3296_arg5 = "HumanoidRootPart"
		do
			local L_3297_ = L_3294_arg3;
			L_3295_arg4 = L_3297_;
			L_3294_arg3 = L_3297_.FindFirstChild
		end
		L_3294_arg3 = L_3294_arg3(L_3295_arg4, L_3296_arg5)
		if L_3294_arg3 then
			L_3296_arg5 = L_3291_arg0[2][1]
			L_3295_arg4 = L_3296_arg5.Character
			L_3294_arg3 = L_3295_arg4.HumanoidRootPart
			L_3294_arg3.CFrame = L_3293_arg2
		end
	end
	return
end

L_13_.fn_290_buyArmor = function(L_3298_arg0, L_3299_arg1, L_3300_arg2, L_3301_arg3, L_3302_arg4, L_3303_arg5)
	L_3300_arg2 = L_3298_arg0[1][1]
	if L_3300_arg2 then
		L_3300_arg2 = L_3298_arg0[1][1]
		L_3302_arg4 = "Buy"
		L_3303_arg5 = "Armor"
		do
			local L_3304_ = L_3300_arg2;
			L_3301_arg3 = L_3304_;
			L_3300_arg2 = L_3304_.FireServer
		end
		L_3300_arg2(L_3301_arg3, L_3302_arg4, L_3303_arg5)
	end
	return
end

L_13_.fn_291_autoArmorLoop = function(L_3305_arg0, L_3306_arg1, ...)
	local L_3307_ = L_10_func(L_3306_arg1, "task")
	local L_3308_ = L_10_func(L_3306_arg1, "pcall")
	while L_3307_.wait(1) do
		local L_3309_ = L_3305_arg0[1][1]
		if not L_3309_ or L_3309_.name ~= "Da Hood" then
			break
		end
		local L_3310_ = L_3305_arg0[2][1]
		local L_3311_ = L_3305_arg0[3][1]
		if L_3310_.AutoArmor and L_3311_.Character then
			local L_3312_ = L_3311_.Character:FindFirstChild("BodyEffects")
			local L_3313_ = L_3312_ and L_3312_:FindFirstChild("Armor")
			if L_3313_ and L_3313_.Value <= 0 then
				L_3308_(function()
					local L_3314_ = L_3305_arg0[4][1]
					if L_3314_ then
						L_3314_:FireServer("Buy", "Armor")
					end
				end)
			end
		end
	end
	return
end

L_13_.fn_292_stomp = function(L_3315_arg0, L_3316_arg1, L_3317_arg2, L_3318_arg3, L_3319_arg4)
	L_3317_arg2 = L_3315_arg0[1][1]
	if L_3317_arg2 then
		L_3317_arg2 = L_3315_arg0[1][1]
		L_3319_arg4 = "Stomp"
		do
			local L_3320_ = L_3317_arg2;
			L_3318_arg3 = L_3320_;
			L_3317_arg2 = L_3320_.FireServer
		end
		L_3317_arg2(L_3318_arg3, L_3319_arg4)
	end
	return
end

L_13_.fn_293_autoStompLoop = function(L_3321_arg0, L_3322_arg1, ...)
	local L_3323_ = L_10_func(L_3322_arg1, "task")
	local L_3324_ = L_10_func(L_3322_arg1, "pcall")
	while L_3323_.wait(0.2) do
		local L_3325_ = L_3321_arg0[1][1]
		if not L_3325_ or L_3325_.name ~= "Da Hood" then
			break
		end
		if L_3321_arg0[2][1].AutoStomp then
			L_3324_(function()
				local L_3326_ = L_3321_arg0[3][1]
				if L_3326_ then
					L_3326_:FireServer("Stomp")
				end
			end)
		end
	end
	return
end

L_13_.fn_294_block = function(L_3327_arg0, L_3328_arg1, L_3329_arg2, L_3330_arg3, L_3331_arg4, L_3332_arg5)
	L_3329_arg2 = L_3327_arg0[1][1]
	if L_3329_arg2 then
		L_3329_arg2 = L_3327_arg0[1][1]
		L_3331_arg4 = "Block"
		L_3332_arg5 = true
		do
			local L_3333_ = L_3329_arg2;
			L_3330_arg3 = L_3333_;
			L_3329_arg2 = L_3333_.FireServer
		end
		L_3329_arg2(L_3330_arg3, L_3331_arg4, L_3332_arg5)
		L_3329_arg2 = true
		L_3327_arg0[2][1] = L_3329_arg2
	end
	return
end

L_13_.fn_295_unblock = function(L_3334_arg0, L_3335_arg1, L_3336_arg2, L_3337_arg3, L_3338_arg4, L_3339_arg5)
	L_3336_arg2 = L_3334_arg0[1][1]
	if L_3336_arg2 then
		L_3336_arg2 = L_3334_arg0[1][1]
		L_3338_arg4 = "Block"
		L_3339_arg5 = false
		do
			local L_3340_ = L_3336_arg2;
			L_3337_arg3 = L_3340_;
			L_3336_arg2 = L_3340_.FireServer
		end
		L_3336_arg2(L_3337_arg3, L_3338_arg4, L_3339_arg5)
		L_3336_arg2 = false
		L_3334_arg0[2][1] = L_3336_arg2
	end
	return
end

L_13_.fn_296_autoBlockLoop = function(L_3341_arg0, L_3342_arg1, ...)
	local L_3343_ = L_10_func(L_3342_arg1, "task")
	local L_3344_ = L_10_func(L_3342_arg1, "pcall")
	local L_3345_ = false
	while L_3343_.wait(0.2) do
		local L_3346_ = L_3341_arg0[1][1]
		if not L_3346_ or L_3346_.name ~= "Da Hood" then
			break
		end
		if L_3341_arg0[2][1].AutoBlock then
			if not L_3345_ then
				L_3344_(function()
					local L_3347_ = L_3341_arg0[3][1]
					if L_3347_ then
						L_3347_:FireServer("Block", true)
						L_3345_ = true
					end
				end)
			end
		elseif L_3345_ then
			L_3344_(function()
				local L_3348_ = L_3341_arg0[3][1]
				if L_3348_ then
					L_3348_:FireServer("Block", false)
					L_3345_ = false
				end
			end)
		end
	end
	return
end

L_13_.fn_297_setAutoArmor = function(L_3349_arg0, L_3350_arg1, L_3351_arg2, L_3352_arg3)
	L_3352_arg3 = L_3349_arg0[1][1]
	L_3352_arg3.AutoArmor = L_3351_arg2
	return
end

L_13_.fn_298_setAutoStomp = function(L_3353_arg0, L_3354_arg1, L_3355_arg2, L_3356_arg3)
	L_3356_arg3 = L_3353_arg0[1][1]
	L_3356_arg3.AutoStomp = L_3355_arg2
	return
end

L_13_.fn_299_setAutoBlock = function(L_3357_arg0, L_3358_arg1, L_3359_arg2, L_3360_arg3)
	L_3360_arg3 = L_3357_arg0[1][1]
	L_3360_arg3.AutoBlock = L_3359_arg2
	return
end

L_13_.fn_300_removeEspBox = function(L_3361_arg0, L_3362_arg1, L_3363_arg2, L_3364_arg3)
	L_3364_arg3 = L_3361_arg0[1][1]
	L_3363_arg2 = L_3364_arg3.Box
	do
		local L_3365_ = L_3363_arg2;
		L_3364_arg3 = L_3365_;
		L_3363_arg2 = L_3365_.Remove
	end
	L_3363_arg2(L_3364_arg3)
	return
end

L_13_.fn_301_removeEspTracer = function(L_3366_arg0, L_3367_arg1, L_3368_arg2, L_3369_arg3)
	L_3369_arg3 = L_3366_arg0[1][1]
	L_3368_arg2 = L_3369_arg3.Tracer
	do
		local L_3370_ = L_3368_arg2;
		L_3369_arg3 = L_3370_;
		L_3368_arg2 = L_3370_.Remove
	end
	L_3368_arg2(L_3369_arg3)
	return
end

L_13_.fn_302_removeEspObject = function(L_3371_arg0, L_3372_arg1, L_3373_arg2, L_3374_arg3)
	L_3374_arg3 = L_3371_arg0[1][1]
	L_3373_arg2 = L_3374_arg3.Name
	do
		local L_3375_ = L_3373_arg2;
		L_3374_arg3 = L_3375_;
		L_3373_arg2 = L_3375_.Remove
	end
	L_3373_arg2(L_3374_arg3)
	return
end

L_13_.fn_303_cleanupEspObjects = function(L_3376_arg0, L_3377_arg1, ...)
	local L_3378_ = L_3376_arg0[1][1]
	local L_3379_ = L_10_func(L_3377_arg1, "pcall")
	for L_3380_forvar0, L_3381_forvar1 in pairs(L_3378_) do
		if L_3381_forvar1.Box then
			L_3379_(function()
				L_3381_forvar1.Box:Remove()
			end)
		end
		if L_3381_forvar1.Tracer then
			L_3379_(function()
				L_3381_forvar1.Tracer:Remove()
			end)
		end
		if L_3381_forvar1.Name then
			L_3379_(function()
				L_3381_forvar1.Name:Remove()
			end)
		end
	end
	L_3376_arg0[1][1] = {}
	return
end

L_13_.fn_304_updatePlayerEsp = function(L_3382_arg0, L_3383_arg1, L_3384_arg2, L_3385_arg3, L_3386_arg4, L_3387_arg5, L_3388_arg6, L_3389_arg7, L_3390_arg8, L_3391_arg9, L_3392_arg10, L_3393_arg11, L_3394_arg12, L_3395_arg13, L_3396_arg14, L_3397_arg15, L_3398_arg16, L_3399_arg17, L_3400_arg18, L_3401_arg19)
	L_3384_arg2 = L_3382_arg0[1][1]
	L_3385_arg3 = L_3382_arg0[2][1]
	L_3401_arg19 = (L_3384_arg2 == L_3385_arg3)
	if not L_3401_arg19 then
		L_3385_arg3 = L_3382_arg0[1][1]
		L_3384_arg2 = L_3385_arg3.Character
		if L_3384_arg2 then
			L_3385_arg3 = L_3382_arg0[1][1]
			L_3384_arg2 = L_3385_arg3.Character
			L_3386_arg4 = "HumanoidRootPart"
			do
				local L_3402_ = L_3384_arg2;
				L_3385_arg3 = L_3402_;
				L_3384_arg2 = L_3402_.FindFirstChild
			end
			L_3384_arg2 = L_3384_arg2(L_3385_arg3, L_3386_arg4)
			if L_3384_arg2 then
				L_3385_arg3 = L_3382_arg0[1][1]
				L_3384_arg2 = L_3385_arg3.Character
				L_3386_arg4 = "Head"
				do
					local L_3403_ = L_3384_arg2;
					L_3385_arg3 = L_3403_;
					L_3384_arg2 = L_3403_.FindFirstChild
				end
				L_3384_arg2 = L_3384_arg2(L_3385_arg3, L_3386_arg4)
				if not L_3384_arg2 then
					L_3385_arg3 = L_3382_arg0[4][1]
					L_3386_arg4 = L_3382_arg0[1][1]
					L_3384_arg2 = L_3385_arg3[L_3386_arg4]
					if L_3384_arg2 then
						L_3386_arg4 = L_3382_arg0[4][1]
						L_3387_arg5 = L_3382_arg0[1][1]
						L_3385_arg3 = L_3386_arg4[L_3387_arg5]
						L_3384_arg2 = L_3385_arg3.Box
						if L_3384_arg2 then
							L_3386_arg4 = L_3382_arg0[4][1]
							L_3387_arg5 = L_3382_arg0[1][1]
							L_3385_arg3 = L_3386_arg4[L_3387_arg5]
							L_3384_arg2 = L_3385_arg3.Box
							do
								local L_3404_ = L_3384_arg2;
								L_3385_arg3 = L_3404_;
								L_3384_arg2 = L_3404_.Remove
							end
							L_3384_arg2(L_3385_arg3)
						end
						L_3386_arg4 = L_3382_arg0[4][1]
						L_3387_arg5 = L_3382_arg0[1][1]
						L_3385_arg3 = L_3386_arg4[L_3387_arg5]
						L_3384_arg2 = L_3385_arg3.Tracer
						if L_3384_arg2 then
							L_3386_arg4 = L_3382_arg0[4][1]
							L_3387_arg5 = L_3382_arg0[1][1]
							L_3385_arg3 = L_3386_arg4[L_3387_arg5]
							L_3384_arg2 = L_3385_arg3.Tracer
							do
								local L_3405_ = L_3384_arg2;
								L_3385_arg3 = L_3405_;
								L_3384_arg2 = L_3405_.Remove
							end
							L_3384_arg2(L_3385_arg3)
						end
						L_3386_arg4 = L_3382_arg0[4][1]
						L_3387_arg5 = L_3382_arg0[1][1]
						L_3385_arg3 = L_3386_arg4[L_3387_arg5]
						L_3384_arg2 = L_3385_arg3.Name
						if L_3384_arg2 then
							L_3386_arg4 = L_3382_arg0[4][1]
							L_3387_arg5 = L_3382_arg0[1][1]
							L_3385_arg3 = L_3386_arg4[L_3387_arg5]
							L_3384_arg2 = L_3385_arg3.Name
							do
								local L_3406_ = L_3384_arg2;
								L_3385_arg3 = L_3406_;
								L_3384_arg2 = L_3406_.Remove
							end
							L_3384_arg2(L_3385_arg3)
						end
						L_3384_arg2 = L_3382_arg0[4][1]
						L_3385_arg3 = L_3382_arg0[1][1]
						L_3386_arg4 = nil
						L_3384_arg2[L_3385_arg3] = L_3386_arg4
					end
				else
					L_3385_arg3 = L_3382_arg0[1][1]
					L_3384_arg2 = L_3385_arg3.Character
					L_3385_arg3 = L_3384_arg2.HumanoidRootPart
					L_3386_arg4 = L_3384_arg2.Head
					L_3387_arg5 = L_3382_arg0[3][1]
					L_3389_arg7 = L_3385_arg3.Position
					do
						local L_3407_ = L_3387_arg5;
						L_3388_arg6 = L_3407_;
						L_3387_arg5 = L_3407_.WorldToViewportPoint
					end
					L_3387_arg5, L_3388_arg6 = L_3387_arg5(L_3388_arg6, L_3389_arg7)
					L_3390_arg8 = L_3382_arg0[4][1]
					L_3391_arg9 = L_3382_arg0[1][1]
					L_3389_arg7 = L_3390_arg8[L_3391_arg9]
					if not L_3389_arg7 then
						L_3389_arg7 = L_3382_arg0[4][1]
						L_3390_arg8 = L_3382_arg0[1][1]
						L_3391_arg9 = {}
						L_3389_arg7[L_3390_arg8] = L_3391_arg9
						L_3389_arg7 = L_10_func(L_3383_arg1, "Drawing")
						if L_3389_arg7 then
							L_3390_arg8 = L_3382_arg0[4][1]
							L_3391_arg9 = L_3382_arg0[1][1]
							L_3389_arg7 = L_3390_arg8[L_3391_arg9]
							L_3390_arg8 = L_10_func(L_3383_arg1, "Drawing")
							L_3390_arg8 = L_3390_arg8.new
							L_3391_arg9 = "Square"
							L_3390_arg8 = L_3390_arg8(L_3391_arg9)
							L_3389_arg7.Box = L_3390_arg8
							L_3391_arg9 = L_3382_arg0[4][1]
							L_3392_arg10 = L_3382_arg0[1][1]
							L_3390_arg8 = L_3391_arg9[L_3392_arg10]
							L_3389_arg7 = L_3390_arg8.Box
							L_3390_arg8 = 1
							L_3389_arg7.Thickness = L_3390_arg8
							L_3391_arg9 = L_3382_arg0[4][1]
							L_3392_arg10 = L_3382_arg0[1][1]
							L_3390_arg8 = L_3391_arg9[L_3392_arg10]
							L_3389_arg7 = L_3390_arg8.Box
							L_3390_arg8 = false
							L_3389_arg7.Filled = L_3390_arg8
							L_3391_arg9 = L_3382_arg0[4][1]
							L_3392_arg10 = L_3382_arg0[1][1]
							L_3390_arg8 = L_3391_arg9[L_3392_arg10]
							L_3389_arg7 = L_3390_arg8.Box
							L_3390_arg8 = 1
							L_3389_arg7.Transparency = L_3390_arg8
							L_3390_arg8 = L_3382_arg0[4][1]
							L_3391_arg9 = L_3382_arg0[1][1]
							L_3389_arg7 = L_3390_arg8[L_3391_arg9]
							L_3390_arg8 = L_10_func(L_3383_arg1, "Drawing")
							L_3390_arg8 = L_3390_arg8.new
							L_3391_arg9 = "Line"
							L_3390_arg8 = L_3390_arg8(L_3391_arg9)
							L_3389_arg7.Tracer = L_3390_arg8
							L_3391_arg9 = L_3382_arg0[4][1]
							L_3392_arg10 = L_3382_arg0[1][1]
							L_3390_arg8 = L_3391_arg9[L_3392_arg10]
							L_3389_arg7 = L_3390_arg8.Tracer
							L_3390_arg8 = 1
							L_3389_arg7.Thickness = L_3390_arg8
							L_3391_arg9 = L_3382_arg0[4][1]
							L_3392_arg10 = L_3382_arg0[1][1]
							L_3390_arg8 = L_3391_arg9[L_3392_arg10]
							L_3389_arg7 = L_3390_arg8.Tracer
							L_3390_arg8 = 1
							L_3389_arg7.Transparency = L_3390_arg8
							L_3390_arg8 = L_3382_arg0[4][1]
							L_3391_arg9 = L_3382_arg0[1][1]
							L_3389_arg7 = L_3390_arg8[L_3391_arg9]
							L_3390_arg8 = L_10_func(L_3383_arg1, "Drawing")
							L_3390_arg8 = L_3390_arg8.new
							L_3391_arg9 = "Text"
							L_3390_arg8 = L_3390_arg8(L_3391_arg9)
							L_3389_arg7.Name = L_3390_arg8
							L_3391_arg9 = L_3382_arg0[4][1]
							L_3392_arg10 = L_3382_arg0[1][1]
							L_3390_arg8 = L_3391_arg9[L_3392_arg10]
							L_3389_arg7 = L_3390_arg8.Name
							L_3390_arg8 = 16
							L_3389_arg7.Size = L_3390_arg8
							L_3391_arg9 = L_3382_arg0[4][1]
							L_3392_arg10 = L_3382_arg0[1][1]
							L_3390_arg8 = L_3391_arg9[L_3392_arg10]
							L_3389_arg7 = L_3390_arg8.Name
							L_3390_arg8 = true
							L_3389_arg7.Center = L_3390_arg8
							L_3391_arg9 = L_3382_arg0[4][1]
							L_3392_arg10 = L_3382_arg0[1][1]
							L_3390_arg8 = L_3391_arg9[L_3392_arg10]
							L_3389_arg7 = L_3390_arg8.Name
							L_3390_arg8 = true
							L_3389_arg7.Outline = L_3390_arg8
						end
					end
					L_3390_arg8 = L_3382_arg0[4][1]
					L_3391_arg9 = L_3382_arg0[1][1]
					L_3389_arg7 = L_3390_arg8[L_3391_arg9]
					if L_3389_arg7 then
						L_3390_arg8 = L_3389_arg7.Box
						if not L_3390_arg8 then
							return
						else
							if not L_3388_arg6 then
								L_3390_arg8 = L_3389_arg7.Box
								L_3391_arg9 = false
								L_3390_arg8.Visible = L_3391_arg9
								L_3390_arg8 = L_3389_arg7.Tracer
								L_3391_arg9 = false
								L_3390_arg8.Visible = L_3391_arg9
								L_3390_arg8 = L_3389_arg7.Name
								L_3391_arg9 = false
								L_3390_arg8.Visible = L_3391_arg9
								return
							else
								L_3390_arg8 = L_3382_arg0[3][1]
								L_3393_arg11 = L_3386_arg4.Position
								L_3394_arg12 = L_10_func(L_3383_arg1, "Vector3")
								L_3394_arg12 = L_3394_arg12.new
								L_3395_arg13 = 0
								L_3396_arg14 = 0.5
								L_3397_arg15 = 0
								L_3394_arg12 = L_3394_arg12(L_3395_arg13, L_3396_arg14, L_3397_arg15)
								L_3392_arg10 = L_3393_arg11 + L_3394_arg12
								do
									local L_3408_ = L_3390_arg8;
									L_3391_arg9 = L_3408_;
									L_3390_arg8 = L_3408_.WorldToViewportPoint
								end
								L_3390_arg8 = L_3390_arg8(L_3391_arg9, L_3392_arg10)
								L_3391_arg9 = L_3382_arg0[3][1]
								L_3394_arg12 = L_3385_arg3.Position
								L_3395_arg13 = L_10_func(L_3383_arg1, "Vector3")
								L_3395_arg13 = L_3395_arg13.new
								L_3396_arg14 = 0
								L_3397_arg15 = 3
								L_3398_arg16 = 0
								L_3395_arg13 = L_3395_arg13(L_3396_arg14, L_3397_arg15, L_3398_arg16)
								L_3393_arg11 = L_3394_arg12 - L_3395_arg13
								do
									local L_3409_ = L_3391_arg9;
									L_3392_arg10 = L_3409_;
									L_3391_arg9 = L_3409_.WorldToViewportPoint
								end
								L_3391_arg9 = L_3391_arg9(L_3392_arg10, L_3393_arg11)
								L_3394_arg12 = L_3390_arg8.Y
								L_3395_arg13 = L_3391_arg9.Y
								L_3393_arg11 = L_3394_arg12 - L_3395_arg13
								L_3392_arg10 = L_10_func(L_3383_arg1, "math")
								L_3392_arg10 = L_3392_arg10.abs
								L_3392_arg10 = L_3392_arg10(L_3393_arg11)
								L_3393_arg11 = L_3392_arg10 / 2
								L_3394_arg12 = L_3389_arg7.Box
								L_3395_arg13 = L_10_func(L_3383_arg1, "Vector2")
								L_3395_arg13 = L_3395_arg13.new
								L_3396_arg14 = L_3393_arg11
								L_3397_arg15 = L_3392_arg10
								L_3395_arg13 = L_3395_arg13(L_3396_arg14, L_3397_arg15)
								L_3394_arg12.Size = L_3395_arg13
								L_3394_arg12 = L_3389_arg7.Box
								L_3395_arg13 = L_10_func(L_3383_arg1, "Vector2")
								L_3395_arg13 = L_3395_arg13.new
								L_3397_arg15 = L_3387_arg5.X
								L_3398_arg16 = L_3393_arg11 / 2
								L_3396_arg14 = L_3397_arg15 - L_3398_arg16
								L_3397_arg15 = L_3390_arg8.Y
								L_3395_arg13 = L_3395_arg13(L_3396_arg14, L_3397_arg15)
								L_3394_arg12.Position = L_3395_arg13
								L_3394_arg12 = L_3389_arg7.Box
								L_3396_arg14 = L_3382_arg0[5][1]
								L_3395_arg13 = L_3396_arg14.Color
								L_3394_arg12.Color = L_3395_arg13
								L_3394_arg12 = L_3389_arg7.Box
								L_3396_arg14 = L_3382_arg0[5][1]
								L_3395_arg13 = L_3396_arg14.Boxes
								L_3394_arg12.Visible = L_3395_arg13
								L_3394_arg12 = L_3389_arg7.Tracer
								L_3395_arg13 = L_10_func(L_3383_arg1, "Vector2")
								L_3395_arg13 = L_3395_arg13.new
								L_3399_arg17 = L_3382_arg0[3][1]
								L_3398_arg16 = L_3399_arg17.ViewportSize
								L_3397_arg15 = L_3398_arg16.X
								L_3396_arg14 = L_3397_arg15 / 2
								L_3399_arg17 = L_3382_arg0[3][1]
								L_3398_arg16 = L_3399_arg17.ViewportSize
								L_3397_arg15 = L_3398_arg16.Y
								L_3395_arg13 = L_3395_arg13(L_3396_arg14, L_3397_arg15)
								L_3394_arg12.From = L_3395_arg13
								L_3394_arg12 = L_3389_arg7.Tracer
								L_3395_arg13 = L_10_func(L_3383_arg1, "Vector2")
								L_3395_arg13 = L_3395_arg13.new
								L_3396_arg14 = L_3387_arg5.X
								L_3397_arg15 = L_3387_arg5.Y
								L_3395_arg13 = L_3395_arg13(L_3396_arg14, L_3397_arg15)
								L_3394_arg12.To = L_3395_arg13
								L_3394_arg12 = L_3389_arg7.Tracer
								L_3396_arg14 = L_3382_arg0[5][1]
								L_3395_arg13 = L_3396_arg14.Color
								L_3394_arg12.Color = L_3395_arg13
								L_3394_arg12 = L_3389_arg7.Tracer
								L_3396_arg14 = L_3382_arg0[5][1]
								L_3395_arg13 = L_3396_arg14.Tracers
								L_3394_arg12.Visible = L_3395_arg13
								L_3394_arg12 = L_3389_arg7.Name
								L_3396_arg14 = L_3382_arg0[1][1]
								L_3395_arg13 = L_3396_arg14.Name
								L_3394_arg12.Text = L_3395_arg13
								L_3394_arg12 = L_3389_arg7.Name
								L_3395_arg13 = L_10_func(L_3383_arg1, "Vector2")
								L_3395_arg13 = L_3395_arg13.new
								L_3396_arg14 = L_3387_arg5.X
								L_3398_arg16 = L_3390_arg8.Y
								L_3397_arg15 = L_3398_arg16 - 20
								L_3395_arg13 = L_3395_arg13(L_3396_arg14, L_3397_arg15)
								L_3394_arg12.Position = L_3395_arg13
								L_3394_arg12 = L_3389_arg7.Name
								L_3396_arg14 = L_3382_arg0[5][1]
								L_3395_arg13 = L_3396_arg14.Color
								L_3394_arg12.Color = L_3395_arg13
								L_3394_arg12 = L_3389_arg7.Name
								L_3396_arg14 = L_3382_arg0[5][1]
								L_3395_arg13 = L_3396_arg14.Names
								L_3394_arg12.Visible = L_3395_arg13
								return
							end
						end
					end
				end
				return
			end
		end
	end
	L_3385_arg3 = L_3382_arg0[4][1]
	L_3386_arg4 = L_3382_arg0[1][1]
	L_3384_arg2 = L_3385_arg3[L_3386_arg4]
	if L_3384_arg2 then
		L_3386_arg4 = L_3382_arg0[4][1]
		L_3387_arg5 = L_3382_arg0[1][1]
		L_3385_arg3 = L_3386_arg4[L_3387_arg5]
		L_3384_arg2 = L_3385_arg3.Box
		if L_3384_arg2 then
			L_3386_arg4 = L_3382_arg0[4][1]
			L_3387_arg5 = L_3382_arg0[1][1]
			L_3385_arg3 = L_3386_arg4[L_3387_arg5]
			L_3384_arg2 = L_3385_arg3.Box
			do
				local L_3410_ = L_3384_arg2;
				L_3385_arg3 = L_3410_;
				L_3384_arg2 = L_3410_.Remove
			end
			L_3384_arg2(L_3385_arg3)
		end
		L_3386_arg4 = L_3382_arg0[4][1]
		L_3387_arg5 = L_3382_arg0[1][1]
		L_3385_arg3 = L_3386_arg4[L_3387_arg5]
		L_3384_arg2 = L_3385_arg3.Tracer
		if L_3384_arg2 then
			L_3386_arg4 = L_3382_arg0[4][1]
			L_3387_arg5 = L_3382_arg0[1][1]
			L_3385_arg3 = L_3386_arg4[L_3387_arg5]
			L_3384_arg2 = L_3385_arg3.Tracer
			do
				local L_3411_ = L_3384_arg2;
				L_3385_arg3 = L_3411_;
				L_3384_arg2 = L_3411_.Remove
			end
			L_3384_arg2(L_3385_arg3)
		end
		L_3386_arg4 = L_3382_arg0[4][1]
		L_3387_arg5 = L_3382_arg0[1][1]
		L_3385_arg3 = L_3386_arg4[L_3387_arg5]
		L_3384_arg2 = L_3385_arg3.Name
		if L_3384_arg2 then
			L_3386_arg4 = L_3382_arg0[4][1]
			L_3387_arg5 = L_3382_arg0[1][1]
			L_3385_arg3 = L_3386_arg4[L_3387_arg5]
			L_3384_arg2 = L_3385_arg3.Name
			do
				local L_3412_ = L_3384_arg2;
				L_3385_arg3 = L_3412_;
				L_3384_arg2 = L_3412_.Remove
			end
			L_3384_arg2(L_3385_arg3)
		end
		L_3384_arg2 = L_3382_arg0[4][1]
		L_3385_arg3 = L_3382_arg0[1][1]
		L_3386_arg4 = nil
		L_3384_arg2[L_3385_arg3] = L_3386_arg4
	end
	return
end

L_13_.fn_305_startPlayerEsp = function(L_3413_arg0, L_3414_arg1, ...)
	local L_3415_ = L_3413_arg0[1][1]
	local L_3416_ = L_3413_arg0[2][1]
	local L_3417_ = L_3413_arg0[3][1]
	local L_3418_ = L_3413_arg0[4][1]
	local L_3419_ = L_3413_arg0[5][1]
	local L_3420_ = L_3413_arg0[6]
	local L_3421_ = L_3413_arg0[7]
	local L_3422_ = L_3413_arg0[8]
	local L_3423_ = L_3413_arg0[9]
	if not L_3415_ or L_3415_.name ~= "Da Hood" then
		if L_3416_ then
			L_3416_:Disconnect()
		end
		L_3417_()
		if L_3418_ then
			L_3418_:Remove()
		end
		return
	end
	local L_3424_ = L_10_func(L_3414_arg1, "pcall")
	for L_3426_forvar0, L_3427_forvar1 in pairs(L_3419_:GetPlayers()) do
		local L_3428_ = L_14_func(
            L_13_.fn_304_updatePlayerEsp,
            L_3414_arg1,
            {
			{
				L_3427_forvar1
			},
			L_3420_,
			L_3421_,
			L_3422_,
			L_3423_
		}
        )
		L_3424_(L_3428_)
	end
	local L_3425_ = L_3422_[1]
	for L_3429_forvar0, L_3430_forvar1 in pairs(L_3425_) do
		local L_3431_ = L_3429_forvar0
            and L_3429_forvar0.Parent
            and L_3419_:FindFirstChild(L_3429_forvar0.Name)
		if not L_3431_ then
			if L_3430_forvar1.Box then
				L_3430_forvar1.Box:Remove()
			end
			if L_3430_forvar1.Tracer then
				L_3430_forvar1.Tracer:Remove()
			end
			if L_3430_forvar1.Name then
				L_3430_forvar1.Name:Remove()
			end
			L_3425_[L_3429_forvar0] = nil
		end
	end
	return
end

L_13_.fn_306_setEspBoxes = function(L_3432_arg0, L_3433_arg1, L_3434_arg2, L_3435_arg3)
	L_3435_arg3 = L_3432_arg0[1][1]
	L_3435_arg3.Boxes = L_3434_arg2
	return
end

L_13_.fn_307_setEspNames = function(L_3436_arg0, L_3437_arg1, L_3438_arg2, L_3439_arg3)
	L_3439_arg3 = L_3436_arg0[1][1]
	L_3439_arg3.Names = L_3438_arg2
	return
end

L_13_.fn_308_setEspTracers = function(L_3440_arg0, L_3441_arg1, L_3442_arg2, L_3443_arg3)
	L_3443_arg3 = L_3440_arg0[1][1]
	L_3443_arg3.Tracers = L_3442_arg2
	return
end

L_13_.fn_309_setEspColor = function(L_3444_arg0, L_3445_arg1, L_3446_arg2, L_3447_arg3, L_3448_arg4, L_3449_arg5, L_3450_arg6, L_3451_arg7)
	L_3447_arg3 = L_3444_arg0[1][1]
	L_3449_arg5 = L_3444_arg0[2][1]
	L_3448_arg4 = L_3449_arg5[L_3446_arg2]
	if not L_3448_arg4 then
		L_3448_arg4 = L_10_func(L_3445_arg1, "Color3")
		L_3448_arg4 = L_3448_arg4.fromRGB
		L_3449_arg5 = 0
		L_3450_arg6 = 162
		L_3451_arg7 = 255
		L_3448_arg4 = L_3448_arg4(L_3449_arg5, L_3450_arg6, L_3451_arg7)
	end
	L_3447_arg3.Color = L_3448_arg4
	return
end

L_13_.main = function(L_3452_arg0, L_3453_arg1, ...)
	local L_3454_ = {}
	local L_3455_ = {}
	local L_3456_ = 73
	local L_3457_ = {
		n = 0
	}
	local L_3458_ = 0
	local function L_3459_func(L_3464_arg0)
		local L_3465_ = L_3455_[L_3464_arg0]
		if L_3465_ ~= nil then
			return L_3465_[1]
		end
		return L_3454_[L_3464_arg0]
	end
	local function L_3460_func(L_3466_arg0, L_3467_arg1)
		local L_3468_ = L_3455_[L_3466_arg0]
		if L_3468_ ~= nil then
			L_3468_[1] = L_3467_arg1
		else
			L_3454_[L_3466_arg0] = L_3467_arg1
		end
	end
	local function L_3461_func(L_3469_arg0)
		local L_3470_ = L_3455_[L_3469_arg0]
		if L_3470_ == nil then
			L_3470_ = {
				L_3454_[L_3469_arg0]
			};
			L_3455_[L_3469_arg0] = L_3470_
		end
		return L_3470_
	end
	local function L_3462_func(L_3471_arg0, L_3472_arg1)
		local L_3473_ = {
			n = L_3472_arg1
		}
		for L_3474_forvar0 = 1, L_3472_arg1 do
			L_3473_[L_3474_forvar0] = L_3459_func(L_3471_arg0 + L_3474_forvar0 - 1)
		end
		return L_3473_
	end

	local L_3463_ = 0
	while true do
		local L_3475_ = math.floor(L_3463_ / 256)
		if L_3475_ == 0 then
			if L_3463_ == 0 then

				L_3460_func(0, L_10_func(L_3453_arg1, "getgenv"))
				do
					local L_3476_ = 0
					local L_3477_ = L_3462_func(1, L_3476_)
					local L_3478_ = L_1_(L_3459_func(0)(L_2_(L_3477_, 1, L_3477_.n)))
					for L_3479_forvar0 = 1, 1 do
						L_3460_func(0 + L_3479_forvar0 - 1, L_3478_[L_3479_forvar0])
					end
				end

				do
					local L_3480_ = {}
					local L_3481_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_3482_
					L_3482_ = function(...)
						return L_13_.fn_001_premTag(L_3480_, L_3481_, ...)
					end
					L_6_[L_3482_] = L_3481_
					L_3460_func(1, L_3482_)
				end
				L_3459_func(0)["_premTag"] = L_3459_func(1)

				do
					local L_3483_ = {}
					local L_3484_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_3485_
					L_3485_ = function(...)
						return L_13_.fn_002_isPremiumUser(L_3483_, L_3484_, ...)
					end
					L_6_[L_3485_] = L_3484_
					L_3460_func(1, L_3485_)
				end
				L_3459_func(0)["_isPremiumUser"] = L_3459_func(1)
				L_3460_func(0, L_10_func(L_3453_arg1, "getgenv"))
				do
					local L_3486_ = 0
					local L_3487_ = L_3462_func(1, L_3486_)
					local L_3488_ = L_1_(L_3459_func(0)(L_2_(L_3487_, 1, L_3487_.n)))
					for L_3489_forvar0 = 1, 1 do
						L_3460_func(0 + L_3489_forvar0 - 1, L_3488_[L_3489_forvar0])
					end
				end
				L_3460_func(1, L_3459_func(0)["__SnowyUIRuntime"])
				if L_3459_func(1) then
					L_3463_ = 12
				else
					L_3463_ = 11
				end
			elseif L_3463_ == 11 then

				L_3460_func(1, {})
				L_3463_ = 12
			elseif L_3463_ == 12 then

				do
					local L_3490_ = {}
					local L_3491_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_3492_
					L_3492_ = function(...)
						return L_13_.fn_003_corner(L_3490_, L_3491_, ...)
					end
					L_6_[L_3492_] = L_3491_
					L_3460_func(2, L_3492_)
				end
				L_3459_func(1)["corner"] = L_3459_func(2)

				do
					local L_3493_ = {}
					local L_3494_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_3495_
					L_3495_ = function(...)
						return L_13_.fn_004_stroke(L_3493_, L_3494_, ...)
					end
					L_6_[L_3495_] = L_3494_
					L_3460_func(2, L_3495_)
				end
				L_3459_func(1)["stroke"] = L_3459_func(2)

				do
					local L_3496_ = {}
					local L_3497_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_3498_
					L_3498_ = function(...)
						return L_13_.fn_005_gradient(L_3496_, L_3497_, ...)
					end
					L_6_[L_3498_] = L_3497_
					L_3460_func(2, L_3498_)
				end
				L_3459_func(1)["gradient"] = L_3459_func(2)

				do
					local L_3499_ = {}
					local L_3500_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_3501_
					L_3501_ = function(...)
						return L_13_.fn_006_shadow(L_3499_, L_3500_, ...)
					end
					L_6_[L_3501_] = L_3500_
					L_3460_func(2, L_3501_)
				end
				L_3459_func(1)["shadow"] = L_3459_func(2)

				do
					local L_3502_ = {}
					local L_3503_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_3504_
					L_3504_ = function(...)
						return L_13_.fn_007_tw(L_3502_, L_3503_, ...)
					end
					L_6_[L_3504_] = L_3503_
					L_3460_func(2, L_3504_)
				end
				L_3459_func(1)["tw"] = L_3459_func(2)
				L_3459_func(0)["__SnowyUIRuntime"] = L_3459_func(1)
				L_3460_func(2, L_3459_func(1)["corner"])
				L_3459_func(0)["corner"] = L_3459_func(2)
				L_3460_func(2, L_3459_func(1)["stroke"])
				L_3459_func(0)["stroke"] = L_3459_func(2)
				L_3460_func(2, L_3459_func(1)["gradient"])
				L_3459_func(0)["gradient"] = L_3459_func(2)
				L_3460_func(2, L_3459_func(1)["shadow"])
				L_3459_func(0)["shadow"] = L_3459_func(2)
				L_3460_func(2, L_3459_func(1)["tw"])
				L_3459_func(0)["tw"] = L_3459_func(2)
				L_3460_func(1, L_10_func(L_3453_arg1, "getgenv"))
				do
					local L_3505_ = 0
					local L_3506_ = L_3462_func(2, L_3505_)
					local L_3507_ = L_1_(L_3459_func(1)(L_2_(L_3506_, 1, L_3506_.n)))
					for L_3508_forvar0 = 1, 1 do
						L_3460_func(1 + L_3508_forvar0 - 1, L_3507_[L_3508_forvar0])
					end
				end
				L_3460_func(0, L_3459_func(1)["_nagPremium"])
				if L_3459_func(0) then
					L_3463_ = 45
				else
					L_3463_ = 41
				end
			elseif L_3463_ == 41 then

				do
					local L_3509_ = {}
					local L_3510_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_3511_
					L_3511_ = function(...)
						return L_13_.fn_008_nagPremium(L_3509_, L_3510_, ...)
					end
					L_6_[L_3511_] = L_3510_
					L_3460_func(0, L_3511_)
				end
				L_3460_func(1, L_10_func(L_3453_arg1, "getgenv"))
				do
					local L_3512_ = 0
					local L_3513_ = L_3462_func(2, L_3512_)
					local L_3514_ = L_1_(L_3459_func(1)(L_2_(L_3513_, 1, L_3513_.n)))
					for L_3515_forvar0 = 1, 1 do
						L_3460_func(1 + L_3515_forvar0 - 1, L_3514_[L_3515_forvar0])
					end
				end
				L_3459_func(1)["_nagPremium"] = L_3459_func(0)
				L_3463_ = 45
			elseif L_3463_ == 45 then

				L_3460_func(0, L_10_func(L_3453_arg1, "game"))
				L_3460_func(2, "TweenService")
				do
					local L_3516_ = L_3459_func(0)
					L_3460_func(1, L_3516_)
					L_3460_func(0, L_3516_["GetService"])
				end
				do
					local L_3517_ = 2
					local L_3518_ = L_3462_func(1, L_3517_)
					local L_3519_ = L_1_(L_3459_func(0)(L_2_(L_3518_, 1, L_3518_.n)))
					for L_3520_forvar0 = 1, 1 do
						L_3460_func(0 + L_3520_forvar0 - 1, L_3519_[L_3520_forvar0])
					end
				end
				L_3460_func(1, L_10_func(L_3453_arg1, "game"))
				L_3460_func(3, "UserInputService")
				do
					local L_3521_ = L_3459_func(1)
					L_3460_func(2, L_3521_)
					L_3460_func(1, L_3521_["GetService"])
				end
				do
					local L_3522_ = 2
					local L_3523_ = L_3462_func(2, L_3522_)
					local L_3524_ = L_1_(L_3459_func(1)(L_2_(L_3523_, 1, L_3523_.n)))
					for L_3525_forvar0 = 1, 1 do
						L_3460_func(1 + L_3525_forvar0 - 1, L_3524_[L_3525_forvar0])
					end
				end
				L_3460_func(2, L_10_func(L_3453_arg1, "game"))
				L_3460_func(4, "RunService")
				do
					local L_3526_ = L_3459_func(2)
					L_3460_func(3, L_3526_)
					L_3460_func(2, L_3526_["GetService"])
				end
				do
					local L_3527_ = 2
					local L_3528_ = L_3462_func(3, L_3527_)
					local L_3529_ = L_1_(L_3459_func(2)(L_2_(L_3528_, 1, L_3528_.n)))
					for L_3530_forvar0 = 1, 1 do
						L_3460_func(2 + L_3530_forvar0 - 1, L_3529_[L_3530_forvar0])
					end
				end
				L_3460_func(3, L_10_func(L_3453_arg1, "game"))
				L_3460_func(5, "Players")
				do
					local L_3531_ = L_3459_func(3)
					L_3460_func(4, L_3531_)
					L_3460_func(3, L_3531_["GetService"])
				end
				do
					local L_3532_ = 2
					local L_3533_ = L_3462_func(4, L_3532_)
					local L_3534_ = L_1_(L_3459_func(3)(L_2_(L_3533_, 1, L_3533_.n)))
					for L_3535_forvar0 = 1, 1 do
						L_3460_func(3 + L_3535_forvar0 - 1, L_3534_[L_3535_forvar0])
					end
				end
				L_3460_func(4, L_10_func(L_3453_arg1, "game"))
				L_3460_func(6, "HttpService")
				do
					local L_3536_ = L_3459_func(4)
					L_3460_func(5, L_3536_)
					L_3460_func(4, L_3536_["GetService"])
				end
				do
					local L_3537_ = 2
					local L_3538_ = L_3462_func(5, L_3537_)
					local L_3539_ = L_1_(L_3459_func(4)(L_2_(L_3538_, 1, L_3538_.n)))
					for L_3540_forvar0 = 1, 1 do
						L_3460_func(4 + L_3540_forvar0 - 1, L_3539_[L_3540_forvar0])
					end
				end
				L_3460_func(5, L_10_func(L_3453_arg1, "game"))
				L_3460_func(7, "CoreGui")
				do
					local L_3541_ = L_3459_func(5)
					L_3460_func(6, L_3541_)
					L_3460_func(5, L_3541_["GetService"])
				end
				do
					local L_3542_ = 2
					local L_3543_ = L_3462_func(6, L_3542_)
					local L_3544_ = L_1_(L_3459_func(5)(L_2_(L_3543_, 1, L_3543_.n)))
					for L_3545_forvar0 = 1, 1 do
						L_3460_func(5 + L_3545_forvar0 - 1, L_3544_[L_3545_forvar0])
					end
				end
				L_3460_func(6, L_3459_func(3)["LocalPlayer"])

				do
					local L_3546_ = {}
					local L_3547_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_3548_
					L_3548_ = function(...)
						return L_13_.fn_011_resolveEnvironment(L_3546_, L_3547_, ...)
					end
					L_6_[L_3548_] = L_3547_
					L_3460_func(7, L_3548_)
				end

				do
					local L_3549_ = {}
					local L_3550_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_3551_
					L_3551_ = function(...)
						return L_13_.fn_013_environmentHelper(L_3549_, L_3550_, ...)
					end
					L_6_[L_3551_] = L_3550_
					L_3460_func(8, L_3551_)
				end
				L_3460_func(9, L_10_func(L_3453_arg1, "pcall"))

				do
					local L_3552_ = {}
					L_3552_[1] = {
						L_3459_func(7)
					}
					local L_3553_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_3554_
					L_3554_ = function(...)
						return L_13_.fn_014_installAntiDetectStubs(L_3552_, L_3553_, ...)
					end
					L_6_[L_3554_] = L_3553_
					L_3460_func(10, L_3554_)
				end
				do
					local L_3555_ = 1
					local L_3556_ = L_3462_func(10, L_3555_)
					L_3459_func(9)(L_2_(L_3556_, 1, L_3556_.n))
				end

				do
					local L_3557_ = {}
					local L_3558_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_3559_
					L_3559_ = function(...)
						return L_13_.fn_018_makeProxyTable(L_3557_, L_3558_, ...)
					end
					L_6_[L_3559_] = L_3558_
					L_3460_func(9, L_3559_)
				end

				do
					local L_3560_ = {}
					local L_3561_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_3562_
					L_3562_ = function(...)
						return L_13_.fn_020(L_3560_, L_3561_, ...)
					end
					L_6_[L_3562_] = L_3561_
					L_3460_func(10, L_3562_)
				end
				L_3460_func(11, L_10_func(L_3453_arg1, "pcall"))
				L_3460_func(13, "getrawmetatable")

				do
					local L_3563_ = {}
					L_3563_[1] = {
						L_3459_func(13)
					}
					L_3563_[2] = {
						L_3459_func(9)
					}
					local L_3564_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_3565_
					L_3565_ = function(...)
						return L_13_.fn_012_probeExecutorGlobal(L_3563_, L_3564_, ...)
					end
					L_6_[L_3565_] = L_3564_
					L_3460_func(12, L_3565_)
				end
				do
					local L_3566_ = 1
					local L_3567_ = L_3462_func(12, L_3566_)
					L_3459_func(11)(L_2_(L_3567_, 1, L_3567_.n))
				end
				L_3460_func(11, L_10_func(L_3453_arg1, "pcall"))
				L_3460_func(13, "hookmetamethod")

				do
					local L_3568_ = {}
					L_3568_[1] = {
						L_3459_func(13)
					}
					L_3568_[2] = {
						L_3459_func(10)
					}
					local L_3569_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_3570_
					L_3570_ = function(...)
						return L_13_.fn_012_probeExecutorGlobal(L_3568_, L_3569_, ...)
					end
					L_6_[L_3570_] = L_3569_
					L_3460_func(12, L_3570_)
				end
				do
					local L_3571_ = 1
					local L_3572_ = L_3462_func(12, L_3571_)
					L_3459_func(11)(L_2_(L_3572_, 1, L_3572_.n))
				end

				do
					local L_3573_ = {}
					local L_3574_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_3575_
					L_3575_ = function(...)
						return L_13_.fn_021(L_3573_, L_3574_, ...)
					end
					L_6_[L_3575_] = L_3574_
					L_3460_func(11, L_3575_)
				end
				L_3460_func(12, L_10_func(L_3453_arg1, "pcall"))
				L_3460_func(14, "setreadonly")

				do
					local L_3576_ = {}
					L_3576_[1] = {
						L_3459_func(14)
					}
					L_3576_[2] = {
						L_3459_func(11)
					}
					local L_3577_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_3578_
					L_3578_ = function(...)
						return L_13_.fn_012_probeExecutorGlobal(L_3576_, L_3577_, ...)
					end
					L_6_[L_3578_] = L_3577_
					L_3460_func(13, L_3578_)
				end
				do
					local L_3579_ = 1
					local L_3580_ = L_3462_func(13, L_3579_)
					L_3459_func(12)(L_2_(L_3580_, 1, L_3580_.n))
				end

				do
					local L_3581_ = {}
					local L_3582_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_3583_
					L_3583_ = function(...)
						return L_13_.fn_022(L_3581_, L_3582_, ...)
					end
					L_6_[L_3583_] = L_3582_
					L_3460_func(11, L_3583_)
				end
				L_3460_func(12, L_10_func(L_3453_arg1, "pcall"))
				L_3460_func(14, "setrawmetatable")

				do
					local L_3584_ = {}
					L_3584_[1] = {
						L_3459_func(14)
					}
					L_3584_[2] = {
						L_3459_func(11)
					}
					local L_3585_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_3586_
					L_3586_ = function(...)
						return L_13_.fn_012_probeExecutorGlobal(L_3584_, L_3585_, ...)
					end
					L_6_[L_3586_] = L_3585_
					L_3460_func(13, L_3586_)
				end
				do
					local L_3587_ = 1
					local L_3588_ = L_3462_func(13, L_3587_)
					L_3459_func(12)(L_2_(L_3588_, 1, L_3588_.n))
				end
				L_3460_func(11, L_10_func(L_3453_arg1, "warn"))
				L_3460_func(12, "[SnowyHub] Anti-detect stub installed (Delta-compatible).")
				do
					local L_3589_ = 1
					local L_3590_ = L_3462_func(12, L_3589_)
					L_3459_func(11)(L_2_(L_3590_, 1, L_3590_.n))
				end
				L_3460_func(7, L_10_func(L_3453_arg1, "pcall"))

				do
					local L_3591_ = {}
					local L_3592_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_3593_
					L_3593_ = function(...)
						return L_13_.fn_040_installCompatibilityAliases(L_3591_, L_3592_, ...)
					end
					L_6_[L_3593_] = L_3592_
					L_3460_func(8, L_3593_)
				end
				do
					local L_3594_ = 1
					local L_3595_ = L_3462_func(8, L_3594_)
					L_3459_func(7)(L_2_(L_3595_, 1, L_3595_.n))
				end
				L_3460_func(7, {})
				L_3460_func(8, 720)
				L_3459_func(7)["WindowWidth"] = L_3459_func(8)
				L_3460_func(8, 520)
				L_3459_func(7)["WindowHeight"] = L_3459_func(8)
				L_3460_func(8, 48)
				L_3459_func(7)["HeaderHeight"] = L_3459_func(8)
				L_3460_func(8, 44)
				L_3459_func(7)["TabBarHeight"] = L_3459_func(8)
				L_3460_func(8, 62)
				L_3459_func(7)["BannerHeight"] = L_3459_func(8)
				L_3460_func(8, 24)
				L_3459_func(7)["Radius"] = L_3459_func(8)
				L_3460_func(8, 16)
				L_3459_func(7)["RadiusSm"] = L_3459_func(8)
				L_3460_func(8, 12)
				L_3459_func(7)["RadiusXs"] = L_3459_func(8)
				L_3460_func(8, 999)
				L_3459_func(7)["RadiusPill"] = L_3459_func(8)
				L_3460_func(8, L_10_func(L_3453_arg1, "Color3"))
				L_3460_func(8, L_3459_func(8)["fromRGB"])
				L_3460_func(9, 18)
				L_3460_func(10, 24)
				L_3460_func(11, 64)
				do
					local L_3596_ = 3
					local L_3597_ = L_3462_func(9, L_3596_)
					local L_3598_ = L_1_(L_3459_func(8)(L_2_(L_3597_, 1, L_3597_.n)))
					for L_3599_forvar0 = 1, 1 do
						L_3460_func(8 + L_3599_forvar0 - 1, L_3598_[L_3599_forvar0])
					end
				end
				L_3459_func(7)["BgPrimary"] = L_3459_func(8)
				L_3460_func(8, L_10_func(L_3453_arg1, "Color3"))
				L_3460_func(8, L_3459_func(8)["fromRGB"])
				L_3460_func(9, 24)
				L_3460_func(10, 32)
				L_3460_func(11, 85)
				do
					local L_3600_ = 3
					local L_3601_ = L_3462_func(9, L_3600_)
					local L_3602_ = L_1_(L_3459_func(8)(L_2_(L_3601_, 1, L_3601_.n)))
					for L_3603_forvar0 = 1, 1 do
						L_3460_func(8 + L_3603_forvar0 - 1, L_3602_[L_3603_forvar0])
					end
				end
				L_3459_func(7)["BgSecondary"] = L_3459_func(8)
				L_3460_func(8, L_10_func(L_3453_arg1, "Color3"))
				L_3460_func(8, L_3459_func(8)["fromRGB"])
				L_3460_func(9, 35)
				L_3460_func(10, 45)
				L_3460_func(11, 110)
				do
					local L_3604_ = 3
					local L_3605_ = L_3462_func(9, L_3604_)
					local L_3606_ = L_1_(L_3459_func(8)(L_2_(L_3605_, 1, L_3605_.n)))
					for L_3607_forvar0 = 1, 1 do
						L_3460_func(8 + L_3607_forvar0 - 1, L_3606_[L_3607_forvar0])
					end
				end
				L_3459_func(7)["BgCard"] = L_3459_func(8)
				L_3460_func(8, L_10_func(L_3453_arg1, "Color3"))
				L_3460_func(8, L_3459_func(8)["fromRGB"])
				L_3460_func(9, 45)
				L_3460_func(10, 60)
				L_3460_func(11, 140)
				do
					local L_3608_ = 3
					local L_3609_ = L_3462_func(9, L_3608_)
					local L_3610_ = L_1_(L_3459_func(8)(L_2_(L_3609_, 1, L_3609_.n)))
					for L_3611_forvar0 = 1, 1 do
						L_3460_func(8 + L_3611_forvar0 - 1, L_3610_[L_3611_forvar0])
					end
				end
				L_3459_func(7)["BgCardHover"] = L_3459_func(8)
				L_3460_func(8, L_10_func(L_3453_arg1, "Color3"))
				L_3460_func(8, L_3459_func(8)["fromRGB"])
				L_3460_func(9, 40)
				L_3460_func(10, 65)
				L_3460_func(11, 160)
				do
					local L_3612_ = 3
					local L_3613_ = L_3462_func(9, L_3612_)
					local L_3614_ = L_1_(L_3459_func(8)(L_2_(L_3613_, 1, L_3613_.n)))
					for L_3615_forvar0 = 1, 1 do
						L_3460_func(8 + L_3615_forvar0 - 1, L_3614_[L_3615_forvar0])
					end
				end
				L_3459_func(7)["BgCardActive"] = L_3459_func(8)
				L_3460_func(8, L_10_func(L_3453_arg1, "Color3"))
				L_3460_func(8, L_3459_func(8)["fromRGB"])
				L_3460_func(9, 14)
				L_3460_func(10, 18)
				L_3460_func(11, 50)
				do
					local L_3616_ = 3
					local L_3617_ = L_3462_func(9, L_3616_)
					local L_3618_ = L_1_(L_3459_func(8)(L_2_(L_3617_, 1, L_3617_.n)))
					for L_3619_forvar0 = 1, 1 do
						L_3460_func(8 + L_3619_forvar0 - 1, L_3618_[L_3619_forvar0])
					end
				end
				L_3459_func(7)["BgHeader"] = L_3459_func(8)
				L_3460_func(8, L_10_func(L_3453_arg1, "Color3"))
				L_3460_func(8, L_3459_func(8)["fromRGB"])
				L_3460_func(9, 20)
				L_3460_func(10, 28)
				L_3460_func(11, 70)
				do
					local L_3620_ = 3
					local L_3621_ = L_3462_func(9, L_3620_)
					local L_3622_ = L_1_(L_3459_func(8)(L_2_(L_3621_, 1, L_3621_.n)))
					for L_3623_forvar0 = 1, 1 do
						L_3460_func(8 + L_3623_forvar0 - 1, L_3622_[L_3623_forvar0])
					end
				end
				L_3459_func(7)["BgInput"] = L_3459_func(8)
				L_3460_func(8, L_10_func(L_3453_arg1, "Color3"))
				L_3460_func(8, L_3459_func(8)["fromRGB"])
				L_3460_func(9, 20)
				L_3460_func(10, 28)
				L_3460_func(11, 70)
				do
					local L_3624_ = 3
					local L_3625_ = L_3462_func(9, L_3624_)
					local L_3626_ = L_1_(L_3459_func(8)(L_2_(L_3625_, 1, L_3625_.n)))
					for L_3627_forvar0 = 1, 1 do
						L_3460_func(8 + L_3627_forvar0 - 1, L_3626_[L_3627_forvar0])
					end
				end
				L_3459_func(7)["BgTabBar"] = L_3459_func(8)
				L_3460_func(8, L_10_func(L_3453_arg1, "Color3"))
				L_3460_func(8, L_3459_func(8)["fromRGB"])
				L_3460_func(9, 85)
				L_3460_func(10, 213)
				L_3460_func(11, 254)
				do
					local L_3628_ = 3
					local L_3629_ = L_3462_func(9, L_3628_)
					local L_3630_ = L_1_(L_3459_func(8)(L_2_(L_3629_, 1, L_3629_.n)))
					for L_3631_forvar0 = 1, 1 do
						L_3460_func(8 + L_3631_forvar0 - 1, L_3630_[L_3631_forvar0])
					end
				end
				L_3459_func(7)["Accent"] = L_3459_func(8)
				L_3460_func(8, L_10_func(L_3453_arg1, "Color3"))
				L_3460_func(8, L_3459_func(8)["fromRGB"])
				L_3460_func(9, 135)
				L_3460_func(10, 235)
				L_3460_func(11, 255)
				do
					local L_3632_ = 3
					local L_3633_ = L_3462_func(9, L_3632_)
					local L_3634_ = L_1_(L_3459_func(8)(L_2_(L_3633_, 1, L_3633_.n)))
					for L_3635_forvar0 = 1, 1 do
						L_3460_func(8 + L_3635_forvar0 - 1, L_3634_[L_3635_forvar0])
					end
				end
				L_3459_func(7)["AccentBright"] = L_3459_func(8)
				L_3460_func(8, L_10_func(L_3453_arg1, "Color3"))
				L_3460_func(8, L_3459_func(8)["fromRGB"])
				L_3460_func(9, 50)
				L_3460_func(10, 170)
				L_3460_func(11, 220)
				do
					local L_3636_ = 3
					local L_3637_ = L_3462_func(9, L_3636_)
					local L_3638_ = L_1_(L_3459_func(8)(L_2_(L_3637_, 1, L_3637_.n)))
					for L_3639_forvar0 = 1, 1 do
						L_3460_func(8 + L_3639_forvar0 - 1, L_3638_[L_3639_forvar0])
					end
				end
				L_3459_func(7)["AccentDark"] = L_3459_func(8)
				L_3460_func(8, L_10_func(L_3453_arg1, "Color3"))
				L_3460_func(8, L_3459_func(8)["fromRGB"])
				L_3460_func(9, 30)
				L_3460_func(10, 90)
				L_3460_func(11, 130)
				do
					local L_3640_ = 3
					local L_3641_ = L_3462_func(9, L_3640_)
					local L_3642_ = L_1_(L_3459_func(8)(L_2_(L_3641_, 1, L_3641_.n)))
					for L_3643_forvar0 = 1, 1 do
						L_3460_func(8 + L_3643_forvar0 - 1, L_3642_[L_3643_forvar0])
					end
				end
				L_3459_func(7)["AccentDim"] = L_3459_func(8)
				L_3460_func(8, L_10_func(L_3453_arg1, "Color3"))
				L_3460_func(8, L_3459_func(8)["fromRGB"])
				L_3460_func(9, 180)
				L_3460_func(10, 240)
				L_3460_func(11, 255)
				do
					local L_3644_ = 3
					local L_3645_ = L_3462_func(9, L_3644_)
					local L_3646_ = L_1_(L_3459_func(8)(L_2_(L_3645_, 1, L_3645_.n)))
					for L_3647_forvar0 = 1, 1 do
						L_3460_func(8 + L_3647_forvar0 - 1, L_3646_[L_3647_forvar0])
					end
				end
				L_3459_func(7)["AccentGlow"] = L_3459_func(8)
				L_3460_func(8, L_10_func(L_3453_arg1, "Color3"))
				L_3460_func(8, L_3459_func(8)["fromRGB"])
				L_3460_func(9, 100)
				L_3460_func(10, 200)
				L_3460_func(11, 255)
				do
					local L_3648_ = 3
					local L_3649_ = L_3462_func(9, L_3648_)
					local L_3650_ = L_1_(L_3459_func(8)(L_2_(L_3649_, 1, L_3649_.n)))
					for L_3651_forvar0 = 1, 1 do
						L_3460_func(8 + L_3651_forvar0 - 1, L_3650_[L_3651_forvar0])
					end
				end
				L_3459_func(7)["AccentSoft"] = L_3459_func(8)
				L_3460_func(8, L_10_func(L_3453_arg1, "Color3"))
				L_3460_func(8, L_3459_func(8)["fromRGB"])
				L_3460_func(9, 255)
				L_3460_func(10, 200)
				L_3460_func(11, 50)
				do
					local L_3652_ = 3
					local L_3653_ = L_3462_func(9, L_3652_)
					local L_3654_ = L_1_(L_3459_func(8)(L_2_(L_3653_, 1, L_3653_.n)))
					for L_3655_forvar0 = 1, 1 do
						L_3460_func(8 + L_3655_forvar0 - 1, L_3654_[L_3655_forvar0])
					end
				end
				L_3459_func(7)["Premium"] = L_3459_func(8)
				L_3460_func(8, L_10_func(L_3453_arg1, "Color3"))
				L_3460_func(8, L_3459_func(8)["fromRGB"])
				L_3460_func(9, 180)
				L_3460_func(10, 130)
				L_3460_func(11, 20)
				do
					local L_3656_ = 3
					local L_3657_ = L_3462_func(9, L_3656_)
					local L_3658_ = L_1_(L_3459_func(8)(L_2_(L_3657_, 1, L_3657_.n)))
					for L_3659_forvar0 = 1, 1 do
						L_3460_func(8 + L_3659_forvar0 - 1, L_3658_[L_3659_forvar0])
					end
				end
				L_3463_ = 256
			else
				error("invalid recovered basic block in main: " .. tostring(L_3463_))
			end
		elseif L_3475_ == 1 then
			if L_3463_ == 256 then

				L_3459_func(7)["PremiumDark"] = L_3459_func(8)
				L_3460_func(8, L_10_func(L_3453_arg1, "Color3"))
				L_3460_func(8, L_3459_func(8)["fromRGB"])
				L_3460_func(9, 50)
				L_3460_func(10, 40)
				L_3460_func(11, 10)
				do
					local L_3660_ = 3
					local L_3661_ = L_3462_func(9, L_3660_)
					local L_3662_ = L_1_(L_3459_func(8)(L_2_(L_3661_, 1, L_3661_.n)))
					for L_3663_forvar0 = 1, 1 do
						L_3460_func(8 + L_3663_forvar0 - 1, L_3662_[L_3663_forvar0])
					end
				end
				L_3459_func(7)["PremiumDim"] = L_3459_func(8)
				L_3460_func(8, L_10_func(L_3453_arg1, "Color3"))
				L_3460_func(8, L_3459_func(8)["fromRGB"])
				L_3460_func(9, 15)
				L_3460_func(10, 45)
				L_3460_func(11, 100)
				do
					local L_3664_ = 3
					local L_3665_ = L_3462_func(9, L_3664_)
					local L_3666_ = L_1_(L_3459_func(8)(L_2_(L_3665_, 1, L_3665_.n)))
					for L_3667_forvar0 = 1, 1 do
						L_3460_func(8 + L_3667_forvar0 - 1, L_3666_[L_3667_forvar0])
					end
				end
				L_3459_func(7)["BannerBg"] = L_3459_func(8)
				L_3460_func(8, L_10_func(L_3453_arg1, "Color3"))
				L_3460_func(8, L_3459_func(8)["fromRGB"])
				L_3460_func(9, 25)
				L_3460_func(10, 70)
				L_3460_func(11, 150)
				do
					local L_3668_ = 3
					local L_3669_ = L_3462_func(9, L_3668_)
					local L_3670_ = L_1_(L_3459_func(8)(L_2_(L_3669_, 1, L_3669_.n)))
					for L_3671_forvar0 = 1, 1 do
						L_3460_func(8 + L_3671_forvar0 - 1, L_3670_[L_3671_forvar0])
					end
				end
				L_3459_func(7)["BannerActive"] = L_3459_func(8)
				L_3460_func(8, L_10_func(L_3453_arg1, "Color3"))
				L_3460_func(8, L_3459_func(8)["fromRGB"])
				L_3460_func(9, 230)
				L_3460_func(10, 245)
				L_3460_func(11, 255)
				do
					local L_3672_ = 3
					local L_3673_ = L_3462_func(9, L_3672_)
					local L_3674_ = L_1_(L_3459_func(8)(L_2_(L_3673_, 1, L_3673_.n)))
					for L_3675_forvar0 = 1, 1 do
						L_3460_func(8 + L_3675_forvar0 - 1, L_3674_[L_3675_forvar0])
					end
				end
				L_3459_func(7)["TextPrimary"] = L_3459_func(8)
				L_3460_func(8, L_10_func(L_3453_arg1, "Color3"))
				L_3460_func(8, L_3459_func(8)["fromRGB"])
				L_3460_func(9, 160)
				L_3460_func(10, 190)
				L_3460_func(11, 230)
				do
					local L_3676_ = 3
					local L_3677_ = L_3462_func(9, L_3676_)
					local L_3678_ = L_1_(L_3459_func(8)(L_2_(L_3677_, 1, L_3677_.n)))
					for L_3679_forvar0 = 1, 1 do
						L_3460_func(8 + L_3679_forvar0 - 1, L_3678_[L_3679_forvar0])
					end
				end
				L_3459_func(7)["TextSecondary"] = L_3459_func(8)
				L_3460_func(8, L_10_func(L_3453_arg1, "Color3"))
				L_3460_func(8, L_3459_func(8)["fromRGB"])
				L_3460_func(9, 80)
				L_3460_func(10, 110)
				L_3460_func(11, 160)
				do
					local L_3680_ = 3
					local L_3681_ = L_3462_func(9, L_3680_)
					local L_3682_ = L_1_(L_3459_func(8)(L_2_(L_3681_, 1, L_3681_.n)))
					for L_3683_forvar0 = 1, 1 do
						L_3460_func(8 + L_3683_forvar0 - 1, L_3682_[L_3683_forvar0])
					end
				end
				L_3459_func(7)["TextMuted"] = L_3459_func(8)
				L_3460_func(8, L_10_func(L_3453_arg1, "Color3"))
				L_3460_func(8, L_3459_func(8)["fromRGB"])
				L_3460_func(9, 50)
				L_3460_func(10, 70)
				L_3460_func(11, 110)
				do
					local L_3684_ = 3
					local L_3685_ = L_3462_func(9, L_3684_)
					local L_3686_ = L_1_(L_3459_func(8)(L_2_(L_3685_, 1, L_3685_.n)))
					for L_3687_forvar0 = 1, 1 do
						L_3460_func(8 + L_3687_forvar0 - 1, L_3686_[L_3687_forvar0])
					end
				end
				L_3459_func(7)["TextDim"] = L_3459_func(8)
				L_3460_func(8, L_10_func(L_3453_arg1, "Color3"))
				L_3460_func(8, L_3459_func(8)["fromRGB"])
				L_3460_func(9, 30)
				L_3460_func(10, 45)
				L_3460_func(11, 100)
				do
					local L_3688_ = 3
					local L_3689_ = L_3462_func(9, L_3688_)
					local L_3690_ = L_1_(L_3459_func(8)(L_2_(L_3689_, 1, L_3689_.n)))
					for L_3691_forvar0 = 1, 1 do
						L_3460_func(8 + L_3691_forvar0 - 1, L_3690_[L_3691_forvar0])
					end
				end
				L_3459_func(7)["Border"] = L_3459_func(8)
				L_3460_func(8, L_10_func(L_3453_arg1, "Color3"))
				L_3460_func(8, L_3459_func(8)["fromRGB"])
				L_3460_func(9, 60)
				L_3460_func(10, 100)
				L_3460_func(11, 220)
				do
					local L_3692_ = 3
					local L_3693_ = L_3462_func(9, L_3692_)
					local L_3694_ = L_1_(L_3459_func(8)(L_2_(L_3693_, 1, L_3693_.n)))
					for L_3695_forvar0 = 1, 1 do
						L_3460_func(8 + L_3695_forvar0 - 1, L_3694_[L_3695_forvar0])
					end
				end
				L_3459_func(7)["BorderHi"] = L_3459_func(8)
				L_3460_func(8, L_10_func(L_3453_arg1, "Color3"))
				L_3460_func(8, L_3459_func(8)["fromRGB"])
				L_3460_func(9, 50)
				L_3460_func(10, 220)
				L_3460_func(11, 120)
				do
					local L_3696_ = 3
					local L_3697_ = L_3462_func(9, L_3696_)
					local L_3698_ = L_1_(L_3459_func(8)(L_2_(L_3697_, 1, L_3697_.n)))
					for L_3699_forvar0 = 1, 1 do
						L_3460_func(8 + L_3699_forvar0 - 1, L_3698_[L_3699_forvar0])
					end
				end
				L_3459_func(7)["Success"] = L_3459_func(8)
				L_3460_func(8, L_10_func(L_3453_arg1, "Color3"))
				L_3460_func(8, L_3459_func(8)["fromRGB"])
				L_3460_func(9, 255)
				L_3460_func(10, 55)
				L_3460_func(11, 75)
				do
					local L_3700_ = 3
					local L_3701_ = L_3462_func(9, L_3700_)
					local L_3702_ = L_1_(L_3459_func(8)(L_2_(L_3701_, 1, L_3701_.n)))
					for L_3703_forvar0 = 1, 1 do
						L_3460_func(8 + L_3703_forvar0 - 1, L_3702_[L_3703_forvar0])
					end
				end
				L_3459_func(7)["Error"] = L_3459_func(8)
				L_3460_func(8, L_10_func(L_3453_arg1, "Color3"))
				L_3460_func(8, L_3459_func(8)["fromRGB"])
				L_3460_func(9, 255)
				L_3460_func(10, 180)
				L_3460_func(11, 50)
				do
					local L_3704_ = 3
					local L_3705_ = L_3462_func(9, L_3704_)
					local L_3706_ = L_1_(L_3459_func(8)(L_2_(L_3705_, 1, L_3705_.n)))
					for L_3707_forvar0 = 1, 1 do
						L_3460_func(8 + L_3707_forvar0 - 1, L_3706_[L_3707_forvar0])
					end
				end
				L_3459_func(7)["Warning"] = L_3459_func(8)
				L_3460_func(8, {})
				L_3460_func(9, {})
				L_3460_func(10, "BedWars")
				L_3459_func(9)["name"] = L_3459_func(10)
				L_3460_func(10, L_10_func(L_3453_arg1, "utf8"))
				L_3460_func(10, L_3459_func(10)["char"])
				L_3460_func(11, 128719)
				do
					local L_3708_ = 1
					local L_3709_ = L_3462_func(11, L_3708_)
					local L_3710_ = L_1_(L_3459_func(10)(L_2_(L_3709_, 1, L_3709_.n)))
					for L_3711_forvar0 = 1, 1 do
						L_3460_func(10 + L_3711_forvar0 - 1, L_3710_[L_3711_forvar0])
					end
				end
				L_3459_func(9)["icon"] = L_3459_func(10)
				L_3460_func(10, {})
				L_3460_func(11, "bedwars")
				L_3460_func(12, "bed wars")
				do
					local L_3712_ = 2
					local L_3713_ = L_3459_func(10)
					for L_3714_forvar0 = 0, L_3712_ - 1 do
						L_3713_[1 + L_3714_forvar0] = L_3459_func(11 + L_3714_forvar0)
					end
				end
				L_3459_func(9)["aliases"] = L_3459_func(10)
				L_3460_func(10, {})
				L_3460_func(11, 6872265039)
				L_3460_func(12, 6872274481)
				do
					local L_3715_ = 2
					local L_3716_ = L_3459_func(10)
					for L_3717_forvar0 = 0, L_3715_ - 1 do
						L_3716_[1 + L_3717_forvar0] = L_3459_func(11 + L_3717_forvar0)
					end
				end
				L_3459_func(9)["placeIds"] = L_3459_func(10)
				L_3460_func(10, 69)
				L_3459_func(9)["features"] = L_3459_func(10)
				L_3460_func(10, "rbxassetid://6034281798")
				L_3459_func(9)["img"] = L_3459_func(10)
				L_3460_func(10, {})
				L_3460_func(11, "BedWars")
				L_3459_func(10)["name"] = L_3459_func(11)
				L_3460_func(11, L_10_func(L_3453_arg1, "utf8"))
				L_3460_func(11, L_3459_func(11)["char"])
				L_3460_func(12, 128719)
				do
					local L_3718_ = 1
					local L_3719_ = L_3462_func(12, L_3718_)
					local L_3720_ = L_1_(L_3459_func(11)(L_2_(L_3719_, 1, L_3719_.n)))
					for L_3721_forvar0 = 1, 1 do
						L_3460_func(11 + L_3721_forvar0 - 1, L_3720_[L_3721_forvar0])
					end
				end
				L_3459_func(10)["icon"] = L_3459_func(11)
				L_3460_func(11, {})
				L_3460_func(12, "bedwars")
				L_3460_func(13, "bed wars")
				do
					local L_3722_ = 2
					local L_3723_ = L_3459_func(11)
					for L_3724_forvar0 = 0, L_3722_ - 1 do
						L_3723_[1 + L_3724_forvar0] = L_3459_func(12 + L_3724_forvar0)
					end
				end
				L_3459_func(10)["aliases"] = L_3459_func(11)
				L_3460_func(11, {})
				L_3460_func(12, 6872265039)
				L_3460_func(13, 6872274481)
				do
					local L_3725_ = 2
					local L_3726_ = L_3459_func(11)
					for L_3727_forvar0 = 0, L_3725_ - 1 do
						L_3726_[1 + L_3727_forvar0] = L_3459_func(12 + L_3727_forvar0)
					end
				end
				L_3459_func(10)["placeIds"] = L_3459_func(11)
				L_3460_func(11, 69)
				L_3459_func(10)["features"] = L_3459_func(11)
				L_3460_func(11, "rbxassetid://6034281798")
				L_3459_func(10)["img"] = L_3459_func(11)
				L_3460_func(11, {})
				L_3460_func(12, "Taxi Boss")
				L_3459_func(11)["name"] = L_3459_func(12)
				L_3460_func(12, L_10_func(L_3453_arg1, "utf8"))
				L_3460_func(12, L_3459_func(12)["char"])
				L_3460_func(13, 128661)
				do
					local L_3728_ = 1
					local L_3729_ = L_3462_func(13, L_3728_)
					local L_3730_ = L_1_(L_3459_func(12)(L_2_(L_3729_, 1, L_3729_.n)))
					for L_3731_forvar0 = 1, 1 do
						L_3460_func(12 + L_3731_forvar0 - 1, L_3730_[L_3731_forvar0])
					end
				end
				L_3459_func(11)["icon"] = L_3459_func(12)
				L_3460_func(12, {})
				L_3460_func(13, "taxi boss")
				L_3460_func(14, "taxiboss")
				L_3460_func(15, "taxi")
				do
					local L_3732_ = 3
					local L_3733_ = L_3459_func(12)
					for L_3734_forvar0 = 0, L_3732_ - 1 do
						L_3733_[1 + L_3734_forvar0] = L_3459_func(13 + L_3734_forvar0)
					end
				end
				L_3459_func(11)["aliases"] = L_3459_func(12)
				L_3460_func(12, {})
				L_3460_func(13, 7305309231)
				do
					local L_3735_ = 1
					local L_3736_ = L_3459_func(12)
					for L_3737_forvar0 = 0, L_3735_ - 1 do
						L_3736_[1 + L_3737_forvar0] = L_3459_func(13 + L_3737_forvar0)
					end
				end
				L_3459_func(11)["placeIds"] = L_3459_func(12)
				L_3460_func(12, 40)
				L_3459_func(11)["features"] = L_3459_func(12)
				L_3460_func(12, "rbxassetid://6034281798")
				L_3459_func(11)["img"] = L_3459_func(12)
				L_3460_func(12, {})
				L_3460_func(13, "BloxStrike")
				L_3459_func(12)["name"] = L_3459_func(13)
				L_3460_func(13, L_10_func(L_3453_arg1, "utf8"))
				L_3460_func(13, L_3459_func(13)["char"])
				L_3460_func(14, 127919)
				do
					local L_3738_ = 1
					local L_3739_ = L_3462_func(14, L_3738_)
					local L_3740_ = L_1_(L_3459_func(13)(L_2_(L_3739_, 1, L_3739_.n)))
					for L_3741_forvar0 = 1, 1 do
						L_3460_func(13 + L_3741_forvar0 - 1, L_3740_[L_3741_forvar0])
					end
				end
				L_3459_func(12)["icon"] = L_3459_func(13)
				L_3460_func(13, {})
				L_3460_func(14, "bloxstrike")
				L_3460_func(15, "blox strike")
				do
					local L_3742_ = 2
					local L_3743_ = L_3459_func(13)
					for L_3744_forvar0 = 0, L_3742_ - 1 do
						L_3743_[1 + L_3744_forvar0] = L_3459_func(14 + L_3744_forvar0)
					end
				end
				L_3459_func(12)["aliases"] = L_3459_func(13)
				L_3460_func(13, {})
				L_3460_func(14, 114234929420007)
				do
					local L_3745_ = 1
					local L_3746_ = L_3459_func(13)
					for L_3747_forvar0 = 0, L_3745_ - 1 do
						L_3746_[1 + L_3747_forvar0] = L_3459_func(14 + L_3747_forvar0)
					end
				end
				L_3459_func(12)["placeIds"] = L_3459_func(13)
				L_3460_func(13, 45)
				L_3459_func(12)["features"] = L_3459_func(13)
				L_3460_func(13, "rbxassetid://6034281798")
				L_3459_func(12)["img"] = L_3459_func(13)
				L_3460_func(13, {})
				L_3460_func(14, "Anime Expeditions")
				L_3459_func(13)["name"] = L_3459_func(14)
				L_3460_func(14, L_10_func(L_3453_arg1, "utf8"))
				L_3460_func(14, L_3459_func(14)["char"])
				L_3460_func(15, 9889)
				do
					local L_3748_ = 1
					local L_3749_ = L_3462_func(15, L_3748_)
					local L_3750_ = L_1_(L_3459_func(14)(L_2_(L_3749_, 1, L_3749_.n)))
					for L_3751_forvar0 = 1, 1 do
						L_3460_func(14 + L_3751_forvar0 - 1, L_3750_[L_3751_forvar0])
					end
				end
				L_3459_func(13)["icon"] = L_3459_func(14)
				L_3460_func(14, {})
				L_3460_func(15, "anime expeditions")
				L_3460_func(16, "expeditions")
				L_3460_func(17, "anime expedition")
				do
					local L_3752_ = 3
					local L_3753_ = L_3459_func(14)
					for L_3754_forvar0 = 0, L_3752_ - 1 do
						L_3753_[1 + L_3754_forvar0] = L_3459_func(15 + L_3754_forvar0)
					end
				end
				L_3459_func(13)["aliases"] = L_3459_func(14)
				L_3460_func(14, {})
				L_3460_func(15, 84515722934860)
				do
					local L_3755_ = 1
					local L_3756_ = L_3459_func(14)
					for L_3757_forvar0 = 0, L_3755_ - 1 do
						L_3756_[1 + L_3757_forvar0] = L_3459_func(15 + L_3757_forvar0)
					end
				end
				L_3459_func(13)["placeIds"] = L_3459_func(14)
				L_3460_func(14, 40)
				L_3459_func(13)["features"] = L_3459_func(14)
				L_3460_func(14, "rbxassetid://6034281798")
				L_3459_func(13)["img"] = L_3459_func(14)
				L_3460_func(14, {})
				L_3460_func(15, "+1 Pickaxe Swing Escape")
				L_3459_func(14)["name"] = L_3459_func(15)
				L_3460_func(15, L_10_func(L_3453_arg1, "utf8"))
				L_3460_func(15, L_3459_func(15)["char"])
				L_3460_func(16, 9935)
				do
					local L_3758_ = 1
					local L_3759_ = L_3462_func(16, L_3758_)
					local L_3760_ = L_1_(L_3459_func(15)(L_2_(L_3759_, 1, L_3759_.n)))
					for L_3761_forvar0 = 1, 1 do
						L_3460_func(15 + L_3761_forvar0 - 1, L_3760_[L_3761_forvar0])
					end
				end
				L_3459_func(14)["icon"] = L_3459_func(15)
				L_3460_func(15, {})
				L_3460_func(16, "+1 pickaxe swing escape")
				L_3460_func(17, "pickaxe swing escape")
				L_3460_func(18, "pickaxe escape")
				L_3460_func(19, "pickaxe swing")
				L_3460_func(20, "pickaxe")
				do
					local L_3762_ = 5
					local L_3763_ = L_3459_func(15)
					for L_3764_forvar0 = 0, L_3762_ - 1 do
						L_3763_[1 + L_3764_forvar0] = L_3459_func(16 + L_3764_forvar0)
					end
				end
				L_3459_func(14)["aliases"] = L_3459_func(15)
				L_3460_func(15, {})
				L_3460_func(16, 82554996468034)
				do
					local L_3765_ = 1
					local L_3766_ = L_3459_func(15)
					for L_3767_forvar0 = 0, L_3765_ - 1 do
						L_3766_[1 + L_3767_forvar0] = L_3459_func(16 + L_3767_forvar0)
					end
				end
				L_3459_func(14)["placeIds"] = L_3459_func(15)
				L_3460_func(15, 20)
				L_3459_func(14)["features"] = L_3459_func(15)
				L_3460_func(15, "rbxassetid://6034281798")
				L_3459_func(14)["img"] = L_3459_func(15)
				L_3460_func(15, {})
				L_3460_func(16, "Animal Hospital")
				L_3459_func(15)["name"] = L_3459_func(16)
				L_3460_func(16, L_10_func(L_3453_arg1, "utf8"))
				L_3460_func(16, L_3459_func(16)["char"])
				L_3460_func(17, 127973)
				do
					local L_3768_ = 1
					local L_3769_ = L_3462_func(17, L_3768_)
					local L_3770_ = L_1_(L_3459_func(16)(L_2_(L_3769_, 1, L_3769_.n)))
					for L_3771_forvar0 = 1, 1 do
						L_3460_func(16 + L_3771_forvar0 - 1, L_3770_[L_3771_forvar0])
					end
				end
				L_3463_ = 512
			else
				error("invalid recovered basic block in main: " .. tostring(L_3463_))
			end
		elseif L_3475_ == 2 then
			if L_3463_ == 512 then

				L_3459_func(15)["icon"] = L_3459_func(16)
				L_3460_func(16, {})
				L_3460_func(17, "animal hospital")
				L_3460_func(18, "anomaly hospital")
				L_3460_func(19, "hospital")
				do
					local L_3772_ = 3
					local L_3773_ = L_3459_func(16)
					for L_3774_forvar0 = 0, L_3772_ - 1 do
						L_3773_[1 + L_3774_forvar0] = L_3459_func(17 + L_3774_forvar0)
					end
				end
				L_3459_func(15)["aliases"] = L_3459_func(16)
				L_3460_func(16, {})
				L_3460_func(17, 78515283254292)
				do
					local L_3775_ = 1
					local L_3776_ = L_3459_func(16)
					for L_3777_forvar0 = 0, L_3775_ - 1 do
						L_3776_[1 + L_3777_forvar0] = L_3459_func(17 + L_3777_forvar0)
					end
				end
				L_3459_func(15)["placeIds"] = L_3459_func(16)
				L_3460_func(16, 15)
				L_3459_func(15)["features"] = L_3459_func(16)
				L_3460_func(16, "rbxassetid://6034281798")
				L_3459_func(15)["img"] = L_3459_func(16)
				L_3460_func(16, {})
				L_3460_func(17, "Merge a Nuke")
				L_3459_func(16)["name"] = L_3459_func(17)
				L_3460_func(17, L_10_func(L_3453_arg1, "utf8"))
				L_3460_func(17, L_3459_func(17)["char"])
				L_3460_func(18, 128163)
				do
					local L_3778_ = 1
					local L_3779_ = L_3462_func(18, L_3778_)
					local L_3780_ = L_1_(L_3459_func(17)(L_2_(L_3779_, 1, L_3779_.n)))
					for L_3781_forvar0 = 1, 1 do
						L_3460_func(17 + L_3781_forvar0 - 1, L_3780_[L_3781_forvar0])
					end
				end
				L_3459_func(16)["icon"] = L_3459_func(17)
				L_3460_func(17, {})
				L_3460_func(18, "merge a nuke")
				L_3460_func(19, "merge a nuke!")
				L_3460_func(20, "nuke tycoon")
				L_3460_func(21, "merge nuke")
				do
					local L_3782_ = 4
					local L_3783_ = L_3459_func(17)
					for L_3784_forvar0 = 0, L_3782_ - 1 do
						L_3783_[1 + L_3784_forvar0] = L_3459_func(18 + L_3784_forvar0)
					end
				end
				L_3459_func(16)["aliases"] = L_3459_func(17)
				L_3460_func(17, {})
				L_3460_func(18, 128784467030899)
				L_3460_func(19, 136423403372990)
				do
					local L_3785_ = 2
					local L_3786_ = L_3459_func(17)
					for L_3787_forvar0 = 0, L_3785_ - 1 do
						L_3786_[1 + L_3787_forvar0] = L_3459_func(18 + L_3787_forvar0)
					end
				end
				L_3459_func(16)["placeIds"] = L_3459_func(17)
				L_3460_func(17, 15)
				L_3459_func(16)["features"] = L_3459_func(17)
				L_3460_func(17, "rbxassetid://6034281798")
				L_3459_func(16)["img"] = L_3459_func(17)
				L_3460_func(17, {})
				L_3460_func(18, "Arsenal")
				L_3459_func(17)["name"] = L_3459_func(18)
				L_3460_func(18, L_10_func(L_3453_arg1, "utf8"))
				L_3460_func(18, L_3459_func(18)["char"])
				L_3460_func(19, 127919)
				do
					local L_3788_ = 1
					local L_3789_ = L_3462_func(19, L_3788_)
					local L_3790_ = L_1_(L_3459_func(18)(L_2_(L_3789_, 1, L_3789_.n)))
					for L_3791_forvar0 = 1, 1 do
						L_3460_func(18 + L_3791_forvar0 - 1, L_3790_[L_3791_forvar0])
					end
				end
				L_3459_func(17)["icon"] = L_3459_func(18)
				L_3460_func(18, {})
				L_3460_func(19, 286090429)
				L_3460_func(20, 2133507413)
				do
					local L_3792_ = 2
					local L_3793_ = L_3459_func(18)
					for L_3794_forvar0 = 0, L_3792_ - 1 do
						L_3793_[1 + L_3794_forvar0] = L_3459_func(19 + L_3794_forvar0)
					end
				end
				L_3459_func(17)["placeIds"] = L_3459_func(18)
				L_3460_func(18, 20)
				L_3459_func(17)["features"] = L_3459_func(18)
				L_3460_func(18, "rbxassetid://6034281798")
				L_3459_func(17)["img"] = L_3459_func(18)
				L_3460_func(18, {})
				L_3460_func(19, "Jujutsu Shenanigans")
				L_3459_func(18)["name"] = L_3459_func(19)
				L_3460_func(19, L_10_func(L_3453_arg1, "utf8"))
				L_3460_func(19, L_3459_func(19)["char"])
				L_3460_func(20, 9889)
				do
					local L_3795_ = 1
					local L_3796_ = L_3462_func(20, L_3795_)
					local L_3797_ = L_1_(L_3459_func(19)(L_2_(L_3796_, 1, L_3796_.n)))
					for L_3798_forvar0 = 1, 1 do
						L_3460_func(19 + L_3798_forvar0 - 1, L_3797_[L_3798_forvar0])
					end
				end
				L_3459_func(18)["icon"] = L_3459_func(19)
				L_3460_func(19, {})
				L_3460_func(20, "jujutsu shenanigans")
				L_3460_func(21, "jujutsu")
				L_3460_func(22, "shenanigans")
				do
					local L_3799_ = 3
					local L_3800_ = L_3459_func(19)
					for L_3801_forvar0 = 0, L_3799_ - 1 do
						L_3800_[1 + L_3801_forvar0] = L_3459_func(20 + L_3801_forvar0)
					end
				end
				L_3459_func(18)["aliases"] = L_3459_func(19)
				L_3460_func(19, {})
				L_3460_func(20, 9391468976)
				do
					local L_3802_ = 1
					local L_3803_ = L_3459_func(19)
					for L_3804_forvar0 = 0, L_3802_ - 1 do
						L_3803_[1 + L_3804_forvar0] = L_3459_func(20 + L_3804_forvar0)
					end
				end
				L_3459_func(18)["placeIds"] = L_3459_func(19)
				L_3460_func(19, {})
				L_3460_func(20, 3508322461)
				do
					local L_3805_ = 1
					local L_3806_ = L_3459_func(19)
					for L_3807_forvar0 = 0, L_3805_ - 1 do
						L_3806_[1 + L_3807_forvar0] = L_3459_func(20 + L_3807_forvar0)
					end
				end
				L_3459_func(18)["universeIds"] = L_3459_func(19)
				L_3460_func(19, 15)
				L_3459_func(18)["features"] = L_3459_func(19)
				L_3460_func(19, "rbxassetid://6034281798")
				L_3459_func(18)["img"] = L_3459_func(19)
				L_3460_func(19, {})
				L_3460_func(20, "Abyss")
				L_3459_func(19)["name"] = L_3459_func(20)
				L_3460_func(20, L_10_func(L_3453_arg1, "utf8"))
				L_3460_func(20, L_3459_func(20)["char"])
				L_3460_func(21, 127754)
				do
					local L_3808_ = 1
					local L_3809_ = L_3462_func(21, L_3808_)
					local L_3810_ = L_1_(L_3459_func(20)(L_2_(L_3809_, 1, L_3809_.n)))
					for L_3811_forvar0 = 1, 1 do
						L_3460_func(20 + L_3811_forvar0 - 1, L_3810_[L_3811_forvar0])
					end
				end
				L_3459_func(19)["icon"] = L_3459_func(20)
				L_3460_func(20, {})
				L_3460_func(21, 8841631016)
				L_3460_func(22, 6499213745)
				do
					local L_3812_ = 2
					local L_3813_ = L_3459_func(20)
					for L_3814_forvar0 = 0, L_3812_ - 1 do
						L_3813_[1 + L_3814_forvar0] = L_3459_func(21 + L_3814_forvar0)
					end
				end
				L_3459_func(19)["placeIds"] = L_3459_func(20)
				L_3460_func(20, 22)
				L_3459_func(19)["features"] = L_3459_func(20)
				L_3460_func(20, "rbxassetid://6034281798")
				L_3459_func(19)["img"] = L_3459_func(20)
				L_3460_func(20, {})
				L_3460_func(21, "Jailbreak")
				L_3459_func(20)["name"] = L_3459_func(21)
				L_3460_func(21, L_10_func(L_3453_arg1, "utf8"))
				L_3460_func(21, L_3459_func(21)["char"])
				L_3460_func(22, 128680)
				do
					local L_3815_ = 1
					local L_3816_ = L_3462_func(22, L_3815_)
					local L_3817_ = L_1_(L_3459_func(21)(L_2_(L_3816_, 1, L_3816_.n)))
					for L_3818_forvar0 = 1, 1 do
						L_3460_func(21 + L_3818_forvar0 - 1, L_3817_[L_3818_forvar0])
					end
				end
				L_3459_func(20)["icon"] = L_3459_func(21)
				L_3460_func(21, {})
				L_3460_func(22, 606849621)
				do
					local L_3819_ = 1
					local L_3820_ = L_3459_func(21)
					for L_3821_forvar0 = 0, L_3819_ - 1 do
						L_3820_[1 + L_3821_forvar0] = L_3459_func(22 + L_3821_forvar0)
					end
				end
				L_3459_func(20)["placeIds"] = L_3459_func(21)
				L_3460_func(21, 50)
				L_3459_func(20)["features"] = L_3459_func(21)
				L_3460_func(21, "rbxassetid://6034281798")
				L_3459_func(20)["img"] = L_3459_func(21)
				L_3460_func(21, {})
				L_3460_func(22, "Tsunami")
				L_3459_func(21)["name"] = L_3459_func(22)
				L_3460_func(22, L_10_func(L_3453_arg1, "utf8"))
				L_3460_func(22, L_3459_func(22)["char"])
				L_3460_func(23, 127754)
				do
					local L_3822_ = 1
					local L_3823_ = L_3462_func(23, L_3822_)
					local L_3824_ = L_1_(L_3459_func(22)(L_2_(L_3823_, 1, L_3823_.n)))
					for L_3825_forvar0 = 1, 1 do
						L_3460_func(22 + L_3825_forvar0 - 1, L_3824_[L_3825_forvar0])
					end
				end
				L_3459_func(21)["icon"] = L_3459_func(22)
				L_3460_func(22, {})
				L_3460_func(23, 2456517837)
				L_3460_func(24, 7456917583)
				do
					local L_3826_ = 2
					local L_3827_ = L_3459_func(22)
					for L_3828_forvar0 = 0, L_3826_ - 1 do
						L_3827_[1 + L_3828_forvar0] = L_3459_func(23 + L_3828_forvar0)
					end
				end
				L_3459_func(21)["placeIds"] = L_3459_func(22)
				L_3460_func(22, 30)
				L_3459_func(21)["features"] = L_3459_func(22)
				L_3460_func(22, "rbxassetid://6034281798")
				L_3459_func(21)["img"] = L_3459_func(22)
				L_3460_func(22, {})
				L_3460_func(23, "Sniper Duels")
				L_3459_func(22)["name"] = L_3459_func(23)
				L_3460_func(23, L_10_func(L_3453_arg1, "utf8"))
				L_3460_func(23, L_3459_func(23)["char"])
				L_3460_func(24, 127919)
				do
					local L_3829_ = 1
					local L_3830_ = L_3462_func(24, L_3829_)
					local L_3831_ = L_1_(L_3459_func(23)(L_2_(L_3830_, 1, L_3830_.n)))
					for L_3832_forvar0 = 1, 1 do
						L_3460_func(23 + L_3832_forvar0 - 1, L_3831_[L_3832_forvar0])
					end
				end
				L_3459_func(22)["icon"] = L_3459_func(23)
				L_3460_func(23, {})
				L_3460_func(24, 2957674229)
				L_3460_func(25, 3519873232)
				L_3460_func(26, 109397169461300)
				do
					local L_3833_ = 3
					local L_3834_ = L_3459_func(23)
					for L_3835_forvar0 = 0, L_3833_ - 1 do
						L_3834_[1 + L_3835_forvar0] = L_3459_func(24 + L_3835_forvar0)
					end
				end
				L_3459_func(22)["placeIds"] = L_3459_func(23)
				L_3460_func(23, 12)
				L_3459_func(22)["features"] = L_3459_func(23)
				L_3460_func(23, "rbxassetid://6034281798")
				L_3459_func(22)["img"] = L_3459_func(23)
				L_3460_func(23, {})
				L_3460_func(24, "Swing Obby")
				L_3459_func(23)["name"] = L_3459_func(24)
				L_3460_func(24, L_10_func(L_3453_arg1, "utf8"))
				L_3460_func(24, L_3459_func(24)["char"])
				L_3460_func(25, 127906)
				do
					local L_3836_ = 1
					local L_3837_ = L_3462_func(25, L_3836_)
					local L_3838_ = L_1_(L_3459_func(24)(L_2_(L_3837_, 1, L_3837_.n)))
					for L_3839_forvar0 = 1, 1 do
						L_3460_func(24 + L_3839_forvar0 - 1, L_3838_[L_3839_forvar0])
					end
				end
				L_3459_func(23)["icon"] = L_3459_func(24)
				L_3460_func(24, {})
				L_3460_func(25, 5334680521)
				do
					local L_3840_ = 1
					local L_3841_ = L_3459_func(24)
					for L_3842_forvar0 = 0, L_3840_ - 1 do
						L_3841_[1 + L_3842_forvar0] = L_3459_func(25 + L_3842_forvar0)
					end
				end
				L_3459_func(23)["placeIds"] = L_3459_func(24)
				L_3460_func(24, 10)
				L_3459_func(23)["features"] = L_3459_func(24)
				L_3460_func(24, "rbxassetid://6034281798")
				L_3459_func(23)["img"] = L_3459_func(24)
				L_3460_func(24, {})
				L_3460_func(25, "Brookhaven")
				L_3459_func(24)["name"] = L_3459_func(25)
				L_3460_func(25, L_10_func(L_3453_arg1, "utf8"))
				L_3460_func(25, L_3459_func(25)["char"])
				L_3460_func(26, 127968)
				do
					local L_3843_ = 1
					local L_3844_ = L_3462_func(26, L_3843_)
					local L_3845_ = L_1_(L_3459_func(25)(L_2_(L_3844_, 1, L_3844_.n)))
					for L_3846_forvar0 = 1, 1 do
						L_3460_func(25 + L_3846_forvar0 - 1, L_3845_[L_3846_forvar0])
					end
				end
				L_3459_func(24)["icon"] = L_3459_func(25)
				L_3460_func(25, {})
				L_3460_func(26, 4924922222)
				do
					local L_3847_ = 1
					local L_3848_ = L_3459_func(25)
					for L_3849_forvar0 = 0, L_3847_ - 1 do
						L_3848_[1 + L_3849_forvar0] = L_3459_func(26 + L_3849_forvar0)
					end
				end
				L_3459_func(24)["placeIds"] = L_3459_func(25)
				L_3460_func(25, 15)
				L_3459_func(24)["features"] = L_3459_func(25)
				L_3460_func(25, "rbxassetid://6034281798")
				L_3459_func(24)["img"] = L_3459_func(25)
				do
					local L_3850_ = 16
					local L_3851_ = L_3459_func(8)
					for L_3852_forvar0 = 0, L_3850_ - 1 do
						L_3851_[1 + L_3852_forvar0] = L_3459_func(9 + L_3852_forvar0)
					end
				end
				L_3460_func(9, {})
				L_3460_func(10, "99 Nights")
				L_3459_func(9)["name"] = L_3459_func(10)
				L_3460_func(10, L_10_func(L_3453_arg1, "utf8"))
				L_3460_func(10, L_3459_func(10)["char"])
				L_3460_func(11, 127769)
				do
					local L_3853_ = 1
					local L_3854_ = L_3462_func(11, L_3853_)
					local L_3855_ = L_1_(L_3459_func(10)(L_2_(L_3854_, 1, L_3854_.n)))
					for L_3856_forvar0 = 1, 1 do
						L_3460_func(10 + L_3856_forvar0 - 1, L_3855_[L_3856_forvar0])
					end
				end
				L_3459_func(9)["icon"] = L_3459_func(10)
				L_3460_func(10, {})
				L_3460_func(11, 13271790403)
				L_3460_func(12, 14502339080)
				do
					local L_3857_ = 2
					local L_3858_ = L_3459_func(10)
					for L_3859_forvar0 = 0, L_3857_ - 1 do
						L_3858_[1 + L_3859_forvar0] = L_3459_func(11 + L_3859_forvar0)
					end
				end
				L_3459_func(9)["placeIds"] = L_3459_func(10)
				L_3460_func(10, 28)
				L_3459_func(9)["features"] = L_3459_func(10)
				L_3460_func(10, "rbxassetid://6034281798")
				L_3459_func(9)["img"] = L_3459_func(10)
				L_3460_func(10, {})
				L_3460_func(11, "Blox Fruits")
				L_3459_func(10)["name"] = L_3459_func(11)
				L_3460_func(11, L_10_func(L_3453_arg1, "utf8"))
				L_3460_func(11, L_3459_func(11)["char"])
				L_3460_func(12, 127822)
				do
					local L_3860_ = 1
					local L_3861_ = L_3462_func(12, L_3860_)
					local L_3862_ = L_1_(L_3459_func(11)(L_2_(L_3861_, 1, L_3861_.n)))
					for L_3863_forvar0 = 1, 1 do
						L_3460_func(11 + L_3863_forvar0 - 1, L_3862_[L_3863_forvar0])
					end
				end
				L_3459_func(10)["icon"] = L_3459_func(11)
				L_3460_func(11, {})
				L_3460_func(12, "blox fruits")
				L_3460_func(13, "blox fruit")
				L_3460_func(14, "bloxfruits")
				do
					local L_3864_ = 3
					local L_3865_ = L_3459_func(11)
					for L_3866_forvar0 = 0, L_3864_ - 1 do
						L_3865_[1 + L_3866_forvar0] = L_3459_func(12 + L_3866_forvar0)
					end
				end
				L_3459_func(10)["aliases"] = L_3459_func(11)
				L_3460_func(11, {})
				L_3460_func(12, 2753915549)
				L_3460_func(13, 4442272183)
				L_3460_func(14, 7449423635)
				do
					local L_3867_ = 3
					local L_3868_ = L_3459_func(11)
					for L_3869_forvar0 = 0, L_3867_ - 1 do
						L_3868_[1 + L_3869_forvar0] = L_3459_func(12 + L_3869_forvar0)
					end
				end
				L_3459_func(10)["placeIds"] = L_3459_func(11)
				L_3460_func(11, 18)
				L_3459_func(10)["features"] = L_3459_func(11)
				L_3460_func(11, "rbxassetid://6034281798")
				L_3459_func(10)["img"] = L_3459_func(11)
				L_3460_func(11, {})
				L_3460_func(12, "Pet Sim 99")
				L_3459_func(11)["name"] = L_3459_func(12)
				L_3460_func(12, L_10_func(L_3453_arg1, "utf8"))
				L_3460_func(12, L_3459_func(12)["char"])
				L_3460_func(13, 128062)
				do
					local L_3870_ = 1
					local L_3871_ = L_3462_func(13, L_3870_)
					local L_3872_ = L_1_(L_3459_func(12)(L_2_(L_3871_, 1, L_3871_.n)))
					for L_3873_forvar0 = 1, 1 do
						L_3460_func(12 + L_3873_forvar0 - 1, L_3872_[L_3873_forvar0])
					end
				end
				L_3459_func(11)["icon"] = L_3459_func(12)
				L_3460_func(12, {})
				L_3460_func(13, "pet simulator 99")
				L_3463_ = 768
			else
				error("invalid recovered basic block in main: " .. tostring(L_3463_))
			end
		elseif L_3475_ == 3 then
			if L_3463_ == 768 then

				L_3460_func(14, "pet sim 99")
				L_3460_func(15, "petsim99")
				do
					local L_3874_ = 3
					local L_3875_ = L_3459_func(12)
					for L_3876_forvar0 = 0, L_3874_ - 1 do
						L_3875_[1 + L_3876_forvar0] = L_3459_func(13 + L_3876_forvar0)
					end
				end
				L_3459_func(11)["aliases"] = L_3459_func(12)
				L_3460_func(12, {})
				L_3460_func(13, 8737899170)
				L_3460_func(14, 15532244896)
				L_3460_func(15, 15588347101)
				do
					local L_3877_ = 3
					local L_3878_ = L_3459_func(12)
					for L_3879_forvar0 = 0, L_3877_ - 1 do
						L_3878_[1 + L_3879_forvar0] = L_3459_func(13 + L_3879_forvar0)
					end
				end
				L_3459_func(11)["placeIds"] = L_3459_func(12)
				L_3460_func(12, {})
				L_3460_func(13, 3317771874)
				do
					local L_3880_ = 1
					local L_3881_ = L_3459_func(12)
					for L_3882_forvar0 = 0, L_3880_ - 1 do
						L_3881_[1 + L_3882_forvar0] = L_3459_func(13 + L_3882_forvar0)
					end
				end
				L_3459_func(11)["universeIds"] = L_3459_func(12)
				L_3460_func(12, 15)
				L_3459_func(11)["features"] = L_3459_func(12)
				L_3460_func(12, "rbxassetid://6034281798")
				L_3459_func(11)["img"] = L_3459_func(12)
				L_3460_func(12, {})
				L_3460_func(13, "Bee Swarm")
				L_3459_func(12)["name"] = L_3459_func(13)
				L_3460_func(13, L_10_func(L_3453_arg1, "utf8"))
				L_3460_func(13, L_3459_func(13)["char"])
				L_3460_func(14, 128029)
				do
					local L_3883_ = 1
					local L_3884_ = L_3462_func(14, L_3883_)
					local L_3885_ = L_1_(L_3459_func(13)(L_2_(L_3884_, 1, L_3884_.n)))
					for L_3886_forvar0 = 1, 1 do
						L_3460_func(13 + L_3886_forvar0 - 1, L_3885_[L_3886_forvar0])
					end
				end
				L_3459_func(12)["icon"] = L_3459_func(13)
				L_3460_func(13, {})
				L_3460_func(14, 1537690962)
				do
					local L_3887_ = 1
					local L_3888_ = L_3459_func(13)
					for L_3889_forvar0 = 0, L_3887_ - 1 do
						L_3888_[1 + L_3889_forvar0] = L_3459_func(14 + L_3889_forvar0)
					end
				end
				L_3459_func(12)["placeIds"] = L_3459_func(13)
				L_3460_func(13, 12)
				L_3459_func(12)["features"] = L_3459_func(13)
				L_3460_func(13, "rbxassetid://6034281798")
				L_3459_func(12)["img"] = L_3459_func(13)
				L_3460_func(13, {})
				L_3460_func(14, "SAB")
				L_3459_func(13)["name"] = L_3459_func(14)
				L_3460_func(14, L_10_func(L_3453_arg1, "utf8"))
				L_3460_func(14, L_3459_func(14)["char"])
				L_3460_func(15, 129302)
				do
					local L_3890_ = 1
					local L_3891_ = L_3462_func(15, L_3890_)
					local L_3892_ = L_1_(L_3459_func(14)(L_2_(L_3891_, 1, L_3891_.n)))
					for L_3893_forvar0 = 1, 1 do
						L_3460_func(14 + L_3893_forvar0 - 1, L_3892_[L_3893_forvar0])
					end
				end
				L_3459_func(13)["icon"] = L_3459_func(14)
				L_3460_func(14, {})
				L_3460_func(15, "steal a brainrot")
				L_3460_func(16, "sab")
				do
					local L_3894_ = 2
					local L_3895_ = L_3459_func(14)
					for L_3896_forvar0 = 0, L_3894_ - 1 do
						L_3895_[1 + L_3896_forvar0] = L_3459_func(15 + L_3896_forvar0)
					end
				end
				L_3459_func(13)["aliases"] = L_3459_func(14)
				L_3460_func(14, {})
				L_3460_func(15, 18668065096)
				L_3460_func(16, 1234567890)
				L_3460_func(17, 10495922230)
				L_3460_func(18, 109983668079237)
				do
					local L_3897_ = 4
					local L_3898_ = L_3459_func(14)
					for L_3899_forvar0 = 0, L_3897_ - 1 do
						L_3898_[1 + L_3899_forvar0] = L_3459_func(15 + L_3899_forvar0)
					end
				end
				L_3459_func(13)["placeIds"] = L_3459_func(14)
				L_3460_func(14, {})
				L_3460_func(15, 109983668079237)
				do
					local L_3900_ = 1
					local L_3901_ = L_3459_func(14)
					for L_3902_forvar0 = 0, L_3900_ - 1 do
						L_3901_[1 + L_3902_forvar0] = L_3459_func(15 + L_3902_forvar0)
					end
				end
				L_3459_func(13)["universeIds"] = L_3459_func(14)
				L_3460_func(14, 24)
				L_3459_func(13)["features"] = L_3459_func(14)
				L_3460_func(14, "rbxassetid://6034281798")
				L_3459_func(13)["img"] = L_3459_func(14)
				L_3460_func(14, {})
				L_3460_func(15, "Ultimate Battlegrounds")
				L_3459_func(14)["name"] = L_3459_func(15)
				L_3460_func(15, L_10_func(L_3453_arg1, "utf8"))
				L_3460_func(15, L_3459_func(15)["char"])
				L_3460_func(16, 128298)
				do
					local L_3903_ = 1
					local L_3904_ = L_3462_func(16, L_3903_)
					local L_3905_ = L_1_(L_3459_func(15)(L_2_(L_3904_, 1, L_3904_.n)))
					for L_3906_forvar0 = 1, 1 do
						L_3460_func(15 + L_3906_forvar0 - 1, L_3905_[L_3906_forvar0])
					end
				end
				L_3459_func(14)["icon"] = L_3459_func(15)
				L_3460_func(15, {})
				L_3460_func(16, 11815767793)
				do
					local L_3907_ = 1
					local L_3908_ = L_3459_func(15)
					for L_3909_forvar0 = 0, L_3907_ - 1 do
						L_3908_[1 + L_3909_forvar0] = L_3459_func(16 + L_3909_forvar0)
					end
				end
				L_3459_func(14)["placeIds"] = L_3459_func(15)
				L_3460_func(15, 18)
				L_3459_func(14)["features"] = L_3459_func(15)
				L_3460_func(15, "rbxassetid://6034281798")
				L_3459_func(14)["img"] = L_3459_func(15)
				L_3460_func(15, {})
				L_3460_func(16, "Strongest Battlegrounds")
				L_3459_func(15)["name"] = L_3459_func(16)
				L_3460_func(16, L_10_func(L_3453_arg1, "utf8"))
				L_3460_func(16, L_3459_func(16)["char"])
				L_3460_func(17, 128293)
				do
					local L_3910_ = 1
					local L_3911_ = L_3462_func(17, L_3910_)
					local L_3912_ = L_1_(L_3459_func(16)(L_2_(L_3911_, 1, L_3911_.n)))
					for L_3913_forvar0 = 1, 1 do
						L_3460_func(16 + L_3913_forvar0 - 1, L_3912_[L_3913_forvar0])
					end
				end
				L_3459_func(15)["icon"] = L_3459_func(16)
				L_3460_func(16, {})
				L_3460_func(17, 10495922230)
				do
					local L_3914_ = 1
					local L_3915_ = L_3459_func(16)
					for L_3916_forvar0 = 0, L_3914_ - 1 do
						L_3915_[1 + L_3916_forvar0] = L_3459_func(17 + L_3916_forvar0)
					end
				end
				L_3459_func(15)["placeIds"] = L_3459_func(16)
				L_3460_func(16, 15)
				L_3459_func(15)["features"] = L_3459_func(16)
				L_3460_func(16, "rbxassetid://6034281798")
				L_3459_func(15)["img"] = L_3459_func(16)
				L_3460_func(16, {})
				L_3460_func(17, "Heroes Battlegrounds")
				L_3459_func(16)["name"] = L_3459_func(17)
				L_3460_func(17, L_10_func(L_3453_arg1, "utf8"))
				L_3460_func(17, L_3459_func(17)["char"])
				L_3460_func(18, 129464)
				do
					local L_3917_ = 1
					local L_3918_ = L_3462_func(18, L_3917_)
					local L_3919_ = L_1_(L_3459_func(17)(L_2_(L_3918_, 1, L_3918_.n)))
					for L_3920_forvar0 = 1, 1 do
						L_3460_func(17 + L_3920_forvar0 - 1, L_3919_[L_3920_forvar0])
					end
				end
				L_3459_func(16)["icon"] = L_3459_func(17)
				L_3460_func(17, {})
				L_3460_func(18, 13076380114)
				do
					local L_3921_ = 1
					local L_3922_ = L_3459_func(17)
					for L_3923_forvar0 = 0, L_3921_ - 1 do
						L_3922_[1 + L_3923_forvar0] = L_3459_func(18 + L_3923_forvar0)
					end
				end
				L_3459_func(16)["placeIds"] = L_3459_func(17)
				L_3460_func(17, 16)
				L_3459_func(16)["features"] = L_3459_func(17)
				L_3460_func(17, "rbxassetid://6034281798")
				L_3459_func(16)["img"] = L_3459_func(17)
				L_3460_func(17, {})
				L_3460_func(18, "Legend Battlegrounds")
				L_3459_func(17)["name"] = L_3459_func(18)
				L_3460_func(18, L_10_func(L_3453_arg1, "utf8"))
				L_3460_func(18, L_3459_func(18)["char"])
				L_3460_func(19, 128481)
				do
					local L_3924_ = 1
					local L_3925_ = L_3462_func(19, L_3924_)
					local L_3926_ = L_1_(L_3459_func(18)(L_2_(L_3925_, 1, L_3925_.n)))
					for L_3927_forvar0 = 1, 1 do
						L_3460_func(18 + L_3927_forvar0 - 1, L_3926_[L_3927_forvar0])
					end
				end
				L_3459_func(17)["icon"] = L_3459_func(18)
				L_3460_func(18, {})
				L_3460_func(19, 15269951959)
				do
					local L_3928_ = 1
					local L_3929_ = L_3459_func(18)
					for L_3930_forvar0 = 0, L_3928_ - 1 do
						L_3929_[1 + L_3930_forvar0] = L_3459_func(19 + L_3930_forvar0)
					end
				end
				L_3459_func(17)["placeIds"] = L_3459_func(18)
				L_3460_func(18, 18)
				L_3459_func(17)["features"] = L_3459_func(18)
				L_3460_func(18, "rbxassetid://6034281798")
				L_3459_func(17)["img"] = L_3459_func(18)
				L_3460_func(18, {})
				L_3460_func(19, "Jump for Brainrots")
				L_3459_func(18)["name"] = L_3459_func(19)
				L_3460_func(19, L_10_func(L_3453_arg1, "utf8"))
				L_3460_func(19, L_3459_func(19)["char"])
				L_3460_func(20, 129504)
				do
					local L_3931_ = 1
					local L_3932_ = L_3462_func(20, L_3931_)
					local L_3933_ = L_1_(L_3459_func(19)(L_2_(L_3932_, 1, L_3932_.n)))
					for L_3934_forvar0 = 1, 1 do
						L_3460_func(19 + L_3934_forvar0 - 1, L_3933_[L_3934_forvar0])
					end
				end
				L_3459_func(18)["icon"] = L_3459_func(19)
				L_3460_func(19, {})
				L_3460_func(20, 139299356663913)
				do
					local L_3935_ = 1
					local L_3936_ = L_3459_func(19)
					for L_3937_forvar0 = 0, L_3935_ - 1 do
						L_3936_[1 + L_3937_forvar0] = L_3459_func(20 + L_3937_forvar0)
					end
				end
				L_3459_func(18)["placeIds"] = L_3459_func(19)
				L_3460_func(19, 12)
				L_3459_func(18)["features"] = L_3459_func(19)
				L_3460_func(19, "rbxassetid://6034281798")
				L_3459_func(18)["img"] = L_3459_func(19)
				L_3460_func(19, {})
				L_3460_func(20, "+1 Jump Brainrot")
				L_3459_func(19)["name"] = L_3459_func(20)
				L_3460_func(20, L_10_func(L_3453_arg1, "utf8"))
				L_3460_func(20, L_3459_func(20)["char"])
				L_3460_func(21, 128095)
				do
					local L_3938_ = 1
					local L_3939_ = L_3462_func(21, L_3938_)
					local L_3940_ = L_1_(L_3459_func(20)(L_2_(L_3939_, 1, L_3939_.n)))
					for L_3941_forvar0 = 1, 1 do
						L_3460_func(20 + L_3941_forvar0 - 1, L_3940_[L_3941_forvar0])
					end
				end
				L_3459_func(19)["icon"] = L_3459_func(20)
				L_3460_func(20, {})
				L_3460_func(21, 121192350097093)
				do
					local L_3942_ = 1
					local L_3943_ = L_3459_func(20)
					for L_3944_forvar0 = 0, L_3942_ - 1 do
						L_3943_[1 + L_3944_forvar0] = L_3459_func(21 + L_3944_forvar0)
					end
				end
				L_3459_func(19)["placeIds"] = L_3459_func(20)
				L_3460_func(20, 15)
				L_3459_func(19)["features"] = L_3459_func(20)
				L_3460_func(20, "rbxassetid://6034281798")
				L_3459_func(19)["img"] = L_3459_func(20)
				L_3460_func(20, {})
				L_3460_func(21, "Grab Ores!")
				L_3459_func(20)["name"] = L_3459_func(21)
				L_3460_func(21, L_10_func(L_3453_arg1, "utf8"))
				L_3460_func(21, L_3459_func(21)["char"])
				L_3460_func(22, 9935)
				do
					local L_3945_ = 1
					local L_3946_ = L_3462_func(22, L_3945_)
					local L_3947_ = L_1_(L_3459_func(21)(L_2_(L_3946_, 1, L_3946_.n)))
					for L_3948_forvar0 = 1, 1 do
						L_3460_func(21 + L_3948_forvar0 - 1, L_3947_[L_3948_forvar0])
					end
				end
				L_3459_func(20)["icon"] = L_3459_func(21)
				L_3460_func(21, {})
				L_3460_func(22, 82806856224736)
				do
					local L_3949_ = 1
					local L_3950_ = L_3459_func(21)
					for L_3951_forvar0 = 0, L_3949_ - 1 do
						L_3950_[1 + L_3951_forvar0] = L_3459_func(22 + L_3951_forvar0)
					end
				end
				L_3459_func(20)["placeIds"] = L_3459_func(21)
				L_3460_func(21, 45)
				L_3459_func(20)["features"] = L_3459_func(21)
				L_3460_func(21, "rbxassetid://6034281798")
				L_3459_func(20)["img"] = L_3459_func(21)
				L_3460_func(21, {})
				L_3460_func(22, "Murderers VS Sheriffs")
				L_3459_func(21)["name"] = L_3459_func(22)
				L_3460_func(22, L_10_func(L_3453_arg1, "utf8"))
				L_3460_func(22, L_3459_func(22)["char"])
				L_3460_func(23, 128298)
				do
					local L_3952_ = 1
					local L_3953_ = L_3462_func(23, L_3952_)
					local L_3954_ = L_1_(L_3459_func(22)(L_2_(L_3953_, 1, L_3953_.n)))
					for L_3955_forvar0 = 1, 1 do
						L_3460_func(22 + L_3955_forvar0 - 1, L_3954_[L_3955_forvar0])
					end
				end
				L_3459_func(21)["icon"] = L_3459_func(22)
				L_3460_func(22, {})
				L_3460_func(23, 135856908115931)
				do
					local L_3956_ = 1
					local L_3957_ = L_3459_func(22)
					for L_3958_forvar0 = 0, L_3956_ - 1 do
						L_3957_[1 + L_3958_forvar0] = L_3459_func(23 + L_3958_forvar0)
					end
				end
				L_3459_func(21)["placeIds"] = L_3459_func(22)
				L_3460_func(22, 22)
				L_3459_func(21)["features"] = L_3459_func(22)
				L_3460_func(22, "rbxassetid://6034281798")
				L_3459_func(21)["img"] = L_3459_func(22)
				L_3460_func(22, {})
				L_3460_func(23, "Sailor Piece")
				L_3459_func(22)["name"] = L_3459_func(23)
				L_3460_func(23, L_10_func(L_3453_arg1, "utf8"))
				L_3460_func(23, L_3459_func(23)["char"])
				L_3460_func(24, 9875)
				do
					local L_3959_ = 1
					local L_3960_ = L_3462_func(24, L_3959_)
					local L_3961_ = L_1_(L_3459_func(23)(L_2_(L_3960_, 1, L_3960_.n)))
					for L_3962_forvar0 = 1, 1 do
						L_3460_func(23 + L_3962_forvar0 - 1, L_3961_[L_3962_forvar0])
					end
				end
				L_3459_func(22)["icon"] = L_3459_func(23)
				L_3460_func(23, {})
				L_3460_func(24, "sailor piece")
				L_3460_func(25, "sailor peace")
				do
					local L_3963_ = 2
					local L_3964_ = L_3459_func(23)
					for L_3965_forvar0 = 0, L_3963_ - 1 do
						L_3964_[1 + L_3965_forvar0] = L_3459_func(24 + L_3965_forvar0)
					end
				end
				L_3459_func(22)["aliases"] = L_3459_func(23)
				L_3460_func(23, {})
				L_3460_func(24, 77747658251236)
				do
					local L_3966_ = 1
					local L_3967_ = L_3459_func(23)
					for L_3968_forvar0 = 0, L_3966_ - 1 do
						L_3967_[1 + L_3968_forvar0] = L_3459_func(24 + L_3968_forvar0)
					end
				end
				L_3459_func(22)["placeIds"] = L_3459_func(23)
				L_3460_func(23, 38)
				L_3459_func(22)["features"] = L_3459_func(23)
				L_3460_func(23, "rbxassetid://6034281798")
				L_3459_func(22)["img"] = L_3459_func(23)
				L_3460_func(23, {})
				L_3460_func(24, "MM2")
				L_3459_func(23)["name"] = L_3459_func(24)
				L_3460_func(24, L_10_func(L_3453_arg1, "utf8"))
				L_3460_func(24, L_3459_func(24)["char"])
				L_3460_func(25, 128481)
				do
					local L_3969_ = 1
					local L_3970_ = L_3462_func(25, L_3969_)
					local L_3971_ = L_1_(L_3459_func(24)(L_2_(L_3970_, 1, L_3970_.n)))
					for L_3972_forvar0 = 1, 1 do
						L_3460_func(24 + L_3972_forvar0 - 1, L_3971_[L_3972_forvar0])
					end
				end
				L_3459_func(23)["icon"] = L_3459_func(24)
				L_3460_func(24, {})
				L_3460_func(25, "murder mystery 2")
				L_3460_func(26, "mm2")
				do
					local L_3973_ = 2
					local L_3974_ = L_3459_func(24)
					for L_3975_forvar0 = 0, L_3973_ - 1 do
						L_3974_[1 + L_3975_forvar0] = L_3459_func(25 + L_3975_forvar0)
					end
				end
				L_3459_func(23)["aliases"] = L_3459_func(24)
				L_3460_func(24, {})
				L_3460_func(25, 142823291)
				L_3460_func(26, 80005698042109)
				do
					local L_3976_ = 2
					local L_3977_ = L_3459_func(24)
					for L_3978_forvar0 = 0, L_3976_ - 1 do
						L_3977_[1 + L_3978_forvar0] = L_3459_func(25 + L_3978_forvar0)
					end
				end
				L_3459_func(23)["placeIds"] = L_3459_func(24)
				L_3460_func(24, 40)
				L_3463_ = 1024
			else
				error("invalid recovered basic block in main: " .. tostring(L_3463_))
			end
		elseif L_3475_ == 4 then
			if L_3463_ == 1024 then

				L_3459_func(23)["features"] = L_3459_func(24)
				L_3460_func(24, "rbxassetid://6034281798")
				L_3459_func(23)["img"] = L_3459_func(24)
				L_3460_func(24, {})
				L_3460_func(25, "Kick a Lucky Block")
				L_3459_func(24)["name"] = L_3459_func(25)
				L_3460_func(25, L_10_func(L_3453_arg1, "utf8"))
				L_3460_func(25, L_3459_func(25)["char"])
				L_3460_func(26, 127808)
				do
					local L_3979_ = 1
					local L_3980_ = L_3462_func(26, L_3979_)
					local L_3981_ = L_1_(L_3459_func(25)(L_2_(L_3980_, 1, L_3980_.n)))
					for L_3982_forvar0 = 1, 1 do
						L_3460_func(25 + L_3982_forvar0 - 1, L_3981_[L_3982_forvar0])
					end
				end
				L_3459_func(24)["icon"] = L_3459_func(25)
				L_3460_func(25, {})
				L_3460_func(26, "kick a lucky block")
				L_3460_func(27, "lucky block")
				L_3460_func(28, "kick lucky")
				do
					local L_3983_ = 3
					local L_3984_ = L_3459_func(25)
					for L_3985_forvar0 = 0, L_3983_ - 1 do
						L_3984_[1 + L_3985_forvar0] = L_3459_func(26 + L_3985_forvar0)
					end
				end
				L_3459_func(24)["aliases"] = L_3459_func(25)
				L_3460_func(25, {})
				L_3460_func(26, 16955097151)
				L_3460_func(27, 89469502395769)
				do
					local L_3986_ = 2
					local L_3987_ = L_3459_func(25)
					for L_3988_forvar0 = 0, L_3986_ - 1 do
						L_3987_[1 + L_3988_forvar0] = L_3459_func(26 + L_3988_forvar0)
					end
				end
				L_3459_func(24)["placeIds"] = L_3459_func(25)
				L_3460_func(25, {})
				L_3460_func(26, 89469502395769)
				do
					local L_3989_ = 1
					local L_3990_ = L_3459_func(25)
					for L_3991_forvar0 = 0, L_3989_ - 1 do
						L_3990_[1 + L_3991_forvar0] = L_3459_func(26 + L_3991_forvar0)
					end
				end
				L_3459_func(24)["universeIds"] = L_3459_func(25)
				L_3460_func(25, 30)
				L_3459_func(24)["features"] = L_3459_func(25)
				L_3460_func(25, "rbxassetid://6034281798")
				L_3459_func(24)["img"] = L_3459_func(25)
				do
					local L_3992_ = 16
					local L_3993_ = L_3459_func(8)
					for L_3994_forvar0 = 0, L_3992_ - 1 do
						L_3993_[17 + L_3994_forvar0] = L_3459_func(9 + L_3994_forvar0)
					end
				end
				L_3460_func(9, {})
				L_3460_func(10, "Rivals")
				L_3459_func(9)["name"] = L_3459_func(10)
				L_3460_func(10, L_10_func(L_3453_arg1, "utf8"))
				L_3460_func(10, L_3459_func(10)["char"])
				L_3460_func(11, 128299)
				do
					local L_3995_ = 1
					local L_3996_ = L_3462_func(11, L_3995_)
					local L_3997_ = L_1_(L_3459_func(10)(L_2_(L_3996_, 1, L_3996_.n)))
					for L_3998_forvar0 = 1, 1 do
						L_3460_func(10 + L_3998_forvar0 - 1, L_3997_[L_3998_forvar0])
					end
				end
				L_3459_func(9)["icon"] = L_3459_func(10)
				L_3460_func(10, {})
				L_3460_func(11, "rivals")
				L_3460_func(12, "rivals fps")
				L_3460_func(13, "matchmaking")
				do
					local L_3999_ = 3
					local L_4000_ = L_3459_func(10)
					for L_4001_forvar0 = 0, L_3999_ - 1 do
						L_4000_[1 + L_4001_forvar0] = L_3459_func(11 + L_4001_forvar0)
					end
				end
				L_3459_func(9)["aliases"] = L_3459_func(10)
				L_3460_func(10, {})
				L_3460_func(11, 17625359962)
				L_3460_func(12, 14721849686)
				L_3460_func(13, 117398147513099)
				do
					local L_4002_ = 3
					local L_4003_ = L_3459_func(10)
					for L_4004_forvar0 = 0, L_4002_ - 1 do
						L_4003_[1 + L_4004_forvar0] = L_3459_func(11 + L_4004_forvar0)
					end
				end
				L_3459_func(9)["placeIds"] = L_3459_func(10)
				L_3460_func(10, {})
				L_3460_func(11, 6035872082)
				do
					local L_4005_ = 1
					local L_4006_ = L_3459_func(10)
					for L_4007_forvar0 = 0, L_4005_ - 1 do
						L_4006_[1 + L_4007_forvar0] = L_3459_func(11 + L_4007_forvar0)
					end
				end
				L_3459_func(9)["universeIds"] = L_3459_func(10)
				L_3460_func(10, 22)
				L_3459_func(9)["features"] = L_3459_func(10)
				L_3460_func(10, "rbxassetid://6034281798")
				L_3459_func(9)["img"] = L_3459_func(10)
				L_3460_func(10, {})
				L_3460_func(11, "Speed Keyboard Escape")
				L_3459_func(10)["name"] = L_3459_func(11)
				L_3460_func(11, L_10_func(L_3453_arg1, "utf8"))
				L_3460_func(11, L_3459_func(11)["char"])
				L_3460_func(12, 9000)
				do
					local L_4008_ = 1
					local L_4009_ = L_3462_func(12, L_4008_)
					local L_4010_ = L_1_(L_3459_func(11)(L_2_(L_4009_, 1, L_4009_.n)))
					for L_4011_forvar0 = 1, 1 do
						L_3460_func(11 + L_4011_forvar0 - 1, L_4010_[L_4011_forvar0])
					end
				end
				L_3459_func(10)["icon"] = L_3459_func(11)
				L_3460_func(11, {})
				L_3460_func(12, "speed keyboard escape")
				L_3460_func(13, "keyboard escape")
				L_3460_func(14, "1 speed keyboard escape")
				L_3460_func(15, "escape candy chocolate")
				L_3460_func(16, "1-speed-keyboard-escape")
				L_3460_func(17, "keyboard")
				do
					local L_4012_ = 6
					local L_4013_ = L_3459_func(11)
					for L_4014_forvar0 = 0, L_4012_ - 1 do
						L_4013_[1 + L_4014_forvar0] = L_3459_func(12 + L_4014_forvar0)
					end
				end
				L_3459_func(10)["aliases"] = L_3459_func(11)
				L_3460_func(11, {})
				L_3460_func(12, 95082159892680)
				do
					local L_4015_ = 1
					local L_4016_ = L_3459_func(11)
					for L_4017_forvar0 = 0, L_4015_ - 1 do
						L_4016_[1 + L_4017_forvar0] = L_3459_func(12 + L_4017_forvar0)
					end
				end
				L_3459_func(10)["placeIds"] = L_3459_func(11)
				L_3460_func(11, 16)
				L_3459_func(10)["features"] = L_3459_func(11)
				L_3460_func(11, "rbxassetid://6034281798")
				L_3459_func(10)["img"] = L_3459_func(11)
				L_3460_func(11, {})
				L_3460_func(12, "Speed Monkey Escape")
				L_3459_func(11)["name"] = L_3459_func(12)
				L_3460_func(12, L_10_func(L_3453_arg1, "utf8"))
				L_3460_func(12, L_3459_func(12)["char"])
				L_3460_func(13, 128018)
				do
					local L_4018_ = 1
					local L_4019_ = L_3462_func(13, L_4018_)
					local L_4020_ = L_1_(L_3459_func(12)(L_2_(L_4019_, 1, L_4019_.n)))
					for L_4021_forvar0 = 1, 1 do
						L_3460_func(12 + L_4021_forvar0 - 1, L_4020_[L_4021_forvar0])
					end
				end
				L_3459_func(11)["icon"] = L_3459_func(12)
				L_3460_func(12, {})
				L_3460_func(13, "speed monkey escape")
				L_3460_func(14, "monkey escape")
				L_3460_func(15, "1 speed monkey escape")
				L_3460_func(16, "monkey")
				do
					local L_4022_ = 4
					local L_4023_ = L_3459_func(12)
					for L_4024_forvar0 = 0, L_4022_ - 1 do
						L_4023_[1 + L_4024_forvar0] = L_3459_func(13 + L_4024_forvar0)
					end
				end
				L_3459_func(11)["aliases"] = L_3459_func(12)
				L_3460_func(12, {})
				L_3460_func(13, 114697347887839)
				do
					local L_4025_ = 1
					local L_4026_ = L_3459_func(12)
					for L_4027_forvar0 = 0, L_4025_ - 1 do
						L_4026_[1 + L_4027_forvar0] = L_3459_func(13 + L_4027_forvar0)
					end
				end
				L_3459_func(11)["placeIds"] = L_3459_func(12)
				L_3460_func(12, 20)
				L_3459_func(11)["features"] = L_3459_func(12)
				L_3460_func(12, "rbxassetid://6034281798")
				L_3459_func(11)["img"] = L_3459_func(12)
				L_3460_func(12, {})
				L_3460_func(13, "Sell Lemons")
				L_3459_func(12)["name"] = L_3459_func(13)
				L_3460_func(13, L_10_func(L_3453_arg1, "utf8"))
				L_3460_func(13, L_3459_func(13)["char"])
				L_3460_func(14, 127819)
				do
					local L_4028_ = 1
					local L_4029_ = L_3462_func(14, L_4028_)
					local L_4030_ = L_1_(L_3459_func(13)(L_2_(L_4029_, 1, L_4029_.n)))
					for L_4031_forvar0 = 1, 1 do
						L_3460_func(13 + L_4031_forvar0 - 1, L_4030_[L_4031_forvar0])
					end
				end
				L_3459_func(12)["icon"] = L_3459_func(13)
				L_3460_func(13, {})
				L_3460_func(14, "sell lemons")
				L_3460_func(15, "lemon tycoon")
				L_3460_func(16, "lemons")
				do
					local L_4032_ = 3
					local L_4033_ = L_3459_func(13)
					for L_4034_forvar0 = 0, L_4032_ - 1 do
						L_4033_[1 + L_4034_forvar0] = L_3459_func(14 + L_4034_forvar0)
					end
				end
				L_3459_func(12)["aliases"] = L_3459_func(13)
				L_3460_func(13, {})
				L_3460_func(14, 79268393072444)
				do
					local L_4035_ = 1
					local L_4036_ = L_3459_func(13)
					for L_4037_forvar0 = 0, L_4035_ - 1 do
						L_4036_[1 + L_4037_forvar0] = L_3459_func(14 + L_4037_forvar0)
					end
				end
				L_3459_func(12)["placeIds"] = L_3459_func(13)
				L_3460_func(13, 14)
				L_3459_func(12)["features"] = L_3459_func(13)
				L_3460_func(13, "rbxassetid://6034281798")
				L_3459_func(12)["img"] = L_3459_func(13)
				L_3460_func(13, {})
				L_3460_func(14, "Demonology")
				L_3459_func(13)["name"] = L_3459_func(14)
				L_3460_func(14, L_10_func(L_3453_arg1, "utf8"))
				L_3460_func(14, L_3459_func(14)["char"])
				L_3460_func(15, 128123)
				do
					local L_4038_ = 1
					local L_4039_ = L_3462_func(15, L_4038_)
					local L_4040_ = L_1_(L_3459_func(14)(L_2_(L_4039_, 1, L_4039_.n)))
					for L_4041_forvar0 = 1, 1 do
						L_3460_func(14 + L_4041_forvar0 - 1, L_4040_[L_4041_forvar0])
					end
				end
				L_3459_func(13)["icon"] = L_3459_func(14)
				L_3460_func(14, {})
				L_3460_func(15, "demonology")
				L_3460_func(16, "ghost hunter")
				L_3460_func(17, "demon")
				do
					local L_4042_ = 3
					local L_4043_ = L_3459_func(14)
					for L_4044_forvar0 = 0, L_4042_ - 1 do
						L_4043_[1 + L_4044_forvar0] = L_3459_func(15 + L_4044_forvar0)
					end
				end
				L_3459_func(13)["aliases"] = L_3459_func(14)
				L_3460_func(14, {})
				L_3460_func(15, 18199615050)
				do
					local L_4045_ = 1
					local L_4046_ = L_3459_func(14)
					for L_4047_forvar0 = 0, L_4045_ - 1 do
						L_4046_[1 + L_4047_forvar0] = L_3459_func(15 + L_4047_forvar0)
					end
				end
				L_3459_func(13)["placeIds"] = L_3459_func(14)
				L_3460_func(14, 12)
				L_3459_func(13)["features"] = L_3459_func(14)
				L_3460_func(14, "rbxassetid://6034281798")
				L_3459_func(13)["img"] = L_3459_func(14)
				L_3460_func(14, {})
				L_3460_func(15, "Grow a Garden 2")
				L_3459_func(14)["name"] = L_3459_func(15)
				L_3460_func(15, L_10_func(L_3453_arg1, "utf8"))
				L_3460_func(15, L_3459_func(15)["char"])
				L_3460_func(16, 127793)
				do
					local L_4048_ = 1
					local L_4049_ = L_3462_func(16, L_4048_)
					local L_4050_ = L_1_(L_3459_func(15)(L_2_(L_4049_, 1, L_4049_.n)))
					for L_4051_forvar0 = 1, 1 do
						L_3460_func(15 + L_4051_forvar0 - 1, L_4050_[L_4051_forvar0])
					end
				end
				L_3459_func(14)["icon"] = L_3459_func(15)
				L_3460_func(15, {})
				L_3460_func(16, "grow a garden 2")
				L_3460_func(17, "grow a garden")
				L_3460_func(18, "gag2")
				L_3460_func(19, "gag 2")
				do
					local L_4052_ = 4
					local L_4053_ = L_3459_func(15)
					for L_4054_forvar0 = 0, L_4052_ - 1 do
						L_4053_[1 + L_4054_forvar0] = L_3459_func(16 + L_4054_forvar0)
					end
				end
				L_3459_func(14)["aliases"] = L_3459_func(15)
				L_3460_func(15, {})
				L_3460_func(16, 97598239454123)
				L_3460_func(17, 1588579651)
				L_3460_func(18, 126884695634066)
				do
					local L_4055_ = 3
					local L_4056_ = L_3459_func(15)
					for L_4057_forvar0 = 0, L_4055_ - 1 do
						L_4056_[1 + L_4057_forvar0] = L_3459_func(16 + L_4057_forvar0)
					end
				end
				L_3459_func(14)["placeIds"] = L_3459_func(15)
				L_3460_func(15, {})
				L_3460_func(16, 7436755782)
				do
					local L_4058_ = 1
					local L_4059_ = L_3459_func(15)
					for L_4060_forvar0 = 0, L_4058_ - 1 do
						L_4059_[1 + L_4060_forvar0] = L_3459_func(16 + L_4060_forvar0)
					end
				end
				L_3459_func(14)["universeIds"] = L_3459_func(15)
				L_3460_func(15, 25)
				L_3459_func(14)["features"] = L_3459_func(15)
				L_3460_func(15, "rbxassetid://6034281798")
				L_3459_func(14)["img"] = L_3459_func(15)
				L_3460_func(15, {})
				L_3460_func(16, "Welcome to Bloxburg")
				L_3459_func(15)["name"] = L_3459_func(16)
				L_3460_func(16, L_10_func(L_3453_arg1, "utf8"))
				L_3460_func(16, L_3459_func(16)["char"])
				L_3460_func(17, 127968)
				do
					local L_4061_ = 1
					local L_4062_ = L_3462_func(17, L_4061_)
					local L_4063_ = L_1_(L_3459_func(16)(L_2_(L_4062_, 1, L_4062_.n)))
					for L_4064_forvar0 = 1, 1 do
						L_3460_func(16 + L_4064_forvar0 - 1, L_4063_[L_4064_forvar0])
					end
				end
				L_3459_func(15)["icon"] = L_3459_func(16)
				L_3460_func(16, {})
				L_3460_func(17, "welcome to bloxburg")
				L_3460_func(18, "bloxburg")
				do
					local L_4065_ = 2
					local L_4066_ = L_3459_func(16)
					for L_4067_forvar0 = 0, L_4065_ - 1 do
						L_4066_[1 + L_4067_forvar0] = L_3459_func(17 + L_4067_forvar0)
					end
				end
				L_3459_func(15)["aliases"] = L_3459_func(16)
				L_3460_func(16, {})
				L_3460_func(17, 185655149)
				do
					local L_4068_ = 1
					local L_4069_ = L_3459_func(16)
					for L_4070_forvar0 = 0, L_4068_ - 1 do
						L_4069_[1 + L_4070_forvar0] = L_3459_func(17 + L_4070_forvar0)
					end
				end
				L_3459_func(15)["placeIds"] = L_3459_func(16)
				L_3460_func(16, 16)
				L_3459_func(15)["features"] = L_3459_func(16)
				L_3460_func(16, "rbxassetid://6034281798")
				L_3459_func(15)["img"] = L_3459_func(16)
				L_3460_func(16, {})
				L_3460_func(17, "Adopt Me")
				L_3459_func(16)["name"] = L_3459_func(17)
				L_3460_func(17, L_10_func(L_3453_arg1, "utf8"))
				L_3460_func(17, L_3459_func(17)["char"])
				L_3460_func(18, 128054)
				do
					local L_4071_ = 1
					local L_4072_ = L_3462_func(18, L_4071_)
					local L_4073_ = L_1_(L_3459_func(17)(L_2_(L_4072_, 1, L_4072_.n)))
					for L_4074_forvar0 = 1, 1 do
						L_3460_func(17 + L_4074_forvar0 - 1, L_4073_[L_4074_forvar0])
					end
				end
				L_3459_func(16)["icon"] = L_3459_func(17)
				L_3460_func(17, {})
				L_3460_func(18, "adopt me")
				L_3460_func(19, "adoptme")
				do
					local L_4075_ = 2
					local L_4076_ = L_3459_func(17)
					for L_4077_forvar0 = 0, L_4075_ - 1 do
						L_4076_[1 + L_4077_forvar0] = L_3459_func(18 + L_4077_forvar0)
					end
				end
				L_3459_func(16)["aliases"] = L_3459_func(17)
				L_3460_func(17, {})
				L_3460_func(18, 920587237)
				do
					local L_4078_ = 1
					local L_4079_ = L_3459_func(17)
					for L_4080_forvar0 = 0, L_4078_ - 1 do
						L_4079_[1 + L_4080_forvar0] = L_3459_func(18 + L_4080_forvar0)
					end
				end
				L_3459_func(16)["placeIds"] = L_3459_func(17)
				L_3460_func(17, 12)
				L_3459_func(16)["features"] = L_3459_func(17)
				L_3460_func(17, "rbxassetid://6034281798")
				L_3459_func(16)["img"] = L_3459_func(17)
				L_3460_func(17, {})
				L_3460_func(18, "Dandy's World")
				L_3459_func(17)["name"] = L_3459_func(18)
				L_3460_func(18, L_10_func(L_3453_arg1, "utf8"))
				L_3460_func(18, L_3459_func(18)["char"])
				L_3460_func(19, 127912)
				do
					local L_4081_ = 1
					local L_4082_ = L_3462_func(19, L_4081_)
					local L_4083_ = L_1_(L_3459_func(18)(L_2_(L_4082_, 1, L_4082_.n)))
					for L_4084_forvar0 = 1, 1 do
						L_3460_func(18 + L_4084_forvar0 - 1, L_4083_[L_4084_forvar0])
					end
				end
				L_3459_func(17)["icon"] = L_3459_func(18)
				L_3463_ = 1280
			else
				error("invalid recovered basic block in main: " .. tostring(L_3463_))
			end
		elseif L_3475_ == 5 then
			if L_3463_ == 1280 then

				L_3460_func(18, {})
				L_3460_func(19, "dandys world")
				L_3460_func(20, "dandy")
				L_3460_func(21, "dandys")
				do
					local L_4085_ = 3
					local L_4086_ = L_3459_func(18)
					for L_4087_forvar0 = 0, L_4085_ - 1 do
						L_4086_[1 + L_4087_forvar0] = L_3459_func(19 + L_4087_forvar0)
					end
				end
				L_3459_func(17)["aliases"] = L_3459_func(18)
				L_3460_func(18, {})
				L_3460_func(19, 16267229903)
				do
					local L_4088_ = 1
					local L_4089_ = L_3459_func(18)
					for L_4090_forvar0 = 0, L_4088_ - 1 do
						L_4089_[1 + L_4090_forvar0] = L_3459_func(19 + L_4090_forvar0)
					end
				end
				L_3459_func(17)["placeIds"] = L_3459_func(18)
				L_3460_func(18, 10)
				L_3459_func(17)["features"] = L_3459_func(18)
				L_3460_func(18, "rbxassetid://6034281798")
				L_3459_func(17)["img"] = L_3459_func(18)
				L_3460_func(18, {})
				L_3460_func(19, "Blade Ball")
				L_3459_func(18)["name"] = L_3459_func(19)
				L_3460_func(19, L_10_func(L_3453_arg1, "utf8"))
				L_3460_func(19, L_3459_func(19)["char"])
				L_3460_func(20, 128298)
				do
					local L_4091_ = 1
					local L_4092_ = L_3462_func(20, L_4091_)
					local L_4093_ = L_1_(L_3459_func(19)(L_2_(L_4092_, 1, L_4092_.n)))
					for L_4094_forvar0 = 1, 1 do
						L_3460_func(19 + L_4094_forvar0 - 1, L_4093_[L_4094_forvar0])
					end
				end
				L_3459_func(18)["icon"] = L_3459_func(19)
				L_3460_func(19, {})
				L_3460_func(20, "blade ball")
				L_3460_func(21, "bladeball")
				L_3460_func(22, "bb")
				do
					local L_4095_ = 3
					local L_4096_ = L_3459_func(19)
					for L_4097_forvar0 = 0, L_4095_ - 1 do
						L_4096_[1 + L_4097_forvar0] = L_3459_func(20 + L_4097_forvar0)
					end
				end
				L_3459_func(18)["aliases"] = L_3459_func(19)
				L_3460_func(19, {})
				L_3460_func(20, 13772394625)
				L_3460_func(21, 14777999650)
				L_3460_func(22, 15182888200)
				do
					local L_4098_ = 3
					local L_4099_ = L_3459_func(19)
					for L_4100_forvar0 = 0, L_4098_ - 1 do
						L_4099_[1 + L_4100_forvar0] = L_3459_func(20 + L_4100_forvar0)
					end
				end
				L_3459_func(18)["placeIds"] = L_3459_func(19)
				L_3460_func(19, 25)
				L_3459_func(18)["features"] = L_3459_func(19)
				L_3460_func(19, "rbxassetid://6034281798")
				L_3459_func(18)["img"] = L_3459_func(19)
				L_3460_func(19, {})
				L_3460_func(20, "KAT")
				L_3459_func(19)["name"] = L_3459_func(20)
				L_3460_func(20, L_10_func(L_3453_arg1, "utf8"))
				L_3460_func(20, L_3459_func(20)["char"])
				L_3460_func(21, 128298)
				do
					local L_4101_ = 1
					local L_4102_ = L_3462_func(21, L_4101_)
					local L_4103_ = L_1_(L_3459_func(20)(L_2_(L_4102_, 1, L_4102_.n)))
					for L_4104_forvar0 = 1, 1 do
						L_3460_func(20 + L_4104_forvar0 - 1, L_4103_[L_4104_forvar0])
					end
				end
				L_3459_func(19)["icon"] = L_3459_func(20)
				L_3460_func(20, {})
				L_3460_func(21, 621129760)
				do
					local L_4105_ = 1
					local L_4106_ = L_3459_func(20)
					for L_4107_forvar0 = 0, L_4105_ - 1 do
						L_4106_[1 + L_4107_forvar0] = L_3459_func(21 + L_4107_forvar0)
					end
				end
				L_3459_func(19)["placeIds"] = L_3459_func(20)
				L_3460_func(20, {})
				L_3460_func(21, 228028122)
				do
					local L_4108_ = 1
					local L_4109_ = L_3459_func(20)
					for L_4110_forvar0 = 0, L_4108_ - 1 do
						L_4109_[1 + L_4110_forvar0] = L_3459_func(21 + L_4110_forvar0)
					end
				end
				L_3459_func(19)["universeIds"] = L_3459_func(20)
				L_3460_func(20, 11)
				L_3459_func(19)["features"] = L_3459_func(20)
				L_3460_func(20, "rbxassetid://6034281798")
				L_3459_func(19)["img"] = L_3459_func(20)
				L_3460_func(20, {})
				L_3460_func(21, "One Scope")
				L_3459_func(20)["name"] = L_3459_func(21)
				L_3460_func(21, L_10_func(L_3453_arg1, "utf8"))
				L_3460_func(21, L_3459_func(21)["char"])
				L_3460_func(22, 127919)
				do
					local L_4111_ = 1
					local L_4112_ = L_3462_func(22, L_4111_)
					local L_4113_ = L_1_(L_3459_func(21)(L_2_(L_4112_, 1, L_4112_.n)))
					for L_4114_forvar0 = 1, 1 do
						L_3460_func(21 + L_4114_forvar0 - 1, L_4113_[L_4114_forvar0])
					end
				end
				L_3459_func(20)["icon"] = L_3459_func(21)
				L_3460_func(21, {})
				L_3460_func(22, 135648408848758)
				do
					local L_4115_ = 1
					local L_4116_ = L_3459_func(21)
					for L_4117_forvar0 = 0, L_4115_ - 1 do
						L_4116_[1 + L_4117_forvar0] = L_3459_func(22 + L_4117_forvar0)
					end
				end
				L_3459_func(20)["placeIds"] = L_3459_func(21)
				L_3460_func(21, 7)
				L_3459_func(20)["features"] = L_3459_func(21)
				L_3460_func(21, "rbxassetid://6034281798")
				L_3459_func(20)["img"] = L_3459_func(21)
				L_3460_func(21, {})
				L_3460_func(22, "Da Hood")
				L_3459_func(21)["name"] = L_3459_func(22)
				L_3460_func(22, L_10_func(L_3453_arg1, "utf8"))
				L_3460_func(22, L_3459_func(22)["char"])
				L_3460_func(23, 127968)
				do
					local L_4118_ = 1
					local L_4119_ = L_3462_func(23, L_4118_)
					local L_4120_ = L_1_(L_3459_func(22)(L_2_(L_4119_, 1, L_4119_.n)))
					for L_4121_forvar0 = 1, 1 do
						L_3460_func(22 + L_4121_forvar0 - 1, L_4120_[L_4121_forvar0])
					end
				end
				L_3459_func(21)["icon"] = L_3459_func(22)
				L_3460_func(22, {})
				L_3460_func(23, "da hood")
				L_3460_func(24, "dahood")
				L_3460_func(25, "dh")
				do
					local L_4122_ = 3
					local L_4123_ = L_3459_func(22)
					for L_4124_forvar0 = 0, L_4122_ - 1 do
						L_4123_[1 + L_4124_forvar0] = L_3459_func(23 + L_4124_forvar0)
					end
				end
				L_3459_func(21)["aliases"] = L_3459_func(22)
				L_3460_func(22, {})
				L_3460_func(23, 2788229376)
				L_3460_func(24, 105305881594005)
				L_3460_func(25, 98343466176190)
				L_3460_func(26, 93778920465645)
				L_3460_func(27, 129449254792324)
				L_3460_func(28, 122120252103378)
				L_3460_func(29, 110917236678062)
				L_3460_func(30, 130879446158509)
				do
					local L_4125_ = 8
					local L_4126_ = L_3459_func(22)
					for L_4127_forvar0 = 0, L_4125_ - 1 do
						L_4126_[1 + L_4127_forvar0] = L_3459_func(23 + L_4127_forvar0)
					end
				end
				L_3459_func(21)["placeIds"] = L_3459_func(22)
				L_3460_func(22, 120)
				L_3459_func(21)["features"] = L_3459_func(22)
				L_3460_func(22, "rbxassetid://6034281798")
				L_3459_func(21)["img"] = L_3459_func(22)
				L_3460_func(22, {})
				L_3460_func(23, "Evade")
				L_3459_func(22)["name"] = L_3459_func(23)
				L_3460_func(23, L_10_func(L_3453_arg1, "utf8"))
				L_3460_func(23, L_3459_func(23)["char"])
				L_3460_func(24, 127939)
				do
					local L_4128_ = 1
					local L_4129_ = L_3462_func(24, L_4128_)
					local L_4130_ = L_1_(L_3459_func(23)(L_2_(L_4129_, 1, L_4129_.n)))
					for L_4131_forvar0 = 1, 1 do
						L_3460_func(23 + L_4131_forvar0 - 1, L_4130_[L_4131_forvar0])
					end
				end
				L_3459_func(22)["icon"] = L_3459_func(23)
				L_3460_func(23, {})
				L_3460_func(24, "evade")
				L_3460_func(25, "rise")
				do
					local L_4132_ = 2
					local L_4133_ = L_3459_func(23)
					for L_4134_forvar0 = 0, L_4132_ - 1 do
						L_4133_[1 + L_4134_forvar0] = L_3459_func(24 + L_4134_forvar0)
					end
				end
				L_3459_func(22)["aliases"] = L_3459_func(23)
				L_3460_func(23, {})
				L_3460_func(24, 9872472334)
				do
					local L_4135_ = 1
					local L_4136_ = L_3459_func(23)
					for L_4137_forvar0 = 0, L_4135_ - 1 do
						L_4136_[1 + L_4137_forvar0] = L_3459_func(24 + L_4137_forvar0)
					end
				end
				L_3459_func(22)["placeIds"] = L_3459_func(23)
				L_3460_func(23, 45)
				L_3459_func(22)["features"] = L_3459_func(23)
				L_3460_func(23, "rbxassetid://6034281798")
				L_3459_func(22)["img"] = L_3459_func(23)
				L_3460_func(23, {})
				L_3460_func(24, "Bridge Duel")
				L_3459_func(23)["name"] = L_3459_func(24)
				L_3460_func(24, L_10_func(L_3453_arg1, "utf8"))
				L_3460_func(24, L_3459_func(24)["char"])
				L_3460_func(25, 128481)
				do
					local L_4138_ = 1
					local L_4139_ = L_3462_func(25, L_4138_)
					local L_4140_ = L_1_(L_3459_func(24)(L_2_(L_4139_, 1, L_4139_.n)))
					for L_4141_forvar0 = 1, 1 do
						L_3460_func(24 + L_4141_forvar0 - 1, L_4140_[L_4141_forvar0])
					end
				end
				L_3459_func(23)["icon"] = L_3459_func(24)
				L_3460_func(24, {})
				L_3460_func(25, "bridge duel")
				L_3460_func(26, "bridge duels")
				L_3460_func(27, "uoro")
				do
					local L_4142_ = 3
					local L_4143_ = L_3459_func(24)
					for L_4144_forvar0 = 0, L_4142_ - 1 do
						L_4143_[1 + L_4144_forvar0] = L_3459_func(25 + L_4144_forvar0)
					end
				end
				L_3459_func(23)["aliases"] = L_3459_func(24)
				L_3460_func(24, {})
				L_3460_func(25, 139566161526375)
				do
					local L_4145_ = 1
					local L_4146_ = L_3459_func(24)
					for L_4147_forvar0 = 0, L_4145_ - 1 do
						L_4146_[1 + L_4147_forvar0] = L_3459_func(25 + L_4147_forvar0)
					end
				end
				L_3459_func(23)["placeIds"] = L_3459_func(24)
				L_3460_func(24, 35)
				L_3459_func(23)["features"] = L_3459_func(24)
				L_3460_func(24, "rbxassetid://6034281798")
				L_3459_func(23)["img"] = L_3459_func(24)
				L_3460_func(24, {})
				L_3460_func(25, "Drain the Lake")
				L_3459_func(24)["name"] = L_3459_func(25)
				L_3460_func(25, L_10_func(L_3453_arg1, "utf8"))
				L_3460_func(25, L_3459_func(25)["char"])
				L_3460_func(26, 128167)
				do
					local L_4148_ = 1
					local L_4149_ = L_3462_func(26, L_4148_)
					local L_4150_ = L_1_(L_3459_func(25)(L_2_(L_4149_, 1, L_4149_.n)))
					for L_4151_forvar0 = 1, 1 do
						L_3460_func(25 + L_4151_forvar0 - 1, L_4150_[L_4151_forvar0])
					end
				end
				L_3459_func(24)["icon"] = L_3459_func(25)
				L_3460_func(25, {})
				L_3460_func(26, "drain the lake")
				L_3460_func(27, "drain lake")
				do
					local L_4152_ = 2
					local L_4153_ = L_3459_func(25)
					for L_4154_forvar0 = 0, L_4152_ - 1 do
						L_4153_[1 + L_4154_forvar0] = L_3459_func(26 + L_4154_forvar0)
					end
				end
				L_3459_func(24)["aliases"] = L_3459_func(25)
				L_3460_func(25, {})
				L_3460_func(26, 138381251771774)
				do
					local L_4155_ = 1
					local L_4156_ = L_3459_func(25)
					for L_4157_forvar0 = 0, L_4155_ - 1 do
						L_4156_[1 + L_4157_forvar0] = L_3459_func(26 + L_4157_forvar0)
					end
				end
				L_3459_func(24)["placeIds"] = L_3459_func(25)
				L_3460_func(25, {})
				L_3460_func(26, 10267363348)
				do
					local L_4158_ = 1
					local L_4159_ = L_3459_func(25)
					for L_4160_forvar0 = 0, L_4158_ - 1 do
						L_4159_[1 + L_4160_forvar0] = L_3459_func(26 + L_4160_forvar0)
					end
				end
				L_3459_func(24)["universeIds"] = L_3459_func(25)
				L_3460_func(25, 9)
				L_3459_func(24)["features"] = L_3459_func(25)
				L_3460_func(25, "rbxassetid://6034281798")
				L_3459_func(24)["img"] = L_3459_func(25)
				do
					local L_4161_ = 16
					local L_4162_ = L_3459_func(8)
					for L_4163_forvar0 = 0, L_4161_ - 1 do
						L_4162_[33 + L_4163_forvar0] = L_3459_func(9 + L_4163_forvar0)
					end
				end
				L_3460_func(9, {})
				L_3460_func(10, "Prison Life")
				L_3459_func(9)["name"] = L_3459_func(10)
				L_3460_func(10, L_10_func(L_3453_arg1, "utf8"))
				L_3460_func(10, L_3459_func(10)["char"])
				L_3460_func(11, 128680)
				do
					local L_4164_ = 1
					local L_4165_ = L_3462_func(11, L_4164_)
					local L_4166_ = L_1_(L_3459_func(10)(L_2_(L_4165_, 1, L_4165_.n)))
					for L_4167_forvar0 = 1, 1 do
						L_3460_func(10 + L_4167_forvar0 - 1, L_4166_[L_4167_forvar0])
					end
				end
				L_3459_func(9)["icon"] = L_3459_func(10)
				L_3460_func(10, {})
				L_3460_func(11, "prison life")
				L_3460_func(12, "prison")
				do
					local L_4168_ = 2
					local L_4169_ = L_3459_func(10)
					for L_4170_forvar0 = 0, L_4168_ - 1 do
						L_4169_[1 + L_4170_forvar0] = L_3459_func(11 + L_4170_forvar0)
					end
				end
				L_3459_func(9)["aliases"] = L_3459_func(10)
				L_3460_func(10, {})
				L_3460_func(11, 155615604)
				do
					local L_4171_ = 1
					local L_4172_ = L_3459_func(10)
					for L_4173_forvar0 = 0, L_4171_ - 1 do
						L_4172_[1 + L_4173_forvar0] = L_3459_func(11 + L_4173_forvar0)
					end
				end
				L_3459_func(9)["placeIds"] = L_3459_func(10)
				L_3460_func(10, {})
				L_3460_func(11, 73885730)
				do
					local L_4174_ = 1
					local L_4175_ = L_3459_func(10)
					for L_4176_forvar0 = 0, L_4174_ - 1 do
						L_4175_[1 + L_4176_forvar0] = L_3459_func(11 + L_4176_forvar0)
					end
				end
				L_3459_func(9)["universeIds"] = L_3459_func(10)
				L_3460_func(10, 9)
				L_3459_func(9)["features"] = L_3459_func(10)
				L_3460_func(10, "rbxassetid://6034281798")
				L_3459_func(9)["img"] = L_3459_func(10)
				L_3460_func(10, {})
				L_3460_func(11, "Fish It")
				L_3459_func(10)["name"] = L_3459_func(11)
				L_3460_func(11, L_10_func(L_3453_arg1, "utf8"))
				L_3460_func(11, L_3459_func(11)["char"])
				L_3460_func(12, 128031)
				do
					local L_4177_ = 1
					local L_4178_ = L_3462_func(12, L_4177_)
					local L_4179_ = L_1_(L_3459_func(11)(L_2_(L_4178_, 1, L_4178_.n)))
					for L_4180_forvar0 = 1, 1 do
						L_3460_func(11 + L_4180_forvar0 - 1, L_4179_[L_4180_forvar0])
					end
				end
				L_3459_func(10)["icon"] = L_3459_func(11)
				L_3460_func(11, {})
				L_3460_func(12, "fish it")
				L_3460_func(13, "fisch")
				L_3460_func(14, "fishit")
				do
					local L_4181_ = 3
					local L_4182_ = L_3459_func(11)
					for L_4183_forvar0 = 0, L_4181_ - 1 do
						L_4182_[1 + L_4183_forvar0] = L_3459_func(12 + L_4183_forvar0)
					end
				end
				L_3459_func(10)["aliases"] = L_3459_func(11)
				L_3460_func(11, {})
				L_3460_func(12, 121864768012064)
				L_3460_func(13, 16732694052)
				L_3460_func(14, 17445763782)
				do
					local L_4184_ = 3
					local L_4185_ = L_3459_func(11)
					for L_4186_forvar0 = 0, L_4184_ - 1 do
						L_4185_[1 + L_4186_forvar0] = L_3459_func(12 + L_4186_forvar0)
					end
				end
				L_3459_func(10)["placeIds"] = L_3459_func(11)
				L_3460_func(11, 25)
				L_3459_func(10)["features"] = L_3459_func(11)
				L_3460_func(11, "rbxassetid://6034281798")
				L_3459_func(10)["img"] = L_3459_func(11)
				L_3460_func(11, {})
				L_3460_func(12, "Forsaken")
				L_3459_func(11)["name"] = L_3459_func(12)
				L_3460_func(12, L_10_func(L_3453_arg1, "utf8"))
				L_3460_func(12, L_3459_func(12)["char"])
				L_3460_func(13, 128128)
				do
					local L_4187_ = 1
					local L_4188_ = L_3462_func(13, L_4187_)
					local L_4189_ = L_1_(L_3459_func(12)(L_2_(L_4188_, 1, L_4188_.n)))
					for L_4190_forvar0 = 1, 1 do
						L_3460_func(12 + L_4190_forvar0 - 1, L_4189_[L_4190_forvar0])
					end
				end
				L_3459_func(11)["icon"] = L_3459_func(12)
				L_3463_ = 1536
			else
				error("invalid recovered basic block in main: " .. tostring(L_3463_))
			end
		elseif L_3475_ == 6 then
			if L_3463_ == 1536 then

				L_3460_func(12, {})
				L_3460_func(13, "forsaken")
				do
					local L_4191_ = 1
					local L_4192_ = L_3459_func(12)
					for L_4193_forvar0 = 0, L_4191_ - 1 do
						L_4192_[1 + L_4193_forvar0] = L_3459_func(13 + L_4193_forvar0)
					end
				end
				L_3459_func(11)["aliases"] = L_3459_func(12)
				L_3460_func(12, {})
				L_3460_func(13, 18687417158)
				do
					local L_4194_ = 1
					local L_4195_ = L_3459_func(12)
					for L_4196_forvar0 = 0, L_4194_ - 1 do
						L_4195_[1 + L_4196_forvar0] = L_3459_func(13 + L_4196_forvar0)
					end
				end
				L_3459_func(11)["placeIds"] = L_3459_func(12)
				L_3460_func(12, 20)
				L_3459_func(11)["features"] = L_3459_func(12)
				L_3460_func(12, "rbxassetid://6034281798")
				L_3459_func(11)["img"] = L_3459_func(12)
				L_3460_func(12, {})
				L_3460_func(25, "Volley Ball Legends")
				L_3459_func(12)["name"] = L_3459_func(25)
				L_3460_func(25, L_10_func(L_3453_arg1, "utf8"))
				L_3460_func(25, L_3459_func(25)["char"])
				L_3460_func(26, 127952)
				do
					local L_4197_ = 1
					local L_4198_ = L_3462_func(26, L_4197_)
					local L_4199_ = L_1_(L_3459_func(25)(L_2_(L_4198_, 1, L_4198_.n)))
					for L_4200_forvar0 = 1, 1 do
						L_3460_func(25 + L_4200_forvar0 - 1, L_4199_[L_4200_forvar0])
					end
				end
				L_3459_func(12)["icon"] = L_3459_func(25)
				L_3460_func(25, {})
				L_3460_func(26, "volley ball legends")
				L_3460_func(27, "volleyball legends")
				L_3460_func(28, "volleyball")
				L_3460_func(29, "volley ball")
				do
					local L_4201_ = 4
					local L_4202_ = L_3459_func(25)
					for L_4203_forvar0 = 0, L_4201_ - 1 do
						L_4202_[1 + L_4203_forvar0] = L_3459_func(26 + L_4203_forvar0)
					end
				end
				L_3459_func(12)["aliases"] = L_3459_func(25)
				L_3460_func(25, {})
				L_3460_func(26, 73956553001240)
				do
					local L_4204_ = 1
					local L_4205_ = L_3459_func(25)
					for L_4206_forvar0 = 0, L_4204_ - 1 do
						L_4205_[1 + L_4206_forvar0] = L_3459_func(26 + L_4206_forvar0)
					end
				end
				L_3459_func(12)["placeIds"] = L_3459_func(25)
				L_3460_func(25, 20)
				L_3459_func(12)["features"] = L_3459_func(25)
				L_3460_func(25, "rbxassetid://6034281798")
				L_3459_func(12)["img"] = L_3459_func(25)
				do
					local L_4207_ = 4
					local L_4208_ = L_3459_func(8)
					for L_4209_forvar0 = 0, L_4207_ - 1 do
						L_4208_[49 + L_4209_forvar0] = L_3459_func(9 + L_4209_forvar0)
					end
				end
				L_3460_func(9, L_10_func(L_3453_arg1, "getgenv"))
				do
					local L_4210_ = 0
					local L_4211_ = L_3462_func(10, L_4210_)
					local L_4212_ = L_1_(L_3459_func(9)(L_2_(L_4211_, 1, L_4211_.n)))
					for L_4213_forvar0 = 1, 1 do
						L_3460_func(9 + L_4213_forvar0 - 1, L_4212_[L_4213_forvar0])
					end
				end
				L_3459_func(9)["SUPPORTED_GAMES"] = L_3459_func(8)
				L_3460_func(9, nil)
				L_3460_func(11, L_10_func(L_3453_arg1, "game"))
				L_3460_func(11, L_3459_func(11)["PlaceId"])
				L_3460_func(10, L_10_func(L_3453_arg1, "tonumber"))
				do
					local L_4214_ = 1
					local L_4215_ = L_3462_func(11, L_4214_)
					local L_4216_ = L_1_(L_3459_func(10)(L_2_(L_4215_, 1, L_4215_.n)))
					for L_4217_forvar0 = 1, 1 do
						L_3460_func(10 + L_4217_forvar0 - 1, L_4216_[L_4217_forvar0])
					end
				end
				if L_3459_func(10) then
					L_3463_ = 1590
				else
					L_3463_ = 1589
				end
			elseif L_3463_ == 1589 then

				L_3460_func(10, 0)
				L_3463_ = 1590
			elseif L_3463_ == 1590 then

				L_3460_func(12, L_10_func(L_3453_arg1, "game"))
				L_3460_func(12, L_3459_func(12)["GameId"])
				L_3460_func(11, L_10_func(L_3453_arg1, "tonumber"))
				do
					local L_4218_ = 1
					local L_4219_ = L_3462_func(12, L_4218_)
					local L_4220_ = L_1_(L_3459_func(11)(L_2_(L_4219_, 1, L_4219_.n)))
					for L_4221_forvar0 = 1, 1 do
						L_3460_func(11 + L_4221_forvar0 - 1, L_4220_[L_4221_forvar0])
					end
				end
				if L_3459_func(11) then
					L_3463_ = 1598
				else
					L_3463_ = 1597
				end
			elseif L_3463_ == 1597 then

				L_3460_func(11, 0)
				L_3463_ = 1598
			elseif L_3463_ == 1598 then

				L_3460_func(12, "")
				L_3460_func(13, L_10_func(L_3453_arg1, "pcall"))

				do
					local L_4222_ = {}
					L_4222_[1] = {
						L_3459_func(10)
					}
					L_4222_[2] = L_3461_func(12)
					local L_4223_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_4224_
					L_4224_ = function(...)
						return L_13_.fn_041_detectGame(L_4222_, L_4223_, ...)
					end
					L_6_[L_4224_] = L_4223_
					L_3460_func(14, L_4224_)
				end
				do
					local L_4225_ = 1
					local L_4226_ = L_3462_func(14, L_4225_)
					L_3459_func(13)(L_2_(L_4226_, 1, L_4226_.n))
				end
				L_3460_func(13, L_10_func(L_3453_arg1, "ipairs"))
				L_3460_func(14, L_3459_func(8))
				do
					local L_4227_ = 1
					local L_4228_ = L_3462_func(14, L_4227_)
					local L_4229_ = L_1_(L_3459_func(13)(L_2_(L_4228_, 1, L_4228_.n)))
					for L_4230_forvar0 = 1, 3 do
						L_3460_func(13 + L_4230_forvar0 - 1, L_4229_[L_4230_forvar0])
					end
				end
				L_3463_ = 1638
			elseif L_3463_ == 1607 then

				L_3460_func(18, L_3459_func(17)["placeIds"])
				if not L_3459_func(18) then
					L_3463_ = 1621
				else
					L_3463_ = 1609
				end
			elseif L_3463_ == 1609 then

				L_3460_func(18, L_10_func(L_3453_arg1, "ipairs"))
				L_3460_func(19, L_3459_func(17)["placeIds"])
				do
					local L_4231_ = 1
					local L_4232_ = L_3462_func(19, L_4231_)
					local L_4233_ = L_1_(L_3459_func(18)(L_2_(L_4232_, 1, L_4232_.n)))
					for L_4234_forvar0 = 1, 3 do
						L_3460_func(18 + L_4234_forvar0 - 1, L_4233_[L_4234_forvar0])
					end
				end
				L_3463_ = 1620
			elseif L_3463_ == 1613 then

				L_3460_func(24, L_3459_func(22))
				L_3460_func(23, L_10_func(L_3453_arg1, "tonumber"))
				do
					local L_4235_ = 1
					local L_4236_ = L_3462_func(24, L_4235_)
					local L_4237_ = L_1_(L_3459_func(23)(L_2_(L_4236_, 1, L_4236_.n)))
					for L_4238_forvar0 = 1, 1 do
						L_3460_func(23 + L_4238_forvar0 - 1, L_4237_[L_4238_forvar0])
					end
				end
				L_3460_func(73, L_3459_func(10) == L_3459_func(23))
				if not L_3459_func(73) then
					L_3463_ = 1620
				else
					L_3463_ = 1618
				end
			elseif L_3463_ == 1618 then

				L_3460_func(9, L_3459_func(17))
				L_3463_ = 1621
			elseif L_3463_ == 1620 then

				if L_12_func(L_3459_func, L_3460_func, 18, 2) then
					L_3463_ = 1613
				else
					L_3463_ = 1621
				end
			elseif L_3463_ == 1621 then

				if L_3459_func(9) then
					L_3463_ = 1637
				else
					L_3463_ = 1622
				end
			elseif L_3463_ == 1622 then

				L_3460_func(18, L_3459_func(17)["universeIds"])
				if not L_3459_func(18) then
					L_3463_ = 1637
				else
					L_3463_ = 1624
				end
			elseif L_3463_ == 1624 then

				L_3460_func(18, L_10_func(L_3453_arg1, "ipairs"))
				L_3460_func(19, L_3459_func(17)["universeIds"])
				do
					local L_4239_ = 1
					local L_4240_ = L_3462_func(19, L_4239_)
					local L_4241_ = L_1_(L_3459_func(18)(L_2_(L_4240_, 1, L_4240_.n)))
					for L_4242_forvar0 = 1, 3 do
						L_3460_func(18 + L_4242_forvar0 - 1, L_4241_[L_4242_forvar0])
					end
				end
				L_3463_ = 1636
			elseif L_3463_ == 1628 then

				L_3460_func(24, L_3459_func(22))
				L_3460_func(23, L_10_func(L_3453_arg1, "tonumber"))
				do
					local L_4243_ = 1
					local L_4244_ = L_3462_func(24, L_4243_)
					local L_4245_ = L_1_(L_3459_func(23)(L_2_(L_4244_, 1, L_4244_.n)))
					for L_4246_forvar0 = 1, 1 do
						L_3460_func(23 + L_4246_forvar0 - 1, L_4245_[L_4246_forvar0])
					end
				end
				L_3460_func(73, L_3459_func(11) == L_3459_func(23))
				if not L_3459_func(73) then
					L_3463_ = 1636
				else
					L_3463_ = 1634
				end
			elseif L_3463_ == 1634 then

				L_3460_func(9, L_3459_func(17))
				L_3463_ = 1637
			elseif L_3463_ == 1636 then

				if L_12_func(L_3459_func, L_3460_func, 18, 2) then
					L_3463_ = 1628
				else
					L_3463_ = 1637
				end
			elseif L_3463_ == 1637 then

				if L_3459_func(9) then
					L_3463_ = 1639
				else
					L_3463_ = 1638
				end
			elseif L_3463_ == 1638 then

				if L_12_func(L_3459_func, L_3460_func, 13, 2) then
					L_3463_ = 1607
				else
					L_3463_ = 1639
				end
			elseif L_3463_ == 1639 then

				if L_3459_func(9) then
					L_3463_ = 1685
				else
					L_3463_ = 1640
				end
			elseif L_3463_ == 1640 then

				L_3460_func(72, "")
				L_3460_func(73, L_3459_func(12) == L_3459_func(72))
				if L_3459_func(73) then
					L_3463_ = 1685
				else
					L_3463_ = 1643
				end
			elseif L_3463_ == 1643 then

				L_3460_func(13, L_10_func(L_3453_arg1, "ipairs"))
				L_3460_func(14, L_3459_func(8))
				do
					local L_4247_ = 1
					local L_4248_ = L_3462_func(14, L_4247_)
					local L_4249_ = L_1_(L_3459_func(13)(L_2_(L_4248_, 1, L_4248_.n)))
					for L_4250_forvar0 = 1, 3 do
						L_3460_func(13 + L_4250_forvar0 - 1, L_4249_[L_4250_forvar0])
					end
				end
				L_3463_ = 1684
			elseif L_3463_ == 1648 then

				L_3460_func(18, L_3459_func(17)["name"])
				do
					local L_4251_ = L_3459_func(18)
					L_3460_func(19, L_4251_)
					L_3460_func(18, L_4251_["lower"])
				end
				do
					local L_4252_ = 1
					local L_4253_ = L_3462_func(19, L_4252_)
					local L_4254_ = L_1_(L_3459_func(18)(L_2_(L_4253_, 1, L_4253_.n)))
					for L_4255_forvar0 = 1, 1 do
						L_3460_func(18 + L_4255_forvar0 - 1, L_4254_[L_4255_forvar0])
					end
				end
				L_3460_func(21, L_3459_func(18))
				L_3460_func(22, 1)
				L_3460_func(23, true)
				do
					local L_4256_ = L_3459_func(12)
					L_3460_func(20, L_4256_)
					L_3460_func(19, L_4256_["find"])
				end
				do
					local L_4257_ = 4
					local L_4258_ = L_3462_func(20, L_4257_)
					local L_4259_ = L_1_(L_3459_func(19)(L_2_(L_4258_, 1, L_4258_.n)))
					for L_4260_forvar0 = 1, 1 do
						L_3460_func(19 + L_4260_forvar0 - 1, L_4259_[L_4260_forvar0])
					end
				end
				if not L_3459_func(19) then
					L_3463_ = 1660
				else
					L_3463_ = 1658
				end
			elseif L_3463_ == 1658 then

				L_3460_func(9, L_3459_func(17))
				L_3463_ = 1685
			elseif L_3463_ == 1660 then

				L_3460_func(19, L_3459_func(17)["aliases"])
				if not L_3459_func(19) then
					L_3463_ = 1683
				else
					L_3463_ = 1662
				end
			elseif L_3463_ == 1662 then

				L_3460_func(19, L_10_func(L_3453_arg1, "ipairs"))
				L_3460_func(20, L_3459_func(17)["aliases"])
				do
					local L_4261_ = 1
					local L_4262_ = L_3462_func(20, L_4261_)
					local L_4263_ = L_1_(L_3459_func(19)(L_2_(L_4262_, 1, L_4262_.n)))
					for L_4264_forvar0 = 1, 3 do
						L_3460_func(19 + L_4264_forvar0 - 1, L_4263_[L_4264_forvar0])
					end
				end
				L_3463_ = 1682
			elseif L_3463_ == 1666 then

				do
					local L_4265_ = L_3459_func(23)
					L_3460_func(25, L_4265_)
					L_3460_func(24, L_4265_["lower"])
				end
				do
					local L_4266_ = 1
					local L_4267_ = L_3462_func(25, L_4266_)
					local L_4268_ = L_1_(L_3459_func(24)(L_2_(L_4267_, 1, L_4267_.n)))
					for L_4269_forvar0 = 1, 1 do
						L_3460_func(24 + L_4269_forvar0 - 1, L_4268_[L_4269_forvar0])
					end
				end
				L_3460_func(25, #L_3459_func(24))
				L_3460_func(26, 3)
				L_3460_func(73, L_3459_func(26) <= L_3459_func(25))
				if not L_3459_func(73) then
					L_3463_ = 1682
				else
					L_3463_ = 1673
				end
			elseif L_3463_ == 1673 then

				L_3460_func(27, L_3459_func(24))
				L_3460_func(28, 1)
				L_3460_func(29, true)
				do
					local L_4270_ = L_3459_func(12)
					L_3460_func(26, L_4270_)
					L_3460_func(25, L_4270_["find"])
				end
				do
					local L_4271_ = 4
					local L_4272_ = L_3462_func(26, L_4271_)
					local L_4273_ = L_1_(L_3459_func(25)(L_2_(L_4272_, 1, L_4272_.n)))
					for L_4274_forvar0 = 1, 1 do
						L_3460_func(25 + L_4274_forvar0 - 1, L_4273_[L_4274_forvar0])
					end
				end
				if not L_3459_func(25) then
					L_3463_ = 1682
				else
					L_3463_ = 1679
				end
			elseif L_3463_ == 1679 then

				L_3460_func(9, L_3459_func(17))
				L_3463_ = 1683
			elseif L_3463_ == 1682 then

				if L_12_func(L_3459_func, L_3460_func, 19, 2) then
					L_3463_ = 1666
				else
					L_3463_ = 1683
				end
			elseif L_3463_ == 1683 then

				if L_3459_func(9) then
					L_3463_ = 1685
				else
					L_3463_ = 1684
				end
			elseif L_3463_ == 1684 then

				if L_12_func(L_3459_func, L_3460_func, 13, 2) then
					L_3463_ = 1648
				else
					L_3463_ = 1685
				end
			elseif L_3463_ == 1685 then

				if L_3459_func(9) then
					L_3463_ = 2104
				else
					L_3463_ = 1686
				end
			elseif L_3463_ == 1686 then

				L_3460_func(15, "bedwars")
				do
					local L_4275_ = L_3459_func(12)
					L_3460_func(14, L_4275_)
					L_3460_func(13, L_4275_["find"])
				end
				do
					local L_4276_ = 2
					local L_4277_ = L_3462_func(14, L_4276_)
					local L_4278_ = L_1_(L_3459_func(13)(L_2_(L_4277_, 1, L_4277_.n)))
					for L_4279_forvar0 = 1, 1 do
						L_3460_func(13 + L_4279_forvar0 - 1, L_4278_[L_4279_forvar0])
					end
				end
				if L_3459_func(13) then
					L_3463_ = 1696
				else
					L_3463_ = 1691
				end
			elseif L_3463_ == 1691 then

				L_3460_func(15, "bed wars")
				do
					local L_4280_ = L_3459_func(12)
					L_3460_func(14, L_4280_)
					L_3460_func(13, L_4280_["find"])
				end
				do
					local L_4281_ = 2
					local L_4282_ = L_3462_func(14, L_4281_)
					local L_4283_ = L_1_(L_3459_func(13)(L_2_(L_4282_, 1, L_4282_.n)))
					for L_4284_forvar0 = 1, 1 do
						L_3460_func(13 + L_4284_forvar0 - 1, L_4283_[L_4284_forvar0])
					end
				end
				if not L_3459_func(13) then
					L_3463_ = 1709
				else
					L_3463_ = 1696
				end
			elseif L_3463_ == 1696 then

				L_3460_func(13, L_10_func(L_3453_arg1, "ipairs"))
				L_3460_func(14, L_3459_func(8))
				do
					local L_4285_ = 1
					local L_4286_ = L_3462_func(14, L_4285_)
					local L_4287_ = L_1_(L_3459_func(13)(L_2_(L_4286_, 1, L_4286_.n)))
					for L_4288_forvar0 = 1, 3 do
						L_3460_func(13 + L_4288_forvar0 - 1, L_4287_[L_4288_forvar0])
					end
				end
				L_3463_ = 1707
			elseif L_3463_ == 1700 then

				L_3460_func(18, L_3459_func(17)["name"])
				L_3460_func(72, "BedWars")
				L_3460_func(73, L_3459_func(18) == L_3459_func(72))
				if not L_3459_func(73) then
					L_3463_ = 1707
				else
					L_3463_ = 1705
				end
			elseif L_3463_ == 1705 then

				L_3460_func(9, L_3459_func(17))
				L_3463_ = 2104
			elseif L_3463_ == 1707 then

				if L_12_func(L_3459_func, L_3460_func, 13, 2) then
					L_3463_ = 1700
				else
					L_3463_ = 1708
				end
			elseif L_3463_ == 1708 then

				L_3463_ = 2104
			elseif L_3463_ == 1709 then

				L_3460_func(15, "bedwars")
				do
					local L_4289_ = L_3459_func(12)
					L_3460_func(14, L_4289_)
					L_3460_func(13, L_4289_["find"])
				end
				do
					local L_4290_ = 2
					local L_4291_ = L_3462_func(14, L_4290_)
					local L_4292_ = L_1_(L_3459_func(13)(L_2_(L_4291_, 1, L_4291_.n)))
					for L_4293_forvar0 = 1, 1 do
						L_3460_func(13 + L_4293_forvar0 - 1, L_4292_[L_4293_forvar0])
					end
				end
				if L_3459_func(13) then
					L_3463_ = 1717
				else
					L_3463_ = 1713
				end
			elseif L_3463_ == 1713 then

				L_3460_func(15, "bed wars")
				do
					local L_4294_ = L_3459_func(12)
					L_3460_func(14, L_4294_)
					L_3460_func(13, L_4294_["find"])
				end
				do
					local L_4295_ = 2
					local L_4296_ = L_3462_func(14, L_4295_)
					local L_4297_ = L_1_(L_3459_func(13)(L_2_(L_4296_, 1, L_4296_.n)))
					for L_4298_forvar0 = 1, 1 do
						L_3460_func(13 + L_4298_forvar0 - 1, L_4297_[L_4298_forvar0])
					end
				end
				if not L_3459_func(13) then
					L_3463_ = 1730
				else
					L_3463_ = 1717
				end
			elseif L_3463_ == 1717 then

				L_3460_func(13, L_10_func(L_3453_arg1, "ipairs"))
				L_3460_func(14, L_3459_func(8))
				do
					local L_4299_ = 1
					local L_4300_ = L_3462_func(14, L_4299_)
					local L_4301_ = L_1_(L_3459_func(13)(L_2_(L_4300_, 1, L_4300_.n)))
					for L_4302_forvar0 = 1, 3 do
						L_3460_func(13 + L_4302_forvar0 - 1, L_4301_[L_4302_forvar0])
					end
				end
				L_3463_ = 1728
			elseif L_3463_ == 1721 then

				L_3460_func(18, L_3459_func(17)["name"])
				L_3460_func(72, "BedWars")
				L_3460_func(73, L_3459_func(18) == L_3459_func(72))
				if not L_3459_func(73) then
					L_3463_ = 1728
				else
					L_3463_ = 1725
				end
			elseif L_3463_ == 1725 then

				L_3460_func(9, L_3459_func(17))
				L_3463_ = 2104
			elseif L_3463_ == 1728 then

				if L_12_func(L_3459_func, L_3460_func, 13, 2) then
					L_3463_ = 1721
				else
					L_3463_ = 1729
				end
			elseif L_3463_ == 1729 then

				L_3463_ = 2104
			elseif L_3463_ == 1730 then

				L_3460_func(15, "blox fruit")
				do
					local L_4303_ = L_3459_func(12)
					L_3460_func(14, L_4303_)
					L_3460_func(13, L_4303_["find"])
				end
				do
					local L_4304_ = 2
					local L_4305_ = L_3462_func(14, L_4304_)
					local L_4306_ = L_1_(L_3459_func(13)(L_2_(L_4305_, 1, L_4305_.n)))
					for L_4307_forvar0 = 1, 1 do
						L_3460_func(13 + L_4307_forvar0 - 1, L_4306_[L_4307_forvar0])
					end
				end
				if L_3459_func(13) then
					L_3463_ = 1740
				else
					L_3463_ = 1735
				end
			elseif L_3463_ == 1735 then

				L_3460_func(15, "bloxfruit")
				do
					local L_4308_ = L_3459_func(12)
					L_3460_func(14, L_4308_)
					L_3460_func(13, L_4308_["find"])
				end
				do
					local L_4309_ = 2
					local L_4310_ = L_3462_func(14, L_4309_)
					local L_4311_ = L_1_(L_3459_func(13)(L_2_(L_4310_, 1, L_4310_.n)))
					for L_4312_forvar0 = 1, 1 do
						L_3460_func(13 + L_4312_forvar0 - 1, L_4311_[L_4312_forvar0])
					end
				end
				if not L_3459_func(13) then
					L_3463_ = 1752
				else
					L_3463_ = 1740
				end
			elseif L_3463_ == 1740 then

				L_3460_func(13, L_10_func(L_3453_arg1, "ipairs"))
				L_3460_func(14, L_3459_func(8))
				do
					local L_4313_ = 1
					local L_4314_ = L_3462_func(14, L_4313_)
					local L_4315_ = L_1_(L_3459_func(13)(L_2_(L_4314_, 1, L_4314_.n)))
					for L_4316_forvar0 = 1, 3 do
						L_3460_func(13 + L_4316_forvar0 - 1, L_4315_[L_4316_forvar0])
					end
				end
				L_3463_ = 1750
			elseif L_3463_ == 1744 then

				L_3460_func(18, L_3459_func(17)["name"])
				L_3460_func(72, "Blox Fruits")
				L_3460_func(73, L_3459_func(18) == L_3459_func(72))
				if not L_3459_func(73) then
					L_3463_ = 1750
				else
					L_3463_ = 1748
				end
			elseif L_3463_ == 1748 then

				L_3460_func(9, L_3459_func(17))
				L_3463_ = 2104
			elseif L_3463_ == 1750 then

				if L_12_func(L_3459_func, L_3460_func, 13, 2) then
					L_3463_ = 1744
				else
					L_3463_ = 1751
				end
			elseif L_3463_ == 1751 then

				L_3463_ = 2104
			elseif L_3463_ == 1752 then

				L_3460_func(15, "fish it")
				do
					local L_4317_ = L_3459_func(12)
					L_3460_func(14, L_4317_)
					L_3460_func(13, L_4317_["find"])
				end
				do
					local L_4318_ = 2
					local L_4319_ = L_3462_func(14, L_4318_)
					local L_4320_ = L_1_(L_3459_func(13)(L_2_(L_4319_, 1, L_4319_.n)))
					for L_4321_forvar0 = 1, 1 do
						L_3460_func(13 + L_4321_forvar0 - 1, L_4320_[L_4321_forvar0])
					end
				end
				if L_3459_func(13) then
					L_3463_ = 1766
				else
					L_3463_ = 1756
				end
			elseif L_3463_ == 1756 then

				L_3460_func(15, "fisch")
				do
					local L_4322_ = L_3459_func(12)
					L_3460_func(14, L_4322_)
					L_3460_func(13, L_4322_["find"])
				end
				do
					local L_4323_ = 2
					local L_4324_ = L_3462_func(14, L_4323_)
					local L_4325_ = L_1_(L_3459_func(13)(L_2_(L_4324_, 1, L_4324_.n)))
					for L_4326_forvar0 = 1, 1 do
						L_3460_func(13 + L_4326_forvar0 - 1, L_4325_[L_4326_forvar0])
					end
				end
				if L_3459_func(13) then
					L_3463_ = 1766
				else
					L_3463_ = 1761
				end
			elseif L_3463_ == 1761 then

				L_3460_func(15, "fishit")
				do
					local L_4327_ = L_3459_func(12)
					L_3460_func(14, L_4327_)
					L_3460_func(13, L_4327_["find"])
				end
				do
					local L_4328_ = 2
					local L_4329_ = L_3462_func(14, L_4328_)
					local L_4330_ = L_1_(L_3459_func(13)(L_2_(L_4329_, 1, L_4329_.n)))
					for L_4331_forvar0 = 1, 1 do
						L_3460_func(13 + L_4331_forvar0 - 1, L_4330_[L_4331_forvar0])
					end
				end
				if not L_3459_func(13) then
					L_3463_ = 1779
				else
					L_3463_ = 1766
				end
			elseif L_3463_ == 1766 then

				L_3460_func(13, L_10_func(L_3453_arg1, "ipairs"))
				L_3460_func(14, L_3459_func(8))
				do
					local L_4332_ = 1
					local L_4333_ = L_3462_func(14, L_4332_)
					local L_4334_ = L_1_(L_3459_func(13)(L_2_(L_4333_, 1, L_4333_.n)))
					for L_4335_forvar0 = 1, 3 do
						L_3460_func(13 + L_4335_forvar0 - 1, L_4334_[L_4335_forvar0])
					end
				end
				L_3463_ = 1777
			elseif L_3463_ == 1771 then

				L_3460_func(18, L_3459_func(17)["name"])
				L_3460_func(72, "Fish It")
				L_3460_func(73, L_3459_func(18) == L_3459_func(72))
				if not L_3459_func(73) then
					L_3463_ = 1777
				else
					L_3463_ = 1775
				end
			elseif L_3463_ == 1775 then

				L_3460_func(9, L_3459_func(17))
				L_3463_ = 2104
			elseif L_3463_ == 1777 then

				if L_12_func(L_3459_func, L_3460_func, 13, 2) then
					L_3463_ = 1771
				else
					L_3463_ = 1778
				end
			elseif L_3463_ == 1778 then

				L_3463_ = 2104
			elseif L_3463_ == 1779 then

				L_3460_func(15, "steal a brainrot")
				do
					local L_4336_ = L_3459_func(12)
					L_3460_func(14, L_4336_)
					L_3460_func(13, L_4336_["find"])
				end
				do
					local L_4337_ = 2
					local L_4338_ = L_3462_func(14, L_4337_)
					local L_4339_ = L_1_(L_3459_func(13)(L_2_(L_4338_, 1, L_4338_.n)))
					for L_4340_forvar0 = 1, 1 do
						L_3460_func(13 + L_4340_forvar0 - 1, L_4339_[L_4340_forvar0])
					end
				end
				if L_3459_func(13) then
					L_3463_ = 1787
				else
					L_3463_ = 1783
				end
			elseif L_3463_ == 1783 then

				L_3460_func(15, "sab")
				do
					local L_4341_ = L_3459_func(12)
					L_3460_func(14, L_4341_)
					L_3460_func(13, L_4341_["find"])
				end
				do
					local L_4342_ = 2
					local L_4343_ = L_3462_func(14, L_4342_)
					local L_4344_ = L_1_(L_3459_func(13)(L_2_(L_4343_, 1, L_4343_.n)))
					for L_4345_forvar0 = 1, 1 do
						L_3460_func(13 + L_4345_forvar0 - 1, L_4344_[L_4345_forvar0])
					end
				end
				if not L_3459_func(13) then
					L_3463_ = 1800
				else
					L_3463_ = 1787
				end
			elseif L_3463_ == 1787 then

				L_3460_func(13, L_10_func(L_3453_arg1, "ipairs"))
				L_3460_func(14, L_3459_func(8))
				do
					local L_4346_ = 1
					local L_4347_ = L_3462_func(14, L_4346_)
					local L_4348_ = L_1_(L_3459_func(13)(L_2_(L_4347_, 1, L_4347_.n)))
					for L_4349_forvar0 = 1, 3 do
						L_3460_func(13 + L_4349_forvar0 - 1, L_4348_[L_4349_forvar0])
					end
				end
				L_3463_ = 1798
			elseif L_3463_ == 1791 then

				L_3460_func(18, L_3459_func(17)["name"])
				L_3463_ = 1792
			else
				error("invalid recovered basic block in main: " .. tostring(L_3463_))
			end
		elseif L_3475_ == 7 then
			if L_3463_ == 1792 then

				L_3460_func(72, "SAB")
				L_3460_func(73, L_3459_func(18) == L_3459_func(72))
				if not L_3459_func(73) then
					L_3463_ = 1798
				else
					L_3463_ = 1796
				end
			elseif L_3463_ == 1796 then

				L_3460_func(9, L_3459_func(17))
				L_3463_ = 2104
			elseif L_3463_ == 1798 then

				if L_12_func(L_3459_func, L_3460_func, 13, 2) then
					L_3463_ = 1791
				else
					L_3463_ = 1799
				end
			elseif L_3463_ == 1799 then

				L_3463_ = 2104
			elseif L_3463_ == 1800 then

				L_3460_func(15, "forsaken")
				do
					local L_4350_ = L_3459_func(12)
					L_3460_func(14, L_4350_)
					L_3460_func(13, L_4350_["find"])
				end
				do
					local L_4351_ = 2
					local L_4352_ = L_3462_func(14, L_4351_)
					local L_4353_ = L_1_(L_3459_func(13)(L_2_(L_4352_, 1, L_4352_.n)))
					for L_4354_forvar0 = 1, 1 do
						L_3460_func(13 + L_4354_forvar0 - 1, L_4353_[L_4354_forvar0])
					end
				end
				if not L_3459_func(13) then
					L_3463_ = 1818
				else
					L_3463_ = 1804
				end
			elseif L_3463_ == 1804 then

				L_3460_func(13, L_10_func(L_3453_arg1, "ipairs"))
				L_3460_func(14, L_3459_func(8))
				do
					local L_4355_ = 1
					local L_4356_ = L_3462_func(14, L_4355_)
					local L_4357_ = L_1_(L_3459_func(13)(L_2_(L_4356_, 1, L_4356_.n)))
					for L_4358_forvar0 = 1, 3 do
						L_3460_func(13 + L_4358_forvar0 - 1, L_4357_[L_4358_forvar0])
					end
				end
				L_3463_ = 1816
			elseif L_3463_ == 1809 then

				L_3460_func(18, L_3459_func(17)["name"])
				L_3460_func(72, "Forsaken")
				L_3460_func(73, L_3459_func(18) == L_3459_func(72))
				if not L_3459_func(73) then
					L_3463_ = 1816
				else
					L_3463_ = 1814
				end
			elseif L_3463_ == 1814 then

				L_3460_func(9, L_3459_func(17))
				L_3463_ = 2104
			elseif L_3463_ == 1816 then

				if L_12_func(L_3459_func, L_3460_func, 13, 2) then
					L_3463_ = 1809
				else
					L_3463_ = 1817
				end
			elseif L_3463_ == 1817 then

				L_3463_ = 2104
			elseif L_3463_ == 1818 then

				L_3460_func(15, "volley")
				do
					local L_4359_ = L_3459_func(12)
					L_3460_func(14, L_4359_)
					L_3460_func(13, L_4359_["find"])
				end
				do
					local L_4360_ = 2
					local L_4361_ = L_3462_func(14, L_4360_)
					local L_4362_ = L_1_(L_3459_func(13)(L_2_(L_4361_, 1, L_4361_.n)))
					for L_4363_forvar0 = 1, 1 do
						L_3460_func(13 + L_4363_forvar0 - 1, L_4362_[L_4363_forvar0])
					end
				end
				if not L_3459_func(13) then
					L_3463_ = 1837
				else
					L_3463_ = 1822
				end
			elseif L_3463_ == 1822 then

				L_3460_func(13, L_10_func(L_3453_arg1, "ipairs"))
				L_3460_func(14, L_3459_func(8))
				do
					local L_4364_ = 1
					local L_4365_ = L_3462_func(14, L_4364_)
					local L_4366_ = L_1_(L_3459_func(13)(L_2_(L_4365_, 1, L_4365_.n)))
					for L_4367_forvar0 = 1, 3 do
						L_3460_func(13 + L_4367_forvar0 - 1, L_4366_[L_4367_forvar0])
					end
				end
				L_3463_ = 1835
			elseif L_3463_ == 1827 then

				L_3460_func(18, L_3459_func(17)["name"])
				L_3460_func(72, "Volley Ball Legends")
				L_3460_func(73, L_3459_func(18) == L_3459_func(72))
				if not L_3459_func(73) then
					L_3463_ = 1835
				else
					L_3463_ = 1832
				end
			elseif L_3463_ == 1832 then

				L_3460_func(9, L_3459_func(17))
				L_3463_ = 2104
			elseif L_3463_ == 1835 then

				if L_12_func(L_3459_func, L_3460_func, 13, 2) then
					L_3463_ = 1827
				else
					L_3463_ = 1836
				end
			elseif L_3463_ == 1836 then

				L_3463_ = 2104
			elseif L_3463_ == 1837 then

				L_3460_func(15, "speed keyboard")
				do
					local L_4368_ = L_3459_func(12)
					L_3460_func(14, L_4368_)
					L_3460_func(13, L_4368_["find"])
				end
				do
					local L_4369_ = 2
					local L_4370_ = L_3462_func(14, L_4369_)
					local L_4371_ = L_1_(L_3459_func(13)(L_2_(L_4370_, 1, L_4370_.n)))
					for L_4372_forvar0 = 1, 1 do
						L_3460_func(13 + L_4372_forvar0 - 1, L_4371_[L_4372_forvar0])
					end
				end
				if L_3459_func(13) then
					L_3463_ = 1846
				else
					L_3463_ = 1842
				end
			elseif L_3463_ == 1842 then

				L_3460_func(15, "keyboard escape")
				do
					local L_4373_ = L_3459_func(12)
					L_3460_func(14, L_4373_)
					L_3460_func(13, L_4373_["find"])
				end
				do
					local L_4374_ = 2
					local L_4375_ = L_3462_func(14, L_4374_)
					local L_4376_ = L_1_(L_3459_func(13)(L_2_(L_4375_, 1, L_4375_.n)))
					for L_4377_forvar0 = 1, 1 do
						L_3460_func(13 + L_4377_forvar0 - 1, L_4376_[L_4377_forvar0])
					end
				end
				if not L_3459_func(13) then
					L_3463_ = 1860
				else
					L_3463_ = 1846
				end
			elseif L_3463_ == 1846 then

				L_3460_func(13, L_10_func(L_3453_arg1, "ipairs"))
				L_3460_func(14, L_3459_func(8))
				do
					local L_4378_ = 1
					local L_4379_ = L_3462_func(14, L_4378_)
					local L_4380_ = L_1_(L_3459_func(13)(L_2_(L_4379_, 1, L_4379_.n)))
					for L_4381_forvar0 = 1, 3 do
						L_3460_func(13 + L_4381_forvar0 - 1, L_4380_[L_4381_forvar0])
					end
				end
				L_3463_ = 1858
			elseif L_3463_ == 1850 then

				L_3460_func(18, L_3459_func(17)["name"])
				L_3460_func(72, "Speed Keyboard Escape")
				L_3460_func(73, L_3459_func(18) == L_3459_func(72))
				if not L_3459_func(73) then
					L_3463_ = 1858
				else
					L_3463_ = 1855
				end
			elseif L_3463_ == 1855 then

				L_3460_func(9, L_3459_func(17))
				L_3463_ = 2104
			elseif L_3463_ == 1858 then

				if L_12_func(L_3459_func, L_3460_func, 13, 2) then
					L_3463_ = 1850
				else
					L_3463_ = 1859
				end
			elseif L_3463_ == 1859 then

				L_3463_ = 2104
			elseif L_3463_ == 1860 then

				L_3460_func(15, "speed monkey")
				do
					local L_4382_ = L_3459_func(12)
					L_3460_func(14, L_4382_)
					L_3460_func(13, L_4382_["find"])
				end
				do
					local L_4383_ = 2
					local L_4384_ = L_3462_func(14, L_4383_)
					local L_4385_ = L_1_(L_3459_func(13)(L_2_(L_4384_, 1, L_4384_.n)))
					for L_4386_forvar0 = 1, 1 do
						L_3460_func(13 + L_4386_forvar0 - 1, L_4385_[L_4386_forvar0])
					end
				end
				if L_3459_func(13) then
					L_3463_ = 1874
				else
					L_3463_ = 1864
				end
			elseif L_3463_ == 1864 then

				L_3460_func(15, "monkey escape")
				do
					local L_4387_ = L_3459_func(12)
					L_3460_func(14, L_4387_)
					L_3460_func(13, L_4387_["find"])
				end
				do
					local L_4388_ = 2
					local L_4389_ = L_3462_func(14, L_4388_)
					local L_4390_ = L_1_(L_3459_func(13)(L_2_(L_4389_, 1, L_4389_.n)))
					for L_4391_forvar0 = 1, 1 do
						L_3460_func(13 + L_4391_forvar0 - 1, L_4390_[L_4391_forvar0])
					end
				end
				if L_3459_func(13) then
					L_3463_ = 1874
				else
					L_3463_ = 1868
				end
			elseif L_3463_ == 1868 then

				L_3460_func(15, "monkey")
				do
					local L_4392_ = L_3459_func(12)
					L_3460_func(14, L_4392_)
					L_3460_func(13, L_4392_["find"])
				end
				do
					local L_4393_ = 2
					local L_4394_ = L_3462_func(14, L_4393_)
					local L_4395_ = L_1_(L_3459_func(13)(L_2_(L_4394_, 1, L_4394_.n)))
					for L_4396_forvar0 = 1, 1 do
						L_3460_func(13 + L_4396_forvar0 - 1, L_4395_[L_4396_forvar0])
					end
				end
				if not L_3459_func(13) then
					L_3463_ = 1888
				else
					L_3463_ = 1874
				end
			elseif L_3463_ == 1874 then

				L_3460_func(13, L_10_func(L_3453_arg1, "ipairs"))
				L_3460_func(14, L_3459_func(8))
				do
					local L_4397_ = 1
					local L_4398_ = L_3462_func(14, L_4397_)
					local L_4399_ = L_1_(L_3459_func(13)(L_2_(L_4398_, 1, L_4398_.n)))
					for L_4400_forvar0 = 1, 3 do
						L_3460_func(13 + L_4400_forvar0 - 1, L_4399_[L_4400_forvar0])
					end
				end
				L_3463_ = 1886
			elseif L_3463_ == 1880 then

				L_3460_func(18, L_3459_func(17)["name"])
				L_3460_func(72, "Speed Monkey Escape")
				L_3460_func(73, L_3459_func(18) == L_3459_func(72))
				if not L_3459_func(73) then
					L_3463_ = 1886
				else
					L_3463_ = 1884
				end
			elseif L_3463_ == 1884 then

				L_3460_func(9, L_3459_func(17))
				L_3463_ = 2104
			elseif L_3463_ == 1886 then

				if L_12_func(L_3459_func, L_3460_func, 13, 2) then
					L_3463_ = 1880
				else
					L_3463_ = 1887
				end
			elseif L_3463_ == 1887 then

				L_3463_ = 2104
			elseif L_3463_ == 1888 then

				L_3460_func(15, "anime expedition")
				do
					local L_4401_ = L_3459_func(12)
					L_3460_func(14, L_4401_)
					L_3460_func(13, L_4401_["find"])
				end
				do
					local L_4402_ = 2
					local L_4403_ = L_3462_func(14, L_4402_)
					local L_4404_ = L_1_(L_3459_func(13)(L_2_(L_4403_, 1, L_4403_.n)))
					for L_4405_forvar0 = 1, 1 do
						L_3460_func(13 + L_4405_forvar0 - 1, L_4404_[L_4405_forvar0])
					end
				end
				if L_3459_func(13) then
					L_3463_ = 1896
				else
					L_3463_ = 1892
				end
			elseif L_3463_ == 1892 then

				L_3460_func(15, "expedition")
				do
					local L_4406_ = L_3459_func(12)
					L_3460_func(14, L_4406_)
					L_3460_func(13, L_4406_["find"])
				end
				do
					local L_4407_ = 2
					local L_4408_ = L_3462_func(14, L_4407_)
					local L_4409_ = L_1_(L_3459_func(13)(L_2_(L_4408_, 1, L_4408_.n)))
					for L_4410_forvar0 = 1, 1 do
						L_3460_func(13 + L_4410_forvar0 - 1, L_4409_[L_4410_forvar0])
					end
				end
				if not L_3459_func(13) then
					L_3463_ = 1908
				else
					L_3463_ = 1896
				end
			elseif L_3463_ == 1896 then

				L_3460_func(13, L_10_func(L_3453_arg1, "ipairs"))
				L_3460_func(14, L_3459_func(8))
				do
					local L_4411_ = 1
					local L_4412_ = L_3462_func(14, L_4411_)
					local L_4413_ = L_1_(L_3459_func(13)(L_2_(L_4412_, 1, L_4412_.n)))
					for L_4414_forvar0 = 1, 3 do
						L_3460_func(13 + L_4414_forvar0 - 1, L_4413_[L_4414_forvar0])
					end
				end
				L_3463_ = 1906
			elseif L_3463_ == 1900 then

				L_3460_func(18, L_3459_func(17)["name"])
				L_3460_func(72, "Anime Expeditions")
				L_3460_func(73, L_3459_func(18) == L_3459_func(72))
				if not L_3459_func(73) then
					L_3463_ = 1906
				else
					L_3463_ = 1904
				end
			elseif L_3463_ == 1904 then

				L_3460_func(9, L_3459_func(17))
				L_3463_ = 2104
			elseif L_3463_ == 1906 then

				if L_12_func(L_3459_func, L_3460_func, 13, 2) then
					L_3463_ = 1900
				else
					L_3463_ = 1907
				end
			elseif L_3463_ == 1907 then

				L_3463_ = 2104
			elseif L_3463_ == 1908 then

				L_3460_func(15, "merge a nuke")
				do
					local L_4415_ = L_3459_func(12)
					L_3460_func(14, L_4415_)
					L_3460_func(13, L_4415_["find"])
				end
				do
					local L_4416_ = 2
					local L_4417_ = L_3462_func(14, L_4416_)
					local L_4418_ = L_1_(L_3459_func(13)(L_2_(L_4417_, 1, L_4417_.n)))
					for L_4419_forvar0 = 1, 1 do
						L_3460_func(13 + L_4419_forvar0 - 1, L_4418_[L_4419_forvar0])
					end
				end
				if L_3459_func(13) then
					L_3463_ = 1917
				else
					L_3463_ = 1913
				end
			elseif L_3463_ == 1913 then

				L_3460_func(15, "merge nuke")
				do
					local L_4420_ = L_3459_func(12)
					L_3460_func(14, L_4420_)
					L_3460_func(13, L_4420_["find"])
				end
				do
					local L_4421_ = 2
					local L_4422_ = L_3462_func(14, L_4421_)
					local L_4423_ = L_1_(L_3459_func(13)(L_2_(L_4422_, 1, L_4422_.n)))
					for L_4424_forvar0 = 1, 1 do
						L_3460_func(13 + L_4424_forvar0 - 1, L_4423_[L_4424_forvar0])
					end
				end
				if not L_3459_func(13) then
					L_3463_ = 1931
				else
					L_3463_ = 1917
				end
			elseif L_3463_ == 1917 then

				L_3460_func(13, L_10_func(L_3453_arg1, "ipairs"))
				L_3460_func(14, L_3459_func(8))
				do
					local L_4425_ = 1
					local L_4426_ = L_3462_func(14, L_4425_)
					local L_4427_ = L_1_(L_3459_func(13)(L_2_(L_4426_, 1, L_4426_.n)))
					for L_4428_forvar0 = 1, 3 do
						L_3460_func(13 + L_4428_forvar0 - 1, L_4427_[L_4428_forvar0])
					end
				end
				L_3463_ = 1929
			elseif L_3463_ == 1922 then

				L_3460_func(18, L_3459_func(17)["name"])
				L_3460_func(72, "Merge a Nuke")
				L_3460_func(73, L_3459_func(18) == L_3459_func(72))
				if not L_3459_func(73) then
					L_3463_ = 1929
				else
					L_3463_ = 1926
				end
			elseif L_3463_ == 1926 then

				L_3460_func(9, L_3459_func(17))
				L_3463_ = 2104
			elseif L_3463_ == 1929 then

				if L_12_func(L_3459_func, L_3460_func, 13, 2) then
					L_3463_ = 1922
				else
					L_3463_ = 1930
				end
			elseif L_3463_ == 1930 then

				L_3463_ = 2104
			elseif L_3463_ == 1931 then

				L_3460_func(15, "pickaxe")
				do
					local L_4429_ = L_3459_func(12)
					L_3460_func(14, L_4429_)
					L_3460_func(13, L_4429_["find"])
				end
				do
					local L_4430_ = 2
					local L_4431_ = L_3462_func(14, L_4430_)
					local L_4432_ = L_1_(L_3459_func(13)(L_2_(L_4431_, 1, L_4431_.n)))
					for L_4433_forvar0 = 1, 1 do
						L_3460_func(13 + L_4433_forvar0 - 1, L_4432_[L_4433_forvar0])
					end
				end
				if not L_3459_func(13) then
					L_3463_ = 1949
				else
					L_3463_ = 1935
				end
			elseif L_3463_ == 1935 then

				L_3460_func(13, L_10_func(L_3453_arg1, "ipairs"))
				L_3460_func(14, L_3459_func(8))
				do
					local L_4434_ = 1
					local L_4435_ = L_3462_func(14, L_4434_)
					local L_4436_ = L_1_(L_3459_func(13)(L_2_(L_4435_, 1, L_4435_.n)))
					for L_4437_forvar0 = 1, 3 do
						L_3460_func(13 + L_4437_forvar0 - 1, L_4436_[L_4437_forvar0])
					end
				end
				L_3463_ = 1946
			elseif L_3463_ == 1940 then

				L_3460_func(18, L_3459_func(17)["name"])
				L_3460_func(72, "+1 Pickaxe Swing Escape")
				L_3460_func(73, L_3459_func(18) == L_3459_func(72))
				if not L_3459_func(73) then
					L_3463_ = 1946
				else
					L_3463_ = 1944
				end
			elseif L_3463_ == 1944 then

				L_3460_func(9, L_3459_func(17))
				L_3463_ = 2104
			elseif L_3463_ == 1946 then

				if L_12_func(L_3459_func, L_3460_func, 13, 2) then
					L_3463_ = 1940
				else
					L_3463_ = 1947
				end
			elseif L_3463_ == 1947 then

				L_3463_ = 2104
			elseif L_3463_ == 1949 then

				L_3460_func(15, "grow a garden")
				do
					local L_4438_ = L_3459_func(12)
					L_3460_func(14, L_4438_)
					L_3460_func(13, L_4438_["find"])
				end
				do
					local L_4439_ = 2
					local L_4440_ = L_3462_func(14, L_4439_)
					local L_4441_ = L_1_(L_3459_func(13)(L_2_(L_4440_, 1, L_4440_.n)))
					for L_4442_forvar0 = 1, 1 do
						L_3460_func(13 + L_4442_forvar0 - 1, L_4441_[L_4442_forvar0])
					end
				end
				if L_3459_func(13) then
					L_3463_ = 1961
				else
					L_3463_ = 1955
				end
			elseif L_3463_ == 1955 then

				L_3460_func(15, "gag2")
				do
					local L_4443_ = L_3459_func(12)
					L_3460_func(14, L_4443_)
					L_3460_func(13, L_4443_["find"])
				end
				do
					local L_4444_ = 2
					local L_4445_ = L_3462_func(14, L_4444_)
					local L_4446_ = L_1_(L_3459_func(13)(L_2_(L_4445_, 1, L_4445_.n)))
					for L_4447_forvar0 = 1, 1 do
						L_3460_func(13 + L_4447_forvar0 - 1, L_4446_[L_4447_forvar0])
					end
				end
				if not L_3459_func(13) then
					L_3463_ = 1975
				else
					L_3463_ = 1961
				end
			elseif L_3463_ == 1961 then

				L_3460_func(13, L_10_func(L_3453_arg1, "ipairs"))
				L_3460_func(14, L_3459_func(8))
				do
					local L_4448_ = 1
					local L_4449_ = L_3462_func(14, L_4448_)
					local L_4450_ = L_1_(L_3459_func(13)(L_2_(L_4449_, 1, L_4449_.n)))
					for L_4451_forvar0 = 1, 3 do
						L_3460_func(13 + L_4451_forvar0 - 1, L_4450_[L_4451_forvar0])
					end
				end
				L_3463_ = 1973
			elseif L_3463_ == 1965 then

				L_3460_func(18, L_3459_func(17)["name"])
				L_3460_func(72, "Grow a Garden 2")
				L_3460_func(73, L_3459_func(18) == L_3459_func(72))
				if not L_3459_func(73) then
					L_3463_ = 1973
				else
					L_3463_ = 1971
				end
			elseif L_3463_ == 1971 then

				L_3460_func(9, L_3459_func(17))
				L_3463_ = 2104
			elseif L_3463_ == 1973 then

				if L_12_func(L_3459_func, L_3460_func, 13, 2) then
					L_3463_ = 1965
				else
					L_3463_ = 1974
				end
			elseif L_3463_ == 1974 then

				L_3463_ = 2104
			elseif L_3463_ == 1975 then

				L_3460_func(15, "animal hospital")
				do
					local L_4452_ = L_3459_func(12)
					L_3460_func(14, L_4452_)
					L_3460_func(13, L_4452_["find"])
				end
				do
					local L_4453_ = 2
					local L_4454_ = L_3462_func(14, L_4453_)
					local L_4455_ = L_1_(L_3459_func(13)(L_2_(L_4454_, 1, L_4454_.n)))
					for L_4456_forvar0 = 1, 1 do
						L_3460_func(13 + L_4456_forvar0 - 1, L_4455_[L_4456_forvar0])
					end
				end
				if L_3459_func(13) then
					L_3463_ = 1985
				else
					L_3463_ = 1979
				end
			elseif L_3463_ == 1979 then

				L_3460_func(15, "hospital")
				do
					local L_4457_ = L_3459_func(12)
					L_3460_func(14, L_4457_)
					L_3460_func(13, L_4457_["find"])
				end
				do
					local L_4458_ = 2
					local L_4459_ = L_3462_func(14, L_4458_)
					local L_4460_ = L_1_(L_3459_func(13)(L_2_(L_4459_, 1, L_4459_.n)))
					for L_4461_forvar0 = 1, 1 do
						L_3460_func(13 + L_4461_forvar0 - 1, L_4460_[L_4461_forvar0])
					end
				end
				if not L_3459_func(13) then
					L_3463_ = 1999
				else
					L_3463_ = 1985
				end
			elseif L_3463_ == 1985 then

				L_3460_func(13, L_10_func(L_3453_arg1, "ipairs"))
				L_3460_func(14, L_3459_func(8))
				do
					local L_4462_ = 1
					local L_4463_ = L_3462_func(14, L_4462_)
					local L_4464_ = L_1_(L_3459_func(13)(L_2_(L_4463_, 1, L_4463_.n)))
					for L_4465_forvar0 = 1, 3 do
						L_3460_func(13 + L_4465_forvar0 - 1, L_4464_[L_4465_forvar0])
					end
				end
				L_3463_ = 1997
			elseif L_3463_ == 1990 then

				L_3460_func(18, L_3459_func(17)["name"])
				L_3460_func(72, "Animal Hospital")
				L_3460_func(73, L_3459_func(18) == L_3459_func(72))
				if not L_3459_func(73) then
					L_3463_ = 1997
				else
					L_3463_ = 1995
				end
			elseif L_3463_ == 1995 then

				L_3460_func(9, L_3459_func(17))
				L_3463_ = 2104
			elseif L_3463_ == 1997 then

				if L_12_func(L_3459_func, L_3460_func, 13, 2) then
					L_3463_ = 1990
				else
					L_3463_ = 1998
				end
			elseif L_3463_ == 1998 then

				L_3463_ = 2104
			elseif L_3463_ == 1999 then

				L_3460_func(15, "prison life")
				do
					local L_4466_ = L_3459_func(12)
					L_3460_func(14, L_4466_)
					L_3460_func(13, L_4466_["find"])
				end
				do
					local L_4467_ = 2
					local L_4468_ = L_3462_func(14, L_4467_)
					local L_4469_ = L_1_(L_3459_func(13)(L_2_(L_4468_, 1, L_4468_.n)))
					for L_4470_forvar0 = 1, 1 do
						L_3460_func(13 + L_4470_forvar0 - 1, L_4469_[L_4470_forvar0])
					end
				end
				if L_3459_func(13) then
					L_3463_ = 2009
				else
					L_3463_ = 2005
				end
			elseif L_3463_ == 2005 then

				L_3460_func(15, "prison")
				do
					local L_4471_ = L_3459_func(12)
					L_3460_func(14, L_4471_)
					L_3460_func(13, L_4471_["find"])
				end
				do
					local L_4472_ = 2
					local L_4473_ = L_3462_func(14, L_4472_)
					local L_4474_ = L_1_(L_3459_func(13)(L_2_(L_4473_, 1, L_4473_.n)))
					for L_4475_forvar0 = 1, 1 do
						L_3460_func(13 + L_4475_forvar0 - 1, L_4474_[L_4475_forvar0])
					end
				end
				if not L_3459_func(13) then
					L_3463_ = 2021
				else
					L_3463_ = 2009
				end
			elseif L_3463_ == 2009 then

				L_3460_func(13, L_10_func(L_3453_arg1, "ipairs"))
				L_3460_func(14, L_3459_func(8))
				do
					local L_4476_ = 1
					local L_4477_ = L_3462_func(14, L_4476_)
					local L_4478_ = L_1_(L_3459_func(13)(L_2_(L_4477_, 1, L_4477_.n)))
					for L_4479_forvar0 = 1, 3 do
						L_3460_func(13 + L_4479_forvar0 - 1, L_4478_[L_4479_forvar0])
					end
				end
				L_3463_ = 2019
			elseif L_3463_ == 2013 then

				L_3460_func(18, L_3459_func(17)["name"])
				L_3460_func(72, "Prison Life")
				L_3460_func(73, L_3459_func(18) == L_3459_func(72))
				if not L_3459_func(73) then
					L_3463_ = 2019
				else
					L_3463_ = 2017
				end
			elseif L_3463_ == 2017 then

				L_3460_func(9, L_3459_func(17))
				L_3463_ = 2104
			elseif L_3463_ == 2019 then

				if L_12_func(L_3459_func, L_3460_func, 13, 2) then
					L_3463_ = 2013
				else
					L_3463_ = 2020
				end
			elseif L_3463_ == 2020 then

				L_3463_ = 2104
			elseif L_3463_ == 2021 then

				L_3460_func(15, "da hood")
				do
					local L_4480_ = L_3459_func(12)
					L_3460_func(14, L_4480_)
					L_3460_func(13, L_4480_["find"])
				end
				do
					local L_4481_ = 2
					local L_4482_ = L_3462_func(14, L_4481_)
					local L_4483_ = L_1_(L_3459_func(13)(L_2_(L_4482_, 1, L_4482_.n)))
					for L_4484_forvar0 = 1, 1 do
						L_3460_func(13 + L_4484_forvar0 - 1, L_4483_[L_4484_forvar0])
					end
				end
				if L_3459_func(13) then
					L_3463_ = 2030
				else
					L_3463_ = 2026
				end
			elseif L_3463_ == 2026 then

				L_3460_func(15, "dahood")
				do
					local L_4485_ = L_3459_func(12)
					L_3460_func(14, L_4485_)
					L_3460_func(13, L_4485_["find"])
				end
				do
					local L_4486_ = 2
					local L_4487_ = L_3462_func(14, L_4486_)
					local L_4488_ = L_1_(L_3459_func(13)(L_2_(L_4487_, 1, L_4487_.n)))
					for L_4489_forvar0 = 1, 1 do
						L_3460_func(13 + L_4489_forvar0 - 1, L_4488_[L_4489_forvar0])
					end
				end
				if not L_3459_func(13) then
					L_3463_ = 2043
				else
					L_3463_ = 2030
				end
			elseif L_3463_ == 2030 then

				L_3460_func(13, L_10_func(L_3453_arg1, "ipairs"))
				L_3460_func(14, L_3459_func(8))
				do
					local L_4490_ = 1
					local L_4491_ = L_3462_func(14, L_4490_)
					local L_4492_ = L_1_(L_3459_func(13)(L_2_(L_4491_, 1, L_4491_.n)))
					for L_4493_forvar0 = 1, 3 do
						L_3460_func(13 + L_4493_forvar0 - 1, L_4492_[L_4493_forvar0])
					end
				end
				L_3463_ = 2041
			elseif L_3463_ == 2034 then

				L_3460_func(18, L_3459_func(17)["name"])
				L_3460_func(72, "Da Hood")
				L_3460_func(73, L_3459_func(18) == L_3459_func(72))
				if not L_3459_func(73) then
					L_3463_ = 2041
				else
					L_3463_ = 2038
				end
			elseif L_3463_ == 2038 then

				L_3460_func(9, L_3459_func(17))
				L_3463_ = 2104
			elseif L_3463_ == 2041 then

				if L_12_func(L_3459_func, L_3460_func, 13, 2) then
					L_3463_ = 2034
				else
					L_3463_ = 2042
				end
			elseif L_3463_ == 2042 then

				L_3463_ = 2104
			elseif L_3463_ == 2043 then

				L_3460_func(15, "bloxstrike")
				do
					local L_4494_ = L_3459_func(12)
					L_3460_func(14, L_4494_)
					L_3460_func(13, L_4494_["find"])
				end
				do
					local L_4495_ = 2
					local L_4496_ = L_3462_func(14, L_4495_)
					local L_4497_ = L_1_(L_3459_func(13)(L_2_(L_4496_, 1, L_4496_.n)))
					for L_4498_forvar0 = 1, 1 do
						L_3460_func(13 + L_4498_forvar0 - 1, L_4497_[L_4498_forvar0])
					end
				end
				if L_3459_func(13) then
					L_3463_ = 2051
				else
					L_3463_ = 2047
				end
			elseif L_3463_ == 2047 then

				L_3460_func(15, "blox strike")
				L_3463_ = 2048
			else
				error("invalid recovered basic block in main: " .. tostring(L_3463_))
			end
		elseif L_3475_ == 8 then
			if L_3463_ == 2048 then

				do
					local L_4499_ = L_3459_func(12)
					L_3460_func(14, L_4499_)
					L_3460_func(13, L_4499_["find"])
				end
				do
					local L_4500_ = 2
					local L_4501_ = L_3462_func(14, L_4500_)
					local L_4502_ = L_1_(L_3459_func(13)(L_2_(L_4501_, 1, L_4501_.n)))
					for L_4503_forvar0 = 1, 1 do
						L_3460_func(13 + L_4503_forvar0 - 1, L_4502_[L_4503_forvar0])
					end
				end
				if not L_3459_func(13) then
					L_3463_ = 2067
				else
					L_3463_ = 2051
				end
			elseif L_3463_ == 2051 then

				L_3460_func(13, L_10_func(L_3453_arg1, "ipairs"))
				L_3460_func(14, L_3459_func(8))
				do
					local L_4504_ = 1
					local L_4505_ = L_3462_func(14, L_4504_)
					local L_4506_ = L_1_(L_3459_func(13)(L_2_(L_4505_, 1, L_4505_.n)))
					for L_4507_forvar0 = 1, 3 do
						L_3460_func(13 + L_4507_forvar0 - 1, L_4506_[L_4507_forvar0])
					end
				end
				L_3463_ = 2064
			elseif L_3463_ == 2056 then

				L_3460_func(18, L_3459_func(17)["name"])
				L_3460_func(72, "BloxStrike")
				L_3460_func(73, L_3459_func(18) == L_3459_func(72))
				if not L_3459_func(73) then
					L_3463_ = 2064
				else
					L_3463_ = 2062
				end
			elseif L_3463_ == 2062 then

				L_3460_func(9, L_3459_func(17))
				L_3463_ = 2104
			elseif L_3463_ == 2064 then

				if L_12_func(L_3459_func, L_3460_func, 13, 2) then
					L_3463_ = 2056
				else
					L_3463_ = 2065
				end
			elseif L_3463_ == 2065 then

				L_3463_ = 2104
			elseif L_3463_ == 2067 then

				L_3460_func(15, "taxi boss")
				do
					local L_4508_ = L_3459_func(12)
					L_3460_func(14, L_4508_)
					L_3460_func(13, L_4508_["find"])
				end
				do
					local L_4509_ = 2
					local L_4510_ = L_3462_func(14, L_4509_)
					local L_4511_ = L_1_(L_3459_func(13)(L_2_(L_4510_, 1, L_4510_.n)))
					for L_4512_forvar0 = 1, 1 do
						L_3460_func(13 + L_4512_forvar0 - 1, L_4511_[L_4512_forvar0])
					end
				end
				if L_3459_func(13) then
					L_3463_ = 2076
				else
					L_3463_ = 2071
				end
			elseif L_3463_ == 2071 then

				L_3460_func(15, "taxiboss")
				do
					local L_4513_ = L_3459_func(12)
					L_3460_func(14, L_4513_)
					L_3460_func(13, L_4513_["find"])
				end
				do
					local L_4514_ = 2
					local L_4515_ = L_3462_func(14, L_4514_)
					local L_4516_ = L_1_(L_3459_func(13)(L_2_(L_4515_, 1, L_4515_.n)))
					for L_4517_forvar0 = 1, 1 do
						L_3460_func(13 + L_4517_forvar0 - 1, L_4516_[L_4517_forvar0])
					end
				end
				if not L_3459_func(13) then
					L_3463_ = 2088
				else
					L_3463_ = 2076
				end
			elseif L_3463_ == 2076 then

				L_3460_func(13, L_10_func(L_3453_arg1, "ipairs"))
				L_3460_func(14, L_3459_func(8))
				do
					local L_4518_ = 1
					local L_4519_ = L_3462_func(14, L_4518_)
					local L_4520_ = L_1_(L_3459_func(13)(L_2_(L_4519_, 1, L_4519_.n)))
					for L_4521_forvar0 = 1, 3 do
						L_3460_func(13 + L_4521_forvar0 - 1, L_4520_[L_4521_forvar0])
					end
				end
				L_3463_ = 2086
			elseif L_3463_ == 2080 then

				L_3460_func(18, L_3459_func(17)["name"])
				L_3460_func(72, "Taxi Boss")
				L_3460_func(73, L_3459_func(18) == L_3459_func(72))
				if not L_3459_func(73) then
					L_3463_ = 2086
				else
					L_3463_ = 2084
				end
			elseif L_3463_ == 2084 then

				L_3460_func(9, L_3459_func(17))
				L_3463_ = 2104
			elseif L_3463_ == 2086 then

				if L_12_func(L_3459_func, L_3460_func, 13, 2) then
					L_3463_ = 2080
				else
					L_3463_ = 2087
				end
			elseif L_3463_ == 2087 then

				L_3463_ = 2104
			elseif L_3463_ == 2088 then

				L_3460_func(15, "evade")
				do
					local L_4522_ = L_3459_func(12)
					L_3460_func(14, L_4522_)
					L_3460_func(13, L_4522_["find"])
				end
				do
					local L_4523_ = 2
					local L_4524_ = L_3462_func(14, L_4523_)
					local L_4525_ = L_1_(L_3459_func(13)(L_2_(L_4524_, 1, L_4524_.n)))
					for L_4526_forvar0 = 1, 1 do
						L_3460_func(13 + L_4526_forvar0 - 1, L_4525_[L_4526_forvar0])
					end
				end
				if not L_3459_func(13) then
					L_3463_ = 2104
				else
					L_3463_ = 2092
				end
			elseif L_3463_ == 2092 then

				L_3460_func(13, L_10_func(L_3453_arg1, "ipairs"))
				L_3460_func(14, L_3459_func(8))
				do
					local L_4527_ = 1
					local L_4528_ = L_3462_func(14, L_4527_)
					local L_4529_ = L_1_(L_3459_func(13)(L_2_(L_4528_, 1, L_4528_.n)))
					for L_4530_forvar0 = 1, 3 do
						L_3460_func(13 + L_4530_forvar0 - 1, L_4529_[L_4530_forvar0])
					end
				end
				L_3463_ = 2103
			elseif L_3463_ == 2097 then

				L_3460_func(18, L_3459_func(17)["name"])
				L_3460_func(72, "Evade")
				L_3460_func(73, L_3459_func(18) == L_3459_func(72))
				if not L_3459_func(73) then
					L_3463_ = 2103
				else
					L_3463_ = 2101
				end
			elseif L_3463_ == 2101 then

				L_3460_func(9, L_3459_func(17))
				L_3463_ = 2104
			elseif L_3463_ == 2103 then

				if L_12_func(L_3459_func, L_3460_func, 13, 2) then
					L_3463_ = 2097
				else
					L_3463_ = 2104
				end
			elseif L_3463_ == 2104 then

				if L_3459_func(9) then
					L_3463_ = 2108
				else
					L_3463_ = 2105
				end
			elseif L_3463_ == 2105 then

				L_3460_func(13, L_10_func(L_3453_arg1, "pcall"))

				do
					local L_4531_ = {}
					L_4531_[1] = {
						L_3459_func(8)
					}
					L_4531_[2] = L_3461_func(9)
					local L_4532_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_4533_
					L_4533_ = function(...)
						return L_13_.fn_042_detectBedWarsRemotes(L_4531_, L_4532_, ...)
					end
					L_6_[L_4533_] = L_4532_
					L_3460_func(14, L_4533_)
				end
				do
					local L_4534_ = 1
					local L_4535_ = L_3462_func(14, L_4534_)
					L_3459_func(13)(L_2_(L_4535_, 1, L_4535_.n))
				end
				L_3463_ = 2108
			elseif L_3463_ == 2108 then

				L_3460_func(13, {})
				L_3460_func(14, "Da Hood")
				L_3459_func(13)["name"] = L_3459_func(14)
				L_3460_func(14, 0)
				L_3459_func(13)["features"] = L_3459_func(14)
				L_3460_func(9, L_3459_func(13))
				L_3460_func(13, {})
				L_3460_func(14, nil)

				do
					local L_4536_ = {}
					L_4536_[1] = L_3461_func(14)
					L_4536_[2] = {
						L_3459_func(5)
					}
					L_4536_[3] = {
						L_3459_func(7)
					}
					local L_4537_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_4538_
					L_4538_ = function(...)
						return L_13_.fn_045_createNotificationGui(L_4536_, L_4537_, ...)
					end
					L_6_[L_4538_] = L_4537_
					L_3460_func(15, L_4538_)
				end

				do
					local L_4539_ = {}
					L_4539_[1] = {
						L_3459_func(15)
					}
					local L_4540_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_4541_
					L_4541_ = function(...)
						return L_13_.fn_046_Notify(L_4539_, L_4540_, ...)
					end
					L_6_[L_4541_] = L_4540_
					L_3460_func(16, L_4541_)
				end
				L_3459_func(13)["Notify"] = L_3459_func(16)
				L_3460_func(16, 0)
				L_3460_func(17, nil)

				do
					local L_4542_ = {}
					L_4542_[1] = L_3461_func(16)
					L_4542_[2] = L_3461_func(17)
					L_4542_[3] = {
						L_3459_func(2)
					}
					L_4542_[4] = {
						L_3459_func(5)
					}
					L_4542_[5] = {
						L_3459_func(6)
					}
					L_4542_[6] = {
						L_3459_func(7)
					}
					L_4542_[7] = {
						L_3459_func(13)
					}
					local L_4543_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_4544_
					L_4544_ = function(...)
						return L_13_.fn_064_premiumLockedAction(L_4542_, L_4543_, ...)
					end
					L_6_[L_4544_] = L_4543_
					L_3460_func(18, L_4544_)
				end

				do
					local L_4545_ = {}
					L_4545_[1] = {
						L_3459_func(7)
					}
					L_4545_[2] = L_3461_func(9)
					local L_4546_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_4547_
					L_4547_ = function(...)
						return L_13_.fn_127_snowyUiLibrary(L_4545_, L_4546_, ...)
					end
					L_6_[L_4547_] = L_4546_
					L_3460_func(19, L_4547_)
				end
				do
					local L_4548_ = 0
					local L_4549_ = L_3462_func(20, L_4548_)
					local L_4550_ = L_1_(L_3459_func(19)(L_2_(L_4549_, 1, L_4549_.n)))
					for L_4551_forvar0 = 1, 1 do
						L_3460_func(19 + L_4551_forvar0 - 1, L_4550_[L_4551_forvar0])
					end
				end

				do
					local L_4552_ = {}
					local L_4553_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_4554_
					L_4554_ = function(...)
						return L_13_.fn_128_normalizeOptions(L_4552_, L_4553_, ...)
					end
					L_6_[L_4554_] = L_4553_
					L_3460_func(20, L_4554_)
				end
				L_3460_func(21, {})

				do
					local L_4555_ = {}
					L_4555_[1] = {
						L_3459_func(19)
					}
					L_4555_[2] = {
						L_3459_func(20)
					}
					L_4555_[3] = {
						L_3459_func(18)
					}
					local L_4556_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_4557_
					L_4557_ = function(...)
						return L_13_.fn_151_CreateLib(L_4555_, L_4556_, ...)
					end
					L_6_[L_4557_] = L_4556_
					L_3460_func(22, L_4557_)
				end
				L_3459_func(21)["CreateLib"] = L_3459_func(22)
				L_3460_func(23, L_10_func(L_3453_arg1, "game"))
				L_3460_func(25, "Players")
				do
					local L_4558_ = L_3459_func(23)
					L_3460_func(24, L_4558_)
					L_3460_func(23, L_4558_["GetService"])
				end
				do
					local L_4559_ = 2
					local L_4560_ = L_3462_func(24, L_4559_)
					local L_4561_ = L_1_(L_3459_func(23)(L_2_(L_4560_, 1, L_4560_.n)))
					for L_4562_forvar0 = 1, 1 do
						L_3460_func(23 + L_4562_forvar0 - 1, L_4561_[L_4562_forvar0])
					end
				end
				L_3460_func(22, L_3459_func(23)["LocalPlayer"])
				L_3460_func(23, L_10_func(L_3453_arg1, "game"))
				L_3460_func(25, "UserInputService")
				do
					local L_4563_ = L_3459_func(23)
					L_3460_func(24, L_4563_)
					L_3460_func(23, L_4563_["GetService"])
				end
				do
					local L_4564_ = 2
					local L_4565_ = L_3462_func(24, L_4564_)
					local L_4566_ = L_1_(L_3459_func(23)(L_2_(L_4565_, 1, L_4565_.n)))
					for L_4567_forvar0 = 1, 1 do
						L_3460_func(23 + L_4567_forvar0 - 1, L_4566_[L_4567_forvar0])
					end
				end
				L_3460_func(24, L_10_func(L_3453_arg1, "game"))
				L_3460_func(26, "ReplicatedStorage")
				do
					local L_4568_ = L_3459_func(24)
					L_3460_func(25, L_4568_)
					L_3460_func(24, L_4568_["GetService"])
				end
				do
					local L_4569_ = 2
					local L_4570_ = L_3462_func(25, L_4569_)
					local L_4571_ = L_1_(L_3459_func(24)(L_2_(L_4570_, 1, L_4570_.n)))
					for L_4572_forvar0 = 1, 1 do
						L_3460_func(24 + L_4572_forvar0 - 1, L_4571_[L_4572_forvar0])
					end
				end
				L_3460_func(25, L_10_func(L_3453_arg1, "game"))
				L_3460_func(27, "RunService")
				do
					local L_4573_ = L_3459_func(25)
					L_3460_func(26, L_4573_)
					L_3460_func(25, L_4573_["GetService"])
				end
				do
					local L_4574_ = 2
					local L_4575_ = L_3462_func(26, L_4574_)
					local L_4576_ = L_1_(L_3459_func(25)(L_2_(L_4575_, 1, L_4575_.n)))
					for L_4577_forvar0 = 1, 1 do
						L_3460_func(25 + L_4577_forvar0 - 1, L_4576_[L_4577_forvar0])
					end
				end
				L_3460_func(26, L_10_func(L_3453_arg1, "workspace"))
				L_3460_func(26, L_3459_func(26)["CurrentCamera"])

				do
					local L_4578_ = {}
					L_4578_[1] = {
						L_3459_func(22)
					}
					local L_4579_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_4580_
					L_4580_ = function(...)
						return L_13_.fn_152_getCharacter(L_4578_, L_4579_, ...)
					end
					L_6_[L_4580_] = L_4579_
					L_3460_func(27, L_4580_)
				end

				do
					local L_4581_ = {}
					L_4581_[1] = {
						L_3459_func(22)
					}
					local L_4582_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_4583_
					L_4583_ = function(...)
						return L_13_.fn_153_getHumanoid(L_4581_, L_4582_, ...)
					end
					L_6_[L_4583_] = L_4582_
					L_3460_func(28, L_4583_)
				end

				do
					local L_4584_ = {}
					L_4584_[1] = {
						L_3459_func(22)
					}
					local L_4585_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_4586_
					L_4586_ = function(...)
						return L_13_.fn_154_getRootPart(L_4584_, L_4585_, ...)
					end
					L_6_[L_4586_] = L_4585_
					L_3460_func(29, L_4586_)
				end

				do
					local L_4587_ = {}
					local L_4588_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_4589_
					L_4589_ = function(...)
						return L_13_.fn_155_packVarargs(L_4587_, L_4588_, ...)
					end
					L_6_[L_4589_] = L_4588_
					L_3460_func(30, L_4589_)
				end
				L_3460_func(31, {})
				L_3460_func(32, "Snowy Studios")
				L_3459_func(31)["HubName"] = L_3459_func(32)
				L_3460_func(32, L_10_func(L_3453_arg1, "Color3"))
				L_3460_func(32, L_3459_func(32)["fromRGB"])
				L_3460_func(33, 0)
				L_3460_func(34, 162)
				L_3460_func(35, 255)
				do
					local L_4590_ = 3
					local L_4591_ = L_3462_func(33, L_4590_)
					local L_4592_ = L_1_(L_3459_func(32)(L_2_(L_4591_, 1, L_4591_.n)))
					for L_4593_forvar0 = 1, 1 do
						L_3460_func(32 + L_4593_forvar0 - 1, L_4592_[L_4593_forvar0])
					end
				end
				L_3459_func(31)["AccentColor"] = L_3459_func(32)

				do
					local L_4594_ = {}
					L_4594_[1] = {
						L_3459_func(13)
					}
					local L_4595_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_4596_
					L_4596_ = function(...)
						return L_13_.fn_156_notifyWrapper(L_4594_, L_4595_, ...)
					end
					L_6_[L_4596_] = L_4595_
					L_3460_func(32, L_4596_)
				end
				L_3460_func(33, L_10_func(L_3453_arg1, "getgenv"))
				do
					local L_4597_ = 0
					local L_4598_ = L_3462_func(34, L_4597_)
					local L_4599_ = L_1_(L_3459_func(33)(L_2_(L_4598_, 1, L_4598_.n)))
					for L_4600_forvar0 = 1, 1 do
						L_3460_func(33 + L_4600_forvar0 - 1, L_4599_[L_4600_forvar0])
					end
				end
				L_3460_func(34, L_3459_func(21)["CreateLib"])
				L_3460_func(35, L_3459_func(31)["HubName"])
				L_3460_func(36, "Midnight")
				do
					local L_4601_ = 2
					local L_4602_ = L_3462_func(35, L_4601_)
					local L_4603_ = L_1_(L_3459_func(34)(L_2_(L_4602_, 1, L_4602_.n)))
					for L_4604_forvar0 = 1, 1 do
						L_3460_func(34 + L_4604_forvar0 - 1, L_4603_[L_4604_forvar0])
					end
				end
				L_3459_func(33)["Window"] = L_3459_func(34)
				L_3460_func(34, L_10_func(L_3453_arg1, "getgenv"))
				do
					local L_4605_ = 0
					local L_4606_ = L_3462_func(35, L_4605_)
					local L_4607_ = L_1_(L_3459_func(34)(L_2_(L_4606_, 1, L_4606_.n)))
					for L_4608_forvar0 = 1, 1 do
						L_3460_func(34 + L_4608_forvar0 - 1, L_4607_[L_4608_forvar0])
					end
				end
				L_3460_func(33, L_3459_func(34)["Window"])
				L_3460_func(34, L_10_func(L_3453_arg1, "getgenv"))
				do
					local L_4609_ = 0
					local L_4610_ = L_3462_func(35, L_4609_)
					local L_4611_ = L_1_(L_3459_func(34)(L_2_(L_4610_, 1, L_4610_.n)))
					for L_4612_forvar0 = 1, 1 do
						L_3460_func(34 + L_4612_forvar0 - 1, L_4611_[L_4612_forvar0])
					end
				end
				if not L_3459_func(9) then
					L_3463_ = 2182
				else
					L_3463_ = 2180
				end
			elseif L_3463_ == 2180 then

				L_3460_func(35, L_3459_func(9)["name"])
				if L_3459_func(35) then
					L_3463_ = 2183
				else
					L_3463_ = 2182
				end
			elseif L_3463_ == 2182 then

				L_3460_func(35, "Unknown")
				L_3463_ = 2183
			elseif L_3463_ == 2183 then

				L_3460_func(36, {})
				L_3460_func(37, L_3459_func(34)["__SnowyLaunchNonce"])
				L_3459_func(36)["nonce"] = L_3459_func(37)
				L_3459_func(36)["game"] = L_3459_func(35)
				L_3460_func(37, true)
				L_3459_func(36)["ui"] = L_3459_func(37)
				L_3460_func(37, L_10_func(L_3453_arg1, "os"))
				L_3460_func(37, L_3459_func(37)["clock"])
				do
					local L_4613_ = 0
					local L_4614_ = L_3462_func(38, L_4613_)
					local L_4615_ = L_1_(L_3459_func(37)(L_2_(L_4614_, 1, L_4614_.n)))
					for L_4616_forvar0 = 1, 1 do
						L_3460_func(37 + L_4616_forvar0 - 1, L_4615_[L_4616_forvar0])
					end
				end
				L_3459_func(36)["at"] = L_3459_func(37)
				L_3459_func(34)["__SnowyPayloadReady"] = L_3459_func(36)
				L_3460_func(36, L_10_func(L_3453_arg1, "print"))
				L_3460_func(38, "[SnowyHub] Payload UI ready: ")
				L_3460_func(40, L_3459_func(35))
				L_3460_func(39, L_10_func(L_3453_arg1, "tostring"))
				do
					local L_4617_ = 1
					local L_4618_ = L_3462_func(40, L_4617_)
					local L_4619_ = L_1_(L_3459_func(39)(L_2_(L_4618_, 1, L_4618_.n)))
					for L_4620_forvar0 = 1, 1 do
						L_3460_func(39 + L_4620_forvar0 - 1, L_4619_[L_4620_forvar0])
					end
				end
				do
					local L_4621_ = L_3459_func(39)
					for L_4622_forvar0 = 38, 38, -1 do
						L_4621_ = L_3459_func(L_4622_forvar0) .. L_4621_
					end
					L_3460_func(37, L_4621_)
				end
				do
					local L_4623_ = 1
					local L_4624_ = L_3462_func(37, L_4623_)
					L_3459_func(36)(L_2_(L_4624_, 1, L_4624_.n))
				end
				L_3460_func(34, L_10_func(L_3453_arg1, "getgenv"))
				do
					local L_4625_ = 0
					local L_4626_ = L_3462_func(35, L_4625_)
					local L_4627_ = L_1_(L_3459_func(34)(L_2_(L_4626_, 1, L_4626_.n)))
					for L_4628_forvar0 = 1, 1 do
						L_3460_func(34 + L_4628_forvar0 - 1, L_4627_[L_4628_forvar0])
					end
				end
				L_3459_func(34)["SnowyLib"] = L_3459_func(13)
				L_3460_func(34, L_10_func(L_3453_arg1, "getgenv"))
				do
					local L_4629_ = 0
					local L_4630_ = L_3462_func(35, L_4629_)
					local L_4631_ = L_1_(L_3459_func(34)(L_2_(L_4630_, 1, L_4630_.n)))
					for L_4632_forvar0 = 1, 1 do
						L_3460_func(34 + L_4632_forvar0 - 1, L_4631_[L_4632_forvar0])
					end
				end
				L_3459_func(34)["Kavo"] = L_3459_func(21)
				L_3460_func(34, L_10_func(L_3453_arg1, "getgenv"))
				do
					local L_4633_ = 0
					local L_4634_ = L_3462_func(35, L_4633_)
					local L_4635_ = L_1_(L_3459_func(34)(L_2_(L_4634_, 1, L_4634_.n)))
					for L_4636_forvar0 = 1, 1 do
						L_3460_func(34 + L_4636_forvar0 - 1, L_4635_[L_4636_forvar0])
					end
				end
				L_3459_func(34)["notify"] = L_3459_func(32)
				L_3460_func(34, L_10_func(L_3453_arg1, "task"))
				L_3460_func(34, L_3459_func(34)["defer"])

				do
					local L_4637_ = {}
					local L_4638_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_4639_
					L_4639_ = function(...)
						return L_13_.fn_158(L_4637_, L_4638_, ...)
					end
					L_6_[L_4639_] = L_4638_
					L_3460_func(35, L_4639_)
				end
				do
					local L_4640_ = 1
					local L_4641_ = L_3462_func(35, L_4640_)
					L_3459_func(34)(L_2_(L_4641_, 1, L_4641_.n))
				end
				L_3460_func(34, {})

				do
					local L_4642_ = {}
					L_4642_[1] = L_3461_func(9)
					L_4642_[2] = {
						L_3459_func(33)
					}
					L_4642_[3] = {
						L_3459_func(20)
					}
					L_4642_[4] = {
						L_3459_func(18)
					}
					local L_4643_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_4644_
					L_4644_ = function(...)
						return L_13_.fn_183_legacyApiAdapter(L_4642_, L_4643_, ...)
					end
					L_6_[L_4644_] = L_4643_
					L_3460_func(35, L_4644_)
				end
				L_3460_func(36, L_10_func(L_3453_arg1, "getgenv"))
				do
					local L_4645_ = 0
					local L_4646_ = L_3462_func(37, L_4645_)
					local L_4647_ = L_1_(L_3459_func(36)(L_2_(L_4646_, 1, L_4646_.n)))
					for L_4648_forvar0 = 1, 1 do
						L_3460_func(36 + L_4648_forvar0 - 1, L_4647_[L_4648_forvar0])
					end
				end
				L_3459_func(36)["gameTab"] = L_3459_func(35)

				do
					local L_4649_ = {}
					L_4649_[1] = {
						L_3459_func(35)
					}
					L_4649_[2] = {
						L_3459_func(13)
					}
					local L_4650_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_4651_
					L_4651_ = function(...)
						return L_13_.fn_227_buildFreePremiumSections(L_4649_, L_4650_, ...)
					end
					L_6_[L_4651_] = L_4650_
					L_3460_func(36, L_4651_)
				end
				if L_3459_func(9) then
					L_3463_ = 2674
				else
					L_3463_ = 2225
				end
			elseif L_3463_ == 2225 then

				L_3460_func(37, L_10_func(L_3453_arg1, "getgenv"))
				do
					local L_4652_ = 0
					local L_4653_ = L_3462_func(38, L_4652_)
					local L_4654_ = L_1_(L_3459_func(37)(L_2_(L_4653_, 1, L_4653_.n)))
					for L_4655_forvar0 = 1, 1 do
						L_3460_func(37 + L_4655_forvar0 - 1, L_4654_[L_4655_forvar0])
					end
				end
				L_3460_func(40, "Home")
				do
					local L_4656_ = L_3459_func(33)
					L_3460_func(39, L_4656_)
					L_3460_func(38, L_4656_["NewTab"])
				end
				do
					local L_4657_ = 2
					local L_4658_ = L_3462_func(39, L_4657_)
					local L_4659_ = L_1_(L_3459_func(38)(L_2_(L_4658_, 1, L_4658_.n)))
					for L_4660_forvar0 = 1, 1 do
						L_3460_func(38 + L_4660_forvar0 - 1, L_4659_[L_4660_forvar0])
					end
				end
				L_3459_func(37)["HomeTab"] = L_3459_func(38)
				L_3460_func(37, L_10_func(L_3453_arg1, "getgenv"))
				do
					local L_4661_ = 0
					local L_4662_ = L_3462_func(38, L_4661_)
					local L_4663_ = L_1_(L_3459_func(37)(L_2_(L_4662_, 1, L_4662_.n)))
					for L_4664_forvar0 = 1, 1 do
						L_3460_func(37 + L_4664_forvar0 - 1, L_4663_[L_4664_forvar0])
					end
				end
				L_3460_func(40, "Player")
				do
					local L_4665_ = L_3459_func(33)
					L_3460_func(39, L_4665_)
					L_3460_func(38, L_4665_["NewTab"])
				end
				do
					local L_4666_ = 2
					local L_4667_ = L_3462_func(39, L_4666_)
					local L_4668_ = L_1_(L_3459_func(38)(L_2_(L_4667_, 1, L_4667_.n)))
					for L_4669_forvar0 = 1, 1 do
						L_3460_func(38 + L_4669_forvar0 - 1, L_4668_[L_4669_forvar0])
					end
				end
				L_3459_func(37)["PlayerTab"] = L_3459_func(38)
				L_3460_func(37, L_10_func(L_3453_arg1, "getgenv"))
				do
					local L_4670_ = 0
					local L_4671_ = L_3462_func(38, L_4670_)
					local L_4672_ = L_1_(L_3459_func(37)(L_2_(L_4671_, 1, L_4671_.n)))
					for L_4673_forvar0 = 1, 1 do
						L_3460_func(37 + L_4673_forvar0 - 1, L_4672_[L_4673_forvar0])
					end
				end
				L_3460_func(40, "Visuals")
				do
					local L_4674_ = L_3459_func(33)
					L_3460_func(39, L_4674_)
					L_3460_func(38, L_4674_["NewTab"])
				end
				do
					local L_4675_ = 2
					local L_4676_ = L_3462_func(39, L_4675_)
					local L_4677_ = L_1_(L_3459_func(38)(L_2_(L_4676_, 1, L_4676_.n)))
					for L_4678_forvar0 = 1, 1 do
						L_3460_func(38 + L_4678_forvar0 - 1, L_4677_[L_4678_forvar0])
					end
				end
				L_3459_func(37)["VisualTab"] = L_3459_func(38)
				L_3460_func(37, L_10_func(L_3453_arg1, "getgenv"))
				do
					local L_4679_ = 0
					local L_4680_ = L_3462_func(38, L_4679_)
					local L_4681_ = L_1_(L_3459_func(37)(L_2_(L_4680_, 1, L_4680_.n)))
					for L_4682_forvar0 = 1, 1 do
						L_3460_func(37 + L_4682_forvar0 - 1, L_4681_[L_4682_forvar0])
					end
				end
				L_3460_func(40, "Utility")
				do
					local L_4683_ = L_3459_func(33)
					L_3460_func(39, L_4683_)
					L_3460_func(38, L_4683_["NewTab"])
				end
				do
					local L_4684_ = 2
					local L_4685_ = L_3462_func(39, L_4684_)
					local L_4686_ = L_1_(L_3459_func(38)(L_2_(L_4685_, 1, L_4685_.n)))
					for L_4687_forvar0 = 1, 1 do
						L_3460_func(38 + L_4687_forvar0 - 1, L_4686_[L_4687_forvar0])
					end
				end
				L_3459_func(37)["UtilTab"] = L_3459_func(38)
				L_3460_func(37, L_10_func(L_3453_arg1, "getgenv"))
				do
					local L_4688_ = 0
					local L_4689_ = L_3462_func(38, L_4688_)
					local L_4690_ = L_1_(L_3459_func(37)(L_2_(L_4689_, 1, L_4689_.n)))
					for L_4691_forvar0 = 1, 1 do
						L_3460_func(37 + L_4691_forvar0 - 1, L_4690_[L_4691_forvar0])
					end
				end
				L_3460_func(40, "Aimbot")
				do
					local L_4692_ = L_3459_func(33)
					L_3460_func(39, L_4692_)
					L_3460_func(38, L_4692_["NewTab"])
				end
				do
					local L_4693_ = 2
					local L_4694_ = L_3462_func(39, L_4693_)
					local L_4695_ = L_1_(L_3459_func(38)(L_2_(L_4694_, 1, L_4694_.n)))
					for L_4696_forvar0 = 1, 1 do
						L_3460_func(38 + L_4696_forvar0 - 1, L_4695_[L_4696_forvar0])
					end
				end
				L_3459_func(37)["AimbotTab"] = L_3459_func(38)
				L_3460_func(37, L_10_func(L_3453_arg1, "getgenv"))
				do
					local L_4697_ = 0
					local L_4698_ = L_3462_func(38, L_4697_)
					local L_4699_ = L_1_(L_3459_func(37)(L_2_(L_4698_, 1, L_4698_.n)))
					for L_4700_forvar0 = 1, 1 do
						L_3460_func(37 + L_4700_forvar0 - 1, L_4699_[L_4700_forvar0])
					end
				end
				L_3460_func(40, "Settings")
				do
					local L_4701_ = L_3459_func(33)
					L_3460_func(39, L_4701_)
					L_3460_func(38, L_4701_["NewTab"])
				end
				do
					local L_4702_ = 2
					local L_4703_ = L_3462_func(39, L_4702_)
					local L_4704_ = L_1_(L_3459_func(38)(L_2_(L_4703_, 1, L_4703_.n)))
					for L_4705_forvar0 = 1, 1 do
						L_3460_func(38 + L_4705_forvar0 - 1, L_4704_[L_4705_forvar0])
					end
				end
				L_3459_func(37)["SettingsTab"] = L_3459_func(38)
				L_3460_func(37, L_10_func(L_3453_arg1, "getgenv"))
				do
					local L_4706_ = 0
					local L_4707_ = L_3462_func(38, L_4706_)
					local L_4708_ = L_1_(L_3459_func(37)(L_2_(L_4707_, 1, L_4707_.n)))
					for L_4709_forvar0 = 1, 1 do
						L_3460_func(37 + L_4709_forvar0 - 1, L_4708_[L_4709_forvar0])
					end
				end
				L_3460_func(38, L_10_func(L_3453_arg1, "HomeTab"))
				L_3460_func(40, "Status")
				do
					local L_4710_ = L_3459_func(38)
					L_3460_func(39, L_4710_)
					L_3460_func(38, L_4710_["NewSection"])
				end
				do
					local L_4711_ = 2
					local L_4712_ = L_3462_func(39, L_4711_)
					local L_4713_ = L_1_(L_3459_func(38)(L_2_(L_4712_, 1, L_4712_.n)))
					for L_4714_forvar0 = 1, 1 do
						L_3460_func(38 + L_4714_forvar0 - 1, L_4713_[L_4714_forvar0])
					end
				end
				L_3459_func(37)["HomeSec"] = L_3459_func(38)
				L_3460_func(37, L_10_func(L_3453_arg1, "HomeSec"))
				L_3460_func(42, L_10_func(L_3453_arg1, "utf8"))
				L_3460_func(42, L_3459_func(42)["char"])
				L_3460_func(43, 10052)
				do
					local L_4715_ = 1
					local L_4716_ = L_3462_func(43, L_4715_)
					local L_4717_ = L_1_(L_3459_func(42)(L_2_(L_4716_, 1, L_4716_.n)))
					for L_4718_forvar0 = 1, 1 do
						L_3460_func(42 + L_4718_forvar0 - 1, L_4717_[L_4718_forvar0])
					end
				end
				L_3460_func(40, L_3459_func(42))
				L_3460_func(41, " SNOWY HUB v6.0")
				do
					local L_4719_ = L_3459_func(41)
					for L_4720_forvar0 = 40, 40, -1 do
						L_4719_ = L_3459_func(L_4720_forvar0) .. L_4719_
					end
					L_3460_func(39, L_4719_)
				end
				do
					local L_4721_ = L_3459_func(37)
					L_3460_func(38, L_4721_)
					L_3460_func(37, L_4721_["NewLabel"])
				end
				do
					local L_4722_ = 2
					local L_4723_ = L_3462_func(38, L_4722_)
					L_3459_func(37)(L_2_(L_4723_, 1, L_4723_.n))
				end
				L_3460_func(37, L_10_func(L_3453_arg1, "getgenv"))
				do
					local L_4724_ = 0
					local L_4725_ = L_3462_func(38, L_4724_)
					local L_4726_ = L_1_(L_3459_func(37)(L_2_(L_4725_, 1, L_4725_.n)))
					for L_4727_forvar0 = 1, 1 do
						L_3460_func(37 + L_4727_forvar0 - 1, L_4726_[L_4727_forvar0])
					end
				end
				L_3460_func(38, L_10_func(L_3453_arg1, "PlayerTab"))
				L_3460_func(40, "General")
				do
					local L_4728_ = L_3459_func(38)
					L_3460_func(39, L_4728_)
					L_3460_func(38, L_4728_["NewSection"])
				end
				do
					local L_4729_ = 2
					local L_4730_ = L_3462_func(39, L_4729_)
					local L_4731_ = L_1_(L_3459_func(38)(L_2_(L_4730_, 1, L_4730_.n)))
					for L_4732_forvar0 = 1, 1 do
						L_3460_func(38 + L_4732_forvar0 - 1, L_4731_[L_4732_forvar0])
					end
				end
				L_3459_func(37)["PlayerSection"] = L_3459_func(38)
				L_3460_func(37, L_10_func(L_3453_arg1, "getgenv"))
				do
					local L_4733_ = 0
					local L_4734_ = L_3462_func(38, L_4733_)
					local L_4735_ = L_1_(L_3459_func(37)(L_2_(L_4734_, 1, L_4734_.n)))
					for L_4736_forvar0 = 1, 1 do
						L_3460_func(37 + L_4736_forvar0 - 1, L_4735_[L_4736_forvar0])
					end
				end
				L_3460_func(38, L_10_func(L_3453_arg1, "VisualTab"))
				L_3460_func(40, "ESP & Effects")
				do
					local L_4737_ = L_3459_func(38)
					L_3460_func(39, L_4737_)
					L_3460_func(38, L_4737_["NewSection"])
				end
				do
					local L_4738_ = 2
					local L_4739_ = L_3462_func(39, L_4738_)
					local L_4740_ = L_1_(L_3459_func(38)(L_2_(L_4739_, 1, L_4739_.n)))
					for L_4741_forvar0 = 1, 1 do
						L_3460_func(38 + L_4741_forvar0 - 1, L_4740_[L_4741_forvar0])
					end
				end
				L_3459_func(37)["VisualSection"] = L_3459_func(38)
				L_3460_func(37, L_10_func(L_3453_arg1, "getgenv"))
				do
					local L_4742_ = 0
					local L_4743_ = L_3462_func(38, L_4742_)
					local L_4744_ = L_1_(L_3459_func(37)(L_2_(L_4743_, 1, L_4743_.n)))
					for L_4745_forvar0 = 1, 1 do
						L_3460_func(37 + L_4745_forvar0 - 1, L_4744_[L_4745_forvar0])
					end
				end
				L_3460_func(38, L_10_func(L_3453_arg1, "UtilTab"))
				L_3460_func(40, "General Tools")
				L_3463_ = 2304
			else
				error("invalid recovered basic block in main: " .. tostring(L_3463_))
			end
		elseif L_3475_ == 9 then
			if L_3463_ == 2304 then

				do
					local L_4746_ = L_3459_func(38)
					L_3460_func(39, L_4746_)
					L_3460_func(38, L_4746_["NewSection"])
				end
				do
					local L_4747_ = 2
					local L_4748_ = L_3462_func(39, L_4747_)
					local L_4749_ = L_1_(L_3459_func(38)(L_2_(L_4748_, 1, L_4748_.n)))
					for L_4750_forvar0 = 1, 1 do
						L_3460_func(38 + L_4750_forvar0 - 1, L_4749_[L_4750_forvar0])
					end
				end
				L_3459_func(37)["UtilSection"] = L_3459_func(38)
				L_3460_func(37, L_10_func(L_3453_arg1, "getgenv"))
				do
					local L_4751_ = 0
					local L_4752_ = L_3462_func(38, L_4751_)
					local L_4753_ = L_1_(L_3459_func(37)(L_2_(L_4752_, 1, L_4752_.n)))
					for L_4754_forvar0 = 1, 1 do
						L_3460_func(37 + L_4754_forvar0 - 1, L_4753_[L_4754_forvar0])
					end
				end
				L_3460_func(38, L_10_func(L_3453_arg1, "AimbotTab"))
				L_3460_func(40, "Combat Settings")
				do
					local L_4755_ = L_3459_func(38)
					L_3460_func(39, L_4755_)
					L_3460_func(38, L_4755_["NewSection"])
				end
				do
					local L_4756_ = 2
					local L_4757_ = L_3462_func(39, L_4756_)
					local L_4758_ = L_1_(L_3459_func(38)(L_2_(L_4757_, 1, L_4757_.n)))
					for L_4759_forvar0 = 1, 1 do
						L_3460_func(38 + L_4759_forvar0 - 1, L_4758_[L_4759_forvar0])
					end
				end
				L_3459_func(37)["AimbotSection"] = L_3459_func(38)
				L_3460_func(37, L_10_func(L_3453_arg1, "getgenv"))
				do
					local L_4760_ = 0
					local L_4761_ = L_3462_func(38, L_4760_)
					local L_4762_ = L_1_(L_3459_func(37)(L_2_(L_4761_, 1, L_4761_.n)))
					for L_4763_forvar0 = 1, 1 do
						L_3460_func(37 + L_4763_forvar0 - 1, L_4762_[L_4763_forvar0])
					end
				end
				L_3460_func(38, L_10_func(L_3453_arg1, "SettingsTab"))
				L_3460_func(40, "Interface")
				do
					local L_4764_ = L_3459_func(38)
					L_3460_func(39, L_4764_)
					L_3460_func(38, L_4764_["NewSection"])
				end
				do
					local L_4765_ = 2
					local L_4766_ = L_3462_func(39, L_4765_)
					local L_4767_ = L_1_(L_3459_func(38)(L_2_(L_4766_, 1, L_4766_.n)))
					for L_4768_forvar0 = 1, 1 do
						L_3460_func(38 + L_4768_forvar0 - 1, L_4767_[L_4768_forvar0])
					end
				end
				L_3459_func(37)["UISec"] = L_3459_func(38)
				L_3460_func(37, L_10_func(L_3453_arg1, "getgenv"))
				do
					local L_4769_ = 0
					local L_4770_ = L_3462_func(38, L_4769_)
					local L_4771_ = L_1_(L_3459_func(37)(L_2_(L_4770_, 1, L_4770_.n)))
					for L_4772_forvar0 = 1, 1 do
						L_3460_func(37 + L_4772_forvar0 - 1, L_4771_[L_4772_forvar0])
					end
				end
				L_3460_func(38, L_10_func(L_3453_arg1, "SettingsTab"))
				L_3460_func(40, "Info")
				do
					local L_4773_ = L_3459_func(38)
					L_3460_func(39, L_4773_)
					L_3460_func(38, L_4773_["NewSection"])
				end
				do
					local L_4774_ = 2
					local L_4775_ = L_3462_func(39, L_4774_)
					local L_4776_ = L_1_(L_3459_func(38)(L_2_(L_4775_, 1, L_4775_.n)))
					for L_4777_forvar0 = 1, 1 do
						L_3460_func(38 + L_4777_forvar0 - 1, L_4776_[L_4777_forvar0])
					end
				end
				L_3459_func(37)["InfoSec"] = L_3459_func(38)
				L_3460_func(37, L_10_func(L_3453_arg1, "getgenv"))
				do
					local L_4778_ = 0
					local L_4779_ = L_3462_func(38, L_4778_)
					local L_4780_ = L_1_(L_3459_func(37)(L_2_(L_4779_, 1, L_4779_.n)))
					for L_4781_forvar0 = 1, 1 do
						L_3460_func(37 + L_4781_forvar0 - 1, L_4780_[L_4781_forvar0])
					end
				end
				L_3460_func(38, 16)
				L_3459_func(37)["WalkSpeedValue"] = L_3459_func(38)
				L_3460_func(37, L_10_func(L_3453_arg1, "getgenv"))
				do
					local L_4782_ = 0
					local L_4783_ = L_3462_func(38, L_4782_)
					local L_4784_ = L_1_(L_3459_func(37)(L_2_(L_4783_, 1, L_4783_.n)))
					for L_4785_forvar0 = 1, 1 do
						L_3460_func(37 + L_4785_forvar0 - 1, L_4784_[L_4785_forvar0])
					end
				end
				L_3460_func(38, 50)
				L_3459_func(37)["JumpPowerValue"] = L_3459_func(38)
				L_3460_func(37, L_10_func(L_3453_arg1, "getgenv"))
				do
					local L_4786_ = 0
					local L_4787_ = L_3462_func(38, L_4786_)
					local L_4788_ = L_1_(L_3459_func(37)(L_2_(L_4787_, 1, L_4787_.n)))
					for L_4789_forvar0 = 1, 1 do
						L_3460_func(37 + L_4789_forvar0 - 1, L_4788_[L_4789_forvar0])
					end
				end
				L_3460_func(38, false)
				L_3459_func(37)["GodModeEnabled"] = L_3459_func(38)
				L_3460_func(38, L_10_func(L_3453_arg1, "getgenv"))
				do
					local L_4790_ = 0
					local L_4791_ = L_3462_func(39, L_4790_)
					local L_4792_ = L_1_(L_3459_func(38)(L_2_(L_4791_, 1, L_4791_.n)))
					for L_4793_forvar0 = 1, 1 do
						L_3460_func(38 + L_4793_forvar0 - 1, L_4792_[L_4793_forvar0])
					end
				end
				L_3460_func(37, L_3459_func(38)["PlayerModifierLoop"])
				if not L_3459_func(37) then
					L_3463_ = 2358
				else
					L_3463_ = 2349
				end
			elseif L_3463_ == 2349 then

				L_3460_func(37, L_10_func(L_3453_arg1, "pcall"))

				do
					local L_4794_ = {}
					local L_4795_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_4796_
					L_4796_ = function(...)
						return L_13_.fn_228_stopPlayerModifierLoop(L_4794_, L_4795_, ...)
					end
					L_6_[L_4796_] = L_4795_
					L_3460_func(38, L_4796_)
				end
				do
					local L_4797_ = 1
					local L_4798_ = L_3462_func(38, L_4797_)
					L_3459_func(37)(L_2_(L_4798_, 1, L_4798_.n))
				end
				L_3460_func(37, L_10_func(L_3453_arg1, "getgenv"))
				do
					local L_4799_ = 0
					local L_4800_ = L_3462_func(38, L_4799_)
					local L_4801_ = L_1_(L_3459_func(37)(L_2_(L_4800_, 1, L_4800_.n)))
					for L_4802_forvar0 = 1, 1 do
						L_3460_func(37 + L_4802_forvar0 - 1, L_4801_[L_4802_forvar0])
					end
				end
				L_3460_func(38, nil)
				L_3459_func(37)["PlayerModifierLoop"] = L_3459_func(38)
				L_3463_ = 2358
			elseif L_3463_ == 2358 then

				L_3460_func(37, L_10_func(L_3453_arg1, "getgenv"))
				do
					local L_4803_ = 0
					local L_4804_ = L_3462_func(38, L_4803_)
					local L_4805_ = L_1_(L_3459_func(37)(L_2_(L_4804_, 1, L_4804_.n)))
					for L_4806_forvar0 = 1, 1 do
						L_3460_func(37 + L_4806_forvar0 - 1, L_4805_[L_4806_forvar0])
					end
				end
				L_3460_func(39, L_10_func(L_3453_arg1, "game"))
				L_3460_func(41, "RunService")
				do
					local L_4807_ = L_3459_func(39)
					L_3460_func(40, L_4807_)
					L_3460_func(39, L_4807_["GetService"])
				end
				do
					local L_4808_ = 2
					local L_4809_ = L_3462_func(40, L_4808_)
					local L_4810_ = L_1_(L_3459_func(39)(L_2_(L_4809_, 1, L_4809_.n)))
					for L_4811_forvar0 = 1, 1 do
						L_3460_func(39 + L_4811_forvar0 - 1, L_4810_[L_4811_forvar0])
					end
				end
				L_3460_func(38, L_3459_func(39)["RenderStepped"])

				do
					local L_4812_ = {}
					local L_4813_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_4814_
					L_4814_ = function(...)
						return L_13_.fn_231(L_4812_, L_4813_, ...)
					end
					L_6_[L_4814_] = L_4813_
					L_3460_func(40, L_4814_)
				end
				do
					local L_4815_ = L_3459_func(38)
					L_3460_func(39, L_4815_)
					L_3460_func(38, L_4815_["Connect"])
				end
				do
					local L_4816_ = 2
					local L_4817_ = L_3462_func(39, L_4816_)
					local L_4818_ = L_1_(L_3459_func(38)(L_2_(L_4817_, 1, L_4817_.n)))
					for L_4819_forvar0 = 1, 1 do
						L_3460_func(38 + L_4819_forvar0 - 1, L_4818_[L_4819_forvar0])
					end
				end
				L_3459_func(37)["PlayerModifierLoop"] = L_3459_func(38)
				L_3460_func(37, L_10_func(L_3453_arg1, "PlayerSection"))
				L_3460_func(39, "WalkSpeed")
				L_3460_func(40, "Changes player speed")
				L_3460_func(41, 250)
				L_3460_func(42, 16)

				do
					local L_4820_ = {}
					local L_4821_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_4822_
					L_4822_ = function(...)
						return L_13_.fn_232_applyWalkSpeed(L_4820_, L_4821_, ...)
					end
					L_6_[L_4822_] = L_4821_
					L_3460_func(43, L_4822_)
				end
				do
					local L_4823_ = L_3459_func(37)
					L_3460_func(38, L_4823_)
					L_3460_func(37, L_4823_["NewSlider"])
				end
				do
					local L_4824_ = 6
					local L_4825_ = L_3462_func(38, L_4824_)
					L_3459_func(37)(L_2_(L_4825_, 1, L_4825_.n))
				end
				L_3460_func(37, L_10_func(L_3453_arg1, "PlayerSection"))
				L_3460_func(39, "JumpPower")
				L_3460_func(40, "Changes jump height")
				L_3460_func(41, 250)
				L_3460_func(42, 50)

				do
					local L_4826_ = {}
					local L_4827_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_4828_
					L_4828_ = function(...)
						return L_13_.fn_233_applyJumpPower(L_4826_, L_4827_, ...)
					end
					L_6_[L_4828_] = L_4827_
					L_3460_func(43, L_4828_)
				end
				do
					local L_4829_ = L_3459_func(37)
					L_3460_func(38, L_4829_)
					L_3460_func(37, L_4829_["NewSlider"])
				end
				do
					local L_4830_ = 6
					local L_4831_ = L_3462_func(38, L_4830_)
					L_3459_func(37)(L_2_(L_4831_, 1, L_4831_.n))
				end
				L_3460_func(37, L_10_func(L_3453_arg1, "PlayerSection"))
				L_3460_func(39, "Gravity")
				L_3460_func(40, "Changes world gravity")
				L_3460_func(41, 196)
				L_3460_func(42, 0)

				do
					local L_4832_ = {}
					local L_4833_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_4834_
					L_4834_ = function(...)
						return L_13_.fn_234_applyGravity(L_4832_, L_4833_, ...)
					end
					L_6_[L_4834_] = L_4833_
					L_3460_func(43, L_4834_)
				end
				do
					local L_4835_ = L_3459_func(37)
					L_3460_func(38, L_4835_)
					L_3460_func(37, L_4835_["NewSlider"])
				end
				do
					local L_4836_ = 6
					local L_4837_ = L_3462_func(38, L_4836_)
					L_3459_func(37)(L_2_(L_4837_, 1, L_4837_.n))
				end
				L_3460_func(37, L_10_func(L_3453_arg1, "PlayerSection"))
				L_3460_func(39, "God Mode")
				L_3460_func(40, "Instantly regenerates health")

				do
					local L_4838_ = {}
					local L_4839_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_4840_
					L_4840_ = function(...)
						return L_13_.fn_236_setGodMode(L_4838_, L_4839_, ...)
					end
					L_6_[L_4840_] = L_4839_
					L_3460_func(41, L_4840_)
				end
				do
					local L_4841_ = L_3459_func(37)
					L_3460_func(38, L_4841_)
					L_3460_func(37, L_4841_["NewPremiumToggle"])
				end
				do
					local L_4842_ = 4
					local L_4843_ = L_3462_func(38, L_4842_)
					L_3459_func(37)(L_2_(L_4843_, 1, L_4843_.n))
				end
				L_3460_func(37, nil)
				L_3460_func(38, nil)

				do
					local L_4844_ = {}
					L_4844_[1] = L_3461_func(38)
					L_4844_[2] = L_3461_func(37)
					local L_4845_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_4846_
					L_4846_ = function(...)
						return L_13_.fn_238_noclip(L_4844_, L_4845_, ...)
					end
					L_6_[L_4846_] = L_4845_
					L_3460_func(39, L_4846_)
				end
				L_11_func(L_3453_arg1, "noclip", L_3459_func(39))

				do
					local L_4847_ = {}
					L_4847_[1] = L_3461_func(37)
					L_4847_[2] = L_3461_func(38)
					local L_4848_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_4849_
					L_4849_ = function(...)
						return L_13_.fn_239_clip(L_4847_, L_4848_, ...)
					end
					L_6_[L_4849_] = L_4848_
					L_3460_func(39, L_4849_)
				end
				L_11_func(L_3453_arg1, "clip", L_3459_func(39))
				L_3460_func(39, L_10_func(L_3453_arg1, "PlayerSection"))
				L_3460_func(41, "Noclip")
				L_3460_func(42, "Walk through objects and walls")

				do
					local L_4850_ = {}
					local L_4851_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_4852_
					L_4852_ = function(...)
						return L_13_.fn_240(L_4850_, L_4851_, ...)
					end
					L_6_[L_4852_] = L_4851_
					L_3460_func(43, L_4852_)
				end
				do
					local L_4853_ = L_3459_func(39)
					L_3460_func(40, L_4853_)
					L_3460_func(39, L_4853_["NewPremiumToggle"])
				end
				do
					local L_4854_ = 4
					local L_4855_ = L_3462_func(40, L_4854_)
					L_3459_func(39)(L_2_(L_4855_, 1, L_4855_.n))
				end
				L_3460_func(39, false)
				L_3460_func(40, L_10_func(L_3453_arg1, "PlayerSection"))
				L_3460_func(42, "Infinite Jump")
				L_3460_func(43, "Jump in mid-air")

				do
					local L_4856_ = {}
					L_4856_[1] = L_3461_func(39)
					local L_4857_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_4858_
					L_4858_ = function(...)
						return L_13_.fn_242_bindInfiniteJump(L_4856_, L_4857_, ...)
					end
					L_6_[L_4858_] = L_4857_
					L_3460_func(44, L_4858_)
				end
				do
					local L_4859_ = L_3459_func(40)
					L_3460_func(41, L_4859_)
					L_3460_func(40, L_4859_["NewPremiumToggle"])
				end
				do
					local L_4860_ = 4
					local L_4861_ = L_3462_func(41, L_4860_)
					L_3459_func(40)(L_2_(L_4861_, 1, L_4861_.n))
				end
				L_3460_func(40, L_10_func(L_3453_arg1, "VisualSection"))
				L_3460_func(42, "Field of View")
				L_3460_func(43, "Change camera FOV")
				L_3460_func(44, 120)
				L_3460_func(45, 70)

				do
					local L_4862_ = {}
					local L_4863_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_4864_
					L_4864_ = function(...)
						return L_13_.fn_243_setCameraFov(L_4862_, L_4863_, ...)
					end
					L_6_[L_4864_] = L_4863_
					L_3460_func(46, L_4864_)
				end
				do
					local L_4865_ = L_3459_func(40)
					L_3460_func(41, L_4865_)
					L_3460_func(40, L_4865_["NewSlider"])
				end
				do
					local L_4866_ = 6
					local L_4867_ = L_3462_func(41, L_4866_)
					L_3459_func(40)(L_2_(L_4867_, 1, L_4867_.n))
				end
				L_3460_func(40, L_10_func(L_3453_arg1, "VisualSection"))
				L_3460_func(42, "Fullbright")
				L_3460_func(43, "Removes shadows and darkness")

				do
					local L_4868_ = {}
					local L_4869_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_4870_
					L_4870_ = function(...)
						return L_13_.fn_244_applyFullbright(L_4868_, L_4869_, ...)
					end
					L_6_[L_4870_] = L_4869_
					L_3460_func(44, L_4870_)
				end
				do
					local L_4871_ = L_3459_func(40)
					L_3460_func(41, L_4871_)
					L_3460_func(40, L_4871_["NewToggle"])
				end
				do
					local L_4872_ = 4
					local L_4873_ = L_3462_func(41, L_4872_)
					L_3459_func(40)(L_2_(L_4873_, 1, L_4873_.n))
				end
				L_3460_func(40, {})
				L_3460_func(41, L_10_func(L_3453_arg1, "VisualSection"))
				L_3460_func(43, "Player ESP")
				L_3460_func(44, "Highlights all players through walls")

				do
					local L_4874_ = {}
					L_4874_[1] = {
						L_3459_func(31)
					}
					L_4874_[2] = L_3461_func(40)
					local L_4875_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_4876_
					L_4876_ = function(...)
						return L_13_.fn_245_applyPlayerHighlights(L_4874_, L_4875_, ...)
					end
					L_6_[L_4876_] = L_4875_
					L_3460_func(45, L_4876_)
				end
				do
					local L_4877_ = L_3459_func(41)
					L_3460_func(42, L_4877_)
					L_3460_func(41, L_4877_["NewPremiumToggle"])
				end
				do
					local L_4878_ = 4
					local L_4879_ = L_3462_func(42, L_4878_)
					L_3459_func(41)(L_2_(L_4879_, 1, L_4879_.n))
				end
				L_3460_func(41, L_10_func(L_3453_arg1, "VisualSection"))
				L_3460_func(43, "Hitbox Expander")
				L_3460_func(44, "Make enemies easier to hit")
				L_3460_func(45, 20)
				L_3460_func(46, 2)

				do
					local L_4880_ = {}
					local L_4881_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_4882_
					L_4882_ = function(...)
						return L_13_.fn_248_startHitboxLoop(L_4880_, L_4881_, ...)
					end
					L_6_[L_4882_] = L_4881_
					L_3460_func(47, L_4882_)
				end
				do
					local L_4883_ = L_3459_func(41)
					L_3460_func(42, L_4883_)
					L_3460_func(41, L_4883_["NewPremiumSlider"])
				end
				do
					local L_4884_ = 6
					local L_4885_ = L_3462_func(42, L_4884_)
					L_3459_func(41)(L_2_(L_4885_, 1, L_4885_.n))
				end
				L_3460_func(41, L_10_func(L_3453_arg1, "UtilSection"))
				L_3460_func(43, "Give Btools")
				L_3460_func(44, "Gives building tools to inventory")

				do
					local L_4886_ = {}
					local L_4887_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_4888_
					L_4888_ = function(...)
						return L_13_.fn_249_giveBuildingTools(L_4886_, L_4887_, ...)
					end
					L_6_[L_4888_] = L_4887_
					L_3460_func(45, L_4888_)
				end
				do
					local L_4889_ = L_3459_func(41)
					L_3460_func(42, L_4889_)
					L_3460_func(41, L_4889_["NewButton"])
				end
				do
					local L_4890_ = 4
					local L_4891_ = L_3462_func(42, L_4890_)
					L_3459_func(41)(L_2_(L_4891_, 1, L_4891_.n))
				end
				L_3460_func(41, L_10_func(L_3453_arg1, "UtilSection"))
				L_3460_func(43, "Teleport to Random Player")
				L_3460_func(44, "TPs you to a random user")

				do
					local L_4892_ = {}
					local L_4893_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_4894_
					L_4894_ = function(...)
						return L_13_.fn_250_teleportRandomPlayer(L_4892_, L_4893_, ...)
					end
					L_6_[L_4894_] = L_4893_
					L_3460_func(45, L_4894_)
				end
				do
					local L_4895_ = L_3459_func(41)
					L_3460_func(42, L_4895_)
					L_3460_func(41, L_4895_["NewPremiumButton"])
				end
				do
					local L_4896_ = 4
					local L_4897_ = L_3462_func(42, L_4896_)
					L_3459_func(41)(L_2_(L_4897_, 1, L_4897_.n))
				end
				L_3460_func(41, L_10_func(L_3453_arg1, "UtilSection"))
				L_3460_func(43, "Rejoin Server")
				L_3460_func(44, "Rejoins the same server")

				do
					local L_4898_ = {}
					local L_4899_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_4900_
					L_4900_ = function(...)
						return L_13_.fn_251_rejoinServer(L_4898_, L_4899_, ...)
					end
					L_6_[L_4900_] = L_4899_
					L_3460_func(45, L_4900_)
				end
				do
					local L_4901_ = L_3459_func(41)
					L_3460_func(42, L_4901_)
					L_3460_func(41, L_4901_["NewButton"])
				end
				do
					local L_4902_ = 4
					local L_4903_ = L_3462_func(42, L_4902_)
					L_3459_func(41)(L_2_(L_4903_, 1, L_4903_.n))
				end
				L_3460_func(41, L_10_func(L_3453_arg1, "UtilSection"))
				L_3460_func(43, "Server Hop")
				L_3460_func(44, "Joins a random new server")

				do
					local L_4904_ = {}
					local L_4905_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_4906_
					L_4906_ = function(...)
						return L_13_.fn_253_serverHop(L_4904_, L_4905_, ...)
					end
					L_6_[L_4906_] = L_4905_
					L_3460_func(45, L_4906_)
				end
				do
					local L_4907_ = L_3459_func(41)
					L_3460_func(42, L_4907_)
					L_3460_func(41, L_4907_["NewPremiumButton"])
				end
				do
					local L_4908_ = 4
					local L_4909_ = L_3462_func(42, L_4908_)
					L_3459_func(41)(L_2_(L_4909_, 1, L_4909_.n))
				end
				L_3460_func(41, L_10_func(L_3453_arg1, "UtilSection"))
				L_3460_func(43, "Anti-AFK")
				L_3460_func(44, "Prevents Roblox disconnects")

				do
					local L_4910_ = {}
					local L_4911_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_4912_
					L_4912_ = function(...)
						return L_13_.fn_254_installAntiAfk(L_4910_, L_4911_, ...)
					end
					L_6_[L_4912_] = L_4911_
					L_3460_func(45, L_4912_)
				end
				do
					local L_4913_ = L_3459_func(41)
					L_3460_func(42, L_4913_)
					L_3460_func(41, L_4913_["NewToggle"])
				end
				do
					local L_4914_ = 4
					local L_4915_ = L_3462_func(42, L_4914_)
					L_3459_func(41)(L_2_(L_4915_, 1, L_4915_.n))
				end
				L_3460_func(41, {})
				L_3460_func(42, false)
				L_3459_func(41)["Enabled"] = L_3459_func(42)
				L_3460_func(42, false)
				L_3459_func(41)["ShowFOV"] = L_3459_func(42)
				L_3460_func(42, 80)
				L_3459_func(41)["FOVRadius"] = L_3459_func(42)
				L_3460_func(42, 0.5)
				L_3459_func(41)["Smoothness"] = L_3459_func(42)
				L_3460_func(42, true)
				L_3459_func(41)["TeamCheck"] = L_3459_func(42)
				L_3460_func(42, "Head")
				L_3459_func(41)["TargetPart"] = L_3459_func(42)
				L_3460_func(42, L_10_func(L_3453_arg1, "Drawing"))
				L_3460_func(42, L_3459_func(42)["new"])
				L_3460_func(43, "Circle")
				do
					local L_4916_ = 1
					local L_4917_ = L_3462_func(43, L_4916_)
					local L_4918_ = L_1_(L_3459_func(42)(L_2_(L_4917_, 1, L_4917_.n)))
					for L_4919_forvar0 = 1, 1 do
						L_3460_func(42 + L_4919_forvar0 - 1, L_4918_[L_4919_forvar0])
					end
				end
				L_3460_func(43, L_10_func(L_3453_arg1, "Vector2"))
				L_3460_func(43, L_3459_func(43)["new"])
				L_3460_func(47, L_10_func(L_3453_arg1, "game"))
				L_3460_func(47, L_3459_func(47)["Workspace"])
				L_3460_func(47, L_3459_func(47)["CurrentCamera"])
				L_3460_func(46, L_3459_func(47)["ViewportSize"])
				L_3460_func(45, L_3459_func(46)["X"])
				L_3460_func(46, 2)
				L_3460_func(44, L_3459_func(45) / L_3459_func(46))
				L_3460_func(48, L_10_func(L_3453_arg1, "game"))
				L_3460_func(48, L_3459_func(48)["Workspace"])
				L_3460_func(48, L_3459_func(48)["CurrentCamera"])
				L_3460_func(47, L_3459_func(48)["ViewportSize"])
				L_3460_func(46, L_3459_func(47)["Y"])
				L_3460_func(47, 2)
				L_3460_func(45, L_3459_func(46) / L_3459_func(47))
				do
					local L_4920_ = 2
					local L_4921_ = L_3462_func(44, L_4920_)
					local L_4922_ = L_1_(L_3459_func(43)(L_2_(L_4921_, 1, L_4921_.n)))
					for L_4923_forvar0 = 1, 1 do
						L_3460_func(43 + L_4923_forvar0 - 1, L_4922_[L_4923_forvar0])
					end
				end
				L_3459_func(42)["Position"] = L_3459_func(43)
				L_3460_func(43, L_3459_func(41)["FOVRadius"])
				L_3459_func(42)["Radius"] = L_3459_func(43)
				L_3460_func(43, false)
				L_3459_func(42)["Filled"] = L_3459_func(43)
				L_3460_func(43, L_10_func(L_3453_arg1, "Color3"))
				L_3460_func(43, L_3459_func(43)["fromRGB"])
				L_3460_func(44, 255)
				L_3460_func(45, 255)
				L_3460_func(46, 255)
				do
					local L_4924_ = 3
					local L_4925_ = L_3462_func(44, L_4924_)
					local L_4926_ = L_1_(L_3459_func(43)(L_2_(L_4925_, 1, L_4925_.n)))
					for L_4927_forvar0 = 1, 1 do
						L_3460_func(43 + L_4927_forvar0 - 1, L_4926_[L_4927_forvar0])
					end
				end
				L_3459_func(42)["Color"] = L_3459_func(43)
				L_3460_func(43, false)
				L_3459_func(42)["Visible"] = L_3459_func(43)
				L_3460_func(43, 1)
				L_3459_func(42)["Thickness"] = L_3459_func(43)

				do
					local L_4928_ = {}
					L_4928_[1] = {
						L_3459_func(41)
					}
					local L_4929_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_4930_
					L_4930_ = function(...)
						return L_13_.fn_255_findAimTarget(L_4928_, L_4929_, ...)
					end
					L_6_[L_4930_] = L_4929_
					L_3460_func(43, L_4930_)
				end
				L_3460_func(45, L_10_func(L_3453_arg1, "game"))
				L_3460_func(47, "RunService")
				do
					local L_4931_ = L_3459_func(45)
					L_3460_func(46, L_4931_)
					L_3460_func(45, L_4931_["GetService"])
				end
				L_3463_ = 2560
			else
				error("invalid recovered basic block in main: " .. tostring(L_3463_))
			end
		elseif L_3475_ == 10 then
			if L_3463_ == 2560 then

				do
					local L_4932_ = 2
					local L_4933_ = L_3462_func(46, L_4932_)
					local L_4934_ = L_1_(L_3459_func(45)(L_2_(L_4933_, 1, L_4933_.n)))
					for L_4935_forvar0 = 1, 1 do
						L_3460_func(45 + L_4935_forvar0 - 1, L_4934_[L_4935_forvar0])
					end
				end
				L_3460_func(44, L_3459_func(45)["RenderStepped"])

				do
					local L_4936_ = {}
					L_4936_[1] = {
						L_3459_func(41)
					}
					L_4936_[2] = {
						L_3459_func(42)
					}
					L_4936_[3] = {
						L_3459_func(43)
					}
					local L_4937_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_4938_
					L_4938_ = function(...)
						return L_13_.fn_256_updateFovCircle(L_4936_, L_4937_, ...)
					end
					L_6_[L_4938_] = L_4937_
					L_3460_func(46, L_4938_)
				end
				do
					local L_4939_ = L_3459_func(44)
					L_3460_func(45, L_4939_)
					L_3460_func(44, L_4939_["Connect"])
				end
				do
					local L_4940_ = 2
					local L_4941_ = L_3462_func(45, L_4940_)
					L_3459_func(44)(L_2_(L_4941_, 1, L_4941_.n))
				end
				L_3460_func(44, L_10_func(L_3453_arg1, "AimbotSection"))
				L_3460_func(46, "Enable Aimbot (Right Click)")
				L_3460_func(47, "Locks onto targets in FOV")

				do
					local L_4942_ = {}
					L_4942_[1] = {
						L_3459_func(41)
					}
					local L_4943_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_4944_
					L_4944_ = function(...)
						return L_13_.fn_257_setAimEnabled(L_4942_, L_4943_, ...)
					end
					L_6_[L_4944_] = L_4943_
					L_3460_func(48, L_4944_)
				end
				do
					local L_4945_ = L_3459_func(44)
					L_3460_func(45, L_4945_)
					L_3460_func(44, L_4945_["NewPremiumToggle"])
				end
				do
					local L_4946_ = 4
					local L_4947_ = L_3462_func(45, L_4946_)
					L_3459_func(44)(L_2_(L_4947_, 1, L_4947_.n))
				end
				L_3460_func(44, L_10_func(L_3453_arg1, "AimbotSection"))
				L_3460_func(46, "Show FOV Circle")
				L_3460_func(47, "Displays the aimbot radius")

				do
					local L_4948_ = {}
					L_4948_[1] = {
						L_3459_func(41)
					}
					local L_4949_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_4950_
					L_4950_ = function(...)
						return L_13_.fn_258_setShowFov(L_4948_, L_4949_, ...)
					end
					L_6_[L_4950_] = L_4949_
					L_3460_func(48, L_4950_)
				end
				do
					local L_4951_ = L_3459_func(44)
					L_3460_func(45, L_4951_)
					L_3460_func(44, L_4951_["NewToggle"])
				end
				do
					local L_4952_ = 4
					local L_4953_ = L_3462_func(45, L_4952_)
					L_3459_func(44)(L_2_(L_4953_, 1, L_4953_.n))
				end
				L_3460_func(44, L_10_func(L_3453_arg1, "AimbotSection"))
				L_3460_func(46, "FOV Size")
				L_3460_func(47, "Target area size")
				L_3460_func(48, 300)
				L_3460_func(49, 20)

				do
					local L_4954_ = {}
					L_4954_[1] = {
						L_3459_func(41)
					}
					local L_4955_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_4956_
					L_4956_ = function(...)
						return L_13_.fn_259_setFovRadius(L_4954_, L_4955_, ...)
					end
					L_6_[L_4956_] = L_4955_
					L_3460_func(50, L_4956_)
				end
				do
					local L_4957_ = L_3459_func(44)
					L_3460_func(45, L_4957_)
					L_3460_func(44, L_4957_["NewSlider"])
				end
				do
					local L_4958_ = 6
					local L_4959_ = L_3462_func(45, L_4958_)
					L_3459_func(44)(L_2_(L_4959_, 1, L_4959_.n))
				end
				L_3460_func(44, L_10_func(L_3453_arg1, "AimbotSection"))
				L_3460_func(46, "Aimbot Smoothness")
				L_3460_func(47, "100=Instant, 1=Slow")
				L_3460_func(48, 100)
				L_3460_func(49, 1)

				do
					local L_4960_ = {}
					L_4960_[1] = {
						L_3459_func(41)
					}
					local L_4961_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_4962_
					L_4962_ = function(...)
						return L_13_.fn_260_setAimSmoothness(L_4960_, L_4961_, ...)
					end
					L_6_[L_4962_] = L_4961_
					L_3460_func(50, L_4962_)
				end
				do
					local L_4963_ = L_3459_func(44)
					L_3460_func(45, L_4963_)
					L_3460_func(44, L_4963_["NewPremiumSlider"])
				end
				do
					local L_4964_ = 6
					local L_4965_ = L_3462_func(45, L_4964_)
					L_3459_func(44)(L_2_(L_4965_, 1, L_4965_.n))
				end
				L_3460_func(44, L_10_func(L_3453_arg1, "AimbotSection"))
				L_3460_func(46, "Team Check")
				L_3460_func(47, "Ignores teammates")

				do
					local L_4966_ = {}
					L_4966_[1] = {
						L_3459_func(41)
					}
					local L_4967_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_4968_
					L_4968_ = function(...)
						return L_13_.fn_261_setTeamCheck(L_4966_, L_4967_, ...)
					end
					L_6_[L_4968_] = L_4967_
					L_3460_func(48, L_4968_)
				end
				do
					local L_4969_ = L_3459_func(44)
					L_3460_func(45, L_4969_)
					L_3460_func(44, L_4969_["NewToggle"])
				end
				do
					local L_4970_ = 4
					local L_4971_ = L_3462_func(45, L_4970_)
					L_3459_func(44)(L_2_(L_4971_, 1, L_4971_.n))
				end
				L_3460_func(44, L_10_func(L_3453_arg1, "UISec"))
				L_3460_func(46, "Test Notification")
				L_3460_func(47, "Test the notification system")

				do
					local L_4972_ = {}
					L_4972_[1] = {
						L_3459_func(13)
					}
					local L_4973_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_4974_
					L_4974_ = function(...)
						return L_13_.fn_262_testNotification(L_4972_, L_4973_, ...)
					end
					L_6_[L_4974_] = L_4973_
					L_3460_func(48, L_4974_)
				end
				do
					local L_4975_ = L_3459_func(44)
					L_3460_func(45, L_4975_)
					L_3460_func(44, L_4975_["NewButton"])
				end
				do
					local L_4976_ = 4
					local L_4977_ = L_3462_func(45, L_4976_)
					L_3459_func(44)(L_2_(L_4977_, 1, L_4977_.n))
				end
				L_3460_func(44, L_10_func(L_3453_arg1, "UISec"))
				L_3460_func(46, "Test Premium Alert")
				L_3460_func(47, "Premium-style notification")

				do
					local L_4978_ = {}
					L_4978_[1] = {
						L_3459_func(13)
					}
					local L_4979_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_4980_
					L_4980_ = function(...)
						return L_13_.fn_263_testPremiumNotification(L_4978_, L_4979_, ...)
					end
					L_6_[L_4980_] = L_4979_
					L_3460_func(48, L_4980_)
				end
				do
					local L_4981_ = L_3459_func(44)
					L_3460_func(45, L_4981_)
					L_3460_func(44, L_4981_["NewButton"])
				end
				do
					local L_4982_ = 4
					local L_4983_ = L_3462_func(45, L_4982_)
					L_3459_func(44)(L_2_(L_4983_, 1, L_4983_.n))
				end
				L_3460_func(44, 0)
				L_3460_func(45, L_10_func(L_3453_arg1, "UISec"))
				L_3460_func(47, "UI Opacity")
				L_3460_func(48, "Adjust hub transparency")
				L_3460_func(49, 8)
				L_3460_func(50, 0)

				do
					local L_4984_ = {}
					L_4984_[1] = L_3461_func(44)
					local L_4985_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_4986_
					L_4986_ = function(...)
						return L_13_.fn_265(L_4984_, L_4985_, ...)
					end
					L_6_[L_4986_] = L_4985_
					L_3460_func(51, L_4986_)
				end
				do
					local L_4987_ = L_3459_func(45)
					L_3460_func(46, L_4987_)
					L_3460_func(45, L_4987_["NewSlider"])
				end
				do
					local L_4988_ = 6
					local L_4989_ = L_3462_func(46, L_4988_)
					L_3459_func(45)(L_2_(L_4989_, 1, L_4989_.n))
				end
				L_3460_func(45, L_10_func(L_3453_arg1, "InfoSec"))
				L_3460_func(47, "Right-click = Hold to aim (Aimbot)")
				do
					local L_4990_ = L_3459_func(45)
					L_3460_func(46, L_4990_)
					L_3460_func(45, L_4990_["NewLabel"])
				end
				do
					local L_4991_ = 2
					local L_4992_ = L_3462_func(46, L_4991_)
					L_3459_func(45)(L_2_(L_4992_, 1, L_4992_.n))
				end
				L_3460_func(45, L_10_func(L_3453_arg1, "InfoSec"))
				L_3460_func(47, "Drag title bar to move")
				do
					local L_4993_ = L_3459_func(45)
					L_3460_func(46, L_4993_)
					L_3460_func(45, L_4993_["NewLabel"])
				end
				do
					local L_4994_ = 2
					local L_4995_ = L_3462_func(46, L_4994_)
					L_3459_func(45)(L_2_(L_4995_, 1, L_4995_.n))
				end
				L_3460_func(45, L_10_func(L_3453_arg1, "InfoSec"))
				L_3460_func(47, "discord.gg/getsnowy")
				do
					local L_4996_ = L_3459_func(45)
					L_3460_func(46, L_4996_)
					L_3460_func(45, L_4996_["NewLabel"])
				end
				do
					local L_4997_ = 2
					local L_4998_ = L_3462_func(46, L_4997_)
					L_3459_func(45)(L_2_(L_4998_, 1, L_4998_.n))
				end
				L_3460_func(45, L_10_func(L_3453_arg1, "InfoSec"))
				L_3460_func(47, "Copy Discord")
				L_3460_func(48, "Copy invite link")

				do
					local L_4999_ = {}
					L_4999_[1] = {
						L_3459_func(13)
					}
					local L_5000_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_5001_
					L_5001_ = function(...)
						return L_13_.fn_266_copyDiscord(L_4999_, L_5000_, ...)
					end
					L_6_[L_5001_] = L_5000_
					L_3460_func(49, L_5001_)
				end
				do
					local L_5002_ = L_3459_func(45)
					L_3460_func(46, L_5002_)
					L_3460_func(45, L_5002_["NewButton"])
				end
				do
					local L_5003_ = 4
					local L_5004_ = L_3462_func(46, L_5003_)
					L_3459_func(45)(L_2_(L_5004_, 1, L_5004_.n))
				end
				L_3460_func(45, L_10_func(L_3453_arg1, "ScriptSec"))
				L_3460_func(47, "Reload Hub")
				L_3460_func(48, "Destroys and reloads the UI")

				do
					local L_5005_ = {}
					L_5005_[1] = {
						L_3459_func(21)
					}
					L_5005_[2] = {
						L_3459_func(31)
					}
					L_5005_[3] = {
						L_3459_func(13)
					}
					local L_5006_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_5007_
					L_5007_ = function(...)
						return L_13_.fn_269_reloadHubUi(L_5005_, L_5006_, ...)
					end
					L_6_[L_5007_] = L_5006_
					L_3460_func(49, L_5007_)
				end
				do
					local L_5008_ = L_3459_func(45)
					L_3460_func(46, L_5008_)
					L_3460_func(45, L_5008_["NewButton"])
				end
				do
					local L_5009_ = 4
					local L_5010_ = L_3462_func(46, L_5009_)
					L_3459_func(45)(L_2_(L_5010_, 1, L_5010_.n))
				end
				L_3460_func(45, L_10_func(L_3453_arg1, "ScriptSec"))
				L_3460_func(47, "SNOWY HUB v6.0 | Built by Snowy Studios")
				do
					local L_5011_ = L_3459_func(45)
					L_3460_func(46, L_5011_)
					L_3460_func(45, L_5011_["NewLabel"])
				end
				do
					local L_5012_ = 2
					local L_5013_ = L_3462_func(46, L_5012_)
					L_3459_func(45)(L_2_(L_5013_, 1, L_5013_.n))
				end
				L_3460_func(45, L_10_func(L_3453_arg1, "ScriptSec"))
				L_3460_func(51, #L_3459_func(8))
				L_3460_func(50, L_10_func(L_3453_arg1, "tostring"))
				do
					local L_5014_ = 1
					local L_5015_ = L_3462_func(51, L_5014_)
					local L_5016_ = L_1_(L_3459_func(50)(L_2_(L_5015_, 1, L_5015_.n)))
					for L_5017_forvar0 = 1, 1 do
						L_3460_func(50 + L_5017_forvar0 - 1, L_5016_[L_5017_forvar0])
					end
				end
				L_3460_func(48, L_3459_func(50))
				L_3460_func(49, " Games Supported")
				do
					local L_5018_ = L_3459_func(49)
					for L_5019_forvar0 = 48, 48, -1 do
						L_5018_ = L_3459_func(L_5019_forvar0) .. L_5018_
					end
					L_3460_func(47, L_5018_)
				end
				do
					local L_5020_ = L_3459_func(45)
					L_3460_func(46, L_5020_)
					L_3460_func(45, L_5020_["NewLabel"])
				end
				do
					local L_5021_ = 2
					local L_5022_ = L_3462_func(46, L_5021_)
					L_3459_func(45)(L_2_(L_5022_, 1, L_5022_.n))
				end

				for L_5023_forvar0 = 37, L_3456_ do
					local L_5024_ = L_3455_[L_5023_forvar0]
					if L_5024_ ~= nil then
						L_3454_[L_5023_forvar0] = L_5024_[1]
						L_3455_[L_5023_forvar0] = nil
					end
				end
				L_3463_ = 2740
			elseif L_3463_ == 2674 then

				do
					local L_5025_ = {}
					local L_5026_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_5027_
					L_5027_ = function(...)
						return L_13_.fn_273(L_5025_, L_5026_, ...)
					end
					L_6_[L_5027_] = L_5026_
					L_3460_func(37, L_5027_)
				end
				L_3460_func(38, L_10_func(L_3453_arg1, "getgenv"))
				do
					local L_5028_ = 0
					local L_5029_ = L_3462_func(39, L_5028_)
					local L_5030_ = L_1_(L_3459_func(38)(L_2_(L_5029_, 1, L_5029_.n)))
					for L_5031_forvar0 = 1, 1 do
						L_3460_func(38 + L_5031_forvar0 - 1, L_5030_[L_5031_forvar0])
					end
				end
				L_3460_func(39, L_3459_func(37))
				do
					local L_5032_ = 0
					local L_5033_ = L_3462_func(40, L_5032_)
					local L_5034_ = L_1_(L_3459_func(39)(L_2_(L_5033_, 1, L_5033_.n)))
					for L_5035_forvar0 = 1, 1 do
						L_3460_func(39 + L_5035_forvar0 - 1, L_5034_[L_5035_forvar0])
					end
				end
				L_3459_func(38)["HomeTab"] = L_3459_func(39)
				L_3460_func(38, L_10_func(L_3453_arg1, "getgenv"))
				do
					local L_5036_ = 0
					local L_5037_ = L_3462_func(39, L_5036_)
					local L_5038_ = L_1_(L_3459_func(38)(L_2_(L_5037_, 1, L_5037_.n)))
					for L_5039_forvar0 = 1, 1 do
						L_3460_func(38 + L_5039_forvar0 - 1, L_5038_[L_5039_forvar0])
					end
				end
				L_3460_func(39, L_3459_func(37))
				do
					local L_5040_ = 0
					local L_5041_ = L_3462_func(40, L_5040_)
					local L_5042_ = L_1_(L_3459_func(39)(L_2_(L_5041_, 1, L_5041_.n)))
					for L_5043_forvar0 = 1, 1 do
						L_3460_func(39 + L_5043_forvar0 - 1, L_5042_[L_5043_forvar0])
					end
				end
				L_3459_func(38)["PlayerTab"] = L_3459_func(39)
				L_3460_func(38, L_10_func(L_3453_arg1, "getgenv"))
				do
					local L_5044_ = 0
					local L_5045_ = L_3462_func(39, L_5044_)
					local L_5046_ = L_1_(L_3459_func(38)(L_2_(L_5045_, 1, L_5045_.n)))
					for L_5047_forvar0 = 1, 1 do
						L_3460_func(38 + L_5047_forvar0 - 1, L_5046_[L_5047_forvar0])
					end
				end
				L_3460_func(39, L_3459_func(37))
				do
					local L_5048_ = 0
					local L_5049_ = L_3462_func(40, L_5048_)
					local L_5050_ = L_1_(L_3459_func(39)(L_2_(L_5049_, 1, L_5049_.n)))
					for L_5051_forvar0 = 1, 1 do
						L_3460_func(39 + L_5051_forvar0 - 1, L_5050_[L_5051_forvar0])
					end
				end
				L_3459_func(38)["VisualTab"] = L_3459_func(39)
				L_3460_func(38, L_10_func(L_3453_arg1, "getgenv"))
				do
					local L_5052_ = 0
					local L_5053_ = L_3462_func(39, L_5052_)
					local L_5054_ = L_1_(L_3459_func(38)(L_2_(L_5053_, 1, L_5053_.n)))
					for L_5055_forvar0 = 1, 1 do
						L_3460_func(38 + L_5055_forvar0 - 1, L_5054_[L_5055_forvar0])
					end
				end
				L_3460_func(39, L_3459_func(37))
				do
					local L_5056_ = 0
					local L_5057_ = L_3462_func(40, L_5056_)
					local L_5058_ = L_1_(L_3459_func(39)(L_2_(L_5057_, 1, L_5057_.n)))
					for L_5059_forvar0 = 1, 1 do
						L_3460_func(39 + L_5059_forvar0 - 1, L_5058_[L_5059_forvar0])
					end
				end
				L_3459_func(38)["UtilTab"] = L_3459_func(39)
				L_3460_func(38, L_10_func(L_3453_arg1, "getgenv"))
				do
					local L_5060_ = 0
					local L_5061_ = L_3462_func(39, L_5060_)
					local L_5062_ = L_1_(L_3459_func(38)(L_2_(L_5061_, 1, L_5061_.n)))
					for L_5063_forvar0 = 1, 1 do
						L_3460_func(38 + L_5063_forvar0 - 1, L_5062_[L_5063_forvar0])
					end
				end
				L_3460_func(39, L_3459_func(37))
				do
					local L_5064_ = 0
					local L_5065_ = L_3462_func(40, L_5064_)
					local L_5066_ = L_1_(L_3459_func(39)(L_2_(L_5065_, 1, L_5065_.n)))
					for L_5067_forvar0 = 1, 1 do
						L_3460_func(39 + L_5067_forvar0 - 1, L_5066_[L_5067_forvar0])
					end
				end
				L_3459_func(38)["AimbotTab"] = L_3459_func(39)
				L_3460_func(38, L_10_func(L_3453_arg1, "getgenv"))
				do
					local L_5068_ = 0
					local L_5069_ = L_3462_func(39, L_5068_)
					local L_5070_ = L_1_(L_3459_func(38)(L_2_(L_5069_, 1, L_5069_.n)))
					for L_5071_forvar0 = 1, 1 do
						L_3460_func(38 + L_5071_forvar0 - 1, L_5070_[L_5071_forvar0])
					end
				end
				L_3460_func(39, L_3459_func(37))
				do
					local L_5072_ = 0
					local L_5073_ = L_3462_func(40, L_5072_)
					local L_5074_ = L_1_(L_3459_func(39)(L_2_(L_5073_, 1, L_5073_.n)))
					for L_5075_forvar0 = 1, 1 do
						L_3460_func(39 + L_5075_forvar0 - 1, L_5074_[L_5075_forvar0])
					end
				end
				L_3459_func(38)["SettingsTab"] = L_3459_func(39)
				L_3460_func(38, L_10_func(L_3453_arg1, "HomeTab"))
				do
					local L_5076_ = L_3459_func(38)
					L_3460_func(39, L_5076_)
					L_3460_func(38, L_5076_["NewSection"])
				end
				do
					local L_5077_ = 1
					local L_5078_ = L_3462_func(39, L_5077_)
					local L_5079_ = L_1_(L_3459_func(38)(L_2_(L_5078_, 1, L_5078_.n)))
					for L_5080_forvar0 = 1, 1 do
						L_3460_func(38 + L_5080_forvar0 - 1, L_5079_[L_5080_forvar0])
					end
				end
				L_3460_func(39, L_10_func(L_3453_arg1, "getgenv"))
				do
					local L_5081_ = 0
					local L_5082_ = L_3462_func(40, L_5081_)
					local L_5083_ = L_1_(L_3459_func(39)(L_2_(L_5082_, 1, L_5082_.n)))
					for L_5084_forvar0 = 1, 1 do
						L_3460_func(39 + L_5084_forvar0 - 1, L_5083_[L_5084_forvar0])
					end
				end
				L_3459_func(39)["HomeSec"] = L_3459_func(38)
				L_3460_func(39, L_10_func(L_3453_arg1, "getgenv"))
				do
					local L_5085_ = 0
					local L_5086_ = L_3462_func(40, L_5085_)
					local L_5087_ = L_1_(L_3459_func(39)(L_2_(L_5086_, 1, L_5086_.n)))
					for L_5088_forvar0 = 1, 1 do
						L_3460_func(39 + L_5088_forvar0 - 1, L_5087_[L_5088_forvar0])
					end
				end
				L_3459_func(39)["PlayerSection"] = L_3459_func(38)
				L_3460_func(39, L_10_func(L_3453_arg1, "getgenv"))
				do
					local L_5089_ = 0
					local L_5090_ = L_3462_func(40, L_5089_)
					local L_5091_ = L_1_(L_3459_func(39)(L_2_(L_5090_, 1, L_5090_.n)))
					for L_5092_forvar0 = 1, 1 do
						L_3460_func(39 + L_5092_forvar0 - 1, L_5091_[L_5092_forvar0])
					end
				end
				L_3459_func(39)["VisualSection"] = L_3459_func(38)
				L_3460_func(39, L_10_func(L_3453_arg1, "getgenv"))
				do
					local L_5093_ = 0
					local L_5094_ = L_3462_func(40, L_5093_)
					local L_5095_ = L_1_(L_3459_func(39)(L_2_(L_5094_, 1, L_5094_.n)))
					for L_5096_forvar0 = 1, 1 do
						L_3460_func(39 + L_5096_forvar0 - 1, L_5095_[L_5096_forvar0])
					end
				end
				L_3459_func(39)["UtilSection"] = L_3459_func(38)
				L_3460_func(39, L_10_func(L_3453_arg1, "getgenv"))
				do
					local L_5097_ = 0
					local L_5098_ = L_3462_func(40, L_5097_)
					local L_5099_ = L_1_(L_3459_func(39)(L_2_(L_5098_, 1, L_5098_.n)))
					for L_5100_forvar0 = 1, 1 do
						L_3460_func(39 + L_5100_forvar0 - 1, L_5099_[L_5100_forvar0])
					end
				end
				L_3459_func(39)["AimbotSection"] = L_3459_func(38)
				L_3460_func(39, L_10_func(L_3453_arg1, "getgenv"))
				do
					local L_5101_ = 0
					local L_5102_ = L_3462_func(40, L_5101_)
					local L_5103_ = L_1_(L_3459_func(39)(L_2_(L_5102_, 1, L_5102_.n)))
					for L_5104_forvar0 = 1, 1 do
						L_3460_func(39 + L_5104_forvar0 - 1, L_5103_[L_5104_forvar0])
					end
				end
				L_3459_func(39)["UISec"] = L_3459_func(38)
				L_3460_func(39, L_10_func(L_3453_arg1, "getgenv"))
				do
					local L_5105_ = 0
					local L_5106_ = L_3462_func(40, L_5105_)
					local L_5107_ = L_1_(L_3459_func(39)(L_2_(L_5106_, 1, L_5106_.n)))
					for L_5108_forvar0 = 1, 1 do
						L_3460_func(39 + L_5108_forvar0 - 1, L_5107_[L_5108_forvar0])
					end
				end
				L_3459_func(39)["InfoSec"] = L_3459_func(38)
				L_3460_func(39, L_10_func(L_3453_arg1, "getgenv"))
				do
					local L_5109_ = 0
					local L_5110_ = L_3462_func(40, L_5109_)
					local L_5111_ = L_1_(L_3459_func(39)(L_2_(L_5110_, 1, L_5110_.n)))
					for L_5112_forvar0 = 1, 1 do
						L_3460_func(39 + L_5112_forvar0 - 1, L_5111_[L_5112_forvar0])
					end
				end
				L_3459_func(39)["ScriptSec"] = L_3459_func(38)
				L_3463_ = 2740
			elseif L_3463_ == 2740 then

				if not L_3459_func(9) then
					L_3463_ = 3118
				else
					L_3463_ = 2741
				end
			elseif L_3463_ == 2741 then

				L_3460_func(37, L_3459_func(9)["name"])
				L_3460_func(72, "Da Hood")
				L_3460_func(73, L_3459_func(37) == L_3459_func(72))
				if not L_3459_func(73) then
					L_3463_ = 3118
				else
					L_3463_ = 2745
				end
			elseif L_3463_ == 2745 then

				L_3460_func(37, L_3459_func(35))
				L_3460_func(38, "Da Hood")
				L_3460_func(39, "Da Hood")
				do
					local L_5113_ = 2
					local L_5114_ = L_3462_func(38, L_5113_)
					local L_5115_ = L_1_(L_3459_func(37)(L_2_(L_5114_, 1, L_5114_.n)))
					for L_5116_forvar0 = 1, 1 do
						L_3460_func(37 + L_5116_forvar0 - 1, L_5115_[L_5116_forvar0])
					end
				end
				L_3460_func(40, "Combat")
				do
					local L_5117_ = L_3459_func(37)
					L_3460_func(39, L_5117_)
					L_3460_func(38, L_5117_["NewSection"])
				end
				do
					local L_5118_ = 2
					local L_5119_ = L_3462_func(39, L_5118_)
					local L_5120_ = L_1_(L_3459_func(38)(L_2_(L_5119_, 1, L_5119_.n)))
					for L_5121_forvar0 = 1, 1 do
						L_3460_func(38 + L_5121_forvar0 - 1, L_5120_[L_5121_forvar0])
					end
				end
				L_3460_func(41, "Movement")
				do
					local L_5122_ = L_3459_func(37)
					L_3460_func(40, L_5122_)
					L_3460_func(39, L_5122_["NewSection"])
				end
				do
					local L_5123_ = 2
					local L_5124_ = L_3462_func(40, L_5123_)
					local L_5125_ = L_1_(L_3459_func(39)(L_2_(L_5124_, 1, L_5124_.n)))
					for L_5126_forvar0 = 1, 1 do
						L_3460_func(39 + L_5126_forvar0 - 1, L_5125_[L_5126_forvar0])
					end
				end
				L_3460_func(42, "Visuals")
				do
					local L_5127_ = L_3459_func(37)
					L_3460_func(41, L_5127_)
					L_3460_func(40, L_5127_["NewSection"])
				end
				do
					local L_5128_ = 2
					local L_5129_ = L_3462_func(41, L_5128_)
					local L_5130_ = L_1_(L_3459_func(40)(L_2_(L_5129_, 1, L_5129_.n)))
					for L_5131_forvar0 = 1, 1 do
						L_3460_func(40 + L_5131_forvar0 - 1, L_5130_[L_5131_forvar0])
					end
				end
				L_3460_func(43, "Utility")
				do
					local L_5132_ = L_3459_func(37)
					L_3460_func(42, L_5132_)
					L_3460_func(41, L_5132_["NewSection"])
				end
				do
					local L_5133_ = 2
					local L_5134_ = L_3462_func(42, L_5133_)
					local L_5135_ = L_1_(L_3459_func(41)(L_2_(L_5134_, 1, L_5134_.n)))
					for L_5136_forvar0 = 1, 1 do
						L_3460_func(41 + L_5136_forvar0 - 1, L_5135_[L_5136_forvar0])
					end
				end
				L_3460_func(42, L_10_func(L_3453_arg1, "game"))
				L_3460_func(44, "Players")
				do
					local L_5137_ = L_3459_func(42)
					L_3460_func(43, L_5137_)
					L_3460_func(42, L_5137_["GetService"])
				end
				do
					local L_5138_ = 2
					local L_5139_ = L_3462_func(43, L_5138_)
					local L_5140_ = L_1_(L_3459_func(42)(L_2_(L_5139_, 1, L_5139_.n)))
					for L_5141_forvar0 = 1, 1 do
						L_3460_func(42 + L_5141_forvar0 - 1, L_5140_[L_5141_forvar0])
					end
				end
				L_3460_func(43, L_3459_func(42)["LocalPlayer"])
				L_3460_func(44, L_10_func(L_3453_arg1, "game"))
				L_3460_func(46, "RunService")
				do
					local L_5142_ = L_3459_func(44)
					L_3460_func(45, L_5142_)
					L_3460_func(44, L_5142_["GetService"])
				end
				do
					local L_5143_ = 2
					local L_5144_ = L_3462_func(45, L_5143_)
					local L_5145_ = L_1_(L_3459_func(44)(L_2_(L_5144_, 1, L_5144_.n)))
					for L_5146_forvar0 = 1, 1 do
						L_3460_func(44 + L_5146_forvar0 - 1, L_5145_[L_5146_forvar0])
					end
				end
				L_3460_func(45, L_10_func(L_3453_arg1, "game"))
				L_3460_func(47, "Workspace")
				do
					local L_5147_ = L_3459_func(45)
					L_3460_func(46, L_5147_)
					L_3460_func(45, L_5147_["GetService"])
				end
				do
					local L_5148_ = 2
					local L_5149_ = L_3462_func(46, L_5148_)
					local L_5150_ = L_1_(L_3459_func(45)(L_2_(L_5149_, 1, L_5149_.n)))
					for L_5151_forvar0 = 1, 1 do
						L_3460_func(45 + L_5151_forvar0 - 1, L_5150_[L_5151_forvar0])
					end
				end
				L_3460_func(46, L_10_func(L_3453_arg1, "game"))
				L_3460_func(48, "UserInputService")
				do
					local L_5152_ = L_3459_func(46)
					L_3460_func(47, L_5152_)
					L_3460_func(46, L_5152_["GetService"])
				end
				do
					local L_5153_ = 2
					local L_5154_ = L_3462_func(47, L_5153_)
					local L_5155_ = L_1_(L_3459_func(46)(L_2_(L_5154_, 1, L_5154_.n)))
					for L_5156_forvar0 = 1, 1 do
						L_3460_func(46 + L_5156_forvar0 - 1, L_5155_[L_5156_forvar0])
					end
				end
				L_3460_func(47, L_3459_func(45)["CurrentCamera"])
				L_3460_func(48, {})
				L_3460_func(49, 16)
				L_3459_func(48)["WS"] = L_3459_func(49)
				L_3460_func(49, 50)
				L_3459_func(48)["JP"] = L_3459_func(49)
				L_3460_func(49, false)
				L_3459_func(48)["InfJump"] = L_3459_func(49)
				L_3460_func(49, false)
				L_3459_func(48)["Noclip"] = L_3459_func(49)
				L_3460_func(49, false)
				L_3459_func(48)["CamLock"] = L_3459_func(49)
				L_3460_func(49, false)
				L_3459_func(48)["SilentAim"] = L_3459_func(49)
				L_3460_func(49, 150)
				L_3459_func(48)["SilentAimFOV"] = L_3459_func(49)
				L_3460_func(49, false)
				L_3459_func(48)["AutoArmor"] = L_3459_func(49)
				L_3460_func(49, false)
				L_3459_func(48)["AutoBlock"] = L_3459_func(49)
				L_3460_func(49, false)
				L_3459_func(48)["AutoStomp"] = L_3459_func(49)
				L_3460_func(49, false)
				L_3459_func(48)["Fly"] = L_3459_func(49)
				L_3463_ = 2816
			else
				error("invalid recovered basic block in main: " .. tostring(L_3463_))
			end
		elseif L_3475_ == 11 then
			if L_3463_ == 2816 then

				L_3460_func(49, 50)
				L_3459_func(48)["FlySpeed"] = L_3459_func(49)
				L_3460_func(49, {})
				L_3460_func(50, false)
				L_3459_func(49)["Boxes"] = L_3459_func(50)
				L_3460_func(50, false)
				L_3459_func(49)["Tracers"] = L_3459_func(50)
				L_3460_func(50, false)
				L_3459_func(49)["Names"] = L_3459_func(50)
				L_3460_func(50, L_10_func(L_3453_arg1, "Color3"))
				L_3460_func(50, L_3459_func(50)["fromRGB"])
				L_3460_func(51, 0)
				L_3460_func(52, 162)
				L_3460_func(53, 255)
				do
					local L_5157_ = 3
					local L_5158_ = L_3462_func(51, L_5157_)
					local L_5159_ = L_1_(L_3459_func(50)(L_2_(L_5158_, 1, L_5158_.n)))
					for L_5160_forvar0 = 1, 1 do
						L_3460_func(50 + L_5160_forvar0 - 1, L_5159_[L_5160_forvar0])
					end
				end
				L_3459_func(49)["Color"] = L_3459_func(50)
				L_3460_func(50, nil)
				L_3460_func(51, L_10_func(L_3453_arg1, "pcall"))

				do
					local L_5161_ = {}
					L_5161_[1] = L_3461_func(50)
					local L_5162_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_5163_
					L_5163_ = function(...)
						return L_13_.fn_274_resolveMainEvent(L_5161_, L_5162_, ...)
					end
					L_6_[L_5163_] = L_5162_
					L_3460_func(52, L_5163_)
				end
				do
					local L_5164_ = 1
					local L_5165_ = L_3462_func(52, L_5164_)
					L_3459_func(51)(L_2_(L_5165_, 1, L_5165_.n))
				end
				L_3460_func(51, nil)
				L_3460_func(52, nil)

				do
					local L_5166_ = {}
					L_5166_[1] = L_3461_func(51)
					L_5166_[2] = L_3461_func(52)
					L_5166_[3] = {
						L_3459_func(43)
					}
					local L_5167_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_5168_
					L_5168_ = function(...)
						return L_13_.fn_275_stopFly(L_5166_, L_5167_, ...)
					end
					L_6_[L_5168_] = L_5167_
					L_3460_func(53, L_5168_)
				end

				do
					local L_5169_ = {}
					L_5169_[1] = {
						L_3459_func(53)
					}
					L_5169_[2] = {
						L_3459_func(43)
					}
					L_5169_[3] = L_3461_func(51)
					L_5169_[4] = L_3461_func(52)
					local L_5170_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_5171_
					L_5171_ = function(...)
						return L_13_.fn_276_startFly(L_5169_, L_5170_, ...)
					end
					L_6_[L_5171_] = L_5170_
					L_3460_func(54, L_5171_)
				end
				L_3460_func(55, L_3459_func(44)["RenderStepped"])

				do
					local L_5172_ = {}
					L_5172_[1] = L_3461_func(9)
					L_5172_[2] = {
						L_3459_func(43)
					}
					L_5172_[3] = {
						L_3459_func(48)
					}
					L_5172_[4] = L_3461_func(51)
					L_5172_[5] = {
						L_3459_func(54)
					}
					L_5172_[6] = L_3461_func(52)
					L_5172_[7] = {
						L_3459_func(47)
					}
					L_5172_[8] = {
						L_3459_func(46)
					}
					L_5172_[9] = {
						L_3459_func(53)
					}
					local L_5173_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_5174_
					L_5174_ = function(...)
						return L_13_.fn_277_applyDaHoodMovement(L_5172_, L_5173_, ...)
					end
					L_6_[L_5174_] = L_5173_
					L_3460_func(57, L_5174_)
				end
				do
					local L_5175_ = L_3459_func(55)
					L_3460_func(56, L_5175_)
					L_3460_func(55, L_5175_["Connect"])
				end
				do
					local L_5176_ = 2
					local L_5177_ = L_3462_func(56, L_5176_)
					L_3459_func(55)(L_2_(L_5177_, 1, L_5177_.n))
				end
				L_3460_func(55, L_10_func(L_3453_arg1, "Drawing"))
				L_3460_func(55, L_3459_func(55)["new"])
				L_3460_func(56, "Circle")
				do
					local L_5178_ = 1
					local L_5179_ = L_3462_func(56, L_5178_)
					local L_5180_ = L_1_(L_3459_func(55)(L_2_(L_5179_, 1, L_5179_.n)))
					for L_5181_forvar0 = 1, 1 do
						L_3460_func(55 + L_5181_forvar0 - 1, L_5180_[L_5181_forvar0])
					end
				end
				L_3460_func(56, 1.5)
				L_3459_func(55)["Thickness"] = L_3459_func(56)
				L_3460_func(56, L_10_func(L_3453_arg1, "Color3"))
				L_3460_func(56, L_3459_func(56)["fromRGB"])
				L_3460_func(57, 0)
				L_3460_func(58, 162)
				L_3460_func(59, 255)
				do
					local L_5182_ = 3
					local L_5183_ = L_3462_func(57, L_5182_)
					local L_5184_ = L_1_(L_3459_func(56)(L_2_(L_5183_, 1, L_5183_.n)))
					for L_5185_forvar0 = 1, 1 do
						L_3460_func(56 + L_5185_forvar0 - 1, L_5184_[L_5185_forvar0])
					end
				end
				L_3459_func(55)["Color"] = L_3459_func(56)
				L_3460_func(56, false)
				L_3459_func(55)["Filled"] = L_3459_func(56)
				L_3460_func(56, false)
				L_3459_func(55)["Visible"] = L_3459_func(56)

				do
					local L_5186_ = {}
					L_5186_[1] = {
						L_3459_func(48)
					}
					L_5186_[2] = {
						L_3459_func(46)
					}
					L_5186_[3] = {
						L_3459_func(42)
					}
					L_5186_[4] = {
						L_3459_func(43)
					}
					L_5186_[5] = {
						L_3459_func(47)
					}
					local L_5187_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_5188_
					L_5188_ = function(...)
						return L_13_.fn_278_findSilentAimTarget(L_5186_, L_5187_, ...)
					end
					L_6_[L_5188_] = L_5187_
					L_3460_func(56, L_5188_)
				end
				L_3460_func(57, L_10_func(L_3453_arg1, "getrawmetatable"))
				L_3460_func(58, L_10_func(L_3453_arg1, "game"))
				do
					local L_5189_ = 1
					local L_5190_ = L_3462_func(58, L_5189_)
					local L_5191_ = L_1_(L_3459_func(57)(L_2_(L_5190_, 1, L_5190_.n)))
					for L_5192_forvar0 = 1, 1 do
						L_3460_func(57 + L_5192_forvar0 - 1, L_5191_[L_5192_forvar0])
					end
				end
				L_3460_func(58, L_3459_func(57)["__index"])
				L_3460_func(59, L_10_func(L_3453_arg1, "setreadonly"))
				L_3460_func(60, L_3459_func(57))
				L_3460_func(61, false)
				do
					local L_5193_ = 2
					local L_5194_ = L_3462_func(60, L_5193_)
					L_3459_func(59)(L_2_(L_5194_, 1, L_5194_.n))
				end
				L_3460_func(59, L_10_func(L_3453_arg1, "newcclosure"))

				do
					local L_5195_ = {}
					L_5195_[1] = {
						L_3459_func(48)
					}
					L_5195_[2] = {
						L_3459_func(56)
					}
					L_5195_[3] = {
						L_3459_func(58)
					}
					local L_5196_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_5197_
					L_5197_ = function(...)
						return L_13_.fn_279_installSilentAimHook(L_5195_, L_5196_, ...)
					end
					L_6_[L_5197_] = L_5196_
					L_3460_func(60, L_5197_)
				end
				do
					local L_5198_ = 1
					local L_5199_ = L_3462_func(60, L_5198_)
					local L_5200_ = L_1_(L_3459_func(59)(L_2_(L_5199_, 1, L_5199_.n)))
					for L_5201_forvar0 = 1, 1 do
						L_3460_func(59 + L_5201_forvar0 - 1, L_5200_[L_5201_forvar0])
					end
				end
				L_3459_func(57)["__index"] = L_3459_func(59)
				L_3460_func(59, L_10_func(L_3453_arg1, "setreadonly"))
				L_3460_func(60, L_3459_func(57))
				L_3460_func(61, true)
				do
					local L_5202_ = 2
					local L_5203_ = L_3462_func(60, L_5202_)
					L_3459_func(59)(L_2_(L_5203_, 1, L_5203_.n))
				end
				L_3460_func(59, L_3459_func(44)["RenderStepped"])

				do
					local L_5204_ = {}
					L_5204_[1] = {
						L_3459_func(48)
					}
					L_5204_[2] = {
						L_3459_func(46)
					}
					L_5204_[3] = {
						L_3459_func(56)
					}
					L_5204_[4] = {
						L_3459_func(47)
					}
					L_5204_[5] = {
						L_3459_func(55)
					}
					local L_5205_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_5206_
					L_5206_ = function(...)
						return L_13_.fn_280_updateCamLock(L_5204_, L_5205_, ...)
					end
					L_6_[L_5206_] = L_5205_
					L_3460_func(61, L_5206_)
				end
				do
					local L_5207_ = L_3459_func(59)
					L_3460_func(60, L_5207_)
					L_3460_func(59, L_5207_["Connect"])
				end
				do
					local L_5208_ = 2
					local L_5209_ = L_3462_func(60, L_5208_)
					L_3459_func(59)(L_2_(L_5209_, 1, L_5209_.n))
				end
				L_3460_func(59, {})
				L_3460_func(60, L_10_func(L_3453_arg1, "CFrame"))
				L_3460_func(60, L_3459_func(60)["new"])
				L_3460_func(61, -380)
				L_3460_func(62, 21)
				L_3460_func(63, -336)
				do
					local L_5210_ = 3
					local L_5211_ = L_3462_func(61, L_5210_)
					local L_5212_ = L_1_(L_3459_func(60)(L_2_(L_5211_, 1, L_5211_.n)))
					for L_5213_forvar0 = 1, 1 do
						L_3460_func(60 + L_5213_forvar0 - 1, L_5212_[L_5213_forvar0])
					end
				end
				L_3459_func(59)["Bank"] = L_3459_func(60)
				L_3460_func(60, L_10_func(L_3453_arg1, "CFrame"))
				L_3460_func(60, L_3459_func(60)["new"])
				L_3460_func(61, -582)
				L_3460_func(62, 7)
				L_3460_func(63, -738)
				do
					local L_5214_ = 3
					local L_5215_ = L_3462_func(61, L_5214_)
					local L_5216_ = L_1_(L_3459_func(60)(L_2_(L_5215_, 1, L_5215_.n)))
					for L_5217_forvar0 = 1, 1 do
						L_3460_func(60 + L_5217_forvar0 - 1, L_5216_[L_5217_forvar0])
					end
				end
				L_3459_func(59)["Gun Shop"] = L_3459_func(60)
				L_3460_func(60, L_10_func(L_3453_arg1, "CFrame"))
				L_3460_func(60, L_3459_func(60)["new"])
				L_3460_func(61, -607)
				L_3460_func(62, 7)
				L_3460_func(63, -788)
				do
					local L_5218_ = 3
					local L_5219_ = L_3462_func(61, L_5218_)
					local L_5220_ = L_1_(L_3459_func(60)(L_2_(L_5219_, 1, L_5219_.n)))
					for L_5221_forvar0 = 1, 1 do
						L_3460_func(60 + L_5221_forvar0 - 1, L_5220_[L_5221_forvar0])
					end
				end
				L_3459_func(59)["Armor Shop"] = L_3459_func(60)
				L_3460_func(60, L_10_func(L_3453_arg1, "CFrame"))
				L_3460_func(60, L_3459_func(60)["new"])
				L_3460_func(61, -338)
				L_3460_func(62, 23)
				L_3460_func(63, -298)
				do
					local L_5222_ = 3
					local L_5223_ = L_3462_func(61, L_5222_)
					local L_5224_ = L_1_(L_3459_func(60)(L_2_(L_5223_, 1, L_5223_.n)))
					for L_5225_forvar0 = 1, 1 do
						L_3460_func(60 + L_5225_forvar0 - 1, L_5224_[L_5225_forvar0])
					end
				end
				L_3459_func(59)["Food Shop"] = L_3459_func(60)

				do
					local L_5226_ = {}
					L_5226_[1] = {
						L_3459_func(43)
					}
					local L_5227_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_5228_
					L_5228_ = function(...)
						return L_13_.fn_281_teleportToTarget(L_5226_, L_5227_, ...)
					end
					L_6_[L_5228_] = L_5227_
					L_3460_func(60, L_5228_)
				end
				L_3460_func(63, "Silent Aim (Mouse Hit)")
				L_3460_func(64, "Redirects bullets inside FOV")

				do
					local L_5229_ = {}
					L_5229_[1] = {
						L_3459_func(48)
					}
					local L_5230_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_5231_
					L_5231_ = function(...)
						return L_13_.fn_282_setSilentAim(L_5229_, L_5230_, ...)
					end
					L_6_[L_5231_] = L_5230_
					L_3460_func(65, L_5231_)
				end
				do
					local L_5232_ = L_3459_func(38)
					L_3460_func(62, L_5232_)
					L_3460_func(61, L_5232_["NewPremiumToggle"])
				end
				do
					local L_5233_ = 4
					local L_5234_ = L_3462_func(62, L_5233_)
					L_3459_func(61)(L_2_(L_5234_, 1, L_5234_.n))
				end
				L_3460_func(63, "Silent Aim FOV")
				L_3460_func(64, "Radius of targets zone")
				L_3460_func(65, 500)
				L_3460_func(66, 50)

				do
					local L_5235_ = {}
					L_5235_[1] = {
						L_3459_func(48)
					}
					local L_5236_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_5237_
					L_5237_ = function(...)
						return L_13_.fn_283_setSilentAimFov(L_5235_, L_5236_, ...)
					end
					L_6_[L_5237_] = L_5236_
					L_3460_func(67, L_5237_)
				end
				do
					local L_5238_ = L_3459_func(38)
					L_3460_func(62, L_5238_)
					L_3460_func(61, L_5238_["NewPremiumSlider"])
				end
				do
					local L_5239_ = 6
					local L_5240_ = L_3462_func(62, L_5239_)
					L_3459_func(61)(L_2_(L_5240_, 1, L_5240_.n))
				end
				L_3460_func(63, "Camera Lock (Right Click)")
				L_3460_func(64, "Locks camera onto nearest player")

				do
					local L_5241_ = {}
					L_5241_[1] = {
						L_3459_func(48)
					}
					local L_5242_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_5243_
					L_5243_ = function(...)
						return L_13_.fn_284_setCamLock(L_5241_, L_5242_, ...)
					end
					L_6_[L_5243_] = L_5242_
					L_3460_func(65, L_5243_)
				end
				do
					local L_5244_ = L_3459_func(38)
					L_3460_func(62, L_5244_)
					L_3460_func(61, L_5244_["NewToggle"])
				end
				do
					local L_5245_ = 4
					local L_5246_ = L_3462_func(62, L_5245_)
					L_3459_func(61)(L_2_(L_5246_, 1, L_5246_.n))
				end
				L_3460_func(63, "Walk Speed")
				L_3460_func(64, "Modify Walk Speed value")
				L_3460_func(65, 200)
				L_3460_func(66, 16)

				do
					local L_5247_ = {}
					L_5247_[1] = {
						L_3459_func(48)
					}
					local L_5248_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_5249_
					L_5249_ = function(...)
						return L_13_.fn_285_setDaHoodWalkSpeed(L_5247_, L_5248_, ...)
					end
					L_6_[L_5249_] = L_5248_
					L_3460_func(67, L_5249_)
				end
				do
					local L_5250_ = L_3459_func(39)
					L_3460_func(62, L_5250_)
					L_3460_func(61, L_5250_["NewSlider"])
				end
				do
					local L_5251_ = 6
					local L_5252_ = L_3462_func(62, L_5251_)
					L_3459_func(61)(L_2_(L_5252_, 1, L_5252_.n))
				end
				L_3460_func(63, "Jump Power")
				L_3460_func(64, "Modify Jump Power value")
				L_3460_func(65, 200)
				L_3460_func(66, 50)

				do
					local L_5253_ = {}
					L_5253_[1] = {
						L_3459_func(48)
					}
					local L_5254_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_5255_
					L_5255_ = function(...)
						return L_13_.fn_286_setDaHoodJumpPower(L_5253_, L_5254_, ...)
					end
					L_6_[L_5255_] = L_5254_
					L_3460_func(67, L_5255_)
				end
				do
					local L_5256_ = L_3459_func(39)
					L_3460_func(62, L_5256_)
					L_3460_func(61, L_5256_["NewSlider"])
				end
				do
					local L_5257_ = 6
					local L_5258_ = L_3462_func(62, L_5257_)
					L_3459_func(61)(L_2_(L_5258_, 1, L_5258_.n))
				end
				L_3460_func(63, "Fly Hack")
				L_3460_func(64, "Lets you fly")

				do
					local L_5259_ = {}
					L_5259_[1] = {
						L_3459_func(48)
					}
					local L_5260_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_5261_
					L_5261_ = function(...)
						return L_13_.fn_287_setFly(L_5259_, L_5260_, ...)
					end
					L_6_[L_5261_] = L_5260_
					L_3460_func(65, L_5261_)
				end
				do
					local L_5262_ = L_3459_func(39)
					L_3460_func(62, L_5262_)
					L_3460_func(61, L_5262_["NewPremiumToggle"])
				end
				do
					local L_5263_ = 4
					local L_5264_ = L_3462_func(62, L_5263_)
					L_3459_func(61)(L_2_(L_5264_, 1, L_5264_.n))
				end
				L_3460_func(63, "Fly Speed")
				L_3460_func(64, "Flight velocity speed")
				L_3460_func(65, 150)
				L_3460_func(66, 16)

				do
					local L_5265_ = {}
					L_5265_[1] = {
						L_3459_func(48)
					}
					local L_5266_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_5267_
					L_5267_ = function(...)
						return L_13_.fn_288_setFlySpeed(L_5265_, L_5266_, ...)
					end
					L_6_[L_5267_] = L_5266_
					L_3460_func(67, L_5267_)
				end
				do
					local L_5268_ = L_3459_func(39)
					L_3460_func(62, L_5268_)
					L_3460_func(61, L_5268_["NewPremiumSlider"])
				end
				do
					local L_5269_ = 6
					local L_5270_ = L_3462_func(62, L_5269_)
					L_3459_func(61)(L_2_(L_5270_, 1, L_5270_.n))
				end
				L_3460_func(61, L_10_func(L_3453_arg1, "pairs"))
				L_3460_func(62, L_3459_func(59))
				do
					local L_5271_ = 1
					local L_5272_ = L_3462_func(62, L_5271_)
					local L_5273_ = L_1_(L_3459_func(61)(L_2_(L_5272_, 1, L_5272_.n)))
					for L_5274_forvar0 = 1, 3 do
						L_3460_func(61 + L_5274_forvar0 - 1, L_5273_[L_5274_forvar0])
					end
				end
				L_3463_ = 2988
			elseif L_3463_ == 2980 then

				L_3460_func(69, "Teleport to ")
				L_3460_func(70, L_3459_func(64))
				do
					local L_5275_ = L_3459_func(70)
					for L_5276_forvar0 = 69, 69, -1 do
						L_5275_ = L_3459_func(L_5276_forvar0) .. L_5275_
					end
					L_3460_func(68, L_5275_)
				end
				L_3460_func(69, "Teleports you directly")

				do
					local L_5277_ = {}
					L_5277_[1] = {
						L_3459_func(65)
					}
					L_5277_[2] = {
						L_3459_func(43)
					}
					local L_5278_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_5279_
					L_5279_ = function(...)
						return L_13_.fn_289_teleportDaHood(L_5277_, L_5278_, ...)
					end
					L_6_[L_5279_] = L_5278_
					L_3460_func(70, L_5279_)
				end
				do
					local L_5280_ = L_3459_func(41)
					L_3460_func(67, L_5280_)
					L_3460_func(66, L_5280_["NewButton"])
				end
				do
					local L_5281_ = 4
					local L_5282_ = L_3462_func(67, L_5281_)
					L_3459_func(66)(L_2_(L_5282_, 1, L_5282_.n))
				end
				L_3463_ = 2988
			elseif L_3463_ == 2988 then

				if L_12_func(L_3459_func, L_3460_func, 61, 2) then
					L_3463_ = 2980
				else
					L_3463_ = 2989
				end
			elseif L_3463_ == 2989 then

				L_3460_func(61, L_10_func(L_3453_arg1, "task"))
				L_3460_func(61, L_3459_func(61)["spawn"])

				do
					local L_5283_ = {}
					L_5283_[1] = L_3461_func(9)
					L_5283_[2] = {
						L_3459_func(48)
					}
					L_5283_[3] = {
						L_3459_func(43)
					}
					L_5283_[4] = L_3461_func(50)
					local L_5284_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_5285_
					L_5285_ = function(...)
						return L_13_.fn_291_autoArmorLoop(L_5283_, L_5284_, ...)
					end
					L_6_[L_5285_] = L_5284_
					L_3460_func(62, L_5285_)
				end
				do
					local L_5286_ = 1
					local L_5287_ = L_3462_func(62, L_5286_)
					L_3459_func(61)(L_2_(L_5287_, 1, L_5287_.n))
				end
				L_3460_func(61, L_10_func(L_3453_arg1, "task"))
				L_3460_func(61, L_3459_func(61)["spawn"])

				do
					local L_5288_ = {}
					L_5288_[1] = L_3461_func(9)
					L_5288_[2] = {
						L_3459_func(48)
					}
					L_5288_[3] = L_3461_func(50)
					local L_5289_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_5290_
					L_5290_ = function(...)
						return L_13_.fn_293_autoStompLoop(L_5288_, L_5289_, ...)
					end
					L_6_[L_5290_] = L_5289_
					L_3460_func(62, L_5290_)
				end
				do
					local L_5291_ = 1
					local L_5292_ = L_3462_func(62, L_5291_)
					L_3459_func(61)(L_2_(L_5292_, 1, L_5292_.n))
				end
				L_3460_func(61, L_10_func(L_3453_arg1, "task"))
				L_3460_func(61, L_3459_func(61)["spawn"])

				do
					local L_5293_ = {}
					L_5293_[1] = L_3461_func(9)
					L_5293_[2] = {
						L_3459_func(48)
					}
					L_5293_[3] = L_3461_func(50)
					local L_5294_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_5295_
					L_5295_ = function(...)
						return L_13_.fn_296_autoBlockLoop(L_5293_, L_5294_, ...)
					end
					L_6_[L_5295_] = L_5294_
					L_3460_func(62, L_5295_)
				end
				do
					local L_5296_ = 1
					local L_5297_ = L_3462_func(62, L_5296_)
					L_3459_func(61)(L_2_(L_5297_, 1, L_5297_.n))
				end
				L_3460_func(63, "Auto Armor")
				L_3460_func(64, "Automatically purchases armor when empty")

				do
					local L_5298_ = {}
					L_5298_[1] = {
						L_3459_func(48)
					}
					local L_5299_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_5300_
					L_5300_ = function(...)
						return L_13_.fn_297_setAutoArmor(L_5298_, L_5299_, ...)
					end
					L_6_[L_5300_] = L_5299_
					L_3460_func(65, L_5300_)
				end
				do
					local L_5301_ = L_3459_func(41)
					L_3460_func(62, L_5301_)
					L_3460_func(61, L_5301_["NewPremiumToggle"])
				end
				do
					local L_5302_ = 4
					local L_5303_ = L_3462_func(62, L_5302_)
					L_3459_func(61)(L_2_(L_5303_, 1, L_5303_.n))
				end
				L_3460_func(63, "Auto Stomp")
				L_3460_func(64, "Automatically stomps downed players")

				do
					local L_5304_ = {}
					L_5304_[1] = {
						L_3459_func(48)
					}
					local L_5305_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_5306_
					L_5306_ = function(...)
						return L_13_.fn_298_setAutoStomp(L_5304_, L_5305_, ...)
					end
					L_6_[L_5306_] = L_5305_
					L_3460_func(65, L_5306_)
				end
				do
					local L_5307_ = L_3459_func(41)
					L_3460_func(62, L_5307_)
					L_3460_func(61, L_5307_["NewPremiumToggle"])
				end
				do
					local L_5308_ = 4
					local L_5309_ = L_3462_func(62, L_5308_)
					L_3459_func(61)(L_2_(L_5309_, 1, L_5309_.n))
				end
				L_3460_func(63, "Auto Block")
				L_3460_func(64, "Automatically blocks attacks")

				do
					local L_5310_ = {}
					L_5310_[1] = {
						L_3459_func(48)
					}
					local L_5311_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_5312_
					L_5312_ = function(...)
						return L_13_.fn_299_setAutoBlock(L_5310_, L_5311_, ...)
					end
					L_6_[L_5312_] = L_5311_
					L_3460_func(65, L_5312_)
				end
				do
					local L_5313_ = L_3459_func(41)
					L_3460_func(62, L_5313_)
					L_3460_func(61, L_5313_["NewPremiumToggle"])
				end
				do
					local L_5314_ = 4
					local L_5315_ = L_3462_func(62, L_5314_)
					L_3459_func(61)(L_2_(L_5315_, 1, L_5315_.n))
				end
				L_3460_func(61, {})

				do
					local L_5316_ = {}
					L_5316_[1] = L_3461_func(61)
					local L_5317_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_5318_
					L_5318_ = function(...)
						return L_13_.fn_303_cleanupEspObjects(L_5316_, L_5317_, ...)
					end
					L_6_[L_5318_] = L_5317_
					L_3460_func(62, L_5318_)
				end
				L_3460_func(63, nil)
				L_3460_func(64, L_3459_func(44)["RenderStepped"])

				do
					local L_5319_ = {}
					L_5319_[1] = L_3461_func(9)
					L_5319_[2] = L_3461_func(63)
					L_5319_[3] = {
						L_3459_func(62)
					}
					L_5319_[4] = {
						L_3459_func(55)
					}
					L_5319_[5] = {
						L_3459_func(42)
					}
					L_5319_[6] = {
						L_3459_func(43)
					}
					L_5319_[7] = {
						L_3459_func(47)
					}
					L_5319_[8] = L_3461_func(61)
					L_5319_[9] = {
						L_3459_func(49)
					}
					local L_5320_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_5321_
					L_5321_ = function(...)
						return L_13_.fn_305_startPlayerEsp(L_5319_, L_5320_, ...)
					end
					L_6_[L_5321_] = L_5320_
					L_3460_func(66, L_5321_)
				end
				do
					local L_5322_ = L_3459_func(64)
					L_3460_func(65, L_5322_)
					L_3460_func(64, L_5322_["Connect"])
				end
				do
					local L_5323_ = 2
					local L_5324_ = L_3462_func(65, L_5323_)
					local L_5325_ = L_1_(L_3459_func(64)(L_2_(L_5324_, 1, L_5324_.n)))
					for L_5326_forvar0 = 1, 1 do
						L_3460_func(64 + L_5326_forvar0 - 1, L_5325_[L_5326_forvar0])
					end
				end
				L_3460_func(63, L_3459_func(64))
				L_3460_func(66, "ESP Boxes")
				L_3460_func(67, "Draw box around players")

				do
					local L_5327_ = {}
					L_5327_[1] = {
						L_3459_func(49)
					}
					local L_5328_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_5329_
					L_5329_ = function(...)
						return L_13_.fn_306_setEspBoxes(L_5327_, L_5328_, ...)
					end
					L_6_[L_5329_] = L_5328_
					L_3460_func(68, L_5329_)
				end
				do
					local L_5330_ = L_3459_func(40)
					L_3460_func(65, L_5330_)
					L_3460_func(64, L_5330_["NewToggle"])
				end
				do
					local L_5331_ = 4
					local L_5332_ = L_3462_func(65, L_5331_)
					L_3459_func(64)(L_2_(L_5332_, 1, L_5332_.n))
				end
				L_3460_func(66, "ESP Names")
				L_3460_func(67, "Show player names")

				do
					local L_5333_ = {}
					L_5333_[1] = {
						L_3459_func(49)
					}
					local L_5334_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_5335_
					L_5335_ = function(...)
						return L_13_.fn_307_setEspNames(L_5333_, L_5334_, ...)
					end
					L_6_[L_5335_] = L_5334_
					L_3460_func(68, L_5335_)
				end
				do
					local L_5336_ = L_3459_func(40)
					L_3460_func(65, L_5336_)
					L_3460_func(64, L_5336_["NewToggle"])
				end
				do
					local L_5337_ = 4
					local L_5338_ = L_3462_func(65, L_5337_)
					L_3459_func(64)(L_2_(L_5338_, 1, L_5338_.n))
				end
				L_3460_func(66, "ESP Tracers")
				L_3460_func(67, "Draw lines to players")

				do
					local L_5339_ = {}
					L_5339_[1] = {
						L_3459_func(49)
					}
					local L_5340_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_5341_
					L_5341_ = function(...)
						return L_13_.fn_308_setEspTracers(L_5339_, L_5340_, ...)
					end
					L_6_[L_5341_] = L_5340_
					L_3460_func(68, L_5341_)
				end
				do
					local L_5342_ = L_3459_func(40)
					L_3460_func(65, L_5342_)
					L_3460_func(64, L_5342_["NewToggle"])
				end
				do
					local L_5343_ = 4
					local L_5344_ = L_3462_func(65, L_5343_)
					L_3459_func(64)(L_2_(L_5344_, 1, L_5344_.n))
				end
				L_3460_func(64, {})
				L_3460_func(65, "Cyan")
				L_3460_func(66, "Red")
				L_3460_func(67, "Green")
				L_3460_func(68, "Blue")
				L_3460_func(69, "Yellow")
				L_3460_func(70, "White")
				L_3460_func(71, "Magenta")
				do
					local L_5345_ = 7
					local L_5346_ = L_3459_func(64)
					for L_5347_forvar0 = 0, L_5345_ - 1 do
						L_5346_[1 + L_5347_forvar0] = L_3459_func(65 + L_5347_forvar0)
					end
				end
				L_3460_func(65, {})
				L_3460_func(66, L_10_func(L_3453_arg1, "Color3"))
				L_3460_func(66, L_3459_func(66)["fromRGB"])
				L_3460_func(67, 0)
				L_3460_func(68, 162)
				L_3460_func(69, 255)
				do
					local L_5348_ = 3
					local L_5349_ = L_3462_func(67, L_5348_)
					local L_5350_ = L_1_(L_3459_func(66)(L_2_(L_5349_, 1, L_5349_.n)))
					for L_5351_forvar0 = 1, 1 do
						L_3460_func(66 + L_5351_forvar0 - 1, L_5350_[L_5351_forvar0])
					end
				end
				L_3459_func(65)["Cyan"] = L_3459_func(66)
				L_3460_func(66, L_10_func(L_3453_arg1, "Color3"))
				L_3460_func(66, L_3459_func(66)["fromRGB"])
				L_3460_func(67, 255)
				L_3460_func(68, 0)
				L_3460_func(69, 0)
				do
					local L_5352_ = 3
					local L_5353_ = L_3462_func(67, L_5352_)
					local L_5354_ = L_1_(L_3459_func(66)(L_2_(L_5353_, 1, L_5353_.n)))
					for L_5355_forvar0 = 1, 1 do
						L_3460_func(66 + L_5355_forvar0 - 1, L_5354_[L_5355_forvar0])
					end
				end
				L_3459_func(65)["Red"] = L_3459_func(66)
				L_3460_func(66, L_10_func(L_3453_arg1, "Color3"))
				L_3463_ = 3072
			else
				error("invalid recovered basic block in main: " .. tostring(L_3463_))
			end
		elseif L_3475_ == 12 then
			if L_3463_ == 3072 then

				L_3460_func(66, L_3459_func(66)["fromRGB"])
				L_3460_func(67, 0)
				L_3460_func(68, 255)
				L_3460_func(69, 0)
				do
					local L_5356_ = 3
					local L_5357_ = L_3462_func(67, L_5356_)
					local L_5358_ = L_1_(L_3459_func(66)(L_2_(L_5357_, 1, L_5357_.n)))
					for L_5359_forvar0 = 1, 1 do
						L_3460_func(66 + L_5359_forvar0 - 1, L_5358_[L_5359_forvar0])
					end
				end
				L_3459_func(65)["Green"] = L_3459_func(66)
				L_3460_func(66, L_10_func(L_3453_arg1, "Color3"))
				L_3460_func(66, L_3459_func(66)["fromRGB"])
				L_3460_func(67, 0)
				L_3460_func(68, 0)
				L_3460_func(69, 255)
				do
					local L_5360_ = 3
					local L_5361_ = L_3462_func(67, L_5360_)
					local L_5362_ = L_1_(L_3459_func(66)(L_2_(L_5361_, 1, L_5361_.n)))
					for L_5363_forvar0 = 1, 1 do
						L_3460_func(66 + L_5363_forvar0 - 1, L_5362_[L_5363_forvar0])
					end
				end
				L_3459_func(65)["Blue"] = L_3459_func(66)
				L_3460_func(66, L_10_func(L_3453_arg1, "Color3"))
				L_3460_func(66, L_3459_func(66)["fromRGB"])
				L_3460_func(67, 255)
				L_3460_func(68, 255)
				L_3460_func(69, 0)
				do
					local L_5364_ = 3
					local L_5365_ = L_3462_func(67, L_5364_)
					local L_5366_ = L_1_(L_3459_func(66)(L_2_(L_5365_, 1, L_5365_.n)))
					for L_5367_forvar0 = 1, 1 do
						L_3460_func(66 + L_5367_forvar0 - 1, L_5366_[L_5367_forvar0])
					end
				end
				L_3459_func(65)["Yellow"] = L_3459_func(66)
				L_3460_func(66, L_10_func(L_3453_arg1, "Color3"))
				L_3460_func(66, L_3459_func(66)["fromRGB"])
				L_3460_func(67, 255)
				L_3460_func(68, 255)
				L_3460_func(69, 255)
				do
					local L_5368_ = 3
					local L_5369_ = L_3462_func(67, L_5368_)
					local L_5370_ = L_1_(L_3459_func(66)(L_2_(L_5369_, 1, L_5369_.n)))
					for L_5371_forvar0 = 1, 1 do
						L_3460_func(66 + L_5371_forvar0 - 1, L_5370_[L_5371_forvar0])
					end
				end
				L_3459_func(65)["White"] = L_3459_func(66)
				L_3460_func(66, L_10_func(L_3453_arg1, "Color3"))
				L_3460_func(66, L_3459_func(66)["fromRGB"])
				L_3460_func(67, 255)
				L_3460_func(68, 0)
				L_3460_func(69, 255)
				do
					local L_5372_ = 3
					local L_5373_ = L_3462_func(67, L_5372_)
					local L_5374_ = L_1_(L_3459_func(66)(L_2_(L_5373_, 1, L_5373_.n)))
					for L_5375_forvar0 = 1, 1 do
						L_3460_func(66 + L_5375_forvar0 - 1, L_5374_[L_5375_forvar0])
					end
				end
				L_3459_func(65)["Magenta"] = L_3459_func(66)
				L_3460_func(68, "ESP Color")
				L_3460_func(69, "Select ESP color")
				L_3460_func(70, L_3459_func(64))

				do
					local L_5376_ = {}
					L_5376_[1] = {
						L_3459_func(49)
					}
					L_5376_[2] = {
						L_3459_func(65)
					}
					local L_5377_ = {
						L_3453_arg1 and L_3453_arg1[1] or nil
					}
					local L_5378_
					L_5378_ = function(...)
						return L_13_.fn_309_setEspColor(L_5376_, L_5377_, ...)
					end
					L_6_[L_5378_] = L_5377_
					L_3460_func(71, L_5378_)
				end
				do
					local L_5379_ = L_3459_func(40)
					L_3460_func(67, L_5379_)
					L_3460_func(66, L_5379_["NewDropdown"])
				end
				do
					local L_5380_ = 5
					local L_5381_ = L_3462_func(67, L_5380_)
					L_3459_func(66)(L_2_(L_5381_, 1, L_5381_.n))
				end

				for L_5382_forvar0 = 50, L_3456_ do
					local L_5383_ = L_3455_[L_5382_forvar0]
					if L_5383_ ~= nil then
						L_3454_[L_5382_forvar0] = L_5383_[1]
						L_3455_[L_5382_forvar0] = nil
					end
				end
				L_3463_ = 3118
			elseif L_3463_ == 3118 then

				for L_5384_forvar0 = 9, L_3456_ do
					local L_5385_ = L_3455_[L_5384_forvar0]
					if L_5385_ ~= nil then
						L_3454_[L_5384_forvar0] = L_5385_[1]
						L_3455_[L_5384_forvar0] = nil
					end
				end
				return
			else
				error("invalid recovered basic block in main: " .. tostring(L_3463_))
			end
		else
			error("invalid recovered block group in main: " .. tostring(L_3463_))
		end
	end
end

local L_15_ = {
	nil
}
return L_13_.main({}, L_15_)
