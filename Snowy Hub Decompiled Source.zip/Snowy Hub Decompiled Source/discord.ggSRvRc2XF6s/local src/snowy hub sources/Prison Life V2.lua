local L_1_ = game:GetService("Players")
local L_2_ = game:GetService("RunService")
local L_3_ = game:GetService("ReplicatedStorage")
local L_4_ = game:GetService("Workspace")
local L_5_ = game:GetService("Teams")

local L_6_ = L_1_.LocalPlayer

local L_7_ = {
	ArrestAura = false,
}

local L_8_ = nil

local function L_9_func(L_26_arg0, L_27_arg1, L_28_arg2)
	pcall(function()
		L_26_arg0:Notify(L_27_arg1, L_28_arg2, 3)
	end)
end

local function L_10_func(L_29_arg0)
	local L_30_ = L_29_arg0 and L_29_arg0:FindFirstChild("AntiJump")
	if L_30_ then
		L_30_:Destroy()
		print("Antijump Destroyed")
	end
	local L_31_ = L_4_:FindFirstChild("BOUNDARY")
	if L_31_ then
		L_31_:Destroy()
		print("Boundaries destroyed.")
	end
end

local function L_11_func()
	pcall(function()
		local L_32_ =
            L_6_.Character
            or L_6_.CharacterAdded:Wait()
		L_10_func(L_32_)
	end)
	L_6_.CharacterAdded:Connect(function(L_33_arg0)
		task.wait(0.5)
		pcall(function()
			local L_34_ = L_33_arg0:FindFirstChild("AntiJump")
			if L_34_ then
				L_34_:Destroy()
				print("Antijump Destroyed")
			end
		end)
	end)
end

local function L_12_func(L_35_arg0, L_36_arg1, L_37_arg2)
	local L_38_ = L_6_.Character
	local L_39_ =
        L_38_
        and L_38_:FindFirstChild("HumanoidRootPart")
	if not L_39_ then
		return
	end
	local L_40_ = L_4_:FindFirstChild("Prison_ITEMS")
	local L_41_ =
        L_40_
        and L_40_:FindFirstChild("giver")
	if not L_41_ then
		return
	end
	local L_42_ = L_41_:FindFirstChild(L_36_arg1)
	if not L_42_ then
		for L_47_forvar0, L_48_forvar1 in ipairs(L_41_:GetChildren()) do
			local L_49_ =
                L_48_forvar1.Name:lower():find(
                    L_36_arg1:lower(),
                    1,
                    true
                ) ~= nil
			if L_49_ or L_48_forvar1:FindFirstChild(L_37_arg2) then
				L_42_ = L_48_forvar1
				break
			end
		end
	end
	local L_43_ =
        L_42_
        and L_42_:FindFirstChild(L_37_arg2)
	if not L_43_ then
		return
	end
	local L_44_ = L_39_.CFrame
	L_39_.CFrame = L_43_.CFrame
	task.wait(0.2)
	local L_45_ = L_3_:FindFirstChild("Remotes")
	local L_46_ =
        L_45_
        and L_45_:FindFirstChild("InteractWithItem")
	if L_46_ then
		L_46_:InvokeServer(L_43_)
	end
	task.wait(0.2)
	L_39_.CFrame = L_44_
	L_9_func(
        L_35_arg0,
        "Weapon Giver",
        "Successfully obtained " .. L_36_arg1 .. "!"
    )
end

local function L_13_func(L_50_arg0)
	pcall(function()
		L_12_func(L_50_arg0, "MP5", "Meshes/MP5 (2)")
	end)
end

local function L_14_func(L_51_arg0)
	pcall(function()
		L_12_func(L_51_arg0, "AK-47", "Meshes/AK47_7")
	end)
end

local function L_15_func(L_52_arg0)
	pcall(function()
		L_12_func(L_52_arg0, "Remington 870", "Meshes/r870_2")
	end)
end

local function L_16_func(L_53_arg0)
	pcall(function()
		local L_54_ = L_6_.Character
		local L_55_ =
            L_54_
            and L_54_:FindFirstChild("HumanoidRootPart")
		local L_56_ = L_4_:FindFirstChild("Criminals Spawn")
		local L_57_ =
            L_56_
            and L_56_:FindFirstChild("SpawnLocation")
		if not L_55_ or not L_57_ then
			return
		end
		local L_58_ = L_55_.CFrame
		L_55_.CFrame = L_57_.CFrame
		task.wait(2)
		L_55_.CFrame = L_58_
		L_9_func(
            L_53_arg0,
            "Teams",
            "Successfully changed team to Criminal!"
        )
	end)
end

local function L_17_func(L_59_arg0)
	local L_60_ = L_3_:FindFirstChild("Remotes")
	local L_61_ =
        L_60_
        and L_60_:FindFirstChild("ArrestPlayer")
	if L_61_ then
		return L_61_:InvokeServer(L_59_arg0, 1)
	end
end

local function L_18_func()
	local L_62_ = L_6_.Character
	local L_63_ =
        L_62_
        and L_62_:FindFirstChild("HumanoidRootPart")
	if not L_63_ then
		return
	end
	for L_64_forvar0, L_65_forvar1 in pairs(L_1_:GetPlayers()) do
		if L_65_forvar1 == L_6_ then
			continue
		end
		local L_66_ = L_65_forvar1.Character
		local L_67_ =
            L_66_
            and L_66_:FindFirstChild("HumanoidRootPart")
		if L_67_
            and (L_63_.Position - L_67_.Position).Magnitude <= 30
        then
			pcall(function()
				L_17_func(L_65_forvar1)
			end)
		end
	end
end

local function L_19_func(L_68_arg0)
	L_7_.ArrestAura = L_68_arg0
	if not L_68_arg0 then
		if L_8_ then
			L_8_:Disconnect()
			L_8_ = nil
		end
		return
	end
	L_8_ =
        L_2_.Heartbeat:Connect(L_18_func)
end

local function L_20_func()
	local L_69_ = L_6_.Character
	local L_70_ =
        L_69_
        and L_69_:FindFirstChildOfClass("Humanoid")
	if not L_70_ then
		return true
	end
	return L_70_.Health <= 0
end

local function L_21_func(L_71_arg0)
	local L_72_ = L_6_.Character
	local L_73_ =
        L_72_
        and L_72_:FindFirstChild("HumanoidRootPart")
	if not L_73_ then
		return
	end
	local L_74_ = {}
	for L_75_forvar0, L_76_forvar1 in pairs(L_1_:GetPlayers()) do
		if L_76_forvar1 ~= L_6_
            and L_76_forvar1.Team == L_5_.Criminals
        then
			table.insert(L_74_, L_76_forvar1)
		end
	end
	if #L_74_ == 0 then
		L_9_func(
            L_71_arg0,
            "Auto Arrest",
            "No criminals found online."
        )
		return
	end
	L_9_func(
        L_71_arg0,
        "Auto Arrest",
        "Arresting "
            .. tostring(#L_74_)
            .. " criminals..."
    )
	for L_77_forvar0, L_78_forvar1 in pairs(L_74_) do
		if L_20_func() then
			break
		end
		local L_79_ = L_78_forvar1.Character
		local L_80_ =
            L_79_
            and L_79_:FindFirstChild("HumanoidRootPart")
		if not L_80_ then
			continue
		end
		local L_81_ = tick()
		local L_82_ = false
		while tick() - L_81_ < 3 and not L_82_ do
			if L_20_func() then
				return
			end
			L_73_.CFrame =
                CFrame.new(
                    L_80_.Position
                        - L_80_.CFrame.LookVector * 3,
                    L_80_.Position
                )
			pcall(function()
				local L_83_ = L_17_func(L_78_forvar1)
				if L_83_ ~= nil then
					L_82_ = true
				end
			end)
			if L_78_forvar1.Team ~= L_5_.Criminals then
				L_82_ = true
			end
			task.wait(0.05)
		end
		if L_20_func() then
			return
		end
		L_73_.CFrame = CFrame.new(872, 40, 2344)
		task.wait(20)
	end
	L_9_func(
        L_71_arg0,
        "Auto Arrest",
        "Finished auto arrest cycle!"
    )
end

local function L_22_func()
	pcall(function()
		loadstring(
            game:HttpGet(
                "https://raw.githubusercontent.com/Exunys/AirHub/main/AirHub.lua"
            )
        )()
	end)
end

local function L_23_func()
	pcall(function()
		loadstring(
            game:HttpGet(
                "https://raw.githubusercontent.com/edgeiy/infiniteyield/master/source"
            )
        )()
	end)
end

local function L_24_func(L_84_arg0, L_85_arg1)
	local L_86_ = L_84_arg0("Prison Life", "Prison Life")
	L_86_:NewSection("Weapons")
	L_86_:NewButton("Get MP5", "Get MP5", function()
		L_13_func(L_85_arg1)
	end)
	L_86_:NewPremiumButton("Get AK-47", "Get AK-47", function()
		L_14_func(L_85_arg1)
	end)
	L_86_:NewButton(
        "Get Remington 870",
        "Get Remington 870",
        function()
		L_15_func(L_85_arg1)
	end
    )
	L_86_:NewSection("Teams")
	L_86_:NewButton(
        "Become Criminal",
        "Become Criminal",
        function()
		L_16_func(L_85_arg1)
	end
    )
	L_86_:NewSection("Arrest")
	L_86_:NewPremiumToggle(
        "Arrest Aura",
        "Arrest nearby players",
        false,
        L_19_func
    )

	L_86_:NewLabel("Auto arrest may be detected by Prison Life anti-cheat.")
	L_86_:NewLabel("Equip handcuffs before using arrest features.")
	L_86_:NewPremiumButton(
        "Arrest All Criminals",
        "Arrest All Criminals",
        function()
		task.spawn(function()
			L_21_func(L_85_arg1)
		end)
	end
    )
	L_86_:NewSection("Scripts")
	L_86_:NewPremiumButton(
        "AirHub",
        "Load AirHub",
        L_22_func
    )
	L_86_:NewButton(
        "Infinite Yield",
        "Load Infinite Yield",
        L_23_func
    )
end

local function L_25_func(L_87_arg0, L_88_arg1)

	local L_89_ = {
		name = "Prison Life",
		features = 0,
	}
	task.spawn(L_11_func)

	if L_89_.name == "Prison Life" then
		L_24_func(L_87_arg0, L_88_arg1)
	end
	return L_89_
end

return {
	Main = L_25_func,
	SetArrestAura = L_19_func,
	ArrestAllCriminals = L_21_func,
	GetMP5 = L_13_func,
	GetAK47 = L_14_func,
	GetRemington870 = L_15_func,
	BecomeCriminal = L_16_func,
}
