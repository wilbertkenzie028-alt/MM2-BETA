local L_1_ = game:GetService("Players")
local L_2_ = game:GetService("RunService")
local L_3_ = game:GetService("UserInputService")
local L_4_ = game:GetService("TeleportService")
local L_5_ = game:GetService("HttpService")
local L_6_ = game:GetService("Lighting")
local L_7_ = game:GetService("Workspace")
local L_8_ = game:GetService("VirtualUser")

local L_9_ = L_1_.LocalPlayer
local L_10_ = L_7_.CurrentCamera

local L_11_ = getgenv and getgenv() or _G

local L_12_ = " SNOWY HUB v6.0"
local L_13_ = "SNOWY HUB v6.0 | Built by Snowy Studios"
local L_14_ = "https://discord.gg/getsnowy"

local L_15_ = {
	AutoDelivery = false,
	AutoJanitor = false,
	AutoMood = false,
	WalkSpeed = 16,
	JumpPower = 50,
	WSLock = false,
	JPLock = false,
	Disable3D = false,
	FPSBoost = false,
}

local L_16_ = {
	Enabled = false,
	ShowFOV = false,
	FOVRadius = 100,
	Smoothness = 0.10,
	TeamCheck = false,
	TargetPart = "Head",
}

local L_17_ = {
	noclip = nil,
	antiIdle = nil,
	aimbot = nil,
	modifier = nil,
}

local L_18_ = {
	HubName = L_12_,
	Credit = L_13_,
	State = L_15_,
	Aimbot = L_16_,
}

local function L_19_func(L_47_arg0, L_48_arg1, L_49_arg2, L_50_arg3)
	L_49_arg2 = L_49_arg2 or 3
	local L_51_ = L_11_.Window
	if L_51_ and type(L_51_.Notify) == "function" then
		pcall(function()
			L_51_:Notify(L_47_arg0, L_48_arg1, L_49_arg2, L_50_arg3 == true)
		end)
		return
	end
	warn(("[SnowyHub] %s: %s"):format(tostring(L_47_arg0), tostring(L_48_arg1)))
end

local function L_20_func()
	return L_9_.Character
end

local function L_21_func()
	local L_52_ = L_20_func()
	return L_52_ and L_52_:FindFirstChild("HumanoidRootPart")
end

local function L_22_func()
	local L_53_ = L_20_func()
	return L_53_ and L_53_:FindFirstChildOfClass("Humanoid")
end

function L_18_.SetWalkSpeed(L_54_arg0)
	L_11_.WalkSpeedValue = L_54_arg0
	local L_55_ = L_22_func()
	if L_55_ then
		L_55_.WalkSpeed = L_54_arg0
	end
end

function L_18_.SetJumpPower(L_56_arg0)
	L_11_.JumpPowerValue = L_56_arg0
	local L_57_ = L_22_func()
	if L_57_ then
		L_57_.JumpPower = L_56_arg0
	end
end

function L_18_.SetGravity(L_58_arg0)
	L_7_.Gravity = L_58_arg0
end

local function L_23_func()
	local L_59_ = L_22_func()
	if not L_59_ then
		return
	end
	L_59_.MaxHealth = 100
	L_59_.Health = 100
	L_59_:SetStateEnabled(Enum.HumanoidStateType.Dead, true)
end

local function L_24_func()
	local L_60_ = L_20_func()
	if not L_60_ then
		return
	end
	local L_61_ = L_60_:FindFirstChild("Humanoid")
	local L_62_ = L_60_:FindFirstChild("HumanoidRootPart")
	if not L_61_ or not L_62_ or not L_11_.GodModeEnabled then
		return
	end
	if L_61_.MaxHealth ~= math.huge then
		L_61_.MaxHealth = math.huge
	end
	if L_61_.Health ~= math.huge then
		L_61_.Health = math.huge
	end
	pcall(function()
		L_61_:SetStateEnabled(Enum.HumanoidStateType.Dead, false)
	end)
end

function L_18_.SetGodMode(L_63_arg0)
	L_11_.GodModeEnabled = L_63_arg0
	if L_63_arg0 then
		pcall(L_24_func)
	else
		pcall(L_23_func)
	end
end

local function L_25_func()
	local L_64_ = L_20_func()
	if not L_64_ then
		return
	end
	for L_65_forvar0, L_66_forvar1 in pairs(L_64_:GetDescendants()) do
		if L_66_forvar1:IsA("BasePart")
            and L_66_forvar1.CanCollide
            and L_66_forvar1.Name ~= L_11_.floatName
        then
			L_66_forvar1.CanCollide = false
		end
	end

	task.wait(0.21)
end

function L_18_.SetNoclip(L_67_arg0)
	if L_67_arg0 then
		if not L_17_.noclip then
			L_17_.noclip = L_2_.Stepped:Connect(function()
				pcall(L_25_func)
			end)
		end
	elseif L_17_.noclip then
		L_17_.noclip:Disconnect()
		L_17_.noclip = nil
	end
end

local L_26_ = false

L_3_.JumpRequest:Connect(function()
	if not L_26_ then
		return
	end
	local L_68_ = L_22_func()
	if L_68_ then
		L_68_:ChangeState("Jumping")
	end
end)

function L_18_.SetInfiniteJump(L_69_arg0)
	L_26_ = L_69_arg0
end

function L_18_.SetCameraFOV(L_70_arg0)
	L_7_.CurrentCamera.FieldOfView = L_70_arg0
end

function L_18_.SetFullbright(L_71_arg0)
	if L_71_arg0 then
		L_6_.Ambient = Color3.new(1, 1, 1)
		L_6_.ColorShift_Bottom = Color3.new(1, 1, 1)
		L_6_.ColorShift_Top = Color3.new(1, 1, 1)
		L_6_.GlobalShadows = false
	else
		L_6_.Ambient = Color3.fromRGB(128, 128, 128)
		L_6_.GlobalShadows = true
	end
end

local L_27_ = {}

function L_18_.SetPlayerESP(L_72_arg0)
	if not L_72_arg0 then
		for L_73_forvar0, L_74_forvar1 in ipairs(L_27_) do
			pcall(function()
				L_74_forvar1:Destroy()
			end)
		end
		table.clear(L_27_)
		return
	end
	for L_75_forvar0, L_76_forvar1 in pairs(L_1_:GetPlayers()) do
		if L_76_forvar1 ~= L_9_ and L_76_forvar1.Character then
			local L_77_ = Instance.new("Highlight")
			L_77_.Parent = L_76_forvar1.Character

			L_77_.FillTransparency = 0.5
			L_77_.OutlineTransparency = 0
			table.insert(L_27_, L_77_)
		end
	end
end

local function L_28_func(L_78_arg0)
	local L_79_ = L_78_arg0.Character
	local L_80_ = L_79_ and L_79_:FindFirstChild("HumanoidRootPart")
	if not L_80_ then
		return
	end
	local L_81_ = _G.HeadSize
	L_80_.Size = Vector3.new(L_81_, L_81_, L_81_)
	L_80_.Transparency = 0.7
	L_80_.BrickColor = BrickColor.new("Really red")
	L_80_.Material = Enum.Material.Neon
	L_80_.CanCollide = false
end

function L_18_.SetHitboxSize(L_82_arg0)
	_G.HeadSize = L_82_arg0
	_G.Disabled = true

	L_2_.RenderStepped:Connect(function()
		if not _G.Disabled then
			return
		end
		for L_83_forvar0, L_84_forvar1 in next, L_1_:GetPlayers() do
			if L_84_forvar1.Name ~= L_9_.Name then
				pcall(L_28_func, L_84_forvar1)
			end
		end
	end)
end

local L_29_ = nil

if Drawing and Drawing.new then
	L_29_ = Drawing.new("Circle")
	L_29_.Visible = false
	L_29_.Filled = false
	L_29_.Thickness = 1
end

local function L_30_func()
	local L_85_ = L_16_.FOVRadius
	local L_86_ = nil
	local L_87_ = L_3_:GetMouseLocation()
	for L_88_forvar0, L_89_forvar1 in pairs(L_1_:GetPlayers()) do
		if L_89_forvar1 ~= L_9_ and L_89_forvar1.Character then
			local L_90_ = L_89_forvar1.Character:FindFirstChild(L_16_.TargetPart)
			local L_91_ = L_89_forvar1.Character:FindFirstChild("Humanoid")
			if L_90_ and L_91_ and L_91_.Health > 0 then
				local L_92_ = L_89_forvar1.Team == L_9_.Team

				if not L_16_.TeamCheck or not L_92_ then
					local L_93_, L_94_ =
                        L_7_.CurrentCamera:WorldToViewportPoint(L_90_.Position)
					if L_94_ then
						local L_95_ =
                            (Vector2.new(L_93_.X, L_93_.Y) - L_87_).Magnitude
						if L_95_ < L_85_ then
							L_85_ = L_95_
							L_86_ = L_89_forvar1
						end
					end
				end
			end
		end
	end
	return L_86_
end

local function L_31_func()
	if L_29_ then
		if L_16_.ShowFOV then
			L_29_.Position = L_3_:GetMouseLocation()
			L_29_.Radius = L_16_.FOVRadius
			L_29_.Visible = true
		else
			L_29_.Visible = false
		end
	end
	if not L_16_.Enabled then
		return
	end
	if not L_3_:IsMouseButtonPressed(Enum.UserInputType.MouseButton2) then
		return
	end
	local L_96_ = L_30_func()
	if not L_96_ or not L_96_.Character then
		return
	end
	local L_97_ = L_96_.Character:FindFirstChild(L_16_.TargetPart)
	if not L_97_ then
		return
	end
	L_10_ = L_7_.CurrentCamera
	local L_98_ =
        CFrame.new(L_10_.CFrame.Position, L_97_.Position)
	L_10_.CFrame =
        L_10_.CFrame:Lerp(L_98_, L_16_.Smoothness)
end

L_17_.aimbot = L_2_.RenderStepped:Connect(L_31_func)

function L_18_.SetAimbotEnabled(L_99_arg0)
	L_16_.Enabled = L_99_arg0
end

function L_18_.SetShowFOV(L_100_arg0)
	L_16_.ShowFOV = L_100_arg0
end

function L_18_.SetFOVRadius(L_101_arg0)
	L_16_.FOVRadius = L_101_arg0
end

function L_18_.SetAimbotSmoothness(L_102_arg0)
	L_16_.Smoothness = L_102_arg0 / 100
end

function L_18_.SetTeamCheck(L_103_arg0)
	L_16_.TeamCheck = L_103_arg0
end

function L_18_.GiveBtools()
	local L_104_ = L_9_:FindFirstChildOfClass("Backpack") or L_9_.Backpack
	local L_105_ = Instance.new("HopperBin", L_104_)
	L_105_.BinType = "Clone"
	local L_106_ = Instance.new("HopperBin", L_104_)
	L_106_.BinType = "Hammer"
	local L_107_ = Instance.new("HopperBin", L_104_)
	L_107_.BinType = "Grab"
end

function L_18_.TeleportToRandomPlayer()
	local L_108_ = L_1_:GetPlayers()
	if #L_108_ <= 1 then
		return
	end
	local L_109_
	repeat
		L_109_ = L_108_[math.random(1, #L_108_)]
	until L_109_ ~= L_9_
	local L_110_ = L_21_func()
	local L_111_ =
        L_109_.Character and L_109_.Character:FindFirstChild("HumanoidRootPart")
	if L_110_ and L_111_ then
		L_110_.CFrame = L_111_.CFrame * CFrame.new(0, 0, 3)
	end
end

function L_18_.RejoinServer()
	L_4_:TeleportToPlaceInstance(
        game.PlaceId,
        game.JobId,
        L_9_
    )
end

local function L_32_func(L_112_arg0, L_113_arg1)
	local L_114_ = L_113_arg1 and ("&cursor=" .. L_113_arg1) or ""
	local L_115_ = game:HttpGet(L_112_arg0 .. L_114_)
	return L_5_:JSONDecode(L_115_)
end

function L_18_.ServerHop()
	local L_116_ = game.PlaceId
	local L_117_ =
        "https://games.roblox.com/v1/games/"
        .. tostring(L_116_)
        .. "/servers/Public?sortOrder=Asc&limit=100"
	local L_118_ = nil
	repeat
		local L_119_ = L_32_func(L_117_, L_118_)
		for L_120_forvar0, L_121_forvar1 in ipairs(L_119_.data or {}) do
			if L_121_forvar1.id ~= game.JobId
                and L_121_forvar1.playing < L_121_forvar1.maxPlayers
            then
				L_4_:TeleportToPlaceInstance(
                    L_116_,
                    L_121_forvar1.id,
                    L_9_
                )
				return
			end
		end
		L_118_ = L_119_.nextPageCursor
	until not L_118_
end

local function L_33_func()
	L_8_:CaptureController()
	L_8_:ClickButton2(Vector2.new(0, 0))
end

function L_18_.SetAntiKick(L_122_arg0)

	local L_123_ = getconnections or get_signal_cons
	if L_122_arg0 and L_123_ then
		for L_124_forvar0, L_125_forvar1 in pairs(L_123_(L_9_.Idled)) do
			if L_125_forvar1.Disable then
				L_125_forvar1:Disable()
			elseif L_125_forvar1.Disconnect then
				L_125_forvar1:Disconnect()
			end
		end
	end
	if L_122_arg0 then
		if not L_17_.antiIdle then
			L_17_.antiIdle = L_9_.Idled:Connect(function()
				pcall(L_33_func)
			end)
		end
	elseif L_17_.antiIdle then
		pcall(function()
			L_17_.antiIdle:Disconnect()
		end)
		L_17_.antiIdle = nil
	end
	L_19_func(
        "AFK Safety",
        L_122_arg0 and "Anti-Kick Enabled" or "Anti-Kick Disabled"
    )
end

function L_18_.SetDisable3D(L_126_arg0)
	L_15_.Disable3D = L_126_arg0
	pcall(function()
		L_2_:Set3dRenderingEnabled(not L_15_.Disable3D)
	end)
	L_19_func(
        "Performance",
        L_126_arg0 and "3D Rendering Disabled" or "3D Rendering Enabled"
    )
end

local function L_34_func()
	settings().Rendering.QualityLevel = Enum.QualityLevel.Level01
	local L_127_ = L_20_func()
	for L_128_forvar0, L_129_forvar1 in ipairs(L_7_:GetDescendants()) do
		if L_129_forvar1:IsA("BasePart") then
			if not L_127_ or not L_129_forvar1:IsDescendantOf(L_127_) then
				L_129_forvar1.Material = Enum.Material.SmoothPlastic
				L_129_forvar1.Reflectance = 0
			end
		elseif L_129_forvar1:IsA("Decal") or L_129_forvar1:IsA("Texture") then
			L_129_forvar1:Destroy()
		elseif L_129_forvar1:IsA("ParticleEmitter") or L_129_forvar1:IsA("Trail") then
			L_129_forvar1.Enabled = false
		end
	end
end

function L_18_.SetFPSBooster(L_130_arg0)
	L_15_.FPSBoost = L_130_arg0
	if L_130_arg0 then
		pcall(L_34_func)
	end
	L_19_func(
        "Performance",
        L_130_arg0 and "FPS Booster Active" or "FPS Booster Disabled"
    )
end

function L_18_.CopyDiscord()
	if setclipboard then
		setclipboard(L_14_)
	end
	L_19_func("Copied!", "Discord link copied.", 3, false)
end

local L_35_ = 0

local function L_36_func(L_131_arg0)
	if not getgenv then
		return
	end
	for L_132_forvar0, L_133_forvar1 in pairs(getgenv()) do
		if type(L_132_forvar0) == "string"
            and L_132_forvar0:sub(1, 3) == "_h_"
            and typeof(L_133_forvar1) == "Instance"
            and L_133_forvar1:IsA("ScreenGui")
        then
			L_131_arg0(L_132_forvar0, L_133_forvar1)
		end
	end
end

function L_18_.SetUIOpacity(L_134_arg0)
	L_35_ = L_134_arg0 / 10
	pcall(function()
		L_36_func(function(L_135_arg0, L_136_arg1)
			local L_137_ = L_136_arg1:FindFirstChild("Main")
			if L_137_ then
				L_137_.BackgroundTransparency = L_35_
			end
		end)
	end)
end

function L_18_.CleanupUI()
	pcall(function()
		L_36_func(function(L_138_arg0, L_139_arg1)
			pcall(function()
				L_139_arg1:Destroy()
			end)
			getgenv()[L_138_arg0] = nil
		end)
	end)
end

function L_18_.ReloadUI(L_140_arg0)
	L_18_.CleanupUI()
	task.wait(0.1)
	if L_140_arg0 and L_140_arg0.CreateLib then
		getgenv().Window =
            L_140_arg0.CreateLib(L_12_, "Midnight")
	end
	L_19_func("Reloaded", "Hub UI restarted.", 3)
end

local L_37_ = {
	["Pizza Planet"] = {
		"pizza",
		"delivery"
	},
	["Hairdresser"] = {
		"hair",
		"style"
	},
	["Janitor"] = {
		"janitor",
		"clean",
		"mop",
		"pick"
	},
	["Cashier"] = {
		"cashier",
		"register"
	},
	["Fresh Food"] = {
		"fresh food",
		"stock",
		"stocker"
	},
	["Lumber"] = {
		"lumber",
		"wood",
		"woodcutter"
	},
	["Mechanic"] = {
		"mechanic",
		"mike",
		"motors"
	},
	["Town Hall"] = {
		"town hall",
		"townhall",
		"office"
	},
	["Fisherman"] = {
		"fish",
		"fishing",
		"dock"
	},
	["Miner"] = {
		"miner",
		"mine",
		"mining",
		"cave"
	},
}

local function L_38_func(L_141_arg0)
	return (
        tostring(L_141_arg0.ActionText or "")
        .. " "
        .. tostring(L_141_arg0.ObjectText or "")
        .. " "
        .. tostring(L_141_arg0.Parent and L_141_arg0.Parent.Name or "")
    ):lower()
end

local function L_39_func(L_142_arg0)
	local L_143_ = L_21_func()
	if not L_143_ or not L_142_arg0 then
		return false
	end
	local L_144_ = L_142_arg0.Parent
	local L_145_
	if L_144_ and L_144_:IsA("Model") then
		L_145_ =
            L_144_.PrimaryPart
            or L_144_:FindFirstChildWhichIsA("BasePart")
	elseif L_144_ and L_144_:IsA("BasePart") then
		L_145_ = L_144_
	end
	if not L_145_ then
		return false
	end
	local L_146_ = L_143_.CFrame
	L_143_.CFrame = L_145_.CFrame + Vector3.new(0, 2, 0)
	task.wait(0.3)
	if L_142_arg0.Enabled and fireproximityprompt then
		fireproximityprompt(L_142_arg0, 9000000000)
		task.wait(0.2)
	end
	L_143_.CFrame = L_146_
	return true
end

function L_18_.TeleportToBloxburgJob(L_147_arg0)
	local L_148_ = L_37_[L_147_arg0]
	if not L_148_ then
		return
	end
	for L_149_forvar0, L_150_forvar1 in ipairs(L_7_:GetDescendants()) do
		if L_150_forvar1:IsA("ProximityPrompt") then
			local L_151_ = L_38_func(L_150_forvar1)
			for L_152_forvar0, L_153_forvar1 in ipairs(L_148_) do
				if L_151_:find(L_153_forvar1, 1, true) then
					L_39_func(L_150_forvar1)
					return
				end
			end
		end
	end
end

local function L_40_func(...)
	local L_154_ = {
		...
	}
	for L_155_forvar0, L_156_forvar1 in ipairs(L_7_:GetDescendants()) do
		if L_156_forvar1:IsA("ProximityPrompt") then
			local L_157_ = tostring(L_156_forvar1.ActionText or ""):lower()
			for L_158_forvar0, L_159_forvar1 in ipairs(L_154_) do
				if L_157_:find(L_159_forvar1, 1, true) then
					return L_156_forvar1
				end
			end
		end
	end
end

local function L_41_func()
	local L_160_ = L_40_func("clean", "mop", "pick")
	if L_160_ then
		L_39_func(L_160_)
	end
end

local L_42_ = nil

local function L_43_func()
	if L_42_ and L_42_.Parent then
		return L_42_
	end
	for L_161_forvar0, L_162_forvar1 in ipairs(L_7_:GetDescendants()) do
		local L_163_ = L_162_forvar1.Name:lower()
		if L_163_:find("plot", 1, true) or L_163_:find("house", 1, true) then
			local L_164_ =
                L_162_forvar1:FindFirstChild("Owner")
                or L_162_forvar1:FindFirstChild("Player")
			if L_164_
                and (L_164_.Value == L_9_ or L_164_.Value == L_9_.Name)
            then
				L_42_ = L_162_forvar1
				return L_162_forvar1
			end
		end
	end
end

local function L_44_func(L_165_arg0, L_166_arg1, L_167_arg2)
	if not L_165_arg0 or not L_166_arg1 or not L_166_arg1.Enabled then
		return
	end
	L_165_arg0.CFrame = L_166_arg1.Parent.CFrame + Vector3.new(0, 2, 0)
	task.wait(0.3)
	if fireproximityprompt then
		fireproximityprompt(L_166_arg1, 9000000000)
	end
	task.wait(L_167_arg2)
end

local function L_45_func()
	local L_168_ = L_43_func()
	if not L_168_ then
		L_19_func(
            "Mood Booster",
            "Plot not found! Teleporting to Town Mood Station.",
            3
        )
		return
	end
	local L_169_
	local L_170_
	local L_171_
	local L_172_
	for L_175_forvar0, L_176_forvar1 in ipairs(L_168_:GetDescendants()) do
		if L_176_forvar1:IsA("ProximityPrompt") then
			local L_177_ = tostring(L_176_forvar1.ActionText or ""):lower()
			local L_178_ = tostring(L_176_forvar1.ObjectText or ""):lower()
			if not L_169_
                and (
                    L_177_:find("sleep", 1, true)
                    or L_177_:find("rest", 1, true)
                    or L_178_:find("bed", 1, true)
                )
            then
				L_169_ = L_176_forvar1
			elseif not L_170_
                and (
                    L_177_:find("shower", 1, true)
                    or L_177_:find("bath", 1, true)
                    or L_178_:find("shower", 1, true)
                )
            then
				L_170_ = L_176_forvar1
			elseif not L_171_
                and (
                    L_177_:find("eat", 1, true)
                    or L_177_:find("take", 1, true)
                    or L_178_:find("fridge", 1, true)
                )
            then
				L_171_ = L_176_forvar1
			elseif not L_172_
                and (
                    L_177_:find("watch", 1, true)
                    or L_178_:find("tv", 1, true)
                    or L_178_:find("television", 1, true)
                )
            then
				L_172_ = L_176_forvar1
			end
		end
	end
	local L_173_ = L_21_func()
	if not L_173_ then
		return
	end
	local L_174_ = L_173_.CFrame

	L_44_func(L_173_, L_169_, 5)
	L_44_func(L_173_, L_170_, 4)
	L_44_func(L_173_, L_171_, 2)
	L_44_func(L_173_, L_172_, 2)
	L_173_.CFrame = L_174_
end

local function L_46_func()

	local L_179_ = L_20_func()
	if not L_179_ then
		return
	end
	local L_180_ =
        L_179_:FindFirstChild("Pizza")
        or L_179_:FindFirstChild("Pizza Box")
        or L_179_:FindFirstChild("Box")
	if not L_180_ then
		L_18_.TeleportToBloxburgJob("Pizza Planet")
		return
	end
	local L_181_ = L_40_func("deliver", "give")
	if L_181_ then
		L_39_func(L_181_)
	end
end

function L_18_.SetAutoPizzaDelivery(L_182_arg0)
	L_15_.AutoDelivery = L_182_arg0
	L_19_func(
        "Job Farm",
        L_182_arg0 and "Auto Pizza Delivery Active"
            or "Auto Pizza Delivery Disabled"
    )
end

function L_18_.SetAutoJanitor(L_183_arg0)
	L_15_.AutoJanitor = L_183_arg0
	L_19_func(
        "Job Farm",
        L_183_arg0 and "Auto Janitor Cleaning Active"
            or "Auto Janitor Cleaning Disabled"
    )
end

function L_18_.StartMoodBoost()
	L_19_func("Mood Booster", "Starting mood boost sequence...")
	pcall(L_45_func)
end

function L_18_.SetAutoMood(L_184_arg0)
	L_15_.AutoMood = L_184_arg0
	L_19_func(
        "Mood Booster",
        L_184_arg0 and "Periodic Mood Boosting Active"
            or "Periodic Mood Boosting Disabled"
    )
end

function L_18_.SetBloxburgWalkSpeed(L_185_arg0)
	L_15_.WalkSpeed = L_185_arg0
end

function L_18_.SetBloxburgWalkSpeedLock(L_186_arg0)
	L_15_.WSLock = L_186_arg0
end

function L_18_.SetBloxburgJumpPower(L_187_arg0)
	L_15_.JumpPower = L_187_arg0
end

function L_18_.SetBloxburgJumpPowerLock(L_188_arg0)
	L_15_.JPLock = L_188_arg0
end

task.spawn(function()
	while true do
		task.wait(1.5)
		if L_15_.AutoDelivery then
			pcall(L_46_func)
		end
	end
end)

task.spawn(function()
	while true do
		task.wait(1.5)
		if L_15_.AutoJanitor then
			pcall(L_41_func)
		end
	end
end)

task.spawn(function()
	while true do
		task.wait(120)
		if L_15_.AutoMood then
			pcall(L_45_func)
		end
	end
end)

L_17_.modifier = L_2_.Stepped:Connect(function()
	local L_189_ = L_22_func()
	if not L_189_ then
		return
	end
	if L_15_.WSLock then
		L_189_.WalkSpeed = L_15_.WalkSpeed
	end
	if L_15_.JPLock then
		L_189_.JumpPower = L_15_.JumpPower
		L_189_.UseJumpPower = true
	end
	if L_11_.GodModeEnabled then
		pcall(L_24_func)
	end
end)

L_18_.UIBindings = {
	Player = {
		{
			"Walk Speed Value",
			L_18_.SetWalkSpeed
		},
		{
			"Jump Power Value",
			L_18_.SetJumpPower
		},
		{
			"Gravity",
			L_18_.SetGravity
		},
		{
			"God Mode",
			L_18_.SetGodMode
		},
		{
			"Noclip",
			L_18_.SetNoclip
		},
		{
			"Infinite Jump",
			L_18_.SetInfiniteJump
		},
	},
	Visuals = {
		{
			"Field of View",
			L_18_.SetCameraFOV
		},
		{
			"Fullbright",
			L_18_.SetFullbright
		},
		{
			"Player ESP",
			L_18_.SetPlayerESP
		},
		{
			"Hitbox Expander",
			L_18_.SetHitboxSize
		},
	},
	Aimbot = {
		{
			"Enable Aimbot (Right Click)",
			L_18_.SetAimbotEnabled
		},
		{
			"Show FOV Circle",
			L_18_.SetShowFOV
		},
		{
			"FOV Size",
			L_18_.SetFOVRadius
		},
		{
			"Aimbot Smoothness",
			L_18_.SetAimbotSmoothness
		},
		{
			"Team Check",
			L_18_.SetTeamCheck
		},
	},
	Utility = {
		{
			"Give Btools",
			L_18_.GiveBtools
		},
		{
			"Teleport to Random Player",
			L_18_.TeleportToRandomPlayer
		},
		{
			"Rejoin Server",
			L_18_.RejoinServer
		},
		{
			"Server Hop",
			L_18_.ServerHop
		},
		{
			"Anti-Kick (Anti-AFK)",
			L_18_.SetAntiKick
		},
		{
			"Disable 3D Rendering",
			L_18_.SetDisable3D
		},
		{
			"FPS Booster",
			L_18_.SetFPSBooster
		},
		{
			"Copy Discord Link",
			L_18_.CopyDiscord
		},
	},
	Bloxburg = {
		{
			"Auto Pizza Delivery",
			L_18_.SetAutoPizzaDelivery
		},
		{
			"Auto Janitor cleaning",
			L_18_.SetAutoJanitor
		},
		{
			"Insta Boost Moods",
			L_18_.StartMoodBoost
		},
		{
			"Auto Boost Moods (Periodic)",
			L_18_.SetAutoMood
		},
		{
			"Teleport to Pizza Delivery job start",
			function()
				L_18_.TeleportToBloxburgJob("Pizza Planet")
			end
		},
		{
			"Teleport to Hairdresser job start",
			function()
				L_18_.TeleportToBloxburgJob("Hairdresser")
			end
		},
		{
			"Teleport to Janitor job start",
			function()
				L_18_.TeleportToBloxburgJob("Janitor")
			end
		},
		{
			"Teleport to Cashier job start",
			function()
				L_18_.TeleportToBloxburgJob("Cashier")
			end
		},
		{
			"Teleport to Fresh Food",
			function()
				L_18_.TeleportToBloxburgJob("Fresh Food")
			end
		},
		{
			"Teleport to Woodcutter job start",
			function()
				L_18_.TeleportToBloxburgJob("Lumber")
			end
		},
		{
			"Teleport to Mechanic job start",
			function()
				L_18_.TeleportToBloxburgJob("Mechanic")
			end
		},
		{
			"Teleport to Town Hall",
			function()
				L_18_.TeleportToBloxburgJob("Town Hall")
			end
		},
		{
			"Teleport to Fisherman job start",
			function()
				L_18_.TeleportToBloxburgJob("Fisherman")
			end
		},
		{
			"Teleport to Miner job start",
			function()
				L_18_.TeleportToBloxburgJob("Miner")
			end
		},
	},
}

print("[SnowyHub] Payload UI ready: " .. L_12_)

return L_18_
