local L_1_ = {}

local L_2_ = game:GetService("Players")
local L_3_ = game:GetService("ReplicatedStorage")
local L_4_ = game:GetService("RunService")
local L_5_ = game:GetService("UserInputService")
local L_6_ = game:GetService("Lighting")
local L_7_ = game:GetService("TeleportService")
local L_8_ = game:GetService("HttpService")
local L_9_ = game:GetService("VirtualUser")
local L_10_ = game.Workspace

local L_11_ = L_2_.LocalPlayer
local L_12_ = L_10_.CurrentCamera
local L_13_ = (getgenv and getgenv()) or _G

local L_14_ = nil
local L_15_ = {
	AccentColor = Color3.fromRGB(255, 255, 255),
	SecondaryColor = Color3.fromRGB(255, 255, 255),
}
local L_16_ = nil

function L_1_.setUI(L_59_arg0)
	L_14_ = L_59_arg0
end

function L_1_.setTheme(L_60_arg0)
	if type(L_60_arg0) == "table" then
		L_15_ = L_60_arg0
	end
end

function L_1_.setGameDescriptor(L_61_arg0)
	L_16_ = L_61_arg0
end

local function L_17_func(L_62_arg0, L_63_arg1, L_64_arg2)
	if L_14_ and type(L_14_.Notify) == "function" then
		pcall(function()
			L_14_:Notify(L_62_arg0, L_63_arg1, L_64_arg2 or 3)
		end)
	end
end

local function L_18_func()
	return L_16_ ~= nil and L_16_.name == "Adopt Me"
end

local function L_19_func(L_65_arg0)
	return L_65_arg0 and L_65_arg0.Character or nil
end

local function L_20_func(L_66_arg0)
	local L_67_ = L_19_func(L_66_arg0)
	if not L_67_ then
		return nil
	end
	return L_67_:FindFirstChild("Humanoid")
        or L_67_:FindFirstChildOfClass("Humanoid")
end

local function L_21_func(L_68_arg0)
	local L_69_ = L_19_func(L_68_arg0)
	return L_69_ and L_69_:FindFirstChild("HumanoidRootPart") or nil
end

L_1_.getCharacter = L_19_func
L_1_.getHumanoid = L_20_func
L_1_.getRoot = L_21_func

local L_22_ = {
	WalkSpeedValue = 16,
	JumpPowerValue = 50,
	GodModeEnabled = false,
	InfiniteJump = false,
	Noclip = false,
	Aimbot = {
		Enabled = false,
		ShowFOV = false,
		FOVRadius = 80,
		Smoothness = 0.5,
		TeamCheck = true,
		TargetPart = "Head",
	},
}

L_1_.UniversalState = L_22_

L_13_.WalkSpeedValue = L_13_.WalkSpeedValue or L_22_.WalkSpeedValue
L_13_.JumpPowerValue = L_13_.JumpPowerValue or L_22_.JumpPowerValue
L_13_.GodModeEnabled = L_13_.GodModeEnabled or false

local function L_23_func()
	if not L_13_.GodModeEnabled then
		return
	end
	local L_70_ = L_20_func(L_11_)
	local L_71_ = L_21_func(L_11_)
	if not L_70_ or not L_71_ then
		return
	end
	if L_70_.MaxHealth ~= math.huge then
		L_70_.MaxHealth = math.huge
	end
	if L_70_.Health ~= math.huge then
		L_70_.Health = math.huge
	end
	pcall(function()
		L_70_:SetStateEnabled(Enum.HumanoidStateType.Dead, false)
	end)
end

local function L_24_func()
	local L_72_ = L_20_func(L_11_)
	if not L_72_ then
		return
	end
	L_72_.MaxHealth = 100
	L_72_.Health = 100
	L_72_:SetStateEnabled(Enum.HumanoidStateType.Dead, true)
end

function L_1_.setUniversalWalkSpeed(L_73_arg0)
	L_22_.WalkSpeedValue = L_73_arg0
	L_13_.WalkSpeedValue = L_73_arg0
	local L_74_ = L_20_func(L_11_)
	if L_74_ then
		L_74_.WalkSpeed = L_73_arg0
	end
end

function L_1_.setUniversalJumpPower(L_75_arg0)
	L_22_.JumpPowerValue = L_75_arg0
	L_13_.JumpPowerValue = L_75_arg0
	local L_76_ = L_20_func(L_11_)
	if L_76_ then
		L_76_.JumpPower = L_75_arg0
	end
end

function L_1_.setGravity(L_77_arg0)
	L_10_.Gravity = L_77_arg0
end

function L_1_.setGodMode(L_78_arg0)
	L_22_.GodModeEnabled = L_78_arg0
	L_13_.GodModeEnabled = L_78_arg0
	if not L_78_arg0 then
		pcall(L_24_func)
	end
end

local L_25_ = nil

local function L_26_func()
	if not L_22_.Noclip then
		return
	end
	local L_79_ = L_11_.Character
	if not L_79_ then
		return
	end
	for L_80_forvar0, L_81_forvar1 in pairs(L_79_:GetDescendants()) do
		if L_81_forvar1:IsA("BasePart")
            and L_81_forvar1.CanCollide
            and L_81_forvar1.Name ~= L_13_.floatName
        then
			L_81_forvar1.CanCollide = false
		end
	end

	wait(0.21)
end

local function L_27_func()
	L_22_.Noclip = true
	if L_25_ then
		L_25_:Disconnect()
	end
	L_25_ = L_4_.Stepped:Connect(L_26_func)
end

local function L_28_func()
	if L_25_ then
		L_25_:Disconnect()
		L_25_ = nil
	end
	L_22_.Noclip = false
end

function L_1_.setNoClip(L_82_arg0)
	if L_82_arg0 then
		L_27_func()
	else
		L_28_func()
	end
end

local L_29_ = nil

local function L_30_func()
	if not L_22_.InfiniteJump then
		return
	end
	local L_83_ = L_20_func(L_11_)
	if L_83_ then

		L_83_:ChangeState("Jumping")
	end
end

function L_1_.setInfiniteJump(L_84_arg0)
	L_22_.InfiniteJump = L_84_arg0
	if not L_29_ then
		L_29_ = L_5_.JumpRequest:Connect(L_30_func)
	end
end

function L_1_.setCameraFOV(L_85_arg0)
	L_12_.FieldOfView = L_85_arg0
end

function L_1_.setFullbright(L_86_arg0)
	if L_86_arg0 then
		L_6_.Ambient = Color3.new(1, 1, 1)
		L_6_.ColorShift_Bottom = Color3.new(1, 1, 1)
		L_6_.ColorShift_Top = Color3.new(1, 1, 1)
		L_6_.GlobalShadows = false
	else

		L_6_.Ambient = Color3.fromRGB(128, 128, 128)
		L_6_.GlobalShadows = true
	end
end

local L_31_ = {}

local function L_32_func()
	for L_87_forvar0, L_88_forvar1 in pairs(L_31_) do
		if L_88_forvar1 and L_88_forvar1.Parent then
			L_88_forvar1:Destroy()
		end
	end
	L_31_ = {}
end

function L_1_.setPlayerESP(L_89_arg0)
	if not L_89_arg0 then
		L_32_func()
		return
	end
	for L_90_forvar0, L_91_forvar1 in pairs(L_2_:GetPlayers()) do
		if L_91_forvar1 ~= L_11_ and L_91_forvar1.Character then
			local L_92_ = Instance.new("Highlight")
			L_92_.Parent = L_91_forvar1.Character
			L_92_.FillColor = L_15_.AccentColor
			L_92_.OutlineColor = L_15_.SecondaryColor
			L_92_.FillTransparency = 0.5
			table.insert(L_31_, L_92_)
		end
	end
end

local L_33_ = nil

local function L_34_func()
	if not _G.Disabled then
		return
	end
	for L_93_forvar0, L_94_forvar1 in next, L_2_:GetPlayers() do
		if L_94_forvar1 ~= L_11_ then
			pcall(function()
				local L_95_ = L_94_forvar1.Character.HumanoidRootPart
				local L_96_ = _G.HeadSize
				L_95_.Size = Vector3.new(L_96_, L_96_, L_96_)
				L_95_.Transparency = 0.7
				L_95_.BrickColor = BrickColor.new("Really blue")
				L_95_.Material = "Neon"
				L_95_.CanCollide = false
			end)
		end
	end
end

function L_1_.setHitboxSize(L_97_arg0)
	_G.HeadSize = L_97_arg0
	_G.Disabled = true

	if not L_33_ then
		L_33_ = L_4_.RenderStepped:Connect(L_34_func)
	end
end

function L_1_.giveBuildingTools()
	local L_98_ = L_11_.Backpack
	local L_99_ = Instance.new("HopperBin", L_98_)
	L_99_.BinType = "Clone"
	local L_100_ = Instance.new("HopperBin", L_98_)
	L_100_.BinType = "Hammer"
	local L_101_ = Instance.new("HopperBin", L_98_)
	L_101_.BinType = "Grab"
end

function L_1_.teleportToRandomPlayer()
	local L_102_ = L_2_:GetPlayers()
	if #L_102_ <= 1 then
		return
	end
	local L_103_
	repeat
		L_103_ = L_102_[math.random(1, #L_102_)]
	until L_103_.Name ~= L_11_.Name
	local L_104_ = L_21_func(L_103_)
	local L_105_ = L_21_func(L_11_)
	if L_104_ and L_105_ then
		L_105_.CFrame = L_104_.CFrame * CFrame.new(0, 0, 3)
	end
end

function L_1_.rejoinServer()
	L_7_:TeleportToPlaceInstance(game.PlaceId, game.JobId, L_11_)
end

function L_1_.serverHop()

	local L_106_ = game.PlaceId
	local L_107_ = "https://games.roblox.com/v1/games/"
        .. tostring(L_106_)
        .. "/servers/Public?sortOrder=Asc&limit=100"
	local L_108_ = nil
	while true do
		local L_109_ = L_108_ and ("&cursor=" .. L_108_) or ""
		local L_110_ = game:HttpGet(L_107_ .. L_109_)
		local L_111_ = L_8_:JSONDecode(L_110_)
		local L_112_ = L_111_.data and L_111_.data[1]
		L_108_ = L_111_.nextPageCursor
		if L_112_ then
			L_7_:TeleportToPlaceInstance(L_106_, L_112_.id, L_11_)
			return
		end
		if not L_108_ then
			return
		end
	end
end

function L_1_.disableIdleConnections(L_113_arg0)
	if not L_113_arg0 then
		return
	end
	local L_114_ = getconnections or get_signal_cons
	if not L_114_ then
		return
	end
	for L_115_forvar0, L_116_forvar1 in pairs(L_114_(L_11_.Idled)) do
		if L_116_forvar1.Disable then
			L_116_forvar1:Disable()
		elseif L_116_forvar1.Disconnect then
			L_116_forvar1:Disconnect()
		end
	end
end

local L_35_ = L_22_.Aimbot
local L_36_ = nil

local function L_37_func()
	local L_117_ = L_35_.FOVRadius
	local L_118_ = nil
	local L_119_ = L_5_:GetMouseLocation()
	for L_120_forvar0, L_121_forvar1 in pairs(L_2_:GetPlayers()) do
		if L_121_forvar1 ~= L_11_ and L_121_forvar1.Character then
			local L_122_ = L_121_forvar1.Character:FindFirstChild(L_35_.TargetPart)
			local L_123_ = L_121_forvar1.Character:FindFirstChild("Humanoid")
			if L_122_ and L_123_ and L_123_.Health > 0 then

				if L_35_.TeamCheck then
					local L_126_ = L_121_forvar1.Team == L_11_.Team

				end
				local L_124_, L_125_ = L_12_:WorldToViewportPoint(L_122_.Position)
				if L_125_ then
					local L_127_ = Vector2.new(L_124_.X, L_124_.Y)
					local L_128_ = (L_127_ - L_119_).Magnitude
					if L_128_ < L_117_ then
						L_117_ = L_128_
						L_118_ = L_121_forvar1
					end
				end
			end
		end
	end
	return L_118_
end

local function L_38_func()
	if L_36_ or not Drawing or not Drawing.new then
		return
	end
	L_36_ = Drawing.new("Circle")
	L_36_.Position = Vector2.new(L_12_.ViewportSize.X / 2, L_12_.ViewportSize.Y / 2)
	L_36_.Radius = L_35_.FOVRadius
	L_36_.Filled = false
	L_36_.Color = Color3.fromRGB(255, 255, 255)
	L_36_.Visible = false
	L_36_.Thickness = 1
end

local function L_39_func()
	L_38_func()
	if L_36_ then
		if L_35_.ShowFOV then
			L_36_.Position = L_5_:GetMouseLocation()
			L_36_.Radius = L_35_.FOVRadius
			L_36_.Visible = true
		else
			L_36_.Visible = false
		end
	end
	if not L_35_.Enabled then
		return
	end
	if not L_5_:IsMouseButtonPressed(Enum.UserInputType.MouseButton2) then
		return
	end
	local L_129_ = L_37_func()
	local L_130_ = L_129_ and L_129_.Character and L_129_.Character:FindFirstChild(L_35_.TargetPart)
	if L_130_ then
		local L_131_ = CFrame.new(L_12_.CFrame.Position, L_130_.Position)
		L_12_.CFrame = L_12_.CFrame:Lerp(L_131_, L_35_.Smoothness)
	end
end

function L_1_.setAimbotEnabled(L_132_arg0)
	L_35_.Enabled = L_132_arg0
end

function L_1_.setShowFOV(L_133_arg0)
	L_35_.ShowFOV = L_133_arg0
end

function L_1_.setAimbotFOV(L_134_arg0)
	L_35_.FOVRadius = L_134_arg0
end

function L_1_.setAimbotSmoothness(L_135_arg0)
	L_35_.Smoothness = L_135_arg0 / 100
end

function L_1_.setAimbotTeamCheck(L_136_arg0)
	L_35_.TeamCheck = L_136_arg0
end

function L_1_.testNotification()
	if L_14_ then
		L_14_:Notify("Test", "Test the notification system", 3)
	end
end

function L_1_.testPremiumNotification()
	if L_14_ then
		L_14_:Notify("Premium Alert", "Premium-style notification", 3)
	end
end

function L_1_.setUIOpacity(L_137_arg0)
	local L_138_ = L_137_arg0 / 10
	pcall(function()
		for L_139_forvar0, L_140_forvar1 in pairs(L_13_) do
			if type(L_139_forvar0) == "string"
                and L_139_forvar0:sub(1, 3) == "_h_"
                and typeof(L_140_forvar1) == "Instance"
                and L_140_forvar1:IsA("ScreenGui")
            then
				local L_141_ = L_140_forvar1:FindFirstChild("Main")
				if L_141_ then
					L_141_.BackgroundTransparency = L_138_
				end
			end
		end
	end)
end

function L_1_.copyDiscord()
	if setclipboard then
		setclipboard("https://discord.gg/getsnowy")
	end
	if L_14_ then
		L_14_:Notify("Copied!", "Discord link copied.", 3, false)
	end
end

local L_40_ = {
	AutoFarm = false,
	AutoHatch = false,
	AutoBuyEggs = false,
	AutoJob = false,
	SelectedJob = "Pizza Shop",
	AutoCollectEvent = false,
	AntiKick = true,
	WSLock = false,
	WalkSpeed = 16,
	JPLock = false,
	JumpPower = 50,
	Disable3D = false,
}

L_1_.State = L_40_

local L_41_ = L_3_:FindFirstChild("Fsys")
local L_42_ = {}

local function L_43_func(L_142_arg0)
	if not L_41_ then
		return
	end
	local L_143_ = require(L_41_)
	local L_144_ = L_143_.load("RouterClient")
	if L_144_ and L_144_.get_remote_from_cache then
		local L_145_ = L_144_.get_remote_from_cache(L_142_arg0)
		if L_145_ then
			L_42_[L_142_arg0] = L_145_
		end
	end
end

local function L_44_func(L_146_arg0)
	if L_42_[L_146_arg0] then
		return L_42_[L_146_arg0]
	end
	local L_147_ = L_3_:FindFirstChild("API")
	if L_147_ then
		local L_148_ = L_147_:FindFirstChild(L_146_arg0)
		if L_148_ then
			L_42_[L_146_arg0] = L_147_[L_146_arg0]
			return L_42_[L_146_arg0]
		end
	end
	if L_41_ then
		pcall(L_43_func, L_146_arg0)
	end
	return L_42_[L_146_arg0]
end

L_1_.getRemote = L_44_func

local function L_45_func()
	if not L_41_ then
		return nil
	end
	local L_149_ = require(L_41_)
	return L_149_ and L_149_.load and L_149_.load("Data") or nil
end

local function L_46_func()
	local L_150_ = L_45_func()
	if not L_150_ or not L_150_.get_data then
		return nil
	end
	return L_150_.get_data(L_11_)
end

local function L_47_func()
	local L_151_ = nil
	pcall(function()
		local L_152_ = L_46_func()
		local L_153_ = L_152_ and L_152_.inventory
		local L_154_ = L_153_ and L_153_.pets
		if not L_154_ then
			return
		end
		for L_155_forvar0, L_156_forvar1 in pairs(L_154_) do
			if L_156_forvar1.equipped then
				L_151_ = L_156_forvar1.unique
				return
			end
		end
	end)
	return L_151_
end

L_1_.getEquippedPetUnique = L_47_func

local function L_48_func(L_157_arg0, L_158_arg1)
	local L_159_ = L_44_func("MonitorAPI/AddRate")
	if not L_159_ then
		return
	end
	pcall(function()
		if L_159_:IsA("RemoteFunction") then
			L_159_:InvokeServer(L_157_arg0, 100, L_158_arg1)
		else
			L_159_:FireServer(L_157_arg0, 100, L_158_arg1)
		end
	end)
end

function L_1_.completeVisibleAilments()
	local L_160_ = L_11_:FindFirstChild("PlayerGui")
	local L_161_ = L_160_ and L_160_:FindFirstChild("AilmentsMonitorApp")
	if not L_161_ then
		return
	end
	local L_162_ = L_47_func()
	for L_163_forvar0, L_164_forvar1 in ipairs(L_161_:GetChildren()) do
		if L_164_forvar1:IsA("Frame") and L_164_forvar1.Name ~= "Background" then
			for L_165_forvar0, L_166_forvar1 in ipairs(L_164_forvar1:GetChildren()) do
				if L_166_forvar1:IsA("Frame") and L_166_forvar1.Name ~= "Template" then
					task.spawn(L_48_func, L_166_forvar1.Name, L_162_)
				end
			end
		end
	end
end

local function L_49_func()
	while true do
		task.wait(2)
		if L_18_func() and L_40_.AutoFarm then
			pcall(L_1_.completeVisibleAilments)
		end
	end
end

function L_1_.setAutoFarm(L_167_arg0)
	L_40_.AutoFarm = L_167_arg0
	L_17_func("Auto Farm", L_167_arg0 and "Enabled" or "Disabled")
end

function L_1_.performSelectedJob()
	local L_168_ = L_44_func("JobAPI/ClaimJob")
	local L_169_ = L_44_func("JobAPI/PerformWork")
	if not L_168_ or not L_169_ then
		return
	end
	local L_170_ = L_40_.SelectedJob == "Pizza Shop"
        and "PizzaShop"
        or "Salon"
	L_168_:FireServer(L_170_)
	task.wait(1)
	L_169_:FireServer(L_170_)
end

local function L_50_func()
	while true do
		task.wait(5)
		if L_18_func() and L_40_.AutoJob then
			pcall(L_1_.performSelectedJob)
		end
	end
end

function L_1_.setSelectedJob(L_171_arg0)
	L_40_.SelectedJob = L_171_arg0
end

function L_1_.setAutoJob(L_172_arg0)
	L_40_.AutoJob = L_172_arg0
	local L_173_
	if L_172_arg0 then
		L_173_ = "Started working at " .. L_40_.SelectedJob
	else
		L_173_ = "Stopped working"
	end
	L_17_func("Auto Job", L_173_)
end

function L_1_.equipFirstUnequippedEgg()
	local L_174_ = L_46_func()
	local L_175_ = L_174_ and L_174_.inventory
	local L_176_ = L_175_ and L_175_.pets
	if not L_176_ then
		return
	end
	for L_177_forvar0, L_178_forvar1 in pairs(L_176_) do
		if L_178_forvar1.is_egg and not L_178_forvar1.equipped then
			local L_179_ = L_44_func("PetAPI/Equip")
			if L_179_ then
				L_179_:FireServer(L_178_forvar1.unique)
			end
			return
		end
	end
end

local function L_51_func()
	while true do
		task.wait(5)
		if L_18_func() and L_40_.AutoHatch then
			pcall(L_1_.equipFirstUnequippedEgg)
		end
	end
end

function L_1_.setAutoHatch(L_180_arg0)
	L_40_.AutoHatch = L_180_arg0
end

function L_1_.buyCrackedEgg()
	local L_181_ = L_44_func("ShopAPI/BuyItem")
	if L_181_ then
		L_181_:FireServer("pets", "cracked_egg", {})
	end
end

function L_1_.collectEventCurrency()
	local L_182_ = L_44_func("EventAPI/CollectCurrency")
        or L_44_func("WinterAPI/CollectGingerbread")
	if L_182_ then
		L_182_:FireServer()
	end
end

local function L_52_func()
	while true do
		task.wait(10)
		if L_18_func() and L_40_.AutoCollectEvent then
			pcall(L_1_.collectEventCurrency)
		end
	end
end

function L_1_.setAutoCollectEvent(L_183_arg0)
	L_40_.AutoCollectEvent = L_183_arg0
end

local L_53_ = {
	"Nursery",
	"School",
	"Hospital",
	"Hot Springs",
	"Pizza Place",
	"Supermarket",
	"Neighborhood",
}

local L_54_ = {
	["Nursery"] = "Nursery",
	["School"] = "School",
	["Hospital"] = "Hospital",
	["Hot Springs"] = "HotSpringHouse",
	["Pizza Place"] = "PizzaPlace",
	["Supermarket"] = "Supermarket",
	["Neighborhood"] = "Neighborhood",
}

L_1_.TeleportLocations = L_53_
L_1_.InteriorNames = L_54_

local function L_55_func(L_184_arg0)
	if not L_41_ then
		return
	end
	local L_185_ = require(L_41_)
	local L_186_ = L_185_.load("InteriorsM")
	if L_186_ and L_186_.enter then
		L_186_.enter(L_54_[L_184_arg0] or L_184_arg0)
	end
end

function L_1_.teleportTo(L_187_arg0)
	L_17_func("Teleport", "Traveling to " .. tostring(L_187_arg0))
	pcall(L_55_func, L_187_arg0)
end

function L_1_.setAdoptMeWalkSpeed(L_188_arg0)
	L_40_.WalkSpeed = L_188_arg0
end

function L_1_.setWalkSpeedLock(L_189_arg0)
	L_40_.WSLock = L_189_arg0
end

function L_1_.setJumpPowerLock(L_190_arg0)
	L_40_.JPLock = L_190_arg0
end

function L_1_.setAdoptMeJumpPower(L_191_arg0)
	L_40_.JumpPower = L_191_arg0
end

function L_1_.setDisable3D(L_192_arg0)
	L_40_.Disable3D = L_192_arg0
	pcall(function()
		L_4_:Set3dRenderingEnabled(not L_192_arg0)
	end)
end

local function L_56_func()
	L_9_:CaptureController()
	L_9_:ClickButton2(Vector2.new(0, 0))
end

function L_1_.setAdoptMeAntiAFK(L_193_arg0)
	L_40_.AntiKick = L_193_arg0

	if L_193_arg0 then
		L_11_.Idled:Connect(L_56_func)
	end
end

local function L_57_func()
	if not L_18_func() then
		return
	end
	local L_194_ = L_20_func(L_11_)
	if not L_194_ then
		return
	end
	if L_40_.WSLock then
		L_194_.WalkSpeed = L_40_.WalkSpeed
	end
	if L_40_.JPLock then
		L_194_.JumpPower = L_40_.JumpPower
		L_194_.UseJumpPower = true
	end
end

L_1_.Controls = {
	Universal = {
		Player = {
			{
				kind = "slider",
				name = "WalkSpeed",
				description = "Changes player speed",
				max = 250,
				default = 16,
				callback = L_1_.setUniversalWalkSpeed
			},
			{
				kind = "slider",
				name = "JumpPower",
				description = "Changes jump height",
				max = 250,
				default = 50,
				callback = L_1_.setUniversalJumpPower
			},
			{
				kind = "slider",
				name = "Gravity",
				description = "Changes world gravity",
				max = 196,
				default = 0,
				callback = L_1_.setGravity
			},
			{
				kind = "premiumToggle",
				name = "God Mode",
				description = "Instantly regenerates health",
				callback = L_1_.setGodMode
			},
			{
				kind = "premiumToggle",
				name = "Noclip",
				description = "Walk through objects and walls",
				callback = L_1_.setNoClip
			},
			{
				kind = "premiumToggle",
				name = "Infinite Jump",
				description = "Jump in mid-air",
				callback = L_1_.setInfiniteJump
			},
		},
		Visual = {
			{
				kind = "slider",
				name = "Field of View",
				description = "Change camera FOV",
				max = 120,
				default = 70,
				callback = L_1_.setCameraFOV
			},
			{
				kind = "toggle",
				name = "Fullbright",
				description = "Removes shadows and darkness",
				callback = L_1_.setFullbright
			},
			{
				kind = "premiumToggle",
				name = "Player ESP",
				description = "Highlights all players through walls",
				callback = L_1_.setPlayerESP
			},
			{
				kind = "premiumSlider",
				name = "Hitbox Expander",
				description = "Make enemies easier to hit",
				max = 20,
				default = 2,
				callback = L_1_.setHitboxSize
			},
		},
		Utility = {
			{
				kind = "button",
				name = "Give Btools",
				description = "Gives building tools to inventory",
				callback = L_1_.giveBuildingTools
			},
			{
				kind = "button",
				name = "Teleport to Random Player",
				description = "TPs you to a random user",
				callback = L_1_.teleportToRandomPlayer
			},
			{
				kind = "button",
				name = "Rejoin",
				description = "Rejoins current server",
				callback = L_1_.rejoinServer
			},
			{
				kind = "premiumButton",
				name = "Server Hop",
				description = "Joins a random new server",
				callback = L_1_.serverHop
			},
			{
				kind = "toggle",
				name = "Anti-AFK",
				description = "Prevents Roblox disconnects",
				callback = L_1_.disableIdleConnections
			},
		},
		Aimbot = {
			{
				kind = "premiumToggle",
				name = "Enable Aimbot (Right Click)",
				description = "Locks onto targets in FOV",
				callback = L_1_.setAimbotEnabled
			},
			{
				kind = "toggle",
				name = "Show FOV Circle",
				description = "Displays the aimbot radius",
				callback = L_1_.setShowFOV
			},
			{
				kind = "slider",
				name = "FOV Size",
				description = "Target area size",
				max = 300,
				default = 20,
				callback = L_1_.setAimbotFOV
			},
			{
				kind = "premiumSlider",
				name = "Aimbot Smoothness",
				description = "100=Instant, 1=Slow",
				max = 100,
				default = 1,
				callback = L_1_.setAimbotSmoothness
			},
			{
				kind = "toggle",
				name = "Team Check",
				description = "Ignores teammates",
				callback = L_1_.setAimbotTeamCheck
			},
		},
	},
	AdoptMe = {
		title = "Snowy Hub - Adopt Me Pro+",
		AutoFarm = {
			{
				kind = "premiumToggle",
				name = "Auto Complete Ailments",
				description = "Instantly satisfies player and pet needs",
				callback = L_1_.setAutoFarm
			},
			{
				kind = "toggle",
				name = "Auto Collect Event Currency",
				description = "Automatically collects Gingerbread/Event items",
				callback = L_1_.setAutoCollectEvent
			},
		},
		AutoJobs = {
			{
				kind = "dropdown",
				name = "Select Job",
				description = "Choose which job to automate",
				values = {
					"Pizza Shop",
					"Salon"
				},
				callback = L_1_.setSelectedJob
			},
			{
				kind = "toggle",
				name = "Auto Work Job",
				description = "Automatically works and claims salary",
				callback = L_1_.setAutoJob
			},
		},
		AutoHatchAndBuy = {
			{
				kind = "toggle",
				name = "Auto Hatch Eggs",
				description = "Automatically equips eggs to hatch them",
				callback = L_1_.setAutoHatch
			},
			{
				kind = "button",
				name = "Buy Cracked Egg",
				description = "Purchases a Cracked Egg ($350)",
				callback = L_1_.buyCrackedEgg
			},
		},
		Teleports = {
			{
				kind = "dropdown",
				name = "Select Location",
				description = "Teleport to game locations",
				values = L_53_,
				callback = L_1_.teleportTo
			},
		},
		Movement = {
			{
				kind = "slider",
				name = "Walk Speed",
				description = "Adjust speed",
				max = 300,
				default = 16,
				callback = L_1_.setAdoptMeWalkSpeed
			},
			{
				kind = "toggle",
				name = "Lock Walk Speed",
				description = "Force speed value",
				callback = L_1_.setWalkSpeedLock
			},
		},
		UtilityAndPerformance = {
			{
				kind = "premiumToggle",
				name = "Disable 3D Rendering",
				description = "Saves resources",
				callback = L_1_.setDisable3D
			},
			{
				kind = "premiumToggle",
				name = "Anti-AFK",
				description = "Prevents idle kicks",
				callback = L_1_.setAdoptMeAntiAFK
			},
			{
				kind = "label",
				name = "Snowy Hub - Adopt Me Pro+"
			},
		},
	},
}

local L_58_ = false

function L_1_.start(L_195_arg0)
	if L_195_arg0 ~= nil then
		L_16_ = L_195_arg0
	end
	if L_58_ then
		return L_1_
	end
	L_58_ = true

	L_13_.PlayerModifierLoop = L_4_.RenderStepped:Connect(function()
		pcall(L_23_func)
	end)
	L_4_.RenderStepped:Connect(L_39_func)

	task.spawn(L_49_func)
	task.spawn(L_50_func)
	task.spawn(L_51_func)
	task.spawn(L_52_func)
	L_4_.RenderStepped:Connect(L_57_func)
	return L_1_
end

return L_1_
