local L_1_ = {}

L_1_.Metadata = {
	hubName = "Snowy Studios",
	versionLabel = "SNOWY HUB v6.0",
	discord = "https://discord.gg/getsnowy",
	forcedGame = "Pet Sim 99",
	externalPS99Url = "https://raw.githubusercontent.com/Kurbywtww/snowy/refs/heads/main/99.lua",
}

L_1_.SUPPORTED_GAMES = {
	{
		name = "BedWars",
		icon = "🛏",
		aliases = {
			"bedwars",
			"bed wars"
		},
		placeIds = {
			6872265039,
			6872274481
		},
		features = 69,
		img = "rbxassetid://6034281798"
	},
	{
		name = "BedWars",
		icon = "🛏",
		aliases = {
			"bedwars",
			"bed wars"
		},
		placeIds = {
			6872265039,
			6872274481
		},
		features = 69,
		img = "rbxassetid://6034281798"
	},
	{
		name = "Taxi Boss",
		icon = "🚕",
		aliases = {
			"taxi boss",
			"taxiboss",
			"taxi"
		},
		placeIds = {
			7305309231
		},
		features = 40,
		img = "rbxassetid://6034281798"
	},
	{
		name = "BloxStrike",
		icon = "🎯",
		aliases = {
			"bloxstrike",
			"blox strike"
		},
		placeIds = {
			114234929420007
		},
		features = 45,
		img = "rbxassetid://6034281798"
	},
	{
		name = "Anime Expeditions",
		icon = "⚡",
		aliases = {
			"anime expeditions",
			"expeditions",
			"anime expedition"
		},
		placeIds = {
			84515722934860
		},
		features = 40,
		img = "rbxassetid://6034281798"
	},
	{
		name = "+1 Pickaxe Swing Escape",
		icon = "⛏",
		aliases = {
			"+1 pickaxe swing escape",
			"pickaxe swing escape",
			"pickaxe escape",
			"pickaxe swing",
			"pickaxe"
		},
		placeIds = {
			82554996468034
		},
		features = 20,
		img = "rbxassetid://6034281798"
	},
	{
		name = "Animal Hospital",
		icon = "🏥",
		aliases = {
			"animal hospital",
			"anomaly hospital",
			"hospital"
		},
		placeIds = {
			78515283254292
		},
		features = 15,
		img = "rbxassetid://6034281798"
	},
	{
		name = "Merge a Nuke",
		icon = "💣",
		aliases = {
			"merge a nuke",
			"merge a nuke!",
			"nuke tycoon",
			"merge nuke"
		},
		placeIds = {
			128784467030899,
			136423403372990
		},
		features = 15,
		img = "rbxassetid://6034281798"
	},
	{
		name = "Arsenal",
		icon = "🎯",
		placeIds = {
			286090429,
			2133507413
		},
		features = 20,
		img = "rbxassetid://6034281798"
	},
	{
		name = "Jujutsu Shenanigans",
		icon = "⚡",
		aliases = {
			"jujutsu shenanigans",
			"jujutsu",
			"shenanigans"
		},
		placeIds = {
			9391468976
		},
		universeIds = {
			3508322461
		},
		features = 15,
		img = "rbxassetid://6034281798"
	},
	{
		name = "Abyss",
		icon = "🌊",
		placeIds = {
			8841631016,
			6499213745
		},
		features = 22,
		img = "rbxassetid://6034281798"
	},
	{
		name = "Jailbreak",
		icon = "🚨",
		placeIds = {
			606849621
		},
		features = 50,
		img = "rbxassetid://6034281798"
	},
	{
		name = "Tsunami",
		icon = "🌊",
		placeIds = {
			2456517837,
			7456917583
		},
		features = 30,
		img = "rbxassetid://6034281798"
	},
	{
		name = "Sniper Duels",
		icon = "🎯",
		placeIds = {
			2957674229,
			3519873232,
			109397169461300
		},
		features = 12,
		img = "rbxassetid://6034281798"
	},
	{
		name = "Swing Obby",
		icon = "🎢",
		placeIds = {
			5334680521
		},
		features = 10,
		img = "rbxassetid://6034281798"
	},
	{
		name = "Brookhaven",
		icon = "🏠",
		placeIds = {
			4924922222
		},
		features = 15,
		img = "rbxassetid://6034281798"
	},
	{
		name = "99 Nights",
		icon = "🌙",
		placeIds = {
			13271790403,
			14502339080
		},
		features = 28,
		img = "rbxassetid://6034281798"
	},
	{
		name = "Blox Fruits",
		icon = "🍎",
		aliases = {
			"blox fruits",
			"blox fruit",
			"bloxfruits"
		},
		placeIds = {
			2753915549,
			4442272183,
			7449423635
		},
		features = 18,
		img = "rbxassetid://6034281798"
	},
	{
		name = "Pet Sim 99",
		icon = "🐾",
		aliases = {
			"pet simulator 99",
			"pet sim 99",
			"petsim99"
		},
		placeIds = {
			8737899170,
			15532244896,
			15588347101
		},
		universeIds = {
			3317771874
		},
		features = 15,
		img = "rbxassetid://6034281798"
	},
	{
		name = "Bee Swarm",
		icon = "🐝",
		placeIds = {
			1537690962
		},
		features = 12,
		img = "rbxassetid://6034281798"
	},
	{
		name = "SAB",
		icon = "🤖",
		aliases = {
			"steal a brainrot",
			"sab"
		},
		placeIds = {
			18668065096,
			1234567890,
			10495922230,
			109983668079237
		},
		universeIds = {
			109983668079237
		},
		features = 24,
		img = "rbxassetid://6034281798"
	},
	{
		name = "Ultimate Battlegrounds",
		icon = "🔪",
		placeIds = {
			11815767793
		},
		features = 18,
		img = "rbxassetid://6034281798"
	},
	{
		name = "Strongest Battlegrounds",
		icon = "🔥",
		placeIds = {
			10495922230
		},
		features = 15,
		img = "rbxassetid://6034281798"
	},
	{
		name = "Heroes Battlegrounds",
		icon = "🦸",
		placeIds = {
			13076380114
		},
		features = 16,
		img = "rbxassetid://6034281798"
	},
	{
		name = "Legend Battlegrounds",
		icon = "🗡",
		placeIds = {
			15269951959
		},
		features = 18,
		img = "rbxassetid://6034281798"
	},
	{
		name = "Jump for Brainrots",
		icon = "🧠",
		placeIds = {
			139299356663913
		},
		features = 12,
		img = "rbxassetid://6034281798"
	},
	{
		name = "+1 Jump Brainrot",
		icon = "👟",
		placeIds = {
			121192350097093
		},
		features = 15,
		img = "rbxassetid://6034281798"
	},
	{
		name = "Grab Ores!",
		icon = "⛏",
		placeIds = {
			82806856224736
		},
		features = 45,
		img = "rbxassetid://6034281798"
	},
	{
		name = "Murderers VS Sheriffs",
		icon = "🔪",
		placeIds = {
			135856908115931
		},
		features = 22,
		img = "rbxassetid://6034281798"
	},
	{
		name = "Sailor Piece",
		icon = "⚓",
		aliases = {
			"sailor piece",
			"sailor peace"
		},
		placeIds = {
			77747658251236
		},
		features = 38,
		img = "rbxassetid://6034281798"
	},
	{
		name = "MM2",
		icon = "🗡",
		aliases = {
			"murder mystery 2",
			"mm2"
		},
		placeIds = {
			142823291,
			80005698042109
		},
		features = 40,
		img = "rbxassetid://6034281798"
	},
	{
		name = "Kick a Lucky Block",
		icon = "🍀",
		aliases = {
			"kick a lucky block",
			"lucky block",
			"kick lucky"
		},
		placeIds = {
			16955097151,
			89469502395769
		},
		universeIds = {
			89469502395769
		},
		features = 30,
		img = "rbxassetid://6034281798"
	},
	{
		name = "Rivals",
		icon = "🔫",
		aliases = {
			"rivals",
			"rivals fps",
			"matchmaking"
		},
		placeIds = {
			17625359962,
			14721849686,
			117398147513099
		},
		universeIds = {
			6035872082
		},
		features = 22,
		img = "rbxassetid://6034281798"
	},
	{
		name = "Speed Keyboard Escape",
		icon = "⌨",
		aliases = {
			"speed keyboard escape",
			"keyboard escape",
			"1 speed keyboard escape",
			"escape candy chocolate",
			"1-speed-keyboard-escape",
			"keyboard"
		},
		placeIds = {
			95082159892680
		},
		features = 16,
		img = "rbxassetid://6034281798"
	},
	{
		name = "Speed Monkey Escape",
		icon = "🐒",
		aliases = {
			"speed monkey escape",
			"monkey escape",
			"1 speed monkey escape",
			"monkey"
		},
		placeIds = {
			114697347887839
		},
		features = 20,
		img = "rbxassetid://6034281798"
	},
	{
		name = "Sell Lemons",
		icon = "🍋",
		aliases = {
			"sell lemons",
			"lemon tycoon",
			"lemons"
		},
		placeIds = {
			79268393072444
		},
		features = 14,
		img = "rbxassetid://6034281798"
	},
	{
		name = "Demonology",
		icon = "👻",
		aliases = {
			"demonology",
			"ghost hunter",
			"demon"
		},
		placeIds = {
			18199615050
		},
		features = 12,
		img = "rbxassetid://6034281798"
	},
	{
		name = "Grow a Garden 2",
		icon = "🌱",
		aliases = {
			"grow a garden 2",
			"grow a garden",
			"gag2",
			"gag 2"
		},
		placeIds = {
			97598239454123,
			1588579651,
			126884695634066
		},
		universeIds = {
			7436755782
		},
		features = 25,
		img = "rbxassetid://6034281798"
	},
	{
		name = "Welcome to Bloxburg",
		icon = "🏠",
		aliases = {
			"welcome to bloxburg",
			"bloxburg"
		},
		placeIds = {
			185655149
		},
		features = 16,
		img = "rbxassetid://6034281798"
	},
	{
		name = "Adopt Me",
		icon = "🐶",
		aliases = {
			"adopt me",
			"adoptme"
		},
		placeIds = {
			920587237
		},
		features = 12,
		img = "rbxassetid://6034281798"
	},
	{
		name = "Dandy's World",
		icon = "🎨",
		aliases = {
			"dandys world",
			"dandy",
			"dandys"
		},
		placeIds = {
			16267229903
		},
		features = 10,
		img = "rbxassetid://6034281798"
	},
	{
		name = "Blade Ball",
		icon = "🔪",
		aliases = {
			"blade ball",
			"bladeball",
			"bb"
		},
		placeIds = {
			13772394625,
			14777999650,
			15182888200
		},
		features = 25,
		img = "rbxassetid://6034281798"
	},
	{
		name = "KAT",
		icon = "🔪",
		placeIds = {
			621129760
		},
		universeIds = {
			228028122
		},
		features = 11,
		img = "rbxassetid://6034281798"
	},
	{
		name = "One Scope",
		icon = "🎯",
		placeIds = {
			135648408848758
		},
		features = 7,
		img = "rbxassetid://6034281798"
	},
	{
		name = "Da Hood",
		icon = "🏠",
		aliases = {
			"da hood",
			"dahood",
			"dh"
		},
		placeIds = {
			2788229376,
			105305881594005,
			98343466176190,
			93778920465645,
			129449254792324,
			122120252103378,
			110917236678062,
			130879446158509
		},
		features = 120,
		img = "rbxassetid://6034281798"
	},
	{
		name = "Evade",
		icon = "🏃",
		aliases = {
			"evade",
			"rise"
		},
		placeIds = {
			9872472334
		},
		features = 45,
		img = "rbxassetid://6034281798"
	},
	{
		name = "Bridge Duel",
		icon = "🗡",
		aliases = {
			"bridge duel",
			"bridge duels",
			"uoro"
		},
		placeIds = {
			139566161526375
		},
		features = 35,
		img = "rbxassetid://6034281798"
	},
	{
		name = "Drain the Lake",
		icon = "💧",
		aliases = {
			"drain the lake",
			"drain lake"
		},
		placeIds = {
			138381251771774
		},
		universeIds = {
			10267363348
		},
		features = 9,
		img = "rbxassetid://6034281798"
	},
	{
		name = "Prison Life",
		icon = "🚨",
		aliases = {
			"prison life",
			"prison"
		},
		placeIds = {
			155615604
		},
		universeIds = {
			73885730
		},
		features = 9,
		img = "rbxassetid://6034281798"
	},
	{
		name = "Fish It",
		icon = "🐟",
		aliases = {
			"fish it",
			"fisch",
			"fishit"
		},
		placeIds = {
			121864768012064,
			16732694052,
			17445763782
		},
		features = 25,
		img = "rbxassetid://6034281798"
	},
	{
		name = "Forsaken",
		icon = "💀",
		aliases = {
			"forsaken"
		},
		placeIds = {
			18687417158
		},
		features = 20,
		img = "rbxassetid://6034281798"
	},
	{
		name = "Volley Ball Legends",
		icon = "🏐",
		aliases = {
			"volley ball legends",
			"volleyball legends",
			"volleyball",
			"volley ball"
		},
		placeIds = {
			73956553001240
		},
		features = 20,
		img = "rbxassetid://6034281798"
	},
}

L_1_.Theme = {
	WindowWidth = 720,
	WindowHeight = 520,
	HeaderHeight = 48,
	TabBarHeight = 44,
	BannerHeight = 62,
	Radius = 24,
	RadiusSm = 16,
	RadiusXs = 12,
	RadiusPill = 999,
	BgPrimary = Color3.fromRGB(18, 24, 64),
	BgSecondary = Color3.fromRGB(24, 32, 85),
	BgCard = Color3.fromRGB(35, 45, 110),
	BgCardHover = Color3.fromRGB(45, 60, 140),
	BgCardActive = Color3.fromRGB(40, 65, 160),
	BgHeader = Color3.fromRGB(14, 18, 50),
	BgInput = Color3.fromRGB(20, 28, 70),
	BgTabBar = Color3.fromRGB(20, 28, 70),
	Accent = Color3.fromRGB(85, 213, 254),
	AccentBright = Color3.fromRGB(135, 235, 255),
	AccentDark = Color3.fromRGB(50, 170, 220),
	AccentDim = Color3.fromRGB(30, 90, 130),
	AccentGlow = Color3.fromRGB(180, 240, 255),
	AccentSoft = Color3.fromRGB(100, 200, 255),
	Premium = Color3.fromRGB(255, 200, 50),
	PremiumDark = Color3.fromRGB(180, 130, 20),
	PremiumDim = Color3.fromRGB(50, 40, 10),
	BannerBg = Color3.fromRGB(15, 45, 100),
	BannerActive = Color3.fromRGB(25, 70, 150),
	TextPrimary = Color3.fromRGB(230, 245, 255),
	TextSecondary = Color3.fromRGB(160, 190, 230),
	TextMuted = Color3.fromRGB(80, 110, 160),
	TextDim = Color3.fromRGB(50, 70, 110),
	Border = Color3.fromRGB(30, 45, 100),
	BorderHi = Color3.fromRGB(60, 100, 220),
	Success = Color3.fromRGB(50, 220, 120),
	Error = Color3.fromRGB(255, 55, 75),
	Warning = Color3.fromRGB(255, 180, 50),
}

local function L_2_func(L_13_arg0)
	for L_14_forvar0, L_15_forvar1 in ipairs(L_1_.SUPPORTED_GAMES) do
		if L_15_forvar1.name == L_13_arg0 then
			return L_15_forvar1
		end
	end
	return nil
end

local function L_3_func(L_16_arg0, L_17_arg1)
	if not L_16_arg0 then
		return false
	end
	for L_18_forvar0, L_19_forvar1 in ipairs(L_16_arg0) do
		if L_19_forvar1 == L_17_arg1 then
			return true
		end
	end
	return false
end

function L_1_.detectGameBeforeOverride()
	local L_20_ = game.PlaceId
	local L_21_ = game.GameId
	for L_27_forvar0, L_28_forvar1 in ipairs(L_1_.SUPPORTED_GAMES) do
		if L_3_func(L_28_forvar1.placeIds, L_20_) or L_3_func(L_28_forvar1.universeIds, L_21_) then
			return L_28_forvar1
		end
	end
	local L_22_, L_23_ = pcall(function()
		return game:GetService("MarketplaceService"):GetProductInfo(L_20_)
	end)
	if L_22_ and L_23_ and L_23_.Name then
		local L_29_ = L_23_.Name:lower()
		for L_30_forvar0, L_31_forvar1 in ipairs(L_1_.SUPPORTED_GAMES) do
			if L_29_:find(L_31_forvar1.name:lower(), 1, true) then
				return L_31_forvar1
			end
			for L_32_forvar0, L_33_forvar1 in ipairs(L_31_forvar1.aliases) do
				if L_29_:find(L_33_forvar1, 1, true) then
					return L_31_forvar1
				end
			end
		end
	end
	local L_24_ = game:GetService("ReplicatedStorage")
	local L_25_ = game:GetService("Players")
	local L_26_ = L_25_.LocalPlayer
	if L_24_:FindFirstChild("TS")
        or (L_26_ and L_26_:FindFirstChild("PlayerScripts") and L_26_.PlayerScripts:FindFirstChild("TS")) then
		return L_2_func("BedWars")
	end
	if L_24_:FindFirstChild("Remotes") or L_24_:FindFirstChild("CommF_") then
		return L_2_func("Blox Fruits")
	end
	if L_24_:FindFirstChild("events") or L_24_:FindFirstChild("reels") then
		return L_2_func("Fish It")
	end
	if L_24_:FindFirstChild("Forsaken") or workspace:FindFirstChild("Forsaken") then
		return L_2_func("Forsaken")
	end
	if L_24_:FindFirstChild("Volleyball") or L_24_:FindFirstChild("Volley") then
		return L_2_func("Volley Ball Legends")
	end
	if L_24_:FindFirstChild("Brainrots") then
		return L_2_func("SAB")
	end
	if workspace:FindFirstChild("Pickaxes") then
		return L_2_func("+1 Pickaxe Swing Escape")
	end
	return nil
end

function L_1_.forceBuildGameDescriptor(L_34_arg0)
	return {
		name = "Pet Sim 99",
		features = 0,
	}
end

local function L_4_func()
	local L_35_ = function()
	end
	local L_36_
	L_36_ = {
		NewToggle = L_35_,
		NewButton = L_35_,
		NewSlider = L_35_,
		NewDropdown = L_35_,
		NewLabel = L_35_,
		NewPremiumToggle = L_35_,
		NewPremiumButton = L_35_,
		NewPremiumSlider = L_35_,
		NewPremiumDropdown = L_35_,
	}
	L_36_.NewSection = function()
		return L_36_
	end
	return L_36_
end

function L_1_.gameTabFacade(L_37_arg0, L_38_arg1, L_39_arg2, L_40_arg3)
	if not L_37_arg0 or L_37_arg0.name:lower() ~= L_39_arg2:lower() then
		return L_4_func()
	end
	return L_38_arg1(L_39_arg2, L_40_arg3)
end

function L_1_.loadPetSim99External(L_41_arg0)
	local L_42_ = game:HttpGet(L_1_.Metadata.externalPS99Url)
	local L_43_ = loadstring(L_42_)
	L_43_()
	L_41_arg0:Notify("PS99 Loaded", "Snowy automation is starting up!", 5)
end

function L_1_.runActiveApplication(L_44_arg0)
	local L_45_ = getgenv()
	L_45_._premTag = tostring
	L_45_._isPremiumUser = function()
		return true
	end
	local L_46_ = L_1_.detectGameBeforeOverride()
	local L_47_ = L_1_.forceBuildGameDescriptor(L_46_)
	local L_48_ = {
		HubName = "Snowy Studios",
		AccentColor = Color3.fromRGB(0, 162, 255),
	}
	L_45_.Window = L_44_arg0.Kavo.CreateLib(L_48_.HubName, "Midnight")
	L_45_.__SnowyPayloadReady = {
		nonce = L_45_.__SnowyLaunchNonce,
		game = L_47_.name or "Unknown",
		ui = true,
		at = os.clock(),
	}
	print("[SnowyHub] Payload UI ready: " .. tostring(L_45_.__SnowyPayloadReady.game))
	L_45_.SnowyLib = L_44_arg0.Notifier
	L_45_.Kavo = L_44_arg0.Kavo
	L_45_.notify = L_44_arg0.notify
	L_45_.gameTab = function(L_50_arg0, L_51_arg1)
		return L_1_.gameTabFacade(L_47_, L_44_arg0.realGameTabFactory, L_50_arg0, L_51_arg1)
	end
	L_45_.HomeTab = L_4_func()
	L_45_.PlayerTab = L_4_func()
	L_45_.VisualTab = L_4_func()
	L_45_.UtilTab = L_4_func()
	L_45_.AimbotTab = L_4_func()
	L_45_.SettingsTab = L_4_func()
	local L_49_ = L_45_.HomeTab:NewSection()
	L_45_.HomeSec = L_49_
	L_45_.PlayerSection = L_49_
	L_45_.VisualSection = L_49_
	L_45_.UtilSection = L_49_
	L_45_.AimbotSection = L_49_
	L_45_.UISec = L_49_
	L_45_.InfoSec = L_49_
	L_45_.ScriptSec = L_49_
	if L_47_.name == "Pet Sim 99" then
		local L_52_ = L_45_.gameTab("Pet Sim 99", "Pet Sim 99 ")
		local L_53_ = L_52_:NewSection("Snowy Automation")
		L_53_:NewButton(
            "Load Snowy Pet Sim 99 Script",
            "Executes the professional Snowy automation for PS99",
            function()
			L_1_.loadPetSim99External(L_44_arg0.Notifier)
		end
        )
		L_53_:NewLabel("Note: This will load the full external script.")
	end
	return {
		detectedBeforeOverride = L_46_,
		activeDescriptor = L_47_,
	}
end

local L_5_ = {}
L_1_.DeadFeatures = L_5_

function L_5_.disconnectPlayerModifierLoop()
	local L_54_ = getgenv()
	if L_54_.PlayerModifierLoop then
		L_54_.PlayerModifierLoop:Disconnect()
	end
end

local function L_6_func(L_55_arg0)
	L_55_arg0:SetStateEnabled(Enum.HumanoidStateType.Dead, false)
end

function L_5_.applyGodMode()
	local L_56_ = game.Players.LocalPlayer.Character
	if not L_56_ then
		return
	end
	local L_57_ = L_56_:FindFirstChild("Humanoid")
	if not L_57_ then
		return
	end
	if not L_56_:FindFirstChild("HumanoidRootPart") then
		return
	end
	if not getgenv().GodModeEnabled then
		return
	end
	if L_57_.MaxHealth ~= math.huge then
		L_57_.MaxHealth = math.huge
	end
	if L_57_.Health ~= math.huge then
		L_57_.Health = math.huge
	end
	pcall(L_6_func, L_57_)
end

function L_5_.setWalkSpeed(L_58_arg0)
	local L_59_ = getgenv()
	L_59_.WalkSpeedValue = L_58_arg0
	local L_60_ = game.Players.LocalPlayer.Character
	local L_61_ = L_60_ and L_60_:FindFirstChild("Humanoid")
	if L_61_ then
		L_61_.WalkSpeed = L_58_arg0
	end
end

function L_5_.setJumpPower(L_62_arg0)
	local L_63_ = getgenv()
	L_63_.JumpPowerValue = L_62_arg0
	local L_64_ = game.Players.LocalPlayer.Character
	local L_65_ = L_64_ and L_64_:FindFirstChild("Humanoid")
	if L_65_ then
		L_65_.JumpPower = L_62_arg0
	end
end

function L_5_.setGravity(L_66_arg0)
	game.Workspace.Gravity = L_66_arg0
end

function L_5_.restoreHumanoid()
	local L_67_ = game.Players.LocalPlayer.Character
	local L_68_ = L_67_ and L_67_:FindFirstChild("Humanoid")
	if not L_68_ then
		return
	end
	L_68_.MaxHealth = 100
	L_68_.Health = 100
	L_68_:SetStateEnabled(Enum.HumanoidStateType.Dead, true)
end

function L_5_.setGodMode(L_69_arg0)
	getgenv().GodModeEnabled = L_69_arg0
	if not L_69_arg0 then
		pcall(L_5_.restoreHumanoid)
	end
end

local L_7_ = true
local L_8_ = nil

local function L_9_func()
	if L_7_ ~= false then
		return
	end
	local L_70_ = game.Players.LocalPlayer.Character
	if not L_70_ then
		return
	end
	for L_71_forvar0, L_72_forvar1 in pairs(L_70_:GetDescendants()) do
		if L_72_forvar1:IsA("BasePart") and L_72_forvar1.CanCollide and L_72_forvar1.Name ~= _G.floatName then
			L_72_forvar1.CanCollide = false
		end
	end
	wait(0.21)
end

function L_5_.startNoclip()
	L_7_ = false
	L_8_ = game:GetService("RunService").Stepped:Connect(L_9_func)
end

function L_5_.stopNoclip()
	if L_8_ then
		L_8_:Disconnect()
		L_8_ = nil
	end
	L_7_ = true
end

function L_5_.setNoclip(L_73_arg0)
	if L_73_arg0 then
		L_5_.startNoclip()
	else
		L_5_.stopNoclip()
	end
end

local L_10_ = false
function L_5_.setInfiniteJump(L_74_arg0)
	L_10_ = L_74_arg0
	game:GetService("UserInputService").JumpRequest:Connect(function()
		if not L_10_ then
			return
		end
		local L_75_ = game.Players.LocalPlayer.Character
		local L_76_ = L_75_ and L_75_:FindFirstChild("Humanoid")
		if L_76_ then
			L_76_:ChangeState("Jumping")
		end
	end)
end

function L_5_.setCameraFov(L_77_arg0)
	game.Workspace.CurrentCamera.FieldOfView = L_77_arg0
end

function L_5_.setFullbright(L_78_arg0)
	local L_79_ = game:GetService("Lighting")
	if L_78_arg0 then
		L_79_.Ambient = Color3.new(1, 1, 1)
		L_79_.ColorShift_Bottom = Color3.new(1, 1, 1)
		L_79_.ColorShift_Top = Color3.new(1, 1, 1)
		L_79_.GlobalShadows = false
	else
		L_79_.Ambient = Color3.fromRGB(128, 128, 128)
		L_79_.GlobalShadows = true
	end
end

local L_11_ = {}
function L_5_.setPlayerEsp(L_80_arg0, L_81_arg1)
	if L_80_arg0 then
		for L_82_forvar0, L_83_forvar1 in pairs(game.Players:GetPlayers()) do
			if L_83_forvar1 ~= game.Players.LocalPlayer and L_83_forvar1.Character then
				local L_84_ = Instance.new("Highlight")
				L_84_.Parent = L_83_forvar1.Character
				L_84_.FillColor = L_81_arg1.AccentColor
				L_84_.OutlineColor = L_81_arg1.SecondaryColor
				L_84_.FillTransparency = 0.5
				table.insert(L_11_, L_84_)
			end
		end
	else
		for L_85_forvar0, L_86_forvar1 in pairs(L_11_) do
			if L_86_forvar1.Parent then
				L_86_forvar1:Destroy()
			end
		end
		L_11_ = {}
	end
end

local function L_12_func(L_87_arg0)
	local L_88_ = L_87_arg0.Character and L_87_arg0.Character:FindFirstChild("HumanoidRootPart")
	if not L_88_ then
		return
	end
	L_88_.Size = Vector3.new(_G.HeadSize, _G.HeadSize, _G.HeadSize)
	L_88_.Transparency = 0.7
	L_88_.BrickColor = BrickColor.new("Really blue")
	L_88_.Material = "Neon"
	L_88_.CanCollide = false
end

function L_5_.startHitboxLoop(L_89_arg0)
	_G.HeadSize = L_89_arg0
	_G.Disabled = true
	game:GetService("RunService").RenderStepped:connect(function()
		if not _G.Disabled then
			return
		end
		for L_90_forvar0, L_91_forvar1 in pairs(game.Players:GetPlayers()) do
			if L_91_forvar1.Name ~= game.Players.LocalPlayer.Name then
				pcall(L_12_func, L_91_forvar1)
			end
		end
	end)
end

function L_5_.giveBtools()
	local L_92_ = game.Players.LocalPlayer.Backpack
	Instance.new("HopperBin", L_92_).BinType = "Clone"
	Instance.new("HopperBin", L_92_).BinType = "Hammer"
	Instance.new("HopperBin", L_92_).BinType = "Grab"
end

function L_5_.teleportToRandomPlayer()
	local L_93_ = game.Players:GetPlayers()
	if #L_93_ <= 1 then
		return
	end
	local L_94_
	repeat
		L_94_ = L_93_[math.random(1, #L_93_)]
	until L_94_.Name ~= game.Players.LocalPlayer.Name
	local L_95_ = L_94_.Character and L_94_.Character:FindFirstChild("HumanoidRootPart")
	local L_96_ = game.Players.LocalPlayer.Character
	local L_97_ = L_96_ and L_96_:FindFirstChild("HumanoidRootPart")
	if L_95_ and L_97_ then
		L_97_.CFrame = L_95_.CFrame * CFrame.new(0, 0, 3)
	end
end

function L_5_.rejoinServer()
	game:GetService("TeleportService"):TeleportToPlaceInstance(
        game.PlaceId,
        game.JobId,
        game.Players.LocalPlayer
    )
end

function L_5_.serverHop()
	local L_98_ = game:GetService("HttpService")
	local L_99_ = game:GetService("TeleportService")
	local L_100_ = game.PlaceId
	local L_101_ = "https://games.roblox.com/v1/games/"
        .. tostring(L_100_)
        .. "/servers/Public?sortOrder=Asc&limit=100"
	local L_102_ = nil
	local L_103_ = nil
	repeat
		local L_104_ = L_102_ and ("&cursor=" .. L_102_) or ""
		local L_105_ = L_98_:JSONDecode(game:HttpGet(L_101_ .. L_104_))
		L_103_ = L_105_.data[1]
		L_102_ = L_105_.nextPageCursor
	until L_103_
	L_99_:TeleportToPlaceInstance(L_100_, L_103_.id, game.Players.LocalPlayer)
end

function L_5_.setAntiAfk(L_106_arg0)
	local L_107_ = getconnections or get_signal_cons
	if not L_106_arg0 or not L_107_ then
		return
	end
	for L_108_forvar0, L_109_forvar1 in pairs(L_107_(game.Players.LocalPlayer.Idled)) do
		if L_109_forvar1.Disable then
			L_109_forvar1:Disable()
		elseif L_109_forvar1.Disconnect then
			L_109_forvar1:Disconnect()
		end
	end
end

L_5_.AimbotSettings = {
	Enabled = false,
	ShowFOV = false,
	FOVRadius = 80,
	Smoothness = 0.5,
	TeamCheck = true,
	TargetPart = "Head",
}

function L_5_.getAimbotTarget(L_110_arg0)
	L_110_arg0 = L_110_arg0 or L_5_.AimbotSettings
	local L_111_ = game:GetService("UserInputService")
	local L_112_ = L_111_:GetMouseLocation()
	local L_113_ = L_110_arg0.FOVRadius
	local L_114_ = nil
	for L_115_forvar0, L_116_forvar1 in pairs(game.Players:GetPlayers()) do
		if L_116_forvar1 ~= game.Players.LocalPlayer and L_116_forvar1.Character then
			local L_117_ = L_116_forvar1.Character:FindFirstChild(L_110_arg0.TargetPart)
			local L_118_ = L_116_forvar1.Character:FindFirstChild("Humanoid")
			if L_117_ and L_118_ and L_118_.Health > 0 then
				local L_119_, L_120_ = game.Workspace.CurrentCamera:WorldToViewportPoint(L_117_.Position)
				if L_120_ then
					local L_121_ = (Vector2.new(L_119_.X, L_119_.Y) - L_112_).Magnitude
					if L_121_ < L_113_ then
						L_113_ = L_121_
						L_114_ = L_116_forvar1
					end
				end
			end
		end
	end
	return L_114_
end

function L_5_.aimbotRenderStep(L_122_arg0, L_123_arg1)
	L_122_arg0 = L_122_arg0 or L_5_.AimbotSettings
	local L_124_ = game:GetService("UserInputService")
	if L_122_arg0.ShowFOV then
		L_123_arg1.Position = L_124_:GetMouseLocation()
		L_123_arg1.Radius = L_122_arg0.FOVRadius
		L_123_arg1.Visible = true
	else
		L_123_arg1.Visible = false
	end
	if not L_122_arg0.Enabled then
		return
	end
	if not L_124_:IsMouseButtonPressed(Enum.UserInputType.MouseButton2) then
		return
	end
	local L_125_ = L_5_.getAimbotTarget(L_122_arg0)
	local L_126_ = L_125_ and L_125_.Character and L_125_.Character:FindFirstChild(L_122_arg0.TargetPart)
	if not L_126_ then
		return
	end
	local L_127_ = game.Workspace.CurrentCamera
	L_127_.CFrame = L_127_.CFrame:Lerp(
        CFrame.new(L_127_.CFrame.Position, L_126_.Position),
        L_122_arg0.Smoothness
    )
end

function L_5_.setAimbotEnabled(L_128_arg0)
	L_5_.AimbotSettings.Enabled = L_128_arg0
end
function L_5_.setShowFov(L_129_arg0)
	L_5_.AimbotSettings.ShowFOV = L_129_arg0
end
function L_5_.setFovRadius(L_130_arg0)
	L_5_.AimbotSettings.FOVRadius = L_130_arg0
end
function L_5_.setAimbotSmoothness(L_131_arg0)
	L_5_.AimbotSettings.Smoothness = L_131_arg0 / 100
end
function L_5_.setTeamCheck(L_132_arg0)
	L_5_.AimbotSettings.TeamCheck = L_132_arg0
end

function L_5_.copyDiscord(L_133_arg0)
	if setclipboard then
		setclipboard(L_1_.Metadata.discord)
		L_133_arg0("Copied!", "Discord link copied.", 3, false)
	end
end

function L_5_.registerDeadGenericUi(L_134_arg0, L_135_arg1, L_136_arg2)
	L_134_arg0.WalkSpeedValue = 16
	L_134_arg0.JumpPowerValue = 50
	L_134_arg0.GodModeEnabled = false
	if L_134_arg0.PlayerModifierLoop then
		pcall(L_5_.disconnectPlayerModifierLoop)
		L_134_arg0.PlayerModifierLoop = nil
	end
	L_134_arg0.PlayerModifierLoop = game:GetService("RunService").RenderStepped:Connect(function()
		pcall(L_5_.applyGodMode)
	end)
	L_134_arg0.PlayerSection:NewSlider("WalkSpeed", "Changes player speed", 250, 16, L_5_.setWalkSpeed)
	L_134_arg0.PlayerSection:NewSlider("JumpPower", "Changes jump height", 250, 50, L_5_.setJumpPower)
	L_134_arg0.PlayerSection:NewSlider("Gravity", "Changes world gravity", 196, 0, L_5_.setGravity)
	L_134_arg0.PlayerSection:NewPremiumToggle("God Mode", "Instantly regenerates health", L_5_.setGodMode)
	L_134_arg0.PlayerSection:NewPremiumToggle("Noclip", "Walk through objects and walls", L_5_.setNoclip)
	L_134_arg0.PlayerSection:NewPremiumToggle("Infinite Jump", "Jump in mid-air", L_5_.setInfiniteJump)
	L_134_arg0.VisualSection:NewSlider("Field of View", "Change camera FOV", 120, 70, L_5_.setCameraFov)
	L_134_arg0.VisualSection:NewToggle("Fullbright", "Removes shadows and darkness", L_5_.setFullbright)
	L_134_arg0.VisualSection:NewPremiumToggle("Player ESP", "Highlights all players through walls", function(L_139_arg0)
		L_5_.setPlayerEsp(L_139_arg0, L_135_arg1)
	end)
	L_134_arg0.VisualSection:NewPremiumSlider("Hitbox Expander", "Make enemies easier to hit", 20, 2, L_5_.startHitboxLoop)
	L_134_arg0.UtilSection:NewButton("Give Btools", "Gives building tools to inventory", L_5_.giveBtools)
	L_134_arg0.UtilSection:NewPremiumButton("Teleport to Random Player", "TPs you to a random user", L_5_.teleportToRandomPlayer)
	L_134_arg0.UtilSection:NewButton("Rejoin Server", "Rejoins the same server", L_5_.rejoinServer)
	L_134_arg0.UtilSection:NewPremiumButton("Server Hop", "Joins a random new server", L_5_.serverHop)
	L_134_arg0.UtilSection:NewToggle("Anti-AFK", "Prevents Roblox disconnects", L_5_.setAntiAfk)
	local L_137_ = L_5_.AimbotSettings
	local L_138_ = Drawing.new("Circle")
	L_138_.Position = Vector2.new(
        game.Workspace.CurrentCamera.ViewportSize.X / 2,
        game.Workspace.CurrentCamera.ViewportSize.Y / 2
    )
	L_138_.Radius = L_137_.FOVRadius
	L_138_.Filled = false
	L_138_.Color = Color3.fromRGB(255, 255, 255)
	L_138_.Visible = false
	L_138_.Thickness = 1
	game:GetService("RunService").RenderStepped:Connect(function()
		L_5_.aimbotRenderStep(L_137_, L_138_)
	end)
	L_134_arg0.AimbotSection:NewPremiumToggle("Enable Aimbot (Right Click)", "Locks onto targets in FOV", L_5_.setAimbotEnabled)
	L_134_arg0.AimbotSection:NewToggle("Show FOV Circle", "Displays the aimbot radius", L_5_.setShowFov)
	L_134_arg0.AimbotSection:NewSlider("FOV Size", "Target area size", 300, 20, L_5_.setFovRadius)
	L_134_arg0.AimbotSection:NewPremiumSlider("Aimbot Smoothness", "100=Instant, 1=Slow", 100, 1, L_5_.setAimbotSmoothness)
	L_134_arg0.AimbotSection:NewToggle("Team Check", "Ignores teammates", L_5_.setTeamCheck)
	L_134_arg0.InfoSec:NewLabel("Right-click = Hold to aim (Aimbot)")
	L_134_arg0.InfoSec:NewLabel("Drag title bar to move")
	L_134_arg0.InfoSec:NewLabel("discord.gg/getsnowy")
	L_134_arg0.InfoSec:NewButton("Copy Discord", "Copy invite link", function()
		L_5_.copyDiscord(L_136_arg2)
	end)

end

return L_1_
