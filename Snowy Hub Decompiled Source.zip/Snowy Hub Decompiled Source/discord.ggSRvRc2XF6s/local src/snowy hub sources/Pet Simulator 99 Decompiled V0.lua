local F = {}

function F.pgvm_entry(...)
    local r0, r1

    r0 = F.snowy_hub_main()
    do return r0, ... end
end

function F.fn_001_function(arg1)
    local r0, r1, r2
    r1 = tostring(arg1)
    do return r1 end
end

function F.fn_002_function()
    local r0
    do return true end
end

function F.fn_003_function(arg1, arg2)
    local r0, r1, r2, r3, r4, r5, r6, r7, r8, r9
    r2 = typeof(arg2)
    r9 = (r2 == "Instance")
    if r9 then

    end
    do return nil end

    r2 = Instance.new("UICorner")
    r6 = tonumber(arg1)
    r5 = r6
    if r5 then

    end

    r3 = UDim.new(0, 8)
    r2.CornerRadius = r3
    r2.Parent = arg2
    do return r2 end
end

function F.fn_004_function(arg1, arg2, arg3)
    local r0, r1, r2, r3, r4, r5, r6, r7, r8, r9
    r3 = typeof(arg3)
    r9 = (r3 == "Instance")
    if r9 then

    end
    do return nil end

    r3 = Instance.new("UIStroke")
    r4 = arg1
    if r4 then

    end
    r4 = Color3.fromRGB(85, 213, 254)

    r3.Color = r4
    r5 = tonumber(arg2)
    r4 = r5
    if r4 then

    end

    r3.Thickness = 1
    r3.Parent = arg3
    do return r3 end
end

function F.fn_005_gradient(arg1, arg2, arg3, arg4)
    local r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12
    r4 = typeof(arg1)
    r12 = (r4 == "Instance")
    if r12 then

    end
    do return nil end

    r4 = Instance.new("UIGradient")
    r6 = arg2
    if r6 then

    end
    r6 = Color3.fromRGB(18, 24, 64)

    r7 = arg3
    if r7 then

    end
    r7 = arg2
    if r7 then

    end
    r7 = Color3.fromRGB(24, 32, 85)

    r5 = ColorSequence.new(r6, r7)
    r4.Color = r5
    r6 = tonumber(arg4)
    r5 = r6
    if r5 then

    end

    r4.Rotation = 0
    r4.Parent = arg1
    do return r4 end
end

function F.fn_006_shadow(arg1)
    local r0, r1, r2, r3, r4, r5, r6, r7, r8
    r1 = typeof(arg1)
    r8 = (r1 == "Instance")
    if r8 then

    end
    do return nil end

    r1 = Instance.new("ImageLabel")
    r1.Name = "SnowyShadow"
    r1.BackgroundTransparency = 1
    r2 = UDim2.new(0, -18, 0, -18)
    r1.Position = r2
    r2 = UDim2.new(1, 36, 1, 36)
    r1.Size = r2
    r1.Image = "rbxassetid://6015897843"
    r2 = Color3.new(0, 0, 0)
    r1.ImageColor3 = r2
    r1.ImageTransparency = 0.42
    r1.ScaleType = Enum.ScaleType.Slice
    r2 = Rect.new(49, 49, 450, 450)
    r1.SliceCenter = r2
    r1.ZIndex = 0
    r1.Parent = arg1
    do return r1 end
end

function F.fn_007_tween(arg1, arg2, arg3, arg4, arg5)
    local r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13
    r5 = typeof(arg1)
    r13 = (r5 == "Instance")
    if not r13 then

    end
    r5 = type(arg2)
    r13 = (r5 == "table")
    if r13 then

    end

    do return nil end

    r5 = game:GetService("TweenService")
    r10 = tonumber(arg3)
    r9 = r10
    if r9 then

    end

    r10 = arg4
    if r10 then

    end

    r11 = arg5
    if r11 then

    end

    r8 = TweenInfo.new(0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
    r5 = r5:Create(arg1, r8, arg2)
    r5:Play()
    do return r5 end
end

function F.fn_008_function()
    local r0
    do return end
end

function F.fn_009_function()
    local r0, r1, r2
    do return _G[up0] end
end

function F.fn_010_function()
    local r0, r1, r2
    r1 = getgenv()
    do return r1[up0] end
end

function F.fn_011_function(arg1)
    local r0, r1, r2, r3, r4, r5, r6, r7
    r1, r2 = pcall(F.fn_009_function)
    if not r1 then

    end
    if not r2 then

    end
    do return r2 end

    r3, r4 = pcall(F.fn_010_function)
    if not r3 then

    end
    if not r4 then

    end
    do return r4 end

    r6 = _ENV
    if r6 then

    end

    r5 = rawget(_G, arg1)
    do return r5 end
end

function F.fn_012_function()
    local r0, r1, r2
    r0 = getgenv()
    r0[up0] = up1
    do return end
end

function F.fn_013_function(arg1, arg2)
    local r0, r1, r2, r3
    pcall(F.fn_012_function)
    do return end
end

function F.fn_014_function()
    local r0, r1, r2
    r0 = getgenv()
    r2 = getgenv()
    r1 = r2.__realGetRawMT
    if r1 then

    end
    r1 = up0("getrawmetatable")

    r0.__realGetRawMT = r1
    r0 = getgenv()
    r2 = getgenv()
    r1 = r2.__realHookNamecall
    if r1 then

    end
    r1 = up0("hookmetamethod")

    r0.__realHookNamecall = r1
    r0 = getgenv()
    r2 = getgenv()
    r1 = r2.__realNewCClosure
    if r1 then

    end
    r1 = up0("newcclosure")

    r0.__realNewCClosure = r1
    do return end
end

function F.fn_015_function()
    local r0
    do return end
end

function F.fn_016_function()
    local r0
    do return F.fn_015_function end
end

function F.fn_017_function()
    local r0
    do return end
end

function F.fn_018_function(arg1)
    local r0, r1, r2, r3, r4
    r2 = {}
    r3 = {}
    r3.__index = F.fn_016_function
    r3.__newindex = F.fn_017_function
    r1 = setmetatable(r2, r3)
    do return r1 end
end

function F.fn_019_function()
    local r0
    do return nil end
end

function F.fn_020_function(arg1, arg2, arg3)
    local r0, r1, r2, r3
    do return F.fn_019_function end
end

function F.fn_021_function()
    local r0
    do return end
end

function F.fn_022_function(arg1, arg2)
    local r0, r1
    do return arg1 end
end

function F.fn_023_function(arg1)
    local r0, r1, r2, r3
    Clipboard:set(arg1)
    do return end
end

function F.fn_024_function()
    local r0
    do return end
end

function F.fn_025_function()
    local r0, r1, r2, r3, r4, r5, r6, r7
    up0:SendMouseButtonEvent(0, 0, 0, true, game, 1)
    do return end
end

function F.fn_026_function()
    local r0, r1
    pcall(F.fn_025_function)
    do return end
end

function F.fn_027_function()
    local r0, r1, r2, r3, r4, r5, r6, r7
    up0:SendMouseButtonEvent(0, 0, 0, false, game, 1)
    do return end
end

function F.fn_028_function()
    local r0, r1
    pcall(F.fn_027_function)
    do return end
end

function F.fn_029_function(arg1)
    local r0
    do return end
end

function F.fn_030_function(arg1)
    local r0
    do return end
end

function F.fn_031_function()
    local r0
    do return end
end

function F.fn_032_function()
    local r0
    do return end
end

function F.fn_033_function()
    local r0
    do return F.fn_032_function end
end

function F.fn_034_function(arg1)
    local r0, r1, r2, r3, r4
    r2 = {}
    r2.Visible = false
    r2.Remove = F.fn_029_function
    r2.Destroy = F.fn_030_function
    r3 = {}
    r3.__newindex = F.fn_031_function
    r3.__index = F.fn_033_function
    r1 = setmetatable(r2, r3)
    do return r1 end
end

function F.fn_035_function()
    local r0, r1
    r0 = getgenv()
    r0.Drawing = up0
    do return end
end

function F.fn_036_function()
    local r0, r1
    r0 = request
    if not r0 then

    end
    r0 = getgenv()
    r0.request = request

    do return end
end

function F.fn_037_function()
    local r0
    do return end
end

function F.fn_038_function()
    local r0, r1, r2
    r0 = game:GetService("CoreGui")
    do return r0 end
end

function F.fn_039_function()
    local r0, r1
    do return "Unknown", "0.0.0" end
end

function F.fn_040_function()
    local r0, r1, r2, r3, r4
    r0 = setclipboard
    if r0 then

    end
    r0 = toclipboard
    if not r0 then

    end
    setclipboard = toclipboard

    r0 = Clipboard
    if not r0 then

    end
    r0 = Clipboard.set
    if not r0 then

    end
    setclipboard = F.fn_023_function

    setclipboard = F.fn_024_function

    r0 = mouse1press
    if r0 then

    end
    r0 = game:GetService("VirtualInputManager")
    r1 = getgenv()
    r1.mouse1press = F.fn_026_function
    r1 = getgenv()
    r1.mouse1release = F.fn_028_function

    r1 = getgenv()
    r0 = r1.Drawing
    if not r0 then

    end
    r2 = getgenv()
    r0 = type(r2.Drawing)
    r4 = (r0 == "table")
    if not r4 then

    end
    r2 = getgenv()
    r0 = r2.Drawing.new
    if r0 then

    end

    r0 = {}
    r0.new = F.fn_034_function
    r1 = {}
    r1.UI = 0
    r1.System = 1
    r1.Plex = 2
    r1.Monospace = 3
    r0.Fonts = r1
    pcall(F.fn_035_function)

    r0 = request
    if r0 then

    end
    r0 = syn
    if not r0 then

    end
    r0 = syn.request
    if not r0 then

    end
    request = syn.request

    r0 = http
    if not r0 then

    end
    r0 = http.request
    if not r0 then

    end
    request = http.request

    r0 = http_request
    if not r0 then

    end
    request = http_request

    pcall(F.fn_036_function)
    r0 = queue_on_teleport
    if r0 then

    end
    r0 = getgenv()
    r0.queue_on_teleport = F.fn_037_function

    r0 = gethui
    if r0 then

    end
    r0 = getgenv()
    r0.gethui = F.fn_038_function

    r0 = identifyexecutor
    if r0 then

    end
    r0 = getgenv()
    r0.identifyexecutor = F.fn_039_function

    do return end
end

function F.fn_041_function()
    local r0, r1, r2
    r0 = game:GetService("MarketplaceService")
    r0 = r0:GetProductInfo(up0)
    if not r0 then

    end
    r1 = r0.Name
    if not r1 then

    end
    r1 = r0.Name:lower()
    up1 = r1

    do return end
end

function F.fn_042_function()
    local r0, r1, r2, r3, r4, r5, r6, r7, r8
    r0 = game:GetService("ReplicatedStorage")
    r1 = r0:FindFirstChild("TS")
    if r1 then

    end
    r1 = lplr.PlayerScripts:FindFirstChild("TS")
    if not r1 then

    end

    r1, r2, r3 = ipairs(up0)

    r8 = (r5.name == "BedWars")
    if not r8 then

    end
    up1 = r5
    do return end

    do return end

    r1 = r0:FindFirstChild("TS")
    if r1 then

    end
    r1 = lplr.PlayerScripts:FindFirstChild("TS")
    if not r1 then

    end

    r1, r2, r3 = ipairs(up0)

    r8 = (r5.name == "BedWars")
    if not r8 then

    end
    up1 = r5
    do return end

    do return end

    r1 = r0:FindFirstChild("Remotes")
    if not r1 then

    end
    r1 = r0.Remotes:FindFirstChild("CommF_")
    if not r1 then

    end
    r1, r2, r3 = ipairs(up0)

    r8 = (r5.name == "Blox Fruits")
    if not r8 then

    end
    up1 = r5
    do return end

    do return end

    r1 = r0:FindFirstChild("events")
    if not r1 then

    end
    r1 = r0.events:FindFirstChild("reels")
    if not r1 then

    end
    r1, r2, r3 = ipairs(up0)

    r8 = (r5.name == "Fish It")
    if not r8 then

    end
    up1 = r5
    do return end

    do return end

    r1 = r0:FindFirstChild("Forsaken")
    if r1 then

    end
    r1 = workspace:FindFirstChild("Forsaken")
    if not r1 then

    end

    r1, r2, r3 = ipairs(up0)

    r8 = (r5.name == "Forsaken")
    if not r8 then

    end
    up1 = r5
    do return end

    do return end

    r1 = r0:FindFirstChild("Volleyball")
    if r1 then

    end
    r1 = workspace:FindFirstChild("Volleyball")
    if r1 then

    end
    r1 = r0:FindFirstChild("Volley")
    if not r1 then

    end

    r1, r2, r3 = ipairs(up0)

    r8 = (r5.name == "Volley Ball Legends")
    if not r8 then

    end
    up1 = r5
    do return end

    do return end

    r1 = r0:FindFirstChild("Brainrots")
    if r1 then

    end
    r1 = workspace:FindFirstChild("Brainrots")
    if not r1 then

    end

    r1, r2, r3 = ipairs(up0)

    r8 = (r5.name == "SAB")
    if not r8 then

    end
    up1 = r5
    do return end

    do return end

    r1 = workspace:FindFirstChild("Pickaxes")
    if not r1 then

    end
    r1, r2, r3 = ipairs(up0)

    r8 = (r5.name == "+1 Pickaxe Swing Escape")
    if not r8 then

    end
    up1 = r5
    do return end

    do return end
end

function F.fn_043_function()
    local r0, r1
    up0:Destroy()
    do return end
end

function F.fn_044_function()
    local r0, r1, r2, r3, r4, r5, r6, r7
    r2 = {}
    r3 = UDim2.new(1, 380, 1, -100)
    r2.Position = r3
    r2.BackgroundTransparency = 0.5
    tw(up0, r2, 0.4)
    task.wait(0.45)
    pcall(F.fn_043_function)
    do return end
end

function F.fn_045_function(arg1, arg2, arg3, arg4)
    local r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16
    r2 = arg3
    if r2 then

    end

    r4 = up0
    if r4 then

    end
    r4 = Instance.new("ScreenGui", up1)
    r4.Name = "SnowyNotifs"
    r4.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
    up0 = r4

    r4 = Instance.new("Frame", up0)
    r5 = UDim2.new(0, 340, 0, 80)
    r4.Size = r5
    r5 = UDim2.new(1, 360, 1, -100)
    r4.Position = r5
    r4.BackgroundColor3 = up2.BgCard
    r4.ZIndex = 500
    corner(up2.RadiusSm, r4)
    r3 = arg4
    if not r3 then

    end
    r6 = up2.Premium
    if r6 then

    end

    stroke(up2.Accent, 1.5, r4)
    gradient(r4, up2.BgSecondary, up2.BgCard, 90)
    r5 = Instance.new("Frame", r4)
    r6 = UDim2.new(0, 5, 0.6, 0)
    r5.Size = r6
    r6 = UDim2.new(0, 10, 0.2, 0)
    r5.Position = r6
    if not r3 then

    end
    r6 = up2.Premium
    if r6 then

    end

    r5.BackgroundColor3 = up2.Accent
    r5.BorderSizePixel = 0
    r5.ZIndex = 501
    corner(up2.RadiusPill, r5)
    r6 = Instance.new("TextLabel", r4)
    r7 = UDim2.new(1, -40, 0, 22)
    r6.Size = r7
    r7 = UDim2.new(0, 24, 0, 10)
    r6.Position = r7
    r6.BackgroundTransparency = 1
    r6.Text = arg1
    if not r3 then

    end
    r7 = up2.Premium
    if r7 then

    end

    r6.TextColor3 = up2.AccentBright
    r6.Font = Enum.Font.GothamBlack
    r6.TextSize = 14
    r6.ZIndex = 501
    r6.TextXAlignment = Enum.TextXAlignment.Left
    r7 = Instance.new("TextLabel", r4)
    r8 = UDim2.new(1, -40, 0, 36)
    r7.Size = r8
    r8 = UDim2.new(0, 24, 0, 34)
    r7.Position = r8
    r7.BackgroundTransparency = 1
    r7.Text = arg2
    r7.TextColor3 = up2.TextSecondary
    r7.Font = Enum.Font.Gotham
    r7.TextSize = 12
    r7.TextWrapped = true
    r7.ZIndex = 501
    r7.TextXAlignment = Enum.TextXAlignment.Left
    r8 = Instance.new("Frame", r4)
    r9 = UDim2.new(1, -20, 0, 3)
    r8.Size = r9
    r9 = UDim2.new(0, 10, 1, -8)
    r8.Position = r9
    if not r3 then

    end
    r9 = up2.Premium
    if r9 then

    end

    r8.BackgroundColor3 = up2.Accent
    r8.ZIndex = 501
    corner(up2.RadiusPill, r8)
    r11 = {}
    r12 = UDim2.new(0, 0, 0, 3)
    r11.Size = r12
    tw(r8, r11, 4, Enum.EasingStyle.Linear)
    r11 = {}
    r12 = UDim2.new(1, -360, 1, -100)
    r11.Position = r12
    tw(r4, r11, 0.5, Enum.EasingStyle.Back)
    task.delay(4, F.fn_044_function)
    do return end
end

function F.fn_046_function(arg1, arg2, arg3, arg4, arg5)
    local r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10
    task.spawn(up0, arg2, arg3, arg4, arg5)
    do return end
end

function F.fn_047_function()
    local r0, r1
    up0:Destroy()
    do return end
end

function F.fn_048_function()
    local r0, r1
    syn.protect_gui(up0)
    up0.Parent = up1
    up2 = true
    do return end
end

function F.fn_049_function()
    local r0, r1
    r1 = gethui()
    up0.Parent = r1
    up1 = true
    do return end
end

function F.fn_050_function()
    local r0, r1
    r1 = get_hidden_gui()
    up0.Parent = r1
    up1 = true
    do return end
end

function F.fn_051_function()
    local r0, r1, r2, r3
    r2 = up1:IsStudio()
    if not r2 then

    end
    r1 = up2.PlayerGui
    if r1 then

    end

    up0.Parent = up3
    do return end
end

function F.fn_052_function()
    local r0, r1, r2, r3, r4, r5, r6, r7
    r2 = {}
    r3 = UDim2.new(1, -52, 0, 46)
    r2.Size = r3
    tw(up0, r2, 0.15)
    do return end
end

function F.fn_053_function()
    local r0, r1, r2, r3, r4, r5, r6, r7
    r2 = {}
    r3 = UDim2.new(1, -60, 0, 44)
    r2.Size = r3
    tw(up0, r2, 0.15)
    do return end
end

function F.fn_054_function()
    local r0, r1
    r0 = setclipboard
    if not r0 then

    end
    setclipboard("https://getsnowy.xyz/pricing")
    up0 = true

    do return end
end

function F.fn_055_function()
    local r0, r1
    toclipboard("https://getsnowy.xyz/pricing")
    up0 = true
    do return end
end

function F.fn_056_function()
    local r0, r1, r2, r3, r4
    up0.Text = "✦  " .. "getsnowy.xyz/pricing" .. "    •  Click to copy"
    r2 = {}
    r2.BackgroundColor3 = up1.Premium
    tw(up0, r2, 0.2)
    do return end
end

function F.fn_057_function()
    local r0, r1
    pcall(F.fn_056_function)
    do return end
end

function F.fn_058_function()
    local r0, r1, r2, r3, r4, r5
    pcall(F.fn_054_function)
    r0 = false
    if r0 then

    end
    pcall(F.fn_055_function)

    if not r0 then

    end
    r2 = "✔  Copied  " .. "https://getsnowy.xyz/pricing"
    if r2 then

    end

    up0.Text = "Visit " .. "getsnowy.xyz/pricing"
    r3 = {}
    r3.BackgroundColor3 = up1.Success
    tw(up0, r3, 0.15)
    task.delay(1.4, F.fn_057_function)

    do return end
end

function F.fn_059_function()
    local r0, r1
    up0:Destroy()
    do return end
end

function F.fn_060_function()
    local r0, r1, r2, r3
    pcall(F.fn_059_function)
    r3 = (up1 == up0)
    if not r3 then

    end
    up1 = nil

    do return end
end

function F.fn_061_function()
    local r0, r1, r2, r3, r4, r5
    r0 = up0.Parent
    if r0 then

    end
    do return end

    r2 = {}
    r2.BackgroundTransparency = 1
    tw(up1, r2, 0.2)
    r2 = {}
    r3 = UDim2.fromOffset(0, 0)
    r2.Size = r3
    tw(up2, r2, 0.18, Enum.EasingStyle.Back, Enum.EasingDirection.In)
    task.delay(0.22, F.fn_060_function)
    do return end
end

function F.fn_062_function()
    local r0, r1, r2, r3
    r3 = (up0 == up1)
    if not r3 then

    end
    up2()

    do return end
end

function F.fn_063_function()
    local r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20, r21, r22, r23, r24, r25, r26, r27
    r1 = up0
    if not r1 then

    end
    r0 = tostring(up0)
    if r0 then

    end

    r1 = Instance.new("ScreenGui")
    r1.Name = "SnowyPremiumModal"
    r1.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
    r1.IgnoreGuiInset = true
    r1.ResetOnSpawn = false
    r1.DisplayOrder = 2147483647
    r3 = up1:IsStudio()
    if r3 then

    end
    r3 = syn
    if not r3 then

    end
    r3 = syn.protect_gui
    if not r3 then

    end
    pcall(F.fn_048_function)

    r2 = false
    if r2 then

    end
    r3 = gethui
    if not r3 then

    end
    pcall(F.fn_049_function)

    if r2 then

    end
    r3 = get_hidden_gui
    if not r3 then

    end
    pcall(F.fn_050_function)

    if r2 then

    end
    pcall(F.fn_051_function)

    up4 = r1
    r3 = Instance.new("TextButton", r1)
    r3.Name = "Backdrop"
    r4 = UDim2.fromScale(1, 1)
    r3.Size = r4
    r4 = Color3.new(0, 0, 0)
    r3.BackgroundColor3 = r4
    r3.BackgroundTransparency = 1
    r3.BorderSizePixel = 0
    r3.AutoButtonColor = false
    r3.Text = ""
    r3.ZIndex = 9000
    r6 = {}
    r6.BackgroundTransparency = 0.45
    tw(r3, r6, 0.2)
    r4 = Instance.new("Frame", r1)
    r4.Name = "Card"
    r5 = Vector2.new(0.5, 0.5)
    r4.AnchorPoint = r5
    r5 = UDim2.fromScale(0.5, 0.5)
    r4.Position = r5
    r5 = UDim2.fromOffset(0, 0)
    r4.Size = r5
    r4.BackgroundColor3 = up5.BgCard
    r4.BorderSizePixel = 0
    r4.ZIndex = 9010
    r4.ClipsDescendants = true
    corner(18, r4)
    stroke(up5.Premium, 2, r4)
    gradient(r4, up5.BgSecondary, up5.BgCard, 125)
    shadow(r4)
    r5 = Instance.new("Frame", r4)
    r6 = UDim2.new(1, 0, 0, 4)
    r5.Size = r6
    r5.BackgroundColor3 = up5.Premium
    r5.BorderSizePixel = 0
    r5.ZIndex = 9011
    gradient(r5, up5.PremiumDark, up5.Premium, 0)
    r6 = Instance.new("Frame", r4)
    r6.Name = "LockContainer"
    r7 = UDim2.new(0, 68, 0, 68)
    r6.Size = r7
    r7 = UDim2.new(0.5, -34, 0, 28)
    r6.Position = r7
    r6.BackgroundColor3 = up5.PremiumDim
    r6.BorderSizePixel = 0
    r6.ZIndex = 9012
    corner(999, r6)
    stroke(up5.Premium, 2, r6)
    r7 = Instance.new("Frame", r6)
    r7.Name = "Shackle"
    r8 = UDim2.new(0, 26, 0, 26)
    r7.Size = r8
    r8 = UDim2.new(0.5, -13, 0.5, -23)
    r7.Position = r8
    r7.BackgroundTransparency = 1
    r7.ZIndex = 9013
    r8 = Instance.new("UICorner", r7)
    r9 = UDim.new(0.5, 0)
    r8.CornerRadius = r9
    r9 = Instance.new("UIStroke", r7)
    r9.Color = up5.Premium
    r9.Thickness = 3
    r9.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
    r10 = Instance.new("Frame", r6)
    r10.Name = "Body"
    r11 = UDim2.new(0, 34, 0, 26)
    r10.Size = r11
    r11 = UDim2.new(0.5, -17, 0.5, -7)
    r10.Position = r11
    r10.BackgroundColor3 = up5.Premium
    r10.BorderSizePixel = 0
    r10.ZIndex = 9014
    r11 = Instance.new("UICorner", r10)
    r12 = UDim.new(0, 4)
    r11.CornerRadius = r12
    r12 = Instance.new("Frame", r10)
    r12.Name = "KeyholeCircle"
    r13 = UDim2.new(0, 6, 0, 6)
    r12.Size = r13
    r13 = UDim2.new(0.5, -3, 0.3, 0)
    r12.Position = r13
    r12.BackgroundColor3 = up5.BgCard
    r12.BorderSizePixel = 0
    r12.ZIndex = 9015
    r13 = Instance.new("UICorner", r12)
    r14 = UDim.new(1, 0)
    r13.CornerRadius = r14
    r14 = Instance.new("Frame", r10)
    r14.Name = "KeyholeLine"
    r15 = UDim2.new(0, 3, 0, 8)
    r14.Size = r15
    r15 = UDim2.new(0.5, -1.5, 0.3, 4)
    r14.Position = r15
    r14.BackgroundColor3 = up5.BgCard
    r14.BorderSizePixel = 0
    r14.ZIndex = 9015
    r15 = Instance.new("UICorner", r14)
    r16 = UDim.new(0, 1)
    r15.CornerRadius = r16
    r16 = Instance.new("TextLabel", r4)
    r17 = UDim2.new(1, -30, 0, 28)
    r16.Size = r17
    r17 = UDim2.new(0, 15, 0, 106)
    r16.Position = r17
    r16.BackgroundTransparency = 1
    r16.Text = "PREMIUM FEATURE"
    r16.TextColor3 = up5.Premium
    r16.Font = Enum.Font.GothamBlack
    r16.TextSize = 20
    r16.ZIndex = 9012
    r17 = Instance.new("TextLabel", r4)
    r18 = UDim2.new(1, -30, 0, 22)
    r17.Size = r18
    r18 = UDim2.new(0, 15, 0, 136)
    r17.Position = r18
    r17.BackgroundTransparency = 1
    r17.Text = "“" .. "That feature" .. "” is locked."
    r17.TextColor3 = up5.TextPrimary
    r17.Font = Enum.Font.GothamSemibold
    r17.TextSize = 14
    r17.TextTruncate = Enum.TextTruncate.AtEnd
    r17.ZIndex = 9012
    r18 = Instance.new("TextLabel", r4)
    r19 = UDim2.new(1, -30, 0, 20)
    r18.Size = r19
    r19 = UDim2.new(0, 15, 0, 160)
    r18.Position = r19
    r18.BackgroundTransparency = 1
    r18.Text = "Unlock every Snowy Premium feature at"
    r18.TextColor3 = up5.TextSecondary
    r18.Font = Enum.Font.Gotham
    r18.TextSize = 12
    r18.ZIndex = 9012
    r19 = Instance.new("TextButton", r4)
    r20 = UDim2.new(1, -60, 0, 44)
    r19.Size = r20
    r20 = UDim2.new(0, 30, 0, 188)
    r19.Position = r20
    r19.BackgroundColor3 = up5.Premium
    r19.BorderSizePixel = 0
    r19.AutoButtonColor = false
    r19.Text = "✦  " .. "getsnowy.xyz/pricing" .. "    •  Click to copy"
    r20 = Color3.fromRGB(20, 15, 0)
    r19.TextColor3 = r20
    r19.Font = Enum.Font.GothamBlack
    r19.TextSize = 15
    r19.ZIndex = 9012
    corner(10, r19)
    stroke(up5.PremiumDark, 1, r19)
    gradient(r19, up5.Premium, up5.PremiumDark, 90)
    r19.MouseEnter:Connect(F.fn_052_function)
    r19.MouseLeave:Connect(F.fn_053_function)
    r19.Activated:Connect(F.fn_058_function)
    r20 = Instance.new("TextButton", r4)
    r21 = UDim2.new(1, -60, 0, 32)
    r20.Size = r21
    r21 = UDim2.new(0, 30, 0, 242)
    r20.Position = r21
    r20.BackgroundColor3 = up5.BgInput
    r20.BorderSizePixel = 0
    r20.AutoButtonColor = false
    r20.Text = "Maybe later"
    r20.TextColor3 = up5.TextSecondary
    r20.Font = Enum.Font.GothamMedium
    r20.TextSize = 13
    r20.ZIndex = 9012
    corner(8, r20)
    stroke(up5.Border, 1, r20)
    r20.Activated:Connect(F.fn_061_function)
    r3.Activated:Connect(F.fn_061_function)
    r22 = UDim2.fromOffset(0, 0)
    r4.Size = r22
    r24 = {}
    r25 = UDim2.fromOffset(400, 300)
    r24.Size = r25
    tw(r4, r24, 0.35, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
    task.delay(7, F.fn_062_function)

    do return end
end

function F.fn_064_notify(arg1)
    local r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13
    r1 = tick()
    r13 = ((r1 - up0) < 1.2)
    if not r13 then

    end
    do return end

    up0 = r1
    r2 = up1
    if not r2 then

    end
    pcall(F.fn_047_function)
    up1 = nil

    r2, r3 = pcall(F.fn_063_function)
    if r2 then

    end
    r0 = arg1
    if not r0 then

    end
    r8 = tostring(r0)
    r4 = "'" .. r8 .. "'"
    if r4 then

    end

    up6:Notify("✦  PREMIUM LOCKED", "That feature" .. " is locked to Snowy Premium. Upgrade at " .. "getsnowy.xyz/pricing", 5, true)

    do return end
end

function F.fn_065_function(arg1, arg2)
    local r0, r1, r2, r3, r4, r5, r6, r7, r8, r9
    r2 = Instance.new(arg1)

    r9 = (r6 == "Parent")
    if r9 then

    end
    r2[r6] = r7

    r2.Parent = arg2.Parent
    do return r2 end
end

function F.fn_066_function(arg1, arg2, arg3)
    local r0, r1, r2, r3, r4, r5, r6, r7, r8, r9
    r6 = TweenInfo.new(arg2, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
    r3 = up0:Create(arg1, r6, arg3)
    r3:Play()
    do return end
end

function F.fn_067_function(arg1)
    local r0, r1, r2, r3, r4
    r4 = (arg1.UserInputType == Enum.UserInputType.MouseButton1)
    if r4 then

    end
    r4 = (arg1.UserInputType == Enum.UserInputType.Touch)
    if not r4 then

    end

    r1 = up0._blockDrag
    if r1 then

    end
    up1 = true
    up2 = false
    up3 = arg1.Position
    up4 = up5.Position

    do return end
end

function F.fn_068_function(arg1)
    local r0, r1, r2, r3, r4
    r4 = (arg1.UserInputType == Enum.UserInputType.MouseButton1)
    if r4 then

    end
    r4 = (arg1.UserInputType == Enum.UserInputType.Touch)
    if not r4 then

    end

    up0 = false

    do return end
end

function F.fn_069_function(arg1)
    local r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12
    r1 = up0
    if not r1 then

    end
    r12 = (arg1.UserInputType == Enum.UserInputType.MouseMovement)
    if r12 then

    end
    r12 = (arg1.UserInputType == Enum.UserInputType.Touch)
    if not r12 then

    end

    r2 = up2
    if r2 then

    end
    r2 = math.abs((arg1.Position - up1).X)
    r12 = (4 <= r2)
    if r12 then

    end
    r2 = math.abs((arg1.Position - up1).Y)
    r12 = (4 <= r2)
    if not r12 then

    end

    up2 = true

    r2 = up2
    if not r2 then

    end
    r3 = UDim2.new(up4.X.Scale, (up4.X.Offset + (arg1.Position - up1).X), up4.Y.Scale, (up4.Y.Offset + (arg1.Position - up1).Y))
    up3.Position = r3

    do return end
end

function F.fn_070_function()
    local r0, r1
    up0 = false
    do return up0 end
end

function F.fn_071_function(arg1, arg2, arg3)
    local r0, r1, r2, r3, r4, r5, r6, r7, r8, r9
    r2 = arg3
    if r2 then

    end

    arg2.InputBegan:Connect(F.fn_067_function)
    arg2.InputEnded:Connect(F.fn_068_function)
    up1.InputChanged:Connect(F.fn_069_function)

    do return F.fn_070_function end
end

function F.fn_072_function(arg1, arg2)
    local r0, r1, r2, r3
    r2 = up0[arg2]
    if r2 then

    end

    do return up0.home end
end

function F.fn_073_function()
    local r0, r1, r2, r3
    r0 = game:GetService("HttpService")
    r0 = r0:GenerateGUID(false)
    r0 = r0:sub(1, 8)
    do return r0 end
end

function F.fn_074_function()
    local r0, r1
    syn.protect_gui(up0)
    up0.Parent = up1
    up2 = true
    do return end
end

function F.fn_075_function()
    local r0, r1
    r1 = gethui()
    up0.Parent = r1
    up1 = true
    do return end
end

function F.fn_076_function()
    local r0, r1
    r1 = get_hidden_gui()
    up0.Parent = r1
    up1 = true
    do return end
end

function F.fn_077_function()
    local r0, r1, r2
    r1 = getgenv()
    r1[up0]:Destroy()
    do return end
end

function F.fn_078_function()
    local r0, r1, r2
    r0 = up0:IsDescendantOf(game)
    if r0 then

    end
    up1:Cancel()

    do return end
end

function F.fn_079_function()
    local r0, r1, r2, r3, r4, r5, r6
    r0 = TweenInfo.new(2, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut, -1, true)
    r5 = {}
    r5.ImageTransparency = 0.8
    r1 = up0:Create(up1, r0, r5)
    r1:Play()
    up2.AncestryChanged:Connect(F.fn_078_function)
    do return end
end

function F.fn_080_function()
    local r0, r1, r2, r3, r4
    r0, r1 = up0:GetUserThumbnailAsync(up1.UserId, Enum.ThumbnailType.HeadShot, Enum.ThumbnailSize.Size100x100)
    if not r1 then

    end
    up2.Image = r0

    do return end
end

function F.fn_081_function()
    local r0, r1
    pcall(F.fn_080_function)
    do return end
end

function F.fn_082_function()
    local r0, r1
    r0 = up0()
    if r0 then

    end
    up1:Destroy()

    do return end
end

function F.fn_083_function()
    local r0, r1, r2, r3, r4, r5, r6, r7, r8
    r1 = {}
    r1.TextColor3 = up1.Accent
    r5 = TweenInfo.new(0.15, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
    r2 = up2:Create(up0, r5, r1)
    r2:Play()
    do return end
end

function F.fn_084_function()
    local r0, r1, r2, r3, r4, r5, r6, r7, r8
    r1 = {}
    r2 = Color3.new(1, 1, 1)
    r1.TextColor3 = r2
    r5 = TweenInfo.new(0.15, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
    r2 = up1:Create(up0, r5, r1)
    r2:Play()
    do return end
end

function F.fn_085_function()
    local r0, r1, r2, r3, r4, r5, r6, r7, r8
    r1 = {}
    r1.TextColor3 = up1.Error
    r5 = TweenInfo.new(0.15, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
    r2 = up2:Create(up0, r5, r1)
    r2:Play()
    do return end
end

function F.fn_086_function()
    local r0, r1, r2, r3, r4, r5, r6, r7, r8
    r1 = {}
    r2 = Color3.new(1, 1, 1)
    r1.TextColor3 = r2
    r5 = TweenInfo.new(0.15, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
    r2 = up1:Create(up0, r5, r1)
    r2:Play()
    do return end
end

function F.fn_087_function(arg1)
    local r0, r1, r2, r3, r4, r5, r6
    r6 = (arg1.UserInputType == Enum.UserInputType.Touch)
    if r6 then

    end
    r6 = (arg1.UserInputType == Enum.UserInputType.MouseButton1)
    if not r6 then

    end

    r1 = up0()
    if r1 then

    end
    up1.Visible = not (up1.Visible)

    do return end
end

function F.fn_088_function(arg1)
    local r0, r1, r2, r3, r4, r5, r6
    r6 = (arg1.KeyCode == Enum.KeyCode.RightShift)
    if not r6 then

    end
    up0.Visible = not (up0.Visible)

    do return end
end

function F.fn_089_function()
    local r0, r1, r2
    r0 = up0:IsDescendantOf(game)
    if r0 then

    end
    up1:Cancel()

    do return end
end

function F.fn_090_function()
    local r0, r1, r2, r3, r4, r5, r6
    r0 = TweenInfo.new(1.6, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut, -1, true)
    r5 = {}
    r5.ImageTransparency = 0.85
    r1 = up0:Create(up1, r0, r5)
    r1:Play()
    up2.AncestryChanged:Connect(F.fn_089_function)
    do return end
end

function F.fn_091_function()
    local r0, r1, r2, r3, r4, r5, r6, r7, r8
    r0 = up0
    if not r0 then

    end
    do return end

    up0 = true
    up1.Visible = false
    up2.Visible = true
    r1 = UDim2.new(0, 0, 0, 0)
    up2.Size = r1
    r1 = {}
    r2 = UDim2.new(0, 170, 0, 46)
    r1.Size = r2
    r5 = TweenInfo.new(0.35, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
    r2 = up3:Create(up2, r5, r1)
    r2:Play()
    do return end
end

function F.fn_092_function()
    local r0, r1
    up0.Visible = false
    do return end
end

function F.fn_093_function()
    local r0, r1, r2, r3, r4, r5, r6, r7, r8
    r0 = up0
    if r0 then

    end
    do return end

    up0 = false
    r1 = {}
    r2 = UDim2.new(0, 0, 0, 0)
    r1.Size = r2
    r5 = TweenInfo.new(0.25, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
    r2 = up2:Create(up1, r5, r1)
    r2:Play()
    task.delay(0.26, F.fn_092_function)
    up3.Visible = true
    do return end
end

function F.fn_094_function()
    local r0
    r0 = up0()
    if r0 then

    end
    up1()

    do return end
end

function F.fn_095_function(arg1)
    local r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20
    r2, r3 = up0:GetChildren()

    r6 = r5:IsA("ImageButton")
    if not r6 then

    end
    r6 = r5:FindFirstChild("Indicator")
    if not r6 then

    end
    r7 = {}
    r7.BackgroundTransparency = 1
    r11 = TweenInfo.new(0.25, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
    r8 = up1:Create(r5.Indicator, r11, r7)
    r8:Play()

    r6 = r5:FindFirstChild("Icon")
    if not r6 then

    end
    r7 = {}
    r8 = Color3.fromRGB(140, 140, 140)
    r7.ImageColor3 = r8
    r11 = TweenInfo.new(0.25, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
    r8 = up1:Create(r5.Icon, r11, r7)
    r8:Play()

    r7, r8 = r5:GetChildren()

    r11 = r5.Icon:IsA("Frame")
    if not r11 then

    end
    r20 = (r5.Icon.Name == "Indicator")
    if r20 then

    end
    r11 = {}
    r11.BackgroundTransparency = 1
    r15 = TweenInfo.new(0.25, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
    r12 = up1:Create(r5.Icon, r15, r11)
    r12:Play()

    r1 = up2.Current
    if not r1 then

    end

    up2.Current.Btn.Visible = false
    up2.Current.Page.Visible = false

    r2 = {}
    r2.Tab = up3
    up2.Current = r2
    r2 = {}
    r2.ImageColor3 = up5.Accent
    r6 = TweenInfo.new(0.25, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
    r3 = up1:Create(up4, r6, r2)
    r3:Play()
    r2 = {}
    r2.BackgroundTransparency = 0
    r6 = TweenInfo.new(0.25, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
    r3 = up1:Create(up6, r6, r2)
    r3:Play()
    r2 = {}
    r2.BackgroundTransparency = 0.85
    r6 = TweenInfo.new(0.25, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
    r3 = up1:Create(up7, r6, r2)
    r3:Play()

    up7.Btn.Visible = true

    r1 = up3.CurrentST
    if not r1 then

    end
    up3.CurrentST:Select()
    do return end

    r1 = up3.SubTabs[1]
    if not r1 then

    end
    up3.SubTabs[1]:Select()

    do return end
end

function F.fn_096_function()
    local r0, r1
    up0:Select()
    do return end
end

function F.fn_097_function(arg1, arg2)
    local r0, r1, r2
    up0.Visible = arg2
    do return end
end

function F.fn_098_function(arg1)
    local r0, r1, r2, r3, r4, r5, r6, r7, r8, r9
    r1 = up0.CurrentST
    if not r1 then

    end
    up0.CurrentST.Page.Visible = false
    r2 = {}
    r3 = Color3.fromRGB(160, 160, 160)
    r2.TextColor3 = r3
    r6 = TweenInfo.new(0.2, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
    r3 = up1:Create(up0.CurrentST.Btn.Label, r6, r2)
    r3:Play()
    r2 = {}
    r3 = Color3.fromRGB(160, 160, 160)
    r2.ImageColor3 = r3
    r6 = TweenInfo.new(0.2, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
    r3 = up1:Create(up0.CurrentST.Btn.Icon, r6, r2)
    r3:Play()
    r1 = up0.CurrentST.Btn:FindFirstChildOfClass("Frame")
    if not r1 then

    end
    r2 = {}
    r2.BackgroundTransparency = 1
    r6 = TweenInfo.new(0.2, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
    r3 = up1:Create(r1, r6, r2)
    r3:Play()

    up0.CurrentST = up2
    up3.Visible = true
    r2 = {}
    r3 = Color3.new(1, 1, 1)
    r2.TextColor3 = r3
    r6 = TweenInfo.new(0.2, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
    r3 = up1:Create(up4, r6, r2)
    r3:Play()
    r2 = {}
    r2.ImageColor3 = up6.Accent
    r6 = TweenInfo.new(0.2, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
    r3 = up1:Create(up5, r6, r2)
    r3:Play()
    r2 = {}
    r2.BackgroundTransparency = 0
    r6 = TweenInfo.new(0.2, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
    r3 = up1:Create(up7, r6, r2)
    r3:Play()
    do return end
end

function F.fn_099_function()
    local r0, r1
    up0:Select()
    do return end
end

function F.fn_100_function()
    local r0, r1, r2, r3, r4, r5, r6, r7, r8
    r1 = {}
    r3 = up1
    if not r3 then

    end
    r2 = up2.Accent
    if r2 then

    end

    r2 = Color3.fromRGB(35, 35, 35)

    r1.BackgroundColor3 = r2
    r5 = TweenInfo.new(0.2, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
    r2 = up3:Create(up0, r5, r1)
    r2:Play()
    r1 = {}
    r3 = up1
    if not r3 then

    end
    r2 = UDim2.new(1, -16, 0.5, -7)
    if r2 then

    end

    r2 = UDim2.new(0, 2, 0.5, -7)

    r1.Position = r2
    r5 = TweenInfo.new(0.2, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
    r2 = up3:Create(up4, r5, r1)
    r2:Play()
    r1 = {}
    r3 = up1
    if not r3 then

    end
    r2 = up2.Accent
    if r2 then

    end

    r2 = Color3.fromRGB(225, 225, 225)

    r1.TextColor3 = r2
    r5 = TweenInfo.new(0.2, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
    r2 = up3:Create(up5, r5, r1)
    r2:Play()
    r0 = up6
    if not r0 then

    end
    up6(up1)

    do return end
end

function F.fn_101_function(arg1)
    local r0, r1, r2, r3, r4
    r4 = (arg1.UserInputType == Enum.UserInputType.MouseButton1)
    if r4 then

    end
    r4 = (arg1.UserInputType == Enum.UserInputType.Touch)
    if not r4 then

    end

    up0 = not (up0)
    up1()

    do return end
end

function F.fn_102_function(arg1, arg2)
    local r0, r1, r2
    up0 = arg2
    up1()
    do return end
end

function F.fn_103_function(arg1, arg2, arg3, arg4)
    local r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16
    r5 = {}
    r5.Parent = up0
    r6 = Color3.fromRGB(13, 13, 13)
    r5.BackgroundColor3 = r6
    r6 = UDim2.new(1, 0, 0, 42)
    r5.Size = r6
    r6 = Instance.new("Frame")

    r16 = (42 == "Parent")
    if r16 then

    end
    r6[42] = r11

    r6.Parent = r5.Parent
    r5 = {}
    r6 = UDim.new(0, 6)
    r5.CornerRadius = r6
    r5.Parent = r6
    r6 = Instance.new("UICorner")

    r16 = (r10 == "Parent")
    if r16 then

    end
    r6[r10] = r11

    r6.Parent = r5.Parent
    r6 = {}
    r6.Parent = r6
    r6.BackgroundTransparency = 1
    r7 = UDim2.new(0, 12, 0, 0)
    r6.Position = r7
    r7 = UDim2.new(1, -64, 1, 0)
    r6.Size = r7
    r6.Font = "Gotham"
    r6.Text = arg2
    r7 = Color3.fromRGB(225, 225, 225)
    r6.TextColor3 = r7
    r6.TextSize = 14
    r6.TextXAlignment = "Left"
    r7 = Instance.new("TextLabel")

    r16 = (0 == "Parent")
    if r16 then

    end
    r7[0] = r12

    r7.Parent = r6.Parent
    r7 = {}
    r7.Parent = r6
    r8 = Vector2.new(1, 0.5)
    r7.AnchorPoint = r8
    r8 = Color3.fromRGB(35, 35, 35)
    r7.BackgroundColor3 = r8
    r8 = UDim2.new(1, -12, 0.5, 0)
    r7.Position = r8
    r8 = UDim2.new(0, 36, 0, 18)
    r7.Size = r8
    r8 = Instance.new("Frame")

    r16 = (18 == "Parent")
    if r16 then

    end
    r8[18] = r13

    r8.Parent = r7.Parent
    r7 = {}
    r8 = UDim.new(1, 0)
    r7.CornerRadius = r8
    r7.Parent = r8
    r8 = Instance.new("UICorner")

    r16 = (r12 == "Parent")
    if r16 then

    end
    r8[r12] = r13

    r8.Parent = r7.Parent
    r8 = {}
    r8.Parent = r8
    r9 = Color3.new(1, 1, 1)
    r8.BackgroundColor3 = r9
    r9 = UDim2.new(0, 2, 0.5, -7)
    r8.Position = r9
    r9 = UDim2.new(0, 14, 0, 14)
    r8.Size = r9
    r9 = Instance.new("Frame")

    r16 = (14 == "Parent")
    if r16 then

    end
    r9[14] = r14

    r9.Parent = r8.Parent
    r8 = {}
    r9 = UDim.new(1, 0)
    r8.CornerRadius = r9
    r8.Parent = r9
    r9 = Instance.new("UICorner")

    r16 = (r13 == "Parent")
    if r16 then

    end
    r9[r13] = r14

    r9.Parent = r8.Parent
    r8 = arg3
    if r8 then

    end

    r6.InputBegan:Connect(F.fn_101_function)
    F.fn_100_function()
    r10 = {}
    r10.Set = F.fn_102_function

    do return r10 end
end

function F.fn_104_function()
    local r0
    r0 = up0
    if not r0 then

    end
    up0()

    do return end
end

function F.fn_105_function(arg1, arg2, arg3)
    local r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12
    r4 = {}
    r4.Parent = up0
    r5 = Color3.fromRGB(13, 13, 13)
    r4.BackgroundColor3 = r5
    r5 = UDim2.new(1, 0, 0, 42)
    r4.Size = r5
    r4.Text = ""
    r4.AutoButtonColor = false
    r5 = Instance.new("TextButton")

    r12 = (42 == "Parent")
    if r12 then

    end
    r5[42] = r10

    r5.Parent = r4.Parent
    r4 = {}
    r5 = UDim.new(0, 6)
    r4.CornerRadius = r5
    r4.Parent = r5
    r5 = Instance.new("UICorner")

    r12 = (r9 == "Parent")
    if r12 then

    end
    r5[r9] = r10

    r5.Parent = r4.Parent
    r4 = {}
    r4.Parent = r5
    r4.BackgroundTransparency = 1
    r5 = UDim2.new(1, 0, 1, 0)
    r4.Size = r5
    r4.Font = "Gotham"
    r4.Text = arg2
    r5 = Color3.fromRGB(225, 225, 225)
    r4.TextColor3 = r5
    r4.TextSize = 14
    r5 = Instance.new("TextLabel")

    r12 = (0 == "Parent")
    if r12 then

    end
    r5[0] = r10

    r5.Parent = r4.Parent
    r5.Activated:Connect(F.fn_104_function)
    do return r5 end
end

function F.fn_106_function(arg1)
    local r0, r1, r2, r3, r4, r5, r6, r7, r8
    r1 = math.clamp(((arg1.Position.X - up0.AbsolutePosition.X) / up0.AbsoluteSize.X), 0, 1)
    r2 = math.floor((up1 + ((up2 - up1) * r1)))
    r4 = UDim2.new(r1, 0, 1, 0)
    up3.Size = r4
    r4 = tostring(r2)
    up4.Text = r4
    up5(r2)
    do return end
end

function F.fn_107_function(arg1)
    local r0, r1, r2, r3, r4
    r4 = (arg1.UserInputType == Enum.UserInputType.MouseButton1)
    if r4 then

    end
    r4 = (arg1.UserInputType == Enum.UserInputType.Touch)
    if not r4 then

    end

    up0 = true
    up1(arg1)

    do return end
end

function F.fn_108_function(arg1)
    local r0, r1, r2, r3, r4
    r4 = (arg1.UserInputType == Enum.UserInputType.MouseButton1)
    if r4 then

    end
    r4 = (arg1.UserInputType == Enum.UserInputType.Touch)
    if not r4 then

    end

    up0 = false

    do return end
end

function F.fn_109_function(arg1)
    local r0, r1, r2, r3, r4
    r1 = up0
    if not r1 then

    end
    r4 = (arg1.UserInputType == Enum.UserInputType.MouseMovement)
    if r4 then

    end
    r4 = (arg1.UserInputType == Enum.UserInputType.Touch)
    if not r4 then

    end

    up1(arg1)

    do return end
end

function F.fn_110_function(arg1, arg2)
    local r0, r1, r2, r3, r4, r5, r6, r7, r8
    r4 = UDim2.new(((arg2 - up0) / (up1 - up0)), 0, 1, 0)
    up2.Size = r4
    r4 = tostring(arg2)
    up3.Text = r4
    up4(arg2)
    do return end
end

function F.fn_111_function(arg1, arg2, arg3, arg4, arg5, arg6)
    local r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18, r19
    r7 = {}
    r7.Parent = up0
    r8 = Color3.fromRGB(13, 13, 13)
    r7.BackgroundColor3 = r8
    r8 = UDim2.new(1, 0, 0, 50)
    r7.Size = r8
    r8 = Instance.new("Frame")

    r19 = (50 == "Parent")
    if r19 then

    end
    r8[50] = r13

    r8.Parent = r7.Parent
    r7 = {}
    r8 = UDim.new(0, 6)
    r7.CornerRadius = r8
    r7.Parent = r8
    r8 = Instance.new("UICorner")

    r19 = (r12 == "Parent")
    if r19 then

    end
    r8[r12] = r13

    r8.Parent = r7.Parent
    r7 = {}
    r7.Parent = r8
    r7.BackgroundTransparency = 1
    r8 = UDim2.new(0, 12, 0, 0)
    r7.Position = r8
    r8 = UDim2.new(1, -64, 0, 28)
    r7.Size = r8
    r7.Font = "Gotham"
    r7.Text = arg2
    r8 = Color3.fromRGB(225, 225, 225)
    r7.TextColor3 = r8
    r7.TextSize = 14
    r7.TextXAlignment = "Left"
    r8 = Instance.new("TextLabel")

    r19 = (28 == "Parent")
    if r19 then

    end
    r8[28] = r13

    r8.Parent = r7.Parent
    r8 = {}
    r8.Parent = r8
    r8.BackgroundTransparency = 1
    r9 = UDim2.new(1, -60, 0, 0)
    r8.Position = r9
    r9 = UDim2.new(0, 48, 0, 24)
    r8.Size = r9
    r8.Font = "GothamBold"
    r9 = tostring(arg5)
    r8.Text = r9
    r8.TextColor3 = up1.Accent
    r8.TextSize = 13
    r8.TextXAlignment = "Right"
    r9 = Instance.new("TextLabel")

    r19 = (24 == "Parent")
    if r19 then

    end
    r9[24] = r14

    r9.Parent = r8.Parent
    r9 = {}
    r9.Parent = r8
    r10 = Color3.fromRGB(35, 35, 35)
    r9.BackgroundColor3 = r10
    r10 = UDim2.new(0, 12, 0, 32)
    r9.Position = r10
    r10 = UDim2.new(1, -24, 0, 6)
    r9.Size = r10
    r10 = Instance.new("Frame")

    r19 = (6 == "Parent")
    if r19 then

    end
    r10[6] = r15

    r10.Parent = r9.Parent
    r9 = {}
    r10 = UDim.new(1, 0)
    r9.CornerRadius = r10
    r9.Parent = r10
    r10 = Instance.new("UICorner")

    r19 = (r14 == "Parent")
    if r19 then

    end
    r10[r14] = r15

    r10.Parent = r9.Parent
    r10 = {}
    r10.Parent = r10
    r10.BackgroundColor3 = up1.Accent
    r11 = UDim2.new(((arg5 - arg3) / (arg4 - arg3)), 0, 1, 0)
    r10.Size = r11
    r11 = Instance.new("Frame")

    r19 = (0 == "Parent")
    if r19 then

    end
    r11[0] = r16

    r11.Parent = r10.Parent
    r10 = {}
    r11 = UDim.new(1, 0)
    r10.CornerRadius = r11
    r10.Parent = r11
    r11 = Instance.new("UICorner")

    r19 = (r15 == "Parent")
    if r19 then

    end
    r11[r15] = r16

    r11.Parent = r10.Parent
    r11 = {}
    r11.Parent = r11
    r12 = Vector2.new(1, 0.5)
    r11.AnchorPoint = r12
    r12 = Color3.new(1, 1, 1)
    r11.BackgroundColor3 = r12
    r12 = UDim2.new(1, 0, 0.5, 0)
    r11.Position = r12
    r12 = UDim2.new(0, 12, 0, 12)
    r11.Size = r12
    r12 = Instance.new("Frame")

    r19 = (12 == "Parent")
    if r19 then

    end
    r12[12] = r17

    r12.Parent = r11.Parent
    r11 = {}
    r12 = UDim.new(1, 0)
    r11.CornerRadius = r12
    r11.Parent = r12
    r12 = Instance.new("UICorner")

    r19 = (r16 == "Parent(")
    if r19 then

    end
    r12[r16] = r17

    r12.Parent = r11.Parent
    r10.InputBegan:Connect(F.fn_107_function)
    up2.InputEnded:Connect(F.fn_108_function)
    up2.InputChanged:Connect(F.fn_109_function)
    r13 = {}
    r13.Set = F.fn_110_function

    do return r13 end
end

function F.fn_112_function()
    local r0, r1, r2, r3, r4, r5, r6, r7, r8
    r4 = tostring(up2)
    up0.Text = up1 .. "): " .. r4
    up3 = false
    up4.Text = "▼"
    r1 = {}
    r2 = UDim2.new(1, 0, 0, 42)
    r1.Size = r2
    r5 = TweenInfo.new(0.25, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
    r2 = up6:Create(up5, r5, r1)
    r2:Play()
    r0 = up7
    if not r0 then

    end
    up7(up2)

    do return end
end

function F.fn_113_function(arg1)
    local r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15
    r2, r3 = up0:GetChildren()

    r6 = r5:IsA("TextButton")
    if not r6 then

    end
    r5:Destroy()

    r7 = {}
    r7.Parent = up0
    r8 = Color3.fromRGB(22, 22, 22)
    r7.BackgroundColor3 = r8
    r8 = UDim2.new(1, 0, 0, 28)
    r7.Size = r8
    r7.Font = "Gotham"
    r8 = tostring(r5)
    r7.Text = r8
    r8 = Color3.fromRGB(200, 200, 200)
    r7.TextColor3 = r8
    r7.TextSize = 13
    r7.AutoButtonColor = true
    r8 = Instance.new("TextButton")

    r15 = (28 == "Parent")
    if r15 then

    end
    r8[28] = r13

    r8.Parent = r7.Parent
    r7 = {}
    r8 = UDim.new(0, 4)
    r7.CornerRadius = r8
    r7.Parent = r8
    r8 = Instance.new("UICorner")

    r15 = (r12 == "Parent")
    if r15 then

    end
    r8[r12] = r13

    r8.Parent = r7.Parent
    r8.Activated:Connect(F.fn_112_function)

    do return end
end

function F.fn_114_function(arg1)
    local r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12
    r12 = (arg1.UserInputType == Enum.UserInputType.MouseButton1)
    if r12 then

    end
    r12 = (arg1.UserInputType == Enum.UserInputType.Touch)
    if not r12 then

    end

    r12 = (arg1.Position.Y < (up0.AbsolutePosition.Y + 42))
    if not r12 then

    end
    up1 = not (up1)
    r3 = up1
    if not r3 then

    end

    up2.Text = "▼"
    r2 = up1
    if not r2 then

    end
    r1 = ((42 + up3.UIListLayout.AbsoluteContentSize.Y) + 8)
    if r1 then

    end

    r3 = {}
    r4 = UDim2.new(1, 0, 0, 42)
    r3.Size = r4
    r7 = TweenInfo.new(0.25, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
    r4 = up4:Create(up0, r7, r3)
    r4:Play()

    do return end
end

function F.fn_115_function(arg1, arg2)
    local r0, r1, r2, r3
    up0(arg2)
    do return end
end

function F.fn_116_function(arg1, arg2, arg3, arg4, arg5)
    local r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17
    r6 = {}
    r6.Parent = up0
    r7 = Color3.fromRGB(13, 13, 13)
    r6.BackgroundColor3 = r7
    r7 = UDim2.new(1, 0, 0, 42)
    r6.Size = r7
    r6.ClipsDescendants = true
    r7 = Instance.new("Frame")

    r17 = (42 == "Parent")
    if r17 then

    end
    r7[42] = r12

    r7.Parent = r6.Parent
    r6 = {}
    r7 = UDim.new(0, 6)
    r6.CornerRadius = r7
    r6.Parent = r7
    r7 = Instance.new("UICorner")

    r17 = (r11 == "Parent")
    if r17 then

    end
    r7[r11] = r12

    r7.Parent = r6.Parent
    r6 = {}
    r7 = Color3.fromRGB(28, 28, 36)
    r6.Color = r7
    r6.Thickness = 1
    r6.Parent = r7
    r7 = Instance.new("UIStroke")

    r17 = (r11 == "Parent")
    if r17 then

    end
    r7[r11] = r12

    r7.Parent = r6.Parent
    r7 = {}
    r7.Parent = r7
    r7.BackgroundTransparency = 1
    r8 = UDim2.new(0, 12, 0, 0)
    r7.Position = r8
    r8 = UDim2.new(1, -52, 0, 42)
    r7.Size = r8
    r7.Font = "Gotham("
    r3 = arg4
    if not r3 then

    end
    r11 = tostring(r3)
    r8 = arg2 .. "): (" .. r11
    if r8 then

    end

    r7.Text = arg2 .. "): Select Option"
    r8 = Color3.fromRGB(225, 225, 225)
    r7.TextColor3 = r8
    r7.TextSize = 13
    r7.TextXAlignment = "Left"
    r8 = Instance.new("TextLabel")

    r17 = (r3 == "Parent")
    if r17 then

    end
    r8[r3] = r13

    r8.Parent = r7.Parent
    r8 = {}
    r8.Parent = r7
    r8.BackgroundTransparency = 1
    r9 = UDim2.new(1, -38, 0, 0)
    r8.Position = r9
    r9 = UDim2.new(0, 28, 0, 42)
    r8.Size = r9
    r8.Font = "GothamBold"
    r8.Text = "▼"
    r9 = up1.Accent
    if r9 then

    end
    r9 = Color3.fromRGB(0, 162, 255)

    r8.TextColor3 = r9
    r8.TextSize = 16
    r9 = Instance.new("TextLabel")

    r17 = (42 == "Parent")
    if r17 then

    end
    r9[42] = r14

    r9.Parent = r8.Parent
    r9 = {}
    r9.Parent = r7
    r9.BackgroundTransparency = 1
    r10 = UDim2.new(0, 6, 0, 42)
    r9.Position = r10
    r10 = UDim2.new(1, -12, 0, 0)
    r9.Size = r10
    r10 = Instance.new("Frame")

    r17 = (0 == "Parent")
    if r17 then

    end
    r10[0] = r15

    r10.Parent = r9.Parent
    r9 = {}
    r9.Parent = r10
    r10 = UDim.new(0, 3)
    r9.Padding = r10
    r10 = Instance.new("UIListLayout")

    r17 = (r14 == "Parent")
    if r17 then

    end
    r10[r14] = r15

    r10.Parent = r9.Parent
    F.fn_113_function(arg3)
    r7.InputBegan:Connect(F.fn_114_function)
    r11 = {}
    r11.Refresh = F.fn_115_function

    do return r11 end
end

function F.fn_117_function(arg1, arg2)
    local r0, r1, r2, r3, r4, r5, r6
    r3 = arg2:gsub("^──%s*", "")
    r3 = r3:gsub("%s*──$", "")
    up0.Text = r3
    do return end
end

function F.fn_118_function(arg1, arg2)
    local r0, r1, r2
    up0.Text = arg2
    do return end
end

function F.fn_119_function(arg1, arg2)
    local r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14
    r3 = arg2:sub(1, 2)
    r14 = (r3 == "──")
    if r14 then

    end
    r3 = arg2:sub(1, 1)
    r14 = (r3 == "✦")
    if r14 then

    end

    r2 = true
    if not r2 then

    end
    r3 = arg2:gsub("^──%s*", "")
    r3 = r3:gsub("%s*──$", "")
    r5 = {}
    r5.Parent = up0
    r5.BackgroundTransparency = 1
    r6 = UDim2.new(1, 0, 0, 26)
    r5.Size = r6
    r6 = Instance.new("Frame")

    r14 = (26 == "Parent")
    if r14 then

    end
    r6[26] = r11

    r6.Parent = r5.Parent
    r6 = {}
    r6.Parent = r6
    r6.BackgroundTransparency = 1
    r7 = UDim2.new(0, 4, 0, 4)
    r6.Position = r7
    r7 = UDim2.new(1, -8, 1, -4)
    r6.Size = r7
    r6.Font = "GothamBold"
    r6.Text = r3
    r7 = up1.Accent
    if r7 then

    end
    r7 = Color3.fromRGB(0, 162, 255)

    r6.TextColor3 = r7
    r6.TextSize = 12
    r6.TextXAlignment = "Left"
    r7 = Instance.new("TextLabel")

    r14 = (-4 == "Parent")
    if r14 then

    end
    r7[-4] = r12

    r7.Parent = r6.Parent
    r6 = {}
    r6.Set = F.fn_117_function
    do return r6 end

    r4 = {}
    r4.Parent = up0
    r5 = Color3.fromRGB(13, 13, 13)
    r4.BackgroundColor3 = r5
    r5 = UDim2.new(1, 0, 0, 32)
    r4.Size = r5
    r5 = Instance.new("Frame")

    r14 = (32 == "Parent")
    if r14 then

    end
    r5[32] = r10

    r5.Parent = r4.Parent
    r4 = {}
    r5 = UDim.new(0, 6)
    r4.CornerRadius = r5
    r4.Parent = r5
    r5 = Instance.new("UICorner")

    r14 = (r9 == "Parent")
    if r14 then

    end
    r5[r9] = r10

    r5.Parent = r4.Parent
    r5 = {}
    r5.Parent = r5
    r5.BackgroundTransparency = 1
    r6 = UDim2.new(0, 12, 0, 0)
    r5.Position = r6
    r6 = UDim2.new(1, -24, 1, 0)
    r5.Size = r6
    r5.Font = "Gotham"
    r5.Text = arg2
    r6 = Color3.fromRGB(180, 180, 180)
    r5.TextColor3 = r6
    r5.TextSize = 13
    r5.TextXAlignment = "Left"
    r6 = Instance.new("TextLabel")

    r14 = (0 == "Parent")
    if r14 then

    end
    r6[0] = r11

    r6.Parent = r5.Parent
    r5 = {}
    r5.Set = F.fn_118_function
    do return r5 end
end

function F.fn_120_function(arg1)
    local r0, r1, r2, r3
    r1 = up0
    if not r1 then

    end
    up0(up1.Text)

    do return end
end

function F.fn_121_function(arg1, arg2)
    local r0, r1, r2, r3, r4
    r3 = tostring(arg2)
    up0.Text = r3
    do return end
end

function F.fn_122_function(arg1, arg2, arg3, arg4)
    local r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15
    r5 = {}
    r5.Parent = up0
    r6 = Color3.fromRGB(13, 13, 13)
    r5.BackgroundColor3 = r6
    r6 = UDim2.new(1, 0, 0, 42)
    r5.Size = r6
    r6 = Instance.new("Frame")

    r15 = (42 == "Parent")
    if r15 then

    end
    r6[42] = r11

    r6.Parent = r5.Parent
    r5 = {}
    r6 = UDim.new(0, 6)
    r5.CornerRadius = r6
    r5.Parent = r6
    r6 = Instance.new("UICorner")

    r15 = (r10 == "Parent")
    if r15 then

    end
    r6[r10] = r11

    r6.Parent = r5.Parent
    r5 = {}
    r6 = Color3.fromRGB(28, 28, 36)
    r5.Color = r6
    r5.Thickness = 1
    r5.Parent = r6
    r6 = Instance.new("UIStroke")

    r15 = (r10 == "Parent")
    if r15 then

    end
    r6[r10] = r11

    r6.Parent = r5.Parent
    r6 = {}
    r6.Parent = r6
    r6.BackgroundTransparency = 1
    r7 = UDim2.new(0, 12, 0, 0)
    r6.Position = r7
    r7 = UDim2.new(0.4, -12, 1, 0)
    r6.Size = r7
    r6.Font = "Gotham"
    r6.Text = arg2
    r7 = Color3.fromRGB(225, 225, 225)
    r6.TextColor3 = r7
    r6.TextSize = 13
    r6.TextXAlignment = "Left"
    r7 = Instance.new("TextLabel")

    r15 = (0 == "Parent")
    if r15 then

    end
    r7[0] = r12

    r7.Parent = r6.Parent
    r7 = {}
    r7.Parent = r6
    r8 = Color3.fromRGB(22, 22, 22)
    r7.BackgroundColor3 = r8
    r8 = UDim2.new(0.4, 0, 0.15, 0)
    r7.Position = r8
    r8 = UDim2.new(0.6, -12, 0.7, 0)
    r7.Size = r8
    r7.Font = "Gotham"
    r8 = arg3
    if r8 then

    end

    r7.Text = ""
    r8 = Color3.fromRGB(255, 255, 255)
    r7.TextColor3 = r8
    r8 = arg3
    if r8 then

    end

    r7.PlaceholderText = "Type here..."
    r7.TextSize = 13
    r7.ClearTextOnFocus = false
    r8 = Instance.new("TextBox")

    r15 = (0 == "Parent")
    if r15 then

    end
    r8[0] = r13

    r8.Parent = r7.Parent
    r7 = {}
    r8 = UDim.new(0, 4)
    r7.CornerRadius = r8
    r7.Parent = r8
    r8 = Instance.new("UICorner")

    r15 = (r12 == "Parent")
    if r15 then

    end
    r8[r12] = r13

    r8.Parent = r7.Parent
    r8.FocusLost:Connect(F.fn_120_function)
    r7 = {}
    r7.Set = F.fn_121_function
    do return r7 end
end

function F.fn_123_function(arg1, arg2)
    local r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12
    r3 = {}
    r3.Parent = up0
    r4 = Color3.fromRGB(16, 16, 16)
    r3.BackgroundColor3 = r4
    r4 = UDim2.new(1, 0, 0, 24)
    r3.Size = r4
    r4 = Instance.new("Frame")

    r12 = (24 == "Parent")
    if r12 then

    end
    r4[24] = r9

    r4.Parent = r3.Parent
    r3 = {}
    r4 = UDim.new(0, 6)
    r3.CornerRadius = r4
    r3.Parent = r4
    r4 = Instance.new("UICorner")

    r12 = (r8 == "Parent")
    if r12 then

    end
    r4[r8] = r9

    r4.Parent = r3.Parent
    r3 = {}
    r3.Parent = r4
    r3.BackgroundTransparency = 1
    r4 = UDim2.new(0, 12, 0, 0)
    r3.Position = r4
    r4 = UDim2.new(1, -12, 1, 0)
    r3.Size = r4
    r3.Font = "GothamBold"
    r4 = arg2:upper()
    r3.Text = r4
    r4 = Color3.fromRGB(190, 190, 190)
    r3.TextColor3 = r4
    r3.TextSize = 10
    r3.TextXAlignment = "Left"
    r4 = Instance.new("TextLabel")

    r12 = (0 == "Parent")
    if r12 then

    end
    r4[0] = r9

    r4.Parent = r3.Parent
    r4 = {}
    r4.Parent = up0
    r4.BackgroundTransparency = 1
    r5 = UDim2.new(1, 0, 0, 0)
    r4.Size = r5
    r4.AutomaticSize = "Y"
    r5 = Instance.new("Frame")

    r12 = (0 == "Parent")
    if r12 then

    end
    r5[0] = r10

    r5.Parent = r4.Parent
    r4 = {}
    r4.Parent = r5
    r5 = UDim.new(0, 4)
    r4.Padding = r5
    r5 = Instance.new("UIListLayout")

    r12 = (r9 == "Parent")
    if r12 then

    end
    r5[r9] = r10

    r5.Parent = r4.Parent
    r4 = {}
    r4.CreateToggle = F.fn_103_function
    r4.CreateButton = F.fn_105_function
    r4.CreateSlider = F.fn_111_function
    r4.CreateDropdown = F.fn_116_function
    r4.CreateLabel = F.fn_119_function
    r4.CreateInput = F.fn_122_function
    do return r4 end
end

function F.fn_124_function(arg1, arg2, arg3)
    local r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18
    r5 = arg3
    if r5 then

    end

    r3 = up0:GetIcon("layout")
    r5 = {}
    r5.Parent = up1
    r5.BackgroundTransparency = 1
    r6 = UDim2.new(0, 0, 1, 0)
    r5.Size = r6
    r5.AutomaticSize = "X"
    r5.Visible = false
    r6 = Instance.new("Frame")

    r18 = (0 == "Parent")
    if r18 then

    end
    r6[0] = r11

    r6.Parent = r5.Parent
    r6 = {}
    r6.Parent = r6
    r6.BackgroundTransparency = 1
    r7 = UDim2.new(1, 0, 1, 0)
    r6.Size = r7
    r6.Text = ""
    r7 = Instance.new("TextButton")

    r18 = (0 == "Parent")
    if r18 then

    end
    r7[0] = r12

    r7.Parent = r6.Parent
    r7 = {}
    r7.Name = "Icon"
    r7.Parent = r6
    r7.BackgroundTransparency = 1
    r8 = UDim2.new(0, 0, 0.5, -10)
    r7.Position = r8
    r8 = UDim2.new(0, 20, 0, 20)
    r7.Size = r8
    r7.Image = "rbxassetid://" .. r3[1]
    r8 = Vector2.new(r3[2], r3[3])
    r7.ImageRectSize = r8
    r8 = Vector2.new(r3[4], r3[5])
    r7.ImageRectOffset = r8
    r8 = Color3.fromRGB(160, 160, 160)
    r7.ImageColor3 = r8
    r7.ScaleType = Enum.ScaleType.Fit
    r8 = Instance.new("ImageLabel")

    r18 = (20 == "Parent")
    if r18 then

    end
    r8[20] = r13

    r8.Parent = r7.Parent
    r8 = {}
    r8.Name = "Label"
    r8.Parent = r6
    r8.BackgroundTransparency = 1
    r9 = UDim2.new(0, 22, 0, 0)
    r8.Position = r9
    r9 = UDim2.new(0, 0, 1, 0)
    r8.Size = r9
    r8.AutomaticSize = "X"
    r8.Font = "Gotham"
    r8.Text = arg2
    r9 = Color3.fromRGB(160, 160, 160)
    r8.TextColor3 = r9
    r8.TextSize = 13
    r9 = Instance.new("TextLabel")

    r18 = (0 == "Parent")
    if r18 then

    end
    r9[0] = r14

    r9.Parent = r8.Parent
    r9 = {}
    r9.Parent = r6
    r9.BackgroundColor3 = up0.Accent
    r9.BackgroundTransparency = 1
    r9.BorderSizePixel = 0
    r10 = UDim2.new(0, 0, 1, -2)
    r9.Position = r10
    r10 = UDim2.new(1, 0, 0, 2)
    r9.Size = r10
    r10 = Instance.new("Frame")

    r18 = (2 == "Parent")
    if r18 then

    end
    r10[2] = r15

    r10.Parent = r9.Parent
    r10 = {}
    r10.Parent = up2
    r10.BackgroundTransparency = 1
    r10.BorderSizePixel = 0
    r11 = UDim2.new(1, 0, 1, 0)
    r10.Size = r11
    r10.Visible = false
    r10.ScrollBarThickness = 2
    r10.ScrollBarImageColor3 = up0.Accent
    r11 = UDim2.new(0, 0, 0, 0)
    r10.CanvasSize = r11
    r10.AutomaticCanvasSize = "Y"
    r11 = Instance.new("ScrollingFrame")

    r18 = (0 == "Parent")
    if r18 then

    end
    r11[0] = r16

    r11.Parent = r10.Parent
    r10 = {}
    r10.Parent = r11
    r11 = UDim.new(0, 6)
    r10.Padding = r11
    r10.HorizontalAlignment = "Center"
    r11 = Instance.new("UIListLayout")

    r18 = (r15 == "Parent")
    if r18 then

    end
    r11[r15] = r16

    r11.Parent = r10.Parent
    r10 = {}
    r10.Parent = r11
    r11 = UDim.new(0, 10)
    r10.PaddingTop = r11
    r11 = UDim.new(0, 18)
    r10.PaddingLeft = r11
    r11 = UDim.new(0, 18)
    r10.PaddingRight = r11
    r11 = Instance.new("UIPadding")

    r18 = (r15 == "Parent")
    if r18 then

    end
    r11[r15] = r16

    r11.Parent = r10.Parent
    r10 = {}
    r10.Page = r11
    r10.Btn = r6
    r10.Select = F.fn_098_function
    r7.Activated:Connect(F.fn_099_function)
    table.insert(up3.SubTabs, r10)
    r11 = up5.Current
    if not r11 then

    end
    r18 = (up5.Current.Tab == up3)
    if not r18 then

    end
    r11 = up3.CurrentST
    if r11 then

    end
    r6.Visible = true
    r10:Select()

    r10.CreateSection = F.fn_123_function
    do return r10 end
end

function F.fn_125_create_subtab(arg1, arg2, arg3)
    local r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16
    r4 = {}
    r4.Name = arg2 .. "Tab"
    r4.Parent = up0
    r4.BackgroundTransparency = 1
    r5 = UDim2.new(1, 0, 0, 50)
    r4.Size = r5
    r5 = Instance.new("ImageButton")

    r16 = (50 == "Parent")
    if r16 then

    end
    r5[50] = r10

    r5.Parent = r4.Parent
    r5 = {}
    r5.Parent = r5
    r6 = Color3.fromRGB(30, 30, 30)
    r5.BackgroundColor3 = r6
    r5.BackgroundTransparency = 1
    r5.BorderSizePixel = 0
    r6 = UDim2.new(1, 0, 1, 0)
    r5.Size = r6
    r6 = Instance.new("Frame")

    r16 = (0 == "Parent")
    if r16 then

    end
    r6[0] = r11

    r6.Parent = r5.Parent
    r5 = {}
    r6 = UDim.new(0, 6)
    r5.CornerRadius = r6
    r5.Parent = r6
    r6 = Instance.new("UICorner")

    r16 = (r10 == "Parent")
    if r16 then

    end
    r6[r10] = r11

    r6.Parent = r5.Parent
    r6 = {}
    r6.Name = "Indicator"
    r6.Parent = r5
    r6.BackgroundColor3 = up1.Accent
    r6.BorderSizePixel = 0
    r7 = UDim2.new(0, 0, 0.5, -12)
    r6.Position = r7
    r7 = UDim2.new(0, 3, 0, 24)
    r6.Size = r7
    r6.BackgroundTransparency = 1
    r6.ZIndex = 5
    r7 = Instance.new("Frame")

    r16 = (24 == "Parent")
    if r16 then

    end
    r7[24] = r12

    r7.Parent = r6.Parent
    r6 = {}
    r7 = UDim.new(1, 0)
    r6.CornerRadius = r7
    r6.Parent = r7
    r7 = Instance.new("UICorner")

    r16 = (r11 == "Parent")
    if r16 then

    end
    r7[r11] = r12

    r7.Parent = r6.Parent
    r8 = arg3
    if r8 then

    end

    r6 = up1:GetIcon("home")
    r8 = {}
    r8.Name = "Icon"
    r8.Parent = r5
    r8.BackgroundTransparency = 1
    r9 = UDim2.new(0.5, -18, 0.5, -18)
    r8.Position = r9
    r9 = UDim2.new(0, 36, 0, 36)
    r8.Size = r9
    r8.Image = "rbxassetid://" .. r6[1]
    r9 = Vector2.new(r6[2], r6[3])
    r8.ImageRectSize = r9
    r9 = Vector2.new(r6[4], r6[5])
    r8.ImageRectOffset = r9
    r9 = Color3.fromRGB(140, 140, 140)
    r8.ImageColor3 = r9
    r8.ScaleType = Enum.ScaleType.Fit
    r8.ZIndex = 6
    r9 = Instance.new("ImageLabel")

    r16 = (36 == "Parent")
    if r16 then

    end
    r9[36] = r14

    r9.Parent = r8.Parent
    r8 = {}
    r9 = {}
    r8.SubTabs = r9
    r8.CurrentST = nil
    r8.Select = F.fn_095_function
    r5.Activated:Connect(F.fn_096_function)
    r8.SetVisible = F.fn_097_function
    r8.CreateSubTab = F.fn_124_function
    Window.Tabs[arg2] = r8
    r9 = up3.Current
    if r9 then

    end
    r8:Select()

    do return r8 end
end

function F.fn_126_create_tab(arg1, arg2)
    local r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20, r21, r22, r23, r24, r25, r26, r27, r28, r29, r30, r31, r32, r33, r34
    r3, r4 = pcall(F.fn_073_function)
    if not r3 then

    end
    r5 = r4
    if r5 then

    end

    r6 = math.random(10000000, 90000000)
    r5 = tostring()

    r4 = {}
    r4.Name = r5
    r4.ResetOnSpawn = false
    r5 = Instance.new("ScreenGui")

    r34 = (r9 == "Parent")
    if r34 then

    end
    r5[r9] = r10

    r5.Parent = r4.Parent
    r5 = up0:IsStudio()
    if r5 then

    end
    r5 = syn
    if not r5 then

    end
    r5 = syn.protect_gui
    if not r5 then

    end
    pcall(F.fn_074_function)

    r4 = false
    if r4 then

    end
    r5 = gethui
    if not r5 then

    end
    pcall(F.fn_075_function)

    if r4 then

    end
    r5 = get_hidden_gui
    if not r5 then

    end
    pcall(F.fn_076_function)

    if r4 then

    end
    r6 = up0:IsStudio()
    if not r6 then

    end
    r5 = up2.PlayerGui
    if r5 then

    end

    r5.Parent = up1

    r5 = getgenv
    if not r5 then

    end
    r7 = getgenv()
    r6 = r7["_h_" .. r5]
    if not r6 then

    end
    pcall(F.fn_077_function)

    r6 = getgenv()
    r6["_h_" .. r5] = r5

    r6 = {}
    r6.Parent = r5
    r6.BackgroundColor3 = up3.BgPrimary
    r7 = UDim2.new(0.5, -300, 0.5, -220)
    r6.Position = r7
    r7 = UDim2.new(0, 600, 0, 440)
    r6.Size = r7
    r6.ClipsDescendants = true
    r6.Visible = true
    r7 = Instance.new("Frame")

    r34 = (440 == "Parent")
    if r34 then

    end
    r7[440] = r12

    r7.Parent = r6.Parent
    r6 = {}
    r7 = UDim.new(0, 10)
    r6.CornerRadius = r7
    r6.Parent = r7
    r7 = Instance.new("UICorner")

    r34 = (r11 == "Parent")
    if r34 then

    end
    r7[r11] = r12

    r7.Parent = r6.Parent
    r7 = {}
    r7.Name = "Glow"
    r7.Parent = r7
    r7.ZIndex = 0
    r7.BackgroundTransparency = 1
    r8 = UDim2.new(0, -25, 0, -25)
    r7.Position = r8
    r8 = UDim2.new(1, 50, 1, 50)
    r7.Size = r8
    r7.Image = "rbxassetid://6015667320"
    r7.ImageColor3 = up3.Accent
    r7.ImageTransparency = 0.5
    r7.ScaleType = Enum.ScaleType.Slice
    r8 = Rect.new(49, 49, 450, 450)
    r7.SliceCenter = r8
    r8 = Instance.new("ImageLabel")

    r34 = (450 == "Parent")
    if r34 then

    end
    r8[450] = r13

    r8.Parent = r7.Parent
    r7 = {}
    r7.Color = up3.Border
    r7.Thickness = 1
    r7.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
    r7.LineJoinMode = Enum.LineJoinMode.Round
    r7.Parent = r7
    r8 = Instance.new("UIStroke")

    r34 = (r12 == "Parent")
    if r34 then

    end
    r8[r12] = r13

    r8.Parent = r7.Parent
    task.spawn(F.fn_079_function)
    r8 = {}
    r8.Parent = r7
    r8.BackgroundColor3 = up3.BgSecondary
    r9 = UDim2.new(0, 65, 1, 0)
    r8.Size = r9
    r9 = Instance.new("Frame")

    r34 = (0 == "Parent")
    if r34 then

    end
    r9[0] = r14

    r9.Parent = r8.Parent
    r8 = {}
    r9 = UDim.new(0, 10)
    r8.CornerRadius = r9
    r8.Parent = r9
    r9 = Instance.new("UICorner")

    r34 = (r13 == "Parent")
    if r34 then

    end
    r9[r13] = r14

    r9.Parent = r8.Parent
    r8 = {}
    r8.Parent = r9
    r8.BackgroundColor3 = up3.BgSecondary
    r8.BorderSizePixel = 0
    r9 = Vector2.new(1, 0)
    r8.AnchorPoint = r9
    r9 = UDim2.new(1, 0, 0, 0)
    r8.Position = r9
    r9 = UDim2.new(0, 15, 1, 0)
    r8.Size = r9
    r9 = Instance.new("Frame")

    r34 = (0 == "Parent")
    if r34 then

    end
    r9[0] = r14

    r9.Parent = r8.Parent
    r8 = {}
    r8.Color = up3.Border
    r8.ApplyStrokeMode = "Border"
    r8.Parent = r9
    r9 = Instance.new("UIStroke")

    r34 = (r13 == "Parent")
    if r34 then

    end
    r9[r13] = r14

    r9.Parent = r8.Parent
    r9 = {}
    r9.Name = "Branding"
    r9.Parent = r9
    r9.BackgroundTransparency = 1
    r10 = UDim2.new(1, 0, 0, 65)
    r9.Size = r10
    r10 = Instance.new("Frame")

    r34 = (65 == "Parent")
    if r34 then

    end
    r10[65] = r15

    r10.Parent = r9.Parent
    r9 = {}
    r9.Parent = r10
    r9.BackgroundTransparency = 1
    r10 = Vector2.new(0.5, 0.5)
    r9.AnchorPoint = r10
    r10 = UDim2.new(0.5, 0, 0.5, 0)
    r9.Position = r10
    r10 = UDim2.new(0, 42, 0, 42)
    r9.Size = r10
    r9.Image = "rbxassetid://123802801726537"
    r9.ScaleType = Enum.ScaleType.Fit
    r10 = Instance.new("ImageLabel")

    r34 = (42 == "Parent")
    if r34 then

    end
    r10[42] = r15

    r10.Parent = r9.Parent
    r9 = {}
    r9.Parent = r10
    r10 = Color3.fromRGB(35, 35, 35)
    r9.BackgroundColor3 = r10
    r9.BorderSizePixel = 0
    r10 = UDim2.new(0, 10, 1, -1)
    r9.Position = r10
    r10 = UDim2.new(1, -20, 0, 1)
    r9.Size = r10
    r10 = Instance.new("Frame")

    r34 = (1 == "Parent")
    if r34 then

    end
    r10[1] = r15

    r10.Parent = r9.Parent
    r10 = {}
    r10.Parent = r9
    r10.BackgroundTransparency = 1
    r11 = UDim2.new(0, 0, 0, 65)
    r10.Position = r11
    r11 = UDim2.new(1, 0, 1, -135)
    r10.Size = r11
    r11 = UDim2.new(0, 0, 0, 0)
    r10.CanvasSize = r11
    r10.AutomaticCanvasSize = "Y"
    r10.ScrollBarThickness = 1
    r10.ScrollBarImageTransparency = 1
    r10.ScrollingDirection = "Y"
    r11 = Instance.new("ScrollingFrame")

    r34 = (0 == "Parent")
    if r34 then

    end
    r11[0] = r16

    r11.Parent = r10.Parent
    r10 = {}
    r10.Parent = r11
    r10.HorizontalAlignment = "Center"
    r11 = UDim.new(0, 8)
    r10.Padding = r11
    r11 = Instance.new("UIListLayout")

    r34 = (r15 == "Parent")
    if r34 then

    end
    r11[r15] = r16

    r11.Parent = r10.Parent
    r11 = {}
    r11.Name = "Profile"
    r11.Parent = r9
    r11.BackgroundTransparency = 1
    r12 = Vector2.new(0, 1)
    r11.AnchorPoint = r12
    r12 = UDim2.new(0, 0, 1, 0)
    r11.Position = r12
    r12 = UDim2.new(1, 0, 0, 70)
    r11.Size = r12
    r12 = Instance.new("Frame")

    r34 = (70 == "Parent")
    if r34 then

    end
    r12[70] = r17

    r12.Parent = r11.Parent
    r11 = {}
    r11.Parent = r12
    r12 = Color3.fromRGB(35, 35, 35)
    r11.BackgroundColor3 = r12
    r11.BorderSizePixel = 0
    r12 = UDim2.new(0, 10, 0, 0)
    r11.Position = r12
    r12 = UDim2.new(1, -20, 0, 1)
    r11.Size = r12
    r12 = Instance.new("Frame")

    r34 = (1 == "Parent")
    if r34 then

    end
    r12[1] = r17

    r12.Parent = r11.Parent
    r12 = {}
    r12.Parent = r12
    r13 = Color3.fromRGB(30, 30, 30)
    r12.BackgroundColor3 = r13
    r13 = Vector2.new(0.5, 0.5)
    r12.AnchorPoint = r13
    r13 = UDim2.new(0.5, 0, 0.5, 0)
    r12.Position = r13
    r13 = UDim2.new(0, 44, 0, 44)
    r12.Size = r13
    r13 = Instance.new("Frame")

    r34 = (44 == "Parent")
    if r34 then

    end
    r13[44] = r18

    r13.Parent = r12.Parent
    r12 = {}
    r13 = UDim.new(1, 0)
    r12.CornerRadius = r13
    r12.Parent = r13
    r13 = Instance.new("UICorner")

    r34 = (r17 == "Parent")
    if r34 then

    end
    r13[r17] = r18

    r13.Parent = r12.Parent
    r12 = {}
    r12.Color = up3.Border
    r12.Thickness = 1
    r12.Parent = r13
    r13 = Instance.new("UIStroke")

    r34 = (r17 == "Parent")
    if r34 then

    end
    r13[r17] = r18

    r13.Parent = r12.Parent
    r13 = {}
    r13.Parent = r13
    r13.BackgroundTransparency = 1
    r14 = UDim2.new(1, 0, 1, 0)
    r13.Size = r14
    r13.Image = ""
    r14 = Instance.new("ImageLabel")

    r34 = (0 == "Parent")
    if r34 then

    end
    r14[0] = r19

    r14.Parent = r13.Parent
    r13 = {}
    r14 = UDim.new(1, 0)
    r13.CornerRadius = r14
    r13.Parent = r14
    r14 = Instance.new("UICorner")

    r34 = (r18 == "Parent")
    if r34 then

    end
    r14[r18] = r19

    r14.Parent = r13.Parent
    task.spawn(F.fn_081_function)
    r14 = {}
    r14.Parent = r7
    r14.BackgroundTransparency = 1
    r15 = UDim2.new(0, 65, 0, 0)
    r14.Position = r15
    r15 = UDim2.new(1, -65, 1, 0)
    r14.Size = r15
    r15 = Instance.new("Frame")

    r34 = (0 == "Parent")
    if r34 then

    end
    r15[0] = r20

    r15.Parent = r14.Parent
    r15 = {}
    r15.Name = "DragBar"
    r15.Parent = r7
    r15.BackgroundTransparency = 1
    r16 = UDim2.new(1, 0, 0, 48)
    r15.Size = r16
    r15.ZIndex = 0
    r16 = Instance.new("Frame")

    r34 = (48 == "Parent")
    if r34 then

    end
    r16[48] = r21

    r16.Parent = r15.Parent
    r16 = {}
    r16.Name = "DragSide"
    r16.Parent = r9
    r16.BackgroundTransparency = 1
    r17 = UDim2.new(1, 0, 0, 65)
    r16.Size = r17
    r16.ZIndex = 11
    r17 = Instance.new("Frame")

    r34 = (65 == "Parent")
    if r34 then

    end
    r17[65] = r22

    r17.Parent = r16.Parent
    r16 = up6:MakeDraggable(r16, r7)
    up6:MakeDraggable(r17, r7)
    r18 = {}
    r18.Parent = r15
    r18.BackgroundTransparency = 1
    r19 = UDim2.new(1, 0, 0, 48)
    r18.Size = r19
    r19 = Instance.new("Frame")

    r34 = (48 == "Parent")
    if r34 then

    end
    r19[48] = r24

    r19.Parent = r18.Parent
    r18 = {}
    r18.Parent = r19
    r18.BackgroundTransparency = 1
    r19 = UDim2.new(0, 16, 0, 0)
    r18.Position = r19
    r19 = UDim2.new(0, 180, 1, 0)
    r18.Size = r19
    r18.Font = "GothamBold"
    r19 = arg2
    if r19 then

    end

    r18.Text = "Snowy Studios"
    r19 = Color3.new(1, 1, 1)
    r18.TextColor3 = r19
    r18.TextSize = 18
    r18.TextXAlignment = "Left"
    r19 = Instance.new("TextLabel")

    r34 = (0 == "Parent")
    if r34 then

    end
    r19[0] = r24

    r19.Parent = r18.Parent
    r19 = {}
    r19.Name = "CloseBtn"
    r19.Parent = r19
    r20 = Vector2.new(1, 0.5)
    r19.AnchorPoint = r20
    r19.BackgroundTransparency = 1
    r20 = UDim2.new(1, -12, 0.5, 0)
    r19.Position = r20
    r20 = UDim2.new(0, 24, 0, 24)
    r19.Size = r20
    r19.Font = "GothamBold"
    r19.Text = "X"
    r20 = Color3.new(1, 1, 1)
    r19.TextColor3 = r20
    r19.TextSize = 13
    r19.AutoButtonColor = false
    r19.ZIndex = 12
    r20 = Instance.new("TextButton")

    r34 = (24 == "Parent")
    if r34 then

    end
    r20[24] = r25

    r20.Parent = r19.Parent
    r20.Activated:Connect(F.fn_082_function)
    r20 = {}
    r20.Name = "MinBtn"
    r20.Parent = r19
    r21 = Vector2.new(1, 0.5)
    r20.AnchorPoint = r21
    r20.BackgroundTransparency = 1
    r21 = UDim2.new(1, -42, 0.5, 0)
    r20.Position = r21
    r21 = UDim2.new(0, 24, 0, 24)
    r20.Size = r21
    r20.Font = "GothamBold"
    r20.Text = "–"
    r21 = Color3.new(1, 1, 1)
    r20.TextColor3 = r21
    r20.TextSize = 22
    r20.AutoButtonColor = false
    r20.ZIndex = 12
    r21 = Instance.new("TextButton")

    r34 = (24 == "Parent")
    if r34 then

    end
    r21[24] = r26

    r21.Parent = r20.Parent
    r21.MouseEnter:Connect(F.fn_083_function)
    r21.MouseLeave:Connect(F.fn_084_function)
    r20.MouseEnter:Connect(F.fn_085_function)
    r20.MouseLeave:Connect(F.fn_086_function)
    r21 = {}
    r21.Parent = r19
    r21.BackgroundTransparency = 1
    r22 = UDim2.new(0, 200, 0, 0)
    r21.Position = r22
    r22 = UDim2.new(1, -240, 1, 0)
    r21.Size = r22
    r22 = Instance.new("Frame")

    r34 = (0 == "Parent")
    if r34 then

    end
    r22[0] = r27

    r22.Parent = r21.Parent
    r21 = {}
    r21.Parent = r22
    r21.FillDirection = "Horizontal"
    r22 = UDim.new(0, 18)
    r21.Padding = r22
    r21.VerticalAlignment = "Center"
    r22 = Instance.new("UIListLayout")

    r34 = (r26 == "Parent")
    if r34 then

    end
    r22[r26] = r27

    r22.Parent = r21.Parent
    r21 = {}
    r21.Parent = r19
    r21.BackgroundColor3 = up3.Border
    r21.BorderSizePixel = 0
    r22 = UDim2.new(0, 0, 1, -1)
    r21.Position = r22
    r22 = UDim2.new(1, 0, 0, 1)
    r21.Size = r22
    r22 = Instance.new("Frame")

    r34 = (1 == "Parent")
    if r34 then

    end
    r22[1] = r27

    r22.Parent = r21.Parent
    r22 = {}
    r22.Name = "MainFolder"
    r22.Parent = r15
    r22.BackgroundTransparency = 1
    r28 = up7
    if not r28 then

    end

    r23 = UDim2.new(0, 0, 0, 48)
    r22.Position = r23
    r28 = up7
    if not r28 then

    end

    r23 = UDim2.new(1, 0, 1, -48)
    r22.Size = r23
    r23 = Instance.new("Frame")

    r34 = (-48 == "Parent")
    if r34 then

    end
    r23[-48] = r28

    r23.Parent = r22.Parent
    r22 = up8.TouchEnabled
    if not r22 then

    end
    r23 = {}
    r23.Name = "MobileToggle"
    r23.Parent = r5
    r23.BackgroundColor3 = up3.BgSecondary
    r24 = UDim2.new(1, -60, 1, -60)
    r23.Position = r24
    r24 = UDim2.new(0, 44, 0, 44)
    r23.Size = r24
    r23.Image = ""
    r23.AutoButtonColor = false
    r23.ZIndex = 100
    r24 = Instance.new("ImageButton")

    r34 = (44 == "Parent")
    if r34 then

    end
    r24[44] = r29

    r24.Parent = r23.Parent
    r23 = {}
    r24 = UDim.new(0, 10)
    r23.CornerRadius = r24
    r23.Parent = r24
    r24 = Instance.new("UICorner")

    r34 = (r28 == "Parent")
    if r34 then

    end
    r24[r28] = r29

    r24.Parent = r23.Parent
    r23 = {}
    r23.Color = up6.Accent
    r23.Thickness = 2
    r23.Parent = r24
    r24 = Instance.new("UIStroke")

    r34 = (r28 == "Parent")
    if r34 then

    end
    r24[r28] = r29

    r24.Parent = r23.Parent
    r23 = {}
    r23.Parent = r24
    r23.BackgroundTransparency = 1
    r24 = UDim2.new(0.5, -14, 0.5, -14)
    r23.Position = r24
    r24 = UDim2.new(0, 28, 0, 28)
    r23.Size = r24
    r23.Image = "rbxassetid://123802801726537"
    r23.ScaleType = Enum.ScaleType.Fit
    r23.ZIndex = 101
    r24 = Instance.new("ImageLabel")

    r34 = (28 == "Parent")
    if r34 then

    end
    r24[28] = r29

    r24.Parent = r23.Parent
    r23 = up6:MakeDraggable(r24)
    r24.InputEnded:Connect(F.fn_087_function)

    up8.InputBegan:Connect(F.fn_088_function)
    r23 = {}
    r23.Name = "SnowyMarketBubble"
    r23.Parent = r5
    r24 = Vector2.new(0, 0)
    r23.AnchorPoint = r24
    r24 = UDim2.new(0, 30, 0, 30)
    r23.Position = r24
    r24 = UDim2.new(0, 0, 0, 0)
    r23.Size = r24
    r23.BackgroundColor3 = up3.BgCard
    r23.BorderSizePixel = 0
    r23.AutoButtonColor = false
    r23.Image = ""
    r23.Visible = false
    r23.ZIndex = 200
    r24 = Instance.new("ImageButton")

    r34 = (0 == "Parent")
    if r34 then

    end
    r24[0] = r29

    r24.Parent = r23.Parent
    r23 = {}
    r24 = UDim.new(1, 0)
    r23.CornerRadius = r24
    r23.Parent = r24
    r24 = Instance.new("UICorner")

    r34 = (r28 == "Parent")
    if r34 then

    end
    r24[r28] = r29

    r24.Parent = r23.Parent
    r23 = {}
    r23.Color = up3.Accent
    r23.Thickness = 2
    r23.Parent = r24
    r24 = Instance.new("UIStroke")

    r34 = (r28 == "Parent")
    if r34 then

    end
    r24[r28] = r29

    r24.Parent = r23.Parent
    r23 = {}
    r24 = ColorSequence.new(up3.BgSecondary, up3.BgCard)
    r23.Color = r24
    r23.Rotation = 125
    r23.Parent = r24
    r24 = Instance.new("UIGradient")

    r34 = (r28 == "Parent")
    if r34 then

    end
    r24[r28] = r29

    r24.Parent = r23.Parent
    r24 = {}
    r24.Parent = r24
    r24.BackgroundTransparency = 1
    r25 = UDim2.new(0, -15, 0, -15)
    r24.Position = r25
    r25 = UDim2.new(1, 30, 1, 30)
    r24.Size = r25
    r24.Image = "rbxassetid://6015667320"
    r24.ImageColor3 = up3.Accent
    r24.ImageTransparency = 0.55
    r24.ScaleType = Enum.ScaleType.Slice
    r25 = Rect.new(49, 49, 450, 450)
    r24.SliceCenter = r25
    r24.ZIndex = 199
    r25 = Instance.new("ImageLabel")

    r34 = (450 == "Parent")
    if r34 then

    end
    r25[450] = r30

    r25.Parent = r24.Parent
    r25 = {}
    r25.Parent = r24
    r25.BackgroundTransparency = 1
    r26 = Vector2.new(0.5, 0.5)
    r25.AnchorPoint = r26
    r26 = UDim2.new(0, 26, 0.5, 0)
    r25.Position = r26
    r26 = UDim2.new(0, 30, 0, 30)
    r25.Size = r26
    r25.Image = "rbxassetid://123802801726537"
    r25.ScaleType = Enum.ScaleType.Fit
    r25.ZIndex = 201
    r26 = Instance.new("ImageLabel")

    r34 = (30 == "Parent")
    if r34 then

    end
    r26[30] = r31

    r26.Parent = r25.Parent
    r26 = {}
    r26.Parent = r24
    r26.BackgroundTransparency = 1
    r27 = UDim2.new(0, 52, 0, 0)
    r26.Position = r27
    r27 = UDim2.new(1, -64, 1, 0)
    r26.Size = r27
    r26.Font = Enum.Font.GothamBlack
    r26.Text = "Snowy Studios"
    r27 = Color3.new(1, 1, 1)
    r26.TextColor3 = r27
    r26.TextSize = 15
    r26.TextXAlignment = Enum.TextXAlignment.Left
    r26.ZIndex = 201
    r27 = Instance.new("TextLabel")

    r34 = (0 == "Parent")
    if r34 then

    end
    r27[0] = r32

    r27.Parent = r26.Parent
    r26 = {}
    r27 = ColorSequence.new(up3.AccentGlow, up3.AccentBright)
    r26.Color = r27
    r26.Parent = r27
    r27 = Instance.new("UIGradient")

    r34 = (r31 == "Parent")
    if r34 then

    end
    r27[r31] = r32

    r27.Parent = r26.Parent
    up6:MakeDraggable(r24)
    task.spawn(F.fn_090_function)
    r21.Activated:Connect(F.fn_094_function)
    r24.Activated:Connect(F.fn_093_function)
    r29 = {}
    r29.Current = nil
    r29.MainContainer = r15
    r29.CreateTab = F.fn_125_create_subtab

    do return r29 end
end

function F.fn_127_create_window()
    local r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13
    r0 = game:GetService("UserInputService")
    r1 = game:GetService("TweenService")
    r2 = game:GetService("RunService")
    r3 = game:GetService("CoreGui")
    r4 = game:GetService("Players")
    r6 = {}
    r6.Toggled = true
    r7 = Color3.fromRGB(0, 162, 255)
    r6.Accent = r7
    r6._blockDrag = false
    r7 = {}
    r8 = {}
    r8[1] = 16898613509
    r8[2] = 48
    r8[3] = 48
    r8[4] = 820
    r8[5] = 147
    r7.home = r8
    r8 = {}
    r8[1] = 16898613353
    r8[2] = 48
    r8[3] = 48
    r8[4] = 967
    r8[5] = 306
    r7.flame = r8
    r8 = {}
    r8[1] = 16898613777
    r8[2] = 48
    r8[3] = 48
    r8[4] = 771
    r8[5] = 257
    r7.settings = r8
    r8 = {}
    r8[1] = 16898613869
    r8[2] = 48
    r8[3] = 48
    r8[4] = 661
    r8[5] = 869
    r7.account = r8
    r8 = {}
    r8[1] = 16898613353
    r8[2] = 48
    r8[3] = 48
    r8[4] = 771
    r8[5] = 563
    r7.eye = r8
    r8 = {}
    r8[1] = 16898613613
    r8[2] = 48
    r8[3] = 48
    r8[4] = 820
    r8[5] = 257
    r7["map-pin"] = r8
    r8 = {}
    r8[1] = 16898612629
    r8[2] = 48
    r8[3] = 48
    r8[4] = 967
    r8[5] = 710
    r7["bar-chart-2"] = r8
    r8 = {}
    r8[1] = 16898613777
    r8[2] = 48
    r8[3] = 48
    r8[4] = 967
    r8[5] = 759
    r7.swords = r8
    r8 = {}
    r8[1] = 16898613869
    r8[2] = 48
    r8[3] = 48
    r8[4] = 661
    r8[5] = 869
    r7.user = r8
    r8 = {}
    r8[1] = 16898613777
    r8[2] = 48
    r8[3] = 48
    r8[4] = 869
    r8[5] = 0
    r7.shield = r8
    r8 = {}
    r8[1] = 16898613869
    r8[2] = 48
    r8[3] = 48
    r8[4] = 918
    r8[5] = 906
    r7.zap = r8
    r8 = {}
    r8[1] = 16898613869
    r8[2] = 48
    r8[3] = 48
    r8[4] = 514
    r8[5] = 771
    r7.target = r8
    r8 = {}
    r8[1] = 16898613509
    r8[2] = 48
    r8[3] = 48
    r8[4] = 771
    r8[5] = 563
    r7.globe = r8
    r8 = {}
    r8[1] = 16898613509
    r8[2] = 48
    r8[3] = 48
    r8[4] = 967
    r8[5] = 612
    r7.layout = r8
    r8 = {}
    r8[1] = 16898613699
    r8[2] = 48
    r8[3] = 48
    r8[4] = 918
    r8[5] = 857
    r7.search = r8
    r8 = {}
    r8[1] = 16898613699
    r8[2] = 48
    r8[3] = 48
    r8[4] = 918
    r8[5] = 453
    r7.save = r8
    r8 = {}
    r8[1] = 16898613777
    r8[2] = 48
    r8[3] = 48
    r8[4] = 404
    r8[5] = 771
    r7.sliders = r8
    r6.MakeDraggable = F.fn_071_function
    r6.GetIcon = F.fn_072_function
    r6.CreateWindow = F.fn_126_create_tab
    do return r6 end
end

function F.fn_128_function(arg1, arg2, arg3)
    local r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10
    r6 = type(arg1)
    r10 = (r6 == "table")
    if not r10 then

    end
    r7 = type(arg2)
    r10 = (r7 == "string")
    if not r10 then

    end
    r6 = arg2
    if r6 then

    end

    r7 = type(arg2)
    r10 = (r7 == "function")
    if not r10 then

    end
    r6 = arg2
    if r6 then

    end

    r6 = arg2
    if r6 then

    end
    r6 = {}

    do return r6, nil, arg3 end
end

function F.fn_129_function(arg1, arg2, arg3, arg4)
    local r0, r1, r2, r3, r4, r5, r6, r7, r8
    r4 = up0:CreateToggle(arg2, false, arg4)
    do return r4 end
end

function F.fn_130_function(arg1, arg2, arg3, arg4, arg5, arg6)
    local r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12
    r6 = up0:CreateSlider(arg2, arg5, arg4, arg5, arg6)
    do return r6 end
end

function F.fn_131_function(arg1, arg2, arg3, arg4)
    local r0, r1, r2, r3, r4, r5, r6, r7
    r4 = up0:CreateButton(arg2, arg4)
    do return r4 end
end

function F.fn_132_function(arg1, arg2, arg3, arg4, arg5)
    local r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13
    r5, r6, r7 = up0(arg3, arg4, arg5)
    r8 = up1:CreateDropdown(arg2, r5, r6, r7)
    do return r8 end
end

function F.fn_133_function(arg1, arg2)
    local r0, r1, r2, r3, r4
    r2 = up0:CreateLabel(arg2)
    do return r2 end
end

function F.fn_134_function(arg1, arg2, arg3, arg4)
    local r0, r1, r2, r3, r4, r5, r6, r7, r8
    r4 = up0:CreateInput(arg2, arg3, arg4)
    do return r4 end
end

function F.fn_135_function(arg1, arg2)
    local r0, r1, r2, r3, r4, r5, r6
    r2 = up0:CreateLabel("✦ " .. arg2)
    do return r2 end
end

function F.fn_136_function(arg1)
    local r0, r1
    do return up0 end
end

function F.fn_137_function()
    local r0, r1, r2
    up0:Set(false)
    do return end
end

function F.fn_138_function()
    local r0, r1
    pcall(F.fn_137_function)
    task.wait()
    up1 = false
    do return end
end

function F.fn_139_function(arg1)
    local r0, r1, r2
    r1 = up0
    if not r1 then

    end
    do return end

    r1 = _isPremiumUser()
    if not r1 then

    end
    r1 = up1
    if not r1 then

    end
    up1(arg1)
    do return end

    r0 = arg1
    if not r0 then

    end
    up2(up3)
    up0 = true
    task.defer(F.fn_138_function)

    do return end
end

function F.fn_140_function(arg1, arg2, arg3, arg4)
    local r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10
    r8 = _premTag(arg2)
    r6 = up0:CreateToggle(r8, false, F.fn_139_function)

    do return r6 end
end

function F.fn_141_function()
    local r0, r1
    r0 = _isPremiumUser()
    if not r0 then

    end
    r0 = up0
    if not r0 then

    end
    up0()
    do return end

    up1(up2)

    do return end
end

function F.fn_142_function(arg1, arg2, arg3, arg4)
    local r0, r1, r2, r3, r4, r5, r6, r7
    r6 = _premTag(arg2)
    r4 = up0:CreateButton(r6, F.fn_141_function)
    do return r4 end
end

function F.fn_143_function(arg1)
    local r0, r1, r2
    r1 = _isPremiumUser()
    if not r1 then

    end
    r1 = up0
    if not r1 then

    end
    up0(arg1)
    do return end

    up1(up2)

    do return end
end

function F.fn_144_function(arg1, arg2, arg3, arg4, arg5, arg6)
    local r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12
    r8 = _premTag(arg2)
    r9 = arg5
    if r9 then

    end

    r10 = arg4
    if r10 then

    end

    r11 = arg5
    if r11 then

    end

    r6 = up0:CreateSlider(r8, 0, 100, 0, F.fn_143_function)
    do return r6 end
end

function F.fn_145_function(arg1)
    local r0, r1, r2
    r1 = _isPremiumUser()
    if not r1 then

    end
    r1 = up0
    if not r1 then

    end
    up0(arg1)
    do return end

    up1(up2)

    do return end
end

function F.fn_146_function(arg1, arg2, arg3, arg4, arg5)
    local r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13
    r5, r6, r7 = up0(arg3, arg4, arg5)
    r10 = _premTag(arg2)
    r8 = up1:CreateDropdown(r10, r5, r6, F.fn_145_function)
    do return r8 end
end

function F.fn_147_premium_toggle(arg1, arg2)
    local r0, r1, r2, r3, r4, r5, r6, r7, r8
    r3 = arg2
    if r3 then

    end

    r3 = (""):lower()
    r4 = r3:find("combat", 1, true)
    if not r4 then

    end

    r4 = r3:find("visual", 1, true)
    if not r4 then

    end

    r4 = r3:find("main", 1, true)
    if r4 then

    end
    r4 = r3:find("home", 1, true)
    if not r4 then

    end

    r4 = r3:find("setting", 1, true)
    if r4 then

    end
    r4 = r3:find("config", 1, true)
    if not r4 then

    end

    r6 = arg2
    if r6 then

    end

    r4 = arg1.ActualTab:CreateSubTab("Main", "settings")
    r7 = arg2
    if r7 then

    end

    r5 = r4:CreateSection("Main")
    r6 = {}
    r6.NewToggle = F.fn_129_function
    r6.NewSlider = F.fn_130_function
    r6.NewButton = F.fn_131_function
    r6.NewDropdown = F.fn_132_function
    r6.NewLabel = F.fn_133_function
    r6.NewInput = F.fn_134_function
    r6.NewTitle = F.fn_135_function
    r6.NewSection = F.fn_136_function
    r6.NewPremiumToggle = F.fn_140_function
    r6.NewPremiumButton = F.fn_142_function
    r6.NewPremiumSlider = F.fn_144_function
    r6.NewPremiumDropdown = F.fn_146_function
    do return r6 end
end

function F.fn_148_function(arg1)
    local r0, r1, r2, r3
    arg1.ActualTab:SetVisible(false)
    do return end
end

function F.fn_149_function(arg1)
    local r0, r1, r2
    arg1.ActualTab:Select()
    do return end
end

function F.fn_150_create_tab(arg1, arg2)
    local r0, r1, r2, r3, r4, r5, r6, r7, r8
    r3 = arg2:lower()
    r4 = r3:find("aim", 1, true)
    if r4 then

    end
    r4 = r3:find("combat", 1, true)
    if r4 then

    end
    r4 = r3:find("kill", 1, true)
    if r4 then

    end
    r4 = r3:find("gun", 1, true)
    if not r4 then

    end

    r4 = r3:find("player", 1, true)
    if r4 then

    end
    r4 = r3:find("user", 1, true)
    if r4 then

    end
    r4 = r3:find("char", 1, true)
    if r4 then

    end
    r4 = r3:find("move", 1, true)
    if not r4 then

    end

    r4 = r3:find("visual", 1, true)
    if r4 then

    end
    r4 = r3:find("esp", 1, true)
    if r4 then

    end
    r4 = r3:find("eye", 1, true)
    if r4 then

    end
    r4 = r3:find("render", 1, true)
    if not r4 then

    end

    r4 = r3:find("setting", 1, true)
    if r4 then

    end
    r4 = r3:find("config", 1, true)
    if r4 then

    end
    r4 = r3:find("ui", 1, true)
    if not r4 then

    end

    r4 = r3:find("util", 1, true)
    if r4 then

    end
    r4 = r3:find("misc", 1, true)
    if r4 then

    end
    r4 = r3:find("tool", 1, true)
    if not r4 then

    end

    r4 = r3:find("game", 1, true)
    if r4 then

    end
    r4 = r3:find("hub", 1, true)
    if r4 then

    end
    r4 = r3:find("main", 1, true)
    if not r4 then

    end

    r4 = up0:CreateTab(arg2, "layout")
    r5 = {}
    r5.ActualTab = r4
    r5.NewSection = F.fn_147_premium_toggle
    r5.HideTabButton = F.fn_148_function
    r5.Select = F.fn_149_function
    do return r5 end
end

function F.fn_151_create_window(arg1, arg2)
    local r0, r1, r2, r3, r4
    r2 = up0:CreateWindow(arg1)
    r3 = {}
    r4 = {}
    r3.Tabs = r4
    r3.Window = r2
    r3.NewTab = F.fn_150_create_tab
    do return r3 end
end

function F.fn_152_function()
    local r0, r1
    do return up0.Character end
end

function F.fn_153_function()
    local r0, r1, r2, r3
    r1 = up0.Character
    if not r1 then

    end
    r1 = up0.Character:FindFirstChildWhichIsA("Humanoid")

    do return r1 end
end

function F.fn_154_function()
    local r0, r1, r2, r3
    r1 = up0.Character
    if not r1 then

    end
    r1 = up0.Character:FindFirstChild("HumanoidRootPart")

    do return r1 end
end

function F.fn_155_function(...)
    local r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15
    r0 = {}

    r2 = workspace:GetDescendants()
    r1, r2, r3 = pairs()

    r6, r7, r8 = pairs(r0)

    r11 = r5.Name:lower()
    r12 = r10:lower()
    r15 = (r11 == r12)
    if not r15 then

    end
    r11 = r5:IsA("IntValue")
    if r11 then

    end
    r11 = r5:IsA("NumberValue")
    if not r11 then

    end

    do return r5 end

    do return nil end
end

function F.fn_156_notify(arg1, arg2, arg3)
    local r0, r1, r2, r3, r4, r5, r6, r7, r8
    up0:Notify(arg1, arg2, arg3, false)
    do return end
end

function F.fn_157_function()
    local r0, r1, r2
    r1 = getgenv()
    r0 = r1.__SnowyLoadingOverlay
    if not r0 then

    end
    r0:Destroy()
    r1 = getgenv()
    r1.__SnowyLoadingOverlay = nil

    do return end
end

function F.fn_158_function()
    local r0, r1
    pcall(F.fn_157_function)
    do return end
end

function F.fn_159_function()
    local r0
    do return end
end

function F.fn_160_function()
    local r0
    do return up0 end
end

function F.fn_161_function()
    local r0
    do return up0 end
end

function F.fn_162_create_tab(arg1, arg2)
    local r0, r1, r2, r3, r4, r5, r6
    r2 = up0[arg1]
    if not r2 then

    end
    do return up1[arg1] end

    r5 = arg2
    if r5 then

    end

    r2 = up2.Window:CreateTab(arg1, "layout")
    r3 = r2:CreateSubTab("Main", "layout")
    r4 = r3:CreateSection("Features")
    up0[arg1] = r2
    up1[arg1] = r4
    do return r4 end
end

function F.fn_163_function(arg1, arg2, arg3, arg4)
    local r0, r1, r2, r3, r4, r5, r6, r7, r8
    r4 = up0:CreateToggle(arg2, false, arg4)
    do return r4 end
end

function F.fn_164_function(arg1, arg2, arg3, arg4)
    local r0, r1, r2, r3, r4, r5, r6, r7
    r4 = up0:CreateButton(arg2, arg4)
    do return r4 end
end

function F.fn_165_function(arg1, arg2, arg3, arg4, arg5, arg6)
    local r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12
    r9 = arg5
    if r9 then

    end

    r10 = arg4
    if r10 then

    end

    r11 = arg5
    if r11 then

    end

    r6 = up0:CreateSlider(arg2, 0, 100, 0, arg6)
    do return r6 end
end

function F.fn_166_function(arg1, arg2, arg3, arg4, arg5)
    local r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13
    r5, r6, r7 = up0(arg3, arg4, arg5)
    r8 = up1:CreateDropdown(arg2, r5, r6, r7)
    do return r8 end
end

function F.fn_167_function(arg1, arg2)
    local r0, r1, r2, r3, r4
    r2 = up0:CreateLabel(arg2)
    do return r2 end
end

function F.fn_168_function(arg1, arg2, arg3, arg4)
    local r0, r1, r2, r3, r4, r5, r6, r7, r8
    r4 = up0:CreateInput(arg2, arg3, arg4)
    do return r4 end
end

function F.fn_169_function(arg1, arg2)
    local r0, r1, r2, r3, r4, r5, r6
    r2 = up0:CreateLabel("✦ " .. arg2)
    do return r2 end
end

function F.fn_170_function(arg1)
    local r0, r1
    do return up0 end
end

function F.fn_171_function()
    local r0, r1, r2
    up0:Set(false)
    do return end
end

function F.fn_172_function()
    local r0, r1
    pcall(F.fn_171_function)
    task.wait()
    up1 = false
    do return end
end

function F.fn_173_function(arg1)
    local r0, r1, r2
    r1 = up0
    if not r1 then

    end
    do return end

    r1 = _isPremiumUser()
    if not r1 then

    end
    r1 = up1
    if not r1 then

    end
    up1(arg1)
    do return end

    r0 = arg1
    if not r0 then

    end
    up2(up3)
    up0 = true
    task.defer(F.fn_172_function)

    do return end
end

function F.fn_174_function(arg1, arg2, arg3, arg4)
    local r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10
    r8 = _premTag(arg2)
    r6 = up0:CreateToggle(r8, false, F.fn_173_function)

    do return r6 end
end

function F.fn_175_function()
    local r0, r1
    r0 = _isPremiumUser()
    if not r0 then

    end
    r0 = up0
    if not r0 then

    end
    up0()
    do return end

    up1(up2)

    do return end
end

function F.fn_176_function(arg1, arg2, arg3, arg4)
    local r0, r1, r2, r3, r4, r5, r6, r7
    r6 = _premTag(arg2)
    r4 = up0:CreateButton(r6, F.fn_175_function)
    do return r4 end
end

function F.fn_177_function(arg1)
    local r0, r1, r2
    r1 = _isPremiumUser()
    if not r1 then

    end
    r1 = up0
    if not r1 then

    end
    up0(arg1)
    do return end

    up1(up2)

    do return end
end

function F.fn_178_function(arg1, arg2, arg3, arg4, arg5, arg6)
    local r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12
    r8 = _premTag(arg2)
    r9 = arg5
    if r9 then

    end

    r10 = arg4
    if r10 then

    end

    r11 = arg5
    if r11 then

    end

    r6 = up0:CreateSlider(r8, 0, 100, 0, F.fn_177_function)
    do return r6 end
end

function F.fn_179_function(arg1)
    local r0, r1, r2
    r1 = _isPremiumUser()
    if not r1 then

    end
    r1 = up0
    if not r1 then

    end
    up0(arg1)
    do return end

    up1(up2)

    do return end
end

function F.fn_180_function(arg1, arg2, arg3, arg4, arg5)
    local r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13
    r5, r6, r7 = up0(arg3, arg4, arg5)
    r10 = _premTag(arg2)
    r8 = up1:CreateDropdown(r10, r5, r6, F.fn_179_function)
    do return r8 end
end

function F.fn_181_premium_toggle(arg1, arg2)
    local r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13
    r2 = arg2
    if r2 then

    end

    r3 = ("General"):lower()
    r6 = r3:find("free feat")
    if not r6 then

    end

    r6 = r3:find("premium feat")
    if not r6 then

    end

    r6 = r3:find("combat")
    if r6 then

    end
    r6 = r3:find("aimbot")
    if r6 then

    end
    r6 = r3:find("aim")
    if r6 then

    end
    r6 = r3:find("weapon")
    if r6 then

    end
    r6 = r3:find("gun")
    if r6 then

    end
    r6 = r3:find("silent")
    if r6 then

    end
    r6 = r3:find("aura")
    if not r6 then

    end

    r6 = r3:find("esp")
    if r6 then

    end
    r6 = r3:find("visual")
    if r6 then

    end
    r6 = r3:find("wallhack")
    if r6 then

    end
    r6 = r3:find("radar")
    if r6 then

    end
    r6 = r3:find("chams")
    if r6 then

    end
    r6 = r3:find("render")
    if not r6 then

    end

    r6 = r3:find("move")
    if r6 then

    end
    r6 = r3:find("fly")
    if r6 then

    end
    r6 = r3:find("speed")
    if r6 then

    end
    r6 = r3:find("noclip")
    if r6 then

    end
    r6 = r3:find("jump")
    if r6 then

    end
    r6 = r3:find("travel")
    if r6 then

    end
    r6 = r3:find("tp")
    if r6 then

    end
    r6 = r3:find("teleport")
    if not r6 then

    end

    r6 = r3:find("farm")
    if r6 then

    end
    r6 = r3:find("auto")
    if r6 then

    end
    r6 = r3:find("fish")
    if r6 then

    end
    r6 = r3:find("chest")
    if r6 then

    end
    r6 = r3:find("collect")
    if r6 then

    end
    r6 = r3:find("resource")
    if not r6 then

    end

    r6 = r3:find("survival")
    if r6 then

    end
    r6 = r3:find("god")
    if r6 then

    end
    r6 = r3:find("oxygen")
    if r6 then

    end
    r6 = r3:find("survive")
    if r6 then

    end
    r6 = r3:find("anti")
    if not r6 then

    end

    r6 = r3:find("troll")
    if r6 then

    end
    r6 = r3:find("rage")
    if r6 then

    end
    r6 = r3:find("hitbox")
    if not r6 then

    end

    r6 = r3:find("misc")
    if r6 then

    end
    r6 = r3:find("util")
    if r6 then

    end
    r6 = r3:find("extra")
    if r6 then

    end
    r6 = r3:find("general")
    if r6 then

    end
    r6 = r3:find("server")
    if not r6 then

    end

    r6 = r3:find("economy")
    if r6 then

    end
    r6 = r3:find("money")
    if r6 then

    end
    r6 = r3:find("shop")
    if not r6 then

    end

    r6 = r3:find("belt")
    if not r6 then

    end

    r6 = r3:find("tank")
    if not r6 then

    end

    r6 = r3:find("slot")
    if not r6 then

    end

    r9 = up0["Slots"]
    if not r9 then

    end

    r12 = "layout"
    if r12 then

    end

    r9 = up2.Window:CreateTab("Slots", "layout")
    r10 = r9:CreateSubTab("Main", "layout")
    r11 = r10:CreateSection("Features")
    up0["Slots"] = r9
    up1["Slots"] = r11

    r11:CreateLabel("── " .. "General" .. " ──")
    r7 = {}
    r7.NewToggle = F.fn_163_function
    r7.NewButton = F.fn_164_function
    r7.NewSlider = F.fn_165_function
    r7.NewDropdown = F.fn_166_function
    r7.NewLabel = F.fn_167_function
    r7.NewInput = F.fn_168_function
    r7.NewTitle = F.fn_169_function
    r7.NewSection = F.fn_170_function
    r7.NewPremiumToggle = F.fn_174_function
    r7.NewPremiumButton = F.fn_176_function
    r7.NewPremiumSlider = F.fn_178_function
    r7.NewPremiumDropdown = F.fn_180_function
    do return r7 end
end

function F.fn_182_function()
    local r0
    do return end
end

function F.fn_183_premium_toggle(arg1, arg2)
    local r0, r1, r2, r3, r4, r5, r6, r7, r8
    r2 = up0
    if not r2 then

    end
    r2 = up0.name:lower()
    r3 = arg1:lower()
    r8 = (r2 == r3)
    if r8 then

    end

    r3 = {}
    r3.NewToggle = F.fn_159_function
    r3.NewButton = F.fn_159_function
    r3.NewSlider = F.fn_159_function
    r3.NewDropdown = F.fn_159_function
    r3.NewLabel = F.fn_159_function
    r3.NewPremiumToggle = F.fn_159_function
    r3.NewPremiumButton = F.fn_159_function
    r3.NewPremiumSlider = F.fn_159_function
    r3.NewPremiumDropdown = F.fn_159_function
    r3.NewSection = F.fn_160_function
    r4 = {}
    r4.NewSection = F.fn_161_function
    r4.NewToggle = F.fn_159_function
    r4.NewButton = F.fn_159_function
    r4.NewSlider = F.fn_159_function
    r4.NewDropdown = F.fn_159_function
    r4.NewPremiumToggle = F.fn_159_function
    r4.NewPremiumButton = F.fn_159_function
    r4.NewPremiumSlider = F.fn_159_function
    r4.NewPremiumDropdown = F.fn_159_function
    do return r4 end

    r2 = {}
    r3 = {}
    r5 = {}
    r5.NewSection = F.fn_181_premium_toggle
    r5.NewToggle = F.fn_182_function
    r5.NewButton = F.fn_182_function
    r5.NewSlider = F.fn_182_function
    do return r5 end
end

function F.fn_184_function(arg1, arg2)
    local r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20
    r2 = arg1
    if r2 then

    end

    r2 = (""):lower()
    r3 = arg2
    if r3 then

    end

    r3 = (""):lower()
    r4 = {}
    r4[1] = "auto"
    r4[2] = "farm"
    r4[3] = "kill"
    r4[4] = "aura"
    r4[5] = "tp"
    r4[6] = "teleport"
    r4[7] = "fly"
    r4[8] = "speed"
    r4[9] = "click"
    r4[10] = "mansion"
    r4[11] = "oil"
    r4[12] = "ship"
    r4[13] = "airdrop"
    r4[14] = "rob"
    r4[15] = "npc"
    r4[16] = "turret"
    r4[17] = "glider"
    r4[18] = "items"
    r4[19] = "give"
    r5, r6, r7 = ipairs(r4)

    r10 = r2:find("tp", 1, true)
    if r10 then

    end
    r10 = r3:find("tp", 1, true)
    if not r10 then

    end

    do return true end

    do return false end
end

function F.fn_185_function(arg1, arg2)
    local r0, r1
    do return arg1 end
end

function F.fn_186_premium_button(arg1, arg2)
    local r0, r1, r2, r3, r4, r5, r6, r7
    r3 = arg2.Title
    if r3 then

    end

    r4 = arg2.Description
    if r4 then

    end

    r2 = up0(arg2.Name, arg2.Desc)
    if not r2 then

    end
    r5 = arg2.Title
    if r5 then

    end
    r5 = arg2.Name
    if r5 then

    end

    r6 = arg2.Description
    if r6 then

    end
    r6 = arg2.Desc
    if r6 then

    end

    up1:NewPremiumButton("Button", "", arg2.Callback)
    do return end

    r5 = arg2.Title
    if r5 then

    end
    r5 = arg2.Name
    if r5 then

    end

    r6 = arg2.Description
    if r6 then

    end
    r6 = arg2.Desc
    if r6 then

    end

    up2:NewButton("Button", "", arg2.Callback)
    do return end
end

function F.fn_187_function()
    local r0, r1
    up0(up1)
    do return end
end

function F.fn_188_function(arg1)
    local r0, r1, r2
    r1 = up0
    if not r1 then

    end
    pcall(F.fn_187_function)

    do return end
end

function F.fn_189_function()
    local r0, r1
    up0(up1)
    do return end
end

function F.fn_190_function(arg1)
    local r0, r1, r2
    r1 = up0
    if not r1 then

    end
    pcall(F.fn_189_function)

    do return end
end

function F.fn_191_function()
    local r0, r1, r2
    up0:Set(up1)
    do return end
end

function F.fn_192_function(arg1, arg2)
    local r0, r1, r2
    up0 = arg2
    do return up1 end
end

function F.fn_193_function()
    local r0, r1, r2
    up0:Set(up1)
    do return end
end

function F.fn_194_function(arg1, arg2)
    local r0, r1, r2, r3
    pcall(F.fn_193_function)
    do return end
end

function F.fn_195_premium_toggle(arg1, arg2, arg3)
    local r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15
    r3 = arg3
    if r3 then

    end

    r4 = arg2.Title
    if r4 then

    end
    r4 = arg2.Name
    if r4 then

    end

    r5 = arg2.Description
    if r5 then

    end
    r5 = arg2.Desc
    if r5 then

    end

    r7 = arg2.Default
    if r7 then

    end

    r8 = up0("Toggle", "")
    if not r8 then

    end
    r11 = up1:NewPremiumToggle("Toggle", "", F.fn_188_function)

    r11 = up2:NewToggle("Toggle", "", F.fn_190_function)

    r7 = false
    if not r7 then

    end
    r10 = r11
    if not r10 then

    end
    r11 = r10.Set
    if not r11 then

    end
    pcall(F.fn_191_function)

    r11 = {}
    r11.OnChanged = F.fn_192_function
    r11.SetValue = F.fn_194_function

    do return r11 end
end

function F.fn_196_function()
    local r0, r1
    up0(up1)
    do return end
end

function F.fn_197_function(arg1)
    local r0, r1, r2
    r1 = up0
    if not r1 then

    end
    pcall(F.fn_196_function)

    do return end
end

function F.fn_198_function()
    local r0, r1
    up0(up1)
    do return end
end

function F.fn_199_function(arg1)
    local r0, r1, r2
    r1 = up0
    if not r1 then

    end
    pcall(F.fn_198_function)

    do return end
end

function F.fn_200_function()
    local r0, r1, r2
    up0:Set(up1)
    do return end
end

function F.fn_201_function(arg1, arg2)
    local r0, r1, r2
    up0 = arg2
    do return up1 end
end

function F.fn_202_function()
    local r0, r1, r2
    up0:Set(up1)
    do return end
end

function F.fn_203_function(arg1, arg2)
    local r0, r1, r2, r3
    pcall(F.fn_202_function)
    do return end
end

function F.fn_204_premium_slider(arg1, arg2, arg3)
    local r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18, r19
    r3 = arg3
    if r3 then

    end

    r4 = arg2.Title
    if r4 then

    end
    r4 = arg2.Name
    if r4 then

    end

    r5 = arg2.Description
    if r5 then

    end
    r5 = arg2.Desc
    if r5 then

    end

    r7 = arg2.Min
    if r7 then

    end

    r8 = arg2.Max
    if r8 then

    end

    r9 = arg2.Default
    if r9 then

    end

    r10 = up0("Slider", "")
    if not r10 then

    end
    r13 = up1:NewPremiumSlider("Slider", "", 100, 0, F.fn_197_function)

    r13 = up2:NewSlider("Slider", "", 100, 0, F.fn_199_function)

    r9 = 0
    if not r9 then

    end
    r12 = r13
    if not r12 then

    end
    r13 = r12.Set
    if not r13 then

    end
    pcall(F.fn_200_function)

    r13 = {}
    r13.OnChanged = F.fn_201_function
    r13.SetValue = F.fn_203_function

    do return r13 end
end

function F.fn_205_function()
    local r0, r1
    up0(up1)
    do return end
end

function F.fn_206_function(arg1)
    local r0, r1, r2
    r1 = up0
    if not r1 then

    end
    pcall(F.fn_205_function)

    do return end
end

function F.fn_207_function()
    local r0, r1
    up0(up1)
    do return end
end

function F.fn_208_function(arg1)
    local r0, r1, r2
    r1 = up0
    if not r1 then

    end
    pcall(F.fn_207_function)

    do return end
end

function F.fn_209_function()
    local r0, r1, r2
    up0:Set(up1)
    do return end
end

function F.fn_210_function(arg1, arg2)
    local r0, r1, r2
    up0 = arg2
    do return up1 end
end

function F.fn_211_function()
    local r0, r1, r2
    up0:Set(up1)
    do return end
end

function F.fn_212_function(arg1, arg2)
    local r0, r1, r2, r3
    pcall(F.fn_211_function)
    do return end
end

function F.fn_213_premium_dropdown(arg1, arg2, arg3)
    local r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17
    r3 = arg3
    if r3 then

    end

    r4 = arg2.Title
    if r4 then

    end
    r4 = arg2.Name
    if r4 then

    end

    r5 = arg2.Description
    if r5 then

    end
    r5 = arg2.Desc
    if r5 then

    end

    r7 = arg2.Values
    if r7 then

    end
    r7 = arg2.List
    if r7 then

    end
    r7 = {}

    r8 = arg2.Default
    if r8 then

    end

    r9 = up0("Dropdown", "")
    if not r9 then

    end
    r12 = up1:NewPremiumDropdown("Dropdown", "", r7, F.fn_206_function)

    r12 = up2:NewDropdown("Dropdown", "", r7, F.fn_208_function)

    r8 = nil
    if not r8 then

    end
    r11 = r12
    if not r11 then

    end
    r12 = r11.Set
    if not r12 then

    end
    pcall(F.fn_209_function)

    r12 = {}
    r12.OnChanged = F.fn_210_function
    r12.SetValue = F.fn_212_function

    do return r12 end
end

function F.fn_214_function(arg1, arg2)
    local r0, r1, r2, r3, r4
    up0:NewLabel(arg2)
    do return end
end

function F.fn_215_function(arg1, arg2)
    local r0, r1, r2, r3, r4, r5, r6, r7, r8
    r5 = arg2.Title
    if r5 then

    end

    r7 = arg2.Content
    if r7 then

    end

    up0:NewLabel("(" .. "): " .. "")
    do return end
end

function F.fn_216_function(arg1, arg2)
    local r0, r1
    do return arg1 end
end

function F.fn_217_function(arg1, arg2)
    local r0, r1
    do return end
end

function F.fn_218_function(arg1, arg2, arg3)
    local r0, r1, r2, r3, r4
    r3 = {}
    r3.OnChanged = F.fn_216_function
    r3.SetValue = F.fn_217_function
    do return r3 end
end

function F.fn_219_function(arg1, arg2)
    local r0, r1
    do return arg1 end
end

function F.fn_220_function(arg1, arg2)
    local r0, r1
    do return end
end

function F.fn_221_function(arg1, arg2, arg3)
    local r0, r1, r2, r3, r4
    r3 = {}
    r3.OnChanged = F.fn_219_function
    r3.SetValue = F.fn_220_function
    do return r3 end
end

function F.fn_222_function(arg1, arg2)
    local r0, r1, r2, r3
    r2 = {}
    r2.AddSection = F.fn_185_function
    r2.AddButton = F.fn_186_premium_button
    r2.AddToggle = F.fn_195_premium_toggle
    r2.AddSlider = F.fn_204_premium_slider
    r2.AddDropdown = F.fn_213_premium_dropdown
    r2.AddLabel = F.fn_214_function
    r2.AddParagraph = F.fn_215_function
    r2.AddKeybind = F.fn_218_function
    r2.AddColorpicker = F.fn_221_function
    do return r2 end
end

function F.fn_223_function(arg1, arg2)
    local r0, r1
    do return end
end

function F.fn_224_function(arg1, arg2)
    local r0, r1, r2, r3
    r2 = {}
    r2.AddTab = F.fn_222_function
    r2.SelectTab = F.fn_223_function
    do return r2 end
end

function F.fn_225_notify()
    local r0, r1, r2, r3, r4, r5, r6
    r2 = up1.Title
    if r2 then

    end

    r3 = up1.Content
    if r3 then

    end
    r3 = up1.Text
    if r3 then

    end

    r4 = up1.Duration
    if r4 then

    end

    up0:Notify("Notification", "", 3)
    do return end
end

function F.fn_226_function(arg1, arg2)
    local r0, r1, r2, r3
    pcall(F.fn_225_notify)
    do return end
end

function F.fn_227_create_window(arg1)
    local r0, r1, r2, r3, r4, r5, r6
    r1 = up0(arg1, arg1)
    r2 = {}
    r3 = r1:NewSection("Free Features")
    r4 = r1:NewSection("Premium Features")
    r2.CreateWindow = F.fn_224_function
    r2.Notify = F.fn_226_function
    do return r2 end
end

function F.fn_228_disconnect_player_modifier_loop()
    local r0, r1
    r1 = getgenv()
    r1.PlayerModifierLoop:Disconnect()
    do return end
end

function F.fn_229_enable_dead_state()
    local r0, r1, r2, r3
    up0:SetStateEnabled(Enum.HumanoidStateType.Dead, false)
    do return end
end

function F.fn_230_apply_god_mode()
    local r0, r1, r2, r3, r4, r5
    r0 = game.Players.LocalPlayer.Character
    if not r0 then

    end
    r1 = r0:FindFirstChild("Humanoid")
    if not r1 then

    end
    r1 = r0:FindFirstChild("HumanoidRootPart")
    if not r1 then

    end
    r3 = getgenv()
    r2 = r3.GodModeEnabled
    if not r2 then

    end
    r5 = (r0.Humanoid.MaxHealth == (math.huge))
    if r5 then

    end
    r0.Humanoid.MaxHealth = (math.huge)

    r5 = (r0.Humanoid.Health == (math.huge))
    if r5 then

    end
    r0.Humanoid.Health = (math.huge)

    pcall(F.fn_229_enable_dead_state)

    do return end
end

function F.fn_231_safe_apply_god_mode(arg1)
    local r0, r1, r2
    pcall(F.fn_230_apply_god_mode)
    do return end
end

function F.fn_232_apply_walk_speed(arg1)
    local r0, r1, r2, r3
    r1 = getgenv()
    r1.WalkSpeedValue = arg1
    r1 = game.Players.LocalPlayer.Character
    if not r1 then

    end
    r1 = game.Players.LocalPlayer.Character:FindFirstChild("Humanoid")
    if not r1 then

    end
    game.Players.LocalPlayer.Character.Humanoid.WalkSpeed = arg1

    do return end
end

function F.fn_233_apply_jump_power(arg1)
    local r0, r1, r2, r3
    r1 = getgenv()
    r1.JumpPowerValue = arg1
    r1 = game.Players.LocalPlayer.Character
    if not r1 then

    end
    r1 = game.Players.LocalPlayer.Character:FindFirstChild("Humanoid")
    if not r1 then

    end
    game.Players.LocalPlayer.Character.Humanoid.JumpPower = arg1

    do return end
end

function F.fn_234_apply_gravity(arg1)
    local r0, r1
    game.Workspace.Gravity = arg1
    do return end
end

function F.fn_235_restore_humanoid()
    local r0, r1, r2, r3, r4
    r0 = game.Players.LocalPlayer.Character
    if not r0 then

    end
    r1 = r0:FindFirstChild("Humanoid")
    if not r1 then

    end
    r0.Humanoid.MaxHealth = 100
    r0.Humanoid.Health = 100
    r0.Humanoid:SetStateEnabled(Enum.HumanoidStateType.Dead, true)

    do return end
end

function F.fn_236_toggle_god_mode(arg1)
    local r0, r1, r2
    r1 = getgenv()
    r1.GodModeEnabled = arg1
    r0 = arg1
    if r0 then

    end
    pcall(F.fn_235_restore_humanoid)

    do return end
end

function F.fn_237_noclip_loop()
    local r0, r1, r2, r3, r4, r5, r6, r7, r8, r9
    r9 = (up0 == false)
    if not r9 then

    end
    r9 = (game.Players.LocalPlayer.Character == nil)
    if r9 then

    end
    r1 = game.Players.LocalPlayer.Character:GetDescendants()
    r0, r1, r2 = pairs()

    r5 = r4:IsA("BasePart")
    if not r5 then

    end
    r5 = r4.CanCollide
    if not r5 then

    end
    r9 = (r4.Name == floatName)
    if r9 then

    end
    r4.CanCollide = false

    wait(0.21)
    do return end
end

function F.fn_238_start_noclip()
    local r0, r1, r2, r3, r4
    up0 = false
    r2 = game:GetService("RunService")
    r1 = r2.Stepped:Connect(F.fn_237_noclip_loop)
    up1 = r1
    do return end
end

function F.fn_239_stop_noclip()
    local r0, r1
    r0 = up0
    if not r0 then

    end
    up0:Disconnect()

    up1 = true
    do return end
end

function F.fn_240_set_noclip(arg1)
    local r0, r1
    r0 = arg1
    if not r0 then

    end
    noclip()
    do return end

    clip()
    do return end
end

function F.fn_241_force_jump()
    local r0, r1, r2
    r0 = up0
    if not r0 then

    end
    r0 = game.Players.LocalPlayer.Character
    if not r0 then

    end
    r0 = game.Players.LocalPlayer.Character:FindFirstChild("Humanoid")
    if not r0 then

    end
    game.Players.LocalPlayer.Character.Humanoid:ChangeState("Jumping")

    do return end
end

function F.fn_242_install_infinite_jump(arg1)
    local r0, r1, r2, r3, r4
    up0 = arg1
    r2 = game:GetService("UserInputService")
    r2.JumpRequest:Connect(F.fn_241_force_jump)
    do return end
end

function F.fn_243_set_camera_fov(arg1)
    local r0, r1
    game.Workspace.CurrentCamera.FieldOfView = arg1
    do return end
end

function F.fn_244_apply_lighting(arg1)
    local r0, r1, r2, r3, r4, r5
    r0 = arg1
    if not r0 then

    end
    r2 = Color3.new(1, 1, 1)
    game.Lighting.Ambient = r2
    r2 = Color3.new(1, 1, 1)
    game.Lighting.ColorShift_Bottom = r2
    r2 = Color3.new(1, 1, 1)
    game.Lighting.ColorShift_Top = r2
    game.Lighting.GlobalShadows = false
    do return end

    r2 = Color3.fromRGB(128, 128, 128)
    game.Lighting.Ambient = r2
    game.Lighting.GlobalShadows = true
    do return end
end

function F.fn_245_create_player_esp(arg1)
    local r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11
    r0 = arg1
    if not r0 then

    end
    r2 = game.Players:GetPlayers()
    r1, r2, r3 = pairs()

    r11 = (r5 == game.Players.LocalPlayer)
    if r11 then

    end
    r6 = r5.Character
    if not r6 then

    end
    r6 = Instance.new("Highlight")
    r6.Parent = r5.Character
    r6.FillColor = up0.AccentColor
    r6.OutlineColor = up0.SecondaryColor
    r6.FillTransparency = 0.5
    table.insert(up1, r6)

    do return end

    r1, r2, r3 = pairs(up1)

    if not r5 then

    end
    r6 = r5.Parent
    if not r6 then

    end
    r5:Destroy()

    r1 = {}
    up1 = r1
    do return end
end

function F.fn_246_expand_hitbox_for_character()
    local r0, r1, r2, r3, r4, r5
    r1 = Vector3.new(_G.HeadSize, _G.HeadSize, _G.HeadSize)
    up0.Character.HumanoidRootPart.Size = r1
    up0.Character.HumanoidRootPart.Transparency = 0.7
    r1 = BrickColor.new("Really blue")
    up0.Character.HumanoidRootPart.BrickColor = r1
    up0.Character.HumanoidRootPart.Material = "Neon"
    up0.Character.HumanoidRootPart.CanCollide = false
    do return end
end

function F.fn_247_apply_hitboxes()
    local r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12
    r0 = _G.Disabled
    if not r0 then

    end
    r1 = game:GetService("Players")
    r1, r2 = r1:GetPlayers()

    r8 = game:GetService("Players")
    r12 = (r4.Name == r8.LocalPlayer.Name)
    if r12 then

    end
    pcall(F.fn_246_expand_hitbox_for_character)

    do return end
end

function F.fn_248_start_hitbox_loop(arg1)
    local r0, r1, r2, r3, r4
    _G.HeadSize = arg1
    _G.Disabled = true
    r2 = game:GetService("RunService")
    r2.RenderStepped:connect(F.fn_247_apply_hitboxes)
    do return end
end

function F.fn_249_give_hammer_tool()
    local r0, r1, r2, r3, r4, r5
    r0 = Instance.new("HopperBin", game.Players.LocalPlayer.Backpack)
    r0.BinType = "Clone"
    r1 = Instance.new("HopperBin", game.Players.LocalPlayer.Backpack)
    r1.BinType = "Hammer"
    r2 = Instance.new("HopperBin", game.Players.LocalPlayer.Backpack)
    r2.BinType = "Grab"
    do return end
end

function F.fn_250_teleport_random_player()
    local r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10
    r0 = game.Players:GetPlayers()
    r10 = (1 < #r0)
    if not r10 then

    end
    r2 = math.random(1, #r0)

    r2 = math.random(1, #r0)
    r10 = (r0[r2].Name == game.Players.LocalPlayer.Name)
    if not r10 then

    end

    r2 = r0[r2].Character
    if not r2 then

    end
    r2 = r0[r2].Character:FindFirstChild("HumanoidRootPart")
    if not r2 then

    end
    r2 = game.Players.LocalPlayer.Character
    if not r2 then

    end
    r2 = game.Players.LocalPlayer.Character:FindFirstChild("HumanoidRootPart")
    if not r2 then

    end
    r5 = CFrame.new(0, 0, 3)
    game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = (r0[r2].Character.HumanoidRootPart.CFrame * r5)

    do return end
end

function F.fn_251_rejoin_server()
    local r0, r1, r2, r3, r4
    r0 = game:GetService("TeleportService")
    r0:TeleportToPlaceInstance(game.PlaceId, game.JobId, game.Players.LocalPlayer)
    do return end
end

function F.fn_252_decode_server_page(arg1)
    local r0, r1, r2, r3, r4, r5, r6, r7
    r0 = arg1
    if not r0 then

    end
    r5 = "&cursor=" .. r0
    if r5 then

    end

    r1 = game:HttpGet(up0 .. "")
    r2 = up1:JSONDecode(r1)
    do return r2 end
end

function F.fn_253_server_hop()
    local r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15
    r0 = game:GetService("HttpService")
    r1 = game:GetService("TeleportService")
    r7 = tostring(game.PlaceId)

    r8 = nil
    if not r8 then

    end
    r13 = "&cursor=" .. r8
    if r13 then

    end

    r9 = game:HttpGet("https://games.roblox.com/v1/games/" .. r7 .. "/servers/Public?sortOrder=Asc&limit=100" .. "")
    r10 = r0:JSONDecode(r9)
    r5 = r10.data[1]
    if r5 then

    end

    r1:TeleportToPlaceInstance(game.PlaceId, r5.id, game.Players.LocalPlayer)
    do return end
end

function F.fn_254_anti_afk(arg1)
    local r0, r1, r2, r3, r4, r5, r6, r7, r8
    r1 = getconnections
    if r1 then

    end

    r0 = arg1
    if not r0 then

    end
    r1 = get_signal_cons
    if not r1 then

    end
    r3 = r1(game.Players.LocalPlayer.Idled)
    r2, r3, r4 = pairs()

    r7 = r6.Disable
    if not r7 then

    end
    r6.Disable(r6)

    r7 = r6.Disconnect
    if not r7 then

    end
    r6.Disconnect(r6)

    do return end
end

function F.fn_255_get_aimbot_target()
    local r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16
    r2 = game:GetService("UserInputService")
    r2 = r2:GetMouseLocation()
    r4 = game.Players:GetPlayers()
    r3, r4, r5 = pairs()

    r16 = (r7 == game.Players.LocalPlayer)
    if r16 then

    end
    r8 = r7.Character
    if not r8 then

    end
    r8 = r7.Character:FindFirstChild(up0.TargetPart)
    if not r8 then

    end
    r8 = r7.Character:FindFirstChild("Humanoid")
    if not r8 then

    end
    r16 = (0 < r7.Character.Humanoid.Health)
    if not r16 then

    end
    r8 = up0.TeamCheck
    if not r8 then

    end
    r16 = (r7.Team == game.Players.LocalPlayer.Team)
    if not r16 then

    end

    r8, r9 = game.Workspace.CurrentCamera:WorldToViewportPoint(r7.Character[up0.TargetPart].Position)
    if not r9 then

    end
    r12 = Vector2.new(r8.X, r8.Y)
    r16 = ((r12 - r2).Magnitude < up0.FOVRadius)
    if not r16 then

    end

    do return r7 end
end

function F.fn_256_aimbot_render_step()
    local r0, r1, r2, r3, r4, r5, r6, r7, r8
    r0 = up0.ShowFOV
    if not r0 then

    end
    r1 = game:GetService("UserInputService")
    r1 = r1:GetMouseLocation()
    up1.Position = r1
    up1.Radius = up0.FOVRadius
    up1.Visible = true

    up1.Visible = false

    r0 = up0.Enabled
    if not r0 then

    end
    r0 = game:GetService("UserInputService")
    r0 = r0:IsMouseButtonPressed(Enum.UserInputType.MouseButton2)
    if not r0 then

    end
    r0 = up2()
    if not r0 then

    end
    r1 = r0.Character
    if not r1 then

    end
    r1 = r0.Character:FindFirstChild(up0.TargetPart)
    if not r1 then

    end
    r2 = CFrame.new(game.Workspace.CurrentCamera.CFrame.Position, r0.Character[up0.TargetPart].Position)
    r3 = game.Workspace.CurrentCamera.CFrame:Lerp(r2, up0.Smoothness)
    game.Workspace.CurrentCamera.CFrame = r3

    do return end
end

function F.fn_257_set_aimbot_enabled(arg1)
    local r0, r1
    up0.Enabled = arg1
    do return end
end

function F.fn_258_set_show_fov(arg1)
    local r0, r1
    up0.ShowFOV = arg1
    do return end
end

function F.fn_259_set_fov_radius(arg1)
    local r0, r1
    up0.FOVRadius = arg1
    do return end
end

function F.fn_260_set_aimbot_smoothness(arg1)
    local r0, r1, r2
    up0.Smoothness = (arg1 / 100)
    do return end
end

function F.fn_261_set_team_check(arg1)
    local r0, r1
    up0.TeamCheck = arg1
    do return end
end

function F.fn_262_test_notification()
    local r0, r1, r2, r3, r4, r5
    up0:Notify("Test", "Notifications are working!", 4, false)
    do return end
end

function F.fn_263_test_premium_notification()
    local r0, r1, r2, r3, r4, r5
    up0:Notify("Premium Alert", "This is how premium alerts look!", 4, true)
    do return end
end

function F.fn_264_function()
    local r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10
    r1 = getgenv()
    r0, r1, r2 = pairs()

    r5 = type(r3)
    r10 = (r5 == "string")
    if not r10 then

    end
    r5 = r3:sub(1, 3)
    r10 = (r5 == "_h_")
    if not r10 then

    end
    r5 = typeof(r4)
    r10 = (r5 == "Instance")
    if not r10 then

    end
    r5 = r4:IsA("ScreenGui")
    if not r5 then

    end
    r5 = r4:FindFirstChild("Main")
    if not r5 then

    end
    r5.BackgroundTransparency = up0

    do return end
end

function F.fn_265_function(arg1)
    local r0, r1, r2
    up0 = (arg1 / 10)
    pcall(F.fn_264_function)
    do return end
end

function F.fn_266_copy_discord()
    local r0, r1, r2, r3, r4, r5
    r0 = setclipboard
    if not r0 then

    end
    setclipboard("https://discord.gg/getsnowy")

    up0:Notify("Copied!", "Discord link copied.", 3, false)
    do return end
end

function F.fn_267_destroy_ui()
    local r0, r1
    up0:Destroy()
    do return end
end

function F.fn_268_function()
    local r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10
    r1 = getgenv()
    r0, r1, r2 = pairs()

    r5 = type(r3)
    r10 = (r5 == "string")
    if not r10 then

    end
    r5 = r3:sub(1, 3)
    r10 = (r5 == "_h_")
    if not r10 then

    end
    r5 = typeof(r4)
    r10 = (r5 == "Instance")
    if not r10 then

    end
    r5 = r4:IsA("ScreenGui")
    if not r5 then

    end
    pcall(F.fn_267_destroy_ui)
    r5 = getgenv()
    r5[r3] = nil

    do return end
end

function F.fn_269_reload_ui()
    local r0, r1, r2, r3, r4, r5
    pcall(F.fn_268_function)
    task.wait(0.1)
    r0 = getgenv()
    r1 = up0.CreateLib(up1.HubName, "Midnight")
    r0.Window = r1
    up2:Notify("Reloaded", "Hub UI restarted.", 3, false)
    do return end
end

function F.fn_270_function()
    local r0
    do return end
end

function F.fn_271_function()
    local r0
    do return up0 end
end

function F.fn_272_function()
    local r0
    do return up0 end
end

function F.fn_273_premium_toggle()
    local r0, r1, r2, r3
    r1 = {}
    r1.NewToggle = F.fn_270_function
    r1.NewButton = F.fn_270_function
    r1.NewSlider = F.fn_270_function
    r1.NewDropdown = F.fn_270_function
    r1.NewLabel = F.fn_270_function
    r1.NewPremiumToggle = F.fn_270_function
    r1.NewPremiumButton = F.fn_270_function
    r1.NewPremiumSlider = F.fn_270_function
    r1.NewPremiumDropdown = F.fn_270_function
    r1.NewSection = F.fn_271_function
    r2 = {}
    r2.NewSection = F.fn_272_function
    r2.HideTabButton = F.fn_270_function
    r2.Select = F.fn_270_function
    r3 = {}
    r3.SetVisible = F.fn_270_function
    r2.ActualTab = r3
    do return r2 end
end

function F.fn_274_load_ps99_external()
    local r0, r1, r2, r3, r4
    r1 = game:HttpGet("https://raw.githubusercontent.com/Kurbywtww/snowy/refs/heads/main/99.lua")
    r0 = loadstring()
    r0()
    up0:Notify("PS99 Loaded", "Snowy automation is starting up!", 5)
    do return end
end

function F.snowy_hub_main(...)
    local r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20, r21, r22, r23, r24, r25, r26, r27, r28, r29, r30, r31, r32, r33, r34, r35, r36, r37, r38, r39, r40, r41, r42, r43, r44, r45, r46, r47, r48, r49, r50, r51, r52, r53
    r0 = getgenv()
    r0._premTag = F.fn_001_function
    r0._isPremiumUser = F.fn_002_function
    r0 = getgenv()
    r1 = r0.__SnowyUIRuntime
    if r1 then

    end
    r1 = {}

    r1.corner = F.fn_003_function
    r1.stroke = F.fn_004_function
    r1.gradient = F.fn_005_gradient
    r1.shadow = F.fn_006_shadow
    r1.tw = F.fn_007_tween
    r0.__SnowyUIRuntime = r1
    r0.corner = r1.corner
    r0.stroke = r1.stroke
    r0.gradient = r1.gradient
    r0.shadow = r1.shadow
    r0.tw = r1.tw
    r1 = getgenv()
    r0 = r1._nagPremium
    if r0 then

    end
    r1 = getgenv()
    r1._nagPremium = F.fn_008_function

    r0 = game:GetService("TweenService")
    r1 = game:GetService("UserInputService")
    r2 = game:GetService("RunService")
    r3 = game:GetService("Players")
    r4 = game:GetService("HttpService")
    r5 = game:GetService("CoreGui")
    pcall(F.fn_014_function)
    pcall(F.fn_012_function)
    pcall(F.fn_012_function)
    pcall(F.fn_012_function)
    pcall(F.fn_012_function)
    warn("[SnowyHub] Anti-detect stub installed (Delta-compatible).")
    pcall(F.fn_040_function)
    r7 = {}
    r7.WindowWidth = 720
    r7.WindowHeight = 520
    r7.HeaderHeight = 48
    r7.TabBarHeight = 44
    r7.BannerHeight = 62
    r7.Radius = 24
    r7.RadiusSm = 16
    r7.RadiusXs = 12
    r7.RadiusPill = 999
    r8 = Color3.fromRGB(18, 24, 64)
    r7.BgPrimary = r8
    r8 = Color3.fromRGB(24, 32, 85)
    r7.BgSecondary = r8
    r8 = Color3.fromRGB(35, 45, 110)
    r7.BgCard = r8
    r8 = Color3.fromRGB(45, 60, 140)
    r7.BgCardHover = r8
    r8 = Color3.fromRGB(40, 65, 160)
    r7.BgCardActive = r8
    r8 = Color3.fromRGB(14, 18, 50)
    r7.BgHeader = r8
    r8 = Color3.fromRGB(20, 28, 70)
    r7.BgInput = r8
    r8 = Color3.fromRGB(20, 28, 70)
    r7.BgTabBar = r8
    r8 = Color3.fromRGB(85, 213, 254)
    r7.Accent = r8
    r8 = Color3.fromRGB(135, 235, 255)
    r7.AccentBright = r8
    r8 = Color3.fromRGB(50, 170, 220)
    r7.AccentDark = r8
    r8 = Color3.fromRGB(30, 90, 130)
    r7.AccentDim = r8
    r8 = Color3.fromRGB(180, 240, 255)
    r7.AccentGlow = r8
    r8 = Color3.fromRGB(100, 200, 255)
    r7.AccentSoft = r8
    r8 = Color3.fromRGB(255, 200, 50)
    r7.Premium = r8
    r8 = Color3.fromRGB(180, 130, 20)
    r7.PremiumDark = r8
    r8 = Color3.fromRGB(50, 40, 10)
    r7.PremiumDim = r8
    r8 = Color3.fromRGB(15, 45, 100)
    r7.BannerBg = r8
    r8 = Color3.fromRGB(25, 70, 150)
    r7.BannerActive = r8
    r8 = Color3.fromRGB(230, 245, 255)
    r7.TextPrimary = r8
    r8 = Color3.fromRGB(160, 190, 230)
    r7.TextSecondary = r8
    r8 = Color3.fromRGB(80, 110, 160)
    r7.TextMuted = r8
    r8 = Color3.fromRGB(50, 70, 110)
    r7.TextDim = r8
    r8 = Color3.fromRGB(30, 45, 100)
    r7.Border = r8
    r8 = Color3.fromRGB(60, 100, 220)
    r7.BorderHi = r8
    r8 = Color3.fromRGB(50, 220, 120)
    r7.Success = r8
    r8 = Color3.fromRGB(255, 55, 75)
    r7.Error = r8
    r8 = Color3.fromRGB(255, 180, 50)
    r7.Warning = r8
    r8 = {}
    r9 = {}
    r9.name = "BedWars"
    r10 = utf8.char(128719)
    r9.icon = r10
    r10 = {}
    r10[1] = "bedwars"
    r10[2] = "bed wars"
    r9.aliases = r10
    r10 = {}
    r10[1] = 6872265039
    r10[2] = 6872274481
    r9.placeIds = r10
    r9.features = 69
    r9.img = "rbxassetid://6034281798"
    r10 = {}
    r10.name = "BedWars"
    r11 = utf8.char(128719)
    r10.icon = r11
    r11 = {}
    r11[1] = "bedwars"
    r11[2] = "bed wars"
    r10.aliases = r11
    r11 = {}
    r11[1] = 6872265039
    r11[2] = 6872274481
    r10.placeIds = r11
    r10.features = 69
    r10.img = "rbxassetid://6034281798"
    r11 = {}
    r11.name = "Taxi Boss"
    r12 = utf8.char(128661)
    r11.icon = r12
    r12 = {}
    r12[1] = "taxi boss"
    r12[2] = "taxiboss"
    r12[3] = "taxi"
    r11.aliases = r12
    r12 = {}
    r12[1] = 7305309231
    r11.placeIds = r12
    r11.features = 40
    r11.img = "rbxassetid://6034281798"
    r12 = {}
    r12.name = "BloxStrike"
    r13 = utf8.char(127919)
    r12.icon = r13
    r13 = {}
    r13[1] = "bloxstrike"
    r13[2] = "blox strike"
    r12.aliases = r13
    r13 = {}
    r13[1] = 114234929420007
    r12.placeIds = r13
    r12.features = 45
    r12.img = "rbxassetid://6034281798"
    r13 = {}
    r13.name = "Anime Expeditions"
    r14 = utf8.char(9889)
    r13.icon = r14
    r14 = {}
    r14[1] = "anime expeditions"
    r14[2] = "expeditions"
    r14[3] = "anime expedition"
    r13.aliases = r14
    r14 = {}
    r14[1] = 84515722934860
    r13.placeIds = r14
    r13.features = 40
    r13.img = "rbxassetid://6034281798"
    r14 = {}
    r14.name = "+1 Pickaxe Swing Escape"
    r15 = utf8.char(9935)
    r14.icon = r15
    r15 = {}
    r15[1] = "+1 pickaxe swing escape"
    r15[2] = "pickaxe swing escape"
    r15[3] = "pickaxe escape"
    r15[4] = "pickaxe swing"
    r15[5] = "pickaxe"
    r14.aliases = r15
    r15 = {}
    r15[1] = 82554996468034
    r14.placeIds = r15
    r14.features = 20
    r14.img = "rbxassetid://6034281798"
    r15 = {}
    r15.name = "Animal Hospital"
    r16 = utf8.char(127973)
    r15.icon = r16
    r16 = {}
    r16[1] = "animal hospital"
    r16[2] = "anomaly hospital"
    r16[3] = "hospital"
    r15.aliases = r16
    r16 = {}
    r16[1] = 78515283254292
    r15.placeIds = r16
    r15.features = 15
    r15.img = "rbxassetid://6034281798"
    r16 = {}
    r16.name = "Merge a Nuke"
    r17 = utf8.char(128163)
    r16.icon = r17
    r17 = {}
    r17[1] = "merge a nuke"
    r17[2] = "merge a nuke!"
    r17[3] = "nuke tycoon"
    r17[4] = "merge nuke"
    r16.aliases = r17
    r17 = {}
    r17[1] = 128784467030899
    r17[2] = 136423403372990
    r16.placeIds = r17
    r16.features = 15
    r16.img = "rbxassetid://6034281798"
    r17 = {}
    r17.name = "Arsenal"
    r18 = utf8.char(127919)
    r17.icon = r18
    r18 = {}
    r18[1] = 286090429
    r18[2] = 2133507413
    r17.placeIds = r18
    r17.features = 20
    r17.img = "rbxassetid://6034281798"
    r18 = {}
    r18.name = "Jujutsu Shenanigans"
    r19 = utf8.char(9889)
    r18.icon = r19
    r19 = {}
    r19[1] = "jujutsu shenanigans"
    r19[2] = "jujutsu"
    r19[3] = "shenanigans"
    r18.aliases = r19
    r19 = {}
    r19[1] = 9391468976
    r18.placeIds = r19
    r19 = {}
    r19[1] = 3508322461
    r18.universeIds = r19
    r18.features = 15
    r18.img = "rbxassetid://6034281798"
    r19 = {}
    r19.name = "Abyss"
    r20 = utf8.char(127754)
    r19.icon = r20
    r20 = {}
    r20[1] = 8841631016
    r20[2] = 6499213745
    r19.placeIds = r20
    r19.features = 22
    r19.img = "rbxassetid://6034281798"
    r20 = {}
    r20.name = "Jailbreak"
    r21 = utf8.char(128680)
    r20.icon = r21
    r21 = {}
    r21[1] = 606849621
    r20.placeIds = r21
    r20.features = 50
    r20.img = "rbxassetid://6034281798"
    r21 = {}
    r21.name = "Tsunami"
    r22 = utf8.char(127754)
    r21.icon = r22
    r22 = {}
    r22[1] = 2456517837
    r22[2] = 7456917583
    r21.placeIds = r22
    r21.features = 30
    r21.img = "rbxassetid://6034281798"
    r22 = {}
    r22.name = "Sniper Duels"
    r23 = utf8.char(127919)
    r22.icon = r23
    r23 = {}
    r23[1] = 2957674229
    r23[2] = 3519873232
    r23[3] = 109397169461300
    r22.placeIds = r23
    r22.features = 12
    r22.img = "rbxassetid://6034281798"
    r23 = {}
    r23.name = "Swing Obby"
    r24 = utf8.char(127906)
    r23.icon = r24
    r24 = {}
    r24[1] = 5334680521
    r23.placeIds = r24
    r23.features = 10
    r23.img = "rbxassetid://6034281798"
    r24 = {}
    r24.name = "Brookhaven"
    r25 = utf8.char(127968)
    r24.icon = r25
    r25 = {}
    r25[1] = 4924922222
    r24.placeIds = r25
    r24.features = 15
    r24.img = "rbxassetid://6034281798"
    r8[1] = r9
    r8[2] = r10
    r8[3] = r11
    r8[4] = r12
    r8[5] = r13
    r8[6] = r14
    r8[7] = r15
    r8[8] = r16
    r8[9] = r17
    r8[10] = r18
    r8[11] = r19
    r8[12] = r20
    r8[13] = r21
    r8[14] = r22
    r8[15] = r23
    r8[16] = r24
    r9 = {}
    r9.name = "99 Nights"
    r10 = utf8.char(127769)
    r9.icon = r10
    r10 = {}
    r10[1] = 13271790403
    r10[2] = 14502339080
    r9.placeIds = r10
    r9.features = 28
    r9.img = "rbxassetid://6034281798"
    r10 = {}
    r10.name = "Blox Fruits"
    r11 = utf8.char(127822)
    r10.icon = r11
    r11 = {}
    r11[1] = "blox fruits"
    r11[2] = "blox fruit"
    r11[3] = "bloxfruits"
    r10.aliases = r11
    r11 = {}
    r11[1] = 2753915549
    r11[2] = 4442272183
    r11[3] = 7449423635
    r10.placeIds = r11
    r10.features = 18
    r10.img = "rbxassetid://6034281798"
    r11 = {}
    r11.name = "Pet Sim 99"
    r12 = utf8.char(128062)
    r11.icon = r12
    r12 = {}
    r12[1] = "pet simulator 99"
    r12[2] = "pet sim 99"
    r12[3] = "petsim99"
    r11.aliases = r12
    r12 = {}
    r12[1] = 8737899170
    r12[2] = 15532244896
    r12[3] = 15588347101
    r11.placeIds = r12
    r12 = {}
    r12[1] = 3317771874
    r11.universeIds = r12
    r11.features = 15
    r11.img = "rbxassetid://6034281798"
    r12 = {}
    r12.name = "Bee Swarm"
    r13 = utf8.char(128029)
    r12.icon = r13
    r13 = {}
    r13[1] = 1537690962
    r12.placeIds = r13
    r12.features = 12
    r12.img = "rbxassetid://6034281798"
    r13 = {}
    r13.name = "SAB"
    r14 = utf8.char(129302)
    r13.icon = r14
    r14 = {}
    r14[1] = "steal a brainrot"
    r14[2] = "sab"
    r13.aliases = r14
    r14 = {}
    r14[1] = 18668065096
    r14[2] = 1234567890
    r14[3] = 10495922230
    r14[4] = 109983668079237
    r13.placeIds = r14
    r14 = {}
    r14[1] = 109983668079237
    r13.universeIds = r14
    r13.features = 24
    r13.img = "rbxassetid://6034281798"
    r14 = {}
    r14.name = "Ultimate Battlegrounds"
    r15 = utf8.char(128298)
    r14.icon = r15
    r15 = {}
    r15[1] = 11815767793
    r14.placeIds = r15
    r14.features = 18
    r14.img = "rbxassetid://6034281798"
    r15 = {}
    r15.name = "Strongest Battlegrounds"
    r16 = utf8.char(128293)
    r15.icon = r16
    r16 = {}
    r16[1] = 10495922230
    r15.placeIds = r16
    r15.features = 15
    r15.img = "rbxassetid://6034281798"
    r16 = {}
    r16.name = "Heroes Battlegrounds"
    r17 = utf8.char(129464)
    r16.icon = r17
    r17 = {}
    r17[1] = 13076380114
    r16.placeIds = r17
    r16.features = 16
    r16.img = "rbxassetid://6034281798"
    r17 = {}
    r17.name = "Legend Battlegrounds"
    r18 = utf8.char(128481)
    r17.icon = r18
    r18 = {}
    r18[1] = 15269951959
    r17.placeIds = r18
    r17.features = 18
    r17.img = "rbxassetid://6034281798"
    r18 = {}
    r18.name = "Jump for Brainrots"
    r19 = utf8.char(129504)
    r18.icon = r19
    r19 = {}
    r19[1] = 139299356663913
    r18.placeIds = r19
    r18.features = 12
    r18.img = "rbxassetid://6034281798"
    r19 = {}
    r19.name = "+1 Jump Brainrot"
    r20 = utf8.char(128095)
    r19.icon = r20
    r20 = {}
    r20[1] = 121192350097093
    r19.placeIds = r20
    r19.features = 15
    r19.img = "rbxassetid://6034281798"
    r20 = {}
    r20.name = "Grab Ores!"
    r21 = utf8.char(9935)
    r20.icon = r21
    r21 = {}
    r21[1] = 82806856224736
    r20.placeIds = r21
    r20.features = 45
    r20.img = "rbxassetid://6034281798"
    r21 = {}
    r21.name = "Murderers VS Sheriffs"
    r22 = utf8.char(128298)
    r21.icon = r22
    r22 = {}
    r22[1] = 135856908115931
    r21.placeIds = r22
    r21.features = 22
    r21.img = "rbxassetid://6034281798"
    r22 = {}
    r22.name = "Sailor Piece"
    r23 = utf8.char(9875)
    r22.icon = r23
    r23 = {}
    r23[1] = "sailor piece"
    r23[2] = "sailor peace"
    r22.aliases = r23
    r23 = {}
    r23[1] = 77747658251236
    r22.placeIds = r23
    r22.features = 38
    r22.img = "rbxassetid://6034281798"
    r23 = {}
    r23.name = "MM2"
    r24 = utf8.char(128481)
    r23.icon = r24
    r24 = {}
    r24[1] = "murder mystery 2"
    r24[2] = "mm2"
    r23.aliases = r24
    r24 = {}
    r24[1] = 142823291
    r24[2] = 80005698042109
    r23.placeIds = r24
    r23.features = 40
    r23.img = "rbxassetid://6034281798"
    r24 = {}
    r24.name = "Kick a Lucky Block"
    r25 = utf8.char(127808)
    r24.icon = r25
    r25 = {}
    r25[1] = "kick a lucky block"
    r25[2] = "lucky block"
    r25[3] = "kick lucky"
    r24.aliases = r25
    r25 = {}
    r25[1] = 16955097151
    r25[2] = 89469502395769
    r24.placeIds = r25
    r25 = {}
    r25[1] = 89469502395769
    r24.universeIds = r25
    r24.features = 30
    r24.img = "rbxassetid://6034281798"
    r8[17] = r9
    r8[18] = r10
    r8[19] = r11
    r8[20] = r12
    r8[21] = r13
    r8[22] = r14
    r8[23] = r15
    r8[24] = r16
    r8[25] = r17
    r8[26] = r18
    r8[27] = r19
    r8[28] = r20
    r8[29] = r21
    r8[30] = r22
    r8[31] = r23
    r8[32] = r24
    r9 = {}
    r9.name = "Rivals"
    r10 = utf8.char(128299)
    r9.icon = r10
    r10 = {}
    r10[1] = "rivals"
    r10[2] = "rivals fps"
    r10[3] = "matchmaking"
    r9.aliases = r10
    r10 = {}
    r10[1] = 17625359962
    r10[2] = 14721849686
    r10[3] = 117398147513099
    r9.placeIds = r10
    r10 = {}
    r10[1] = 6035872082
    r9.universeIds = r10
    r9.features = 22
    r9.img = "rbxassetid://6034281798"
    r10 = {}
    r10.name = "Speed Keyboard Escape"
    r11 = utf8.char(9000)
    r10.icon = r11
    r11 = {}
    r11[1] = "speed keyboard escape"
    r11[2] = "keyboard escape"
    r11[3] = "1 speed keyboard escape"
    r11[4] = "escape candy chocolate"
    r11[5] = "1-speed-keyboard-escape"
    r11[6] = "keyboard"
    r10.aliases = r11
    r11 = {}
    r11[1] = 95082159892680
    r10.placeIds = r11
    r10.features = 16
    r10.img = "rbxassetid://6034281798"
    r11 = {}
    r11.name = "Speed Monkey Escape"
    r12 = utf8.char(128018)
    r11.icon = r12
    r12 = {}
    r12[1] = "speed monkey escape"
    r12[2] = "monkey escape"
    r12[3] = "1 speed monkey escape"
    r12[4] = "monkey"
    r11.aliases = r12
    r12 = {}
    r12[1] = 114697347887839
    r11.placeIds = r12
    r11.features = 20
    r11.img = "rbxassetid://6034281798"
    r12 = {}
    r12.name = "Sell Lemons"
    r13 = utf8.char(127819)
    r12.icon = r13
    r13 = {}
    r13[1] = "sell lemons"
    r13[2] = "lemon tycoon"
    r13[3] = "lemons"
    r12.aliases = r13
    r13 = {}
    r13[1] = 79268393072444
    r12.placeIds = r13
    r12.features = 14
    r12.img = "rbxassetid://6034281798"
    r13 = {}
    r13.name = "Demonology"
    r14 = utf8.char(128123)
    r13.icon = r14
    r14 = {}
    r14[1] = "demonology"
    r14[2] = "ghost hunter"
    r14[3] = "demon"
    r13.aliases = r14
    r14 = {}
    r14[1] = 18199615050
    r13.placeIds = r14
    r13.features = 12
    r13.img = "rbxassetid://6034281798"
    r14 = {}
    r14.name = "Grow a Garden 2"
    r15 = utf8.char(127793)
    r14.icon = r15
    r15 = {}
    r15[1] = "grow a garden 2"
    r15[2] = "grow a garden"
    r15[3] = "gag2"
    r15[4] = "gag 2"
    r14.aliases = r15
    r15 = {}
    r15[1] = 97598239454123
    r15[2] = 1588579651
    r15[3] = 126884695634066
    r14.placeIds = r15
    r15 = {}
    r15[1] = 7436755782
    r14.universeIds = r15
    r14.features = 25
    r14.img = "rbxassetid://6034281798"
    r15 = {}
    r15.name = "Welcome to Bloxburg"
    r16 = utf8.char(127968)
    r15.icon = r16
    r16 = {}
    r16[1] = "welcome to bloxburg"
    r16[2] = "bloxburg"
    r15.aliases = r16
    r16 = {}
    r16[1] = 185655149
    r15.placeIds = r16
    r15.features = 16
    r15.img = "rbxassetid://6034281798"
    r16 = {}
    r16.name = "Adopt Me"
    r17 = utf8.char(128054)
    r16.icon = r17
    r17 = {}
    r17[1] = "adopt me"
    r17[2] = "adoptme"
    r16.aliases = r17
    r17 = {}
    r17[1] = 920587237
    r16.placeIds = r17
    r16.features = 12
    r16.img = "rbxassetid://6034281798"
    r17 = {}
    r17.name = "Dandy's World"
    r18 = utf8.char(127912)
    r17.icon = r18
    r18 = {}
    r18[1] = "dandys world"
    r18[2] = "dandy"
    r18[3] = "dandys"
    r17.aliases = r18
    r18 = {}
    r18[1] = 16267229903
    r17.placeIds = r18
    r17.features = 10
    r17.img = "rbxassetid://6034281798"
    r18 = {}
    r18.name = "Blade Ball"
    r19 = utf8.char(128298)
    r18.icon = r19
    r19 = {}
    r19[1] = "blade ball"
    r19[2] = "bladeball"
    r19[3] = "bb"
    r18.aliases = r19
    r19 = {}
    r19[1] = 13772394625
    r19[2] = 14777999650
    r19[3] = 15182888200
    r18.placeIds = r19
    r18.features = 25
    r18.img = "rbxassetid://6034281798"
    r19 = {}
    r19.name = "KAT"
    r20 = utf8.char(128298)
    r19.icon = r20
    r20 = {}
    r20[1] = 621129760
    r19.placeIds = r20
    r20 = {}
    r20[1] = 228028122
    r19.universeIds = r20
    r19.features = 11
    r19.img = "rbxassetid://6034281798"
    r20 = {}
    r20.name = "One Scope"
    r21 = utf8.char(127919)
    r20.icon = r21
    r21 = {}
    r21[1] = 135648408848758
    r20.placeIds = r21
    r20.features = 7
    r20.img = "rbxassetid://6034281798"
    r21 = {}
    r21.name = "Da Hood"
    r22 = utf8.char(127968)
    r21.icon = r22
    r22 = {}
    r22[1] = "da hood"
    r22[2] = "dahood"
    r22[3] = "dh"
    r21.aliases = r22
    r22 = {}
    r22[1] = 2788229376
    r22[2] = 105305881594005
    r22[3] = 98343466176190
    r22[4] = 93778920465645
    r22[5] = 129449254792324
    r22[6] = 122120252103378
    r22[7] = 110917236678062
    r22[8] = 130879446158509
    r21.placeIds = r22
    r21.features = 120
    r21.img = "rbxassetid://6034281798"
    r22 = {}
    r22.name = "Evade"
    r23 = utf8.char(127939)
    r22.icon = r23
    r23 = {}
    r23[1] = "evade"
    r23[2] = "rise"
    r22.aliases = r23
    r23 = {}
    r23[1] = 9872472334
    r22.placeIds = r23
    r22.features = 45
    r22.img = "rbxassetid://6034281798"
    r23 = {}
    r23.name = "Bridge Duel"
    r24 = utf8.char(128481)
    r23.icon = r24
    r24 = {}
    r24[1] = "bridge duel"
    r24[2] = "bridge duels"
    r24[3] = "uoro"
    r23.aliases = r24
    r24 = {}
    r24[1] = 139566161526375
    r23.placeIds = r24
    r23.features = 35
    r23.img = "rbxassetid://6034281798"
    r24 = {}
    r24.name = "Drain the Lake"
    r25 = utf8.char(128167)
    r24.icon = r25
    r25 = {}
    r25[1] = "drain the lake"
    r25[2] = "drain lake"
    r24.aliases = r25
    r25 = {}
    r25[1] = 138381251771774
    r24.placeIds = r25
    r25 = {}
    r25[1] = 10267363348
    r24.universeIds = r25
    r24.features = 9
    r24.img = "rbxassetid://6034281798"
    r8[33] = r9
    r8[34] = r10
    r8[35] = r11
    r8[36] = r12
    r8[37] = r13
    r8[38] = r14
    r8[39] = r15
    r8[40] = r16
    r8[41] = r17
    r8[42] = r18
    r8[43] = r19
    r8[44] = r20
    r8[45] = r21
    r8[46] = r22
    r8[47] = r23
    r8[48] = r24
    r9 = {}
    r9.name = "Prison Life"
    r10 = utf8.char(128680)
    r9.icon = r10
    r10 = {}
    r10[1] = "prison life"
    r10[2] = "prison"
    r9.aliases = r10
    r10 = {}
    r10[1] = 155615604
    r9.placeIds = r10
    r10 = {}
    r10[1] = 73885730
    r9.universeIds = r10
    r9.features = 9
    r9.img = "rbxassetid://6034281798"
    r10 = {}
    r10.name = "Fish It"
    r11 = utf8.char(128031)
    r10.icon = r11
    r11 = {}
    r11[1] = "fish it"
    r11[2] = "fisch"
    r11[3] = "fishit"
    r10.aliases = r11
    r11 = {}
    r11[1] = 121864768012064
    r11[2] = 16732694052
    r11[3] = 17445763782
    r10.placeIds = r11
    r10.features = 25
    r10.img = "rbxassetid://6034281798"
    r11 = {}
    r11.name = "Forsaken"
    r12 = utf8.char(128128)
    r11.icon = r12
    r12 = {}
    r12[1] = "forsaken"
    r11.aliases = r12
    r12 = {}
    r12[1] = 18687417158
    r11.placeIds = r12
    r11.features = 20
    r11.img = "rbxassetid://6034281798"
    r12 = {}
    r12.name = "Volley Ball Legends"
    r25 = utf8.char(127952)
    r12.icon = r25
    r25 = {}
    r25[1] = "volley ball legends"
    r25[2] = "volleyball legends"
    r25[3] = "volleyball"
    r25[4] = "volley ball"
    r12.aliases = r25
    r25 = {}
    r25[1] = 73956553001240
    r12.placeIds = r25
    r12.features = 20
    r12.img = "rbxassetid://6034281798"
    r8[49] = r9
    r8[50] = r10
    r8[51] = r11
    r8[52] = r12
    r9 = getgenv()
    r9.SUPPORTED_GAMES = r8
    r10 = tonumber(game.PlaceId)
    if r10 then

    end

    r11 = tonumber(game.GameId)
    if r11 then

    end

    pcall(F.fn_041_function)
    r13, r14, r15 = ipairs(r8)

    r18 = r17.placeIds
    if not r18 then

    end
    r18, r19, r20 = ipairs(r17.placeIds)

    r23 = tonumber(r22)
    r53 = (0 == r23)
    if not r53 then

    end

    r9 = r17
    if r9 then

    end
    r18 = r17.universeIds
    if not r18 then

    end
    r18, r19, r20 = ipairs(r17.universeIds)

    r23 = tonumber(r22)
    r53 = (0 == r23)
    if not r53 then

    end

    r9 = r17
    if r9 then

    end

    if r9 then

    end
    r53 = ("" == "")
    if r53 then

    end
    r13, r14, r15 = ipairs(r8)

    r18 = r17.name:lower()
    r19 = (""):find(r18, 1, true)
    if not r19 then

    end

    r19 = r17.aliases
    if not r19 then

    end
    r19, r20, r21 = ipairs(r17.aliases)

    r24 = (true):lower()
    r53 = (3 <= #r24)
    if not r53 then

    end
    r25 = (""):find(r24, 1, true)
    if not r25 then

    end

    r9 = r17
    if r9 then

    end

    if r9 then

    end
    r13 = (""):find("bedwars")
    if r13 then

    end
    r13 = (""):find("bed wars")
    if not r13 then

    end

    r13, r14, r15 = ipairs(r8)

    r53 = (r17.name == "BedWars")
    if not r53 then

    end

    r13 = (""):find("bedwars")
    if r13 then

    end
    r13 = (""):find("bed wars")
    if not r13 then

    end

    r13, r14, r15 = ipairs(r8)

    r53 = (r17.name == "BedWars")
    if not r53 then

    end

    r13 = (""):find("blox fruit")
    if r13 then

    end
    r13 = (""):find("bloxfruit")
    if not r13 then

    end

    r13, r14, r15 = ipairs(r8)

    r53 = (r17.name == "Blox Fruits")
    if not r53 then

    end

    r13 = (""):find("fish it")
    if r13 then

    end
    r13 = (""):find("fisch")
    if r13 then

    end
    r13 = (""):find("fishit")
    if not r13 then

    end

    r13, r14, r15 = ipairs(r8)

    r53 = (r17.name == "Fish It")
    if not r53 then

    end

    r13 = (""):find("steal a brainrot")
    if r13 then

    end
    r13 = (""):find("sab")
    if not r13 then

    end

    r13, r14, r15 = ipairs(r8)

    r53 = (r17.name == "SAB")
    if not r53 then

    end

    r13 = (""):find("forsaken")
    if not r13 then

    end
    r13, r14, r15 = ipairs(r8)

    r53 = (r17.name == "Forsaken")
    if not r53 then

    end

    r13 = (""):find("volley")
    if not r13 then

    end
    r13, r14, r15 = ipairs(r8)

    r53 = (r17.name == "Volley Ball Legends")
    if not r53 then

    end

    r13 = (""):find("speed keyboard")
    if r13 then

    end
    r13 = (""):find("keyboard escape")
    if not r13 then

    end

    r13, r14, r15 = ipairs(r8)

    r53 = (r17.name == "Speed Keyboard Escape")
    if not r53 then

    end

    r13 = (""):find("speed monkey")
    if r13 then

    end
    r13 = (""):find("monkey escape")
    if r13 then

    end
    r13 = (""):find("monkey")
    if not r13 then

    end

    r13, r14, r15 = ipairs(r8)

    r53 = (r17.name == "Speed Monkey Escape")
    if not r53 then

    end

    r13 = (""):find("anime expedition")
    if r13 then

    end
    r13 = (""):find("expedition")
    if not r13 then

    end

    r13, r14, r15 = ipairs(r8)

    r53 = (r17.name == "Anime Expeditions")
    if not r53 then

    end

    r13 = (""):find("merge a nuke")
    if r13 then

    end
    r13 = (""):find("merge nuke")
    if not r13 then

    end

    r13, r14, r15 = ipairs(r8)

    r53 = (r17.name == "Merge a Nuke")
    if not r53 then

    end

    r13 = (""):find("pickaxe")
    if not r13 then

    end
    r13, r14, r15 = ipairs(r8)

    r53 = (r17.name == "+1 Pickaxe Swing Escape")
    if not r53 then

    end

    r13 = (""):find("grow a garden")
    if r13 then

    end
    r13 = (""):find("gag2")
    if not r13 then

    end

    r13, r14, r15 = ipairs(r8)

    r53 = (r17.name == "Grow a Garden 2")
    if not r53 then

    end

    r13 = (""):find("animal hospital")
    if r13 then

    end
    r13 = (""):find("hospital")
    if not r13 then

    end

    r13, r14, r15 = ipairs(r8)

    r53 = (r17.name == "Animal Hospital")
    if not r53 then

    end

    r13 = (""):find("prison life")
    if r13 then

    end
    r13 = (""):find("prison")
    if not r13 then

    end

    r13, r14, r15 = ipairs(r8)

    r53 = (r17.name == "Prison Life")
    if not r53 then

    end

    r13 = (""):find("da hood")
    if r13 then

    end
    r13 = (""):find("dahood")
    if not r13 then

    end

    r13, r14, r15 = ipairs(r8)

    r53 = (r17.name == "Da Hood")
    if not r53 then

    end

    r13 = (""):find("bloxstrike")
    if r13 then

    end
    r13 = (""):find("blox strike")
    if not r13 then

    end

    r13, r14, r15 = ipairs(r8)

    r53 = (r17.name == "BloxStrike")
    if not r53 then

    end

    r13 = (""):find("taxi boss")
    if r13 then

    end
    r13 = (""):find("taxiboss")
    if not r13 then

    end

    r13, r14, r15 = ipairs(r8)

    r53 = (r17.name == "Taxi Boss")
    if not r53 then

    end

    r13 = (""):find("evade")
    if not r13 then

    end
    r13, r14, r15 = ipairs(r8)

    r53 = (r17.name == "Evade")
    if not r53 then

    end

    r9 = r17
    if r9 then

    end
    pcall(F.fn_042_function)

    r13 = {}
    r13.name = "Pet Sim 99"
    r13.features = 0
    r13 = {}
    r13.Notify = F.fn_046_function
    r19 = F.fn_127_create_window()
    r21 = {}
    r21.CreateLib = F.fn_151_create_window
    r23 = game:GetService("Players")
    r23 = game:GetService("UserInputService")
    r24 = game:GetService("ReplicatedStorage")
    r25 = game:GetService("RunService")
    r31 = {}
    r31.HubName = "Snowy Studios"
    r32 = Color3.fromRGB(0, 162, 255)
    r31.AccentColor = r32
    r33 = getgenv()
    r34 = r21.CreateLib(r31.HubName, "Midnight")
    r33.Window = r34
    r34 = getgenv()
    r34 = getgenv()
    r9 = r13
    if not r9 then

    end
    r35 = r9.name
    if r35 then

    end

    r36 = {}
    r36.nonce = r34.__SnowyLaunchNonce
    r36.game = "Unknown"
    r36.ui = true
    r37 = os.clock()
    r36.at = r37
    r34.__SnowyPayloadReady = r36
    r39 = tostring("Unknown")
    print("[SnowyHub] Payload UI ready: " .. r39)
    r34 = getgenv()
    r34.SnowyLib = r13
    r34 = getgenv()
    r34.Kavo = r21
    r34 = getgenv()
    r34.notify = F.fn_156_notify
    task.defer(F.fn_158_function)
    r34 = {}
    r36 = getgenv()
    r36.gameTab = F.fn_183_premium_toggle
    if r9 then

    end
    r37 = getgenv()
    r38 = r34.Window:NewTab("Home")
    r37.HomeTab = r38
    r37 = getgenv()
    r38 = r34.Window:NewTab("Player")
    r37.PlayerTab = r38
    r37 = getgenv()
    r38 = r34.Window:NewTab("Visuals")
    r37.VisualTab = r38
    r37 = getgenv()
    r38 = r34.Window:NewTab("Utility")
    r37.UtilTab = r38
    r37 = getgenv()
    r38 = r34.Window:NewTab("Aimbot")
    r37.AimbotTab = r38
    r37 = getgenv()
    r38 = r34.Window:NewTab("Settings")
    r37.SettingsTab = r38
    r37 = getgenv()
    r38 = HomeTab:NewSection("Status")
    r37.HomeSec = r38
    r42 = utf8.char(10052)
    HomeSec:NewLabel(r42 .. " SNOWY HUB v6.0")
    r37 = getgenv()
    r38 = PlayerTab:NewSection("General")
    r37.PlayerSection = r38
    r37 = getgenv()
    r38 = VisualTab:NewSection("ESP & Effects")
    r37.VisualSection = r38
    r37 = getgenv()
    r38 = UtilTab:NewSection("General Tools")
    r37.UtilSection = r38
    r37 = getgenv()
    r38 = AimbotTab:NewSection("Combat Settings")
    r37.AimbotSection = r38
    r37 = getgenv()
    r38 = SettingsTab:NewSection("Interface")
    r37.UISec = r38
    r37 = getgenv()
    r38 = SettingsTab:NewSection("Info")
    r37.InfoSec = r38
    r37 = getgenv()
    r37.WalkSpeedValue = 16
    r37 = getgenv()
    r37.JumpPowerValue = 50
    r37 = getgenv()
    r37.GodModeEnabled = false
    r38 = getgenv()
    r37 = r38.PlayerModifierLoop
    if not r37 then

    end
    pcall(F.fn_228_disconnect_player_modifier_loop)
    r37 = getgenv()
    r37.PlayerModifierLoop = nil

    r37 = getgenv()
    r39 = game:GetService("RunService")
    r38 = r39.RenderStepped:Connect(F.fn_231_safe_apply_god_mode)
    r37.PlayerModifierLoop = r38
    PlayerSection:NewSlider("WalkSpeed", "Changes player speed", 250, 16, F.fn_232_apply_walk_speed)
    PlayerSection:NewSlider("JumpPower", "Changes jump height", 250, 50, F.fn_233_apply_jump_power)
    PlayerSection:NewSlider("Gravity", "Changes world gravity", 196, 0, F.fn_234_apply_gravity)
    PlayerSection:NewPremiumToggle("God Mode", "Instantly regenerates health", F.fn_236_toggle_god_mode)
    noclip = F.fn_238_start_noclip
    clip = F.fn_239_stop_noclip
    PlayerSection:NewPremiumToggle("Noclip", "Walk through objects and walls", F.fn_240_set_noclip)
    PlayerSection:NewPremiumToggle("Infinite Jump", "Jump in mid-air", F.fn_242_install_infinite_jump)
    VisualSection:NewSlider("Field of View", "Change camera FOV", 120, 70, F.fn_243_set_camera_fov)
    VisualSection:NewToggle("Fullbright", "Removes shadows and darkness", F.fn_244_apply_lighting)
    r40 = {}
    VisualSection:NewPremiumToggle("Player ESP", "Highlights all players through walls", F.fn_245_create_player_esp)
    VisualSection:NewPremiumSlider("Hitbox Expander", "Make enemies easier to hit", 20, 2, F.fn_248_start_hitbox_loop)
    UtilSection:NewButton("Give Btools", "Gives building tools to inventory", F.fn_249_give_hammer_tool)
    UtilSection:NewPremiumButton("Teleport to Random Player", "TPs you to a random user", F.fn_250_teleport_random_player)
    UtilSection:NewButton("Rejoin Server", "Rejoins the same server", F.fn_251_rejoin_server)
    UtilSection:NewPremiumButton("Server Hop", "Joins a random new server", F.fn_253_server_hop)
    UtilSection:NewToggle("Anti-AFK", "Prevents Roblox disconnects", F.fn_254_anti_afk)
    r41 = {}
    r41.Enabled = false
    r41.ShowFOV = false
    r41.FOVRadius = 80
    r41.Smoothness = 0.5
    r41.TeamCheck = true
    r41.TargetPart = "Head"
    r42 = Drawing.new("Circle")
    r43 = Vector2.new((game.Workspace.CurrentCamera.ViewportSize.X / 2), (game.Workspace.CurrentCamera.ViewportSize.Y / 2))
    r42.Position = r43
    r42.Radius = r41.FOVRadius
    r42.Filled = false
    r43 = Color3.fromRGB(255, 255, 255)
    r42.Color = r43
    r42.Visible = false
    r42.Thickness = 1
    r45 = game:GetService("RunService")
    r45.RenderStepped:Connect(F.fn_256_aimbot_render_step)
    AimbotSection:NewPremiumToggle("Enable Aimbot (Right Click)", "Locks onto targets in FOV", F.fn_257_set_aimbot_enabled)
    AimbotSection:NewToggle("Show FOV Circle", "Displays the aimbot radius", F.fn_258_set_show_fov)
    AimbotSection:NewSlider("FOV Size", "Target area size", 300, 20, F.fn_259_set_fov_radius)
    AimbotSection:NewPremiumSlider("Aimbot Smoothness", "100=Instant, 1=Slow", 100, 1, F.fn_260_set_aimbot_smoothness)
    AimbotSection:NewToggle("Team Check", "Ignores teammates", F.fn_261_set_team_check)
    UISec:NewButton("Test Notification", "Test the notification system", F.fn_262_test_notification)
    UISec:NewButton("Test Premium Alert", "Premium-style notification", F.fn_263_test_premium_notification)
    UISec:NewSlider("UI Opacity", "Adjust hub transparency", 8, 0, F.fn_265_function)
    InfoSec:NewLabel("Right-click = Hold to aim (Aimbot)")
    InfoSec:NewLabel("Drag title bar to move")
    InfoSec:NewLabel("discord.gg/getsnowy")
    InfoSec:NewButton("Copy Discord", "Copy invite link", F.fn_266_copy_discord)
    ScriptSec:NewButton("Reload Hub", "Destroys and reloads the UI", F.fn_269_reload_ui)
    ScriptSec:NewLabel("SNOWY HUB v6.0 | Built by Snowy Studios")
    r50 = tostring(#r8)
    ScriptSec:NewLabel(r50 .. " Games Supported")

    r38 = getgenv()
    r39 = F.fn_273_premium_toggle()
    r38.HomeTab = r39
    r38 = getgenv()
    r39 = F.fn_273_premium_toggle()
    r38.PlayerTab = r39
    r38 = getgenv()
    r39 = F.fn_273_premium_toggle()
    r38.VisualTab = r39
    r38 = getgenv()
    r39 = F.fn_273_premium_toggle()
    r38.UtilTab = r39
    r38 = getgenv()
    r39 = F.fn_273_premium_toggle()
    r38.AimbotTab = r39
    r38 = getgenv()
    r39 = F.fn_273_premium_toggle()
    r38.SettingsTab = r39
    r38 = HomeTab:NewSection()
    r39 = getgenv()
    r39.HomeSec = r38
    r39 = getgenv()
    r39.PlayerSection = r38
    r39 = getgenv()
    r39.VisualSection = r38
    r39 = getgenv()
    r39.UtilSection = r38
    r39 = getgenv()
    r39.AimbotSection = r38
    r39 = getgenv()
    r39.UISec = r38
    r39 = getgenv()
    r39.InfoSec = r38
    r39 = getgenv()
    r39.ScriptSec = r38

    if not r9 then

    end
    r53 = (r9.name == "Pet Sim 99")
    if not r53 then

    end
    r37 = F.fn_183_premium_toggle("Pet Sim 99", "Pet Sim 99 ")
    r38 = r37:NewSection("Snowy Automation")
    r38:NewButton("Load Snowy Pet Sim 99 Script", "Executes the professional Snowy automation for PS99", F.fn_274_load_ps99_external)
    r38:NewLabel("Note: This will load the full external script.")

    do return end
end

return F
