local L_1_ = {}

L_1_.entry = function(...)
	local L_2_, L_3_
	L_2_ = L_1_.main

	return L_2_(...)
end

L_1_.premiumTag = function(L_4_arg0)
	local L_5_, L_6_
	return tostring(L_4_arg0)
end

L_1_.isPremiumUser = function()
	local L_7_
	return true
end

L_1_.createCorner = function(L_8_arg0, L_9_arg1)
	if typeof(L_9_arg1) ~= "Instance" then
		return nil
	end
	local L_10_ = Instance.new("UICorner")
	L_10_.CornerRadius = UDim.new(0, tonumber(L_8_arg0) or 8)
	L_10_.Parent = L_9_arg1
	return L_10_
end

L_1_.createStroke = function(L_11_arg0, L_12_arg1, L_13_arg2)
	if typeof(L_13_arg2) ~= "Instance" then
		return nil
	end
	local L_14_ = Instance.new("UIStroke")
	L_14_.Color = L_11_arg0 or Color3.fromRGB(85, 213, 254)
	L_14_.Thickness = tonumber(L_12_arg1) or 1
	L_14_.Parent = L_13_arg2
	return L_14_
end

L_1_.createGradient = function(L_15_arg0, L_16_arg1, L_17_arg2, L_18_arg3)
	if typeof(L_15_arg0) ~= "Instance" then
		return nil
	end
	local L_19_ = Instance.new("UIGradient")
	L_19_.Color = ColorSequence.new(
        L_16_arg1 or Color3.fromRGB(18, 24, 64),
        L_17_arg2 or L_16_arg1 or Color3.fromRGB(24, 32, 85)
    )
	L_19_.Rotation = tonumber(L_18_arg3) or 0
	L_19_.Parent = L_15_arg0
	return L_19_
end

L_1_.createShadow = function(L_20_arg0)
	if typeof(L_20_arg0) ~= "Instance" then
		return nil
	end
	local L_21_ = Instance.new("ImageLabel")
	L_21_.Name = "SnowyShadow"
	L_21_.BackgroundTransparency = 1
	L_21_.Position = UDim2.new(0, -18, 0, -18)
	L_21_.Size = UDim2.new(1, 36, 1, 36)
	L_21_.Image = "rbxassetid://6015897843"
	L_21_.ImageColor3 = Color3.new(0, 0, 0)
	L_21_.ImageTransparency = 0.42
	L_21_.ScaleType = Enum.ScaleType.Slice
	L_21_.SliceCenter = Rect.new(49, 49, 450, 450)
	L_21_.ZIndex = 0
	L_21_.Parent = L_20_arg0
	return L_21_
end

L_1_.tween = function(L_22_arg0, L_23_arg1, L_24_arg2, L_25_arg3, L_26_arg4)
	if typeof(L_22_arg0) ~= "Instance" or type(L_23_arg1) ~= "table" then
		return nil
	end
	local L_27_ = game:GetService("TweenService")
	local L_28_ = TweenInfo.new(
        tonumber(L_24_arg2) or 0.2,
        L_25_arg3 or Enum.EasingStyle.Quad,
        L_26_arg4 or Enum.EasingDirection.Out
    )
	local L_29_ = L_27_:Create(L_22_arg0, L_28_, L_23_arg1)
	L_29_:Play()
	return L_29_
end

L_1_._nagPremium = function()
	local L_30_
	return
end

L_1_.callback_9 = function()
	local L_31_, L_32_, L_33_
	return _G[upvalue_0]
end

L_1_.callback_10 = function()
	local L_34_, L_35_, L_36_
	return getgenv()[upvalue_0]
end

L_1_.callback_11 = function(L_37_arg0)
	local L_38_, L_39_, L_40_, L_41_, L_42_, L_43_, L_44_
	L_38_ = pcall
	L_39_ = L_1_.callback_9
	L_38_, L_39_ = pcall(L_1_.callback_9)
	if not L_38_ then
		L_40_ = pcall
		L_41_ = L_1_.callback_10
		L_40_, L_41_ = pcall(L_1_.callback_10)
		if not L_40_ then
			L_43_ = _ENV
			if _ENV then
				return rawget(L_43_, L_37_arg0)
			end
			L_43_ = _G
			return rawget(L_43_, L_37_arg0)
		else
			if L_41_ then
				return L_41_
			end
			L_43_ = _ENV
			if _ENV then
				return rawget(L_43_, L_37_arg0)
			end
			L_43_ = _G
			return rawget(L_43_, L_37_arg0)
		end
	else
		if L_39_ then
			return L_39_
		end
		L_40_ = pcall
		L_41_ = L_1_.callback_10
		L_40_, L_41_ = pcall(L_1_.callback_10)
		if not L_40_ then
			L_43_ = _ENV
			if _ENV then
				return rawget(L_43_, L_37_arg0)
			end
			L_43_ = _G
			return rawget(L_43_, L_37_arg0)
		else
			if L_41_ then
				return L_41_
			end
			L_43_ = _ENV
			if _ENV then
				return rawget(L_43_, L_37_arg0)
			end
			L_43_ = _G
			return rawget(L_43_, L_37_arg0)
		end
	end
end

L_1_.callback_12 = function()
	local L_45_, L_46_, L_47_
	L_45_ = getgenv()
	L_45_[upvalue_0] = upvalue_1
	return
end

L_1_.callback_13 = function(L_48_arg0, L_49_arg1)
	local L_50_, L_51_
	pcall(L_1_.callback_12)
	return
end

L_1_.callback_14 = function()
	local L_52_, L_53_, L_54_
	L_52_ = getgenv()
	L_53_ = getgenv().__realGetRawMT
	L_54_ = getgenv()
	if not (getgenv().__realGetRawMT) then
		L_53_ = upvalue_0("getrawmetatable")
		L_54_ = "getrawmetatable"
	end
	L_52_.__realGetRawMT = L_53_
	L_52_ = getgenv()
	L_53_ = getgenv().__realHookNamecall
	L_54_ = getgenv()
	if not (getgenv().__realHookNamecall) then
		L_53_ = upvalue_0("hookmetamethod")
		L_54_ = "hookmetamethod"
	end
	L_52_.__realHookNamecall = L_53_
	L_52_ = getgenv()
	L_53_ = getgenv().__realNewCClosure
	L_54_ = getgenv()
	if getgenv().__realNewCClosure then
		L_52_.__realNewCClosure = L_53_
		return
	end
	L_53_ = upvalue_0("newcclosure")
	L_54_ = "newcclosure"
	L_52_.__realNewCClosure = L_53_
	return
end

L_1_.callback_15 = function()
	local L_55_
	return
end

L_1_.__index = function()
	local L_56_
	return L_1_.callback_15
end

L_1_.__newindex = function()
	local L_57_
	return
end

L_1_.callback_18 = function(L_58_arg0)
	local L_59_, L_60_, L_61_, L_62_
	L_61_ = {}
	L_61_.__index = L_1_.__index
	L_61_.__newindex = L_1_.__newindex
	return setmetatable({}, L_61_)
end

L_1_.callback_19 = function()
	local L_63_
	return nil
end

L_1_.callback_20 = function(L_64_arg0, L_65_arg1, L_66_arg2)
	local L_67_
	return L_1_.callback_19
end

L_1_.callback_21 = function()
	local L_68_
	return
end

L_1_.callback_22 = function(L_69_arg0, L_70_arg1)
	return L_69_arg0
end

L_1_.callback_23 = function(L_71_arg0)
	local L_72_, L_73_, L_74_
	Clipboard:set(L_71_arg0)
	return
end

L_1_.callback_24 = function()
	local L_75_
	return
end

L_1_.callback_25 = function()
	local L_76_, L_77_, L_78_, L_79_, L_80_, L_81_, L_82_, L_83_
	upvalue_0:SendMouseButtonEvent(0, 0, 0, true, game, 1)
	return
end

L_1_.mouse1press = function()
	local L_84_, L_85_
	pcall(L_1_.callback_25)
	return
end

L_1_.callback_27 = function()
	local L_86_, L_87_, L_88_, L_89_, L_90_, L_91_, L_92_, L_93_
	upvalue_0:SendMouseButtonEvent(0, 0, 0, false, game, 1)
	return
end

L_1_.mouse1release = function()
	local L_94_, L_95_
	pcall(L_1_.callback_27)
	return
end

L_1_.Remove = function(L_96_arg0)
	return
end

L_1_.Destroy = function(L_97_arg0)
	return
end

L_1_.__newindex_31 = function()
	local L_98_
	return
end

L_1_.callback_32 = function()
	local L_99_
	return
end

L_1_.__index_33 = function()
	local L_100_
	return L_1_.callback_32
end

L_1_.new = function(L_101_arg0)
	local L_102_, L_103_, L_104_, L_105_
	L_103_ = {}
	L_103_.Visible = false
	L_103_.Remove = L_1_.Remove
	L_103_.Destroy = L_1_.Destroy
	L_104_ = {}
	L_104_.__newindex = L_1_.__newindex_31
	L_104_.__index = L_1_.__index_33
	return setmetatable(L_103_, L_104_)
end

L_1_.callback_35 = function()
	local L_106_, L_107_
	L_106_ = getgenv()
	L_106_.Drawing = upvalue_0
	return
end

L_1_.queue_on_teleport = function()
	local L_108_, L_109_
	L_108_ = request
	if not request then
		return
	end
	L_108_ = getgenv()
	L_108_.request = request
	L_109_ = request
	return
end

L_1_.queue_on_teleport_37 = function()
	local L_110_
	return
end

L_1_.gethui = function()
	local L_111_, L_112_, L_113_
	L_111_ = game.GetService
	L_112_ = game
	L_113_ = "CoreGui"
	return game:GetService("CoreGui")
end

L_1_.identifyexecutor = function()
	local L_114_, L_115_
	return "Unknown", "0.0.0"
end

L_1_.WindowWidth = function()
	local L_116_, L_117_, L_118_, L_119_, L_120_
	L_116_ = setclipboard
	if not (setclipboard) then
		L_116_ = toclipboard
		if not toclipboard then
			L_116_ = Clipboard
			if not Clipboard then
				setclipboard = L_1_.callback_24
				L_116_ = L_1_.callback_24
			else
				L_116_ = Clipboard.set
				if not Clipboard.set then
					setclipboard = L_1_.callback_24
					L_116_ = L_1_.callback_24
				else
					setclipboard = L_1_.callback_23
					L_116_ = L_1_.callback_23
				end
			end
		else
			setclipboard = toclipboard
			L_116_ = toclipboard
		end
	end
	L_116_ = mouse1press
	if not (mouse1press) then
		L_117_ = getgenv()
		L_117_.mouse1press = L_1_.mouse1press
		L_117_ = getgenv()
		L_117_.mouse1release = L_1_.mouse1release
		L_116_ = game:GetService("VirtualInputManager")
		L_118_ = L_1_.mouse1release
	end
	L_116_ = getgenv().Drawing
	L_117_ = getgenv()
	if not getgenv().Drawing then
		L_116_ = {}
		L_116_.new = L_1_.new
		L_117_ = {}
		L_117_.UI = 0
		L_117_.System = 1
		L_117_.Plex = 2
		L_117_.Monospace = 3
		L_116_.Fonts = L_117_
		pcall(L_1_.callback_35)
		L_117_ = pcall
		L_118_ = L_1_.callback_35
	else
		L_116_ = type(getgenv().Drawing)
		L_117_ = getgenv().Drawing
		L_118_ = getgenv()
		L_119_ = "table"
		L_120_ = (type(getgenv().Drawing) == "table")
		if not (type(getgenv().Drawing) == "table") then
			L_116_ = {}
			L_116_.new = L_1_.new
			L_117_ = {}
			L_117_.UI = 0
			L_117_.System = 1
			L_117_.Plex = 2
			L_117_.Monospace = 3
			L_116_.Fonts = L_117_
			pcall(L_1_.callback_35)
			L_117_ = pcall
			L_118_ = L_1_.callback_35
		else
			L_116_ = getgenv().Drawing.new
			L_117_ = getgenv().Drawing
			L_118_ = getgenv()
			if not (getgenv().Drawing.new) then
				L_116_ = {}
				L_116_.new = L_1_.new
				L_117_ = {}
				L_117_.UI = 0
				L_117_.System = 1
				L_117_.Plex = 2
				L_117_.Monospace = 3
				L_116_.Fonts = L_117_
				pcall(L_1_.callback_35)
				L_117_ = pcall
				L_118_ = L_1_.callback_35
			end
		end
	end
	L_116_ = request
	if not (request) then
		L_116_ = syn
		if not syn then
			L_116_ = http
			if not http then
				L_116_ = http_request
				if http_request then
					request = http_request
					L_116_ = http_request
				end
			else
				L_116_ = http.request
				if not http.request then
					L_116_ = http_request
					if http_request then
						request = http_request
						L_116_ = http_request
					end
				else
					request = http.request
					L_116_ = http.request
				end
			end
		else
			L_116_ = syn.request
			if not syn.request then
				L_116_ = http
				if not http then
					L_116_ = http_request
					if http_request then
						request = http_request
						L_116_ = http_request
					end
				else
					L_116_ = http.request
					if not http.request then
						L_116_ = http_request
						if http_request then
							request = http_request
							L_116_ = http_request
						end
					else
						request = http.request
						L_116_ = http.request
					end
				end
			else
				request = syn.request
				L_116_ = syn.request
			end
		end
	end
	pcall(L_1_.queue_on_teleport)
	L_116_ = queue_on_teleport
	L_117_ = L_1_.queue_on_teleport
	if not (queue_on_teleport) then
		L_116_ = getgenv()
		L_116_.queue_on_teleport = L_1_.queue_on_teleport_37
		L_117_ = L_1_.queue_on_teleport_37
	end
	L_116_ = gethui
	if not (gethui) then
		L_116_ = getgenv()
		L_116_.gethui = L_1_.gethui
		L_117_ = L_1_.gethui
	end
	L_116_ = identifyexecutor
	if identifyexecutor then
		return
	end
	L_116_ = getgenv()
	L_116_.identifyexecutor = L_1_.identifyexecutor
	L_117_ = L_1_.identifyexecutor
	return
end

L_1_.callback_41 = function()
	local L_121_, L_122_, L_123_
	L_121_ = game:GetService("MarketplaceService")
	L_121_ = L_121_:GetProductInfo(upvalue_0)
	L_122_ = L_121_
	L_123_ = upvalue_0
	if not L_121_:GetProductInfo(upvalue_0) then
		return
	end
	L_122_ = L_121_.Name
	if not L_121_.Name then
		return
	end
	upvalue_1 = L_121_.Name:lower()
	L_122_ = L_121_.Name:lower()
	L_123_ = L_121_.Name
	return
end

L_1_.name = function()
	local L_124_, L_125_, L_126_, L_127_, L_128_, L_129_, L_130_, L_131_, L_132_
	L_124_ = game:GetService("ReplicatedStorage")
	L_125_ = L_124_:FindFirstChild("TS")
	L_126_ = L_124_
	L_127_ = "TS"
	if L_124_:FindFirstChild("TS") then
		L_125_ = ipairs
		L_126_ = upvalue_0
		for L_133_forvar0, L_134_forvar1 in ipairs(upvalue_0) do
			L_130_ = L_134_forvar1.name
			L_131_ = "BedWars"
			L_132_ = (L_134_forvar1.name == "BedWars")
			if L_134_forvar1.name == "BedWars" then
				upvalue_1 = L_134_forvar1
				return
			end
		end
		return
	else
		L_125_ = lplr.PlayerScripts:FindFirstChild("TS")
		L_126_ = lplr.PlayerScripts
		L_127_ = "TS"
		if not lplr.PlayerScripts:FindFirstChild("TS") then
			L_125_ = L_124_:FindFirstChild("TS")
			L_126_ = L_124_
			L_127_ = "TS"
			if L_124_:FindFirstChild("TS") then
				L_125_ = ipairs
				L_126_ = upvalue_0
				for L_135_forvar0, L_136_forvar1 in ipairs(upvalue_0) do
					L_130_ = L_136_forvar1.name
					L_131_ = "BedWars"
					L_132_ = (L_136_forvar1.name == "BedWars")
					if L_136_forvar1.name == "BedWars" then
						upvalue_1 = L_136_forvar1
						return
					end
				end
				return
			else
				L_125_ = lplr.PlayerScripts:FindFirstChild("TS")
				L_126_ = lplr.PlayerScripts
				L_127_ = "TS"
				if not lplr.PlayerScripts:FindFirstChild("TS") then
					L_125_ = L_124_:FindFirstChild("Remotes")
					L_126_ = L_124_
					L_127_ = "Remotes"
					if not L_124_:FindFirstChild("Remotes") then
						L_125_ = L_124_:FindFirstChild("events")
						L_126_ = L_124_
						L_127_ = "events"
						if not L_124_:FindFirstChild("events") then
							L_125_ = L_124_:FindFirstChild("Forsaken")
							L_126_ = L_124_
							L_127_ = "Forsaken"
							if L_124_:FindFirstChild("Forsaken") then
								L_125_ = ipairs
								L_126_ = upvalue_0
								for L_137_forvar0, L_138_forvar1 in ipairs(upvalue_0) do
									L_130_ = L_138_forvar1.name
									L_131_ = "Forsaken"
									L_132_ = (L_138_forvar1.name == "Forsaken")
									if L_138_forvar1.name == "Forsaken" then
										upvalue_1 = L_138_forvar1
										return
									end
								end
								return
							else
								L_125_ = workspace:FindFirstChild("Forsaken")
								L_126_ = workspace
								L_127_ = "Forsaken"
								if not workspace:FindFirstChild("Forsaken") then
									L_125_ = L_124_:FindFirstChild("Volleyball")
									L_126_ = L_124_
									L_127_ = "Volleyball"
									if L_124_:FindFirstChild("Volleyball") then
										L_125_ = ipairs
										L_126_ = upvalue_0
										for L_139_forvar0, L_140_forvar1 in ipairs(upvalue_0) do
											L_130_ = L_140_forvar1.name
											L_131_ = "Volley Ball Legends"
											L_132_ = (L_140_forvar1.name == "Volley Ball Legends")
											if L_140_forvar1.name == "Volley Ball Legends" then
												upvalue_1 = L_140_forvar1
												return
											end
										end
										return
									else
										L_125_ = workspace:FindFirstChild("Volleyball")
										L_126_ = workspace
										L_127_ = "Volleyball"
										if workspace:FindFirstChild("Volleyball") then
											L_125_ = ipairs
											L_126_ = upvalue_0
											for L_141_forvar0, L_142_forvar1 in ipairs(upvalue_0) do
												L_130_ = L_142_forvar1.name
												L_131_ = "Volley Ball Legends"
												L_132_ = (L_142_forvar1.name == "Volley Ball Legends")
												if L_142_forvar1.name == "Volley Ball Legends" then
													upvalue_1 = L_142_forvar1
													return
												end
											end
											return
										else
											L_125_ = L_124_:FindFirstChild("Volley")
											L_126_ = L_124_
											L_127_ = "Volley"
											if not L_124_:FindFirstChild("Volley") then
												L_125_ = L_124_:FindFirstChild("Brainrots")
												L_126_ = L_124_
												L_127_ = "Brainrots"
												if L_124_:FindFirstChild("Brainrots") then
													L_125_ = ipairs
													L_126_ = upvalue_0
													for L_143_forvar0, L_144_forvar1 in ipairs(upvalue_0) do
														L_130_ = L_144_forvar1.name
														L_131_ = "SAB"
														L_132_ = (L_144_forvar1.name == "SAB")
														if L_144_forvar1.name == "SAB" then
															upvalue_1 = L_144_forvar1
															return
														end
													end
													return
												else
													L_125_ = workspace:FindFirstChild("Brainrots")
													L_126_ = workspace
													L_127_ = "Brainrots"
													if not workspace:FindFirstChild("Brainrots") then
														L_125_ = workspace:FindFirstChild("Pickaxes")
														L_126_ = workspace
														L_127_ = "Pickaxes"
														if not workspace:FindFirstChild("Pickaxes") then
															return
														end
														L_125_ = ipairs
														L_126_ = upvalue_0
														for L_145_forvar0, L_146_forvar1 in ipairs(upvalue_0) do
															L_130_ = L_146_forvar1.name
															L_131_ = "+1 Pickaxe Swing Escape"
															L_132_ = (L_146_forvar1.name == "+1 Pickaxe Swing Escape")
															if L_146_forvar1.name == "+1 Pickaxe Swing Escape" then
																upvalue_1 = L_146_forvar1
																return
															end
														end
														return
													else
														L_125_ = ipairs
														L_126_ = upvalue_0
														for L_147_forvar0, L_148_forvar1 in ipairs(upvalue_0) do
															L_130_ = L_148_forvar1.name
															L_131_ = "SAB"
															L_132_ = (L_148_forvar1.name == "SAB")
															if L_148_forvar1.name == "SAB" then
																upvalue_1 = L_148_forvar1
																return
															end
														end
														return
													end
												end
											else
												L_125_ = ipairs
												L_126_ = upvalue_0
												for L_149_forvar0, L_150_forvar1 in ipairs(upvalue_0) do
													L_130_ = L_150_forvar1.name
													L_131_ = "Volley Ball Legends"
													L_132_ = (L_150_forvar1.name == "Volley Ball Legends")
													if L_150_forvar1.name == "Volley Ball Legends" then
														upvalue_1 = L_150_forvar1
														return
													end
												end
												return
											end
										end
									end
								else
									L_125_ = ipairs
									L_126_ = upvalue_0
									for L_151_forvar0, L_152_forvar1 in ipairs(upvalue_0) do
										L_130_ = L_152_forvar1.name
										L_131_ = "Forsaken"
										L_132_ = (L_152_forvar1.name == "Forsaken")
										if L_152_forvar1.name == "Forsaken" then
											upvalue_1 = L_152_forvar1
											return
										end
									end
									return
								end
							end
						else
							L_125_ = L_124_.events:FindFirstChild("reels")
							L_126_ = L_124_.events
							L_127_ = "reels"
							if not L_124_.events:FindFirstChild("reels") then
								L_125_ = L_124_:FindFirstChild("Forsaken")
								L_126_ = L_124_
								L_127_ = "Forsaken"
								if L_124_:FindFirstChild("Forsaken") then
									L_125_ = ipairs
									L_126_ = upvalue_0
									for L_153_forvar0, L_154_forvar1 in ipairs(upvalue_0) do
										L_130_ = L_154_forvar1.name
										L_131_ = "Forsaken"
										L_132_ = (L_154_forvar1.name == "Forsaken")
										if L_154_forvar1.name == "Forsaken" then
											upvalue_1 = L_154_forvar1
											return
										end
									end
									return
								else
									L_125_ = workspace:FindFirstChild("Forsaken")
									L_126_ = workspace
									L_127_ = "Forsaken"
									if not workspace:FindFirstChild("Forsaken") then
										L_125_ = L_124_:FindFirstChild("Volleyball")
										L_126_ = L_124_
										L_127_ = "Volleyball"
										if L_124_:FindFirstChild("Volleyball") then
											L_125_ = ipairs
											L_126_ = upvalue_0
											for L_155_forvar0, L_156_forvar1 in ipairs(upvalue_0) do
												L_130_ = L_156_forvar1.name
												L_131_ = "Volley Ball Legends"
												L_132_ = (L_156_forvar1.name == "Volley Ball Legends")
												if L_156_forvar1.name == "Volley Ball Legends" then
													upvalue_1 = L_156_forvar1
													return
												end
											end
											return
										else
											L_125_ = workspace:FindFirstChild("Volleyball")
											L_126_ = workspace
											L_127_ = "Volleyball"
											if workspace:FindFirstChild("Volleyball") then
												L_125_ = ipairs
												L_126_ = upvalue_0
												for L_157_forvar0, L_158_forvar1 in ipairs(upvalue_0) do
													L_130_ = L_158_forvar1.name
													L_131_ = "Volley Ball Legends"
													L_132_ = (L_158_forvar1.name == "Volley Ball Legends")
													if L_158_forvar1.name == "Volley Ball Legends" then
														upvalue_1 = L_158_forvar1
														return
													end
												end
												return
											else
												L_125_ = L_124_:FindFirstChild("Volley")
												L_126_ = L_124_
												L_127_ = "Volley"
												if not L_124_:FindFirstChild("Volley") then
													L_125_ = L_124_:FindFirstChild("Brainrots")
													L_126_ = L_124_
													L_127_ = "Brainrots"
													if L_124_:FindFirstChild("Brainrots") then
														L_125_ = ipairs
														L_126_ = upvalue_0
														for L_159_forvar0, L_160_forvar1 in ipairs(upvalue_0) do
															L_130_ = L_160_forvar1.name
															L_131_ = "SAB"
															L_132_ = (L_160_forvar1.name == "SAB")
															if L_160_forvar1.name == "SAB" then
																upvalue_1 = L_160_forvar1
																return
															end
														end
														return
													else
														L_125_ = workspace:FindFirstChild("Brainrots")
														L_126_ = workspace
														L_127_ = "Brainrots"
														if not workspace:FindFirstChild("Brainrots") then
															L_125_ = workspace:FindFirstChild("Pickaxes")
															L_126_ = workspace
															L_127_ = "Pickaxes"
															if not workspace:FindFirstChild("Pickaxes") then
																return
															end
															L_125_ = ipairs
															L_126_ = upvalue_0
															for L_161_forvar0, L_162_forvar1 in ipairs(upvalue_0) do
																L_130_ = L_162_forvar1.name
																L_131_ = "+1 Pickaxe Swing Escape"
																L_132_ = (L_162_forvar1.name == "+1 Pickaxe Swing Escape")
																if L_162_forvar1.name == "+1 Pickaxe Swing Escape" then
																	upvalue_1 = L_162_forvar1
																	return
																end
															end
															return
														else
															L_125_ = ipairs
															L_126_ = upvalue_0
															for L_163_forvar0, L_164_forvar1 in ipairs(upvalue_0) do
																L_130_ = L_164_forvar1.name
																L_131_ = "SAB"
																L_132_ = (L_164_forvar1.name == "SAB")
																if L_164_forvar1.name == "SAB" then
																	upvalue_1 = L_164_forvar1
																	return
																end
															end
															return
														end
													end
												else
													L_125_ = ipairs
													L_126_ = upvalue_0
													for L_165_forvar0, L_166_forvar1 in ipairs(upvalue_0) do
														L_130_ = L_166_forvar1.name
														L_131_ = "Volley Ball Legends"
														L_132_ = (L_166_forvar1.name == "Volley Ball Legends")
														if L_166_forvar1.name == "Volley Ball Legends" then
															upvalue_1 = L_166_forvar1
															return
														end
													end
													return
												end
											end
										end
									else
										L_125_ = ipairs
										L_126_ = upvalue_0
										for L_167_forvar0, L_168_forvar1 in ipairs(upvalue_0) do
											L_130_ = L_168_forvar1.name
											L_131_ = "Forsaken"
											L_132_ = (L_168_forvar1.name == "Forsaken")
											if L_168_forvar1.name == "Forsaken" then
												upvalue_1 = L_168_forvar1
												return
											end
										end
										return
									end
								end
							else
								L_125_ = ipairs
								L_126_ = upvalue_0
								for L_169_forvar0, L_170_forvar1 in ipairs(upvalue_0) do
									L_130_ = L_170_forvar1.name
									L_131_ = "Fish It"
									L_132_ = (L_170_forvar1.name == "Fish It")
									if L_170_forvar1.name == "Fish It" then
										upvalue_1 = L_170_forvar1
										return
									end
								end
								return
							end
						end
					else
						L_125_ = L_124_.Remotes:FindFirstChild("CommF_")
						L_126_ = L_124_.Remotes
						L_127_ = "CommF_"
						if not L_124_.Remotes:FindFirstChild("CommF_") then
							L_125_ = L_124_:FindFirstChild("events")
							L_126_ = L_124_
							L_127_ = "events"
							if not L_124_:FindFirstChild("events") then
								L_125_ = L_124_:FindFirstChild("Forsaken")
								L_126_ = L_124_
								L_127_ = "Forsaken"
								if L_124_:FindFirstChild("Forsaken") then
									L_125_ = ipairs
									L_126_ = upvalue_0
									for L_171_forvar0, L_172_forvar1 in ipairs(upvalue_0) do
										L_130_ = L_172_forvar1.name
										L_131_ = "Forsaken"
										L_132_ = (L_172_forvar1.name == "Forsaken")
										if L_172_forvar1.name == "Forsaken" then
											upvalue_1 = L_172_forvar1
											return
										end
									end
									return
								else
									L_125_ = workspace:FindFirstChild("Forsaken")
									L_126_ = workspace
									L_127_ = "Forsaken"
									if not workspace:FindFirstChild("Forsaken") then
										L_125_ = L_124_:FindFirstChild("Volleyball")
										L_126_ = L_124_
										L_127_ = "Volleyball"
										if L_124_:FindFirstChild("Volleyball") then
											L_125_ = ipairs
											L_126_ = upvalue_0
											for L_173_forvar0, L_174_forvar1 in ipairs(upvalue_0) do
												L_130_ = L_174_forvar1.name
												L_131_ = "Volley Ball Legends"
												L_132_ = (L_174_forvar1.name == "Volley Ball Legends")
												if L_174_forvar1.name == "Volley Ball Legends" then
													upvalue_1 = L_174_forvar1
													return
												end
											end
											return
										else
											L_125_ = workspace:FindFirstChild("Volleyball")
											L_126_ = workspace
											L_127_ = "Volleyball"
											if workspace:FindFirstChild("Volleyball") then
												L_125_ = ipairs
												L_126_ = upvalue_0
												for L_175_forvar0, L_176_forvar1 in ipairs(upvalue_0) do
													L_130_ = L_176_forvar1.name
													L_131_ = "Volley Ball Legends"
													L_132_ = (L_176_forvar1.name == "Volley Ball Legends")
													if L_176_forvar1.name == "Volley Ball Legends" then
														upvalue_1 = L_176_forvar1
														return
													end
												end
												return
											else
												L_125_ = L_124_:FindFirstChild("Volley")
												L_126_ = L_124_
												L_127_ = "Volley"
												if not L_124_:FindFirstChild("Volley") then
													L_125_ = L_124_:FindFirstChild("Brainrots")
													L_126_ = L_124_
													L_127_ = "Brainrots"
													if L_124_:FindFirstChild("Brainrots") then
														L_125_ = ipairs
														L_126_ = upvalue_0
														for L_177_forvar0, L_178_forvar1 in ipairs(upvalue_0) do
															L_130_ = L_178_forvar1.name
															L_131_ = "SAB"
															L_132_ = (L_178_forvar1.name == "SAB")
															if L_178_forvar1.name == "SAB" then
																upvalue_1 = L_178_forvar1
																return
															end
														end
														return
													else
														L_125_ = workspace:FindFirstChild("Brainrots")
														L_126_ = workspace
														L_127_ = "Brainrots"
														if not workspace:FindFirstChild("Brainrots") then
															L_125_ = workspace:FindFirstChild("Pickaxes")
															L_126_ = workspace
															L_127_ = "Pickaxes"
															if not workspace:FindFirstChild("Pickaxes") then
																return
															end
															L_125_ = ipairs
															L_126_ = upvalue_0
															for L_179_forvar0, L_180_forvar1 in ipairs(upvalue_0) do
																L_130_ = L_180_forvar1.name
																L_131_ = "+1 Pickaxe Swing Escape"
																L_132_ = (L_180_forvar1.name == "+1 Pickaxe Swing Escape")
																if L_180_forvar1.name == "+1 Pickaxe Swing Escape" then
																	upvalue_1 = L_180_forvar1
																	return
																end
															end
															return
														else
															L_125_ = ipairs
															L_126_ = upvalue_0
															for L_181_forvar0, L_182_forvar1 in ipairs(upvalue_0) do
																L_130_ = L_182_forvar1.name
																L_131_ = "SAB"
																L_132_ = (L_182_forvar1.name == "SAB")
																if L_182_forvar1.name == "SAB" then
																	upvalue_1 = L_182_forvar1
																	return
																end
															end
															return
														end
													end
												else
													L_125_ = ipairs
													L_126_ = upvalue_0
													for L_183_forvar0, L_184_forvar1 in ipairs(upvalue_0) do
														L_130_ = L_184_forvar1.name
														L_131_ = "Volley Ball Legends"
														L_132_ = (L_184_forvar1.name == "Volley Ball Legends")
														if L_184_forvar1.name == "Volley Ball Legends" then
															upvalue_1 = L_184_forvar1
															return
														end
													end
													return
												end
											end
										end
									else
										L_125_ = ipairs
										L_126_ = upvalue_0
										for L_185_forvar0, L_186_forvar1 in ipairs(upvalue_0) do
											L_130_ = L_186_forvar1.name
											L_131_ = "Forsaken"
											L_132_ = (L_186_forvar1.name == "Forsaken")
											if L_186_forvar1.name == "Forsaken" then
												upvalue_1 = L_186_forvar1
												return
											end
										end
										return
									end
								end
							else
								L_125_ = L_124_.events:FindFirstChild("reels")
								L_126_ = L_124_.events
								L_127_ = "reels"
								if not L_124_.events:FindFirstChild("reels") then
									L_125_ = L_124_:FindFirstChild("Forsaken")
									L_126_ = L_124_
									L_127_ = "Forsaken"
									if L_124_:FindFirstChild("Forsaken") then
										L_125_ = ipairs
										L_126_ = upvalue_0
										for L_187_forvar0, L_188_forvar1 in ipairs(upvalue_0) do
											L_130_ = L_188_forvar1.name
											L_131_ = "Forsaken"
											L_132_ = (L_188_forvar1.name == "Forsaken")
											if L_188_forvar1.name == "Forsaken" then
												upvalue_1 = L_188_forvar1
												return
											end
										end
										return
									else
										L_125_ = workspace:FindFirstChild("Forsaken")
										L_126_ = workspace
										L_127_ = "Forsaken"
										if not workspace:FindFirstChild("Forsaken") then
											L_125_ = L_124_:FindFirstChild("Volleyball")
											L_126_ = L_124_
											L_127_ = "Volleyball"
											if L_124_:FindFirstChild("Volleyball") then
												L_125_ = ipairs
												L_126_ = upvalue_0
												for L_189_forvar0, L_190_forvar1 in ipairs(upvalue_0) do
													L_130_ = L_190_forvar1.name
													L_131_ = "Volley Ball Legends"
													L_132_ = (L_190_forvar1.name == "Volley Ball Legends")
													if L_190_forvar1.name == "Volley Ball Legends" then
														upvalue_1 = L_190_forvar1
														return
													end
												end
												return
											else
												L_125_ = workspace:FindFirstChild("Volleyball")
												L_126_ = workspace
												L_127_ = "Volleyball"
												if workspace:FindFirstChild("Volleyball") then
													L_125_ = ipairs
													L_126_ = upvalue_0
													for L_191_forvar0, L_192_forvar1 in ipairs(upvalue_0) do
														L_130_ = L_192_forvar1.name
														L_131_ = "Volley Ball Legends"
														L_132_ = (L_192_forvar1.name == "Volley Ball Legends")
														if L_192_forvar1.name == "Volley Ball Legends" then
															upvalue_1 = L_192_forvar1
															return
														end
													end
													return
												else
													L_125_ = L_124_:FindFirstChild("Volley")
													L_126_ = L_124_
													L_127_ = "Volley"
													if not L_124_:FindFirstChild("Volley") then
														L_125_ = L_124_:FindFirstChild("Brainrots")
														L_126_ = L_124_
														L_127_ = "Brainrots"
														if L_124_:FindFirstChild("Brainrots") then
															L_125_ = ipairs
															L_126_ = upvalue_0
															for L_193_forvar0, L_194_forvar1 in ipairs(upvalue_0) do
																L_130_ = L_194_forvar1.name
																L_131_ = "SAB"
																L_132_ = (L_194_forvar1.name == "SAB")
																if L_194_forvar1.name == "SAB" then
																	upvalue_1 = L_194_forvar1
																	return
																end
															end
															return
														else
															L_125_ = workspace:FindFirstChild("Brainrots")
															L_126_ = workspace
															L_127_ = "Brainrots"
															if not workspace:FindFirstChild("Brainrots") then
																L_125_ = workspace:FindFirstChild("Pickaxes")
																L_126_ = workspace
																L_127_ = "Pickaxes"
																if not workspace:FindFirstChild("Pickaxes") then
																	return
																end
																L_125_ = ipairs
																L_126_ = upvalue_0
																for L_195_forvar0, L_196_forvar1 in ipairs(upvalue_0) do
																	L_130_ = L_196_forvar1.name
																	L_131_ = "+1 Pickaxe Swing Escape"
																	L_132_ = (L_196_forvar1.name == "+1 Pickaxe Swing Escape")
																	if L_196_forvar1.name == "+1 Pickaxe Swing Escape" then
																		upvalue_1 = L_196_forvar1
																		return
																	end
																end
																return
															else
																L_125_ = ipairs
																L_126_ = upvalue_0
																for L_197_forvar0, L_198_forvar1 in ipairs(upvalue_0) do
																	L_130_ = L_198_forvar1.name
																	L_131_ = "SAB"
																	L_132_ = (L_198_forvar1.name == "SAB")
																	if L_198_forvar1.name == "SAB" then
																		upvalue_1 = L_198_forvar1
																		return
																	end
																end
																return
															end
														end
													else
														L_125_ = ipairs
														L_126_ = upvalue_0
														for L_199_forvar0, L_200_forvar1 in ipairs(upvalue_0) do
															L_130_ = L_200_forvar1.name
															L_131_ = "Volley Ball Legends"
															L_132_ = (L_200_forvar1.name == "Volley Ball Legends")
															if L_200_forvar1.name == "Volley Ball Legends" then
																upvalue_1 = L_200_forvar1
																return
															end
														end
														return
													end
												end
											end
										else
											L_125_ = ipairs
											L_126_ = upvalue_0
											for L_201_forvar0, L_202_forvar1 in ipairs(upvalue_0) do
												L_130_ = L_202_forvar1.name
												L_131_ = "Forsaken"
												L_132_ = (L_202_forvar1.name == "Forsaken")
												if L_202_forvar1.name == "Forsaken" then
													upvalue_1 = L_202_forvar1
													return
												end
											end
											return
										end
									end
								else
									L_125_ = ipairs
									L_126_ = upvalue_0
									for L_203_forvar0, L_204_forvar1 in ipairs(upvalue_0) do
										L_130_ = L_204_forvar1.name
										L_131_ = "Fish It"
										L_132_ = (L_204_forvar1.name == "Fish It")
										if L_204_forvar1.name == "Fish It" then
											upvalue_1 = L_204_forvar1
											return
										end
									end
									return
								end
							end
						else
							L_125_ = ipairs
							L_126_ = upvalue_0
							for L_205_forvar0, L_206_forvar1 in ipairs(upvalue_0) do
								L_130_ = L_206_forvar1.name
								L_131_ = "Blox Fruits"
								L_132_ = (L_206_forvar1.name == "Blox Fruits")
								if L_206_forvar1.name == "Blox Fruits" then
									upvalue_1 = L_206_forvar1
									return
								end
							end
							return
						end
					end
				else
					L_125_ = ipairs
					L_126_ = upvalue_0
					for L_207_forvar0, L_208_forvar1 in ipairs(upvalue_0) do
						L_130_ = L_208_forvar1.name
						L_131_ = "BedWars"
						L_132_ = (L_208_forvar1.name == "BedWars")
						if L_208_forvar1.name == "BedWars" then
							upvalue_1 = L_208_forvar1
							return
						end
					end
					return
				end
			end
		else
			L_125_ = ipairs
			L_126_ = upvalue_0
			for L_209_forvar0, L_210_forvar1 in ipairs(upvalue_0) do
				L_130_ = L_210_forvar1.name
				L_131_ = "BedWars"
				L_132_ = (L_210_forvar1.name == "BedWars")
				if L_210_forvar1.name == "BedWars" then
					upvalue_1 = L_210_forvar1
					return
				end
			end
			return
		end
	end
end

L_1_.callback_43 = function()
	local L_211_, L_212_
	upvalue_0:Destroy()
	return
end

L_1_.callback_44 = function()
	local L_213_, L_214_, L_215_, L_216_, L_217_, L_218_, L_219_, L_220_
	L_215_ = {}
	L_215_.Position = UDim2.new(1, 380, 1, -100)
	L_215_.BackgroundTransparency = 0.5
	tw(upvalue_0, L_215_, 0.4)
	task.wait(0.45)
	pcall(L_1_.callback_43)
	return
end

L_1_.callback_45 = function(L_221_arg0, L_222_arg1, L_223_arg2, L_224_arg3)
	local L_225_, L_226_, L_227_, L_228_, L_229_, L_230_, L_231_, L_232_, L_233_, L_234_, L_235_, L_236_, L_237_
	if not (L_223_arg2) then
		L_223_arg2 = 4
	end
	L_225_ = upvalue_0
	if not (upvalue_0) then
		L_225_ = Instance.new("ScreenGui", upvalue_1)
		L_225_.Name = "SnowyNotifs"
		L_225_.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
		upvalue_0 = L_225_
		L_226_ = Enum.ZIndexBehavior.Sibling
		L_227_ = upvalue_1
	end
	L_225_ = Instance.new("Frame", upvalue_0)
	L_225_.Size = UDim2.new(0, 340, 0, 80)
	L_225_.Position = UDim2.new(1, 360, 1, -100)
	L_225_.BackgroundColor3 = upvalue_2.BgCard
	L_225_.ZIndex = 500
	corner(upvalue_2.RadiusSm, L_225_)
	L_226_ = stroke
	L_227_ = upvalue_2.RadiusSm
	L_228_ = L_225_
	L_229_ = 1
	L_230_ = -100
	if not L_224_arg3 then
		L_227_ = upvalue_2.Accent
		L_228_ = upvalue_2
	else
		L_227_ = upvalue_2.Premium
		L_228_ = upvalue_2
		if not (upvalue_2.Premium) then
			L_227_ = upvalue_2.Accent
			L_228_ = upvalue_2
		end
	end
	L_226_(L_227_, 1.5, L_225_)
	gradient(L_225_, upvalue_2.BgSecondary, upvalue_2.BgCard, 90)
	L_226_ = Instance.new("Frame", L_225_)
	L_226_.Size = UDim2.new(0, 5, 0.6, 0)
	L_226_.Position = UDim2.new(0, 10, 0.2, 0)
	L_227_ = UDim2.new(0, 10, 0.2, 0)
	L_228_ = 0
	L_229_ = 10
	L_230_ = 0.2
	L_231_ = 0
	if not L_224_arg3 then
		L_227_ = upvalue_2.Accent
		L_228_ = upvalue_2
	else
		L_227_ = upvalue_2.Premium
		L_228_ = upvalue_2
		if not (upvalue_2.Premium) then
			L_227_ = upvalue_2.Accent
			L_228_ = upvalue_2
		end
	end
	L_226_.BackgroundColor3 = L_227_
	L_226_.BorderSizePixel = 0
	L_226_.ZIndex = 501
	corner(upvalue_2.RadiusPill, L_226_)
	L_227_ = Instance.new("TextLabel", L_225_)
	L_227_.Size = UDim2.new(1, -40, 0, 22)
	L_227_.Position = UDim2.new(0, 24, 0, 10)
	L_227_.BackgroundTransparency = 1
	L_227_.Text = L_221_arg0
	L_228_ = 1
	L_229_ = 0
	L_230_ = 24
	L_231_ = 0
	L_232_ = 10
	if not L_224_arg3 then
		L_228_ = upvalue_2.AccentBright
		L_229_ = upvalue_2
	else
		L_228_ = upvalue_2.Premium
		L_229_ = upvalue_2
		if not (upvalue_2.Premium) then
			L_228_ = upvalue_2.AccentBright
			L_229_ = upvalue_2
		end
	end
	L_227_.TextColor3 = L_228_
	L_227_.Font = Enum.Font.GothamBlack
	L_227_.TextSize = 14
	L_227_.ZIndex = 501
	L_227_.TextXAlignment = Enum.TextXAlignment.Left
	L_228_ = Instance.new("TextLabel", L_225_)
	L_228_.Size = UDim2.new(1, -40, 0, 36)
	L_228_.Position = UDim2.new(0, 24, 0, 34)
	L_228_.BackgroundTransparency = 1
	L_228_.Text = L_222_arg1
	L_228_.TextColor3 = upvalue_2.TextSecondary
	L_228_.Font = Enum.Font.Gotham
	L_228_.TextSize = 12
	L_228_.TextWrapped = true
	L_228_.ZIndex = 501
	L_228_.TextXAlignment = Enum.TextXAlignment.Left
	L_229_ = Instance.new("Frame", L_225_)
	L_229_.Size = UDim2.new(1, -20, 0, 3)
	L_229_.Position = UDim2.new(0, 10, 1, -8)
	L_230_ = UDim2.new(0, 10, 1, -8)
	L_231_ = 0
	L_232_ = 10
	L_233_ = 1
	L_234_ = -8
	if not L_224_arg3 then
		L_230_ = upvalue_2.Accent
		L_231_ = upvalue_2
	else
		L_230_ = upvalue_2.Premium
		L_231_ = upvalue_2
		if upvalue_2.Premium then
			L_229_.BackgroundColor3 = L_230_
			L_229_.ZIndex = 501
			corner(upvalue_2.RadiusPill, L_229_)
			L_232_ = {}
			L_232_.Size = UDim2.new(0, 0, 0, 3)
			tw(L_229_, L_232_, L_223_arg2, Enum.EasingStyle.Linear)
			L_232_ = {}
			L_232_.Position = UDim2.new(1, -360, 1, -100)
			tw(L_225_, L_232_, 0.5, Enum.EasingStyle.Back)
			task.delay(L_223_arg2, L_1_.callback_44)
			return
		end
		L_230_ = upvalue_2.Accent
		L_231_ = upvalue_2
	end
	L_229_.BackgroundColor3 = L_230_
	L_229_.ZIndex = 501
	corner(upvalue_2.RadiusPill, L_229_)
	L_232_ = {}
	L_232_.Size = UDim2.new(0, 0, 0, 3)
	tw(L_229_, L_232_, L_223_arg2, Enum.EasingStyle.Linear)
	L_232_ = {}
	L_232_.Position = UDim2.new(1, -360, 1, -100)
	tw(L_225_, L_232_, 0.5, Enum.EasingStyle.Back)
	task.delay(L_223_arg2, L_1_.callback_44)
	return
end

L_1_.Notify = function(L_238_arg0, L_239_arg1, L_240_arg2, L_241_arg3, L_242_arg4)
	local L_243_, L_244_, L_245_, L_246_, L_247_, L_248_
	task.spawn(upvalue_0, L_239_arg1, L_240_arg2, L_241_arg3, L_242_arg4)
	return
end

L_1_.callback_47 = function()
	local L_249_, L_250_
	upvalue_0:Destroy()
	return
end

L_1_.callback_48 = function()
	local L_251_, L_252_
	syn.protect_gui(upvalue_0)
	L_251_ = upvalue_0
	L_251_.Parent = upvalue_1
	upvalue_2 = true
	return
end

L_1_.callback_49 = function()
	local L_253_, L_254_
	L_253_ = upvalue_0
	L_253_.Parent = gethui()
	upvalue_1 = true
	return
end

L_1_.callback_50 = function()
	local L_255_, L_256_
	L_255_ = upvalue_0
	L_255_.Parent = get_hidden_gui()
	upvalue_1 = true
	return
end

L_1_.callback_51 = function()
	local L_257_, L_258_, L_259_, L_260_
	L_257_ = upvalue_0
	L_259_ = upvalue_1:IsStudio()
	L_260_ = upvalue_1
	if not upvalue_1:IsStudio() then
		L_258_ = upvalue_3
	else
		L_258_ = upvalue_2.PlayerGui
		L_259_ = upvalue_2
		if upvalue_2.PlayerGui then
			L_257_.Parent = L_258_
			return
		end
		L_258_ = upvalue_3
	end
	L_257_.Parent = L_258_
	return
end

L_1_.callback_52 = function()
	local L_261_, L_262_, L_263_, L_264_, L_265_, L_266_, L_267_, L_268_
	L_263_ = {}
	L_263_.Size = UDim2.new(1, -52, 0, 46)
	tw(upvalue_0, L_263_, 0.15)
	return
end

L_1_.callback_53 = function()
	local L_269_, L_270_, L_271_, L_272_, L_273_, L_274_, L_275_, L_276_
	L_271_ = {}
	L_271_.Size = UDim2.new(1, -60, 0, 44)
	tw(upvalue_0, L_271_, 0.15)
	return
end

L_1_.callback_54 = function()
	local L_277_, L_278_
	L_277_ = setclipboard
	if not setclipboard then
		return
	end
	setclipboard("https://getsnowy.xyz/pricing")
	upvalue_0 = true
	L_277_ = true
	L_278_ = "https://getsnowy.xyz/pricing"
	return
end

L_1_.callback_55 = function()
	local L_279_, L_280_
	toclipboard("https://getsnowy.xyz/pricing")
	upvalue_0 = true
	return
end

L_1_.callback_56 = function()
	local L_281_, L_282_, L_283_, L_284_, L_285_
	L_281_ = upvalue_0
	L_281_.Text = "\u{2726}  getsnowy.xyz/pricing    \u{2022}  Click to copy"
	L_283_ = {}
	L_283_.BackgroundColor3 = upvalue_1.Premium
	tw(upvalue_0, L_283_, 0.2)
	return
end

L_1_.callback_57 = function()
	local L_286_, L_287_
	pcall(L_1_.callback_56)
	return
end

L_1_.callback_58 = function()
	local L_288_, L_289_, L_290_, L_291_, L_292_, L_293_
	pcall(L_1_.callback_54)
	L_288_ = false
	L_289_ = pcall
	L_290_ = L_1_.callback_54
	if true then
		pcall(L_1_.callback_55)
		L_289_ = pcall
		L_290_ = L_1_.callback_55
	end
	L_289_ = upvalue_0
	if not L_288_ then
		L_290_ = "Visit getsnowy.xyz/pricing"
		L_291_ = "Visit "
		L_292_ = "getsnowy.xyz/pricing"
	else
		L_290_ = "\u{2714}  Copied  https://getsnowy.xyz/pricing"
		L_291_ = "\u{2714}  Copied  "
		L_292_ = "https://getsnowy.xyz/pricing"
		if "\u{2714}  Copied  https://getsnowy.xyz/pricing" then
			L_289_.Text = L_290_
			L_291_ = {}
			L_291_.BackgroundColor3 = upvalue_1.Success
			tw(upvalue_0, L_291_, 0.15)
			task.delay(1.4, L_1_.callback_57)

			return
		end
		L_290_ = "Visit getsnowy.xyz/pricing"
		L_291_ = "Visit "
		L_292_ = "getsnowy.xyz/pricing"
	end
	L_289_.Text = L_290_
	L_291_ = {}
	L_291_.BackgroundColor3 = upvalue_1.Success
	tw(upvalue_0, L_291_, 0.15)
	task.delay(1.4, L_1_.callback_57)

	return
end

L_1_.callback_59 = function()
	local L_294_, L_295_
	upvalue_0:Destroy()
	return
end

L_1_.callback_60 = function()
	local L_296_, L_297_, L_298_, L_299_
	pcall(L_1_.callback_59)
	L_296_ = upvalue_1
	L_297_ = upvalue_0
	L_299_ = (upvalue_1 == upvalue_0)
	if not (upvalue_1 == upvalue_0) then
		return
	end
	upvalue_1 = nil
	L_296_ = nil
	return
end

L_1_.callback_61 = function()
	local L_300_, L_301_, L_302_, L_303_, L_304_, L_305_
	L_300_ = upvalue_0.Parent
	L_301_ = upvalue_0
	if upvalue_0.Parent then
		L_302_ = {}
		L_302_.BackgroundTransparency = 1
		tw(upvalue_1, L_302_, 0.2)
		L_302_ = {}
		L_302_.Size = UDim2.fromOffset(0, 0)
		tw(upvalue_2, L_302_, 0.18, Enum.EasingStyle.Back, Enum.EasingDirection.In)
		task.delay(0.22, L_1_.callback_60)
		return
	else
		return
	end
end

L_1_.callback_62 = function()
	local L_306_, L_307_, L_308_, L_309_
	L_306_ = upvalue_0
	L_307_ = upvalue_1
	L_309_ = (upvalue_0 == upvalue_1)
	if not (upvalue_0 == upvalue_1) then
		return
	end
	upvalue_2()
	L_306_ = upvalue_2
	return
end

L_1_.callback_63 = function()
	local L_310_, L_311_, L_312_, L_313_, L_314_, L_315_, L_316_, L_317_, L_318_, L_319_, L_320_, L_321_, L_322_, L_323_, L_324_, L_325_
	local L_326_, L_327_, L_328_, L_329_, L_330_, L_331_, L_332_, L_333_, L_334_, L_335_, L_336_, L_337_
	L_311_ = upvalue_0
	if not upvalue_0 then
		L_310_ = "That feature"
	else
		L_310_ = tostring(upvalue_0)
		L_311_ = upvalue_0
		if not (tostring(upvalue_0)) then
			L_310_ = "That feature"
		end
	end
	L_311_ = Instance.new("ScreenGui")
	L_311_.Name = "SnowyPremiumModal"
	L_311_.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
	L_311_.IgnoreGuiInset = true
	L_311_.ResetOnSpawn = false
	L_311_.DisplayOrder = 2147483647
	L_312_ = false
	L_313_ = upvalue_1:IsStudio()
	L_314_ = upvalue_1
	if not (upvalue_1:IsStudio()) then
		L_313_ = syn
		if syn then
			L_313_ = syn.protect_gui
			if syn.protect_gui then
				pcall(L_1_.callback_48)
				L_313_ = pcall
				L_314_ = L_1_.callback_48
			end
		end
		if not (L_312_) then
			L_313_ = gethui
			if gethui then
				pcall(L_1_.callback_49)
				L_313_ = pcall
				L_314_ = L_1_.callback_49
			end
		end
		if not (L_312_) then
			L_313_ = get_hidden_gui
			if get_hidden_gui then
				pcall(L_1_.callback_50)
				L_313_ = pcall
				L_314_ = L_1_.callback_50
			end
		end
	end
	if L_312_ then
		upvalue_4 = L_311_
		L_313_ = Instance.new("TextButton", L_311_)
		L_313_.Name = "Backdrop"
		L_313_.Size = UDim2.fromScale(1, 1)
		L_313_.BackgroundColor3 = Color3.new(0, 0, 0)
		L_313_.BackgroundTransparency = 1
		L_313_.BorderSizePixel = 0
		L_313_.AutoButtonColor = false
		L_313_.Text = ""
		L_313_.ZIndex = 9000
		L_316_ = {}
		L_316_.BackgroundTransparency = 0.45
		tw(L_313_, L_316_, 0.2)
		L_314_ = Instance.new("Frame", L_311_)
		L_314_.Name = "Card"
		L_314_.AnchorPoint = Vector2.new(0.5, 0.5)
		L_314_.Position = UDim2.fromScale(0.5, 0.5)
		L_314_.Size = UDim2.fromOffset(0, 0)
		L_314_.BackgroundColor3 = upvalue_5.BgCard
		L_314_.BorderSizePixel = 0
		L_314_.ZIndex = 9010
		L_314_.ClipsDescendants = true
		corner(18, L_314_)
		stroke(upvalue_5.Premium, 2, L_314_)
		gradient(L_314_, upvalue_5.BgSecondary, upvalue_5.BgCard, 125)
		shadow(L_314_)
		L_315_ = Instance.new("Frame", L_314_)
		L_315_.Size = UDim2.new(1, 0, 0, 4)
		L_315_.BackgroundColor3 = upvalue_5.Premium
		L_315_.BorderSizePixel = 0
		L_315_.ZIndex = 9011
		gradient(L_315_, upvalue_5.PremiumDark, upvalue_5.Premium, 0)
		L_316_ = Instance.new("Frame", L_314_)
		L_316_.Name = "LockContainer"
		L_316_.Size = UDim2.new(0, 68, 0, 68)
		L_316_.Position = UDim2.new(0.5, -34, 0, 28)
		L_316_.BackgroundColor3 = upvalue_5.PremiumDim
		L_316_.BorderSizePixel = 0
		L_316_.ZIndex = 9012
		corner(999, L_316_)
		stroke(upvalue_5.Premium, 2, L_316_)
		L_317_ = Instance.new("Frame", L_316_)
		L_317_.Name = "Shackle"
		L_317_.Size = UDim2.new(0, 26, 0, 26)
		L_317_.Position = UDim2.new(0.5, -13, 0.5, -23)
		L_317_.BackgroundTransparency = 1
		L_317_.ZIndex = 9013
		L_318_ = Instance.new("UICorner", L_317_)
		L_318_.CornerRadius = UDim.new(0.5, 0)
		L_319_ = Instance.new("UIStroke", L_317_)
		L_319_.Color = upvalue_5.Premium
		L_319_.Thickness = 3
		L_319_.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		L_320_ = Instance.new("Frame", L_316_)
		L_320_.Name = "Body"
		L_320_.Size = UDim2.new(0, 34, 0, 26)
		L_320_.Position = UDim2.new(0.5, -17, 0.5, -7)
		L_320_.BackgroundColor3 = upvalue_5.Premium
		L_320_.BorderSizePixel = 0
		L_320_.ZIndex = 9014
		L_321_ = Instance.new("UICorner", L_320_)
		L_321_.CornerRadius = UDim.new(0, 4)
		L_322_ = Instance.new("Frame", L_320_)
		L_322_.Name = "KeyholeCircle"
		L_322_.Size = UDim2.new(0, 6, 0, 6)
		L_322_.Position = UDim2.new(0.5, -3, 0.3, 0)
		L_322_.BackgroundColor3 = upvalue_5.BgCard
		L_322_.BorderSizePixel = 0
		L_322_.ZIndex = 9015
		L_323_ = Instance.new("UICorner", L_322_)
		L_323_.CornerRadius = UDim.new(1, 0)
		L_324_ = Instance.new("Frame", L_320_)
		L_324_.Name = "KeyholeLine"
		L_324_.Size = UDim2.new(0, 3, 0, 8)
		L_324_.Position = UDim2.new(0.5, -1.5, 0.3, 4)
		L_324_.BackgroundColor3 = upvalue_5.BgCard
		L_324_.BorderSizePixel = 0
		L_324_.ZIndex = 9015
		L_325_ = Instance.new("UICorner", L_324_)
		L_325_.CornerRadius = UDim.new(0, 1)
		L_326_ = Instance.new("TextLabel", L_314_)
		L_326_.Size = UDim2.new(1, -30, 0, 28)
		L_326_.Position = UDim2.new(0, 15, 0, 106)
		L_326_.BackgroundTransparency = 1
		L_326_.Text = "PREMIUM FEATURE"
		L_326_.TextColor3 = upvalue_5.Premium
		L_326_.Font = Enum.Font.GothamBlack
		L_326_.TextSize = 20
		L_326_.ZIndex = 9012
		L_327_ = Instance.new("TextLabel", L_314_)
		L_327_.Size = UDim2.new(1, -30, 0, 22)
		L_327_.Position = UDim2.new(0, 15, 0, 136)
		L_327_.BackgroundTransparency = 1
		L_327_.Text = "\u{201c}" .. L_310_ .. "\u{201d} is locked."
		L_327_.TextColor3 = upvalue_5.TextPrimary
		L_327_.Font = Enum.Font.GothamSemibold
		L_327_.TextSize = 14
		L_327_.TextTruncate = Enum.TextTruncate.AtEnd
		L_327_.ZIndex = 9012
		L_328_ = Instance.new("TextLabel", L_314_)
		L_328_.Size = UDim2.new(1, -30, 0, 20)
		L_328_.Position = UDim2.new(0, 15, 0, 160)
		L_328_.BackgroundTransparency = 1
		L_328_.Text = "Unlock every Snowy Premium feature at"
		L_328_.TextColor3 = upvalue_5.TextSecondary
		L_328_.Font = Enum.Font.Gotham
		L_328_.TextSize = 12
		L_328_.ZIndex = 9012
		L_329_ = Instance.new("TextButton", L_314_)
		L_329_.Size = UDim2.new(1, -60, 0, 44)
		L_329_.Position = UDim2.new(0, 30, 0, 188)
		L_329_.BackgroundColor3 = upvalue_5.Premium
		L_329_.BorderSizePixel = 0
		L_329_.AutoButtonColor = false
		L_329_.Text = "\u{2726}  getsnowy.xyz/pricing    \u{2022}  Click to copy"
		L_329_.TextColor3 = Color3.fromRGB(20, 15, 0)
		L_329_.Font = Enum.Font.GothamBlack
		L_329_.TextSize = 15
		L_329_.ZIndex = 9012
		corner(10, L_329_)
		stroke(upvalue_5.PremiumDark, 1, L_329_)
		gradient(L_329_, upvalue_5.Premium, upvalue_5.PremiumDark, 90)
		L_329_.MouseEnter:Connect(L_1_.callback_52)
		L_329_.MouseLeave:Connect(L_1_.callback_53)
		L_329_.Activated:Connect(L_1_.callback_58)
		L_330_ = Instance.new("TextButton", L_314_)
		L_330_.Size = UDim2.new(1, -60, 0, 32)
		L_330_.Position = UDim2.new(0, 30, 0, 242)
		L_330_.BackgroundColor3 = upvalue_5.BgInput
		L_330_.BorderSizePixel = 0
		L_330_.AutoButtonColor = false
		L_330_.Text = "Maybe later"
		L_330_.TextColor3 = upvalue_5.TextSecondary
		L_330_.Font = Enum.Font.GothamMedium
		L_330_.TextSize = 13
		L_330_.ZIndex = 9012
		corner(8, L_330_)
		stroke(upvalue_5.Border, 1, L_330_)
		L_330_.Activated:Connect(L_1_.callback_61)
		L_313_.Activated:Connect(L_1_.callback_61)
		L_314_.Size = UDim2.fromOffset(0, 0)
		L_334_ = {}
		L_334_.Size = UDim2.fromOffset(400, 300)
		tw(L_314_, L_334_, 0.35, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
		task.delay(7, L_1_.callback_62)

		return
	end
	pcall(L_1_.callback_51)
	L_313_ = pcall
	L_314_ = L_1_.callback_51
	upvalue_4 = L_311_
	L_313_ = Instance.new("TextButton", L_311_)
	L_313_.Name = "Backdrop"
	L_313_.Size = UDim2.fromScale(1, 1)
	L_313_.BackgroundColor3 = Color3.new(0, 0, 0)
	L_313_.BackgroundTransparency = 1
	L_313_.BorderSizePixel = 0
	L_313_.AutoButtonColor = false
	L_313_.Text = ""
	L_313_.ZIndex = 9000
	L_316_ = {}
	L_316_.BackgroundTransparency = 0.45
	tw(L_313_, L_316_, 0.2)
	L_314_ = Instance.new("Frame", L_311_)
	L_314_.Name = "Card"
	L_314_.AnchorPoint = Vector2.new(0.5, 0.5)
	L_314_.Position = UDim2.fromScale(0.5, 0.5)
	L_314_.Size = UDim2.fromOffset(0, 0)
	L_314_.BackgroundColor3 = upvalue_5.BgCard
	L_314_.BorderSizePixel = 0
	L_314_.ZIndex = 9010
	L_314_.ClipsDescendants = true
	corner(18, L_314_)
	stroke(upvalue_5.Premium, 2, L_314_)
	gradient(L_314_, upvalue_5.BgSecondary, upvalue_5.BgCard, 125)
	shadow(L_314_)
	L_315_ = Instance.new("Frame", L_314_)
	L_315_.Size = UDim2.new(1, 0, 0, 4)
	L_315_.BackgroundColor3 = upvalue_5.Premium
	L_315_.BorderSizePixel = 0
	L_315_.ZIndex = 9011
	gradient(L_315_, upvalue_5.PremiumDark, upvalue_5.Premium, 0)
	L_316_ = Instance.new("Frame", L_314_)
	L_316_.Name = "LockContainer"
	L_316_.Size = UDim2.new(0, 68, 0, 68)
	L_316_.Position = UDim2.new(0.5, -34, 0, 28)
	L_316_.BackgroundColor3 = upvalue_5.PremiumDim
	L_316_.BorderSizePixel = 0
	L_316_.ZIndex = 9012
	corner(999, L_316_)
	stroke(upvalue_5.Premium, 2, L_316_)
	L_317_ = Instance.new("Frame", L_316_)
	L_317_.Name = "Shackle"
	L_317_.Size = UDim2.new(0, 26, 0, 26)
	L_317_.Position = UDim2.new(0.5, -13, 0.5, -23)
	L_317_.BackgroundTransparency = 1
	L_317_.ZIndex = 9013
	L_318_ = Instance.new("UICorner", L_317_)
	L_318_.CornerRadius = UDim.new(0.5, 0)
	L_319_ = Instance.new("UIStroke", L_317_)
	L_319_.Color = upvalue_5.Premium
	L_319_.Thickness = 3
	L_319_.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	L_320_ = Instance.new("Frame", L_316_)
	L_320_.Name = "Body"
	L_320_.Size = UDim2.new(0, 34, 0, 26)
	L_320_.Position = UDim2.new(0.5, -17, 0.5, -7)
	L_320_.BackgroundColor3 = upvalue_5.Premium
	L_320_.BorderSizePixel = 0
	L_320_.ZIndex = 9014
	L_321_ = Instance.new("UICorner", L_320_)
	L_321_.CornerRadius = UDim.new(0, 4)
	L_322_ = Instance.new("Frame", L_320_)
	L_322_.Name = "KeyholeCircle"
	L_322_.Size = UDim2.new(0, 6, 0, 6)
	L_322_.Position = UDim2.new(0.5, -3, 0.3, 0)
	L_322_.BackgroundColor3 = upvalue_5.BgCard
	L_322_.BorderSizePixel = 0
	L_322_.ZIndex = 9015
	L_323_ = Instance.new("UICorner", L_322_)
	L_323_.CornerRadius = UDim.new(1, 0)
	L_324_ = Instance.new("Frame", L_320_)
	L_324_.Name = "KeyholeLine"
	L_324_.Size = UDim2.new(0, 3, 0, 8)
	L_324_.Position = UDim2.new(0.5, -1.5, 0.3, 4)
	L_324_.BackgroundColor3 = upvalue_5.BgCard
	L_324_.BorderSizePixel = 0
	L_324_.ZIndex = 9015
	L_325_ = Instance.new("UICorner", L_324_)
	L_325_.CornerRadius = UDim.new(0, 1)
	L_326_ = Instance.new("TextLabel", L_314_)
	L_326_.Size = UDim2.new(1, -30, 0, 28)
	L_326_.Position = UDim2.new(0, 15, 0, 106)
	L_326_.BackgroundTransparency = 1
	L_326_.Text = "PREMIUM FEATURE"
	L_326_.TextColor3 = upvalue_5.Premium
	L_326_.Font = Enum.Font.GothamBlack
	L_326_.TextSize = 20
	L_326_.ZIndex = 9012
	L_327_ = Instance.new("TextLabel", L_314_)
	L_327_.Size = UDim2.new(1, -30, 0, 22)
	L_327_.Position = UDim2.new(0, 15, 0, 136)
	L_327_.BackgroundTransparency = 1
	L_327_.Text = "\u{201c}" .. L_310_ .. "\u{201d} is locked."
	L_327_.TextColor3 = upvalue_5.TextPrimary
	L_327_.Font = Enum.Font.GothamSemibold
	L_327_.TextSize = 14
	L_327_.TextTruncate = Enum.TextTruncate.AtEnd
	L_327_.ZIndex = 9012
	L_328_ = Instance.new("TextLabel", L_314_)
	L_328_.Size = UDim2.new(1, -30, 0, 20)
	L_328_.Position = UDim2.new(0, 15, 0, 160)
	L_328_.BackgroundTransparency = 1
	L_328_.Text = "Unlock every Snowy Premium feature at"
	L_328_.TextColor3 = upvalue_5.TextSecondary
	L_328_.Font = Enum.Font.Gotham
	L_328_.TextSize = 12
	L_328_.ZIndex = 9012
	L_329_ = Instance.new("TextButton", L_314_)
	L_329_.Size = UDim2.new(1, -60, 0, 44)
	L_329_.Position = UDim2.new(0, 30, 0, 188)
	L_329_.BackgroundColor3 = upvalue_5.Premium
	L_329_.BorderSizePixel = 0
	L_329_.AutoButtonColor = false
	L_329_.Text = "\u{2726}  getsnowy.xyz/pricing    \u{2022}  Click to copy"
	L_329_.TextColor3 = Color3.fromRGB(20, 15, 0)
	L_329_.Font = Enum.Font.GothamBlack
	L_329_.TextSize = 15
	L_329_.ZIndex = 9012
	corner(10, L_329_)
	stroke(upvalue_5.PremiumDark, 1, L_329_)
	gradient(L_329_, upvalue_5.Premium, upvalue_5.PremiumDark, 90)
	L_329_.MouseEnter:Connect(L_1_.callback_52)
	L_329_.MouseLeave:Connect(L_1_.callback_53)
	L_329_.Activated:Connect(L_1_.callback_58)
	L_330_ = Instance.new("TextButton", L_314_)
	L_330_.Size = UDim2.new(1, -60, 0, 32)
	L_330_.Position = UDim2.new(0, 30, 0, 242)
	L_330_.BackgroundColor3 = upvalue_5.BgInput
	L_330_.BorderSizePixel = 0
	L_330_.AutoButtonColor = false
	L_330_.Text = "Maybe later"
	L_330_.TextColor3 = upvalue_5.TextSecondary
	L_330_.Font = Enum.Font.GothamMedium
	L_330_.TextSize = 13
	L_330_.ZIndex = 9012
	corner(8, L_330_)
	stroke(upvalue_5.Border, 1, L_330_)
	L_330_.Activated:Connect(L_1_.callback_61)
	L_313_.Activated:Connect(L_1_.callback_61)
	L_314_.Size = UDim2.fromOffset(0, 0)
	L_334_ = {}
	L_334_.Size = UDim2.fromOffset(400, 300)
	tw(L_314_, L_334_, 0.35, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
	task.delay(7, L_1_.callback_62)

	return
end

L_1_.callback_64 = function(L_338_arg0)
	local L_339_, L_340_, L_341_, L_342_, L_343_, L_344_, L_345_, L_346_, L_347_, L_348_, L_349_, L_350_, L_351_
	L_339_ = tick()
	L_340_ = (tick() - upvalue_0)
	L_341_ = 1.2
	L_351_ = ((tick() - upvalue_0) < 1.2)
	if (tick() - upvalue_0) < 1.2 then
		return
	end
	upvalue_0 = L_339_
	L_340_ = upvalue_1
	if upvalue_1 then
		pcall(L_1_.callback_47)
		upvalue_1 = nil
		L_340_ = nil
		L_341_ = L_1_.callback_47
	end
	L_340_ = pcall
	L_341_ = L_1_.callback_63
	L_340_, L_341_ = pcall(L_1_.callback_63)
	if L_340_ then
		return
	end
	if not L_338_arg0 then
		L_342_ = "That feature"
	else
		L_342_ = "'" .. tostring(L_338_arg0) .. "'"
		L_343_ = "'"
		L_344_ = tostring(L_338_arg0)
		L_345_ = "'"
		L_346_ = tostring(L_338_arg0)
		L_347_ = L_338_arg0
		if not ("'" .. tostring(L_338_arg0) .. "'") then
			L_342_ = "That feature"
		end
	end
	upvalue_6:Notify("\u{2726}  PREMIUM LOCKED", L_342_ .. " is locked to Snowy Premium. Upgrade at getsnowy.xyz/pricing", 5, true)
	L_343_ = upvalue_6.Notify
	L_344_ = upvalue_6
	L_345_ = "\u{2726}  PREMIUM LOCKED"
	L_346_ = L_342_ .. " is locked to Snowy Premium. Upgrade at getsnowy.xyz/pricing"
	L_347_ = 5
	L_348_ = true
	L_349_ = "getsnowy.xyz/pricing"
	return
end

L_1_.callback_65 = function(L_352_arg0, L_353_arg1)
	local L_354_, L_355_, L_356_, L_357_, L_358_, L_359_, L_360_, L_361_
	L_354_ = Instance.new(L_352_arg0)
	for L_362_forvar0, L_363_forvar1 in next, L_353_arg1 do
		L_360_ = "Parent"
		L_361_ = (L_362_forvar0 == "Parent")
		if not (L_362_forvar0 == "Parent") then
			L_354_[L_362_forvar0] = L_363_forvar1
		end
	end
	L_354_.Parent = L_353_arg1.Parent
	return L_354_
end

L_1_.callback_66 = function(L_364_arg0, L_365_arg1, L_366_arg2)
	local L_367_, L_368_, L_369_, L_370_, L_371_, L_372_, L_373_
	L_367_ = upvalue_0:Create(L_364_arg0, TweenInfo.new(L_365_arg1, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_366_arg2)
	L_367_:Play()
	return
end

L_1_.callback_67 = function(L_374_arg0)
	local L_375_, L_376_, L_377_, L_378_
	L_375_ = L_374_arg0.UserInputType
	L_376_ = Enum.UserInputType.MouseButton1
	L_378_ = (L_374_arg0.UserInputType == Enum.UserInputType.MouseButton1)
	if (L_374_arg0.UserInputType == Enum.UserInputType.MouseButton1) then
		L_375_ = upvalue_0._blockDrag
		L_376_ = upvalue_0
		if upvalue_0._blockDrag then
			return
		end
		upvalue_1 = true
		upvalue_2 = false
		upvalue_3 = L_374_arg0.Position
		upvalue_4 = upvalue_5.Position
		L_375_ = upvalue_5.Position
		L_376_ = upvalue_5
	else
		L_375_ = L_374_arg0.UserInputType
		L_376_ = Enum.UserInputType.Touch
		L_378_ = (L_374_arg0.UserInputType == Enum.UserInputType.Touch)
		if not (L_374_arg0.UserInputType == Enum.UserInputType.Touch) then
			return
		end
		L_375_ = upvalue_0._blockDrag
		L_376_ = upvalue_0
		if upvalue_0._blockDrag then
			return
		end
		upvalue_1 = true
		upvalue_2 = false
		upvalue_3 = L_374_arg0.Position
		upvalue_4 = upvalue_5.Position
		L_375_ = upvalue_5.Position
		L_376_ = upvalue_5
	end
	return
end

L_1_.callback_68 = function(L_379_arg0)
	local L_380_, L_381_, L_382_, L_383_
	L_380_ = L_379_arg0.UserInputType
	L_381_ = Enum.UserInputType.MouseButton1
	L_383_ = (L_379_arg0.UserInputType == Enum.UserInputType.MouseButton1)
	if (L_379_arg0.UserInputType == Enum.UserInputType.MouseButton1) then
		upvalue_0 = false
		L_380_ = false
	else
		L_380_ = L_379_arg0.UserInputType
		L_381_ = Enum.UserInputType.Touch
		L_383_ = (L_379_arg0.UserInputType == Enum.UserInputType.Touch)
		if not (L_379_arg0.UserInputType == Enum.UserInputType.Touch) then
			return
		end
		upvalue_0 = false
		L_380_ = false
	end
	return
end

L_1_.callback_69 = function(L_384_arg0)
	local L_385_, L_386_, L_387_, L_388_, L_389_, L_390_, L_391_, L_392_, L_393_, L_394_, L_395_, L_396_
	L_385_ = upvalue_0
	if not upvalue_0 then
		return
	end
	L_385_ = L_384_arg0.UserInputType
	L_386_ = Enum.UserInputType.MouseMovement
	L_396_ = (L_384_arg0.UserInputType == Enum.UserInputType.MouseMovement)
	if (L_384_arg0.UserInputType == Enum.UserInputType.MouseMovement) then
		L_385_ = (L_384_arg0.Position - upvalue_1)
		L_386_ = upvalue_2
		L_387_ = upvalue_1
		if not (upvalue_2) then
			L_386_ = math.abs(L_385_.X)
			L_387_ = 4
			L_396_ = (4 <= math.abs(L_385_.X))
			if (4 <= math.abs(L_385_.X)) then
				upvalue_2 = true
				L_386_ = true
			else
				L_386_ = math.abs(L_385_.Y)
				L_387_ = 4
				L_396_ = (4 <= math.abs(L_385_.Y))
				if 4 <= math.abs(L_385_.Y) then
					upvalue_2 = true
					L_386_ = true
				end
			end
		end
		L_386_ = upvalue_2
		if not upvalue_2 then
			return
		end
		L_386_ = upvalue_3
		L_386_.Position = UDim2.new(upvalue_4.X.Scale, (upvalue_4.X.Offset + L_385_.X), upvalue_4.Y.Scale, (upvalue_4.Y.Offset + L_385_.Y))
		L_387_ = UDim2.new(upvalue_4.X.Scale, (upvalue_4.X.Offset + L_385_.X), upvalue_4.Y.Scale, (upvalue_4.Y.Offset + L_385_.Y))
		L_388_ = upvalue_4.X.Scale
		L_389_ = (upvalue_4.X.Offset + L_385_.X)
		L_390_ = upvalue_4.Y.Scale
		L_391_ = (upvalue_4.Y.Offset + L_385_.Y)
		L_392_ = upvalue_4.Y.Offset
		L_393_ = L_385_.Y
		L_394_ = upvalue_4
	else
		L_385_ = L_384_arg0.UserInputType
		L_386_ = Enum.UserInputType.Touch
		L_396_ = (L_384_arg0.UserInputType == Enum.UserInputType.Touch)
		if not (L_384_arg0.UserInputType == Enum.UserInputType.Touch) then
			return
		end
		L_385_ = (L_384_arg0.Position - upvalue_1)
		L_386_ = upvalue_2
		L_387_ = upvalue_1
		if not (upvalue_2) then
			L_386_ = math.abs(L_385_.X)
			L_387_ = 4
			L_396_ = (4 <= math.abs(L_385_.X))
			if (4 <= math.abs(L_385_.X)) then
				upvalue_2 = true
				L_386_ = true
			else
				L_386_ = math.abs(L_385_.Y)
				L_387_ = 4
				L_396_ = (4 <= math.abs(L_385_.Y))
				if 4 <= math.abs(L_385_.Y) then
					upvalue_2 = true
					L_386_ = true
				end
			end
		end
		L_386_ = upvalue_2
		if not upvalue_2 then
			return
		end
		L_386_ = upvalue_3
		L_386_.Position = UDim2.new(upvalue_4.X.Scale, (upvalue_4.X.Offset + L_385_.X), upvalue_4.Y.Scale, (upvalue_4.Y.Offset + L_385_.Y))
		L_387_ = UDim2.new(upvalue_4.X.Scale, (upvalue_4.X.Offset + L_385_.X), upvalue_4.Y.Scale, (upvalue_4.Y.Offset + L_385_.Y))
		L_388_ = upvalue_4.X.Scale
		L_389_ = (upvalue_4.X.Offset + L_385_.X)
		L_390_ = upvalue_4.Y.Scale
		L_391_ = (upvalue_4.Y.Offset + L_385_.Y)
		L_392_ = upvalue_4.Y.Offset
		L_393_ = L_385_.Y
		L_394_ = upvalue_4
	end
	return
end

L_1_.callback_70 = function()
	local L_397_, L_398_
	upvalue_0 = false
	return upvalue_0
end

L_1_.MakeDraggable = function(L_399_arg0, L_400_arg1, L_401_arg2)
	local L_402_, L_403_, L_404_, L_405_, L_406_, L_407_, L_408_
	if L_401_arg2 then
		L_400_arg1.InputBegan:Connect(L_1_.callback_67)
		L_400_arg1.InputEnded:Connect(L_1_.callback_68)
		upvalue_1.InputChanged:Connect(L_1_.callback_69)

		return L_1_.callback_70
	end
	L_401_arg2 = L_400_arg1
	L_400_arg1.InputBegan:Connect(L_1_.callback_67)
	L_400_arg1.InputEnded:Connect(L_1_.callback_68)
	upvalue_1.InputChanged:Connect(L_1_.callback_69)

	return L_1_.callback_70
end

L_1_.GetIcon = function(L_409_arg0, L_410_arg1)
	local L_411_, L_412_
	L_411_ = upvalue_0[L_410_arg1]
	L_412_ = upvalue_0
	if upvalue_0[L_410_arg1] then
		return L_411_
	end
	L_411_ = upvalue_0.home
	L_412_ = upvalue_0
	return L_411_
end

L_1_.callback_73 = function()
	local L_413_, L_414_, L_415_, L_416_
	L_413_ = game:GetService("HttpService")
	L_413_ = L_413_:GenerateGUID(false)
	L_413_ = L_413_.sub
	L_414_ = L_413_
	L_415_ = 1
	L_416_ = 8
	return L_413_:sub(1, 8)
end

L_1_.callback_74 = function()
	local L_417_, L_418_
	syn.protect_gui(upvalue_0)
	L_417_ = upvalue_0
	L_417_.Parent = upvalue_1
	upvalue_2 = true
	return
end

L_1_.callback_75 = function()
	local L_419_, L_420_
	L_419_ = upvalue_0
	L_419_.Parent = gethui()
	upvalue_1 = true
	return
end

L_1_.callback_76 = function()
	local L_421_, L_422_
	L_421_ = upvalue_0
	L_421_.Parent = get_hidden_gui()
	upvalue_1 = true
	return
end

L_1_.callback_77 = function()
	local L_423_, L_424_, L_425_
	L_423_ = getgenv()[upvalue_0]
	L_423_:Destroy()
	return
end

L_1_.callback_78 = function()
	local L_426_, L_427_, L_428_
	L_426_ = upvalue_0:IsDescendantOf(game)
	L_427_ = upvalue_0
	L_428_ = game
	if upvalue_0:IsDescendantOf(game) then
		return
	end
	upvalue_1:Cancel()
	L_426_ = upvalue_1.Cancel
	L_427_ = upvalue_1
	return
end

L_1_.callback_79 = function()
	local L_429_, L_430_, L_431_, L_432_, L_433_, L_434_, L_435_
	L_434_ = {}
	L_434_.ImageTransparency = 0.8
	L_430_ = upvalue_0:Create(upvalue_1, TweenInfo.new(2, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut, -1, true), L_434_)
	L_430_:Play()
	upvalue_2.AncestryChanged:Connect(L_1_.callback_78)
	return
end

L_1_.callback_80 = function()
	local L_436_, L_437_, L_438_, L_439_, L_440_
	L_436_ = upvalue_0.GetUserThumbnailAsync
	L_437_ = upvalue_0
	L_438_ = upvalue_1.UserId
	L_439_ = Enum.ThumbnailType.HeadShot
	L_440_ = Enum.ThumbnailSize.Size100x100
	L_436_, L_437_ = upvalue_0:GetUserThumbnailAsync(upvalue_1.UserId, Enum.ThumbnailType.HeadShot, Enum.ThumbnailSize.Size100x100)
	if not L_437_ then
		return
	end
	L_438_ = upvalue_2
	L_438_.Image = L_436_
	return
end

L_1_.callback_81 = function()
	local L_441_, L_442_
	pcall(L_1_.callback_80)
	return
end

L_1_.Name = function()
	local L_443_, L_444_
	L_443_ = upvalue_0()
	if upvalue_0() then
		return
	end
	upvalue_1:Destroy()
	L_443_ = upvalue_1.Destroy
	L_444_ = upvalue_1
	return
end

L_1_.callback_83 = function()
	local L_445_, L_446_, L_447_, L_448_, L_449_, L_450_, L_451_, L_452_, L_453_
	L_446_ = {}
	L_446_.TextColor3 = upvalue_1.Accent
	L_447_ = upvalue_2:Create(upvalue_0, TweenInfo.new(0.15, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_446_)
	L_447_:Play()
	return
end

L_1_.callback_84 = function()
	local L_454_, L_455_, L_456_, L_457_, L_458_, L_459_, L_460_, L_461_, L_462_
	L_455_ = {}
	L_455_.TextColor3 = Color3.new(1, 1, 1)
	L_456_ = upvalue_1:Create(upvalue_0, TweenInfo.new(0.15, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_455_)
	L_456_:Play()
	return
end

L_1_.callback_85 = function()
	local L_463_, L_464_, L_465_, L_466_, L_467_, L_468_, L_469_, L_470_, L_471_
	L_464_ = {}
	L_464_.TextColor3 = upvalue_1.Error
	L_465_ = upvalue_2:Create(upvalue_0, TweenInfo.new(0.15, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_464_)
	L_465_:Play()
	return
end

L_1_.BackgroundTransparency = function()
	local L_472_, L_473_, L_474_, L_475_, L_476_, L_477_, L_478_, L_479_, L_480_
	L_473_ = {}
	L_473_.TextColor3 = Color3.new(1, 1, 1)
	L_474_ = upvalue_1:Create(upvalue_0, TweenInfo.new(0.15, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_473_)
	L_474_:Play()
	return
end

L_1_.callback_87 = function(L_481_arg0)
	local L_482_, L_483_, L_484_, L_485_, L_486_, L_487_
	L_482_ = L_481_arg0.UserInputType
	L_483_ = Enum.UserInputType.Touch
	L_487_ = (L_481_arg0.UserInputType == Enum.UserInputType.Touch)
	if (L_481_arg0.UserInputType == Enum.UserInputType.Touch) then
		L_482_ = upvalue_0()
		if upvalue_0() then
			return
		end
		L_482_ = upvalue_1
		L_482_.Visible = not upvalue_1.Visible
		L_483_ = not upvalue_1.Visible
		L_484_ = upvalue_1.Visible
		L_485_ = upvalue_1
	else
		L_482_ = L_481_arg0.UserInputType
		L_483_ = Enum.UserInputType.MouseButton1
		L_487_ = (L_481_arg0.UserInputType == Enum.UserInputType.MouseButton1)
		if not (L_481_arg0.UserInputType == Enum.UserInputType.MouseButton1) then
			return
		end
		L_482_ = upvalue_0()
		if upvalue_0() then
			return
		end
		L_482_ = upvalue_1
		L_482_.Visible = not upvalue_1.Visible
		L_483_ = not upvalue_1.Visible
		L_484_ = upvalue_1.Visible
		L_485_ = upvalue_1
	end
	return
end

L_1_.Name_88 = function(L_488_arg0)
	local L_489_, L_490_, L_491_, L_492_, L_493_, L_494_
	L_489_ = L_488_arg0.KeyCode
	L_490_ = Enum.KeyCode.RightShift
	L_494_ = (L_488_arg0.KeyCode == Enum.KeyCode.RightShift)
	if not (L_488_arg0.KeyCode == Enum.KeyCode.RightShift) then
		return
	end
	L_489_ = upvalue_0
	L_489_.Visible = not upvalue_0.Visible
	L_490_ = not upvalue_0.Visible
	L_491_ = upvalue_0.Visible
	L_492_ = upvalue_0
	return
end

L_1_.callback_89 = function()
	local L_495_, L_496_, L_497_
	L_495_ = upvalue_0:IsDescendantOf(game)
	L_496_ = upvalue_0
	L_497_ = game
	if upvalue_0:IsDescendantOf(game) then
		return
	end
	upvalue_1:Cancel()
	L_495_ = upvalue_1.Cancel
	L_496_ = upvalue_1
	return
end

L_1_.callback_90 = function()
	local L_498_, L_499_, L_500_, L_501_, L_502_, L_503_, L_504_
	L_503_ = {}
	L_503_.ImageTransparency = 0.85
	L_499_ = upvalue_0:Create(upvalue_1, TweenInfo.new(1.6, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut, -1, true), L_503_)
	L_499_:Play()
	upvalue_2.AncestryChanged:Connect(L_1_.callback_89)
	return
end

L_1_.callback_91 = function()
	local L_505_, L_506_, L_507_, L_508_, L_509_, L_510_, L_511_, L_512_, L_513_
	L_505_ = upvalue_0
	if not upvalue_0 then
		upvalue_0 = true
		L_505_ = upvalue_1
		L_505_.Visible = false
		L_505_ = upvalue_2
		L_505_.Visible = true
		L_505_ = upvalue_2
		L_505_.Size = UDim2.new(0, 0, 0, 0)
		L_506_ = {}
		L_506_.Size = UDim2.new(0, 170, 0, 46)
		L_507_ = upvalue_3:Create(upvalue_2, TweenInfo.new(0.35, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_506_)
		L_507_:Play()
		return
	else
		return
	end
end

L_1_.callback_92 = function()
	local L_514_, L_515_
	L_514_ = upvalue_0
	L_514_.Visible = false
	return
end

L_1_.callback_93 = function()
	local L_516_, L_517_, L_518_, L_519_, L_520_, L_521_, L_522_, L_523_, L_524_
	L_516_ = upvalue_0
	if upvalue_0 then
		upvalue_0 = false
		L_517_ = {}
		L_517_.Size = UDim2.new(0, 0, 0, 0)
		L_518_ = upvalue_2:Create(upvalue_1, TweenInfo.new(0.25, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_517_)
		L_518_:Play()
		task.delay(0.26, L_1_.callback_92)
		L_516_ = upvalue_3
		L_516_.Visible = true
		return
	else
		return
	end
end

L_1_.callback_94 = function()
	local L_525_
	L_525_ = upvalue_0()
	if upvalue_0() then
		return
	end
	upvalue_1()
	L_525_ = upvalue_1
	return
end

L_1_.Select = function(L_526_arg0)
	local L_527_, L_528_, L_529_, L_530_, L_531_, L_532_, L_533_, L_534_, L_535_, L_536_, L_537_, L_538_, L_539_, L_540_, L_541_, L_542_
	local L_543_, L_544_, L_545_, L_546_
	L_528_, L_529_ = upvalue_0:GetChildren()
	for L_547_forvar0, L_548_forvar1 in next, upvalue_0.GetChildren, upvalue_0 do
		L_532_ = L_548_forvar1:IsA("ImageButton")
		L_533_ = L_548_forvar1
		L_534_ = "ImageButton"
		if L_548_forvar1:IsA("ImageButton") then
			L_532_ = L_548_forvar1:FindFirstChild("Indicator")
			L_533_ = L_548_forvar1
			L_534_ = "Indicator"
			if L_548_forvar1:FindFirstChild("Indicator") then
				L_533_ = {}
				L_533_.BackgroundTransparency = 1
				L_534_ = upvalue_1:Create(L_548_forvar1.Indicator, TweenInfo.new(0.25, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_533_)
				L_534_:Play()
				L_532_ = L_548_forvar1.Indicator
				L_534_ = L_534_.Play
				L_535_ = L_534_
				L_536_ = L_548_forvar1.Indicator
				L_537_ = TweenInfo.new(0.25, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
				L_538_ = L_533_
				L_539_ = Enum.EasingStyle.Quart
				L_540_ = Enum.EasingDirection.Out
			end
			L_532_ = L_548_forvar1:FindFirstChild("Icon")
			L_533_ = L_548_forvar1
			L_534_ = "Icon"
			if L_548_forvar1:FindFirstChild("Icon") then
				L_533_ = {}
				L_533_.ImageColor3 = Color3.fromRGB(140, 140, 140)
				L_534_ = upvalue_1:Create(L_548_forvar1.Icon, TweenInfo.new(0.25, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_533_)
				L_534_:Play()
				L_532_ = L_548_forvar1.Icon
				L_534_ = L_534_.Play
				L_535_ = L_534_
				L_536_ = L_548_forvar1.Icon
				L_537_ = TweenInfo.new(0.25, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
				L_538_ = L_533_
				L_539_ = Enum.EasingStyle.Quart
				L_540_ = Enum.EasingDirection.Out
			end
			L_533_, L_534_ = L_548_forvar1:GetChildren()
			for L_549_forvar0, L_550_forvar1 in next, L_548_forvar1.GetChildren, L_548_forvar1 do
				L_537_ = L_550_forvar1:IsA("Frame")
				L_538_ = L_550_forvar1
				L_539_ = "Frame"
				if L_550_forvar1:IsA("Frame") then
					L_537_ = L_550_forvar1.Name
					L_545_ = "Indicator"
					L_546_ = (L_550_forvar1.Name == "Indicator")
					if not (L_550_forvar1.Name == "Indicator") then
						L_537_ = {}
						L_537_.BackgroundTransparency = 1
						L_538_ = upvalue_1:Create(L_550_forvar1, TweenInfo.new(0.25, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_537_)
						L_538_:Play()
						L_538_ = L_538_.Play
						L_539_ = L_538_
						L_540_ = L_550_forvar1
						L_541_ = TweenInfo.new(0.25, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
						L_542_ = L_537_
						L_543_ = Enum.EasingStyle.Quart
						L_544_ = Enum.EasingDirection.Out
					end
				end
			end
		end
	end
	L_527_ = upvalue_2.Current
	L_528_ = upvalue_2
	if upvalue_2.Current then
		L_532_ = upvalue_2
		for L_551_forvar0, L_552_forvar1 in next, upvalue_2.Current.Tab.SubTabs do
			L_532_ = L_552_forvar1.Btn
			L_532_.Visible = false
			L_532_ = L_552_forvar1.Page
			L_532_.Visible = false
			L_533_ = false
		end
	end
	L_528_ = {}
	L_528_.Tab = upvalue_3
	L_527_ = upvalue_2
	L_527_.Current = L_528_
	L_528_ = {}
	L_528_.ImageColor3 = upvalue_5.Accent
	L_529_ = upvalue_1:Create(upvalue_4, TweenInfo.new(0.25, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_528_)
	L_529_:Play()
	L_528_ = {}
	L_528_.BackgroundTransparency = 0
	L_529_ = upvalue_1:Create(upvalue_6, TweenInfo.new(0.25, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_528_)
	L_529_:Play()
	L_528_ = {}
	L_528_.BackgroundTransparency = 0.85
	L_529_ = upvalue_1:Create(upvalue_7, TweenInfo.new(0.25, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_528_)
	L_529_:Play()
	L_532_ = TweenInfo.new(0.25, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
	L_533_ = L_528_
	L_534_ = Enum.EasingStyle.Quart
	L_535_ = Enum.EasingDirection.Out
	for L_553_forvar0, L_554_forvar1 in next, upvalue_3.SubTabs do
		L_532_ = L_554_forvar1.Btn
		L_532_.Visible = true
		L_533_ = true
	end
	L_527_ = upvalue_3.CurrentST
	L_528_ = upvalue_3
	if upvalue_3.CurrentST then
		upvalue_3.CurrentST:Select()
		return
	end
	L_527_ = upvalue_3.SubTabs[1]
	L_528_ = upvalue_3.SubTabs
	L_529_ = upvalue_3
	if not upvalue_3.SubTabs[1] then
		return
	end
	upvalue_3.SubTabs[1]:Select()
	L_527_ = upvalue_3.SubTabs[1].Select
	L_528_ = upvalue_3.SubTabs[1]
	L_529_ = upvalue_3
	return
end

L_1_.callback_96 = function()
	local L_555_, L_556_
	upvalue_0:Select()
	return
end

L_1_.SetVisible = function(L_557_arg0, L_558_arg1)
	local L_559_
	L_559_ = upvalue_0
	L_559_.Visible = L_558_arg1
	return
end

L_1_.Select_98 = function(L_560_arg0)
	local L_561_, L_562_, L_563_, L_564_, L_565_, L_566_, L_567_, L_568_, L_569_
	L_561_ = upvalue_0.CurrentST
	L_562_ = upvalue_0
	if not upvalue_0.CurrentST then
		L_561_ = upvalue_0
		L_561_.CurrentST = upvalue_2
		L_561_ = upvalue_3
		L_561_.Visible = true
		L_562_ = {}
		L_562_.TextColor3 = Color3.new(1, 1, 1)
		L_563_ = upvalue_1:Create(upvalue_4, TweenInfo.new(0.2, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_562_)
		L_563_:Play()
		L_562_ = {}
		L_562_.ImageColor3 = upvalue_6.Accent
		L_563_ = upvalue_1:Create(upvalue_5, TweenInfo.new(0.2, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_562_)
		L_563_:Play()
		L_562_ = {}
		L_562_.BackgroundTransparency = 0
		L_563_ = upvalue_1:Create(upvalue_7, TweenInfo.new(0.2, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_562_)
		L_563_:Play()
		return
	end
	L_561_ = upvalue_0.CurrentST.Page
	L_561_.Visible = false
	L_562_ = {}
	L_562_.TextColor3 = Color3.fromRGB(160, 160, 160)
	L_563_ = upvalue_1:Create(upvalue_0.CurrentST.Btn.Label, TweenInfo.new(0.2, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_562_)
	L_563_:Play()
	L_562_ = {}
	L_562_.ImageColor3 = Color3.fromRGB(160, 160, 160)
	L_563_ = upvalue_1:Create(upvalue_0.CurrentST.Btn.Icon, TweenInfo.new(0.2, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_562_)
	L_563_:Play()
	L_561_ = upvalue_0.CurrentST.Btn:FindFirstChildOfClass("Frame")
	L_562_ = upvalue_0.CurrentST.Btn
	L_563_ = "Frame"
	L_564_ = L_563_
	L_565_ = upvalue_0.CurrentST.Btn.Icon
	L_566_ = TweenInfo.new(0.2, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
	L_567_ = L_562_
	L_568_ = Enum.EasingStyle.Quart
	L_569_ = Enum.EasingDirection.Out
	if not upvalue_0.CurrentST.Btn:FindFirstChildOfClass("Frame") then
		L_561_ = upvalue_0
		L_561_.CurrentST = upvalue_2
		L_561_ = upvalue_3
		L_561_.Visible = true
		L_562_ = {}
		L_562_.TextColor3 = Color3.new(1, 1, 1)
		L_563_ = upvalue_1:Create(upvalue_4, TweenInfo.new(0.2, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_562_)
		L_563_:Play()
		L_562_ = {}
		L_562_.ImageColor3 = upvalue_6.Accent
		L_563_ = upvalue_1:Create(upvalue_5, TweenInfo.new(0.2, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_562_)
		L_563_:Play()
		L_562_ = {}
		L_562_.BackgroundTransparency = 0
		L_563_ = upvalue_1:Create(upvalue_7, TweenInfo.new(0.2, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_562_)
		L_563_:Play()
		return
	end
	L_562_ = {}
	L_562_.BackgroundTransparency = 1
	L_563_ = upvalue_1:Create(L_561_, TweenInfo.new(0.2, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_562_)
	L_563_:Play()
	L_563_ = L_563_.Play
	L_564_ = L_563_
	L_565_ = L_561_
	L_566_ = TweenInfo.new(0.2, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
	L_567_ = L_562_
	L_568_ = Enum.EasingStyle.Quart
	L_569_ = Enum.EasingDirection.Out
	L_561_ = upvalue_0
	L_561_.CurrentST = upvalue_2
	L_561_ = upvalue_3
	L_561_.Visible = true
	L_562_ = {}
	L_562_.TextColor3 = Color3.new(1, 1, 1)
	L_563_ = upvalue_1:Create(upvalue_4, TweenInfo.new(0.2, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_562_)
	L_563_:Play()
	L_562_ = {}
	L_562_.ImageColor3 = upvalue_6.Accent
	L_563_ = upvalue_1:Create(upvalue_5, TweenInfo.new(0.2, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_562_)
	L_563_:Play()
	L_562_ = {}
	L_562_.BackgroundTransparency = 0
	L_563_ = upvalue_1:Create(upvalue_7, TweenInfo.new(0.2, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_562_)
	L_563_:Play()
	return
end

L_1_.callback_99 = function()
	local L_570_, L_571_
	upvalue_0:Select()
	return
end

L_1_.callback_100 = function()
	local L_572_, L_573_, L_574_, L_575_, L_576_, L_577_, L_578_, L_579_, L_580_
	L_572_ = upvalue_0
	L_573_ = {}
	L_575_ = upvalue_1
	if not upvalue_1 then
		L_574_ = Color3.fromRGB(35, 35, 35)
		L_575_ = 35
		L_576_ = 35
		L_577_ = 35
	else
		L_574_ = upvalue_2.Accent
		L_575_ = upvalue_2
		if not (upvalue_2.Accent) then
			L_574_ = Color3.fromRGB(35, 35, 35)
			L_575_ = 35
			L_576_ = 35
			L_577_ = 35
		end
	end
	L_573_.BackgroundColor3 = L_574_
	L_574_ = upvalue_3:Create(L_572_, TweenInfo.new(0.2, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_573_)
	L_574_:Play()
	L_572_ = upvalue_4
	L_573_ = {}
	L_574_ = L_574_.Play
	L_575_ = upvalue_1
	L_576_ = L_572_
	L_577_ = TweenInfo.new(0.2, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
	L_578_ = L_573_
	L_579_ = Enum.EasingStyle.Quart
	L_580_ = Enum.EasingDirection.Out
	if not upvalue_1 then
		L_574_ = UDim2.new(0, 2, 0.5, -7)
		L_575_ = 0
		L_576_ = 2
		L_577_ = 0.5
		L_578_ = -7
	else
		L_574_ = UDim2.new(1, -16, 0.5, -7)
		L_575_ = 1
		L_576_ = -16
		L_577_ = 0.5
		L_578_ = -7
		if not (UDim2.new(1, -16, 0.5, -7)) then
			L_574_ = UDim2.new(0, 2, 0.5, -7)
			L_575_ = 0
			L_576_ = 2
			L_577_ = 0.5
			L_578_ = -7
		end
	end
	L_573_.Position = L_574_
	L_574_ = upvalue_3:Create(L_572_, TweenInfo.new(0.2, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_573_)
	L_574_:Play()
	L_572_ = upvalue_5
	L_573_ = {}
	L_574_ = L_574_.Play
	L_575_ = upvalue_1
	L_576_ = L_572_
	L_577_ = TweenInfo.new(0.2, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
	L_578_ = L_573_
	L_579_ = Enum.EasingStyle.Quart
	L_580_ = Enum.EasingDirection.Out
	if not upvalue_1 then
		L_574_ = Color3.fromRGB(225, 225, 225)
		L_575_ = 225
		L_576_ = 225
		L_577_ = 225
	else
		L_574_ = upvalue_2.Accent
		L_575_ = upvalue_2
		if not (upvalue_2.Accent) then
			L_574_ = Color3.fromRGB(225, 225, 225)
			L_575_ = 225
			L_576_ = 225
			L_577_ = 225
		end
	end
	L_573_.TextColor3 = L_574_
	L_574_ = upvalue_3:Create(L_572_, TweenInfo.new(0.2, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_573_)
	L_574_:Play()
	L_572_ = upvalue_6
	L_574_ = L_574_.Play
	L_575_ = L_574_
	L_576_ = L_572_
	L_577_ = TweenInfo.new(0.2, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
	L_578_ = L_573_
	L_579_ = Enum.EasingStyle.Quart
	L_580_ = Enum.EasingDirection.Out
	if not upvalue_6 then
		return
	end
	upvalue_6(upvalue_1)
	L_572_ = upvalue_6
	L_573_ = upvalue_1
	return
end

L_1_.callback_101 = function(L_581_arg0)
	local L_582_, L_583_, L_584_, L_585_
	L_582_ = L_581_arg0.UserInputType
	L_583_ = Enum.UserInputType.MouseButton1
	L_585_ = (L_581_arg0.UserInputType == Enum.UserInputType.MouseButton1)
	if (L_581_arg0.UserInputType == Enum.UserInputType.MouseButton1) then
		upvalue_0 = not upvalue_0
		upvalue_1()
		L_582_ = upvalue_1
		L_583_ = upvalue_0
	else
		L_582_ = L_581_arg0.UserInputType
		L_583_ = Enum.UserInputType.Touch
		L_585_ = (L_581_arg0.UserInputType == Enum.UserInputType.Touch)
		if not (L_581_arg0.UserInputType == Enum.UserInputType.Touch) then
			return
		end
		upvalue_0 = not upvalue_0
		upvalue_1()
		L_582_ = upvalue_1
		L_583_ = upvalue_0
	end
	return
end

L_1_.Set = function(L_586_arg0, L_587_arg1)
	local L_588_
	upvalue_0 = L_587_arg1
	upvalue_1()
	return
end

L_1_.CreateToggle = function(L_589_arg0, L_590_arg1, L_591_arg2, L_592_arg3)
	local L_593_, L_594_, L_595_, L_596_, L_597_, L_598_, L_599_, L_600_, L_601_, L_602_, L_603_, L_604_, L_605_
	L_594_ = {}
	L_594_.Parent = upvalue_0
	L_594_.BackgroundColor3 = Color3.fromRGB(13, 13, 13)
	L_594_.Size = UDim2.new(1, 0, 0, 42)
	L_595_ = Instance.new("Frame")
	for L_606_forvar0, L_607_forvar1 in next, L_594_ do
		L_604_ = "Parent"
		L_605_ = (L_606_forvar0 == "Parent")
		if not (L_606_forvar0 == "Parent") then
			L_595_[L_606_forvar0] = L_607_forvar1
		end
	end
	L_595_.Parent = L_594_.Parent
	L_594_ = {}
	L_594_.CornerRadius = UDim.new(0, 6)
	L_594_.Parent = L_595_
	L_593_ = L_595_
	L_595_ = Instance.new("UICorner")
	for L_608_forvar0, L_609_forvar1 in next, L_594_ do
		L_604_ = "Parent"
		L_605_ = (L_608_forvar0 == "Parent")
		if not (L_608_forvar0 == "Parent") then
			L_595_[L_608_forvar0] = L_609_forvar1
		end
	end
	L_595_.Parent = L_594_.Parent
	L_595_ = {}
	L_595_.Parent = L_593_
	L_595_.BackgroundTransparency = 1
	L_595_.Position = UDim2.new(0, 12, 0, 0)
	L_595_.Size = UDim2.new(1, -64, 1, 0)
	L_595_.Font = "Gotham"
	L_595_.Text = L_590_arg1
	L_595_.TextColor3 = Color3.fromRGB(225, 225, 225)
	L_595_.TextSize = 14
	L_595_.TextXAlignment = "Left"
	L_596_ = Instance.new("TextLabel")
	for L_610_forvar0, L_611_forvar1 in next, L_595_ do
		L_604_ = "Parent"
		L_605_ = (L_610_forvar0 == "Parent")
		if not (L_610_forvar0 == "Parent") then
			L_596_[L_610_forvar0] = L_611_forvar1
		end
	end
	L_596_.Parent = L_595_.Parent
	L_596_ = {}
	L_596_.Parent = L_593_
	L_596_.AnchorPoint = Vector2.new(1, 0.5)
	L_596_.BackgroundColor3 = Color3.fromRGB(35, 35, 35)
	L_596_.Position = UDim2.new(1, -12, 0.5, 0)
	L_596_.Size = UDim2.new(0, 36, 0, 18)
	L_594_ = L_596_
	L_597_ = Instance.new("Frame")
	for L_612_forvar0, L_613_forvar1 in next, L_596_ do
		L_604_ = "Parent"
		L_605_ = (L_612_forvar0 == "Parent")
		if not (L_612_forvar0 == "Parent") then
			L_597_[L_612_forvar0] = L_613_forvar1
		end
	end
	L_597_.Parent = L_596_.Parent
	L_596_ = {}
	L_596_.CornerRadius = UDim.new(1, 0)
	L_596_.Parent = L_597_
	L_595_ = L_597_
	L_597_ = Instance.new("UICorner")
	for L_614_forvar0, L_615_forvar1 in next, L_596_ do
		L_604_ = "Parent"
		L_605_ = (L_614_forvar0 == "Parent")
		if not (L_614_forvar0 == "Parent") then
			L_597_[L_614_forvar0] = L_615_forvar1
		end
	end
	L_597_.Parent = L_596_.Parent
	L_597_ = {}
	L_597_.Parent = L_595_
	L_597_.BackgroundColor3 = Color3.new(1, 1, 1)
	L_597_.Position = UDim2.new(0, 2, 0.5, -7)
	L_597_.Size = UDim2.new(0, 14, 0, 14)
	L_598_ = Instance.new("Frame")
	for L_616_forvar0, L_617_forvar1 in next, L_597_ do
		L_604_ = "Parent"
		L_605_ = (L_616_forvar0 == "Parent")
		if not (L_616_forvar0 == "Parent") then
			L_598_[L_616_forvar0] = L_617_forvar1
		end
	end
	L_598_.Parent = L_597_.Parent
	L_597_ = {}
	L_597_.CornerRadius = UDim.new(1, 0)
	L_597_.Parent = L_598_
	L_596_ = L_598_
	L_598_ = Instance.new("UICorner")
	for L_618_forvar0, L_619_forvar1 in next, L_597_ do
		L_604_ = "Parent"
		L_605_ = (L_618_forvar0 == "Parent")
		if not (L_618_forvar0 == "Parent") then
			L_598_[L_618_forvar0] = L_619_forvar1
		end
	end
	L_598_.Parent = L_597_.Parent
	L_597_ = L_591_arg2
	L_599_ = L_597_.Parent
	if L_591_arg2 then
		L_593_.InputBegan:Connect(L_1_.callback_101)
		L_1_.callback_100()
		L_599_ = {}
		L_599_.Set = L_1_.Set

		return L_599_
	end
	L_597_ = false
	L_593_.InputBegan:Connect(L_1_.callback_101)
	L_1_.callback_100()
	L_599_ = {}
	L_599_.Set = L_1_.Set

	return L_599_
end

L_1_.callback_104 = function()
	local L_620_
	L_620_ = upvalue_0
	if not upvalue_0 then
		return
	end
	upvalue_0()
	L_620_ = upvalue_0
	return
end

L_1_.CreateButton = function(L_621_arg0, L_622_arg1, L_623_arg2)
	local L_624_, L_625_, L_626_, L_627_, L_628_, L_629_, L_630_, L_631_, L_632_, L_633_
	L_625_ = {}
	L_625_.Parent = upvalue_0
	L_625_.BackgroundColor3 = Color3.fromRGB(13, 13, 13)
	L_625_.Size = UDim2.new(1, 0, 0, 42)
	L_625_.Text = ""
	L_625_.AutoButtonColor = false
	L_626_ = Instance.new("TextButton")
	for L_634_forvar0, L_635_forvar1 in next, L_625_ do
		L_632_ = "Parent"
		L_633_ = (L_634_forvar0 == "Parent")
		if not (L_634_forvar0 == "Parent") then
			L_626_[L_634_forvar0] = L_635_forvar1
		end
	end
	L_626_.Parent = L_625_.Parent
	L_625_ = {}
	L_625_.CornerRadius = UDim.new(0, 6)
	L_625_.Parent = L_626_
	L_624_ = L_626_
	L_626_ = Instance.new("UICorner")
	for L_636_forvar0, L_637_forvar1 in next, L_625_ do
		L_632_ = "Parent"
		L_633_ = (L_636_forvar0 == "Parent")
		if not (L_636_forvar0 == "Parent") then
			L_626_[L_636_forvar0] = L_637_forvar1
		end
	end
	L_626_.Parent = L_625_.Parent
	L_625_ = {}
	L_625_.Parent = L_624_
	L_625_.BackgroundTransparency = 1
	L_625_.Size = UDim2.new(1, 0, 1, 0)
	L_625_.Font = "Gotham"
	L_625_.Text = L_622_arg1
	L_625_.TextColor3 = Color3.fromRGB(225, 225, 225)
	L_625_.TextSize = 14
	L_626_ = Instance.new("TextLabel")
	for L_638_forvar0, L_639_forvar1 in next, L_625_ do
		L_632_ = "Parent"
		L_633_ = (L_638_forvar0 == "Parent")
		if not (L_638_forvar0 == "Parent") then
			L_626_[L_638_forvar0] = L_639_forvar1
		end
	end
	L_626_.Parent = L_625_.Parent
	L_624_.Activated:Connect(L_1_.callback_104)
	return L_624_
end

L_1_.callback_106 = function(L_640_arg0)
	local L_641_, L_642_, L_643_, L_644_, L_645_, L_646_, L_647_, L_648_
	L_643_ = upvalue_3
	L_643_.Size = UDim2.new(math.clamp(((L_640_arg0.Position.X - upvalue_0.AbsolutePosition.X) / upvalue_0.AbsoluteSize.X), 0, 1), 0, 1, 0)
	L_643_ = upvalue_4
	L_643_.Text = tostring(math.floor((upvalue_1 + ((upvalue_2 - upvalue_1) * math.clamp(((L_640_arg0.Position.X - upvalue_0.AbsolutePosition.X) / upvalue_0.AbsoluteSize.X), 0, 1)))))
	upvalue_5(math.floor((upvalue_1 + ((upvalue_2 - upvalue_1) * math.clamp(((L_640_arg0.Position.X - upvalue_0.AbsolutePosition.X) / upvalue_0.AbsoluteSize.X), 0, 1)))))
	return
end

L_1_.callback_107 = function(L_649_arg0)
	local L_650_, L_651_, L_652_, L_653_
	L_650_ = L_649_arg0.UserInputType
	L_651_ = Enum.UserInputType.MouseButton1
	L_653_ = (L_649_arg0.UserInputType == Enum.UserInputType.MouseButton1)
	if (L_649_arg0.UserInputType == Enum.UserInputType.MouseButton1) then
		upvalue_0 = true
		upvalue_1(L_649_arg0)
		L_650_ = upvalue_1
		L_651_ = L_649_arg0
	else
		L_650_ = L_649_arg0.UserInputType
		L_651_ = Enum.UserInputType.Touch
		L_653_ = (L_649_arg0.UserInputType == Enum.UserInputType.Touch)
		if not (L_649_arg0.UserInputType == Enum.UserInputType.Touch) then
			return
		end
		upvalue_0 = true
		upvalue_1(L_649_arg0)
		L_650_ = upvalue_1
		L_651_ = L_649_arg0
	end
	return
end

L_1_.callback_108 = function(L_654_arg0)
	local L_655_, L_656_, L_657_, L_658_
	L_655_ = L_654_arg0.UserInputType
	L_656_ = Enum.UserInputType.MouseButton1
	L_658_ = (L_654_arg0.UserInputType == Enum.UserInputType.MouseButton1)
	if (L_654_arg0.UserInputType == Enum.UserInputType.MouseButton1) then
		upvalue_0 = false
		L_655_ = false
	else
		L_655_ = L_654_arg0.UserInputType
		L_656_ = Enum.UserInputType.Touch
		L_658_ = (L_654_arg0.UserInputType == Enum.UserInputType.Touch)
		if not (L_654_arg0.UserInputType == Enum.UserInputType.Touch) then
			return
		end
		upvalue_0 = false
		L_655_ = false
	end
	return
end

L_1_.callback_109 = function(L_659_arg0)
	local L_660_, L_661_, L_662_, L_663_
	L_660_ = upvalue_0
	if not upvalue_0 then
		return
	end
	L_660_ = L_659_arg0.UserInputType
	L_661_ = Enum.UserInputType.MouseMovement
	L_663_ = (L_659_arg0.UserInputType == Enum.UserInputType.MouseMovement)
	if (L_659_arg0.UserInputType == Enum.UserInputType.MouseMovement) then
		upvalue_1(L_659_arg0)
		L_660_ = upvalue_1
		L_661_ = L_659_arg0
	else
		L_660_ = L_659_arg0.UserInputType
		L_661_ = Enum.UserInputType.Touch
		L_663_ = (L_659_arg0.UserInputType == Enum.UserInputType.Touch)
		if not (L_659_arg0.UserInputType == Enum.UserInputType.Touch) then
			return
		end
		upvalue_1(L_659_arg0)
		L_660_ = upvalue_1
		L_661_ = L_659_arg0
	end
	return
end

L_1_.Set_110 = function(L_664_arg0, L_665_arg1)
	local L_666_, L_667_, L_668_, L_669_, L_670_, L_671_, L_672_
	L_667_ = upvalue_2
	L_667_.Size = UDim2.new(((L_665_arg1 - upvalue_0) / (upvalue_1 - upvalue_0)), 0, 1, 0)
	L_667_ = upvalue_3
	L_667_.Text = tostring(L_665_arg1)
	upvalue_4(L_665_arg1)
	return
end

L_1_.CreateSlider = function(L_673_arg0, L_674_arg1, L_675_arg2, L_676_arg3, L_677_arg4, L_678_arg5)
	local L_679_, L_680_, L_681_, L_682_, L_683_, L_684_, L_685_, L_686_, L_687_, L_688_, L_689_, L_690_, L_691_, L_692_
	L_680_ = {}
	L_680_.Parent = upvalue_0
	L_680_.BackgroundColor3 = Color3.fromRGB(13, 13, 13)
	L_680_.Size = UDim2.new(1, 0, 0, 50)
	L_681_ = Instance.new("Frame")
	for L_693_forvar0, L_694_forvar1 in next, L_680_ do
		L_691_ = "Parent"
		L_692_ = (L_693_forvar0 == "Parent")
		if not (L_693_forvar0 == "Parent") then
			L_681_[L_693_forvar0] = L_694_forvar1
		end
	end
	L_681_.Parent = L_680_.Parent
	L_680_ = {}
	L_680_.CornerRadius = UDim.new(0, 6)
	L_680_.Parent = L_681_
	L_679_ = L_681_
	L_681_ = Instance.new("UICorner")
	for L_695_forvar0, L_696_forvar1 in next, L_680_ do
		L_691_ = "Parent"
		L_692_ = (L_695_forvar0 == "Parent")
		if not (L_695_forvar0 == "Parent") then
			L_681_[L_695_forvar0] = L_696_forvar1
		end
	end
	L_681_.Parent = L_680_.Parent
	L_680_ = {}
	L_680_.Parent = L_679_
	L_680_.BackgroundTransparency = 1
	L_680_.Position = UDim2.new(0, 12, 0, 0)
	L_680_.Size = UDim2.new(1, -64, 0, 28)
	L_680_.Font = "Gotham"
	L_680_.Text = L_674_arg1
	L_680_.TextColor3 = Color3.fromRGB(225, 225, 225)
	L_680_.TextSize = 14
	L_680_.TextXAlignment = "Left"
	L_681_ = Instance.new("TextLabel")
	for L_697_forvar0, L_698_forvar1 in next, L_680_ do
		L_691_ = "Parent"
		L_692_ = (L_697_forvar0 == "Parent")
		if not (L_697_forvar0 == "Parent") then
			L_681_[L_697_forvar0] = L_698_forvar1
		end
	end
	L_681_.Parent = L_680_.Parent
	L_681_ = {}
	L_681_.Parent = L_679_
	L_681_.BackgroundTransparency = 1
	L_681_.Position = UDim2.new(1, -60, 0, 0)
	L_681_.Size = UDim2.new(0, 48, 0, 24)
	L_681_.Font = "GothamBold"
	L_681_.Text = tostring(L_677_arg4)
	L_681_.TextColor3 = upvalue_1.Accent
	L_681_.TextSize = 13
	L_681_.TextXAlignment = "Right"
	L_682_ = Instance.new("TextLabel")
	for L_699_forvar0, L_700_forvar1 in next, L_681_ do
		L_691_ = "Parent"
		L_692_ = (L_699_forvar0 == "Parent")
		if not (L_699_forvar0 == "Parent") then
			L_682_[L_699_forvar0] = L_700_forvar1
		end
	end
	L_682_.Parent = L_681_.Parent
	L_682_ = {}
	L_682_.Parent = L_679_
	L_682_.BackgroundColor3 = Color3.fromRGB(35, 35, 35)
	L_682_.Position = UDim2.new(0, 12, 0, 32)
	L_682_.Size = UDim2.new(1, -24, 0, 6)
	L_680_ = L_682_
	L_683_ = Instance.new("Frame")
	for L_701_forvar0, L_702_forvar1 in next, L_682_ do
		L_691_ = "Parent"
		L_692_ = (L_701_forvar0 == "Parent")
		if not (L_701_forvar0 == "Parent") then
			L_683_[L_701_forvar0] = L_702_forvar1
		end
	end
	L_683_.Parent = L_682_.Parent
	L_682_ = {}
	L_682_.CornerRadius = UDim.new(1, 0)
	L_682_.Parent = L_683_
	L_681_ = L_683_
	L_683_ = Instance.new("UICorner")
	for L_703_forvar0, L_704_forvar1 in next, L_682_ do
		L_691_ = "Parent"
		L_692_ = (L_703_forvar0 == "Parent")
		if not (L_703_forvar0 == "Parent") then
			L_683_[L_703_forvar0] = L_704_forvar1
		end
	end
	L_683_.Parent = L_682_.Parent
	L_683_ = {}
	L_683_.Parent = L_681_
	L_683_.BackgroundColor3 = upvalue_1.Accent
	L_683_.Size = UDim2.new(((L_677_arg4 - L_675_arg2) / (L_676_arg3 - L_675_arg2)), 0, 1, 0)
	L_684_ = Instance.new("Frame")
	for L_705_forvar0, L_706_forvar1 in next, L_683_ do
		L_691_ = "Parent"
		L_692_ = (L_705_forvar0 == "Parent")
		if not (L_705_forvar0 == "Parent") then
			L_684_[L_705_forvar0] = L_706_forvar1
		end
	end
	L_684_.Parent = L_683_.Parent
	L_683_ = {}
	L_683_.CornerRadius = UDim.new(1, 0)
	L_683_.Parent = L_684_
	L_682_ = L_684_
	L_684_ = Instance.new("UICorner")
	for L_707_forvar0, L_708_forvar1 in next, L_683_ do
		L_691_ = "Parent"
		L_692_ = (L_707_forvar0 == "Parent")
		if not (L_707_forvar0 == "Parent") then
			L_684_[L_707_forvar0] = L_708_forvar1
		end
	end
	L_684_.Parent = L_683_.Parent
	L_684_ = {}
	L_684_.Parent = L_682_
	L_684_.AnchorPoint = Vector2.new(1, 0.5)
	L_684_.BackgroundColor3 = Color3.new(1, 1, 1)
	L_684_.Position = UDim2.new(1, 0, 0.5, 0)
	L_684_.Size = UDim2.new(0, 12, 0, 12)
	L_685_ = Instance.new("Frame")
	for L_709_forvar0, L_710_forvar1 in next, L_684_ do
		L_691_ = "Parent"
		L_692_ = (L_709_forvar0 == "Parent")
		if not (L_709_forvar0 == "Parent") then
			L_685_[L_709_forvar0] = L_710_forvar1
		end
	end
	L_685_.Parent = L_684_.Parent
	L_684_ = {}
	L_684_.CornerRadius = UDim.new(1, 0)
	L_684_.Parent = L_685_
	L_683_ = L_685_
	L_685_ = Instance.new("UICorner")
	for L_711_forvar0, L_712_forvar1 in next, L_684_ do
		L_691_ = "Parent"
		L_692_ = (L_711_forvar0 == "Parent")
		if not (L_711_forvar0 == "Parent") then
			L_685_[L_711_forvar0] = L_712_forvar1
		end
	end
	L_685_.Parent = L_684_.Parent
	L_681_.InputBegan:Connect(L_1_.callback_107)
	upvalue_2.InputEnded:Connect(L_1_.callback_108)
	upvalue_2.InputChanged:Connect(L_1_.callback_109)
	L_686_ = {}
	L_686_.Set = L_1_.Set_110

	return L_686_
end

L_1_.callback_112 = function()
	local L_713_, L_714_, L_715_, L_716_, L_717_, L_718_, L_719_, L_720_, L_721_
	L_713_ = upvalue_0
	L_713_.Text = upvalue_1 .. ": " .. tostring(upvalue_2)
	upvalue_3 = false
	L_713_ = upvalue_4
	L_713_.Text = "\u{25bc}"
	L_714_ = {}
	L_714_.Size = UDim2.new(1, 0, 0, 42)
	L_715_ = upvalue_6:Create(upvalue_5, TweenInfo.new(0.25, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_714_)
	L_715_:Play()
	L_713_ = upvalue_7
	L_715_ = L_715_.Play
	L_716_ = L_715_
	L_717_ = upvalue_5
	L_718_ = TweenInfo.new(0.25, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
	L_719_ = L_714_
	L_720_ = Enum.EasingStyle.Quart
	L_721_ = Enum.EasingDirection.Out
	if not upvalue_7 then
		return
	end
	upvalue_7(upvalue_2)
	L_713_ = upvalue_7
	L_714_ = upvalue_2
	return
end

L_1_.callback_113 = function(L_722_arg0)
	local L_723_, L_724_, L_725_, L_726_, L_727_, L_728_, L_729_, L_730_, L_731_, L_732_, L_733_, L_734_, L_735_, L_736_, L_737_
	L_724_, L_725_ = upvalue_0:GetChildren()
	for L_738_forvar0, L_739_forvar1 in next, upvalue_0.GetChildren, upvalue_0 do
		L_728_ = L_739_forvar1:IsA("TextButton")
		L_729_ = L_739_forvar1
		L_730_ = "TextButton"
		if L_739_forvar1:IsA("TextButton") then
			L_739_forvar1:Destroy()
			L_728_ = L_739_forvar1.Destroy
			L_729_ = L_739_forvar1
		end
	end
	for L_740_forvar0, L_741_forvar1 in next, L_722_arg0 do
		L_729_ = {}
		L_729_.Parent = upvalue_0
		L_729_.BackgroundColor3 = Color3.fromRGB(22, 22, 22)
		L_729_.Size = UDim2.new(1, 0, 0, 28)
		L_729_.Font = "Gotham"
		L_729_.Text = tostring(L_741_forvar1)
		L_729_.TextColor3 = Color3.fromRGB(200, 200, 200)
		L_729_.TextSize = 13
		L_729_.AutoButtonColor = true
		L_730_ = Instance.new("TextButton")
		for L_742_forvar0, L_743_forvar1 in next, L_729_ do
			L_736_ = "Parent"
			L_737_ = (L_742_forvar0 == "Parent")
			if not (L_742_forvar0 == "Parent") then
				L_730_[L_742_forvar0] = L_743_forvar1
			end
		end
		L_730_.Parent = L_729_.Parent
		L_729_ = {}
		L_729_.CornerRadius = UDim.new(0, 4)
		L_729_.Parent = L_730_
		L_728_ = L_730_
		L_730_ = Instance.new("UICorner")
		for L_744_forvar0, L_745_forvar1 in next, L_729_ do
			L_736_ = "Parent"
			L_737_ = (L_744_forvar0 == "Parent")
			if not (L_744_forvar0 == "Parent") then
				L_730_[L_744_forvar0] = L_745_forvar1
			end
		end
		L_730_.Parent = L_729_.Parent
		L_728_.Activated:Connect(L_1_.callback_112)
		L_729_ = L_728_.Activated.Connect
		L_730_ = L_728_.Activated
		L_731_ = L_1_.callback_112
	end
	return
end

L_1_.callback_114 = function(L_746_arg0)
	local L_747_, L_748_, L_749_, L_750_, L_751_, L_752_, L_753_, L_754_, L_755_, L_756_, L_757_, L_758_
	L_747_ = L_746_arg0.UserInputType
	L_748_ = Enum.UserInputType.MouseButton1
	L_758_ = (L_746_arg0.UserInputType == Enum.UserInputType.MouseButton1)
	if (L_746_arg0.UserInputType == Enum.UserInputType.MouseButton1) then
		L_747_ = L_746_arg0.Position.Y
		L_748_ = (upvalue_0.AbsolutePosition.Y + 42)
		L_749_ = upvalue_0.AbsolutePosition.Y
		L_750_ = upvalue_0.AbsolutePosition
		L_751_ = upvalue_0
		L_758_ = (L_746_arg0.Position.Y < (upvalue_0.AbsolutePosition.Y + 42))
		if not (L_746_arg0.Position.Y < (upvalue_0.AbsolutePosition.Y + 42)) then
			return
		end
		upvalue_1 = not upvalue_1
		L_747_ = upvalue_2
		L_748_ = upvalue_1
		L_749_ = upvalue_1
		if not upvalue_1 then
			L_748_ = "\u{25bc}"
		else
			L_748_ = "\u{25b2}"
		end
		L_747_.Text = L_748_
		L_748_ = upvalue_1
		if not upvalue_1 then
			L_747_ = 42
		else
			L_747_ = ((42 + upvalue_3.UIListLayout.AbsoluteContentSize.Y) + 8)
			L_748_ = (42 + upvalue_3.UIListLayout.AbsoluteContentSize.Y)
			L_749_ = 42
			L_750_ = upvalue_3.UIListLayout.AbsoluteContentSize.Y
			L_751_ = upvalue_3.UIListLayout.AbsoluteContentSize
			L_752_ = upvalue_3.UIListLayout
			L_753_ = upvalue_3
			if not ((42 + upvalue_3.UIListLayout.AbsoluteContentSize.Y) + 8) then
				L_747_ = 42
			end
		end
		L_749_ = {}
		L_749_.Size = UDim2.new(1, 0, 0, L_747_)
		L_750_ = upvalue_4:Create(upvalue_0, TweenInfo.new(0.25, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_749_)
		L_750_:Play()
		L_748_ = upvalue_0
		L_750_ = L_750_.Play
		L_751_ = L_750_
		L_752_ = upvalue_0
		L_753_ = TweenInfo.new(0.25, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
		L_754_ = L_749_
		L_755_ = Enum.EasingStyle.Quart
		L_756_ = Enum.EasingDirection.Out
	else
		L_747_ = L_746_arg0.UserInputType
		L_748_ = Enum.UserInputType.Touch
		L_758_ = (L_746_arg0.UserInputType == Enum.UserInputType.Touch)
		if not (L_746_arg0.UserInputType == Enum.UserInputType.Touch) then
			return
		end
		L_747_ = L_746_arg0.Position.Y
		L_748_ = (upvalue_0.AbsolutePosition.Y + 42)
		L_749_ = upvalue_0.AbsolutePosition.Y
		L_750_ = upvalue_0.AbsolutePosition
		L_751_ = upvalue_0
		L_758_ = (L_746_arg0.Position.Y < (upvalue_0.AbsolutePosition.Y + 42))
		if not (L_746_arg0.Position.Y < (upvalue_0.AbsolutePosition.Y + 42)) then
			return
		end
		upvalue_1 = not upvalue_1
		L_747_ = upvalue_2
		L_748_ = upvalue_1
		L_749_ = upvalue_1
		if not upvalue_1 then
			L_748_ = "\u{25bc}"
		else
			L_748_ = "\u{25b2}"
		end
		L_747_.Text = L_748_
		L_748_ = upvalue_1
		if not upvalue_1 then
			L_747_ = 42
		else
			L_747_ = ((42 + upvalue_3.UIListLayout.AbsoluteContentSize.Y) + 8)
			L_748_ = (42 + upvalue_3.UIListLayout.AbsoluteContentSize.Y)
			L_749_ = 42
			L_750_ = upvalue_3.UIListLayout.AbsoluteContentSize.Y
			L_751_ = upvalue_3.UIListLayout.AbsoluteContentSize
			L_752_ = upvalue_3.UIListLayout
			L_753_ = upvalue_3
			if not ((42 + upvalue_3.UIListLayout.AbsoluteContentSize.Y) + 8) then
				L_747_ = 42
			end
		end
		L_749_ = {}
		L_749_.Size = UDim2.new(1, 0, 0, L_747_)
		L_750_ = upvalue_4:Create(upvalue_0, TweenInfo.new(0.25, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), L_749_)
		L_750_:Play()
		L_748_ = upvalue_0
		L_750_ = L_750_.Play
		L_751_ = L_750_
		L_752_ = upvalue_0
		L_753_ = TweenInfo.new(0.25, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
		L_754_ = L_749_
		L_755_ = Enum.EasingStyle.Quart
		L_756_ = Enum.EasingDirection.Out
	end
	return
end

L_1_.Refresh = function(L_759_arg0, L_760_arg1)
	local L_761_, L_762_
	upvalue_0(L_760_arg1)
	return
end

L_1_.CreateDropdown = function(L_763_arg0, L_764_arg1, L_765_arg2, L_766_arg3, L_767_arg4)
	local L_768_, L_769_, L_770_, L_771_, L_772_, L_773_, L_774_, L_775_, L_776_, L_777_, L_778_, L_779_, L_780_
	L_769_ = {}
	L_769_.Parent = upvalue_0
	L_769_.BackgroundColor3 = Color3.fromRGB(13, 13, 13)
	L_769_.Size = UDim2.new(1, 0, 0, 42)
	L_769_.ClipsDescendants = true
	L_770_ = Instance.new("Frame")
	for L_781_forvar0, L_782_forvar1 in next, L_769_ do
		L_779_ = "Parent"
		L_780_ = (L_781_forvar0 == "Parent")
		if not (L_781_forvar0 == "Parent") then
			L_770_[L_781_forvar0] = L_782_forvar1
		end
	end
	L_770_.Parent = L_769_.Parent
	L_769_ = {}
	L_769_.CornerRadius = UDim.new(0, 6)
	L_769_.Parent = L_770_
	L_768_ = L_770_
	L_770_ = Instance.new("UICorner")
	for L_783_forvar0, L_784_forvar1 in next, L_769_ do
		L_779_ = "Parent"
		L_780_ = (L_783_forvar0 == "Parent")
		if not (L_783_forvar0 == "Parent") then
			L_770_[L_783_forvar0] = L_784_forvar1
		end
	end
	L_770_.Parent = L_769_.Parent
	L_769_ = {}
	L_769_.Color = Color3.fromRGB(28, 28, 36)
	L_769_.Thickness = 1
	L_769_.Parent = L_768_
	L_770_ = Instance.new("UIStroke")
	for L_785_forvar0, L_786_forvar1 in next, L_769_ do
		L_779_ = "Parent"
		L_780_ = (L_785_forvar0 == "Parent")
		if not (L_785_forvar0 == "Parent") then
			L_770_[L_785_forvar0] = L_786_forvar1
		end
	end
	L_770_.Parent = L_769_.Parent
	L_770_ = {}
	L_770_.Parent = L_768_
	L_770_.BackgroundTransparency = 1
	L_770_.Position = UDim2.new(0, 12, 0, 0)
	L_770_.Size = UDim2.new(1, -52, 0, 42)
	L_770_.Font = "Gotham"
	L_771_ = "Gotham"
	L_772_ = 1
	L_773_ = -52
	L_774_ = 0
	L_775_ = 42
	if not L_766_arg3 then
		L_771_ = L_764_arg1 .. ": Select Option"
		L_772_ = L_764_arg1
		L_773_ = ": Select Option"
	else
		L_771_ = L_764_arg1 .. ": " .. tostring(L_766_arg3)
		L_772_ = L_764_arg1
		L_773_ = ": "
		L_774_ = tostring(L_766_arg3)
		L_775_ = L_766_arg3
		if not (L_764_arg1 .. ": " .. tostring(L_766_arg3)) then
			L_771_ = L_764_arg1 .. ": Select Option"
			L_772_ = L_764_arg1
			L_773_ = ": Select Option"
		end
	end
	L_770_.Text = L_771_
	L_770_.TextColor3 = Color3.fromRGB(225, 225, 225)
	L_770_.TextSize = 13
	L_770_.TextXAlignment = "Left"
	L_771_ = Instance.new("TextLabel")
	for L_787_forvar0, L_788_forvar1 in next, L_770_ do
		L_779_ = "Parent"
		L_780_ = (L_787_forvar0 == "Parent")
		if not (L_787_forvar0 == "Parent") then
			L_771_[L_787_forvar0] = L_788_forvar1
		end
	end
	L_771_.Parent = L_770_.Parent
	L_771_ = {}
	L_771_.Parent = L_768_
	L_771_.BackgroundTransparency = 1
	L_771_.Position = UDim2.new(1, -38, 0, 0)
	L_771_.Size = UDim2.new(0, 28, 0, 42)
	L_771_.Font = "GothamBold"
	L_771_.Text = "\u{25bc}"
	L_769_ = L_771_
	L_772_ = upvalue_1.Accent
	L_773_ = upvalue_1
	L_774_ = 28
	L_775_ = 0
	L_776_ = 42
	if not (upvalue_1.Accent) then
		L_772_ = Color3.fromRGB(0, 162, 255)
		L_773_ = 0
		L_774_ = 162
		L_775_ = 255
	end
	L_771_.TextColor3 = L_772_
	L_771_.TextSize = 16
	L_772_ = Instance.new("TextLabel")
	for L_789_forvar0, L_790_forvar1 in next, L_771_ do
		L_779_ = "Parent"
		L_780_ = (L_789_forvar0 == "Parent")
		if not (L_789_forvar0 == "Parent") then
			L_772_[L_789_forvar0] = L_790_forvar1
		end
	end
	L_772_.Parent = L_771_.Parent
	L_772_ = {}
	L_772_.Parent = L_768_
	L_772_.BackgroundTransparency = 1
	L_772_.Position = UDim2.new(0, 6, 0, 42)
	L_772_.Size = UDim2.new(1, -12, 0, 0)
	L_770_ = L_772_
	L_773_ = Instance.new("Frame")
	for L_791_forvar0, L_792_forvar1 in next, L_772_ do
		L_779_ = "Parent"
		L_780_ = (L_791_forvar0 == "Parent")
		if not (L_791_forvar0 == "Parent") then
			L_773_[L_791_forvar0] = L_792_forvar1
		end
	end
	L_773_.Parent = L_772_.Parent
	L_772_ = {}
	L_772_.Parent = L_773_
	L_772_.Padding = UDim.new(0, 3)
	L_771_ = L_773_
	L_773_ = Instance.new("UIListLayout")
	for L_793_forvar0, L_794_forvar1 in next, L_772_ do
		L_779_ = "Parent"
		L_780_ = (L_793_forvar0 == "Parent")
		if not (L_793_forvar0 == "Parent") then
			L_773_[L_793_forvar0] = L_794_forvar1
		end
	end
	L_773_.Parent = L_772_.Parent
	L_1_.callback_113(L_765_arg2)
	L_768_.InputBegan:Connect(L_1_.callback_114)
	L_774_ = {}
	L_774_.Refresh = L_1_.Refresh

	return L_774_
end

L_1_.Set_117 = function(L_795_arg0, L_796_arg1)
	local L_797_, L_798_, L_799_, L_800_, L_801_
	L_798_ = L_796_arg1:gsub("^\u{2500}\u{2500}%s*", "")
	L_797_ = upvalue_0
	L_797_.Text = L_798_:gsub("%s*\u{2500}\u{2500}$", "")
	return
end

L_1_.Set_118 = function(L_802_arg0, L_803_arg1)
	local L_804_
	L_804_ = upvalue_0
	L_804_.Text = L_803_arg1
	return
end

L_1_.CreateLabel = function(L_805_arg0, L_806_arg1)
	local L_807_, L_808_, L_809_, L_810_, L_811_, L_812_, L_813_, L_814_, L_815_, L_816_, L_817_, L_818_, L_819_
	L_807_ = true
	L_808_ = L_806_arg1:sub(1, 2)
	L_809_ = L_806_arg1
	L_810_ = 1
	L_811_ = 2
	L_818_ = "\u{2500}\u{2500}"
	L_819_ = (L_806_arg1:sub(1, 2) == "\u{2500}\u{2500}")
	if not (L_806_arg1:sub(1, 2) == "\u{2500}\u{2500}") then
		L_808_ = L_806_arg1:sub(1, 1)
		L_809_ = L_806_arg1
		L_810_ = 1
		L_811_ = 1
		L_818_ = "\u{2726}"
		L_819_ = (L_806_arg1:sub(1, 1) == "\u{2726}")
		if (L_806_arg1:sub(1, 1) == "\u{2726}") then
			L_807_ = true
		else
			L_807_ = false
		end
	end
	if not L_807_ then
		L_809_ = {}
		L_809_.Parent = upvalue_0
		L_809_.BackgroundColor3 = Color3.fromRGB(13, 13, 13)
		L_809_.Size = UDim2.new(1, 0, 0, 32)
		L_810_ = Instance.new("Frame")
		for L_820_forvar0, L_821_forvar1 in next, L_809_ do
			L_818_ = "Parent"
			L_819_ = (L_820_forvar0 == "Parent")
			if not (L_820_forvar0 == "Parent") then
				L_810_[L_820_forvar0] = L_821_forvar1
			end
		end
		L_810_.Parent = L_809_.Parent
		L_809_ = {}
		L_809_.CornerRadius = UDim.new(0, 6)
		L_809_.Parent = L_810_
		L_808_ = L_810_
		L_810_ = Instance.new("UICorner")
		for L_822_forvar0, L_823_forvar1 in next, L_809_ do
			L_818_ = "Parent"
			L_819_ = (L_822_forvar0 == "Parent")
			if not (L_822_forvar0 == "Parent") then
				L_810_[L_822_forvar0] = L_823_forvar1
			end
		end
		L_810_.Parent = L_809_.Parent
		L_810_ = {}
		L_810_.Parent = L_808_
		L_810_.BackgroundTransparency = 1
		L_810_.Position = UDim2.new(0, 12, 0, 0)
		L_810_.Size = UDim2.new(1, -24, 1, 0)
		L_810_.Font = "Gotham"
		L_810_.Text = L_806_arg1
		L_810_.TextColor3 = Color3.fromRGB(180, 180, 180)
		L_810_.TextSize = 13
		L_810_.TextXAlignment = "Left"
		L_811_ = Instance.new("TextLabel")
		for L_824_forvar0, L_825_forvar1 in next, L_810_ do
			L_818_ = "Parent"
			L_819_ = (L_824_forvar0 == "Parent")
			if not (L_824_forvar0 == "Parent") then
				L_811_[L_824_forvar0] = L_825_forvar1
			end
		end
		L_811_.Parent = L_810_.Parent
		L_810_ = {}
		L_810_.Set = L_1_.Set_118
		return L_810_
	else
		L_808_ = L_806_arg1:gsub("^\u{2500}\u{2500}%s*", "")
		L_810_ = {}
		L_810_.Parent = upvalue_0
		L_810_.BackgroundTransparency = 1
		L_810_.Size = UDim2.new(1, 0, 0, 26)
		L_808_ = L_808_:gsub("%s*\u{2500}\u{2500}$", "")
		L_809_ = L_808_
		L_811_ = Instance.new("Frame")
		for L_826_forvar0, L_827_forvar1 in next, L_810_ do
			L_818_ = "Parent"
			L_819_ = (L_826_forvar0 == "Parent")
			if not (L_826_forvar0 == "Parent") then
				L_811_[L_826_forvar0] = L_827_forvar1
			end
		end
		L_811_.Parent = L_810_.Parent
		L_811_ = {}
		L_811_.Parent = L_811_
		L_811_.BackgroundTransparency = 1
		L_811_.Position = UDim2.new(0, 4, 0, 4)
		L_811_.Size = UDim2.new(1, -8, 1, -4)
		L_811_.Font = "GothamBold"
		L_811_.Text = L_808_
		L_809_ = L_811_
		L_812_ = upvalue_1.Accent
		L_813_ = upvalue_1
		L_814_ = -8
		L_815_ = 1
		L_816_ = -4
		if not (upvalue_1.Accent) then
			L_812_ = Color3.fromRGB(0, 162, 255)
			L_813_ = 0
			L_814_ = 162
			L_815_ = 255
		end
		L_811_.TextColor3 = L_812_
		L_811_.TextSize = 12
		L_811_.TextXAlignment = "Left"
		L_812_ = Instance.new("TextLabel")
		for L_828_forvar0, L_829_forvar1 in next, L_811_ do
			L_818_ = "Parent"
			L_819_ = (L_828_forvar0 == "Parent")
			if not (L_828_forvar0 == "Parent") then
				L_812_[L_828_forvar0] = L_829_forvar1
			end
		end
		L_812_.Parent = L_811_.Parent
		L_811_ = {}
		L_811_.Set = L_1_.Set_117
		return L_811_
	end
end

L_1_.callback_120 = function(L_830_arg0)
	local L_831_, L_832_, L_833_
	L_831_ = upvalue_0
	if not upvalue_0 then
		return
	end
	upvalue_0(upvalue_1.Text)
	L_831_ = upvalue_0
	L_832_ = upvalue_1.Text
	L_833_ = upvalue_1
	return
end

L_1_.Set_121 = function(L_834_arg0, L_835_arg1)
	local L_836_, L_837_, L_838_
	L_836_ = upvalue_0
	L_836_.Text = tostring(L_835_arg1)
	return
end

L_1_.CreateInput = function(L_839_arg0, L_840_arg1, L_841_arg2, L_842_arg3)
	local L_843_, L_844_, L_845_, L_846_, L_847_, L_848_, L_849_, L_850_, L_851_, L_852_, L_853_, L_854_
	L_844_ = {}
	L_844_.Parent = upvalue_0
	L_844_.BackgroundColor3 = Color3.fromRGB(13, 13, 13)
	L_844_.Size = UDim2.new(1, 0, 0, 42)
	L_845_ = Instance.new("Frame")
	for L_855_forvar0, L_856_forvar1 in next, L_844_ do
		L_853_ = "Parent"
		L_854_ = (L_855_forvar0 == "Parent")
		if not (L_855_forvar0 == "Parent") then
			L_845_[L_855_forvar0] = L_856_forvar1
		end
	end
	L_845_.Parent = L_844_.Parent
	L_844_ = {}
	L_844_.CornerRadius = UDim.new(0, 6)
	L_844_.Parent = L_845_
	L_843_ = L_845_
	L_845_ = Instance.new("UICorner")
	for L_857_forvar0, L_858_forvar1 in next, L_844_ do
		L_853_ = "Parent"
		L_854_ = (L_857_forvar0 == "Parent")
		if not (L_857_forvar0 == "Parent") then
			L_845_[L_857_forvar0] = L_858_forvar1
		end
	end
	L_845_.Parent = L_844_.Parent
	L_844_ = {}
	L_844_.Color = Color3.fromRGB(28, 28, 36)
	L_844_.Thickness = 1
	L_844_.Parent = L_843_
	L_845_ = Instance.new("UIStroke")
	for L_859_forvar0, L_860_forvar1 in next, L_844_ do
		L_853_ = "Parent"
		L_854_ = (L_859_forvar0 == "Parent")
		if not (L_859_forvar0 == "Parent") then
			L_845_[L_859_forvar0] = L_860_forvar1
		end
	end
	L_845_.Parent = L_844_.Parent
	L_845_ = {}
	L_845_.Parent = L_843_
	L_845_.BackgroundTransparency = 1
	L_845_.Position = UDim2.new(0, 12, 0, 0)
	L_845_.Size = UDim2.new(0.4, -12, 1, 0)
	L_845_.Font = "Gotham"
	L_845_.Text = L_840_arg1
	L_845_.TextColor3 = Color3.fromRGB(225, 225, 225)
	L_845_.TextSize = 13
	L_845_.TextXAlignment = "Left"
	L_846_ = Instance.new("TextLabel")
	for L_861_forvar0, L_862_forvar1 in next, L_845_ do
		L_853_ = "Parent"
		L_854_ = (L_861_forvar0 == "Parent")
		if not (L_861_forvar0 == "Parent") then
			L_846_[L_861_forvar0] = L_862_forvar1
		end
	end
	L_846_.Parent = L_845_.Parent
	L_846_ = {}
	L_846_.Parent = L_843_
	L_846_.BackgroundColor3 = Color3.fromRGB(22, 22, 22)
	L_846_.Position = UDim2.new(0.4, 0, 0.15, 0)
	L_846_.Size = UDim2.new(0.6, -12, 0.7, 0)
	L_846_.Font = "Gotham"
	L_844_ = L_846_
	L_847_ = L_841_arg2
	L_848_ = 0.6
	L_849_ = -12
	L_850_ = 0.7
	L_851_ = 0
	if not (L_841_arg2) then
		L_847_ = ""
	end
	L_846_.Text = L_847_
	L_846_.TextColor3 = Color3.fromRGB(255, 255, 255)
	L_847_ = L_841_arg2
	L_848_ = 255
	L_849_ = 255
	L_850_ = 255
	if not (L_841_arg2) then
		L_847_ = "Type here..."
	end
	L_846_.PlaceholderText = L_847_
	L_846_.TextSize = 13
	L_846_.ClearTextOnFocus = false
	L_847_ = Instance.new("TextBox")
	for L_863_forvar0, L_864_forvar1 in next, L_846_ do
		L_853_ = "Parent"
		L_854_ = (L_863_forvar0 == "Parent")
		if not (L_863_forvar0 == "Parent") then
			L_847_[L_863_forvar0] = L_864_forvar1
		end
	end
	L_847_.Parent = L_846_.Parent
	L_846_ = {}
	L_846_.CornerRadius = UDim.new(0, 4)
	L_846_.Parent = L_847_
	L_845_ = L_847_
	L_847_ = Instance.new("UICorner")
	for L_865_forvar0, L_866_forvar1 in next, L_846_ do
		L_853_ = "Parent"
		L_854_ = (L_865_forvar0 == "Parent")
		if not (L_865_forvar0 == "Parent") then
			L_847_[L_865_forvar0] = L_866_forvar1
		end
	end
	L_847_.Parent = L_846_.Parent
	L_845_.FocusLost:Connect(L_1_.callback_120)
	L_846_ = {}
	L_846_.Set = L_1_.Set_121
	return L_846_
end

L_1_.CreateSection = function(L_867_arg0, L_868_arg1)
	local L_869_, L_870_, L_871_, L_872_, L_873_, L_874_, L_875_, L_876_, L_877_, L_878_, L_879_
	L_870_ = {}
	L_870_.Parent = upvalue_0
	L_870_.BackgroundColor3 = Color3.fromRGB(16, 16, 16)
	L_870_.Size = UDim2.new(1, 0, 0, 24)
	L_871_ = Instance.new("Frame")
	for L_880_forvar0, L_881_forvar1 in next, L_870_ do
		L_878_ = "Parent"
		L_879_ = (L_880_forvar0 == "Parent")
		if not (L_880_forvar0 == "Parent") then
			L_871_[L_880_forvar0] = L_881_forvar1
		end
	end
	L_871_.Parent = L_870_.Parent
	L_870_ = {}
	L_870_.CornerRadius = UDim.new(0, 6)
	L_870_.Parent = L_871_
	L_869_ = L_871_
	L_871_ = Instance.new("UICorner")
	for L_882_forvar0, L_883_forvar1 in next, L_870_ do
		L_878_ = "Parent"
		L_879_ = (L_882_forvar0 == "Parent")
		if not (L_882_forvar0 == "Parent") then
			L_871_[L_882_forvar0] = L_883_forvar1
		end
	end
	L_871_.Parent = L_870_.Parent
	L_870_ = {}
	L_870_.Parent = L_869_
	L_870_.BackgroundTransparency = 1
	L_870_.Position = UDim2.new(0, 12, 0, 0)
	L_870_.Size = UDim2.new(1, -12, 1, 0)
	L_870_.Font = "GothamBold"
	L_870_.Text = L_868_arg1:upper()
	L_870_.TextColor3 = Color3.fromRGB(190, 190, 190)
	L_870_.TextSize = 10
	L_870_.TextXAlignment = "Left"
	L_871_ = Instance.new("TextLabel")
	for L_884_forvar0, L_885_forvar1 in next, L_870_ do
		L_878_ = "Parent"
		L_879_ = (L_884_forvar0 == "Parent")
		if not (L_884_forvar0 == "Parent") then
			L_871_[L_884_forvar0] = L_885_forvar1
		end
	end
	L_871_.Parent = L_870_.Parent
	L_871_ = {}
	L_871_.Parent = upvalue_0
	L_871_.BackgroundTransparency = 1
	L_871_.Size = UDim2.new(1, 0, 0, 0)
	L_871_.AutomaticSize = "Y"
	L_872_ = Instance.new("Frame")
	for L_886_forvar0, L_887_forvar1 in next, L_871_ do
		L_878_ = "Parent"
		L_879_ = (L_886_forvar0 == "Parent")
		if not (L_886_forvar0 == "Parent") then
			L_872_[L_886_forvar0] = L_887_forvar1
		end
	end
	L_872_.Parent = L_871_.Parent
	L_871_ = {}
	L_871_.Parent = L_872_
	L_871_.Padding = UDim.new(0, 4)
	L_870_ = L_872_
	L_872_ = Instance.new("UIListLayout")
	for L_888_forvar0, L_889_forvar1 in next, L_871_ do
		L_878_ = "Parent"
		L_879_ = (L_888_forvar0 == "Parent")
		if not (L_888_forvar0 == "Parent") then
			L_872_[L_888_forvar0] = L_889_forvar1
		end
	end
	L_872_.Parent = L_871_.Parent
	L_871_ = {}
	L_871_.CreateToggle = L_1_.CreateToggle
	L_871_.CreateButton = L_1_.CreateButton
	L_871_.CreateSlider = L_1_.CreateSlider
	L_871_.CreateDropdown = L_1_.CreateDropdown
	L_871_.CreateLabel = L_1_.CreateLabel
	L_871_.CreateInput = L_1_.CreateInput
	return L_871_
end

L_1_.CreateSubTab = function(L_890_arg0, L_891_arg1, L_892_arg2)
	local L_893_, L_894_, L_895_, L_896_, L_897_, L_898_, L_899_, L_900_, L_901_, L_902_, L_903_, L_904_, L_905_, L_906_, L_907_, L_908_
	L_893_ = upvalue_0
	L_895_ = L_892_arg2
	if not (L_892_arg2) then
		L_895_ = "layout"
	end
	L_895_ = {}
	L_895_.Parent = upvalue_1
	L_895_.BackgroundTransparency = 1
	L_895_.Size = UDim2.new(0, 0, 1, 0)
	L_895_.AutomaticSize = "X"
	L_895_.Visible = false
	L_893_ = L_893_:GetIcon(L_895_)
	L_894_ = L_893_
	L_896_ = Instance.new("Frame")
	for L_909_forvar0, L_910_forvar1 in next, L_895_ do
		L_907_ = "Parent"
		L_908_ = (L_909_forvar0 == "Parent")
		if not (L_909_forvar0 == "Parent") then
			L_896_[L_909_forvar0] = L_910_forvar1
		end
	end
	L_896_.Parent = L_895_.Parent
	L_896_ = {}
	L_896_.Parent = L_896_
	L_896_.BackgroundTransparency = 1
	L_896_.Size = UDim2.new(1, 0, 1, 0)
	L_896_.Text = ""
	L_894_ = L_896_
	L_897_ = Instance.new("TextButton")
	for L_911_forvar0, L_912_forvar1 in next, L_896_ do
		L_907_ = "Parent"
		L_908_ = (L_911_forvar0 == "Parent")
		if not (L_911_forvar0 == "Parent") then
			L_897_[L_911_forvar0] = L_912_forvar1
		end
	end
	L_897_.Parent = L_896_.Parent
	L_897_ = {}
	L_897_.Name = "Icon"
	L_897_.Parent = L_894_
	L_897_.BackgroundTransparency = 1
	L_897_.Position = UDim2.new(0, 0, 0.5, -10)
	L_897_.Size = UDim2.new(0, 20, 0, 20)
	L_897_.Image = "rbxassetid://" .. L_893_[1]
	L_897_.ImageRectSize = Vector2.new(L_893_[2], L_893_[3])
	L_897_.ImageRectOffset = Vector2.new(L_893_[4], L_893_[5])
	L_897_.ImageColor3 = Color3.fromRGB(160, 160, 160)
	L_897_.ScaleType = Enum.ScaleType.Fit
	L_895_ = L_897_
	L_898_ = Instance.new("ImageLabel")
	for L_913_forvar0, L_914_forvar1 in next, L_897_ do
		L_907_ = "Parent"
		L_908_ = (L_913_forvar0 == "Parent")
		if not (L_913_forvar0 == "Parent") then
			L_898_[L_913_forvar0] = L_914_forvar1
		end
	end
	L_898_.Parent = L_897_.Parent
	L_898_ = {}
	L_898_.Name = "Label"
	L_898_.Parent = L_894_
	L_898_.BackgroundTransparency = 1
	L_898_.Position = UDim2.new(0, 22, 0, 0)
	L_898_.Size = UDim2.new(0, 0, 1, 0)
	L_898_.AutomaticSize = "X"
	L_898_.Font = "Gotham"
	L_898_.Text = L_891_arg1
	L_898_.TextColor3 = Color3.fromRGB(160, 160, 160)
	L_898_.TextSize = 13
	L_896_ = L_898_
	L_899_ = Instance.new("TextLabel")
	for L_915_forvar0, L_916_forvar1 in next, L_898_ do
		L_907_ = "Parent"
		L_908_ = (L_915_forvar0 == "Parent")
		if not (L_915_forvar0 == "Parent") then
			L_899_[L_915_forvar0] = L_916_forvar1
		end
	end
	L_899_.Parent = L_898_.Parent
	L_899_ = {}
	L_899_.Parent = L_894_
	L_899_.BackgroundColor3 = upvalue_0.Accent
	L_899_.BackgroundTransparency = 1
	L_899_.BorderSizePixel = 0
	L_899_.Position = UDim2.new(0, 0, 1, -2)
	L_899_.Size = UDim2.new(1, 0, 0, 2)
	L_897_ = L_899_
	L_900_ = Instance.new("Frame")
	for L_917_forvar0, L_918_forvar1 in next, L_899_ do
		L_907_ = "Parent"
		L_908_ = (L_917_forvar0 == "Parent")
		if not (L_917_forvar0 == "Parent") then
			L_900_[L_917_forvar0] = L_918_forvar1
		end
	end
	L_900_.Parent = L_899_.Parent
	L_900_ = {}
	L_900_.Parent = upvalue_2
	L_900_.BackgroundTransparency = 1
	L_900_.BorderSizePixel = 0
	L_900_.Size = UDim2.new(1, 0, 1, 0)
	L_900_.Visible = false
	L_900_.ScrollBarThickness = 2
	L_900_.ScrollBarImageColor3 = upvalue_0.Accent
	L_900_.CanvasSize = UDim2.new(0, 0, 0, 0)
	L_900_.AutomaticCanvasSize = "Y"
	L_898_ = L_900_
	L_901_ = Instance.new("ScrollingFrame")
	for L_919_forvar0, L_920_forvar1 in next, L_900_ do
		L_907_ = "Parent"
		L_908_ = (L_919_forvar0 == "Parent")
		if not (L_919_forvar0 == "Parent") then
			L_901_[L_919_forvar0] = L_920_forvar1
		end
	end
	L_901_.Parent = L_900_.Parent
	L_900_ = {}
	L_900_.Parent = L_901_
	L_900_.Padding = UDim.new(0, 6)
	L_900_.HorizontalAlignment = "Center"
	L_899_ = L_901_
	L_901_ = Instance.new("UIListLayout")
	for L_921_forvar0, L_922_forvar1 in next, L_900_ do
		L_907_ = "Parent"
		L_908_ = (L_921_forvar0 == "Parent")
		if not (L_921_forvar0 == "Parent") then
			L_901_[L_921_forvar0] = L_922_forvar1
		end
	end
	L_901_.Parent = L_900_.Parent
	L_900_ = {}
	L_900_.Parent = L_899_
	L_900_.PaddingTop = UDim.new(0, 10)
	L_900_.PaddingLeft = UDim.new(0, 18)
	L_900_.PaddingRight = UDim.new(0, 18)
	L_901_ = Instance.new("UIPadding")
	for L_923_forvar0, L_924_forvar1 in next, L_900_ do
		L_907_ = "Parent"
		L_908_ = (L_923_forvar0 == "Parent")
		if not (L_923_forvar0 == "Parent") then
			L_901_[L_923_forvar0] = L_924_forvar1
		end
	end
	L_901_.Parent = L_900_.Parent
	L_900_ = {}
	L_900_.Page = L_899_
	L_900_.Btn = L_894_
	L_900_.Select = L_1_.Select_98
	L_895_.Activated:Connect(L_1_.callback_99)
	table.insert(upvalue_3.SubTabs, L_900_)
	L_901_ = upvalue_5.Current
	L_902_ = upvalue_5
	L_903_ = L_900_
	if not upvalue_5.Current then
		L_900_.CreateSection = L_1_.CreateSection
		return L_900_
	end
	L_901_ = upvalue_5.Current.Tab
	L_902_ = upvalue_3
	L_903_ = upvalue_5
	L_908_ = (upvalue_5.Current.Tab == upvalue_3)
	if not (upvalue_5.Current.Tab == upvalue_3) then
		L_900_.CreateSection = L_1_.CreateSection
		return L_900_
	end
	L_901_ = upvalue_3.CurrentST
	L_902_ = upvalue_3
	if upvalue_3.CurrentST then
		L_900_.CreateSection = L_1_.CreateSection
		return L_900_
	end
	L_894_.Visible = true
	L_900_:Select()
	L_901_ = L_900_.Select
	L_902_ = L_900_
	L_900_.CreateSection = L_1_.CreateSection
	return L_900_
end

L_1_.CreateTab = function(L_925_arg0, L_926_arg1, L_927_arg2)
	local L_928_, L_929_, L_930_, L_931_, L_932_, L_933_, L_934_, L_935_, L_936_, L_937_, L_938_, L_939_, L_940_, L_941_
	L_929_ = {}
	L_929_.Name = L_926_arg1 .. "Tab"
	L_929_.Parent = upvalue_0
	L_929_.BackgroundTransparency = 1
	L_929_.Size = UDim2.new(1, 0, 0, 50)
	L_930_ = Instance.new("ImageButton")
	for L_942_forvar0, L_943_forvar1 in next, L_929_ do
		L_940_ = "Parent"
		L_941_ = (L_942_forvar0 == "Parent")
		if not (L_942_forvar0 == "Parent") then
			L_930_[L_942_forvar0] = L_943_forvar1
		end
	end
	L_930_.Parent = L_929_.Parent
	L_930_ = {}
	L_930_.Parent = L_930_
	L_930_.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
	L_930_.BackgroundTransparency = 1
	L_930_.BorderSizePixel = 0
	L_930_.Size = UDim2.new(1, 0, 1, 0)
	L_928_ = L_930_
	L_931_ = Instance.new("Frame")
	for L_944_forvar0, L_945_forvar1 in next, L_930_ do
		L_940_ = "Parent"
		L_941_ = (L_944_forvar0 == "Parent")
		if not (L_944_forvar0 == "Parent") then
			L_931_[L_944_forvar0] = L_945_forvar1
		end
	end
	L_931_.Parent = L_930_.Parent
	L_930_ = {}
	L_930_.CornerRadius = UDim.new(0, 6)
	L_930_.Parent = L_931_
	L_929_ = L_931_
	L_931_ = Instance.new("UICorner")
	for L_946_forvar0, L_947_forvar1 in next, L_930_ do
		L_940_ = "Parent"
		L_941_ = (L_946_forvar0 == "Parent")
		if not (L_946_forvar0 == "Parent") then
			L_931_[L_946_forvar0] = L_947_forvar1
		end
	end
	L_931_.Parent = L_930_.Parent
	L_931_ = {}
	L_931_.Name = "Indicator"
	L_931_.Parent = L_928_
	L_931_.BackgroundColor3 = upvalue_1.Accent
	L_931_.BorderSizePixel = 0
	L_931_.Position = UDim2.new(0, 0, 0.5, -12)
	L_931_.Size = UDim2.new(0, 3, 0, 24)
	L_931_.BackgroundTransparency = 1
	L_931_.ZIndex = 5
	L_932_ = Instance.new("Frame")
	for L_948_forvar0, L_949_forvar1 in next, L_931_ do
		L_940_ = "Parent"
		L_941_ = (L_948_forvar0 == "Parent")
		if not (L_948_forvar0 == "Parent") then
			L_932_[L_948_forvar0] = L_949_forvar1
		end
	end
	L_932_.Parent = L_931_.Parent
	L_931_ = {}
	L_931_.CornerRadius = UDim.new(1, 0)
	L_931_.Parent = L_932_
	L_930_ = L_932_
	L_932_ = Instance.new("UICorner")
	for L_950_forvar0, L_951_forvar1 in next, L_931_ do
		L_940_ = "Parent"
		L_941_ = (L_950_forvar0 == "Parent")
		if not (L_950_forvar0 == "Parent") then
			L_932_[L_950_forvar0] = L_951_forvar1
		end
	end
	L_932_.Parent = L_931_.Parent
	L_931_ = upvalue_1
	L_933_ = L_927_arg2
	if not (L_927_arg2) then
		L_933_ = "home"
	end
	L_933_ = {}
	L_933_.Name = "Icon"
	L_933_.Parent = L_928_
	L_933_.BackgroundTransparency = 1
	L_933_.Position = UDim2.new(0.5, -18, 0.5, -18)
	L_933_.Size = UDim2.new(0, 36, 0, 36)
	L_933_.Image = "rbxassetid://" .. L_931_:GetIcon(L_933_)[1]
	L_933_.ImageRectSize = Vector2.new(L_931_:GetIcon(L_933_)[2], L_931_:GetIcon(L_933_)[3])
	L_933_.ImageRectOffset = Vector2.new(L_931_:GetIcon(L_933_)[4], L_931_:GetIcon(L_933_)[5])
	L_933_.ImageColor3 = Color3.fromRGB(140, 140, 140)
	L_933_.ScaleType = Enum.ScaleType.Fit
	L_933_.ZIndex = 6
	L_931_ = L_931_:GetIcon(L_933_)
	L_932_ = L_931_
	L_934_ = Instance.new("ImageLabel")
	for L_952_forvar0, L_953_forvar1 in next, L_933_ do
		L_940_ = "Parent"
		L_941_ = (L_952_forvar0 == "Parent")
		if not (L_952_forvar0 == "Parent") then
			L_934_[L_952_forvar0] = L_953_forvar1
		end
	end
	L_934_.Parent = L_933_.Parent
	L_933_ = {}
	L_933_.SubTabs = {}
	L_933_.CurrentST = nil
	L_933_.Select = L_1_.Select
	L_928_.Activated:Connect(L_1_.callback_96)
	L_933_.SetVisible = L_1_.SetVisible
	L_933_.CreateSubTab = L_1_.CreateSubTab
	L_934_ = Window.Tabs
	L_934_[L_926_arg1] = L_933_
	L_932_ = L_934_
	L_934_ = upvalue_3.Current
	L_935_ = upvalue_3
	L_936_ = L_1_.callback_96
	if upvalue_3.Current then
		return L_933_
	end
	L_933_:Select()
	L_934_ = L_933_.Select
	L_935_ = L_933_
	return L_933_
end

L_1_.CreateWindow = function(L_954_arg0, L_955_arg1)
	local L_956_, L_957_, L_958_, L_959_, L_960_, L_961_, L_962_, L_963_, L_964_, L_965_, L_966_, L_967_, L_968_, L_969_, L_970_, L_971_
	local L_972_, L_973_, L_974_, L_975_, L_976_, L_977_, L_978_, L_979_, L_980_, L_981_, L_982_, L_983_, L_984_, L_985_, L_986_, L_987_
	local L_988_
	L_956_ = nil
	L_957_ = pcall
	L_958_ = L_1_.callback_73
	L_957_, L_958_ = pcall(L_1_.callback_73)
	if not L_957_ then
		L_960_ = math.random
		L_961_ = 10000000
		L_962_ = 90000000
		L_959_ = tostring(math.random(10000000, 90000000))
	else
		L_959_ = L_958_
		if not (L_958_) then
			L_960_ = math.random
			L_961_ = 10000000
			L_962_ = 90000000
			L_959_ = tostring(math.random(10000000, 90000000))
		end
	end
	L_958_ = {}
	L_958_.Name = L_959_
	L_958_.ResetOnSpawn = false
	L_956_ = L_959_
	L_959_ = Instance.new("ScreenGui")
	for L_989_forvar0, L_990_forvar1 in next, L_958_ do
		L_987_ = "Parent"
		L_988_ = (L_989_forvar0 == "Parent")
		if not (L_989_forvar0 == "Parent") then
			L_959_[L_989_forvar0] = L_990_forvar1
		end
	end
	L_959_.Parent = L_958_.Parent
	L_957_ = L_959_
	L_958_ = false
	L_959_ = upvalue_0:IsStudio()
	L_960_ = upvalue_0
	if not (upvalue_0:IsStudio()) then
		L_959_ = syn
		if syn then
			L_959_ = syn.protect_gui
			if syn.protect_gui then
				pcall(L_1_.callback_74)
				L_959_ = pcall
				L_960_ = L_1_.callback_74
			end
		end
		if not (L_958_) then
			L_959_ = gethui
			if gethui then
				pcall(L_1_.callback_75)
				L_959_ = pcall
				L_960_ = L_1_.callback_75
			end
		end
		if not (L_958_) then
			L_959_ = get_hidden_gui
			if get_hidden_gui then
				pcall(L_1_.callback_76)
				L_959_ = pcall
				L_960_ = L_1_.callback_76
			end
		end
	end
	if not (L_958_) then
		L_960_ = upvalue_0:IsStudio()
		L_961_ = upvalue_0
		if not upvalue_0:IsStudio() then
			L_959_ = upvalue_1
		else
			L_959_ = upvalue_2.PlayerGui
			L_960_ = upvalue_2
			if not (upvalue_2.PlayerGui) then
				L_959_ = upvalue_1
			end
		end
		L_957_.Parent = L_959_
	end
	L_959_ = getgenv
	if getgenv then
		L_959_ = "_h_" .. L_956_
		L_960_ = getgenv()["_h_" .. L_956_]
		L_961_ = getgenv()
		if getgenv()["_h_" .. L_956_] then
			pcall(L_1_.callback_77)
			L_960_ = pcall
			L_961_ = L_1_.callback_77
		end
		L_960_ = getgenv()
		L_960_[L_959_] = L_957_
	end
	L_960_ = {}
	L_960_.Parent = L_957_
	L_960_.BackgroundColor3 = upvalue_3.BgPrimary
	L_960_.Position = UDim2.new(0.5, -300, 0.5, -220)
	L_960_.Size = UDim2.new(0, 600, 0, 440)
	L_960_.ClipsDescendants = true
	L_960_.Visible = true
	L_961_ = Instance.new("Frame")
	for L_991_forvar0, L_992_forvar1 in next, L_960_ do
		L_987_ = "Parent"
		L_988_ = (L_991_forvar0 == "Parent")
		if not (L_991_forvar0 == "Parent") then
			L_961_[L_991_forvar0] = L_992_forvar1
		end
	end
	L_961_.Parent = L_960_.Parent
	L_960_ = {}
	L_960_.CornerRadius = UDim.new(0, 10)
	L_960_.Parent = L_961_
	L_959_ = L_961_
	L_961_ = Instance.new("UICorner")
	for L_993_forvar0, L_994_forvar1 in next, L_960_ do
		L_987_ = "Parent"
		L_988_ = (L_993_forvar0 == "Parent")
		if not (L_993_forvar0 == "Parent") then
			L_961_[L_993_forvar0] = L_994_forvar1
		end
	end
	L_961_.Parent = L_960_.Parent
	L_961_ = {}
	L_961_.Name = "Glow"
	L_961_.Parent = L_959_
	L_961_.ZIndex = 0
	L_961_.BackgroundTransparency = 1
	L_961_.Position = UDim2.new(0, -25, 0, -25)
	L_961_.Size = UDim2.new(1, 50, 1, 50)
	L_961_.Image = "rbxassetid://6015667320"
	L_961_.ImageColor3 = upvalue_3.Accent
	L_961_.ImageTransparency = 0.5
	L_961_.ScaleType = Enum.ScaleType.Slice
	L_961_.SliceCenter = Rect.new(49, 49, 450, 450)
	L_962_ = Instance.new("ImageLabel")
	for L_995_forvar0, L_996_forvar1 in next, L_961_ do
		L_987_ = "Parent"
		L_988_ = (L_995_forvar0 == "Parent")
		if not (L_995_forvar0 == "Parent") then
			L_962_[L_995_forvar0] = L_996_forvar1
		end
	end
	L_962_.Parent = L_961_.Parent
	L_961_ = {}
	L_961_.Color = upvalue_3.Border
	L_961_.Thickness = 1
	L_961_.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	L_961_.LineJoinMode = Enum.LineJoinMode.Round
	L_961_.Parent = L_959_
	L_960_ = L_962_
	L_962_ = Instance.new("UIStroke")
	for L_997_forvar0, L_998_forvar1 in next, L_961_ do
		L_987_ = "Parent"
		L_988_ = (L_997_forvar0 == "Parent")
		if not (L_997_forvar0 == "Parent") then
			L_962_[L_997_forvar0] = L_998_forvar1
		end
	end
	L_962_.Parent = L_961_.Parent
	task.spawn(L_1_.callback_79)
	L_962_ = {}
	L_962_.Parent = L_959_
	L_962_.BackgroundColor3 = upvalue_3.BgSecondary
	L_962_.Size = UDim2.new(0, 65, 1, 0)
	L_961_ = task.spawn
	L_963_ = Instance.new("Frame")
	for L_999_forvar0, L_1000_forvar1 in next, L_962_ do
		L_987_ = "Parent"
		L_988_ = (L_999_forvar0 == "Parent")
		if not (L_999_forvar0 == "Parent") then
			L_963_[L_999_forvar0] = L_1000_forvar1
		end
	end
	L_963_.Parent = L_962_.Parent
	L_962_ = {}
	L_962_.CornerRadius = UDim.new(0, 10)
	L_962_.Parent = L_963_
	L_961_ = L_963_
	L_963_ = Instance.new("UICorner")
	for L_1001_forvar0, L_1002_forvar1 in next, L_962_ do
		L_987_ = "Parent"
		L_988_ = (L_1001_forvar0 == "Parent")
		if not (L_1001_forvar0 == "Parent") then
			L_963_[L_1001_forvar0] = L_1002_forvar1
		end
	end
	L_963_.Parent = L_962_.Parent
	L_962_ = {}
	L_962_.Parent = L_961_
	L_962_.BackgroundColor3 = upvalue_3.BgSecondary
	L_962_.BorderSizePixel = 0
	L_962_.AnchorPoint = Vector2.new(1, 0)
	L_962_.Position = UDim2.new(1, 0, 0, 0)
	L_962_.Size = UDim2.new(0, 15, 1, 0)
	L_963_ = Instance.new("Frame")
	for L_1003_forvar0, L_1004_forvar1 in next, L_962_ do
		L_987_ = "Parent"
		L_988_ = (L_1003_forvar0 == "Parent")
		if not (L_1003_forvar0 == "Parent") then
			L_963_[L_1003_forvar0] = L_1004_forvar1
		end
	end
	L_963_.Parent = L_962_.Parent
	L_962_ = {}
	L_962_.Color = upvalue_3.Border
	L_962_.ApplyStrokeMode = "Border"
	L_962_.Parent = L_961_
	L_963_ = Instance.new("UIStroke")
	for L_1005_forvar0, L_1006_forvar1 in next, L_962_ do
		L_987_ = "Parent"
		L_988_ = (L_1005_forvar0 == "Parent")
		if not (L_1005_forvar0 == "Parent") then
			L_963_[L_1005_forvar0] = L_1006_forvar1
		end
	end
	L_963_.Parent = L_962_.Parent
	L_963_ = {}
	L_963_.Name = "Branding"
	L_963_.Parent = L_961_
	L_963_.BackgroundTransparency = 1
	L_963_.Size = UDim2.new(1, 0, 0, 65)
	L_964_ = Instance.new("Frame")
	for L_1007_forvar0, L_1008_forvar1 in next, L_963_ do
		L_987_ = "Parent"
		L_988_ = (L_1007_forvar0 == "Parent")
		if not (L_1007_forvar0 == "Parent") then
			L_964_[L_1007_forvar0] = L_1008_forvar1
		end
	end
	L_964_.Parent = L_963_.Parent
	L_963_ = {}
	L_963_.Parent = L_964_
	L_963_.BackgroundTransparency = 1
	L_963_.AnchorPoint = Vector2.new(0.5, 0.5)
	L_963_.Position = UDim2.new(0.5, 0, 0.5, 0)
	L_963_.Size = UDim2.new(0, 42, 0, 42)
	L_963_.Image = "rbxassetid://123802801726537"
	L_963_.ScaleType = Enum.ScaleType.Fit
	L_962_ = L_964_
	L_964_ = Instance.new("ImageLabel")
	for L_1009_forvar0, L_1010_forvar1 in next, L_963_ do
		L_987_ = "Parent"
		L_988_ = (L_1009_forvar0 == "Parent")
		if not (L_1009_forvar0 == "Parent") then
			L_964_[L_1009_forvar0] = L_1010_forvar1
		end
	end
	L_964_.Parent = L_963_.Parent
	L_963_ = {}
	L_963_.Parent = L_962_
	L_963_.BackgroundColor3 = Color3.fromRGB(35, 35, 35)
	L_963_.BorderSizePixel = 0
	L_963_.Position = UDim2.new(0, 10, 1, -1)
	L_963_.Size = UDim2.new(1, -20, 0, 1)
	L_964_ = Instance.new("Frame")
	for L_1011_forvar0, L_1012_forvar1 in next, L_963_ do
		L_987_ = "Parent"
		L_988_ = (L_1011_forvar0 == "Parent")
		if not (L_1011_forvar0 == "Parent") then
			L_964_[L_1011_forvar0] = L_1012_forvar1
		end
	end
	L_964_.Parent = L_963_.Parent
	L_964_ = {}
	L_964_.Parent = L_961_
	L_964_.BackgroundTransparency = 1
	L_964_.Position = UDim2.new(0, 0, 0, 65)
	L_964_.Size = UDim2.new(1, 0, 1, -135)
	L_964_.CanvasSize = UDim2.new(0, 0, 0, 0)
	L_964_.AutomaticCanvasSize = "Y"
	L_964_.ScrollBarThickness = 1
	L_964_.ScrollBarImageTransparency = 1
	L_964_.ScrollingDirection = "Y"
	L_965_ = Instance.new("ScrollingFrame")
	for L_1013_forvar0, L_1014_forvar1 in next, L_964_ do
		L_987_ = "Parent"
		L_988_ = (L_1013_forvar0 == "Parent")
		if not (L_1013_forvar0 == "Parent") then
			L_965_[L_1013_forvar0] = L_1014_forvar1
		end
	end
	L_965_.Parent = L_964_.Parent
	L_964_ = {}
	L_964_.Parent = L_965_
	L_964_.HorizontalAlignment = "Center"
	L_964_.Padding = UDim.new(0, 8)
	L_963_ = L_965_
	L_965_ = Instance.new("UIListLayout")
	for L_1015_forvar0, L_1016_forvar1 in next, L_964_ do
		L_987_ = "Parent"
		L_988_ = (L_1015_forvar0 == "Parent")
		if not (L_1015_forvar0 == "Parent") then
			L_965_[L_1015_forvar0] = L_1016_forvar1
		end
	end
	L_965_.Parent = L_964_.Parent
	L_965_ = {}
	L_965_.Name = "Profile"
	L_965_.Parent = L_961_
	L_965_.BackgroundTransparency = 1
	L_965_.AnchorPoint = Vector2.new(0, 1)
	L_965_.Position = UDim2.new(0, 0, 1, 0)
	L_965_.Size = UDim2.new(1, 0, 0, 70)
	L_966_ = Instance.new("Frame")
	for L_1017_forvar0, L_1018_forvar1 in next, L_965_ do
		L_987_ = "Parent"
		L_988_ = (L_1017_forvar0 == "Parent")
		if not (L_1017_forvar0 == "Parent") then
			L_966_[L_1017_forvar0] = L_1018_forvar1
		end
	end
	L_966_.Parent = L_965_.Parent
	L_965_ = {}
	L_965_.Parent = L_966_
	L_965_.BackgroundColor3 = Color3.fromRGB(35, 35, 35)
	L_965_.BorderSizePixel = 0
	L_965_.Position = UDim2.new(0, 10, 0, 0)
	L_965_.Size = UDim2.new(1, -20, 0, 1)
	L_964_ = L_966_
	L_966_ = Instance.new("Frame")
	for L_1019_forvar0, L_1020_forvar1 in next, L_965_ do
		L_987_ = "Parent"
		L_988_ = (L_1019_forvar0 == "Parent")
		if not (L_1019_forvar0 == "Parent") then
			L_966_[L_1019_forvar0] = L_1020_forvar1
		end
	end
	L_966_.Parent = L_965_.Parent
	L_966_ = {}
	L_966_.Parent = L_964_
	L_966_.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
	L_966_.AnchorPoint = Vector2.new(0.5, 0.5)
	L_966_.Position = UDim2.new(0.5, 0, 0.5, 0)
	L_966_.Size = UDim2.new(0, 44, 0, 44)
	L_967_ = Instance.new("Frame")
	for L_1021_forvar0, L_1022_forvar1 in next, L_966_ do
		L_987_ = "Parent"
		L_988_ = (L_1021_forvar0 == "Parent")
		if not (L_1021_forvar0 == "Parent") then
			L_967_[L_1021_forvar0] = L_1022_forvar1
		end
	end
	L_967_.Parent = L_966_.Parent
	L_966_ = {}
	L_966_.CornerRadius = UDim.new(1, 0)
	L_966_.Parent = L_967_
	L_965_ = L_967_
	L_967_ = Instance.new("UICorner")
	for L_1023_forvar0, L_1024_forvar1 in next, L_966_ do
		L_987_ = "Parent"
		L_988_ = (L_1023_forvar0 == "Parent")
		if not (L_1023_forvar0 == "Parent") then
			L_967_[L_1023_forvar0] = L_1024_forvar1
		end
	end
	L_967_.Parent = L_966_.Parent
	L_966_ = {}
	L_966_.Color = upvalue_3.Border
	L_966_.Thickness = 1
	L_966_.Parent = L_965_
	L_967_ = Instance.new("UIStroke")
	for L_1025_forvar0, L_1026_forvar1 in next, L_966_ do
		L_987_ = "Parent"
		L_988_ = (L_1025_forvar0 == "Parent")
		if not (L_1025_forvar0 == "Parent") then
			L_967_[L_1025_forvar0] = L_1026_forvar1
		end
	end
	L_967_.Parent = L_966_.Parent
	L_967_ = {}
	L_967_.Parent = L_965_
	L_967_.BackgroundTransparency = 1
	L_967_.Size = UDim2.new(1, 0, 1, 0)
	L_967_.Image = ""
	L_968_ = Instance.new("ImageLabel")
	for L_1027_forvar0, L_1028_forvar1 in next, L_967_ do
		L_987_ = "Parent"
		L_988_ = (L_1027_forvar0 == "Parent")
		if not (L_1027_forvar0 == "Parent") then
			L_968_[L_1027_forvar0] = L_1028_forvar1
		end
	end
	L_968_.Parent = L_967_.Parent
	L_967_ = {}
	L_967_.CornerRadius = UDim.new(1, 0)
	L_967_.Parent = L_968_
	L_966_ = L_968_
	L_968_ = Instance.new("UICorner")
	for L_1029_forvar0, L_1030_forvar1 in next, L_967_ do
		L_987_ = "Parent"
		L_988_ = (L_1029_forvar0 == "Parent")
		if not (L_1029_forvar0 == "Parent") then
			L_968_[L_1029_forvar0] = L_1030_forvar1
		end
	end
	L_968_.Parent = L_967_.Parent
	task.spawn(L_1_.callback_81)
	L_968_ = {}
	L_968_.Parent = L_959_
	L_968_.BackgroundTransparency = 1
	L_968_.Position = UDim2.new(0, 65, 0, 0)
	L_968_.Size = UDim2.new(1, -65, 1, 0)
	L_967_ = task.spawn
	L_969_ = Instance.new("Frame")
	for L_1031_forvar0, L_1032_forvar1 in next, L_968_ do
		L_987_ = "Parent"
		L_988_ = (L_1031_forvar0 == "Parent")
		if not (L_1031_forvar0 == "Parent") then
			L_969_[L_1031_forvar0] = L_1032_forvar1
		end
	end
	L_969_.Parent = L_968_.Parent
	L_969_ = {}
	L_969_.Name = "DragBar"
	L_969_.Parent = L_959_
	L_969_.BackgroundTransparency = 1
	L_969_.Size = UDim2.new(1, 0, 0, 48)
	L_969_.ZIndex = 0
	L_967_ = L_969_
	L_970_ = Instance.new("Frame")
	for L_1033_forvar0, L_1034_forvar1 in next, L_969_ do
		L_987_ = "Parent"
		L_988_ = (L_1033_forvar0 == "Parent")
		if not (L_1033_forvar0 == "Parent") then
			L_970_[L_1033_forvar0] = L_1034_forvar1
		end
	end
	L_970_.Parent = L_969_.Parent
	L_970_ = {}
	L_970_.Name = "DragSide"
	L_970_.Parent = L_961_
	L_970_.BackgroundTransparency = 1
	L_970_.Size = UDim2.new(1, 0, 0, 65)
	L_970_.ZIndex = 11
	L_968_ = L_970_
	L_971_ = Instance.new("Frame")
	for L_1035_forvar0, L_1036_forvar1 in next, L_970_ do
		L_987_ = "Parent"
		L_988_ = (L_1035_forvar0 == "Parent")
		if not (L_1035_forvar0 == "Parent") then
			L_971_[L_1035_forvar0] = L_1036_forvar1
		end
	end
	L_971_.Parent = L_970_.Parent
	upvalue_6:MakeDraggable(L_971_, L_959_)
	L_972_ = {}
	L_972_.Parent = L_967_
	L_972_.BackgroundTransparency = 1
	L_972_.Size = UDim2.new(1, 0, 0, 48)
	L_969_ = L_971_
	L_970_ = upvalue_6:MakeDraggable(L_968_, L_959_)
	L_971_ = upvalue_6.MakeDraggable
	L_973_ = Instance.new("Frame")
	for L_1037_forvar0, L_1038_forvar1 in next, L_972_ do
		L_987_ = "Parent"
		L_988_ = (L_1037_forvar0 == "Parent")
		if not (L_1037_forvar0 == "Parent") then
			L_973_[L_1037_forvar0] = L_1038_forvar1
		end
	end
	L_973_.Parent = L_972_.Parent
	L_972_ = {}
	L_972_.Parent = L_973_
	L_972_.BackgroundTransparency = 1
	L_972_.Position = UDim2.new(0, 16, 0, 0)
	L_972_.Size = UDim2.new(0, 180, 1, 0)
	L_972_.Font = "GothamBold"
	L_971_ = L_973_
	L_973_ = L_955_arg1
	L_974_ = 0
	L_975_ = 180
	L_976_ = 1
	L_977_ = 0
	if not (L_955_arg1) then
		L_973_ = "Snowy Studios"
	end
	L_972_.Text = L_973_
	L_972_.TextColor3 = Color3.new(1, 1, 1)
	L_972_.TextSize = 18
	L_972_.TextXAlignment = "Left"
	L_973_ = Instance.new("TextLabel")
	for L_1039_forvar0, L_1040_forvar1 in next, L_972_ do
		L_987_ = "Parent"
		L_988_ = (L_1039_forvar0 == "Parent")
		if not (L_1039_forvar0 == "Parent") then
			L_973_[L_1039_forvar0] = L_1040_forvar1
		end
	end
	L_973_.Parent = L_972_.Parent
	L_973_ = {}
	L_973_.Name = "CloseBtn"
	L_973_.Parent = L_971_
	L_973_.AnchorPoint = Vector2.new(1, 0.5)
	L_973_.BackgroundTransparency = 1
	L_973_.Position = UDim2.new(1, -12, 0.5, 0)
	L_973_.Size = UDim2.new(0, 24, 0, 24)
	L_973_.Font = "GothamBold"
	L_973_.Text = "X"
	L_973_.TextColor3 = Color3.new(1, 1, 1)
	L_973_.TextSize = 13
	L_973_.AutoButtonColor = false
	L_973_.ZIndex = 12
	L_974_ = Instance.new("TextButton")
	for L_1041_forvar0, L_1042_forvar1 in next, L_973_ do
		L_987_ = "Parent"
		L_988_ = (L_1041_forvar0 == "Parent")
		if not (L_1041_forvar0 == "Parent") then
			L_974_[L_1041_forvar0] = L_1042_forvar1
		end
	end
	L_974_.Parent = L_973_.Parent
	L_974_.Activated:Connect(L_1_.Name)
	L_974_ = {}
	L_974_.Name = "MinBtn"
	L_974_.Parent = L_971_
	L_974_.AnchorPoint = Vector2.new(1, 0.5)
	L_974_.BackgroundTransparency = 1
	L_974_.Position = UDim2.new(1, -42, 0.5, 0)
	L_974_.Size = UDim2.new(0, 24, 0, 24)
	L_974_.Font = "GothamBold"
	L_974_.Text = "\u{2013}"
	L_974_.TextColor3 = Color3.new(1, 1, 1)
	L_974_.TextSize = 22
	L_974_.AutoButtonColor = false
	L_974_.ZIndex = 12
	L_972_ = L_974_
	L_973_ = L_974_.Activated.Connect
	L_975_ = Instance.new("TextButton")
	for L_1043_forvar0, L_1044_forvar1 in next, L_974_ do
		L_987_ = "Parent"
		L_988_ = (L_1043_forvar0 == "Parent")
		if not (L_1043_forvar0 == "Parent") then
			L_975_[L_1043_forvar0] = L_1044_forvar1
		end
	end
	L_975_.Parent = L_974_.Parent
	L_975_.MouseEnter:Connect(L_1_.callback_83)
	L_975_.MouseLeave:Connect(L_1_.callback_84)
	L_972_.MouseEnter:Connect(L_1_.callback_85)
	L_972_.MouseLeave:Connect(L_1_.BackgroundTransparency)
	L_975_ = {}
	L_975_.Parent = L_971_
	L_975_.BackgroundTransparency = 1
	L_975_.Position = UDim2.new(0, 200, 0, 0)
	L_975_.Size = UDim2.new(1, -240, 1, 0)
	L_973_ = L_975_
	L_974_ = L_972_.MouseLeave.Connect
	L_976_ = Instance.new("Frame")
	for L_1045_forvar0, L_1046_forvar1 in next, L_975_ do
		L_987_ = "Parent"
		L_988_ = (L_1045_forvar0 == "Parent")
		if not (L_1045_forvar0 == "Parent") then
			L_976_[L_1045_forvar0] = L_1046_forvar1
		end
	end
	L_976_.Parent = L_975_.Parent
	L_975_ = {}
	L_975_.Parent = L_976_
	L_975_.FillDirection = "Horizontal"
	L_975_.Padding = UDim.new(0, 18)
	L_975_.VerticalAlignment = "Center"
	L_974_ = L_976_
	L_976_ = Instance.new("UIListLayout")
	for L_1047_forvar0, L_1048_forvar1 in next, L_975_ do
		L_987_ = "Parent"
		L_988_ = (L_1047_forvar0 == "Parent")
		if not (L_1047_forvar0 == "Parent") then
			L_976_[L_1047_forvar0] = L_1048_forvar1
		end
	end
	L_976_.Parent = L_975_.Parent
	L_975_ = {}
	L_975_.Parent = L_971_
	L_975_.BackgroundColor3 = upvalue_3.Border
	L_975_.BorderSizePixel = 0
	L_975_.Position = UDim2.new(0, 0, 1, -1)
	L_975_.Size = UDim2.new(1, 0, 0, 1)
	L_976_ = Instance.new("Frame")
	for L_1049_forvar0, L_1050_forvar1 in next, L_975_ do
		L_987_ = "Parent"
		L_988_ = (L_1049_forvar0 == "Parent")
		if not (L_1049_forvar0 == "Parent") then
			L_976_[L_1049_forvar0] = L_1050_forvar1
		end
	end
	L_976_.Parent = L_975_.Parent
	L_976_ = {}
	L_976_.Name = "MainFolder"
	L_976_.Parent = L_967_
	L_976_.BackgroundTransparency = 1
	L_977_ = UDim2.new
	L_978_ = 0
	L_979_ = 0
	L_980_ = 0
	L_982_ = upvalue_7
	if not upvalue_7 then
		L_981_ = 48
	else
		L_981_ = 92
	end
	L_976_.Position = L_977_(L_978_, L_979_, L_980_, L_981_)
	L_977_ = UDim2.new
	L_978_ = 1
	L_979_ = 0
	L_980_ = 1
	L_982_ = upvalue_7
	if not upvalue_7 then
		L_981_ = -48
	else
		L_981_ = -92
	end
	L_976_.Size = L_977_(L_978_, L_979_, L_980_, L_981_)
	L_977_ = Instance.new("Frame")
	for L_1051_forvar0, L_1052_forvar1 in next, L_976_ do
		L_987_ = "Parent"
		L_988_ = (L_1051_forvar0 == "Parent")
		if not (L_1051_forvar0 == "Parent") then
			L_977_[L_1051_forvar0] = L_1052_forvar1
		end
	end
	L_977_.Parent = L_976_.Parent
	L_975_ = L_977_
	L_976_ = upvalue_8.TouchEnabled
	L_977_ = upvalue_8
	L_978_ = L_976_.Parent
	if upvalue_8.TouchEnabled then
		L_977_ = {}
		L_977_.Name = "MobileToggle"
		L_977_.Parent = L_957_
		L_977_.BackgroundColor3 = upvalue_3.BgSecondary
		L_977_.Position = UDim2.new(1, -60, 1, -60)
		L_977_.Size = UDim2.new(0, 44, 0, 44)
		L_977_.Image = ""
		L_977_.AutoButtonColor = false
		L_977_.ZIndex = 100
		L_978_ = Instance.new("ImageButton")
		for L_1053_forvar0, L_1054_forvar1 in next, L_977_ do
			L_987_ = "Parent"
			L_988_ = (L_1053_forvar0 == "Parent")
			if not (L_1053_forvar0 == "Parent") then
				L_978_[L_1053_forvar0] = L_1054_forvar1
			end
		end
		L_978_.Parent = L_977_.Parent
		L_977_ = {}
		L_977_.CornerRadius = UDim.new(0, 10)
		L_977_.Parent = L_978_
		L_976_ = L_978_
		L_978_ = Instance.new("UICorner")
		for L_1055_forvar0, L_1056_forvar1 in next, L_977_ do
			L_987_ = "Parent"
			L_988_ = (L_1055_forvar0 == "Parent")
			if not (L_1055_forvar0 == "Parent") then
				L_978_[L_1055_forvar0] = L_1056_forvar1
			end
		end
		L_978_.Parent = L_977_.Parent
		L_977_ = {}
		L_977_.Color = upvalue_6.Accent
		L_977_.Thickness = 2
		L_977_.Parent = L_976_
		L_978_ = Instance.new("UIStroke")
		for L_1057_forvar0, L_1058_forvar1 in next, L_977_ do
			L_987_ = "Parent"
			L_988_ = (L_1057_forvar0 == "Parent")
			if not (L_1057_forvar0 == "Parent") then
				L_978_[L_1057_forvar0] = L_1058_forvar1
			end
		end
		L_978_.Parent = L_977_.Parent
		L_977_ = {}
		L_977_.Parent = L_976_
		L_977_.BackgroundTransparency = 1
		L_977_.Position = UDim2.new(0.5, -14, 0.5, -14)
		L_977_.Size = UDim2.new(0, 28, 0, 28)
		L_977_.Image = "rbxassetid://123802801726537"
		L_977_.ScaleType = Enum.ScaleType.Fit
		L_977_.ZIndex = 101
		L_978_ = Instance.new("ImageLabel")
		for L_1059_forvar0, L_1060_forvar1 in next, L_977_ do
			L_987_ = "Parent"
			L_988_ = (L_1059_forvar0 == "Parent")
			if not (L_1059_forvar0 == "Parent") then
				L_978_[L_1059_forvar0] = L_1060_forvar1
			end
		end
		L_978_.Parent = L_977_.Parent
		L_976_.InputEnded:Connect(L_1_.callback_87)
		L_977_ = upvalue_6:MakeDraggable(L_976_)
		L_978_ = L_976_.InputEnded.Connect
		L_979_ = L_976_.InputEnded
		L_980_ = L_1_.callback_87
	end
	upvalue_8.InputBegan:Connect(L_1_.Name_88)
	L_977_ = {}
	L_977_.Name = "SnowyMarketBubble"
	L_977_.Parent = L_957_
	L_977_.AnchorPoint = Vector2.new(0, 0)
	L_977_.Position = UDim2.new(0, 30, 0, 30)
	L_977_.Size = UDim2.new(0, 0, 0, 0)
	L_977_.BackgroundColor3 = upvalue_3.BgCard
	L_977_.BorderSizePixel = 0
	L_977_.AutoButtonColor = false
	L_977_.Image = ""
	L_977_.Visible = false
	L_977_.ZIndex = 200
	L_976_ = upvalue_8.InputBegan.Connect
	L_978_ = Instance.new("ImageButton")
	for L_1061_forvar0, L_1062_forvar1 in next, L_977_ do
		L_987_ = "Parent"
		L_988_ = (L_1061_forvar0 == "Parent")
		if not (L_1061_forvar0 == "Parent") then
			L_978_[L_1061_forvar0] = L_1062_forvar1
		end
	end
	L_978_.Parent = L_977_.Parent
	L_977_ = {}
	L_977_.CornerRadius = UDim.new(1, 0)
	L_977_.Parent = L_978_
	L_976_ = L_978_
	L_978_ = Instance.new("UICorner")
	for L_1063_forvar0, L_1064_forvar1 in next, L_977_ do
		L_987_ = "Parent"
		L_988_ = (L_1063_forvar0 == "Parent")
		if not (L_1063_forvar0 == "Parent") then
			L_978_[L_1063_forvar0] = L_1064_forvar1
		end
	end
	L_978_.Parent = L_977_.Parent
	L_977_ = {}
	L_977_.Color = upvalue_3.Accent
	L_977_.Thickness = 2
	L_977_.Parent = L_976_
	L_978_ = Instance.new("UIStroke")
	for L_1065_forvar0, L_1066_forvar1 in next, L_977_ do
		L_987_ = "Parent"
		L_988_ = (L_1065_forvar0 == "Parent")
		if not (L_1065_forvar0 == "Parent") then
			L_978_[L_1065_forvar0] = L_1066_forvar1
		end
	end
	L_978_.Parent = L_977_.Parent
	L_977_ = {}
	L_977_.Color = ColorSequence.new(upvalue_3.BgSecondary, upvalue_3.BgCard)
	L_977_.Rotation = 125
	L_977_.Parent = L_976_
	L_978_ = Instance.new("UIGradient")
	for L_1067_forvar0, L_1068_forvar1 in next, L_977_ do
		L_987_ = "Parent"
		L_988_ = (L_1067_forvar0 == "Parent")
		if not (L_1067_forvar0 == "Parent") then
			L_978_[L_1067_forvar0] = L_1068_forvar1
		end
	end
	L_978_.Parent = L_977_.Parent
	L_978_ = {}
	L_978_.Parent = L_976_
	L_978_.BackgroundTransparency = 1
	L_978_.Position = UDim2.new(0, -15, 0, -15)
	L_978_.Size = UDim2.new(1, 30, 1, 30)
	L_978_.Image = "rbxassetid://6015667320"
	L_978_.ImageColor3 = upvalue_3.Accent
	L_978_.ImageTransparency = 0.55
	L_978_.ScaleType = Enum.ScaleType.Slice
	L_978_.SliceCenter = Rect.new(49, 49, 450, 450)
	L_978_.ZIndex = 199
	L_979_ = Instance.new("ImageLabel")
	for L_1069_forvar0, L_1070_forvar1 in next, L_978_ do
		L_987_ = "Parent"
		L_988_ = (L_1069_forvar0 == "Parent")
		if not (L_1069_forvar0 == "Parent") then
			L_979_[L_1069_forvar0] = L_1070_forvar1
		end
	end
	L_979_.Parent = L_978_.Parent
	L_979_ = {}
	L_979_.Parent = L_976_
	L_979_.BackgroundTransparency = 1
	L_979_.AnchorPoint = Vector2.new(0.5, 0.5)
	L_979_.Position = UDim2.new(0, 26, 0.5, 0)
	L_979_.Size = UDim2.new(0, 30, 0, 30)
	L_979_.Image = "rbxassetid://123802801726537"
	L_979_.ScaleType = Enum.ScaleType.Fit
	L_979_.ZIndex = 201
	L_977_ = L_979_
	L_980_ = Instance.new("ImageLabel")
	for L_1071_forvar0, L_1072_forvar1 in next, L_979_ do
		L_987_ = "Parent"
		L_988_ = (L_1071_forvar0 == "Parent")
		if not (L_1071_forvar0 == "Parent") then
			L_980_[L_1071_forvar0] = L_1072_forvar1
		end
	end
	L_980_.Parent = L_979_.Parent
	L_980_ = {}
	L_980_.Parent = L_976_
	L_980_.BackgroundTransparency = 1
	L_980_.Position = UDim2.new(0, 52, 0, 0)
	L_980_.Size = UDim2.new(1, -64, 1, 0)
	L_980_.Font = Enum.Font.GothamBlack
	L_980_.Text = "Snowy Studios"
	L_980_.TextColor3 = Color3.new(1, 1, 1)
	L_980_.TextSize = 15
	L_980_.TextXAlignment = Enum.TextXAlignment.Left
	L_980_.ZIndex = 201
	L_978_ = L_980_
	L_981_ = Instance.new("TextLabel")
	for L_1073_forvar0, L_1074_forvar1 in next, L_980_ do
		L_987_ = "Parent"
		L_988_ = (L_1073_forvar0 == "Parent")
		if not (L_1073_forvar0 == "Parent") then
			L_981_[L_1073_forvar0] = L_1074_forvar1
		end
	end
	L_981_.Parent = L_980_.Parent
	L_980_ = {}
	L_980_.Color = ColorSequence.new(upvalue_3.AccentGlow, upvalue_3.AccentBright)
	L_980_.Parent = L_981_
	L_979_ = L_981_
	L_981_ = Instance.new("UIGradient")
	for L_1075_forvar0, L_1076_forvar1 in next, L_980_ do
		L_987_ = "Parent"
		L_988_ = (L_1075_forvar0 == "Parent")
		if not (L_1075_forvar0 == "Parent") then
			L_981_[L_1075_forvar0] = L_1076_forvar1
		end
	end
	L_981_.Parent = L_980_.Parent
	upvalue_6:MakeDraggable(L_976_)
	task.spawn(L_1_.callback_90)
	L_973_.Activated:Connect(L_1_.callback_94)
	L_976_.Activated:Connect(L_1_.callback_93)
	L_983_ = {}
	L_983_.Current = nil
	L_983_.MainContainer = L_967_
	L_983_.CreateTab = L_1_.CreateTab

	return L_983_
end

L_1_.callback_127 = function()
	local L_1077_, L_1078_, L_1079_, L_1080_, L_1081_, L_1082_, L_1083_, L_1084_, L_1085_, L_1086_, L_1087_, L_1088_, L_1089_, L_1090_
	L_1083_ = {}
	L_1083_.Toggled = true
	L_1083_.Accent = Color3.fromRGB(0, 162, 255)
	L_1083_._blockDrag = false
	L_1085_ = {}
	L_1085_[1] = 16898613509
	L_1085_[2] = 48
	L_1085_[3] = 48
	L_1085_[4] = 820
	L_1085_[5] = 147
	L_1084_ = {}
	L_1084_.home = L_1085_
	L_1085_ = {}
	L_1085_[1] = 16898613353
	L_1085_[2] = 48
	L_1085_[3] = 48
	L_1085_[4] = 967
	L_1085_[5] = 306
	L_1084_.flame = L_1085_
	L_1085_ = {}
	L_1085_[1] = 16898613777
	L_1085_[2] = 48
	L_1085_[3] = 48
	L_1085_[4] = 771
	L_1085_[5] = 257
	L_1084_.settings = L_1085_
	L_1085_ = {}
	L_1085_[1] = 16898613869
	L_1085_[2] = 48
	L_1085_[3] = 48
	L_1085_[4] = 661
	L_1085_[5] = 869
	L_1084_.account = L_1085_
	L_1085_ = {}
	L_1085_[1] = 16898613353
	L_1085_[2] = 48
	L_1085_[3] = 48
	L_1085_[4] = 771
	L_1085_[5] = 563
	L_1084_.eye = L_1085_
	L_1085_ = {}
	L_1085_[1] = 16898613613
	L_1085_[2] = 48
	L_1085_[3] = 48
	L_1085_[4] = 820
	L_1085_[5] = 257
	L_1084_["map-pin"] = L_1085_
	L_1085_ = {}
	L_1085_[1] = 16898612629
	L_1085_[2] = 48
	L_1085_[3] = 48
	L_1085_[4] = 967
	L_1085_[5] = 710
	L_1084_["bar-chart-2"] = L_1085_
	L_1085_ = {}
	L_1085_[1] = 16898613777
	L_1085_[2] = 48
	L_1085_[3] = 48
	L_1085_[4] = 967
	L_1085_[5] = 759
	L_1084_.swords = L_1085_
	L_1085_ = {}
	L_1085_[1] = 16898613869
	L_1085_[2] = 48
	L_1085_[3] = 48
	L_1085_[4] = 661
	L_1085_[5] = 869
	L_1084_.user = L_1085_
	L_1085_ = {}
	L_1085_[1] = 16898613777
	L_1085_[2] = 48
	L_1085_[3] = 48
	L_1085_[4] = 869
	L_1085_[5] = 0
	L_1084_.shield = L_1085_
	L_1085_ = {}
	L_1085_[1] = 16898613869
	L_1085_[2] = 48
	L_1085_[3] = 48
	L_1085_[4] = 918
	L_1085_[5] = 906
	L_1084_.zap = L_1085_
	L_1085_ = {}
	L_1085_[1] = 16898613869
	L_1085_[2] = 48
	L_1085_[3] = 48
	L_1085_[4] = 514
	L_1085_[5] = 771
	L_1084_.target = L_1085_
	L_1085_ = {}
	L_1085_[1] = 16898613509
	L_1085_[2] = 48
	L_1085_[3] = 48
	L_1085_[4] = 771
	L_1085_[5] = 563
	L_1084_.globe = L_1085_
	L_1085_ = {}
	L_1085_[1] = 16898613509
	L_1085_[2] = 48
	L_1085_[3] = 48
	L_1085_[4] = 967
	L_1085_[5] = 612
	L_1084_.layout = L_1085_
	L_1085_ = {}
	L_1085_[1] = 16898613699
	L_1085_[2] = 48
	L_1085_[3] = 48
	L_1085_[4] = 918
	L_1085_[5] = 857
	L_1084_.search = L_1085_
	L_1085_ = {}
	L_1085_[1] = 16898613699
	L_1085_[2] = 48
	L_1085_[3] = 48
	L_1085_[4] = 918
	L_1085_[5] = 453
	L_1084_.save = L_1085_
	L_1085_ = {}
	L_1085_[1] = 16898613777
	L_1085_[2] = 48
	L_1085_[3] = 48
	L_1085_[4] = 404
	L_1085_[5] = 771
	L_1084_.sliders = L_1085_
	L_1083_.MakeDraggable = L_1_.MakeDraggable
	L_1083_.GetIcon = L_1_.GetIcon
	L_1083_.CreateWindow = L_1_.CreateWindow
	return L_1083_
end

L_1_.callback_128 = function(L_1091_arg0, L_1092_arg1, L_1093_arg2)
	local L_1094_, L_1095_, L_1096_, L_1097_, L_1098_, L_1099_, L_1100_, L_1101_
	L_1094_ = nil
	L_1095_ = nil
	L_1096_ = nil
	L_1097_ = type(L_1091_arg0)
	L_1098_ = L_1091_arg0
	L_1100_ = "table"
	L_1101_ = (type(L_1091_arg0) == "table")
	if not (type(L_1091_arg0) == "table") then
		L_1094_ = L_1092_arg1
		L_1095_ = nil
		L_1096_ = L_1093_arg2
	else
		L_1094_ = L_1091_arg0
		L_1098_ = type(L_1092_arg1)
		L_1099_ = L_1092_arg1
		L_1100_ = "string"
		L_1101_ = (type(L_1092_arg1) == "string")
		if not (type(L_1092_arg1) == "string") then
			L_1097_ = nil
		else
			L_1097_ = L_1092_arg1
			if not (L_1092_arg1) then
				L_1097_ = nil
			end
		end
		L_1095_ = L_1097_
		L_1098_ = type(L_1092_arg1)
		L_1099_ = L_1092_arg1
		L_1100_ = "function"
		L_1101_ = (type(L_1092_arg1) == "function")
		if not (type(L_1092_arg1) == "function") then
			L_1097_ = L_1093_arg2
		else
			L_1097_ = L_1092_arg1
			if not (L_1092_arg1) then
				L_1097_ = L_1093_arg2
			end
		end
		L_1096_ = L_1097_
	end
	L_1097_ = L_1094_
	if L_1094_ then
		return L_1097_, L_1095_, L_1096_
	end
	L_1097_ = {}
	return L_1097_, L_1095_, L_1096_
end

L_1_.NewToggle = function(L_1102_arg0, L_1103_arg1, L_1104_arg2, L_1105_arg3)
	local L_1106_, L_1107_, L_1108_, L_1109_, L_1110_
	L_1106_ = upvalue_0.CreateToggle
	L_1107_ = upvalue_0
	L_1108_ = L_1103_arg1
	L_1109_ = false
	L_1110_ = L_1105_arg3
	return upvalue_0:CreateToggle(L_1103_arg1, false, L_1105_arg3)
end

L_1_.NewSlider = function(L_1111_arg0, L_1112_arg1, L_1113_arg2, L_1114_arg3, L_1115_arg4, L_1116_arg5)
	local L_1117_, L_1118_, L_1119_, L_1120_, L_1121_, L_1122_, L_1123_
	L_1117_ = upvalue_0.CreateSlider
	L_1118_ = upvalue_0
	L_1119_ = L_1112_arg1
	L_1120_ = L_1115_arg4
	L_1121_ = L_1114_arg3
	L_1122_ = L_1115_arg4
	L_1123_ = L_1116_arg5
	return upvalue_0:CreateSlider(L_1112_arg1, L_1115_arg4, L_1114_arg3, L_1115_arg4, L_1116_arg5)
end

L_1_.NewButton = function(L_1124_arg0, L_1125_arg1, L_1126_arg2, L_1127_arg3)
	local L_1128_, L_1129_, L_1130_, L_1131_
	L_1128_ = upvalue_0.CreateButton
	L_1129_ = upvalue_0
	L_1130_ = L_1125_arg1
	L_1131_ = L_1127_arg3
	return upvalue_0:CreateButton(L_1125_arg1, L_1127_arg3)
end

L_1_.NewDropdown = function(L_1132_arg0, L_1133_arg1, L_1134_arg2, L_1135_arg3, L_1136_arg4)
	local L_1137_, L_1138_, L_1139_, L_1140_, L_1141_, L_1142_, L_1143_, L_1144_, L_1145_
	L_1137_ = upvalue_0
	L_1138_ = L_1134_arg2
	L_1139_ = L_1135_arg3
	L_1140_ = L_1136_arg4
	L_1137_, L_1138_, L_1139_ = upvalue_0(L_1134_arg2, L_1135_arg3, L_1136_arg4)
	L_1140_ = upvalue_1.CreateDropdown
	L_1141_ = upvalue_1
	L_1142_ = L_1133_arg1
	L_1143_ = L_1137_
	L_1144_ = L_1138_
	L_1145_ = L_1139_
	return upvalue_1:CreateDropdown(L_1133_arg1, L_1137_, L_1138_, L_1139_)
end

L_1_.NewLabel = function(L_1146_arg0, L_1147_arg1)
	local L_1148_, L_1149_, L_1150_
	L_1148_ = upvalue_0.CreateLabel
	L_1149_ = upvalue_0
	L_1150_ = L_1147_arg1
	return upvalue_0:CreateLabel(L_1147_arg1)
end

L_1_.NewInput = function(L_1151_arg0, L_1152_arg1, L_1153_arg2, L_1154_arg3)
	local L_1155_, L_1156_, L_1157_, L_1158_, L_1159_
	L_1155_ = upvalue_0.CreateInput
	L_1156_ = upvalue_0
	L_1157_ = L_1152_arg1
	L_1158_ = L_1153_arg2
	L_1159_ = L_1154_arg3
	return upvalue_0:CreateInput(L_1152_arg1, L_1153_arg2, L_1154_arg3)
end

L_1_.NewTitle = function(L_1160_arg0, L_1161_arg1)
	local L_1162_, L_1163_, L_1164_, L_1165_, L_1166_
	L_1162_ = upvalue_0.CreateLabel
	L_1163_ = upvalue_0
	L_1164_ = "\u{2726} " .. L_1161_arg1
	L_1165_ = "\u{2726} "
	L_1166_ = L_1161_arg1
	return upvalue_0:CreateLabel("\u{2726} " .. L_1161_arg1)
end

L_1_.NewSection = function(L_1167_arg0)
	local L_1168_
	return upvalue_0
end

L_1_.callback_137 = function()
	local L_1169_, L_1170_, L_1171_
	upvalue_0:Set(false)
	return
end

L_1_.callback_138 = function()
	local L_1172_, L_1173_
	pcall(L_1_.callback_137)
	task.wait()
	upvalue_1 = false
	return
end

L_1_.callback_139 = function(L_1174_arg0)
	local L_1175_, L_1176_
	L_1175_ = upvalue_0
	if upvalue_0 then
		return
	end
	L_1175_ = _isPremiumUser()
	if not _isPremiumUser() then
		if not L_1174_arg0 then
			return
		end
		upvalue_2(upvalue_3)
		upvalue_0 = true
		task.defer(L_1_.callback_138)
		L_1175_ = task.defer
		L_1176_ = L_1_.callback_138
		return
	else
		L_1175_ = upvalue_1
		if not upvalue_1 then
			return
		else
			upvalue_1(L_1174_arg0)
			return
		end
	end
end

L_1_.NewPremiumToggle = function(L_1177_arg0, L_1178_arg1, L_1179_arg2, L_1180_arg3)
	local L_1181_, L_1182_, L_1183_, L_1184_, L_1185_, L_1186_, L_1187_

	return upvalue_0:CreateToggle(_premTag(L_1178_arg1), false, L_1_.callback_139)
end

L_1_.callback_141 = function()
	local L_1188_, L_1189_
	L_1188_ = _isPremiumUser()
	if not _isPremiumUser() then
		upvalue_1(upvalue_2)
		L_1188_ = upvalue_1
		L_1189_ = upvalue_2
		return
	else
		L_1188_ = upvalue_0
		if not upvalue_0 then
			return
		else
			upvalue_0()
			return
		end
	end
end

L_1_.NewPremiumButton = function(L_1190_arg0, L_1191_arg1, L_1192_arg2, L_1193_arg3)
	local L_1194_, L_1195_, L_1196_, L_1197_
	L_1194_ = upvalue_0.CreateButton
	L_1195_ = upvalue_0
	L_1196_ = _premTag(L_1191_arg1)
	L_1197_ = L_1_.callback_141
	return upvalue_0:CreateButton(_premTag(L_1191_arg1), L_1_.callback_141)
end

L_1_.callback_143 = function(L_1198_arg0)
	local L_1199_, L_1200_
	L_1199_ = _isPremiumUser()
	if not _isPremiumUser() then
		upvalue_1(upvalue_2)
		L_1199_ = upvalue_1
		L_1200_ = upvalue_2
		return
	else
		L_1199_ = upvalue_0
		if not upvalue_0 then
			return
		else
			upvalue_0(L_1198_arg0)
			return
		end
	end
end

L_1_.NewPremiumSlider = function(L_1201_arg0, L_1202_arg1, L_1203_arg2, L_1204_arg3, L_1205_arg4, L_1206_arg5)
	local L_1207_, L_1208_, L_1209_, L_1210_, L_1211_, L_1212_, L_1213_
	L_1207_ = upvalue_0
	L_1209_ = _premTag(L_1202_arg1)
	L_1210_ = L_1205_arg4
	if not (L_1205_arg4) then
		L_1210_ = 0
	end
	L_1211_ = L_1204_arg3
	if not (L_1204_arg3) then
		L_1211_ = 100
	end
	L_1212_ = L_1205_arg4
	if L_1205_arg4 then
		L_1207_ = L_1207_.CreateSlider
		L_1208_ = L_1207_
		L_1213_ = L_1_.callback_143
		return L_1207_:CreateSlider(L_1209_, L_1210_, L_1211_, L_1212_, L_1_.callback_143)
	end
	L_1212_ = 0
	L_1207_ = L_1207_.CreateSlider
	L_1208_ = L_1207_
	L_1213_ = L_1_.callback_143
	return L_1207_:CreateSlider(L_1209_, L_1210_, L_1211_, L_1212_, L_1_.callback_143)
end

L_1_.callback_145 = function(L_1214_arg0)
	local L_1215_, L_1216_
	L_1215_ = _isPremiumUser()
	if not _isPremiumUser() then
		upvalue_1(upvalue_2)
		L_1215_ = upvalue_1
		L_1216_ = upvalue_2
		return
	else
		L_1215_ = upvalue_0
		if not upvalue_0 then
			return
		else
			upvalue_0(L_1214_arg0)
			return
		end
	end
end

L_1_.NewPremiumDropdown = function(L_1217_arg0, L_1218_arg1, L_1219_arg2, L_1220_arg3, L_1221_arg4)
	local L_1222_, L_1223_, L_1224_, L_1225_, L_1226_, L_1227_, L_1228_, L_1229_, L_1230_
	L_1222_ = upvalue_0
	L_1223_ = L_1219_arg2
	L_1224_ = L_1220_arg3
	L_1225_ = L_1221_arg4
	L_1222_, L_1223_, L_1224_ = upvalue_0(L_1219_arg2, L_1220_arg3, L_1221_arg4)
	L_1225_ = upvalue_1.CreateDropdown
	L_1226_ = upvalue_1
	L_1227_ = _premTag(L_1218_arg1)
	L_1228_ = L_1222_
	L_1229_ = L_1223_
	L_1230_ = L_1_.callback_145
	return upvalue_1:CreateDropdown(_premTag(L_1218_arg1), L_1222_, L_1223_, L_1_.callback_145)
end

L_1_.NewSection_147 = function(L_1231_arg0, L_1232_arg1)
	local L_1233_, L_1234_, L_1235_, L_1236_, L_1237_, L_1238_, L_1239_
	L_1233_ = "layout"
	L_1234_ = L_1232_arg1
	if not (L_1232_arg1) then
		L_1234_ = ""
	end
	L_1234_ = L_1234_:lower()
	L_1235_ = L_1234_:find("combat", 1, true)
	L_1236_ = L_1234_
	L_1237_ = "combat"
	L_1238_ = 1
	L_1239_ = true
	if not L_1234_:find("combat", 1, true) then
		L_1235_ = L_1234_:find("visual", 1, true)
		L_1236_ = L_1234_
		L_1237_ = "visual"
		L_1238_ = 1
		L_1239_ = true
		if not L_1234_:find("visual", 1, true) then
			L_1235_ = L_1234_:find("main", 1, true)
			L_1236_ = L_1234_
			L_1237_ = "main"
			L_1238_ = 1
			L_1239_ = true
			if L_1234_:find("main", 1, true) then
				L_1233_ = "home"
			else
				L_1235_ = L_1234_:find("home", 1, true)
				L_1236_ = L_1234_
				L_1237_ = "home"
				L_1238_ = 1
				L_1239_ = true
				if not L_1234_:find("home", 1, true) then
					L_1235_ = L_1234_:find("setting", 1, true)
					L_1236_ = L_1234_
					L_1237_ = "setting"
					L_1238_ = 1
					L_1239_ = true
					if L_1234_:find("setting", 1, true) then
						L_1233_ = "settings"
					else
						L_1235_ = L_1234_:find("config", 1, true)
						L_1236_ = L_1234_
						L_1237_ = "config"
						L_1238_ = 1
						L_1239_ = true
						if L_1234_:find("config", 1, true) then
							L_1233_ = "settings"
						end
					end
				else
					L_1233_ = "home"
				end
			end
		else
			L_1233_ = "eye"
		end
	else
		L_1233_ = "swords"
	end
	L_1235_ = L_1231_arg0.ActualTab
	L_1237_ = L_1232_arg1
	if not (L_1232_arg1) then
		L_1237_ = "Main"
	end
	L_1235_ = L_1235_:CreateSubTab(L_1237_, L_1233_)
	L_1236_ = L_1235_
	L_1238_ = L_1232_arg1
	if L_1232_arg1 then
		L_1237_ = {}
		L_1237_.NewToggle = L_1_.NewToggle
		L_1237_.NewSlider = L_1_.NewSlider
		L_1237_.NewButton = L_1_.NewButton
		L_1237_.NewDropdown = L_1_.NewDropdown
		L_1237_.NewLabel = L_1_.NewLabel
		L_1237_.NewInput = L_1_.NewInput
		L_1237_.NewTitle = L_1_.NewTitle
		L_1237_.NewSection = L_1_.NewSection
		L_1237_.NewPremiumToggle = L_1_.NewPremiumToggle
		L_1237_.NewPremiumButton = L_1_.NewPremiumButton
		L_1237_.NewPremiumSlider = L_1_.NewPremiumSlider
		L_1237_.NewPremiumDropdown = L_1_.NewPremiumDropdown
		return L_1237_
	end
	L_1238_ = "Main"
	L_1237_ = {}
	L_1237_.NewToggle = L_1_.NewToggle
	L_1237_.NewSlider = L_1_.NewSlider
	L_1237_.NewButton = L_1_.NewButton
	L_1237_.NewDropdown = L_1_.NewDropdown
	L_1237_.NewLabel = L_1_.NewLabel
	L_1237_.NewInput = L_1_.NewInput
	L_1237_.NewTitle = L_1_.NewTitle
	L_1237_.NewSection = L_1_.NewSection
	L_1237_.NewPremiumToggle = L_1_.NewPremiumToggle
	L_1237_.NewPremiumButton = L_1_.NewPremiumButton
	L_1237_.NewPremiumSlider = L_1_.NewPremiumSlider
	L_1237_.NewPremiumDropdown = L_1_.NewPremiumDropdown
	return L_1237_
end

L_1_.HideTabButton = function(L_1240_arg0)
	local L_1241_, L_1242_, L_1243_
	L_1240_arg0.ActualTab:SetVisible(false)
	return
end

L_1_.Select_149 = function(L_1244_arg0)
	local L_1245_, L_1246_
	L_1244_arg0.ActualTab:Select()
	return
end

L_1_.NewTab = function(L_1247_arg0, L_1248_arg1)
	local L_1249_, L_1250_, L_1251_, L_1252_, L_1253_, L_1254_, L_1255_
	L_1250_ = L_1248_arg1:lower()
	L_1249_ = "home"
	L_1251_ = L_1250_:find("aim", 1, true)
	L_1252_ = L_1250_
	L_1253_ = "aim"
	L_1254_ = 1
	L_1255_ = true
	if L_1250_:find("aim", 1, true) then
		L_1249_ = "target"
	else
		L_1251_ = L_1250_:find("combat", 1, true)
		L_1252_ = L_1250_
		L_1253_ = "combat"
		L_1254_ = 1
		L_1255_ = true
		if L_1250_:find("combat", 1, true) then
			L_1249_ = "target"
		else
			L_1251_ = L_1250_:find("kill", 1, true)
			L_1252_ = L_1250_
			L_1253_ = "kill"
			L_1254_ = 1
			L_1255_ = true
			if L_1250_:find("kill", 1, true) then
				L_1249_ = "target"
			else
				L_1251_ = L_1250_:find("gun", 1, true)
				L_1252_ = L_1250_
				L_1253_ = "gun"
				L_1254_ = 1
				L_1255_ = true
				if not L_1250_:find("gun", 1, true) then
					L_1251_ = L_1250_:find("player", 1, true)
					L_1252_ = L_1250_
					L_1253_ = "player"
					L_1254_ = 1
					L_1255_ = true
					if L_1250_:find("player", 1, true) then
						L_1249_ = "user"
					else
						L_1251_ = L_1250_:find("user", 1, true)
						L_1252_ = L_1250_
						L_1253_ = "user"
						L_1254_ = 1
						L_1255_ = true
						if L_1250_:find("user", 1, true) then
							L_1249_ = "user"
						else
							L_1251_ = L_1250_:find("char", 1, true)
							L_1252_ = L_1250_
							L_1253_ = "char"
							L_1254_ = 1
							L_1255_ = true
							if L_1250_:find("char", 1, true) then
								L_1249_ = "user"
							else
								L_1251_ = L_1250_:find("move", 1, true)
								L_1252_ = L_1250_
								L_1253_ = "move"
								L_1254_ = 1
								L_1255_ = true
								if not L_1250_:find("move", 1, true) then
									L_1251_ = L_1250_:find("visual", 1, true)
									L_1252_ = L_1250_
									L_1253_ = "visual"
									L_1254_ = 1
									L_1255_ = true
									if L_1250_:find("visual", 1, true) then
										L_1249_ = "eye"
									else
										L_1251_ = L_1250_:find("esp", 1, true)
										L_1252_ = L_1250_
										L_1253_ = "esp"
										L_1254_ = 1
										L_1255_ = true
										if L_1250_:find("esp", 1, true) then
											L_1249_ = "eye"
										else
											L_1251_ = L_1250_:find("eye", 1, true)
											L_1252_ = L_1250_
											L_1253_ = "eye"
											L_1254_ = 1
											L_1255_ = true
											if L_1250_:find("eye", 1, true) then
												L_1249_ = "eye"
											else
												L_1251_ = L_1250_:find("render", 1, true)
												L_1252_ = L_1250_
												L_1253_ = "render"
												L_1254_ = 1
												L_1255_ = true
												if not L_1250_:find("render", 1, true) then
													L_1251_ = L_1250_:find("setting", 1, true)
													L_1252_ = L_1250_
													L_1253_ = "setting"
													L_1254_ = 1
													L_1255_ = true
													if L_1250_:find("setting", 1, true) then
														L_1249_ = "settings"
													else
														L_1251_ = L_1250_:find("config", 1, true)
														L_1252_ = L_1250_
														L_1253_ = "config"
														L_1254_ = 1
														L_1255_ = true
														if L_1250_:find("config", 1, true) then
															L_1249_ = "settings"
														else
															L_1251_ = L_1250_:find("ui", 1, true)
															L_1252_ = L_1250_
															L_1253_ = "ui"
															L_1254_ = 1
															L_1255_ = true
															if not L_1250_:find("ui", 1, true) then
																L_1251_ = L_1250_:find("util", 1, true)
																L_1252_ = L_1250_
																L_1253_ = "util"
																L_1254_ = 1
																L_1255_ = true
																if L_1250_:find("util", 1, true) then
																	L_1249_ = "sliders"
																else
																	L_1251_ = L_1250_:find("misc", 1, true)
																	L_1252_ = L_1250_
																	L_1253_ = "misc"
																	L_1254_ = 1
																	L_1255_ = true
																	if L_1250_:find("misc", 1, true) then
																		L_1249_ = "sliders"
																	else
																		L_1251_ = L_1250_:find("tool", 1, true)
																		L_1252_ = L_1250_
																		L_1253_ = "tool"
																		L_1254_ = 1
																		L_1255_ = true
																		if not L_1250_:find("tool", 1, true) then
																			L_1251_ = L_1250_:find("game", 1, true)
																			L_1252_ = L_1250_
																			L_1253_ = "game"
																			L_1254_ = 1
																			L_1255_ = true
																			if L_1250_:find("game", 1, true) then
																				L_1249_ = "layout"
																			else
																				L_1251_ = L_1250_:find("hub", 1, true)
																				L_1252_ = L_1250_
																				L_1253_ = "hub"
																				L_1254_ = 1
																				L_1255_ = true
																				if L_1250_:find("hub", 1, true) then
																					L_1249_ = "layout"
																				else
																					L_1251_ = L_1250_:find("main", 1, true)
																					L_1252_ = L_1250_
																					L_1253_ = "main"
																					L_1254_ = 1
																					L_1255_ = true
																					if not L_1250_:find("main", 1, true) then
																						L_1252_ = {}
																						L_1252_.ActualTab = upvalue_0:CreateTab(L_1248_arg1, L_1249_)
																						L_1252_.NewSection = L_1_.NewSection_147
																						L_1252_.HideTabButton = L_1_.HideTabButton
																						L_1252_.Select = L_1_.Select_149
																						return L_1252_
																					end
																					L_1249_ = "layout"
																				end
																			end
																		else
																			L_1249_ = "sliders"
																		end
																	end
																end
															else
																L_1249_ = "settings"
															end
														end
													end
												else
													L_1249_ = "eye"
												end
											end
										end
									end
								else
									L_1249_ = "user"
								end
							end
						end
					end
				else
					L_1249_ = "target"
				end
			end
		end
	end
	L_1252_ = {}
	L_1252_.ActualTab = upvalue_0:CreateTab(L_1248_arg1, L_1249_)
	L_1252_.NewSection = L_1_.NewSection_147
	L_1252_.HideTabButton = L_1_.HideTabButton
	L_1252_.Select = L_1_.Select_149
	return L_1252_
end

L_1_.CreateLib = function(L_1256_arg0, L_1257_arg1)
	local L_1258_, L_1259_, L_1260_
	L_1259_ = {}
	L_1259_.Tabs = {}
	L_1259_.Window = upvalue_0:CreateWindow(L_1256_arg0)
	L_1259_.NewTab = L_1_.NewTab
	return L_1259_
end

L_1_.callback_152 = function()
	local L_1261_, L_1262_
	return upvalue_0.Character
end

L_1_.callback_153 = function()
	local L_1263_, L_1264_, L_1265_, L_1266_
	L_1263_ = upvalue_0.Character
	L_1264_ = upvalue_0.Character
	if not upvalue_0.Character then
		return L_1264_
	end
	L_1264_ = L_1263_:FindFirstChildWhichIsA("Humanoid")
	L_1265_ = L_1263_
	L_1266_ = "Humanoid"
	return L_1264_
end

L_1_.callback_154 = function()
	local L_1267_, L_1268_, L_1269_, L_1270_
	L_1267_ = upvalue_0.Character
	L_1268_ = upvalue_0.Character
	if not upvalue_0.Character then
		return L_1268_
	end
	L_1268_ = L_1267_:FindFirstChild("HumanoidRootPart")
	L_1269_ = L_1267_
	L_1270_ = "HumanoidRootPart"
	return L_1268_
end

L_1_.callback_155 = function(...)
	local L_1271_ = {
		...
	}
	for L_1272_forvar0, L_1273_forvar1 in pairs(workspace:GetDescendants()) do
		for L_1274_forvar0, L_1275_forvar1 in pairs(L_1271_) do
			if L_1273_forvar1.Name:lower() == L_1275_forvar1:lower()
                and (L_1273_forvar1:IsA("IntValue") or L_1273_forvar1:IsA("NumberValue")) then
				return L_1273_forvar1
			end
		end
	end
	return nil
end

L_1_.callback_156 = function(L_1276_arg0, L_1277_arg1, L_1278_arg2)
	local L_1279_, L_1280_, L_1281_, L_1282_, L_1283_, L_1284_
	upvalue_0:Notify(L_1276_arg0, L_1277_arg1, L_1278_arg2, false)
	return
end

L_1_.callback_157 = function()
	local L_1285_, L_1286_, L_1287_
	L_1285_ = getgenv().__SnowyLoadingOverlay
	L_1286_ = getgenv()
	if not getgenv().__SnowyLoadingOverlay then
		return
	end
	L_1285_:Destroy()
	L_1286_ = getgenv()
	L_1286_.__SnowyLoadingOverlay = nil
	L_1287_ = nil
	return
end

L_1_.gameTab = function()
	local L_1288_, L_1289_
	pcall(L_1_.callback_157)
	return
end

L_1_.NewToggle_159 = function()
	local L_1290_
	return
end

L_1_.NewSection_160 = function()
	local L_1291_
	return upvalue_0
end

L_1_.NewSection_161 = function()
	local L_1292_
	return upvalue_0
end

L_1_.callback_162 = function(L_1293_arg0, L_1294_arg1)
	local L_1295_, L_1296_, L_1297_, L_1298_, L_1299_
	L_1295_ = upvalue_0[L_1293_arg0]
	L_1296_ = upvalue_0
	if upvalue_0[L_1293_arg0] then
		return upvalue_1[L_1293_arg0]
	end
	L_1295_ = upvalue_2.Window
	L_1296_ = upvalue_2
	L_1297_ = L_1293_arg0
	L_1298_ = L_1294_arg1
	if L_1294_arg1 then
		L_1295_ = L_1295_:CreateTab(L_1297_, L_1298_)
		L_1296_ = L_1295_:CreateSubTab("Main", "layout")
		L_1298_ = upvalue_0
		L_1298_[L_1293_arg0] = L_1295_
		L_1298_ = upvalue_1
		L_1298_[L_1293_arg0] = L_1296_:CreateSection("Features")
		return L_1296_:CreateSection("Features")
	end
	L_1298_ = "layout"
	L_1295_ = L_1295_:CreateTab(L_1297_, L_1298_)
	L_1296_ = L_1295_:CreateSubTab("Main", "layout")
	L_1298_ = upvalue_0
	L_1298_[L_1293_arg0] = L_1295_
	L_1298_ = upvalue_1
	L_1298_[L_1293_arg0] = L_1296_:CreateSection("Features")
	return L_1296_:CreateSection("Features")
end

L_1_.NewToggle_163 = function(L_1300_arg0, L_1301_arg1, L_1302_arg2, L_1303_arg3)
	local L_1304_, L_1305_, L_1306_, L_1307_, L_1308_
	L_1304_ = upvalue_0.CreateToggle
	L_1305_ = upvalue_0
	L_1306_ = L_1301_arg1
	L_1307_ = false
	L_1308_ = L_1303_arg3
	return upvalue_0:CreateToggle(L_1301_arg1, false, L_1303_arg3)
end

L_1_.NewButton_164 = function(L_1309_arg0, L_1310_arg1, L_1311_arg2, L_1312_arg3)
	local L_1313_, L_1314_, L_1315_, L_1316_
	L_1313_ = upvalue_0.CreateButton
	L_1314_ = upvalue_0
	L_1315_ = L_1310_arg1
	L_1316_ = L_1312_arg3
	return upvalue_0:CreateButton(L_1310_arg1, L_1312_arg3)
end

L_1_.NewSlider_165 = function(L_1317_arg0, L_1318_arg1, L_1319_arg2, L_1320_arg3, L_1321_arg4, L_1322_arg5)
	local L_1323_, L_1324_, L_1325_, L_1326_, L_1327_, L_1328_, L_1329_
	L_1323_ = upvalue_0
	L_1325_ = L_1318_arg1
	L_1326_ = L_1321_arg4
	if not (L_1321_arg4) then
		L_1326_ = 0
	end
	L_1327_ = L_1320_arg3
	if not (L_1320_arg3) then
		L_1327_ = 100
	end
	L_1328_ = L_1321_arg4
	if L_1321_arg4 then
		L_1323_ = L_1323_.CreateSlider
		L_1324_ = L_1323_
		L_1329_ = L_1322_arg5
		return L_1323_:CreateSlider(L_1325_, L_1326_, L_1327_, L_1328_, L_1322_arg5)
	end
	L_1328_ = 0
	L_1323_ = L_1323_.CreateSlider
	L_1324_ = L_1323_
	L_1329_ = L_1322_arg5
	return L_1323_:CreateSlider(L_1325_, L_1326_, L_1327_, L_1328_, L_1322_arg5)
end

L_1_.NewDropdown_166 = function(L_1330_arg0, L_1331_arg1, L_1332_arg2, L_1333_arg3, L_1334_arg4)
	local L_1335_, L_1336_, L_1337_, L_1338_, L_1339_, L_1340_, L_1341_, L_1342_, L_1343_
	L_1335_ = upvalue_0
	L_1336_ = L_1332_arg2
	L_1337_ = L_1333_arg3
	L_1338_ = L_1334_arg4
	L_1335_, L_1336_, L_1337_ = upvalue_0(L_1332_arg2, L_1333_arg3, L_1334_arg4)
	L_1338_ = upvalue_1.CreateDropdown
	L_1339_ = upvalue_1
	L_1340_ = L_1331_arg1
	L_1341_ = L_1335_
	L_1342_ = L_1336_
	L_1343_ = L_1337_
	return upvalue_1:CreateDropdown(L_1331_arg1, L_1335_, L_1336_, L_1337_)
end

L_1_.NewLabel_167 = function(L_1344_arg0, L_1345_arg1)
	local L_1346_, L_1347_, L_1348_
	L_1346_ = upvalue_0.CreateLabel
	L_1347_ = upvalue_0
	L_1348_ = L_1345_arg1
	return upvalue_0:CreateLabel(L_1345_arg1)
end

L_1_.NewInput_168 = function(L_1349_arg0, L_1350_arg1, L_1351_arg2, L_1352_arg3)
	local L_1353_, L_1354_, L_1355_, L_1356_, L_1357_
	L_1353_ = upvalue_0.CreateInput
	L_1354_ = upvalue_0
	L_1355_ = L_1350_arg1
	L_1356_ = L_1351_arg2
	L_1357_ = L_1352_arg3
	return upvalue_0:CreateInput(L_1350_arg1, L_1351_arg2, L_1352_arg3)
end

L_1_.NewTitle_169 = function(L_1358_arg0, L_1359_arg1)
	local L_1360_, L_1361_, L_1362_, L_1363_, L_1364_
	L_1360_ = upvalue_0.CreateLabel
	L_1361_ = upvalue_0
	L_1362_ = "\u{2726} " .. L_1359_arg1
	L_1363_ = "\u{2726} "
	L_1364_ = L_1359_arg1
	return upvalue_0:CreateLabel("\u{2726} " .. L_1359_arg1)
end

L_1_.NewSection_170 = function(L_1365_arg0)
	local L_1366_
	return upvalue_0
end

L_1_.callback_171 = function()
	local L_1367_, L_1368_, L_1369_
	upvalue_0:Set(false)
	return
end

L_1_.callback_172 = function()
	local L_1370_, L_1371_
	pcall(L_1_.callback_171)
	task.wait()
	upvalue_1 = false
	return
end

L_1_.callback_173 = function(L_1372_arg0)
	local L_1373_, L_1374_
	L_1373_ = upvalue_0
	if upvalue_0 then
		return
	end
	L_1373_ = _isPremiumUser()
	if not _isPremiumUser() then
		if not L_1372_arg0 then
			return
		end
		upvalue_2(upvalue_3)
		upvalue_0 = true
		task.defer(L_1_.callback_172)
		L_1373_ = task.defer
		L_1374_ = L_1_.callback_172
		return
	else
		L_1373_ = upvalue_1
		if not upvalue_1 then
			return
		else
			upvalue_1(L_1372_arg0)
			return
		end
	end
end

L_1_.NewPremiumToggle_174 = function(L_1375_arg0, L_1376_arg1, L_1377_arg2, L_1378_arg3)
	local L_1379_, L_1380_, L_1381_, L_1382_, L_1383_, L_1384_, L_1385_

	return upvalue_0:CreateToggle(_premTag(L_1376_arg1), false, L_1_.callback_173)
end

L_1_.callback_175 = function()
	local L_1386_, L_1387_
	L_1386_ = _isPremiumUser()
	if not _isPremiumUser() then
		upvalue_1(upvalue_2)
		L_1386_ = upvalue_1
		L_1387_ = upvalue_2
		return
	else
		L_1386_ = upvalue_0
		if not upvalue_0 then
			return
		else
			upvalue_0()
			return
		end
	end
end

L_1_.NewPremiumButton_176 = function(L_1388_arg0, L_1389_arg1, L_1390_arg2, L_1391_arg3)
	local L_1392_, L_1393_, L_1394_, L_1395_
	L_1392_ = upvalue_0.CreateButton
	L_1393_ = upvalue_0
	L_1394_ = _premTag(L_1389_arg1)
	L_1395_ = L_1_.callback_175
	return upvalue_0:CreateButton(_premTag(L_1389_arg1), L_1_.callback_175)
end

L_1_.callback_177 = function(L_1396_arg0)
	local L_1397_, L_1398_
	L_1397_ = _isPremiumUser()
	if not _isPremiumUser() then
		upvalue_1(upvalue_2)
		L_1397_ = upvalue_1
		L_1398_ = upvalue_2
		return
	else
		L_1397_ = upvalue_0
		if not upvalue_0 then
			return
		else
			upvalue_0(L_1396_arg0)
			return
		end
	end
end

L_1_.NewPremiumSlider_178 = function(L_1399_arg0, L_1400_arg1, L_1401_arg2, L_1402_arg3, L_1403_arg4, L_1404_arg5)
	local L_1405_, L_1406_, L_1407_, L_1408_, L_1409_, L_1410_, L_1411_
	L_1405_ = upvalue_0
	L_1407_ = _premTag(L_1400_arg1)
	L_1408_ = L_1403_arg4
	if not (L_1403_arg4) then
		L_1408_ = 0
	end
	L_1409_ = L_1402_arg3
	if not (L_1402_arg3) then
		L_1409_ = 100
	end
	L_1410_ = L_1403_arg4
	if L_1403_arg4 then
		L_1405_ = L_1405_.CreateSlider
		L_1406_ = L_1405_
		L_1411_ = L_1_.callback_177
		return L_1405_:CreateSlider(L_1407_, L_1408_, L_1409_, L_1410_, L_1_.callback_177)
	end
	L_1410_ = 0
	L_1405_ = L_1405_.CreateSlider
	L_1406_ = L_1405_
	L_1411_ = L_1_.callback_177
	return L_1405_:CreateSlider(L_1407_, L_1408_, L_1409_, L_1410_, L_1_.callback_177)
end

L_1_.callback_179 = function(L_1412_arg0)
	local L_1413_, L_1414_
	L_1413_ = _isPremiumUser()
	if not _isPremiumUser() then
		upvalue_1(upvalue_2)
		L_1413_ = upvalue_1
		L_1414_ = upvalue_2
		return
	else
		L_1413_ = upvalue_0
		if not upvalue_0 then
			return
		else
			upvalue_0(L_1412_arg0)
			return
		end
	end
end

L_1_.NewPremiumDropdown_180 = function(L_1415_arg0, L_1416_arg1, L_1417_arg2, L_1418_arg3, L_1419_arg4)
	local L_1420_, L_1421_, L_1422_, L_1423_, L_1424_, L_1425_, L_1426_, L_1427_, L_1428_
	L_1420_ = upvalue_0
	L_1421_ = L_1417_arg2
	L_1422_ = L_1418_arg3
	L_1423_ = L_1419_arg4
	L_1420_, L_1421_, L_1422_ = upvalue_0(L_1417_arg2, L_1418_arg3, L_1419_arg4)
	L_1423_ = upvalue_1.CreateDropdown
	L_1424_ = upvalue_1
	L_1425_ = _premTag(L_1416_arg1)
	L_1426_ = L_1420_
	L_1427_ = L_1421_
	L_1428_ = L_1_.callback_179
	return upvalue_1:CreateDropdown(_premTag(L_1416_arg1), L_1420_, L_1421_, L_1_.callback_179)
end

L_1_.NewSection_181 = function(L_1429_arg0, L_1430_arg1)
	local L_1431_, L_1432_, L_1433_, L_1434_, L_1435_, L_1436_, L_1437_, L_1438_, L_1439_, L_1440_, L_1441_, L_1442_
	L_1431_ = L_1430_arg1
	if not (L_1430_arg1) then
		L_1431_ = "General"
	end
	L_1432_ = L_1431_:lower()
	L_1433_ = "General"
	L_1434_ = "globe"
	L_1435_ = L_1432_:find("free feat")
	L_1436_ = L_1432_
	L_1437_ = "free feat"
	if not L_1432_:find("free feat") then
		L_1435_ = L_1432_:find("premium feat")
		L_1436_ = L_1432_
		L_1437_ = "premium feat"
		if not L_1432_:find("premium feat") then
			L_1435_ = L_1432_:find("combat")
			L_1436_ = L_1432_
			L_1437_ = "combat"
			if L_1432_:find("combat") then
				L_1433_ = "Combat"
				L_1434_ = "swords"
			else
				L_1435_ = L_1432_:find("aimbot")
				L_1436_ = L_1432_
				L_1437_ = "aimbot"
				if L_1432_:find("aimbot") then
					L_1433_ = "Combat"
					L_1434_ = "swords"
				else
					L_1435_ = L_1432_:find("aim")
					L_1436_ = L_1432_
					L_1437_ = "aim"
					if L_1432_:find("aim") then
						L_1433_ = "Combat"
						L_1434_ = "swords"
					else
						L_1435_ = L_1432_:find("weapon")
						L_1436_ = L_1432_
						L_1437_ = "weapon"
						if L_1432_:find("weapon") then
							L_1433_ = "Combat"
							L_1434_ = "swords"
						else
							L_1435_ = L_1432_:find("gun")
							L_1436_ = L_1432_
							L_1437_ = "gun"
							if L_1432_:find("gun") then
								L_1433_ = "Combat"
								L_1434_ = "swords"
							else
								L_1435_ = L_1432_:find("silent")
								L_1436_ = L_1432_
								L_1437_ = "silent"
								if L_1432_:find("silent") then
									L_1433_ = "Combat"
									L_1434_ = "swords"
								else
									L_1435_ = L_1432_:find("aura")
									L_1436_ = L_1432_
									L_1437_ = "aura"
									if not L_1432_:find("aura") then
										L_1435_ = L_1432_:find("esp")
										L_1436_ = L_1432_
										L_1437_ = "esp"
										if L_1432_:find("esp") then
											L_1433_ = "Visuals"
											L_1434_ = "eye"
										else
											L_1435_ = L_1432_:find("visual")
											L_1436_ = L_1432_
											L_1437_ = "visual"
											if L_1432_:find("visual") then
												L_1433_ = "Visuals"
												L_1434_ = "eye"
											else
												L_1435_ = L_1432_:find("wallhack")
												L_1436_ = L_1432_
												L_1437_ = "wallhack"
												if L_1432_:find("wallhack") then
													L_1433_ = "Visuals"
													L_1434_ = "eye"
												else
													L_1435_ = L_1432_:find("radar")
													L_1436_ = L_1432_
													L_1437_ = "radar"
													if L_1432_:find("radar") then
														L_1433_ = "Visuals"
														L_1434_ = "eye"
													else
														L_1435_ = L_1432_:find("chams")
														L_1436_ = L_1432_
														L_1437_ = "chams"
														if L_1432_:find("chams") then
															L_1433_ = "Visuals"
															L_1434_ = "eye"
														else
															L_1435_ = L_1432_:find("render")
															L_1436_ = L_1432_
															L_1437_ = "render"
															if not L_1432_:find("render") then
																L_1435_ = L_1432_:find("move")
																L_1436_ = L_1432_
																L_1437_ = "move"
																if L_1432_:find("move") then
																	L_1433_ = "Movement"
																	L_1434_ = "bar-chart-2"
																else
																	L_1435_ = L_1432_:find("fly")
																	L_1436_ = L_1432_
																	L_1437_ = "fly"
																	if L_1432_:find("fly") then
																		L_1433_ = "Movement"
																		L_1434_ = "bar-chart-2"
																	else
																		L_1435_ = L_1432_:find("speed")
																		L_1436_ = L_1432_
																		L_1437_ = "speed"
																		if L_1432_:find("speed") then
																			L_1433_ = "Movement"
																			L_1434_ = "bar-chart-2"
																		else
																			L_1435_ = L_1432_:find("noclip")
																			L_1436_ = L_1432_
																			L_1437_ = "noclip"
																			if L_1432_:find("noclip") then
																				L_1433_ = "Movement"
																				L_1434_ = "bar-chart-2"
																			else
																				L_1435_ = L_1432_:find("jump")
																				L_1436_ = L_1432_
																				L_1437_ = "jump"
																				if L_1432_:find("jump") then
																					L_1433_ = "Movement"
																					L_1434_ = "bar-chart-2"
																				else
																					L_1435_ = L_1432_:find("travel")
																					L_1436_ = L_1432_
																					L_1437_ = "travel"
																					if L_1432_:find("travel") then
																						L_1433_ = "Movement"
																						L_1434_ = "bar-chart-2"
																					else
																						L_1435_ = L_1432_:find("tp")
																						L_1436_ = L_1432_
																						L_1437_ = "tp"
																						if L_1432_:find("tp") then
																							L_1433_ = "Movement"
																							L_1434_ = "bar-chart-2"
																						else
																							L_1435_ = L_1432_:find("teleport")
																							L_1436_ = L_1432_
																							L_1437_ = "teleport"
																							if not L_1432_:find("teleport") then
																								L_1435_ = L_1432_:find("farm")
																								L_1436_ = L_1432_
																								L_1437_ = "farm"
																								if L_1432_:find("farm") then
																									L_1433_ = "AutoFarm"
																									L_1434_ = "zap"
																								else
																									L_1435_ = L_1432_:find("auto")
																									L_1436_ = L_1432_
																									L_1437_ = "auto"
																									if L_1432_:find("auto") then
																										L_1433_ = "AutoFarm"
																										L_1434_ = "zap"
																									else
																										L_1435_ = L_1432_:find("fish")
																										L_1436_ = L_1432_
																										L_1437_ = "fish"
																										if L_1432_:find("fish") then
																											L_1433_ = "AutoFarm"
																											L_1434_ = "zap"
																										else
																											L_1435_ = L_1432_:find("chest")
																											L_1436_ = L_1432_
																											L_1437_ = "chest"
																											if L_1432_:find("chest") then
																												L_1433_ = "AutoFarm"
																												L_1434_ = "zap"
																											else
																												L_1435_ = L_1432_:find("collect")
																												L_1436_ = L_1432_
																												L_1437_ = "collect"
																												if L_1432_:find("collect") then
																													L_1433_ = "AutoFarm"
																													L_1434_ = "zap"
																												else
																													L_1435_ = L_1432_:find("resource")
																													L_1436_ = L_1432_
																													L_1437_ = "resource"
																													if not L_1432_:find("resource") then
																														L_1435_ = L_1432_:find("survival")
																														L_1436_ = L_1432_
																														L_1437_ = "survival"
																														if L_1432_:find("survival") then
																															L_1433_ = "Survival"
																															L_1434_ = "shield"
																														else
																															L_1435_ = L_1432_:find("god")
																															L_1436_ = L_1432_
																															L_1437_ = "god"
																															if L_1432_:find("god") then
																																L_1433_ = "Survival"
																																L_1434_ = "shield"
																															else
																																L_1435_ = L_1432_:find("oxygen")
																																L_1436_ = L_1432_
																																L_1437_ = "oxygen"
																																if L_1432_:find("oxygen") then
																																	L_1433_ = "Survival"
																																	L_1434_ = "shield"
																																else
																																	L_1435_ = L_1432_:find("survive")
																																	L_1436_ = L_1432_
																																	L_1437_ = "survive"
																																	if L_1432_:find("survive") then
																																		L_1433_ = "Survival"
																																		L_1434_ = "shield"
																																	else
																																		L_1435_ = L_1432_:find("anti")
																																		L_1436_ = L_1432_
																																		L_1437_ = "anti"
																																		if not L_1432_:find("anti") then
																																			L_1435_ = L_1432_:find("troll")
																																			L_1436_ = L_1432_
																																			L_1437_ = "troll"
																																			if L_1432_:find("troll") then
																																				L_1433_ = "Rage"
																																				L_1434_ = "flame"
																																			else
																																				L_1435_ = L_1432_:find("rage")
																																				L_1436_ = L_1432_
																																				L_1437_ = "rage"
																																				if L_1432_:find("rage") then
																																					L_1433_ = "Rage"
																																					L_1434_ = "flame"
																																				else
																																					L_1435_ = L_1432_:find("hitbox")
																																					L_1436_ = L_1432_
																																					L_1437_ = "hitbox"
																																					if not L_1432_:find("hitbox") then
																																						L_1435_ = L_1432_:find("misc")
																																						L_1436_ = L_1432_
																																						L_1437_ = "misc"
																																						if L_1432_:find("misc") then
																																							L_1433_ = "Utility"
																																							L_1434_ = "sliders"
																																						else
																																							L_1435_ = L_1432_:find("util")
																																							L_1436_ = L_1432_
																																							L_1437_ = "util"
																																							if L_1432_:find("util") then
																																								L_1433_ = "Utility"
																																								L_1434_ = "sliders"
																																							else
																																								L_1435_ = L_1432_:find("extra")
																																								L_1436_ = L_1432_
																																								L_1437_ = "extra"
																																								if L_1432_:find("extra") then
																																									L_1433_ = "Utility"
																																									L_1434_ = "sliders"
																																								else
																																									L_1435_ = L_1432_:find("general")
																																									L_1436_ = L_1432_
																																									L_1437_ = "general"
																																									if L_1432_:find("general") then
																																										L_1433_ = "Utility"
																																										L_1434_ = "sliders"
																																									else
																																										L_1435_ = L_1432_:find("server")
																																										L_1436_ = L_1432_
																																										L_1437_ = "server"
																																										if not L_1432_:find("server") then
																																											L_1435_ = L_1432_:find("economy")
																																											L_1436_ = L_1432_
																																											L_1437_ = "economy"
																																											if L_1432_:find("economy") then
																																												L_1433_ = "Economy"
																																												L_1434_ = "bar-chart-2"
																																											else
																																												L_1435_ = L_1432_:find("money")
																																												L_1436_ = L_1432_
																																												L_1437_ = "money"
																																												if L_1432_:find("money") then
																																													L_1433_ = "Economy"
																																													L_1434_ = "bar-chart-2"
																																												else
																																													L_1435_ = L_1432_:find("shop")
																																													L_1436_ = L_1432_
																																													L_1437_ = "shop"
																																													if not L_1432_:find("shop") then
																																														L_1435_ = L_1432_:find("belt")
																																														L_1436_ = L_1432_
																																														L_1437_ = "belt"
																																														if not L_1432_:find("belt") then
																																															L_1435_ = L_1432_:find("tank")
																																															L_1436_ = L_1432_
																																															L_1437_ = "tank"
																																															if not L_1432_:find("tank") then
																																																L_1435_ = L_1432_:find("slot")
																																																L_1436_ = L_1432_
																																																L_1437_ = "slot"
																																																if L_1432_:find("slot") then
																																																	L_1433_ = "Slots"
																																																	L_1434_ = "layout"
																																																end
																																															else
																																																L_1433_ = "Tanks"
																																																L_1434_ = "layout"
																																															end
																																														else
																																															L_1433_ = "Belts"
																																															L_1434_ = "layout"
																																														end
																																													else
																																														L_1433_ = "Economy"
																																														L_1434_ = "bar-chart-2"
																																													end
																																												end
																																											end
																																										else
																																											L_1433_ = "Utility"
																																											L_1434_ = "sliders"
																																										end
																																									end
																																								end
																																							end
																																						end
																																					else
																																						L_1433_ = "Rage"
																																						L_1434_ = "flame"
																																					end
																																				end
																																			end
																																		else
																																			L_1433_ = "Survival"
																																			L_1434_ = "shield"
																																		end
																																	end
																																end
																															end
																														end
																													else
																														L_1433_ = "AutoFarm"
																														L_1434_ = "zap"
																													end
																												end
																											end
																										end
																									end
																								end
																							else
																								L_1433_ = "Movement"
																								L_1434_ = "bar-chart-2"
																							end
																						end
																					end
																				end
																			end
																		end
																	end
																end
															else
																L_1433_ = "Visuals"
																L_1434_ = "eye"
															end
														end
													end
												end
											end
										end
									else
										L_1433_ = "Combat"
										L_1434_ = "swords"
									end
								end
							end
						end
					end
				end
			end
		else
			L_1433_ = "Premium"
			L_1434_ = "zap"
		end
	else
		L_1433_ = "Free"
		L_1434_ = "home"
	end
	L_1436_ = L_1433_
	L_1437_ = L_1434_
	L_1438_ = upvalue_0[L_1433_]
	L_1439_ = upvalue_0
	if not upvalue_0[L_1433_] then
		L_1438_ = upvalue_2.Window
		L_1439_ = upvalue_2
		L_1440_ = L_1436_
		L_1441_ = L_1437_
		if not (L_1437_) then
			L_1441_ = "layout"
		end
		L_1438_ = L_1438_:CreateTab(L_1440_, L_1441_)
		L_1439_ = L_1438_:CreateSubTab("Main", "layout")
		L_1441_ = upvalue_0
		L_1441_[L_1436_] = L_1438_
		L_1441_ = upvalue_1
		L_1441_[L_1436_] = L_1439_:CreateSection("Features")
		L_1435_ = L_1439_:CreateSection("Features")
		L_1440_ = L_1439_:CreateSection("Features")
		L_1442_ = "Features"
	else
		L_1435_ = upvalue_1[L_1436_]
		L_1438_ = upvalue_1
	end
	L_1435_:CreateLabel("\u{2500}\u{2500} " .. L_1431_ .. " \u{2500}\u{2500}")
	L_1436_ = {}
	L_1436_.NewToggle = L_1_.NewToggle_163
	L_1436_.NewButton = L_1_.NewButton_164
	L_1436_.NewSlider = L_1_.NewSlider_165
	L_1436_.NewDropdown = L_1_.NewDropdown_166
	L_1436_.NewLabel = L_1_.NewLabel_167
	L_1436_.NewInput = L_1_.NewInput_168
	L_1436_.NewTitle = L_1_.NewTitle_169
	L_1436_.NewSection = L_1_.NewSection_170
	L_1436_.NewPremiumToggle = L_1_.NewPremiumToggle_174
	L_1436_.NewPremiumButton = L_1_.NewPremiumButton_176
	L_1436_.NewPremiumSlider = L_1_.NewPremiumSlider_178
	L_1436_.NewPremiumDropdown = L_1_.NewPremiumDropdown_180
	return L_1436_
end

L_1_.NewToggle_182 = function()
	local L_1443_
	return
end

L_1_.gameTab_183 = function(L_1444_arg0, L_1445_arg1)
	local L_1446_, L_1447_, L_1448_, L_1449_, L_1450_, L_1451_, L_1452_
	L_1446_ = upvalue_0
	if not upvalue_0 then
		L_1447_ = {}
		L_1447_.NewToggle = L_1_.NewToggle_159
		L_1447_.NewButton = L_1_.NewToggle_159
		L_1447_.NewSlider = L_1_.NewToggle_159
		L_1447_.NewDropdown = L_1_.NewToggle_159
		L_1447_.NewLabel = L_1_.NewToggle_159
		L_1447_.NewPremiumToggle = L_1_.NewToggle_159
		L_1447_.NewPremiumButton = L_1_.NewToggle_159
		L_1447_.NewPremiumSlider = L_1_.NewToggle_159
		L_1447_.NewPremiumDropdown = L_1_.NewToggle_159
		L_1447_.NewSection = L_1_.NewSection_160
		L_1448_ = {}
		L_1448_.NewSection = L_1_.NewSection_161
		L_1448_.NewToggle = L_1_.NewToggle_159
		L_1448_.NewButton = L_1_.NewToggle_159
		L_1448_.NewSlider = L_1_.NewToggle_159
		L_1448_.NewDropdown = L_1_.NewToggle_159
		L_1448_.NewPremiumToggle = L_1_.NewToggle_159
		L_1448_.NewPremiumButton = L_1_.NewToggle_159
		L_1448_.NewPremiumSlider = L_1_.NewToggle_159
		L_1448_.NewPremiumDropdown = L_1_.NewToggle_159
		return L_1448_
	end
	L_1446_ = upvalue_0.name:lower()
	L_1447_ = L_1444_arg0:lower()
	L_1448_ = L_1444_arg0
	L_1452_ = (upvalue_0.name:lower() == L_1444_arg0:lower())
	if (upvalue_0.name:lower() == L_1444_arg0:lower()) then
		L_1449_ = {}
		L_1449_.NewSection = L_1_.NewSection_181
		L_1449_.NewToggle = L_1_.NewToggle_182
		L_1449_.NewButton = L_1_.NewToggle_182
		L_1449_.NewSlider = L_1_.NewToggle_182
		return L_1449_
	else
		L_1447_ = {}
		L_1447_.NewToggle = L_1_.NewToggle_159
		L_1447_.NewButton = L_1_.NewToggle_159
		L_1447_.NewSlider = L_1_.NewToggle_159
		L_1447_.NewDropdown = L_1_.NewToggle_159
		L_1447_.NewLabel = L_1_.NewToggle_159
		L_1447_.NewPremiumToggle = L_1_.NewToggle_159
		L_1447_.NewPremiumButton = L_1_.NewToggle_159
		L_1447_.NewPremiumSlider = L_1_.NewToggle_159
		L_1447_.NewPremiumDropdown = L_1_.NewToggle_159
		L_1447_.NewSection = L_1_.NewSection_160
		L_1448_ = {}
		L_1448_.NewSection = L_1_.NewSection_161
		L_1448_.NewToggle = L_1_.NewToggle_159
		L_1448_.NewButton = L_1_.NewToggle_159
		L_1448_.NewSlider = L_1_.NewToggle_159
		L_1448_.NewDropdown = L_1_.NewToggle_159
		L_1448_.NewPremiumToggle = L_1_.NewToggle_159
		L_1448_.NewPremiumButton = L_1_.NewToggle_159
		L_1448_.NewPremiumSlider = L_1_.NewToggle_159
		L_1448_.NewPremiumDropdown = L_1_.NewToggle_159
		return L_1448_
	end
end

L_1_.callback_184 = function(L_1453_arg0, L_1454_arg1)
	local L_1455_, L_1456_, L_1457_, L_1458_, L_1459_, L_1460_, L_1461_, L_1462_, L_1463_, L_1464_, L_1465_, L_1466_, L_1467_, L_1468_, L_1469_, L_1470_
	local L_1471_, L_1472_, L_1473_
	L_1455_ = L_1453_arg0
	if not (L_1453_arg0) then
		L_1455_ = ""
	end
	L_1455_ = L_1455_:lower()
	L_1456_ = L_1454_arg1
	if not (L_1454_arg1) then
		L_1456_ = ""
	end
	L_1457_ = {}
	L_1457_[1] = "auto"
	L_1457_[2] = "farm"
	L_1457_[3] = "kill"
	L_1457_[4] = "aura"
	L_1457_[5] = "tp"
	L_1457_[6] = "teleport"
	L_1457_[7] = "fly"
	L_1457_[8] = "speed"
	L_1457_[9] = "click"
	L_1457_[10] = "mansion"
	L_1457_[11] = "oil"
	L_1457_[12] = "ship"
	L_1457_[13] = "airdrop"
	L_1457_[14] = "rob"
	L_1457_[15] = "npc"
	L_1457_[16] = "turret"
	L_1457_[17] = "glider"
	L_1457_[18] = "items"
	L_1457_[19] = "give"
	L_1456_ = L_1456_:lower()
	L_1458_ = ipairs
	L_1459_ = L_1457_
	L_1460_ = "give"
	L_1461_ = "aura"
	L_1462_ = "tp"
	L_1463_ = "teleport"
	L_1464_ = "fly"
	L_1465_ = "speed"
	L_1466_ = "click"
	L_1467_ = "mansion"
	L_1468_ = "oil"
	L_1469_ = "ship"
	L_1470_ = "airdrop"
	L_1471_ = "rob"
	L_1472_ = "npc"
	L_1473_ = "turret"
	for L_1474_forvar0, L_1475_forvar1 in ipairs(L_1457_) do
		L_1463_ = L_1455_:find(L_1475_forvar1, 1, true)
		L_1464_ = L_1455_
		L_1465_ = L_1475_forvar1
		L_1466_ = 1
		L_1467_ = true
		if L_1455_:find(L_1475_forvar1, 1, true) then
			return true
		end
		L_1463_ = L_1456_:find(L_1475_forvar1, 1, true)
		L_1464_ = L_1456_
		L_1465_ = L_1475_forvar1
		L_1466_ = 1
		L_1467_ = true
		if L_1456_:find(L_1475_forvar1, 1, true) then
			return true
		end
	end
	return false
end

L_1_.AddSection = function(L_1476_arg0, L_1477_arg1)
	return L_1476_arg0
end

L_1_.AddButton = function(L_1478_arg0, L_1479_arg1)
	local L_1480_, L_1481_, L_1482_, L_1483_, L_1484_, L_1485_
	L_1480_ = upvalue_0
	L_1481_ = L_1479_arg1.Title
	if not (L_1479_arg1.Title) then
		L_1481_ = L_1479_arg1.Name
	end
	L_1482_ = L_1479_arg1.Description
	if not (L_1479_arg1.Description) then
		L_1482_ = L_1479_arg1.Desc
	end
	L_1480_ = L_1480_(L_1481_, L_1482_)
	if not L_1480_(L_1481_, L_1482_) then
		L_1481_ = upvalue_2
		L_1483_ = L_1479_arg1.Title
		if not (L_1479_arg1.Title) then
			L_1483_ = L_1479_arg1.Name
			if not (L_1479_arg1.Name) then
				L_1483_ = "Button"
			end
		end
		L_1484_ = L_1479_arg1.Description
		if L_1479_arg1.Description then
			L_1481_:NewButton(L_1483_, L_1484_, L_1479_arg1.Callback)
			return
		end
		L_1484_ = L_1479_arg1.Desc
		if L_1479_arg1.Desc then
			L_1481_:NewButton(L_1483_, L_1484_, L_1479_arg1.Callback)
			return
		end
		L_1484_ = ""
		L_1481_:NewButton(L_1483_, L_1484_, L_1479_arg1.Callback)
		return
	else
		L_1481_ = upvalue_1
		L_1483_ = L_1479_arg1.Title
		if not (L_1479_arg1.Title) then
			L_1483_ = L_1479_arg1.Name
			if not (L_1479_arg1.Name) then
				L_1483_ = "Button"
			end
		end
		L_1484_ = L_1479_arg1.Description
		if L_1479_arg1.Description then
			L_1481_:NewPremiumButton(L_1483_, L_1484_, L_1479_arg1.Callback)
			return
		end
		L_1484_ = L_1479_arg1.Desc
		if L_1479_arg1.Desc then
			L_1481_:NewPremiumButton(L_1483_, L_1484_, L_1479_arg1.Callback)
			return
		end
		L_1484_ = ""
		L_1481_:NewPremiumButton(L_1483_, L_1484_, L_1479_arg1.Callback)
		return
	end
end

L_1_.callback_187 = function()
	local L_1486_, L_1487_
	upvalue_0(upvalue_1)
	return
end

L_1_.callback_188 = function(L_1488_arg0)
	local L_1489_, L_1490_
	L_1489_ = upvalue_0
	if not upvalue_0 then
		return
	end
	pcall(L_1_.callback_187)
	L_1489_ = pcall
	L_1490_ = L_1_.callback_187
	return
end

L_1_.callback_189 = function()
	local L_1491_, L_1492_
	upvalue_0(upvalue_1)
	return
end

L_1_.callback_190 = function(L_1493_arg0)
	local L_1494_, L_1495_
	L_1494_ = upvalue_0
	if not upvalue_0 then
		return
	end
	pcall(L_1_.callback_189)
	L_1494_ = pcall
	L_1495_ = L_1_.callback_189
	return
end

L_1_.OnChanged = function()
	local L_1496_, L_1497_, L_1498_
	upvalue_0:Set(upvalue_1)
	return
end

L_1_.OnChanged_192 = function(L_1499_arg0, L_1500_arg1)
	local L_1501_
	upvalue_0 = L_1500_arg1
	return upvalue_1
end

L_1_.callback_193 = function()
	local L_1502_, L_1503_, L_1504_
	upvalue_0:Set(upvalue_1)
	return
end

L_1_.SetValue = function(L_1505_arg0, L_1506_arg1)
	local L_1507_, L_1508_
	pcall(L_1_.callback_193)
	return
end

L_1_.AddToggle = function(L_1509_arg0, L_1510_arg1, L_1511_arg2)
	local L_1512_, L_1513_, L_1514_, L_1515_, L_1516_, L_1517_, L_1518_, L_1519_, L_1520_, L_1521_, L_1522_, L_1523_, L_1524_
	L_1512_ = L_1511_arg2
	if not (L_1511_arg2) then
		L_1512_ = L_1510_arg1
	end
	L_1513_ = L_1512_.Title
	if not (L_1512_.Title) then
		L_1513_ = L_1512_.Name
		if not (L_1512_.Name) then
			L_1513_ = "Toggle"
		end
	end
	L_1514_ = L_1512_.Description
	if not (L_1512_.Description) then
		L_1514_ = L_1512_.Desc
		if not (L_1512_.Desc) then
			L_1514_ = ""
		end
	end
	L_1515_ = L_1512_.Callback
	L_1516_ = L_1512_.Default
	L_1517_ = L_1512_.Default
	if not (L_1512_.Default) then
		L_1516_ = false
	end
	L_1517_ = upvalue_0(L_1513_, L_1514_)
	L_1518_ = L_1515_
	L_1519_ = nil
	if not upvalue_0(L_1513_, L_1514_) then
		L_1519_ = upvalue_2:NewToggle(L_1513_, L_1514_, L_1_.callback_190)
		L_1520_ = upvalue_2:NewToggle(L_1513_, L_1514_, L_1_.callback_190)
		L_1521_ = upvalue_2
		L_1522_ = L_1513_
		L_1523_ = L_1514_
		L_1524_ = L_1_.callback_190
	else
		L_1519_ = upvalue_1:NewPremiumToggle(L_1513_, L_1514_, L_1_.callback_188)
		L_1520_ = upvalue_1:NewPremiumToggle(L_1513_, L_1514_, L_1_.callback_188)
		L_1521_ = upvalue_1
		L_1522_ = L_1513_
		L_1523_ = L_1514_
		L_1524_ = L_1_.callback_188
	end
	if not L_1516_ then
		L_1520_ = {}
		L_1520_.OnChanged = L_1_.OnChanged_192
		L_1520_.SetValue = L_1_.SetValue

		return L_1520_
	end
	if not L_1519_ then
		L_1520_ = {}
		L_1520_.OnChanged = L_1_.OnChanged_192
		L_1520_.SetValue = L_1_.SetValue

		return L_1520_
	end
	L_1520_ = L_1519_.Set
	if not L_1519_.Set then
		L_1520_ = {}
		L_1520_.OnChanged = L_1_.OnChanged_192
		L_1520_.SetValue = L_1_.SetValue

		return L_1520_
	end
	pcall(L_1_.OnChanged)
	L_1520_ = pcall
	L_1521_ = L_1_.OnChanged
	L_1520_ = {}
	L_1520_.OnChanged = L_1_.OnChanged_192
	L_1520_.SetValue = L_1_.SetValue

	return L_1520_
end

L_1_.callback_196 = function()
	local L_1525_, L_1526_
	upvalue_0(upvalue_1)
	return
end

L_1_.callback_197 = function(L_1527_arg0)
	local L_1528_, L_1529_
	L_1528_ = upvalue_0
	if not upvalue_0 then
		return
	end
	pcall(L_1_.callback_196)
	L_1528_ = pcall
	L_1529_ = L_1_.callback_196
	return
end

L_1_.callback_198 = function()
	local L_1530_, L_1531_
	upvalue_0(upvalue_1)
	return
end

L_1_.callback_199 = function(L_1532_arg0)
	local L_1533_, L_1534_
	L_1533_ = upvalue_0
	if not upvalue_0 then
		return
	end
	pcall(L_1_.callback_198)
	L_1533_ = pcall
	L_1534_ = L_1_.callback_198
	return
end

L_1_.OnChanged_200 = function()
	local L_1535_, L_1536_, L_1537_
	upvalue_0:Set(upvalue_1)
	return
end

L_1_.OnChanged_201 = function(L_1538_arg0, L_1539_arg1)
	local L_1540_
	upvalue_0 = L_1539_arg1
	return upvalue_1
end

L_1_.callback_202 = function()
	local L_1541_, L_1542_, L_1543_
	upvalue_0:Set(upvalue_1)
	return
end

L_1_.SetValue_203 = function(L_1544_arg0, L_1545_arg1)
	local L_1546_, L_1547_
	pcall(L_1_.callback_202)
	return
end

L_1_.AddSlider = function(L_1548_arg0, L_1549_arg1, L_1550_arg2)
	local L_1551_, L_1552_, L_1553_, L_1554_, L_1555_, L_1556_, L_1557_, L_1558_, L_1559_, L_1560_, L_1561_, L_1562_, L_1563_, L_1564_, L_1565_, L_1566_
	local L_1567_
	L_1551_ = L_1550_arg2
	if not (L_1550_arg2) then
		L_1551_ = L_1549_arg1
	end
	L_1552_ = L_1551_.Title
	if not (L_1551_.Title) then
		L_1552_ = L_1551_.Name
		if not (L_1551_.Name) then
			L_1552_ = "Slider"
		end
	end
	L_1553_ = L_1551_.Description
	if not (L_1551_.Description) then
		L_1553_ = L_1551_.Desc
		if not (L_1551_.Desc) then
			L_1553_ = ""
		end
	end
	L_1554_ = L_1551_.Callback
	L_1555_ = L_1551_.Min
	L_1556_ = L_1551_.Min
	if not (L_1551_.Min) then
		L_1555_ = 0
	end
	L_1556_ = L_1551_.Max
	L_1557_ = L_1551_.Max
	if not (L_1551_.Max) then
		L_1556_ = 100
	end
	L_1557_ = L_1551_.Default
	L_1558_ = L_1551_.Default
	if not (L_1551_.Default) then
		L_1557_ = L_1555_
	end
	L_1558_ = upvalue_0(L_1552_, L_1553_)
	L_1559_ = L_1554_
	L_1560_ = nil
	if not upvalue_0(L_1552_, L_1553_) then
		L_1560_ = upvalue_2:NewSlider(L_1552_, L_1553_, L_1556_, L_1555_, L_1_.callback_199)
		L_1561_ = upvalue_2:NewSlider(L_1552_, L_1553_, L_1556_, L_1555_, L_1_.callback_199)
		L_1562_ = upvalue_2
		L_1563_ = L_1552_
		L_1564_ = L_1553_
		L_1565_ = L_1556_
		L_1566_ = L_1555_
		L_1567_ = L_1_.callback_199
	else
		L_1560_ = upvalue_1:NewPremiumSlider(L_1552_, L_1553_, L_1556_, L_1555_, L_1_.callback_197)
		L_1561_ = upvalue_1:NewPremiumSlider(L_1552_, L_1553_, L_1556_, L_1555_, L_1_.callback_197)
		L_1562_ = upvalue_1
		L_1563_ = L_1552_
		L_1564_ = L_1553_
		L_1565_ = L_1556_
		L_1566_ = L_1555_
		L_1567_ = L_1_.callback_197
	end
	if not L_1557_ then
		L_1561_ = {}
		L_1561_.OnChanged = L_1_.OnChanged_201
		L_1561_.SetValue = L_1_.SetValue_203

		return L_1561_
	end
	if not L_1560_ then
		L_1561_ = {}
		L_1561_.OnChanged = L_1_.OnChanged_201
		L_1561_.SetValue = L_1_.SetValue_203

		return L_1561_
	end
	L_1561_ = L_1560_.Set
	if not L_1560_.Set then
		L_1561_ = {}
		L_1561_.OnChanged = L_1_.OnChanged_201
		L_1561_.SetValue = L_1_.SetValue_203

		return L_1561_
	end
	pcall(L_1_.OnChanged_200)
	L_1561_ = pcall
	L_1562_ = L_1_.OnChanged_200
	L_1561_ = {}
	L_1561_.OnChanged = L_1_.OnChanged_201
	L_1561_.SetValue = L_1_.SetValue_203

	return L_1561_
end

L_1_.callback_205 = function()
	local L_1568_, L_1569_
	upvalue_0(upvalue_1)
	return
end

L_1_.callback_206 = function(L_1570_arg0)
	local L_1571_, L_1572_
	L_1571_ = upvalue_0
	if not upvalue_0 then
		return
	end
	pcall(L_1_.callback_205)
	L_1571_ = pcall
	L_1572_ = L_1_.callback_205
	return
end

L_1_.callback_207 = function()
	local L_1573_, L_1574_
	upvalue_0(upvalue_1)
	return
end

L_1_.callback_208 = function(L_1575_arg0)
	local L_1576_, L_1577_
	L_1576_ = upvalue_0
	if not upvalue_0 then
		return
	end
	pcall(L_1_.callback_207)
	L_1576_ = pcall
	L_1577_ = L_1_.callback_207
	return
end

L_1_.OnChanged_209 = function()
	local L_1578_, L_1579_, L_1580_
	upvalue_0:Set(upvalue_1)
	return
end

L_1_.OnChanged_210 = function(L_1581_arg0, L_1582_arg1)
	local L_1583_
	upvalue_0 = L_1582_arg1
	return upvalue_1
end

L_1_.callback_211 = function()
	local L_1584_, L_1585_, L_1586_
	upvalue_0:Set(upvalue_1)
	return
end

L_1_.SetValue_212 = function(L_1587_arg0, L_1588_arg1)
	local L_1589_, L_1590_
	pcall(L_1_.callback_211)
	return
end

L_1_.AddDropdown = function(L_1591_arg0, L_1592_arg1, L_1593_arg2)
	local L_1594_, L_1595_, L_1596_, L_1597_, L_1598_, L_1599_, L_1600_, L_1601_, L_1602_, L_1603_, L_1604_, L_1605_, L_1606_, L_1607_, L_1608_
	L_1594_ = L_1593_arg2
	if not (L_1593_arg2) then
		L_1594_ = L_1592_arg1
	end
	L_1595_ = L_1594_.Title
	if not (L_1594_.Title) then
		L_1595_ = L_1594_.Name
		if not (L_1594_.Name) then
			L_1595_ = "Dropdown"
		end
	end
	L_1596_ = L_1594_.Description
	if not (L_1594_.Description) then
		L_1596_ = L_1594_.Desc
		if not (L_1594_.Desc) then
			L_1596_ = ""
		end
	end
	L_1597_ = L_1594_.Callback
	L_1598_ = L_1594_.Values
	if not (L_1594_.Values) then
		L_1598_ = L_1594_.List
		if not (L_1594_.List) then
			L_1598_ = {}
		end
	end
	L_1599_ = L_1594_.Default
	L_1600_ = L_1594_.Default
	if not (L_1594_.Default) then
		L_1599_ = nil
	end
	L_1600_ = upvalue_0(L_1595_, L_1596_)
	L_1601_ = L_1597_
	L_1602_ = nil
	if not upvalue_0(L_1595_, L_1596_) then
		L_1602_ = upvalue_2:NewDropdown(L_1595_, L_1596_, L_1598_, L_1_.callback_208)
		L_1603_ = upvalue_2:NewDropdown(L_1595_, L_1596_, L_1598_, L_1_.callback_208)
		L_1604_ = upvalue_2
		L_1605_ = L_1595_
		L_1606_ = L_1596_
		L_1607_ = L_1598_
		L_1608_ = L_1_.callback_208
	else
		L_1602_ = upvalue_1:NewPremiumDropdown(L_1595_, L_1596_, L_1598_, L_1_.callback_206)
		L_1603_ = upvalue_1:NewPremiumDropdown(L_1595_, L_1596_, L_1598_, L_1_.callback_206)
		L_1604_ = upvalue_1
		L_1605_ = L_1595_
		L_1606_ = L_1596_
		L_1607_ = L_1598_
		L_1608_ = L_1_.callback_206
	end
	if not L_1599_ then
		L_1603_ = {}
		L_1603_.OnChanged = L_1_.OnChanged_210
		L_1603_.SetValue = L_1_.SetValue_212

		return L_1603_
	end
	if not L_1602_ then
		L_1603_ = {}
		L_1603_.OnChanged = L_1_.OnChanged_210
		L_1603_.SetValue = L_1_.SetValue_212

		return L_1603_
	end
	L_1603_ = L_1602_.Set
	if not L_1602_.Set then
		L_1603_ = {}
		L_1603_.OnChanged = L_1_.OnChanged_210
		L_1603_.SetValue = L_1_.SetValue_212

		return L_1603_
	end
	pcall(L_1_.OnChanged_209)
	L_1603_ = pcall
	L_1604_ = L_1_.OnChanged_209
	L_1603_ = {}
	L_1603_.OnChanged = L_1_.OnChanged_210
	L_1603_.SetValue = L_1_.SetValue_212

	return L_1603_
end

L_1_.AddLabel = function(L_1609_arg0, L_1610_arg1)
	local L_1611_, L_1612_, L_1613_
	upvalue_0:NewLabel(L_1610_arg1)
	return
end

L_1_.AddParagraph = function(L_1614_arg0, L_1615_arg1)
	local L_1616_, L_1617_, L_1618_, L_1619_, L_1620_, L_1621_, L_1622_
	L_1616_ = upvalue_0
	L_1619_ = L_1615_arg1.Title
	L_1622_ = L_1615_arg1.Title
	if not (L_1615_arg1.Title) then
		L_1619_ = ""
	end
	L_1620_ = ": "
	L_1621_ = L_1615_arg1.Content
	L_1622_ = L_1615_arg1.Content
	if L_1615_arg1.Content then
		L_1616_:NewLabel(L_1619_ .. L_1620_ .. L_1621_)
		return
	end
	L_1621_ = ""
	L_1616_:NewLabel(L_1619_ .. L_1620_ .. L_1621_)
	return
end

L_1_.OnChanged_216 = function(L_1623_arg0, L_1624_arg1)
	return L_1623_arg0
end

L_1_.SetValue_217 = function(L_1625_arg0, L_1626_arg1)
	return
end

L_1_.AddKeybind = function(L_1627_arg0, L_1628_arg1, L_1629_arg2)
	local L_1630_, L_1631_
	L_1630_ = {}
	L_1630_.OnChanged = L_1_.OnChanged_216
	L_1630_.SetValue = L_1_.SetValue_217
	return L_1630_
end

L_1_.OnChanged_219 = function(L_1632_arg0, L_1633_arg1)
	return L_1632_arg0
end

L_1_.SetValue_220 = function(L_1634_arg0, L_1635_arg1)
	return
end

L_1_.AddColorpicker = function(L_1636_arg0, L_1637_arg1, L_1638_arg2)
	local L_1639_, L_1640_
	L_1639_ = {}
	L_1639_.OnChanged = L_1_.OnChanged_219
	L_1639_.SetValue = L_1_.SetValue_220
	return L_1639_
end

L_1_.AddTab = function(L_1641_arg0, L_1642_arg1)
	local L_1643_, L_1644_
	L_1643_ = {}
	L_1643_.AddSection = L_1_.AddSection
	L_1643_.AddButton = L_1_.AddButton
	L_1643_.AddToggle = L_1_.AddToggle
	L_1643_.AddSlider = L_1_.AddSlider
	L_1643_.AddDropdown = L_1_.AddDropdown
	L_1643_.AddLabel = L_1_.AddLabel
	L_1643_.AddParagraph = L_1_.AddParagraph
	L_1643_.AddKeybind = L_1_.AddKeybind
	L_1643_.AddColorpicker = L_1_.AddColorpicker
	return L_1643_
end

L_1_.SelectTab = function(L_1645_arg0, L_1646_arg1)
	return
end

L_1_.CreateWindow_224 = function(L_1647_arg0, L_1648_arg1)
	local L_1649_, L_1650_
	L_1649_ = {}
	L_1649_.AddTab = L_1_.AddTab
	L_1649_.SelectTab = L_1_.SelectTab
	return L_1649_
end

L_1_.callback_225 = function()
	local L_1651_, L_1652_, L_1653_, L_1654_, L_1655_, L_1656_, L_1657_
	L_1651_ = upvalue_0
	L_1653_ = upvalue_1.Title
	L_1654_ = upvalue_1.Title
	L_1655_ = upvalue_1
	if not (upvalue_1.Title) then
		L_1653_ = "Notification"
	end
	L_1654_ = upvalue_1.Content
	L_1655_ = upvalue_1
	if not (upvalue_1.Content) then
		L_1654_ = upvalue_1.Text
		L_1655_ = upvalue_1
		if not (upvalue_1.Text) then
			L_1654_ = ""
		end
	end
	L_1655_ = upvalue_1.Duration
	L_1656_ = upvalue_1.Duration
	L_1657_ = upvalue_1
	if upvalue_1.Duration then
		L_1651_:Notify(L_1653_, L_1654_, L_1655_)
		return
	end
	L_1655_ = 3
	L_1651_:Notify(L_1653_, L_1654_, L_1655_)
	return
end

L_1_.Notify_226 = function(L_1658_arg0, L_1659_arg1)
	local L_1660_, L_1661_
	pcall(L_1_.callback_225)
	return
end

L_1_.callback_227 = function(L_1662_arg0)
	local L_1663_, L_1664_, L_1665_, L_1666_, L_1667_, L_1668_
	L_1663_ = upvalue_0(L_1662_arg0, L_1662_arg0)
	L_1664_ = {}
	L_1664_.CreateWindow = L_1_.CreateWindow_224
	L_1664_.Notify = L_1_.Notify_226
	return L_1664_
end

L_1_.PlayerModifierLoop = function()
	local L_1669_, L_1670_
	L_1669_ = getgenv().PlayerModifierLoop
	L_1669_:Disconnect()
	return
end

L_1_.callback_229 = function()
	local L_1671_, L_1672_, L_1673_, L_1674_
	upvalue_0:SetStateEnabled(Enum.HumanoidStateType.Dead, false)
	return
end

L_1_.callback_230 = function()
	local L_1675_, L_1676_, L_1677_, L_1678_, L_1679_, L_1680_
	L_1675_ = game.Players.LocalPlayer.Character
	L_1676_ = game.Players.LocalPlayer
	if not game.Players.LocalPlayer.Character then
		return
	end
	L_1676_ = L_1675_:FindFirstChild("Humanoid")
	L_1677_ = L_1675_
	L_1678_ = "Humanoid"
	if not L_1675_:FindFirstChild("Humanoid") then
		return
	end
	L_1676_ = L_1675_:FindFirstChild("HumanoidRootPart")
	L_1677_ = L_1675_
	L_1678_ = "HumanoidRootPart"
	if not L_1675_:FindFirstChild("HumanoidRootPart") then
		return
	end
	L_1676_ = L_1675_.Humanoid
	L_1677_ = getgenv().GodModeEnabled
	L_1678_ = getgenv()
	if not getgenv().GodModeEnabled then
		return
	end
	L_1677_ = L_1676_.MaxHealth
	L_1679_ = inf
	L_1680_ = (L_1676_.MaxHealth == inf)
	if not (L_1676_.MaxHealth == inf) then
		L_1676_.MaxHealth = inf
		L_1677_ = inf
	end
	L_1677_ = L_1676_.Health
	L_1679_ = inf
	L_1680_ = (L_1676_.Health == inf)
	if not (L_1676_.Health == inf) then
		L_1676_.Health = inf
		L_1677_ = inf
	end
	pcall(L_1_.callback_229)
	L_1677_ = pcall
	L_1678_ = L_1_.callback_229
	return
end

L_1_.callback_231 = function(L_1681_arg0)
	local L_1682_, L_1683_
	pcall(L_1_.callback_230)
	return
end

L_1_.callback_232 = function(L_1684_arg0)
	local L_1685_, L_1686_, L_1687_
	L_1685_ = getgenv()
	L_1685_.WalkSpeedValue = L_1684_arg0
	L_1685_ = game.Players.LocalPlayer.Character
	L_1686_ = game.Players.LocalPlayer
	if not game.Players.LocalPlayer.Character then
		return
	end
	L_1685_ = game.Players.LocalPlayer.Character:FindFirstChild("Humanoid")
	L_1686_ = game.Players.LocalPlayer.Character
	L_1687_ = "Humanoid"
	if not game.Players.LocalPlayer.Character:FindFirstChild("Humanoid") then
		return
	end
	L_1685_ = game.Players.LocalPlayer.Character.Humanoid
	L_1685_.WalkSpeed = L_1684_arg0
	L_1686_ = game.Players.LocalPlayer.Character
	L_1687_ = game.Players.LocalPlayer
	return
end

L_1_.callback_233 = function(L_1688_arg0)
	local L_1689_, L_1690_, L_1691_
	L_1689_ = getgenv()
	L_1689_.JumpPowerValue = L_1688_arg0
	L_1689_ = game.Players.LocalPlayer.Character
	L_1690_ = game.Players.LocalPlayer
	if not game.Players.LocalPlayer.Character then
		return
	end
	L_1689_ = game.Players.LocalPlayer.Character:FindFirstChild("Humanoid")
	L_1690_ = game.Players.LocalPlayer.Character
	L_1691_ = "Humanoid"
	if not game.Players.LocalPlayer.Character:FindFirstChild("Humanoid") then
		return
	end
	L_1689_ = game.Players.LocalPlayer.Character.Humanoid
	L_1689_.JumpPower = L_1688_arg0
	L_1690_ = game.Players.LocalPlayer.Character
	L_1691_ = game.Players.LocalPlayer
	return
end

L_1_.callback_234 = function(L_1692_arg0)
	local L_1693_
	L_1693_ = game.Workspace
	L_1693_.Gravity = L_1692_arg0
	return
end

L_1_.callback_235 = function()
	local L_1694_, L_1695_, L_1696_, L_1697_, L_1698_
	L_1694_ = game.Players.LocalPlayer.Character
	L_1695_ = game.Players.LocalPlayer
	if not game.Players.LocalPlayer.Character then
		return
	end
	L_1695_ = L_1694_:FindFirstChild("Humanoid")
	L_1696_ = L_1694_
	L_1697_ = "Humanoid"
	if not L_1694_:FindFirstChild("Humanoid") then
		return
	end
	L_1695_ = L_1694_.Humanoid
	L_1695_.MaxHealth = 100
	L_1695_ = L_1694_.Humanoid
	L_1695_.Health = 100
	L_1694_.Humanoid:SetStateEnabled(Enum.HumanoidStateType.Dead, true)
	L_1695_ = L_1694_.Humanoid.SetStateEnabled
	L_1696_ = L_1694_.Humanoid
	L_1697_ = Enum.HumanoidStateType.Dead
	L_1698_ = true
	return
end

L_1_.callback_236 = function(L_1699_arg0)
	local L_1700_, L_1701_
	L_1700_ = getgenv()
	L_1700_.GodModeEnabled = L_1699_arg0
	if L_1699_arg0 then
		return
	end
	pcall(L_1_.callback_235)
	L_1700_ = pcall
	L_1701_ = L_1_.callback_235
	return
end

L_1_.callback_237 = function()
	local L_1702_, L_1703_, L_1704_, L_1705_, L_1706_, L_1707_, L_1708_, L_1709_, L_1710_, L_1711_
	L_1702_ = upvalue_0
	L_1710_ = false
	L_1711_ = (upvalue_0 == false)
	if not (upvalue_0 == false) then
		wait(0.21)
		return
	end
	L_1702_ = game.Players.LocalPlayer.Character
	L_1703_ = game.Players.LocalPlayer
	L_1710_ = nil
	L_1711_ = (game.Players.LocalPlayer.Character == nil)
	if (game.Players.LocalPlayer.Character == nil) then
		wait(0.21)
		return
	end
	L_1702_ = pairs
	L_1703_ = game.Players.LocalPlayer.Character.GetDescendants
	L_1704_ = game.Players.LocalPlayer.Character
	for L_1712_forvar0, L_1713_forvar1 in pairs(game.Players.LocalPlayer.Character:GetDescendants()) do
		L_1707_ = L_1713_forvar1:IsA("BasePart")
		L_1708_ = L_1713_forvar1
		L_1709_ = "BasePart"
		if L_1713_forvar1:IsA("BasePart") then
			L_1707_ = L_1713_forvar1.CanCollide
			if L_1713_forvar1.CanCollide then
				L_1707_ = L_1713_forvar1.Name
				L_1708_ = floatName
				L_1711_ = (L_1713_forvar1.Name == floatName)
				if not (L_1713_forvar1.Name == floatName) then
					L_1713_forvar1.CanCollide = false
					L_1707_ = false
				end
			end
		end
	end
	wait(0.21)
	return
end

L_1_.enableNoclip = function()
	local L_1714_, L_1715_, L_1716_, L_1717_, L_1718_
	upvalue_0 = false
	L_1715_ = game:GetService("RunService").Stepped
	upvalue_1 = L_1715_:Connect(L_1_.callback_237)
	return
end

L_1_.disableNoclip = function()
	local L_1719_, L_1720_
	L_1719_ = upvalue_0
	if not upvalue_0 then
		upvalue_1 = true
		return
	end
	upvalue_0:Disconnect()
	L_1719_ = upvalue_0.Disconnect
	L_1720_ = upvalue_0
	upvalue_1 = true
	return
end

L_1_.callback_240 = function(L_1721_arg0)
	local L_1722_
	if not L_1721_arg0 then
		clip()
		return
	else
		noclip()
		return
	end
end

L_1_.callback_241 = function()
	local L_1723_, L_1724_, L_1725_
	L_1723_ = upvalue_0
	if not upvalue_0 then
		return
	end
	L_1723_ = game.Players.LocalPlayer.Character
	L_1724_ = game.Players.LocalPlayer
	if not game.Players.LocalPlayer.Character then
		return
	end
	L_1723_ = game.Players.LocalPlayer.Character:FindFirstChild("Humanoid")
	L_1724_ = game.Players.LocalPlayer.Character
	L_1725_ = "Humanoid"
	if not game.Players.LocalPlayer.Character:FindFirstChild("Humanoid") then
		return
	end
	game.Players.LocalPlayer.Character.Humanoid:ChangeState("Jumping")
	L_1723_ = game.Players.LocalPlayer.Character.Humanoid.ChangeState
	L_1724_ = game.Players.LocalPlayer.Character.Humanoid
	L_1725_ = "Jumping"
	return
end

L_1_.callback_242 = function(L_1726_arg0)
	local L_1727_, L_1728_, L_1729_, L_1730_
	upvalue_0 = L_1726_arg0
	L_1727_ = game:GetService("UserInputService").JumpRequest
	L_1727_:Connect(L_1_.callback_241)
	return
end

L_1_.callback_243 = function(L_1731_arg0)
	local L_1732_
	L_1732_ = game.Workspace.CurrentCamera
	L_1732_.FieldOfView = L_1731_arg0
	return
end

L_1_.callback_244 = function(L_1733_arg0)
	local L_1734_, L_1735_, L_1736_, L_1737_, L_1738_
	if not L_1733_arg0 then
		L_1734_ = game.Lighting
		L_1734_.Ambient = Color3.fromRGB(128, 128, 128)
		L_1734_ = game.Lighting
		L_1734_.GlobalShadows = true
		return
	else
		L_1734_ = game.Lighting
		L_1734_.Ambient = Color3.new(1, 1, 1)
		L_1734_ = game.Lighting
		L_1734_.ColorShift_Bottom = Color3.new(1, 1, 1)
		L_1734_ = game.Lighting
		L_1734_.ColorShift_Top = Color3.new(1, 1, 1)
		L_1734_ = game.Lighting
		L_1734_.GlobalShadows = false
		return
	end
end

L_1_.callback_245 = function(L_1739_arg0)
	local L_1740_, L_1741_, L_1742_, L_1743_, L_1744_, L_1745_, L_1746_, L_1747_, L_1748_, L_1749_, L_1750_
	if not L_1739_arg0 then
		L_1740_ = pairs
		L_1741_ = upvalue_1
		for L_1751_forvar0, L_1752_forvar1 in pairs(upvalue_1) do
			if L_1752_forvar1 then
				L_1745_ = L_1752_forvar1.Parent
				if L_1752_forvar1.Parent then
					L_1752_forvar1:Destroy()
					L_1745_ = L_1752_forvar1.Destroy
					L_1746_ = L_1752_forvar1
				end
			end
		end
		upvalue_1 = {}
		return
	else
		L_1740_ = pairs
		L_1741_ = game.Players.GetPlayers
		L_1742_ = game.Players
		for L_1753_forvar0, L_1754_forvar1 in pairs(game.Players:GetPlayers()) do
			L_1745_ = game.Players.LocalPlayer
			L_1750_ = (L_1754_forvar1 == game.Players.LocalPlayer)
			if not (L_1754_forvar1 == game.Players.LocalPlayer) then
				L_1745_ = L_1754_forvar1.Character
				if L_1754_forvar1.Character then
					L_1745_ = Instance.new("Highlight")
					L_1745_.Parent = L_1754_forvar1.Character
					L_1745_.FillColor = upvalue_0.AccentColor
					L_1745_.OutlineColor = upvalue_0.SecondaryColor
					L_1745_.FillTransparency = 0.5
					table.insert(upvalue_1, L_1745_)
					L_1746_ = table.insert
					L_1747_ = upvalue_1
					L_1748_ = L_1745_
				end
			end
		end
		return
	end
end

L_1_.callback_246 = function()
	local L_1755_, L_1756_, L_1757_, L_1758_, L_1759_, L_1760_
	L_1755_ = upvalue_0.Character.HumanoidRootPart
	L_1755_.Size = Vector3.new(_G.HeadSize, _G.HeadSize, _G.HeadSize)
	L_1755_ = upvalue_0.Character.HumanoidRootPart
	L_1755_.Transparency = 0.7
	L_1755_ = upvalue_0.Character.HumanoidRootPart
	L_1755_.BrickColor = BrickColor.new("Really blue")
	L_1755_ = upvalue_0.Character.HumanoidRootPart
	L_1755_.Material = "Neon"
	L_1755_ = upvalue_0.Character.HumanoidRootPart
	L_1755_.CanCollide = false
	return
end

L_1_.callback_247 = function()
	local L_1761_, L_1762_, L_1763_, L_1764_, L_1765_, L_1766_, L_1767_, L_1768_, L_1769_, L_1770_, L_1771_, L_1772_, L_1773_
	L_1761_ = _G.Disabled
	L_1762_ = _G
	if not _G.Disabled then
		return
	end
	L_1762_ = game:GetService("Players")
	L_1762_, L_1763_ = L_1762_:GetPlayers()
	for L_1774_forvar0, L_1775_forvar1 in next, L_1762_.GetPlayers, L_1762_ do
		L_1766_ = L_1775_forvar1.Name
		L_1767_ = game:GetService("Players").LocalPlayer.Name
		L_1768_ = game:GetService("Players").LocalPlayer
		L_1769_ = game:GetService("Players")
		L_1770_ = game
		L_1771_ = "Players"
		L_1773_ = (L_1775_forvar1.Name == game:GetService("Players").LocalPlayer.Name)
		if not (L_1775_forvar1.Name == game:GetService("Players").LocalPlayer.Name) then
			pcall(L_1_.callback_246)
			L_1766_ = pcall
			L_1767_ = L_1_.callback_246
		end
	end
	return
end

L_1_.callback_248 = function(L_1776_arg0)
	local L_1777_, L_1778_, L_1779_, L_1780_
	L_1777_ = _G
	L_1777_.HeadSize = L_1776_arg0
	L_1777_ = _G
	L_1777_.Disabled = true
	L_1777_ = game:GetService("RunService").RenderStepped
	L_1777_:connect(L_1_.callback_247)
	return
end

L_1_.callback_249 = function()
	local L_1781_, L_1782_, L_1783_, L_1784_, L_1785_, L_1786_
	L_1781_ = Instance.new("HopperBin", game.Players.LocalPlayer.Backpack)
	L_1781_.BinType = "Clone"
	L_1782_ = Instance.new("HopperBin", game.Players.LocalPlayer.Backpack)
	L_1782_.BinType = "Hammer"
	L_1783_ = Instance.new("HopperBin", game.Players.LocalPlayer.Backpack)
	L_1783_.BinType = "Grab"
	return
end

L_1_.callback_250 = function()
	local L_1787_ = game.Players:GetPlayers()
	if #L_1787_ <= 1 then
		return
	end
	local L_1788_
	repeat
		L_1788_ = L_1787_[math.random(1, #L_1787_)]
	until L_1788_.Name ~= game.Players.LocalPlayer.Name
	local L_1789_ = L_1788_.Character and L_1788_.Character:FindFirstChild("HumanoidRootPart")
	local L_1790_ = game.Players.LocalPlayer.Character
	local L_1791_ = L_1790_ and L_1790_:FindFirstChild("HumanoidRootPart")
	if not L_1789_ or not L_1791_ then
		return
	end
	L_1791_.CFrame = L_1789_.CFrame * CFrame.new(0, 0, 3)
end

L_1_.callback_251 = function()
	local L_1792_ = game:GetService("TeleportService")
	L_1792_:TeleportToPlaceInstance(
        game.PlaceId,
        game.JobId,
        game.Players.LocalPlayer
    )
end

L_1_.callback_252 = function(L_1793_arg0)
	local L_1794_ = L_1793_arg0 and ("&cursor=" .. L_1793_arg0) or ""
	local L_1795_ = game:HttpGet(upvalue_0 .. L_1794_)
	return upvalue_1:JSONDecode(L_1795_)
end

L_1_.callback_253 = function()
	local L_1796_ = game:GetService("HttpService")
	local L_1797_ = game:GetService("TeleportService")
	local L_1798_ = game.PlaceId
	local L_1799_ = "https://games.roblox.com/v1/games/"
        .. tostring(L_1798_)
        .. "/servers/Public?sortOrder=Asc&limit=100"
	local L_1800_
	local L_1801_
	repeat
		local L_1802_ = L_1800_ and ("&cursor=" .. L_1800_) or ""
		local L_1803_ = L_1796_:JSONDecode(game:HttpGet(L_1799_ .. L_1802_))
		L_1801_ = L_1803_.data[1]
		L_1800_ = L_1803_.nextPageCursor
	until L_1801_
	L_1797_:TeleportToPlaceInstance(
        L_1798_,
        L_1801_.id,
        game.Players.LocalPlayer
    )
end

L_1_.callback_254 = function(L_1804_arg0)
	local L_1805_ = getconnections or get_signal_cons
	if not L_1804_arg0 or not L_1805_ then
		return
	end
	for L_1806_forvar0, L_1807_forvar1 in pairs(L_1805_(game.Players.LocalPlayer.Idled)) do
		if L_1807_forvar1.Disable then
			L_1807_forvar1:Disable()
		elseif L_1807_forvar1.Disconnect then
			L_1807_forvar1:Disconnect()
		end
	end
end

L_1_.callback_255 = function()
	local L_1808_, L_1809_, L_1810_, L_1811_, L_1812_, L_1813_, L_1814_, L_1815_, L_1816_, L_1817_, L_1818_, L_1819_, L_1820_, L_1821_, L_1822_, L_1823_
	local L_1824_
	L_1810_ = game:GetService("UserInputService")
	L_1808_ = upvalue_0.FOVRadius
	L_1809_ = nil
	L_1810_ = L_1810_:GetMouseLocation()
	L_1811_ = pairs
	L_1812_ = game.Players.GetPlayers
	L_1813_ = game.Players
	for L_1825_forvar0, L_1826_forvar1 in pairs(game.Players:GetPlayers()) do
		L_1816_ = game.Players.LocalPlayer
		L_1824_ = (L_1826_forvar1 == game.Players.LocalPlayer)
		if not (L_1826_forvar1 == game.Players.LocalPlayer) then
			L_1816_ = L_1826_forvar1.Character
			if L_1826_forvar1.Character then
				L_1816_ = L_1826_forvar1.Character:FindFirstChild(upvalue_0.TargetPart)
				L_1817_ = L_1826_forvar1.Character
				L_1818_ = upvalue_0.TargetPart
				L_1819_ = upvalue_0
				if L_1826_forvar1.Character:FindFirstChild(upvalue_0.TargetPart) then
					L_1816_ = L_1826_forvar1.Character:FindFirstChild("Humanoid")
					L_1817_ = L_1826_forvar1.Character
					L_1818_ = "Humanoid"
					if L_1826_forvar1.Character:FindFirstChild("Humanoid") then
						L_1816_ = L_1826_forvar1.Character.Humanoid.Health
						L_1817_ = 0
						L_1818_ = L_1826_forvar1.Character
						L_1824_ = (0 < L_1826_forvar1.Character.Humanoid.Health)
						if 0 < L_1826_forvar1.Character.Humanoid.Health then
							L_1816_ = upvalue_0.TeamCheck
							L_1817_ = upvalue_0
							if upvalue_0.TeamCheck then
								L_1816_ = L_1826_forvar1.Team
								L_1817_ = game.Players.LocalPlayer.Team
								L_1818_ = game.Players.LocalPlayer
								L_1824_ = (L_1826_forvar1.Team == game.Players.LocalPlayer.Team)
								if L_1826_forvar1.Team == game.Players.LocalPlayer.Team then
								end
							end
							L_1816_ = game.Workspace.CurrentCamera.WorldToViewportPoint
							L_1817_ = game.Workspace.CurrentCamera
							L_1818_ = L_1826_forvar1.Character[upvalue_0.TargetPart].Position
							L_1819_ = L_1826_forvar1.Character[upvalue_0.TargetPart]
							L_1820_ = L_1826_forvar1.Character
							L_1821_ = upvalue_0.TargetPart
							L_1822_ = upvalue_0
							L_1816_, L_1817_ = game.Workspace.CurrentCamera:WorldToViewportPoint(L_1826_forvar1.Character[upvalue_0.TargetPart].Position)
							if L_1817_ then
								L_1818_ = (Vector2.new(L_1816_.X, L_1816_.Y) - L_1810_).Magnitude
								L_1819_ = (Vector2.new(L_1816_.X, L_1816_.Y) - L_1810_)
								L_1820_ = Vector2.new(L_1816_.X, L_1816_.Y)
								L_1821_ = L_1816_.X
								L_1822_ = L_1816_.Y
								L_1824_ = ((Vector2.new(L_1816_.X, L_1816_.Y) - L_1810_).Magnitude < L_1808_)
								if (Vector2.new(L_1816_.X, L_1816_.Y) - L_1810_).Magnitude < L_1808_ then
									L_1808_ = L_1818_
									L_1809_ = L_1826_forvar1
								end
							end
						end
					end
				end
			end
		end
	end
	return L_1809_
end

L_1_.callback_256 = function()
	local L_1827_, L_1828_, L_1829_, L_1830_, L_1831_, L_1832_, L_1833_, L_1834_, L_1835_
	L_1827_ = upvalue_0.ShowFOV
	L_1828_ = upvalue_0
	if not upvalue_0.ShowFOV then
		L_1827_ = upvalue_1
		L_1827_.Visible = false
		L_1828_ = false
	else
		L_1828_ = game:GetService("UserInputService")
		L_1827_ = upvalue_1
		L_1827_.Position = L_1828_:GetMouseLocation()
		L_1827_ = upvalue_1
		L_1827_.Radius = upvalue_0.FOVRadius
		L_1827_ = upvalue_1
		L_1827_.Visible = true
		L_1828_ = true
		L_1829_ = upvalue_0
		L_1830_ = "UserInputService"
	end
	L_1827_ = upvalue_0.Enabled
	L_1828_ = upvalue_0
	if not upvalue_0.Enabled then
		return
	end
	L_1827_ = game:GetService("UserInputService")
	L_1827_ = L_1827_:IsMouseButtonPressed(Enum.UserInputType.MouseButton2)
	L_1828_ = L_1827_
	L_1829_ = Enum.UserInputType.MouseButton2
	if not L_1827_:IsMouseButtonPressed(Enum.UserInputType.MouseButton2) then
		return
	end
	L_1827_ = upvalue_2()
	if not upvalue_2() then
		return
	end
	L_1828_ = L_1827_.Character
	if not L_1827_.Character then
		return
	end
	L_1828_ = L_1827_.Character:FindFirstChild(upvalue_0.TargetPart)
	L_1829_ = L_1827_.Character
	L_1830_ = upvalue_0.TargetPart
	L_1831_ = upvalue_0
	if not L_1827_.Character:FindFirstChild(upvalue_0.TargetPart) then
		return
	end
	L_1828_ = game.Workspace.CurrentCamera
	L_1828_.CFrame = game.Workspace.CurrentCamera.CFrame:Lerp(CFrame.new(game.Workspace.CurrentCamera.CFrame.Position, L_1827_.Character[upvalue_0.TargetPart].Position), upvalue_0.Smoothness)
	L_1829_ = CFrame.new(game.Workspace.CurrentCamera.CFrame.Position, L_1827_.Character[upvalue_0.TargetPart].Position)
	L_1830_ = game.Workspace.CurrentCamera.CFrame:Lerp(CFrame.new(game.Workspace.CurrentCamera.CFrame.Position, L_1827_.Character[upvalue_0.TargetPart].Position), upvalue_0.Smoothness)
	L_1831_ = game.Workspace.CurrentCamera.CFrame
	L_1832_ = CFrame.new(game.Workspace.CurrentCamera.CFrame.Position, L_1827_.Character[upvalue_0.TargetPart].Position)
	L_1833_ = upvalue_0.Smoothness
	L_1834_ = upvalue_0
	L_1835_ = upvalue_0
	return
end

L_1_.callback_257 = function(L_1836_arg0)
	local L_1837_
	L_1837_ = upvalue_0
	L_1837_.Enabled = L_1836_arg0
	return
end

L_1_.callback_258 = function(L_1838_arg0)
	local L_1839_
	L_1839_ = upvalue_0
	L_1839_.ShowFOV = L_1838_arg0
	return
end

L_1_.callback_259 = function(L_1840_arg0)
	local L_1841_
	L_1841_ = upvalue_0
	L_1841_.FOVRadius = L_1840_arg0
	return
end

L_1_.callback_260 = function(L_1842_arg0)
	local L_1843_, L_1844_
	L_1843_ = upvalue_0
	L_1843_.Smoothness = (L_1842_arg0 / 100)
	return
end

L_1_.callback_261 = function(L_1845_arg0)
	local L_1846_
	L_1846_ = upvalue_0
	L_1846_.TeamCheck = L_1845_arg0
	return
end

L_1_.callback_262 = function()
	local L_1847_, L_1848_, L_1849_, L_1850_, L_1851_, L_1852_
	upvalue_0:Notify("Test", "Notifications are working!", 4, false)
	return
end

L_1_.callback_263 = function()
	local L_1853_, L_1854_, L_1855_, L_1856_, L_1857_, L_1858_
	upvalue_0:Notify("Premium Alert", "This is how premium alerts look!", 4, true)
	return
end

L_1_.callback_264 = function()
	local L_1859_, L_1860_, L_1861_, L_1862_, L_1863_, L_1864_, L_1865_, L_1866_, L_1867_, L_1868_, L_1869_
	L_1859_ = pairs
	L_1860_ = getgenv
	for L_1870_forvar0, L_1871_forvar1 in pairs(getgenv()) do
		L_1864_ = type(L_1870_forvar0)
		L_1865_ = L_1870_forvar0
		L_1868_ = "string"
		L_1869_ = (type(L_1870_forvar0) == "string")
		if type(L_1870_forvar0) == "string" then
			L_1864_ = L_1870_forvar0:sub(1, 3)
			L_1865_ = L_1870_forvar0
			L_1866_ = 1
			L_1867_ = 3
			L_1868_ = "_h_"
			L_1869_ = (L_1870_forvar0:sub(1, 3) == "_h_")
			if L_1870_forvar0:sub(1, 3) == "_h_" then
				L_1864_ = typeof(L_1871_forvar1)
				L_1865_ = L_1871_forvar1
				L_1868_ = "Instance"
				L_1869_ = (typeof(L_1871_forvar1) == "Instance")
				if typeof(L_1871_forvar1) == "Instance" then
					L_1864_ = L_1871_forvar1:IsA("ScreenGui")
					L_1865_ = L_1871_forvar1
					L_1866_ = "ScreenGui"
					if L_1871_forvar1:IsA("ScreenGui") then
						L_1864_ = L_1871_forvar1:FindFirstChild("Main")
						L_1865_ = L_1871_forvar1
						L_1866_ = "Main"
						if L_1871_forvar1:FindFirstChild("Main") then
							L_1864_.BackgroundTransparency = upvalue_0
							L_1865_ = upvalue_0
						end
					end
				end
			end
		end
	end
	return
end

L_1_.callback_265 = function(L_1872_arg0)
	local L_1873_, L_1874_
	upvalue_0 = (L_1872_arg0 / 10)
	pcall(L_1_.callback_264)
	return
end

L_1_.callback_266 = function()
	local L_1875_, L_1876_, L_1877_, L_1878_, L_1879_, L_1880_
	L_1875_ = setclipboard
	if not setclipboard then
		upvalue_0:Notify("Copied!", "Discord link copied.", 3, false)
		return
	end
	setclipboard("https://discord.gg/getsnowy")
	L_1875_ = setclipboard
	L_1876_ = "https://discord.gg/getsnowy"
	upvalue_0:Notify("Copied!", "Discord link copied.", 3, false)
	return
end

L_1_.callback_267 = function()
	local L_1881_, L_1882_
	upvalue_0:Destroy()
	return
end

L_1_.callback_268 = function()
	local L_1883_, L_1884_, L_1885_, L_1886_, L_1887_, L_1888_, L_1889_, L_1890_, L_1891_, L_1892_, L_1893_
	L_1883_ = pairs
	L_1884_ = getgenv
	for L_1894_forvar0, L_1895_forvar1 in pairs(getgenv()) do
		L_1888_ = type(L_1894_forvar0)
		L_1889_ = L_1894_forvar0
		L_1892_ = "string"
		L_1893_ = (type(L_1894_forvar0) == "string")
		if type(L_1894_forvar0) == "string" then
			L_1888_ = L_1894_forvar0:sub(1, 3)
			L_1889_ = L_1894_forvar0
			L_1890_ = 1
			L_1891_ = 3
			L_1892_ = "_h_"
			L_1893_ = (L_1894_forvar0:sub(1, 3) == "_h_")
			if L_1894_forvar0:sub(1, 3) == "_h_" then
				L_1888_ = typeof(L_1895_forvar1)
				L_1889_ = L_1895_forvar1
				L_1892_ = "Instance"
				L_1893_ = (typeof(L_1895_forvar1) == "Instance")
				if typeof(L_1895_forvar1) == "Instance" then
					L_1888_ = L_1895_forvar1:IsA("ScreenGui")
					L_1889_ = L_1895_forvar1
					L_1890_ = "ScreenGui"
					if L_1895_forvar1:IsA("ScreenGui") then
						pcall(L_1_.callback_267)
						L_1888_ = getgenv()
						L_1888_[L_1894_forvar0] = nil
						L_1889_ = nil
					end
				end
			end
		end
	end
	return
end

L_1_.callback_269 = function()
	local L_1896_, L_1897_, L_1898_, L_1899_, L_1900_, L_1901_
	pcall(L_1_.callback_268)
	task.wait(0.1)
	L_1896_ = getgenv()
	L_1896_.Window = upvalue_0.CreateLib(upvalue_1.HubName, "Midnight")
	upvalue_2:Notify("Reloaded", "Hub UI restarted.", 3, false)
	return
end

L_1_.NewToggle_270 = function()
	local L_1902_
	return
end

L_1_.NewSection_271 = function()
	local L_1903_
	return upvalue_0
end

L_1_.NewSection_272 = function()
	local L_1904_
	return upvalue_0
end

L_1_.callback_273 = function()
	local L_1905_, L_1906_, L_1907_, L_1908_
	L_1906_ = {}
	L_1906_.NewToggle = L_1_.NewToggle_270
	L_1906_.NewButton = L_1_.NewToggle_270
	L_1906_.NewSlider = L_1_.NewToggle_270
	L_1906_.NewDropdown = L_1_.NewToggle_270
	L_1906_.NewLabel = L_1_.NewToggle_270
	L_1906_.NewPremiumToggle = L_1_.NewToggle_270
	L_1906_.NewPremiumButton = L_1_.NewToggle_270
	L_1906_.NewPremiumSlider = L_1_.NewToggle_270
	L_1906_.NewPremiumDropdown = L_1_.NewToggle_270
	L_1906_.NewSection = L_1_.NewSection_271
	L_1907_ = {}
	L_1907_.NewSection = L_1_.NewSection_272
	L_1907_.HideTabButton = L_1_.NewToggle_270
	L_1907_.Select = L_1_.NewToggle_270
	L_1908_ = {}
	L_1908_.SetVisible = L_1_.NewToggle_270
	L_1907_.ActualTab = L_1908_
	return L_1907_
end

L_1_.callback_274 = function()
	local L_1909_, L_1910_, L_1911_, L_1912_, L_1913_
	upvalue_0:Notify(upvalue_1, upvalue_2, 3)
	return
end

L_1_.callback_275 = function(L_1914_arg0, L_1915_arg1)
	local L_1916_, L_1917_
	pcall(L_1_.callback_274)
	return
end

L_1_.callback_276 = function(L_1918_arg0)
	local L_1919_, L_1920_, L_1921_
	L_1919_ = L_1918_arg0
	if not (L_1918_arg0) then
		L_1919_ = upvalue_0
	end
	L_1918_arg0 = L_1919_
	L_1919_ = L_1919_.Character
	if L_1919_.Character then
		return L_1919_
	end
	L_1919_ = upvalue_1:FindFirstChild(L_1918_arg0.Name)
	L_1920_ = upvalue_1
	L_1921_ = L_1918_arg0.Name
	return L_1919_
end

L_1_.callback_277 = function(L_1922_arg0)
	local L_1923_, L_1924_, L_1925_, L_1926_, L_1927_
	L_1924_ = L_1922_arg0
	L_1925_ = L_1922_arg0
	if not (L_1922_arg0) then
		L_1925_ = upvalue_0
	end
	L_1923_ = L_1925_.Character
	L_1924_ = L_1925_
	if not (L_1925_.Character) then
		L_1923_ = upvalue_1:FindFirstChild(L_1924_.Name)
		L_1925_ = upvalue_1:FindFirstChild(L_1924_.Name)
		L_1926_ = upvalue_1
		L_1927_ = L_1924_.Name
	end
	L_1924_ = L_1923_
	if not L_1923_ then
		return L_1924_
	end
	L_1924_ = L_1923_:FindFirstChild("HumanoidRootPart")
	L_1925_ = L_1923_
	L_1926_ = "HumanoidRootPart"
	if L_1923_:FindFirstChild("HumanoidRootPart") then
		return L_1924_
	end
	L_1924_ = L_1923_:FindFirstChild("UpperTorso")
	L_1925_ = L_1923_
	L_1926_ = "UpperTorso"
	if L_1923_:FindFirstChild("UpperTorso") then
		return L_1924_
	end
	L_1924_ = L_1923_.PrimaryPart
	return L_1924_
end

L_1_.callback_278 = function(L_1928_arg0)
	local L_1929_, L_1930_, L_1931_, L_1932_, L_1933_
	L_1930_ = L_1928_arg0
	L_1931_ = L_1928_arg0
	if not (L_1928_arg0) then
		L_1931_ = upvalue_0
	end
	L_1929_ = L_1931_.Character
	L_1930_ = L_1931_
	if not (L_1931_.Character) then
		L_1929_ = upvalue_1:FindFirstChild(L_1930_.Name)
		L_1931_ = upvalue_1:FindFirstChild(L_1930_.Name)
		L_1932_ = upvalue_1
		L_1933_ = L_1930_.Name
	end
	L_1930_ = L_1929_
	if not L_1929_ then
		return L_1930_
	end
	L_1930_ = L_1929_:FindFirstChildOfClass("Humanoid")
	L_1931_ = L_1929_
	L_1932_ = "Humanoid"
	return L_1930_
end

L_1_.callback_279 = function()
	local L_1934_, L_1935_, L_1936_, L_1937_, L_1938_, L_1939_
	L_1934_ = upvalue_0.Team
	L_1935_ = upvalue_0
	if not upvalue_0.Team then
		return
	end
	L_1934_ = upvalue_1.Team
	L_1935_ = upvalue_1
	if not upvalue_1.Team then
		return
	end
	L_1935_ = upvalue_0.Team
	L_1936_ = upvalue_1.Team
	L_1937_ = upvalue_1
	L_1939_ = (upvalue_0.Team == upvalue_1.Team)
	if not (upvalue_0.Team == upvalue_1.Team) then
		L_1934_ = true
	else
		L_1934_ = false
	end
	return L_1934_
end

L_1_.callback_280 = function(L_1940_arg0)
	local L_1941_, L_1942_, L_1943_, L_1944_
	L_1941_ = upvalue_0
	L_1944_ = (L_1940_arg0 == upvalue_0)
	if L_1940_arg0 == upvalue_0 then
		return false
	end
	L_1941_ = RivFlags.TeamCheck
	if RivFlags.TeamCheck then
		pcall(L_1_.callback_279)
		return true
	else
		return true
	end
end

L_1_.callback_281 = function(L_1945_arg0)
	local L_1946_, L_1947_, L_1948_, L_1949_, L_1950_, L_1951_, L_1952_, L_1953_, L_1954_, L_1955_, L_1956_, L_1957_, L_1958_, L_1959_, L_1960_, L_1961_
	local L_1962_, L_1963_, L_1964_, L_1965_
	L_1946_ = nil
	L_1947_ = L_1945_arg0
	if not (L_1945_arg0) then
		L_1947_ = RivFlags.FOVRadius
	end
	L_1948_ = upvalue_0.CurrentCamera
	L_1949_ = upvalue_0
	if not (upvalue_0.CurrentCamera) then
		return nil
	end
	L_1949_ = ipairs
	L_1950_ = upvalue_1.GetPlayers
	L_1951_ = upvalue_1
	for L_1966_forvar0, L_1967_forvar1 in ipairs(upvalue_1:GetPlayers()) do
		L_1955_ = upvalue_2
		L_1965_ = (L_1967_forvar1 == upvalue_2)
		if not (L_1967_forvar1 == upvalue_2) then
			L_1955_ = RivFlags.TeamCheck
			if RivFlags.TeamCheck then
				pcall(L_1_.callback_279)
				L_1954_ = true
				L_1955_ = pcall
				L_1956_ = L_1_.callback_279
			else
				L_1954_ = true
			end
		else
			L_1954_ = false
		end
		if L_1954_ then
			L_1954_ = L_1967_forvar1.Character
			if L_1967_forvar1.Character then
				L_1956_ = L_1967_forvar1
				L_1957_ = L_1967_forvar1
				if not (L_1967_forvar1) then
					L_1957_ = upvalue_2
				end
				L_1955_ = L_1957_.Character
				L_1956_ = L_1957_
				if not (L_1957_.Character) then
					L_1955_ = upvalue_0:FindFirstChild(L_1956_.Name)
					L_1957_ = upvalue_0:FindFirstChild(L_1956_.Name)
					L_1958_ = upvalue_0
					L_1959_ = L_1956_.Name
				end
				L_1954_ = L_1955_
				if L_1955_ then
					L_1954_ = L_1955_:FindFirstChild("HumanoidRootPart")
					L_1956_ = L_1955_:FindFirstChild("HumanoidRootPart")
					L_1957_ = L_1955_
					L_1958_ = "HumanoidRootPart"
					if not (L_1955_:FindFirstChild("HumanoidRootPart")) then
						L_1954_ = L_1955_:FindFirstChild("UpperTorso")
						L_1956_ = L_1955_:FindFirstChild("UpperTorso")
						L_1957_ = L_1955_
						L_1958_ = "UpperTorso"
						if not (L_1955_:FindFirstChild("UpperTorso")) then
							L_1954_ = L_1955_.PrimaryPart
						end
					end
				end
				L_1957_ = L_1967_forvar1
				L_1958_ = L_1967_forvar1
				if not (L_1967_forvar1) then
					L_1958_ = upvalue_2
				end
				L_1956_ = L_1958_.Character
				L_1957_ = L_1958_
				if not (L_1958_.Character) then
					L_1956_ = upvalue_0:FindFirstChild(L_1957_.Name)
					L_1958_ = upvalue_0:FindFirstChild(L_1957_.Name)
					L_1959_ = upvalue_0
					L_1960_ = L_1957_.Name
				end
				L_1955_ = L_1956_
				if L_1956_ then
					L_1955_ = L_1956_:FindFirstChildOfClass("Humanoid")
					L_1957_ = L_1956_:FindFirstChildOfClass("Humanoid")
					L_1958_ = L_1956_
					L_1959_ = "Humanoid"
				end
				if L_1954_ then
					if L_1955_ then
						L_1956_ = L_1955_.Health
						L_1957_ = 0
						L_1965_ = (0 < L_1955_.Health)
						if 0 < L_1955_.Health then
							L_1956_ = L_1948_.WorldToViewportPoint
							L_1957_ = L_1948_
							L_1958_ = L_1954_.Position
							L_1956_, L_1957_ = L_1948_:WorldToViewportPoint(L_1954_.Position)
							if L_1957_ then
								L_1958_ = upvalue_3:GetMouseLocation()
								L_1959_ = (Vector2.new(L_1956_.X, L_1956_.Y) - upvalue_3:GetMouseLocation()).Magnitude
								L_1960_ = (Vector2.new(L_1956_.X, L_1956_.Y) - upvalue_3:GetMouseLocation())
								L_1961_ = Vector2.new(L_1956_.X, L_1956_.Y)
								L_1962_ = L_1956_.X
								L_1963_ = L_1956_.Y
								L_1965_ = ((Vector2.new(L_1956_.X, L_1956_.Y) - upvalue_3:GetMouseLocation()).Magnitude < L_1947_)
								if (Vector2.new(L_1956_.X, L_1956_.Y) - upvalue_3:GetMouseLocation()).Magnitude < L_1947_ then
									L_1946_ = L_1967_forvar1
									L_1947_ = L_1959_
								end
							end
						end
					end
				end
			end
		end
	end
	return L_1946_
end

L_1_.callback_282 = function()
	local L_1968_, L_1969_, L_1970_, L_1971_, L_1972_, L_1973_, L_1974_, L_1975_, L_1976_, L_1977_, L_1978_
	L_1968_ = upvalue_0()
	if not upvalue_0() then
		return
	end
	L_1969_ = L_1968_.Character
	if not L_1968_.Character then
		return
	end
	L_1969_ = L_1968_.Character:FindFirstChild(RivFlags.AimPart)
	L_1970_ = L_1968_.Character
	L_1971_ = RivFlags.AimPart
	if not (L_1968_.Character:FindFirstChild(RivFlags.AimPart)) then
		L_1971_ = L_1968_
		L_1972_ = L_1968_
		if not (L_1968_) then
			L_1972_ = upvalue_1
		end
		L_1970_ = L_1972_.Character
		L_1971_ = L_1972_
		if not (L_1972_.Character) then
			L_1970_ = upvalue_2:FindFirstChild(L_1971_.Name)
			L_1972_ = upvalue_2:FindFirstChild(L_1971_.Name)
			L_1973_ = upvalue_2
			L_1974_ = L_1971_.Name
		end
		L_1969_ = L_1970_
		if L_1970_ then
			L_1969_ = L_1970_:FindFirstChild("HumanoidRootPart")
			L_1971_ = L_1970_:FindFirstChild("HumanoidRootPart")
			L_1972_ = L_1970_
			L_1973_ = "HumanoidRootPart"
			if not (L_1970_:FindFirstChild("HumanoidRootPart")) then
				L_1969_ = L_1970_:FindFirstChild("UpperTorso")
				L_1971_ = L_1970_:FindFirstChild("UpperTorso")
				L_1972_ = L_1970_
				L_1973_ = "UpperTorso"
				if not (L_1970_:FindFirstChild("UpperTorso")) then
					L_1969_ = L_1970_.PrimaryPart
				end
			end
		end
	end
	if not L_1969_ then
		return
	end
	L_1970_ = upvalue_2.CurrentCamera
	L_1970_.CFrame = upvalue_2.CurrentCamera.CFrame:Lerp(CFrame.lookAt(upvalue_2.CurrentCamera.CFrame.Position, L_1969_.Position), (1 / math.max(1, RivFlags.Smoothness)))
	L_1971_ = CFrame.lookAt(upvalue_2.CurrentCamera.CFrame.Position, L_1969_.Position)
	L_1972_ = upvalue_2.CurrentCamera.CFrame:Lerp(CFrame.lookAt(upvalue_2.CurrentCamera.CFrame.Position, L_1969_.Position), (1 / math.max(1, RivFlags.Smoothness)))
	L_1973_ = upvalue_2.CurrentCamera.CFrame
	L_1974_ = CFrame.lookAt(upvalue_2.CurrentCamera.CFrame.Position, L_1969_.Position)
	L_1975_ = (1 / math.max(1, RivFlags.Smoothness))
	L_1976_ = math.max(1, RivFlags.Smoothness)
	L_1977_ = 1
	L_1978_ = RivFlags.Smoothness
	return
end

L_1_.callback_283 = function()
	local L_1979_, L_1980_, L_1981_, L_1982_, L_1983_
	L_1979_ = upvalue_0
	if not upvalue_0 then
		return
	end
	L_1979_ = upvalue_0.name
	L_1980_ = upvalue_0
	L_1982_ = "Rivals"
	L_1983_ = (upvalue_0.name == "Rivals")
	if not (upvalue_0.name == "Rivals") then
		return
	end
	L_1979_ = RivFlags.Aimbot
	if not (RivFlags.Aimbot) then
		return
	end
	L_1979_ = RivFlags.RequireRMB
	if not RivFlags.RequireRMB then
		pcall(L_1_.callback_282)
		return
	end
	L_1979_ = upvalue_1:IsMouseButtonPressed(Enum.UserInputType.MouseButton2)
	L_1980_ = upvalue_1
	L_1981_ = Enum.UserInputType.MouseButton2
	if upvalue_1:IsMouseButtonPressed(Enum.UserInputType.MouseButton2) then
		pcall(L_1_.callback_282)
		return
	else
		return
	end
end

L_1_.callback_284 = function()
	local L_1984_, L_1985_, L_1986_, L_1987_, L_1988_, L_1989_, L_1990_, L_1991_, L_1992_, L_1993_, L_1994_, L_1995_
	L_1984_ = ipairs
	L_1985_ = upvalue_0.GetPlayers
	L_1986_ = upvalue_0
	for L_1996_forvar0, L_1997_forvar1 in ipairs(upvalue_0:GetPlayers()) do
		L_1990_ = upvalue_1
		L_1995_ = (L_1997_forvar1 == upvalue_1)
		if not (L_1997_forvar1 == upvalue_1) then
			L_1990_ = RivFlags.TeamCheck
			if RivFlags.TeamCheck then
				pcall(L_1_.callback_279)
				L_1989_ = true
				L_1990_ = pcall
				L_1991_ = L_1_.callback_279
			else
				L_1989_ = true
			end
		else
			L_1989_ = false
		end
		if L_1989_ then
			L_1989_ = L_1997_forvar1.Character
			if L_1997_forvar1.Character then
				L_1989_ = L_1997_forvar1.Character:FindFirstChild("Head")
				L_1990_ = L_1997_forvar1.Character
				L_1991_ = "Head"
				if L_1997_forvar1.Character:FindFirstChild("Head") then
					L_1989_.Size = Vector3.new(RivFlags.HitboxSize, RivFlags.HitboxSize, RivFlags.HitboxSize)
					L_1989_.Transparency = RivFlags.HitboxTransparency
					L_1989_.CanCollide = false
					L_1990_ = false
					L_1991_ = RivFlags.HitboxSize
					L_1992_ = RivFlags.HitboxSize
					L_1993_ = RivFlags.HitboxSize
				end
			end
		end
	end
	return
end

L_1_.callback_285 = function()
	local L_1998_, L_1999_, L_2000_, L_2001_
	L_1998_ = upvalue_0
	if not upvalue_0 then
		return
	end
	L_1998_ = upvalue_0.name
	L_1999_ = upvalue_0
	L_2000_ = "Rivals"
	L_2001_ = (upvalue_0.name == "Rivals")
	if not (upvalue_0.name == "Rivals") then
		return
	end
	L_1998_ = RivFlags.HitboxExpander
	if RivFlags.HitboxExpander then
		pcall(L_1_.callback_284)
		return
	else
		return
	end
end

L_1_.callback_286 = function()
	local L_2002_, L_2003_, L_2004_, L_2005_, L_2006_, L_2007_, L_2008_, L_2009_, L_2010_, L_2011_, L_2012_, L_2013_
	L_2004_ = nil
	L_2005_ = nil
	if true then
		L_2005_ = upvalue_0
	end
	L_2003_ = L_2005_.Character
	L_2004_ = L_2005_
	if not (L_2005_.Character) then
		L_2003_ = upvalue_1:FindFirstChild(L_2004_.Name)
		L_2005_ = upvalue_1:FindFirstChild(L_2004_.Name)
		L_2006_ = upvalue_1
		L_2007_ = L_2004_.Name
	end
	L_2002_ = L_2003_
	if L_2003_ then
		L_2002_ = L_2003_:FindFirstChild("HumanoidRootPart")
		L_2004_ = L_2003_:FindFirstChild("HumanoidRootPart")
		L_2005_ = L_2003_
		L_2006_ = "HumanoidRootPart"
		if not (L_2003_:FindFirstChild("HumanoidRootPart")) then
			L_2002_ = L_2003_:FindFirstChild("UpperTorso")
			L_2004_ = L_2003_:FindFirstChild("UpperTorso")
			L_2005_ = L_2003_
			L_2006_ = "UpperTorso"
			if not (L_2003_:FindFirstChild("UpperTorso")) then
				L_2002_ = L_2003_.PrimaryPart
			end
		end
	end
	L_2005_ = nil
	L_2006_ = nil
	if true then
		L_2006_ = upvalue_0
	end
	L_2004_ = L_2006_.Character
	L_2005_ = L_2006_
	if not (L_2006_.Character) then
		L_2004_ = upvalue_1:FindFirstChild(L_2005_.Name)
		L_2006_ = upvalue_1:FindFirstChild(L_2005_.Name)
		L_2007_ = upvalue_1
		L_2008_ = L_2005_.Name
	end
	L_2003_ = L_2004_
	if L_2004_ then
		L_2003_ = L_2004_:FindFirstChildOfClass("Humanoid")
		L_2005_ = L_2004_:FindFirstChildOfClass("Humanoid")
		L_2006_ = L_2004_
		L_2007_ = "Humanoid"
	end
	if not L_2002_ then
		return
	end
	if not L_2003_ then
		return
	end
	L_2004_ = RivFlags.CFrameSpeed
	if RivFlags.CFrameSpeed then
		L_2004_ = L_2003_.MoveDirection.Magnitude
		L_2005_ = 0
		L_2013_ = (0 < L_2003_.MoveDirection.Magnitude)
		if 0 < L_2003_.MoveDirection.Magnitude then
			L_2004_ = (RivFlags.SpeedValue - 16)
			L_2005_ = 0
			L_2013_ = (0 < (RivFlags.SpeedValue - 16))
			if 0 < (RivFlags.SpeedValue - 16) then
				L_2002_.CFrame = (L_2002_.CFrame + ((L_2003_.MoveDirection * L_2004_) * upvalue_2))
				L_2005_ = (L_2002_.CFrame + ((L_2003_.MoveDirection * L_2004_) * upvalue_2))
				L_2006_ = L_2002_.CFrame
				L_2007_ = ((L_2003_.MoveDirection * L_2004_) * upvalue_2)
				L_2008_ = (L_2003_.MoveDirection * L_2004_)
				L_2009_ = upvalue_2
			end
		end
	end
	L_2004_ = RivFlags.CFrameFly
	if not RivFlags.CFrameFly then
		return
	end
	L_2004_ = upvalue_1.CurrentCamera
	L_2005_ = Vector3.new()
	L_2006_ = upvalue_3:IsKeyDown(Enum.KeyCode.W)
	L_2007_ = upvalue_3
	L_2008_ = Enum.KeyCode.W
	if upvalue_3:IsKeyDown(Enum.KeyCode.W) then
		L_2005_ = (L_2005_ + L_2004_.CFrame.LookVector)
		L_2006_ = L_2004_.CFrame.LookVector
		L_2007_ = L_2004_.CFrame
	end
	L_2006_ = upvalue_3:IsKeyDown(Enum.KeyCode.S)
	L_2007_ = upvalue_3
	L_2008_ = Enum.KeyCode.S
	if upvalue_3:IsKeyDown(Enum.KeyCode.S) then
		L_2005_ = (L_2005_ - L_2004_.CFrame.LookVector)
		L_2006_ = L_2004_.CFrame.LookVector
		L_2007_ = L_2004_.CFrame
	end
	L_2006_ = upvalue_3:IsKeyDown(Enum.KeyCode.A)
	L_2007_ = upvalue_3
	L_2008_ = Enum.KeyCode.A
	if upvalue_3:IsKeyDown(Enum.KeyCode.A) then
		L_2005_ = (L_2005_ - L_2004_.CFrame.RightVector)
		L_2006_ = L_2004_.CFrame.RightVector
		L_2007_ = L_2004_.CFrame
	end
	L_2006_ = upvalue_3:IsKeyDown(Enum.KeyCode.D)
	L_2007_ = upvalue_3
	L_2008_ = Enum.KeyCode.D
	if upvalue_3:IsKeyDown(Enum.KeyCode.D) then
		L_2005_ = (L_2005_ + L_2004_.CFrame.RightVector)
		L_2006_ = L_2004_.CFrame.RightVector
		L_2007_ = L_2004_.CFrame
	end
	L_2006_ = L_2005_.Magnitude
	L_2007_ = 0
	L_2013_ = (0 < L_2005_.Magnitude)
	if not (0 < L_2005_.Magnitude) then
		return
	end
	L_2002_.CFrame = (L_2002_.CFrame + ((L_2005_.Unit * RivFlags.FlySpeed) * upvalue_2))
	L_2006_ = (L_2002_.CFrame + ((L_2005_.Unit * RivFlags.FlySpeed) * upvalue_2))
	L_2007_ = L_2002_.CFrame
	L_2008_ = ((L_2005_.Unit * RivFlags.FlySpeed) * upvalue_2)
	L_2009_ = (L_2005_.Unit * RivFlags.FlySpeed)
	L_2010_ = upvalue_2
	L_2011_ = RivFlags.FlySpeed
	return
end

L_1_.callback_287 = function(L_2014_arg0)
	local L_2015_, L_2016_, L_2017_, L_2018_
	L_2015_ = upvalue_0
	if not upvalue_0 then
		return
	end
	L_2015_ = upvalue_0.name
	L_2016_ = upvalue_0
	L_2017_ = "Rivals"
	L_2018_ = (upvalue_0.name == "Rivals")
	if (upvalue_0.name == "Rivals") then
		pcall(L_1_.callback_286)
		return
	else
		return
	end
end

L_1_.callback_288 = function()
	local L_2019_, L_2020_, L_2021_, L_2022_, L_2023_, L_2024_, L_2025_, L_2026_, L_2027_
	L_2020_ = nil
	L_2021_ = nil
	if true then
		L_2021_ = upvalue_0
	end
	L_2019_ = L_2021_.Character
	L_2020_ = L_2021_
	if not (L_2021_.Character) then
		L_2019_ = upvalue_1:FindFirstChild(L_2020_.Name)
		L_2021_ = upvalue_1:FindFirstChild(L_2020_.Name)
		L_2022_ = upvalue_1
		L_2023_ = L_2020_.Name
	end
	if not L_2019_ then
		return
	end
	L_2020_ = ipairs
	L_2021_ = L_2019_.GetDescendants
	L_2022_ = L_2019_
	for L_2028_forvar0, L_2029_forvar1 in ipairs(L_2019_:GetDescendants()) do
		L_2025_ = L_2029_forvar1:IsA("BasePart")
		L_2026_ = L_2029_forvar1
		L_2027_ = "BasePart"
		if L_2029_forvar1:IsA("BasePart") then
			L_2029_forvar1.CanCollide = false
			L_2025_ = false
		end
	end
	return
end

L_1_.callback_289 = function()
	local L_2030_, L_2031_, L_2032_, L_2033_
	L_2030_ = upvalue_0
	if not upvalue_0 then
		return
	end
	L_2030_ = upvalue_0.name
	L_2031_ = upvalue_0
	L_2032_ = "Rivals"
	L_2033_ = (upvalue_0.name == "Rivals")
	if not (upvalue_0.name == "Rivals") then
		return
	end
	L_2030_ = RivFlags.Noclip
	if not RivFlags.Noclip then
		return
	end
	pcall(L_1_.callback_288)
	L_2030_ = pcall
	L_2031_ = L_1_.callback_288
	return
end

L_1_.callback_290 = function()
	local L_2034_, L_2035_, L_2036_, L_2037_, L_2038_, L_2039_, L_2040_, L_2041_
	L_2034_ = upvalue_0
	if not upvalue_0 then
		return
	end
	L_2034_ = upvalue_0.name
	L_2035_ = upvalue_0
	L_2040_ = "Rivals"
	L_2041_ = (upvalue_0.name == "Rivals")
	if not (upvalue_0.name == "Rivals") then
		return
	end
	L_2034_ = RivFlags.InfJump
	if not RivFlags.InfJump then
		return
	end
	L_2036_ = nil
	L_2037_ = nil
	if true then
		L_2037_ = upvalue_1
	end
	L_2035_ = L_2037_.Character
	L_2036_ = L_2037_
	if not (L_2037_.Character) then
		L_2035_ = upvalue_2:FindFirstChild(L_2036_.Name)
		L_2037_ = upvalue_2:FindFirstChild(L_2036_.Name)
		L_2038_ = upvalue_2
		L_2039_ = L_2036_.Name
	end
	L_2034_ = L_2035_
	if L_2035_ then
		L_2034_ = L_2035_:FindFirstChildOfClass("Humanoid")
		L_2036_ = L_2035_:FindFirstChildOfClass("Humanoid")
		L_2037_ = L_2035_
		L_2038_ = "Humanoid"
	end
	if not L_2034_ then
		return
	end
	L_2034_:ChangeState(Enum.HumanoidStateType.Jumping)
	L_2035_ = L_2034_.ChangeState
	L_2036_ = L_2034_
	L_2037_ = Enum.HumanoidStateType.Jumping
	return
end

L_1_.callback_291 = function(L_2042_arg0)
	local L_2043_, L_2044_, L_2045_, L_2046_
	L_2043_ = RivFlags
	L_2043_.Aimbot = L_2042_arg0
	if not L_2042_arg0 then
		L_2043_ = "Aimbot Disabled"
	else
		L_2043_ = "Aimbot Enabled"
	end
	pcall(L_1_.callback_274)
	return
end

L_1_.callback_292 = function(L_2047_arg0)
	local L_2048_
	L_2048_ = RivFlags
	L_2048_.SilentAim = L_2047_arg0
	return
end

L_1_.callback_293 = function(L_2049_arg0)
	local L_2050_
	L_2050_ = RivFlags
	L_2050_.SilentWallbang = L_2049_arg0
	return
end

L_1_.callback_294 = function(L_2051_arg0)
	local L_2052_
	L_2052_ = RivFlags
	L_2052_.Ragebot = L_2051_arg0
	return
end

L_1_.callback_295 = function(L_2053_arg0)
	local L_2054_
	L_2054_ = RivFlags
	L_2054_.FOVRadius = L_2053_arg0
	return
end

L_1_.callback_296 = function(L_2055_arg0)
	local L_2056_
	L_2056_ = RivFlags
	L_2056_.Smoothness = L_2055_arg0
	return
end

L_1_.callback_297 = function(L_2057_arg0)
	local L_2058_
	L_2058_ = RivFlags
	L_2058_.AimPart = L_2057_arg0
	return
end

L_1_.callback_298 = function(L_2059_arg0)
	local L_2060_
	L_2060_ = RivFlags
	L_2060_.RequireRMB = L_2059_arg0
	return
end

L_1_.callback_299 = function(L_2061_arg0)
	local L_2062_
	L_2062_ = RivFlags
	L_2062_.VisibleOnly = L_2061_arg0
	return
end

L_1_.callback_300 = function(L_2063_arg0)
	local L_2064_
	L_2064_ = RivFlags
	L_2064_.TeamCheck = L_2063_arg0
	return
end

L_1_.callback_301 = function(L_2065_arg0)
	local L_2066_
	L_2066_ = RivFlags
	L_2066_.HitboxExpander = L_2065_arg0
	return
end

L_1_.callback_302 = function(L_2067_arg0)
	local L_2068_
	L_2068_ = RivFlags
	L_2068_.HitboxSize = L_2067_arg0
	return
end

L_1_.callback_303 = function(L_2069_arg0)
	local L_2070_, L_2071_, L_2072_, L_2073_
	L_2070_ = RivFlags
	L_2070_.NoRecoil = L_2069_arg0
	if not L_2069_arg0 then
		L_2070_ = "Disabled"
	else
		L_2070_ = "No Recoil Enabled"
	end
	pcall(L_1_.callback_274)
	return
end

L_1_.callback_304 = function(L_2074_arg0)
	local L_2075_, L_2076_, L_2077_, L_2078_
	L_2075_ = RivFlags
	L_2075_.NoSpread = L_2074_arg0
	if not L_2074_arg0 then
		L_2075_ = "Disabled"
	else
		L_2075_ = "No Spread Enabled"
	end
	pcall(L_1_.callback_274)
	return
end

L_1_.callback_305 = function(L_2079_arg0)
	local L_2080_
	L_2080_ = RivFlags
	L_2080_.ESPEnabled = L_2079_arg0
	return
end

L_1_.callback_306 = function(L_2081_arg0)
	local L_2082_
	L_2082_ = RivFlags
	L_2082_.ESPBoxType = L_2081_arg0
	return
end

L_1_.callback_307 = function(L_2083_arg0)
	local L_2084_
	L_2084_ = RivFlags
	L_2084_.ESPName = L_2083_arg0
	return
end

L_1_.callback_308 = function(L_2085_arg0)
	local L_2086_
	L_2086_ = RivFlags
	L_2086_.ESPHealth = L_2085_arg0
	return
end

L_1_.callback_309 = function(L_2087_arg0)
	local L_2088_
	L_2088_ = RivFlags
	L_2088_.ESPDistance = L_2087_arg0
	return
end

L_1_.callback_310 = function(L_2089_arg0)
	local L_2090_
	L_2090_ = RivFlags
	L_2090_.ESPWeapon = L_2089_arg0
	return
end

L_1_.callback_311 = function(L_2091_arg0)
	local L_2092_
	L_2092_ = RivFlags
	L_2092_.ESPTracer = L_2091_arg0
	return
end

L_1_.callback_312 = function(L_2093_arg0)
	local L_2094_
	L_2094_ = RivFlags
	L_2094_.CFrameSpeed = L_2093_arg0
	return
end

L_1_.callback_313 = function(L_2095_arg0)
	local L_2096_
	L_2096_ = RivFlags
	L_2096_.SpeedValue = L_2095_arg0
	return
end

L_1_.callback_314 = function(L_2097_arg0)
	local L_2098_
	L_2098_ = RivFlags
	L_2098_.CFrameFly = L_2097_arg0
	return
end

L_1_.callback_315 = function(L_2099_arg0)
	local L_2100_
	L_2100_ = RivFlags
	L_2100_.Noclip = L_2099_arg0
	return
end

L_1_.callback_316 = function(L_2101_arg0)
	local L_2102_
	L_2102_ = RivFlags
	L_2102_.InfJump = L_2101_arg0
	return
end

L_1_.callback_317 = function()
	local L_2103_, L_2104_, L_2105_, L_2106_, L_2107_, L_2108_, L_2109_, L_2110_, L_2111_
	L_2103_ = upvalue_0(2000)
	L_2104_ = 2000
	if not upvalue_0(2000) then
		pcall(L_1_.callback_274)
		L_2104_ = pcall
		L_2105_ = L_1_.callback_274
		L_2106_ = "Teleport"
		L_2107_ = "No enemy found in range!"
		return
	else
		L_2106_ = L_2103_
		L_2107_ = L_2103_
		if not (L_2103_) then
			L_2107_ = upvalue_1
		end
		L_2105_ = L_2107_.Character
		L_2106_ = L_2107_
		if not (L_2107_.Character) then
			L_2105_ = upvalue_2:FindFirstChild(L_2106_.Name)
			L_2107_ = upvalue_2:FindFirstChild(L_2106_.Name)
			L_2108_ = upvalue_2
			L_2109_ = L_2106_.Name
		end
		L_2104_ = L_2105_
		if L_2105_ then
			L_2104_ = L_2105_:FindFirstChild("HumanoidRootPart")
			L_2106_ = L_2105_:FindFirstChild("HumanoidRootPart")
			L_2107_ = L_2105_
			L_2108_ = "HumanoidRootPart"
			if not (L_2105_:FindFirstChild("HumanoidRootPart")) then
				L_2104_ = L_2105_:FindFirstChild("UpperTorso")
				L_2106_ = L_2105_:FindFirstChild("UpperTorso")
				L_2107_ = L_2105_
				L_2108_ = "UpperTorso"
				if not (L_2105_:FindFirstChild("UpperTorso")) then
					L_2104_ = L_2105_.PrimaryPart
				end
			end
		end
		L_2107_ = nil
		L_2108_ = nil
		if true then
			L_2108_ = upvalue_1
		end
		L_2106_ = L_2108_.Character
		L_2107_ = L_2108_
		if not (L_2108_.Character) then
			L_2106_ = upvalue_2:FindFirstChild(L_2107_.Name)
			L_2108_ = upvalue_2:FindFirstChild(L_2107_.Name)
			L_2109_ = upvalue_2
			L_2110_ = L_2107_.Name
		end
		L_2105_ = L_2106_
		if L_2106_ then
			L_2105_ = L_2106_:FindFirstChild("HumanoidRootPart")
			L_2107_ = L_2106_:FindFirstChild("HumanoidRootPart")
			L_2108_ = L_2106_
			L_2109_ = "HumanoidRootPart"
			if not (L_2106_:FindFirstChild("HumanoidRootPart")) then
				L_2105_ = L_2106_:FindFirstChild("UpperTorso")
				L_2107_ = L_2106_:FindFirstChild("UpperTorso")
				L_2108_ = L_2106_
				L_2109_ = "UpperTorso"
				if not (L_2106_:FindFirstChild("UpperTorso")) then
					L_2105_ = L_2106_.PrimaryPart
				end
			end
		end
		if not L_2104_ then
			return
		end
		if not L_2105_ then
			return
		else
			L_2105_.CFrame = (L_2104_.CFrame * CFrame.new(0, 0, 4))
			pcall(L_1_.callback_274)
			return
		end
	end
end

L_1_.callback_318 = function(L_2112_arg0)
	local L_2113_
	L_2113_ = RivFlags
	L_2113_.StealthMode = L_2112_arg0
	return
end

L_1_.callback_319 = function(L_2114_arg0)
	local L_2115_
	L_2115_ = RivFlags
	L_2115_.PauseOnDamage = L_2114_arg0
	return
end

L_1_.callback_320 = function(L_2116_arg0)
	local L_2117_
	L_2117_ = RivFlags
	L_2117_.AutoRequeue = L_2116_arg0
	return
end

L_1_.callback_321 = function()
	local L_2118_, L_2119_, L_2120_, L_2121_
	upvalue_0:Teleport(17625359962, upvalue_1)
	return
end

L_1_.callback_322 = function()
	local L_2122_, L_2123_, L_2124_, L_2125_
	pcall(L_1_.callback_274)
	pcall(L_1_.callback_321)
	return
end

L_1_.main = function(...)
	local L_2126_, L_2127_, L_2128_, L_2129_, L_2130_, L_2131_, L_2132_, L_2133_, L_2134_, L_2135_, L_2136_, L_2137_, L_2138_, L_2139_, L_2140_, L_2141_
	local L_2142_, L_2143_, L_2144_, L_2145_, L_2146_, L_2147_, L_2148_, L_2149_, L_2150_, L_2151_, L_2152_, L_2153_, L_2154_, L_2155_, L_2156_, L_2157_
	local L_2158_, L_2159_, L_2160_, L_2161_, L_2162_, L_2163_, L_2164_, L_2165_, L_2166_, L_2167_, L_2168_, L_2169_, L_2170_, L_2171_, L_2172_, L_2173_
	local L_2174_, L_2175_, L_2176_, L_2177_, L_2178_, L_2179_, L_2180_, L_2181_, L_2182_, L_2183_, L_2184_, L_2185_, L_2186_, L_2187_, L_2188_, L_2189_
	local L_2190_, L_2191_, L_2192_
	L_2126_ = getgenv()
	L_2126_._premTag = L_1_.premiumTag
	L_2126_._isPremiumUser = L_1_.isPremiumUser
	L_2126_ = getgenv()
	L_2127_ = getgenv().__SnowyUIRuntime

	L_2127_ = {}

	L_2127_.corner = L_1_.createCorner
	L_2127_.stroke = L_1_.createStroke
	L_2127_.gradient = L_1_.createGradient
	L_2127_.shadow = L_1_.createShadow
	L_2127_.tw = L_1_.tween
	L_2126_.__SnowyUIRuntime = L_2127_
	L_2126_.corner = L_2127_.corner
	L_2126_.stroke = L_2127_.stroke
	L_2126_.gradient = L_2127_.gradient
	L_2126_.shadow = L_2127_.shadow
	L_2126_.tw = L_2127_.tw
	L_2126_ = getgenv()._nagPremium
	L_2127_ = getgenv()
	L_2128_ = L_2127_.tw

	L_2127_ = getgenv()
	L_2127_._nagPremium = L_1_._nagPremium
	L_2126_ = L_1_._nagPremium

	pcall(L_1_.callback_14)
	pcall(L_1_.callback_12)
	pcall(L_1_.callback_12)
	pcall(L_1_.callback_12)
	pcall(L_1_.callback_12)
	warn("[SnowyHub] Anti-detect stub installed (Delta-compatible).")
	pcall(L_1_.WindowWidth)
	L_2133_ = {}
	L_2133_.WindowWidth = 720
	L_2133_.WindowHeight = 520
	L_2133_.HeaderHeight = 48
	L_2133_.TabBarHeight = 44
	L_2133_.BannerHeight = 62
	L_2133_.Radius = 24
	L_2133_.RadiusSm = 16
	L_2133_.RadiusXs = 12
	L_2133_.RadiusPill = 999
	L_2133_.BgPrimary = Color3.fromRGB(18, 24, 64)
	L_2133_.BgSecondary = Color3.fromRGB(24, 32, 85)
	L_2133_.BgCard = Color3.fromRGB(35, 45, 110)
	L_2133_.BgCardHover = Color3.fromRGB(45, 60, 140)
	L_2133_.BgCardActive = Color3.fromRGB(40, 65, 160)
	L_2133_.BgHeader = Color3.fromRGB(14, 18, 50)
	L_2133_.BgInput = Color3.fromRGB(20, 28, 70)
	L_2133_.BgTabBar = Color3.fromRGB(20, 28, 70)
	L_2133_.Accent = Color3.fromRGB(85, 213, 254)
	L_2133_.AccentBright = Color3.fromRGB(135, 235, 255)
	L_2133_.AccentDark = Color3.fromRGB(50, 170, 220)
	L_2133_.AccentDim = Color3.fromRGB(30, 90, 130)
	L_2133_.AccentGlow = Color3.fromRGB(180, 240, 255)
	L_2133_.AccentSoft = Color3.fromRGB(100, 200, 255)
	L_2133_.Premium = Color3.fromRGB(255, 200, 50)
	L_2133_.PremiumDark = Color3.fromRGB(180, 130, 20)
	L_2133_.PremiumDim = Color3.fromRGB(50, 40, 10)
	L_2133_.BannerBg = Color3.fromRGB(15, 45, 100)
	L_2133_.BannerActive = Color3.fromRGB(25, 70, 150)
	L_2133_.TextPrimary = Color3.fromRGB(230, 245, 255)
	L_2133_.TextSecondary = Color3.fromRGB(160, 190, 230)
	L_2133_.TextMuted = Color3.fromRGB(80, 110, 160)
	L_2133_.TextDim = Color3.fromRGB(50, 70, 110)
	L_2133_.Border = Color3.fromRGB(30, 45, 100)
	L_2133_.BorderHi = Color3.fromRGB(60, 100, 220)
	L_2133_.Success = Color3.fromRGB(50, 220, 120)
	L_2133_.Error = Color3.fromRGB(255, 55, 75)
	L_2133_.Warning = Color3.fromRGB(255, 180, 50)
	L_2135_ = {}
	L_2135_.name = "BedWars"
	L_2135_.icon = utf8.char(128719)
	L_2136_ = {}
	L_2136_[1] = "bedwars"
	L_2136_[2] = "bed wars"
	L_2135_.aliases = L_2136_
	L_2136_ = {}
	L_2136_[1] = 6872265039
	L_2136_[2] = 6872274481
	L_2135_.placeIds = L_2136_
	L_2135_.features = 69
	L_2135_.img = "rbxassetid://6034281798"
	L_2136_ = {}
	L_2136_.name = "BedWars"
	L_2136_.icon = utf8.char(128719)
	L_2137_ = {}
	L_2137_[1] = "bedwars"
	L_2137_[2] = "bed wars"
	L_2136_.aliases = L_2137_
	L_2137_ = {}
	L_2137_[1] = 6872265039
	L_2137_[2] = 6872274481
	L_2136_.placeIds = L_2137_
	L_2136_.features = 69
	L_2136_.img = "rbxassetid://6034281798"
	L_2137_ = {}
	L_2137_.name = "Taxi Boss"
	L_2137_.icon = utf8.char(128661)
	L_2138_ = {}
	L_2138_[1] = "taxi boss"
	L_2138_[2] = "taxiboss"
	L_2138_[3] = "taxi"
	L_2137_.aliases = L_2138_
	L_2138_ = {}
	L_2138_[1] = 7305309231
	L_2137_.placeIds = L_2138_
	L_2137_.features = 40
	L_2137_.img = "rbxassetid://6034281798"
	L_2138_ = {}
	L_2138_.name = "BloxStrike"
	L_2138_.icon = utf8.char(127919)
	L_2139_ = {}
	L_2139_[1] = "bloxstrike"
	L_2139_[2] = "blox strike"
	L_2138_.aliases = L_2139_
	L_2139_ = {}
	L_2139_[1] = 114234929420007
	L_2138_.placeIds = L_2139_
	L_2138_.features = 45
	L_2138_.img = "rbxassetid://6034281798"
	L_2139_ = {}
	L_2139_.name = "Anime Expeditions"
	L_2139_.icon = utf8.char(9889)
	L_2140_ = {}
	L_2140_[1] = "anime expeditions"
	L_2140_[2] = "expeditions"
	L_2140_[3] = "anime expedition"
	L_2139_.aliases = L_2140_
	L_2140_ = {}
	L_2140_[1] = 84515722934860
	L_2139_.placeIds = L_2140_
	L_2139_.features = 40
	L_2139_.img = "rbxassetid://6034281798"
	L_2140_ = {}
	L_2140_.name = "+1 Pickaxe Swing Escape"
	L_2140_.icon = utf8.char(9935)
	L_2141_ = {}
	L_2141_[1] = "+1 pickaxe swing escape"
	L_2141_[2] = "pickaxe swing escape"
	L_2141_[3] = "pickaxe escape"
	L_2141_[4] = "pickaxe swing"
	L_2141_[5] = "pickaxe"
	L_2140_.aliases = L_2141_
	L_2141_ = {}
	L_2141_[1] = 82554996468034
	L_2140_.placeIds = L_2141_
	L_2140_.features = 20
	L_2140_.img = "rbxassetid://6034281798"
	L_2141_ = {}
	L_2141_.name = "Animal Hospital"
	L_2141_.icon = utf8.char(127973)
	L_2142_ = {}
	L_2142_[1] = "animal hospital"
	L_2142_[2] = "anomaly hospital"
	L_2142_[3] = "hospital"
	L_2141_.aliases = L_2142_
	L_2142_ = {}
	L_2142_[1] = 78515283254292
	L_2141_.placeIds = L_2142_
	L_2141_.features = 15
	L_2141_.img = "rbxassetid://6034281798"
	L_2142_ = {}
	L_2142_.name = "Merge a Nuke"
	L_2142_.icon = utf8.char(128163)
	L_2143_ = {}
	L_2143_[1] = "merge a nuke"
	L_2143_[2] = "merge a nuke!"
	L_2143_[3] = "nuke tycoon"
	L_2143_[4] = "merge nuke"
	L_2142_.aliases = L_2143_
	L_2143_ = {}
	L_2143_[1] = 128784467030899
	L_2143_[2] = 136423403372990
	L_2142_.placeIds = L_2143_
	L_2142_.features = 15
	L_2142_.img = "rbxassetid://6034281798"
	L_2143_ = {}
	L_2143_.name = "Arsenal"
	L_2143_.icon = utf8.char(127919)
	L_2144_ = {}
	L_2144_[1] = 286090429
	L_2144_[2] = 2133507413
	L_2143_.placeIds = L_2144_
	L_2143_.features = 20
	L_2143_.img = "rbxassetid://6034281798"
	L_2144_ = {}
	L_2144_.name = "Jujutsu Shenanigans"
	L_2144_.icon = utf8.char(9889)
	L_2145_ = {}
	L_2145_[1] = "jujutsu shenanigans"
	L_2145_[2] = "jujutsu"
	L_2145_[3] = "shenanigans"
	L_2144_.aliases = L_2145_
	L_2145_ = {}
	L_2145_[1] = 9391468976
	L_2144_.placeIds = L_2145_
	L_2145_ = {}
	L_2145_[1] = 3508322461
	L_2144_.universeIds = L_2145_
	L_2144_.features = 15
	L_2144_.img = "rbxassetid://6034281798"
	L_2145_ = {}
	L_2145_.name = "Abyss"
	L_2145_.icon = utf8.char(127754)
	L_2146_ = {}
	L_2146_[1] = 8841631016
	L_2146_[2] = 6499213745
	L_2145_.placeIds = L_2146_
	L_2145_.features = 22
	L_2145_.img = "rbxassetid://6034281798"
	L_2146_ = {}
	L_2146_.name = "Jailbreak"
	L_2146_.icon = utf8.char(128680)
	L_2147_ = {}
	L_2147_[1] = 606849621
	L_2146_.placeIds = L_2147_
	L_2146_.features = 50
	L_2146_.img = "rbxassetid://6034281798"
	L_2147_ = {}
	L_2147_.name = "Tsunami"
	L_2147_.icon = utf8.char(127754)
	L_2148_ = {}
	L_2148_[1] = 2456517837
	L_2148_[2] = 7456917583
	L_2147_.placeIds = L_2148_
	L_2147_.features = 30
	L_2147_.img = "rbxassetid://6034281798"
	L_2148_ = {}
	L_2148_.name = "Sniper Duels"
	L_2148_.icon = utf8.char(127919)
	L_2149_ = {}
	L_2149_[1] = 2957674229
	L_2149_[2] = 3519873232
	L_2149_[3] = 109397169461300
	L_2148_.placeIds = L_2149_
	L_2148_.features = 12
	L_2148_.img = "rbxassetid://6034281798"
	L_2149_ = {}
	L_2149_.name = "Swing Obby"
	L_2149_.icon = utf8.char(127906)
	L_2150_ = {}
	L_2150_[1] = 5334680521
	L_2149_.placeIds = L_2150_
	L_2149_.features = 10
	L_2149_.img = "rbxassetid://6034281798"
	L_2150_ = {}
	L_2150_.name = "Brookhaven"
	L_2150_.icon = utf8.char(127968)
	L_2151_ = {}
	L_2151_[1] = 4924922222
	L_2150_.placeIds = L_2151_
	L_2150_.features = 15
	L_2150_.img = "rbxassetid://6034281798"
	L_2134_ = {}
	L_2134_[1] = L_2135_
	L_2134_[2] = L_2136_
	L_2134_[3] = L_2137_
	L_2134_[4] = L_2138_
	L_2134_[5] = L_2139_
	L_2134_[6] = L_2140_
	L_2134_[7] = L_2141_
	L_2134_[8] = L_2142_
	L_2134_[9] = L_2143_
	L_2134_[10] = L_2144_
	L_2134_[11] = L_2145_
	L_2134_[12] = L_2146_
	L_2134_[13] = L_2147_
	L_2134_[14] = L_2148_
	L_2134_[15] = L_2149_
	L_2134_[16] = L_2150_
	L_2135_ = {}
	L_2135_.name = "99 Nights"
	L_2135_.icon = utf8.char(127769)
	L_2136_ = {}
	L_2136_[1] = 13271790403
	L_2136_[2] = 14502339080
	L_2135_.placeIds = L_2136_
	L_2135_.features = 28
	L_2135_.img = "rbxassetid://6034281798"
	L_2136_ = {}
	L_2136_.name = "Blox Fruits"
	L_2136_.icon = utf8.char(127822)
	L_2137_ = {}
	L_2137_[1] = "blox fruits"
	L_2137_[2] = "blox fruit"
	L_2137_[3] = "bloxfruits"
	L_2136_.aliases = L_2137_
	L_2137_ = {}
	L_2137_[1] = 2753915549
	L_2137_[2] = 4442272183
	L_2137_[3] = 7449423635
	L_2136_.placeIds = L_2137_
	L_2136_.features = 18
	L_2136_.img = "rbxassetid://6034281798"
	L_2137_ = {}
	L_2137_.name = "Pet Sim 99"
	L_2137_.icon = utf8.char(128062)
	L_2138_ = {}
	L_2138_[1] = "pet simulator 99"
	L_2138_[2] = "pet sim 99"
	L_2138_[3] = "petsim99"
	L_2137_.aliases = L_2138_
	L_2138_ = {}
	L_2138_[1] = 8737899170
	L_2138_[2] = 15532244896
	L_2138_[3] = 15588347101
	L_2137_.placeIds = L_2138_
	L_2138_ = {}
	L_2138_[1] = 3317771874
	L_2137_.universeIds = L_2138_
	L_2137_.features = 15
	L_2137_.img = "rbxassetid://6034281798"
	L_2138_ = {}
	L_2138_.name = "Bee Swarm"
	L_2138_.icon = utf8.char(128029)
	L_2139_ = {}
	L_2139_[1] = 1537690962
	L_2138_.placeIds = L_2139_
	L_2138_.features = 12
	L_2138_.img = "rbxassetid://6034281798"
	L_2139_ = {}
	L_2139_.name = "SAB"
	L_2139_.icon = utf8.char(129302)
	L_2140_ = {}
	L_2140_[1] = "steal a brainrot"
	L_2140_[2] = "sab"
	L_2139_.aliases = L_2140_
	L_2140_ = {}
	L_2140_[1] = 18668065096
	L_2140_[2] = 1234567890
	L_2140_[3] = 10495922230
	L_2140_[4] = 109983668079237
	L_2139_.placeIds = L_2140_
	L_2140_ = {}
	L_2140_[1] = 109983668079237
	L_2139_.universeIds = L_2140_
	L_2139_.features = 24
	L_2139_.img = "rbxassetid://6034281798"
	L_2140_ = {}
	L_2140_.name = "Ultimate Battlegrounds"
	L_2140_.icon = utf8.char(128298)
	L_2141_ = {}
	L_2141_[1] = 11815767793
	L_2140_.placeIds = L_2141_
	L_2140_.features = 18
	L_2140_.img = "rbxassetid://6034281798"
	L_2141_ = {}
	L_2141_.name = "Strongest Battlegrounds"
	L_2141_.icon = utf8.char(128293)
	L_2142_ = {}
	L_2142_[1] = 10495922230
	L_2141_.placeIds = L_2142_
	L_2141_.features = 15
	L_2141_.img = "rbxassetid://6034281798"
	L_2142_ = {}
	L_2142_.name = "Heroes Battlegrounds"
	L_2142_.icon = utf8.char(129464)
	L_2143_ = {}
	L_2143_[1] = 13076380114
	L_2142_.placeIds = L_2143_
	L_2142_.features = 16
	L_2142_.img = "rbxassetid://6034281798"
	L_2143_ = {}
	L_2143_.name = "Legend Battlegrounds"
	L_2143_.icon = utf8.char(128481)
	L_2144_ = {}
	L_2144_[1] = 15269951959
	L_2143_.placeIds = L_2144_
	L_2143_.features = 18
	L_2143_.img = "rbxassetid://6034281798"
	L_2144_ = {}
	L_2144_.name = "Jump for Brainrots"
	L_2144_.icon = utf8.char(129504)
	L_2145_ = {}
	L_2145_[1] = 139299356663913
	L_2144_.placeIds = L_2145_
	L_2144_.features = 12
	L_2144_.img = "rbxassetid://6034281798"
	L_2145_ = {}
	L_2145_.name = "+1 Jump Brainrot"
	L_2145_.icon = utf8.char(128095)
	L_2146_ = {}
	L_2146_[1] = 121192350097093
	L_2145_.placeIds = L_2146_
	L_2145_.features = 15
	L_2145_.img = "rbxassetid://6034281798"
	L_2146_ = {}
	L_2146_.name = "Grab Ores!"
	L_2146_.icon = utf8.char(9935)
	L_2147_ = {}
	L_2147_[1] = 82806856224736
	L_2146_.placeIds = L_2147_
	L_2146_.features = 45
	L_2146_.img = "rbxassetid://6034281798"
	L_2147_ = {}
	L_2147_.name = "Murderers VS Sheriffs"
	L_2147_.icon = utf8.char(128298)
	L_2148_ = {}
	L_2148_[1] = 135856908115931
	L_2147_.placeIds = L_2148_
	L_2147_.features = 22
	L_2147_.img = "rbxassetid://6034281798"
	L_2148_ = {}
	L_2148_.name = "Sailor Piece"
	L_2148_.icon = utf8.char(9875)
	L_2149_ = {}
	L_2149_[1] = "sailor piece"
	L_2149_[2] = "sailor peace"
	L_2148_.aliases = L_2149_
	L_2149_ = {}
	L_2149_[1] = 77747658251236
	L_2148_.placeIds = L_2149_
	L_2148_.features = 38
	L_2148_.img = "rbxassetid://6034281798"
	L_2149_ = {}
	L_2149_.name = "MM2"
	L_2149_.icon = utf8.char(128481)
	L_2150_ = {}
	L_2150_[1] = "murder mystery 2"
	L_2150_[2] = "mm2"
	L_2149_.aliases = L_2150_
	L_2150_ = {}
	L_2150_[1] = 142823291
	L_2150_[2] = 80005698042109
	L_2149_.placeIds = L_2150_
	L_2149_.features = 40
	L_2149_.img = "rbxassetid://6034281798"
	L_2150_ = {}
	L_2150_.name = "Kick a Lucky Block"
	L_2150_.icon = utf8.char(127808)
	L_2151_ = {}
	L_2151_[1] = "kick a lucky block"
	L_2151_[2] = "lucky block"
	L_2151_[3] = "kick lucky"
	L_2150_.aliases = L_2151_
	L_2151_ = {}
	L_2151_[1] = 16955097151
	L_2151_[2] = 89469502395769
	L_2150_.placeIds = L_2151_
	L_2151_ = {}
	L_2151_[1] = 89469502395769
	L_2150_.universeIds = L_2151_
	L_2150_.features = 30
	L_2150_.img = "rbxassetid://6034281798"
	L_2134_[17] = L_2135_
	L_2134_[18] = L_2136_
	L_2134_[19] = L_2137_
	L_2134_[20] = L_2138_
	L_2134_[21] = L_2139_
	L_2134_[22] = L_2140_
	L_2134_[23] = L_2141_
	L_2134_[24] = L_2142_
	L_2134_[25] = L_2143_
	L_2134_[26] = L_2144_
	L_2134_[27] = L_2145_
	L_2134_[28] = L_2146_
	L_2134_[29] = L_2147_
	L_2134_[30] = L_2148_
	L_2134_[31] = L_2149_
	L_2134_[32] = L_2150_
	L_2135_ = {}
	L_2135_.name = "Rivals"
	L_2135_.icon = utf8.char(128299)
	L_2136_ = {}
	L_2136_[1] = "rivals"
	L_2136_[2] = "rivals fps"
	L_2136_[3] = "matchmaking"
	L_2135_.aliases = L_2136_
	L_2136_ = {}
	L_2136_[1] = 17625359962
	L_2136_[2] = 14721849686
	L_2136_[3] = 117398147513099
	L_2135_.placeIds = L_2136_
	L_2136_ = {}
	L_2136_[1] = 6035872082
	L_2135_.universeIds = L_2136_
	L_2135_.features = 22
	L_2135_.img = "rbxassetid://6034281798"
	L_2136_ = {}
	L_2136_.name = "Speed Keyboard Escape"
	L_2136_.icon = utf8.char(9000)
	L_2137_ = {}
	L_2137_[1] = "speed keyboard escape"
	L_2137_[2] = "keyboard escape"
	L_2137_[3] = "1 speed keyboard escape"
	L_2137_[4] = "escape candy chocolate"
	L_2137_[5] = "1-speed-keyboard-escape"
	L_2137_[6] = "keyboard"
	L_2136_.aliases = L_2137_
	L_2137_ = {}
	L_2137_[1] = 95082159892680
	L_2136_.placeIds = L_2137_
	L_2136_.features = 16
	L_2136_.img = "rbxassetid://6034281798"
	L_2137_ = {}
	L_2137_.name = "Speed Monkey Escape"
	L_2137_.icon = utf8.char(128018)
	L_2138_ = {}
	L_2138_[1] = "speed monkey escape"
	L_2138_[2] = "monkey escape"
	L_2138_[3] = "1 speed monkey escape"
	L_2138_[4] = "monkey"
	L_2137_.aliases = L_2138_
	L_2138_ = {}
	L_2138_[1] = 114697347887839
	L_2137_.placeIds = L_2138_
	L_2137_.features = 20
	L_2137_.img = "rbxassetid://6034281798"
	L_2138_ = {}
	L_2138_.name = "Sell Lemons"
	L_2138_.icon = utf8.char(127819)
	L_2139_ = {}
	L_2139_[1] = "sell lemons"
	L_2139_[2] = "lemon tycoon"
	L_2139_[3] = "lemons"
	L_2138_.aliases = L_2139_
	L_2139_ = {}
	L_2139_[1] = 79268393072444
	L_2138_.placeIds = L_2139_
	L_2138_.features = 14
	L_2138_.img = "rbxassetid://6034281798"
	L_2139_ = {}
	L_2139_.name = "Demonology"
	L_2139_.icon = utf8.char(128123)
	L_2140_ = {}
	L_2140_[1] = "demonology"
	L_2140_[2] = "ghost hunter"
	L_2140_[3] = "demon"
	L_2139_.aliases = L_2140_
	L_2140_ = {}
	L_2140_[1] = 18199615050
	L_2139_.placeIds = L_2140_
	L_2139_.features = 12
	L_2139_.img = "rbxassetid://6034281798"
	L_2140_ = {}
	L_2140_.name = "Grow a Garden 2"
	L_2140_.icon = utf8.char(127793)
	L_2141_ = {}
	L_2141_[1] = "grow a garden 2"
	L_2141_[2] = "grow a garden"
	L_2141_[3] = "gag2"
	L_2141_[4] = "gag 2"
	L_2140_.aliases = L_2141_
	L_2141_ = {}
	L_2141_[1] = 97598239454123
	L_2141_[2] = 1588579651
	L_2141_[3] = 126884695634066
	L_2140_.placeIds = L_2141_
	L_2141_ = {}
	L_2141_[1] = 7436755782
	L_2140_.universeIds = L_2141_
	L_2140_.features = 25
	L_2140_.img = "rbxassetid://6034281798"
	L_2141_ = {}
	L_2141_.name = "Welcome to Bloxburg"
	L_2141_.icon = utf8.char(127968)
	L_2142_ = {}
	L_2142_[1] = "welcome to bloxburg"
	L_2142_[2] = "bloxburg"
	L_2141_.aliases = L_2142_
	L_2142_ = {}
	L_2142_[1] = 185655149
	L_2141_.placeIds = L_2142_
	L_2141_.features = 16
	L_2141_.img = "rbxassetid://6034281798"
	L_2142_ = {}
	L_2142_.name = "Adopt Me"
	L_2142_.icon = utf8.char(128054)
	L_2143_ = {}
	L_2143_[1] = "adopt me"
	L_2143_[2] = "adoptme"
	L_2142_.aliases = L_2143_
	L_2143_ = {}
	L_2143_[1] = 920587237
	L_2142_.placeIds = L_2143_
	L_2142_.features = 12
	L_2142_.img = "rbxassetid://6034281798"
	L_2143_ = {}
	L_2143_.name = "Dandy's World"
	L_2143_.icon = utf8.char(127912)
	L_2144_ = {}
	L_2144_[1] = "dandys world"
	L_2144_[2] = "dandy"
	L_2144_[3] = "dandys"
	L_2143_.aliases = L_2144_
	L_2144_ = {}
	L_2144_[1] = 16267229903
	L_2143_.placeIds = L_2144_
	L_2143_.features = 10
	L_2143_.img = "rbxassetid://6034281798"
	L_2144_ = {}
	L_2144_.name = "Blade Ball"
	L_2144_.icon = utf8.char(128298)
	L_2145_ = {}
	L_2145_[1] = "blade ball"
	L_2145_[2] = "bladeball"
	L_2145_[3] = "bb"
	L_2144_.aliases = L_2145_
	L_2145_ = {}
	L_2145_[1] = 13772394625
	L_2145_[2] = 14777999650
	L_2145_[3] = 15182888200
	L_2144_.placeIds = L_2145_
	L_2144_.features = 25
	L_2144_.img = "rbxassetid://6034281798"
	L_2145_ = {}
	L_2145_.name = "KAT"
	L_2145_.icon = utf8.char(128298)
	L_2146_ = {}
	L_2146_[1] = 621129760
	L_2145_.placeIds = L_2146_
	L_2146_ = {}
	L_2146_[1] = 228028122
	L_2145_.universeIds = L_2146_
	L_2145_.features = 11
	L_2145_.img = "rbxassetid://6034281798"
	L_2146_ = {}
	L_2146_.name = "One Scope"
	L_2146_.icon = utf8.char(127919)
	L_2147_ = {}
	L_2147_[1] = 135648408848758
	L_2146_.placeIds = L_2147_
	L_2146_.features = 7
	L_2146_.img = "rbxassetid://6034281798"
	L_2147_ = {}
	L_2147_.name = "Da Hood"
	L_2147_.icon = utf8.char(127968)
	L_2148_ = {}
	L_2148_[1] = "da hood"
	L_2148_[2] = "dahood"
	L_2148_[3] = "dh"
	L_2147_.aliases = L_2148_
	L_2148_ = {}
	L_2148_[1] = 2788229376
	L_2148_[2] = 105305881594005
	L_2148_[3] = 98343466176190
	L_2148_[4] = 93778920465645
	L_2148_[5] = 129449254792324
	L_2148_[6] = 122120252103378
	L_2148_[7] = 110917236678062
	L_2148_[8] = 130879446158509
	L_2147_.placeIds = L_2148_
	L_2147_.features = 120
	L_2147_.img = "rbxassetid://6034281798"
	L_2148_ = {}
	L_2148_.name = "Evade"
	L_2148_.icon = utf8.char(127939)
	L_2149_ = {}
	L_2149_[1] = "evade"
	L_2149_[2] = "rise"
	L_2148_.aliases = L_2149_
	L_2149_ = {}
	L_2149_[1] = 9872472334
	L_2148_.placeIds = L_2149_
	L_2148_.features = 45
	L_2148_.img = "rbxassetid://6034281798"
	L_2149_ = {}
	L_2149_.name = "Bridge Duel"
	L_2149_.icon = utf8.char(128481)
	L_2150_ = {}
	L_2150_[1] = "bridge duel"
	L_2150_[2] = "bridge duels"
	L_2150_[3] = "uoro"
	L_2149_.aliases = L_2150_
	L_2150_ = {}
	L_2150_[1] = 139566161526375
	L_2149_.placeIds = L_2150_
	L_2149_.features = 35
	L_2149_.img = "rbxassetid://6034281798"
	L_2150_ = {}
	L_2150_.name = "Drain the Lake"
	L_2150_.icon = utf8.char(128167)
	L_2151_ = {}
	L_2151_[1] = "drain the lake"
	L_2151_[2] = "drain lake"
	L_2150_.aliases = L_2151_
	L_2151_ = {}
	L_2151_[1] = 138381251771774
	L_2150_.placeIds = L_2151_
	L_2151_ = {}
	L_2151_[1] = 10267363348
	L_2150_.universeIds = L_2151_
	L_2150_.features = 9
	L_2150_.img = "rbxassetid://6034281798"
	L_2134_[33] = L_2135_
	L_2134_[34] = L_2136_
	L_2134_[35] = L_2137_
	L_2134_[36] = L_2138_
	L_2134_[37] = L_2139_
	L_2134_[38] = L_2140_
	L_2134_[39] = L_2141_
	L_2134_[40] = L_2142_
	L_2134_[41] = L_2143_
	L_2134_[42] = L_2144_
	L_2134_[43] = L_2145_
	L_2134_[44] = L_2146_
	L_2134_[45] = L_2147_
	L_2134_[46] = L_2148_
	L_2134_[47] = L_2149_
	L_2134_[48] = L_2150_
	L_2135_ = {}
	L_2135_.name = "Prison Life"
	L_2135_.icon = utf8.char(128680)
	L_2136_ = {}
	L_2136_[1] = "prison life"
	L_2136_[2] = "prison"
	L_2135_.aliases = L_2136_
	L_2136_ = {}
	L_2136_[1] = 155615604
	L_2135_.placeIds = L_2136_
	L_2136_ = {}
	L_2136_[1] = 73885730
	L_2135_.universeIds = L_2136_
	L_2135_.features = 9
	L_2135_.img = "rbxassetid://6034281798"
	L_2136_ = {}
	L_2136_.name = "Fish It"
	L_2136_.icon = utf8.char(128031)
	L_2137_ = {}
	L_2137_[1] = "fish it"
	L_2137_[2] = "fisch"
	L_2137_[3] = "fishit"
	L_2136_.aliases = L_2137_
	L_2137_ = {}
	L_2137_[1] = 121864768012064
	L_2137_[2] = 16732694052
	L_2137_[3] = 17445763782
	L_2136_.placeIds = L_2137_
	L_2136_.features = 25
	L_2136_.img = "rbxassetid://6034281798"
	L_2137_ = {}
	L_2137_.name = "Forsaken"
	L_2137_.icon = utf8.char(128128)
	L_2138_ = {}
	L_2138_[1] = "forsaken"
	L_2137_.aliases = L_2138_
	L_2138_ = {}
	L_2138_[1] = 18687417158
	L_2137_.placeIds = L_2138_
	L_2137_.features = 20
	L_2137_.img = "rbxassetid://6034281798"
	L_2138_ = {}
	L_2138_.name = "Volley Ball Legends"
	L_2138_.icon = utf8.char(127952)
	L_2151_ = {}
	L_2151_[1] = "volley ball legends"
	L_2151_[2] = "volleyball legends"
	L_2151_[3] = "volleyball"
	L_2151_[4] = "volley ball"
	L_2138_.aliases = L_2151_
	L_2151_ = {}
	L_2151_[1] = 73956553001240
	L_2138_.placeIds = L_2151_
	L_2138_.features = 20
	L_2138_.img = "rbxassetid://6034281798"
	L_2134_[49] = L_2135_
	L_2134_[50] = L_2136_
	L_2134_[51] = L_2137_
	L_2134_[52] = L_2138_
	L_2135_ = getgenv()
	L_2135_.SUPPORTED_GAMES = L_2134_
	L_2126_ = game:GetService("TweenService")
	L_2127_ = game:GetService("UserInputService")
	L_2128_ = game:GetService("RunService")
	L_2129_ = game:GetService("Players")
	L_2130_ = game:GetService("HttpService")
	L_2131_ = game:GetService("CoreGui")
	L_2132_ = game:GetService("Players").LocalPlayer
	L_2135_ = nil
	L_2136_ = tonumber(game.PlaceId)
	L_2137_ = game.PlaceId
	L_2139_ = 18687417158
	L_2140_ = 17445763782
	L_2151_ = "rbxassetid://6034281798"
	L_2152_ = 73956553001240
	L_2153_ = "volleyball legends"
	L_2154_ = "volleyball"
	L_2155_ = "volley ball"
	L_2156_ = 130879446158509

	L_2136_ = 0

	L_2137_ = tonumber(game.GameId)
	L_2138_ = game.GameId

	L_2137_ = 0

	pcall(L_1_.callback_41)
	L_2138_ = ""
	L_2139_ = ipairs
	L_2140_ = L_2134_
	L_2139_, L_2140_, L_2141_ = ipairs(L_2134_)

	L_2144_ = L_2143_.placeIds

	L_2144_ = ipairs
	L_2145_ = L_2143_.placeIds
	L_2144_, L_2145_, L_2146_ = ipairs(L_2143_.placeIds)

	L_2149_ = tonumber(L_2148_)
	L_2150_ = L_2148_
	L_2192_ = (L_2136_ == tonumber(L_2148_))

	L_2135_ = L_2143_

	L_2144_ = L_2143_.universeIds

	L_2144_ = ipairs
	L_2145_ = L_2143_.universeIds
	L_2144_, L_2145_, L_2146_ = ipairs(L_2143_.universeIds)

	L_2149_ = tonumber(L_2148_)
	L_2150_ = L_2148_
	L_2192_ = (L_2137_ == tonumber(L_2148_))

	L_2135_ = L_2143_

	L_2191_ = ""
	L_2192_ = (L_2138_ == "")

	L_2139_ = ipairs
	L_2140_ = L_2134_
	L_2139_, L_2140_, L_2141_ = ipairs(L_2134_)

	L_2144_ = L_2143_.name:lower()
	L_2145_ = L_2138_:find(L_2143_.name:lower(), 1, true)
	L_2146_ = L_2138_
	L_2147_ = L_2143_.name:lower()
	L_2148_ = 1
	L_2149_ = true

	L_2135_ = L_2143_

	L_2145_ = L_2143_.aliases

	L_2145_ = ipairs
	L_2146_ = L_2143_.aliases
	L_2145_, L_2146_, L_2147_ = ipairs(L_2143_.aliases)

	L_2150_ = L_2149_:lower()
	L_2151_ = #L_2149_:lower()
	L_2152_ = 3
	L_2192_ = (3 <= #L_2149_:lower())

	L_2151_ = L_2138_:find(L_2150_, 1, true)
	L_2152_ = L_2138_
	L_2153_ = L_2150_
	L_2154_ = 1
	L_2155_ = true

	L_2135_ = L_2143_

	L_2139_ = L_2138_:find("bedwars")
	L_2140_ = L_2138_
	L_2141_ = "bedwars"

	L_2139_ = L_2138_:find("bed wars")
	L_2140_ = L_2138_
	L_2141_ = "bed wars"

	L_2139_ = ipairs
	L_2140_ = L_2134_
	L_2139_, L_2140_, L_2141_ = ipairs(L_2134_)

	L_2144_ = L_2143_.name
	L_2191_ = "BedWars"
	L_2192_ = (L_2143_.name == "BedWars")

	L_2135_ = L_2143_

	L_2139_ = L_2138_:find("bedwars")
	L_2140_ = L_2138_
	L_2141_ = "bedwars"

	L_2139_ = L_2138_:find("bed wars")
	L_2140_ = L_2138_
	L_2141_ = "bed wars"

	L_2139_ = ipairs
	L_2140_ = L_2134_
	L_2139_, L_2140_, L_2141_ = ipairs(L_2134_)

	L_2144_ = L_2143_.name
	L_2191_ = "BedWars"
	L_2192_ = (L_2143_.name == "BedWars")

	L_2135_ = L_2143_

	L_2139_ = L_2138_:find("blox fruit")
	L_2140_ = L_2138_
	L_2141_ = "blox fruit"

	L_2139_ = L_2138_:find("bloxfruit")
	L_2140_ = L_2138_
	L_2141_ = "bloxfruit"

	L_2139_ = ipairs
	L_2140_ = L_2134_
	L_2139_, L_2140_, L_2141_ = ipairs(L_2134_)

	L_2144_ = L_2143_.name
	L_2191_ = "Blox Fruits"
	L_2192_ = (L_2143_.name == "Blox Fruits")

	L_2135_ = L_2143_

	L_2139_ = L_2138_:find("fish it")
	L_2140_ = L_2138_
	L_2141_ = "fish it"

	L_2139_ = L_2138_:find("fisch")
	L_2140_ = L_2138_
	L_2141_ = "fisch"

	L_2139_ = L_2138_:find("fishit")
	L_2140_ = L_2138_
	L_2141_ = "fishit"

	L_2139_ = ipairs
	L_2140_ = L_2134_
	L_2139_, L_2140_, L_2141_ = ipairs(L_2134_)

	L_2144_ = L_2143_.name
	L_2191_ = "Fish It"
	L_2192_ = (L_2143_.name == "Fish It")

	L_2135_ = L_2143_

	L_2139_ = L_2138_:find("steal a brainrot")
	L_2140_ = L_2138_
	L_2141_ = "steal a brainrot"

	L_2139_ = L_2138_:find("sab")
	L_2140_ = L_2138_
	L_2141_ = "sab"

	L_2139_ = ipairs
	L_2140_ = L_2134_
	L_2139_, L_2140_, L_2141_ = ipairs(L_2134_)

	L_2144_ = L_2143_.name
	L_2191_ = "SAB"
	L_2192_ = (L_2143_.name == "SAB")

	L_2135_ = L_2143_

	L_2139_ = L_2138_:find("forsaken")
	L_2140_ = L_2138_
	L_2141_ = "forsaken"

	L_2139_ = ipairs
	L_2140_ = L_2134_
	L_2139_, L_2140_, L_2141_ = ipairs(L_2134_)

	L_2144_ = L_2143_.name
	L_2191_ = "Forsaken"
	L_2192_ = (L_2143_.name == "Forsaken")

	L_2135_ = L_2143_

	L_2139_ = L_2138_:find("volley")
	L_2140_ = L_2138_
	L_2141_ = "volley"

	L_2139_ = ipairs
	L_2140_ = L_2134_
	L_2139_, L_2140_, L_2141_ = ipairs(L_2134_)

	L_2144_ = L_2143_.name
	L_2191_ = "Volley Ball Legends"
	L_2192_ = (L_2143_.name == "Volley Ball Legends")

	L_2135_ = L_2143_

	L_2139_ = L_2138_:find("speed keyboard")
	L_2140_ = L_2138_
	L_2141_ = "speed keyboard"

	L_2139_ = L_2138_:find("keyboard escape")
	L_2140_ = L_2138_
	L_2141_ = "keyboard escape"

	L_2139_ = ipairs
	L_2140_ = L_2134_
	L_2139_, L_2140_, L_2141_ = ipairs(L_2134_)

	L_2144_ = L_2143_.name
	L_2191_ = "Speed Keyboard Escape"
	L_2192_ = (L_2143_.name == "Speed Keyboard Escape")

	L_2135_ = L_2143_

	L_2139_ = L_2138_:find("speed monkey")
	L_2140_ = L_2138_
	L_2141_ = "speed monkey"

	L_2139_ = L_2138_:find("monkey escape")
	L_2140_ = L_2138_
	L_2141_ = "monkey escape"

	L_2139_ = L_2138_:find("monkey")
	L_2140_ = L_2138_
	L_2141_ = "monkey"

	L_2139_ = ipairs
	L_2140_ = L_2134_
	L_2139_, L_2140_, L_2141_ = ipairs(L_2134_)

	L_2144_ = L_2143_.name
	L_2191_ = "Speed Monkey Escape"
	L_2192_ = (L_2143_.name == "Speed Monkey Escape")

	L_2135_ = L_2143_

	L_2139_ = L_2138_:find("anime expedition")
	L_2140_ = L_2138_
	L_2141_ = "anime expedition"

	L_2139_ = L_2138_:find("expedition")
	L_2140_ = L_2138_
	L_2141_ = "expedition"

	L_2139_ = ipairs
	L_2140_ = L_2134_
	L_2139_, L_2140_, L_2141_ = ipairs(L_2134_)

	L_2144_ = L_2143_.name
	L_2191_ = "Anime Expeditions"
	L_2192_ = (L_2143_.name == "Anime Expeditions")

	L_2135_ = L_2143_

	L_2139_ = L_2138_:find("merge a nuke")
	L_2140_ = L_2138_
	L_2141_ = "merge a nuke"

	L_2139_ = L_2138_:find("merge nuke")
	L_2140_ = L_2138_
	L_2141_ = "merge nuke"

	L_2139_ = ipairs
	L_2140_ = L_2134_
	L_2139_, L_2140_, L_2141_ = ipairs(L_2134_)

	L_2144_ = L_2143_.name
	L_2191_ = "Merge a Nuke"
	L_2192_ = (L_2143_.name == "Merge a Nuke")

	L_2135_ = L_2143_

	L_2139_ = L_2138_:find("pickaxe")
	L_2140_ = L_2138_
	L_2141_ = "pickaxe"

	L_2139_ = ipairs
	L_2140_ = L_2134_
	L_2139_, L_2140_, L_2141_ = ipairs(L_2134_)

	L_2144_ = L_2143_.name
	L_2191_ = "+1 Pickaxe Swing Escape"
	L_2192_ = (L_2143_.name == "+1 Pickaxe Swing Escape")

	L_2135_ = L_2143_

	L_2139_ = L_2138_:find("grow a garden")
	L_2140_ = L_2138_
	L_2141_ = "grow a garden"

	L_2139_ = L_2138_:find("gag2")
	L_2140_ = L_2138_
	L_2141_ = "gag2"

	L_2139_ = ipairs
	L_2140_ = L_2134_
	L_2139_, L_2140_, L_2141_ = ipairs(L_2134_)

	L_2144_ = L_2143_.name
	L_2191_ = "Grow a Garden 2"
	L_2192_ = (L_2143_.name == "Grow a Garden 2")

	L_2135_ = L_2143_

	L_2139_ = L_2138_:find("animal hospital")
	L_2140_ = L_2138_
	L_2141_ = "animal hospital"

	L_2139_ = L_2138_:find("hospital")
	L_2140_ = L_2138_
	L_2141_ = "hospital"

	L_2139_ = ipairs
	L_2140_ = L_2134_
	L_2139_, L_2140_, L_2141_ = ipairs(L_2134_)

	L_2144_ = L_2143_.name
	L_2191_ = "Animal Hospital"
	L_2192_ = (L_2143_.name == "Animal Hospital")

	L_2135_ = L_2143_

	L_2139_ = L_2138_:find("prison life")
	L_2140_ = L_2138_
	L_2141_ = "prison life"

	L_2139_ = L_2138_:find("prison")
	L_2140_ = L_2138_
	L_2141_ = "prison"

	L_2139_ = ipairs
	L_2140_ = L_2134_
	L_2139_, L_2140_, L_2141_ = ipairs(L_2134_)

	L_2144_ = L_2143_.name
	L_2191_ = "Prison Life"
	L_2192_ = (L_2143_.name == "Prison Life")

	L_2135_ = L_2143_

	L_2139_ = L_2138_:find("da hood")
	L_2140_ = L_2138_
	L_2141_ = "da hood"

	L_2139_ = L_2138_:find("dahood")
	L_2140_ = L_2138_
	L_2141_ = "dahood"

	L_2139_ = ipairs
	L_2140_ = L_2134_
	L_2139_, L_2140_, L_2141_ = ipairs(L_2134_)

	L_2144_ = L_2143_.name
	L_2191_ = "Da Hood"
	L_2192_ = (L_2143_.name == "Da Hood")

	L_2135_ = L_2143_

	L_2139_ = L_2138_:find("bloxstrike")
	L_2140_ = L_2138_
	L_2141_ = "bloxstrike"

	L_2139_ = L_2138_:find("blox strike")
	L_2140_ = L_2138_
	L_2141_ = "blox strike"

	L_2139_ = ipairs
	L_2140_ = L_2134_
	L_2139_, L_2140_, L_2141_ = ipairs(L_2134_)

	L_2144_ = L_2143_.name
	L_2191_ = "BloxStrike"
	L_2192_ = (L_2143_.name == "BloxStrike")

	L_2135_ = L_2143_

	L_2139_ = L_2138_:find("taxi boss")
	L_2140_ = L_2138_
	L_2141_ = "taxi boss"

	L_2139_ = L_2138_:find("taxiboss")
	L_2140_ = L_2138_
	L_2141_ = "taxiboss"

	L_2139_ = ipairs
	L_2140_ = L_2134_
	L_2139_, L_2140_, L_2141_ = ipairs(L_2134_)

	L_2144_ = L_2143_.name
	L_2191_ = "Taxi Boss"
	L_2192_ = (L_2143_.name == "Taxi Boss")

	L_2135_ = L_2143_

	L_2139_ = L_2138_:find("evade")
	L_2140_ = L_2138_
	L_2141_ = "evade"

	L_2139_ = ipairs
	L_2140_ = L_2134_
	L_2139_, L_2140_, L_2141_ = ipairs(L_2134_)

	L_2144_ = L_2143_.name
	L_2191_ = "Evade"
	L_2192_ = (L_2143_.name == "Evade")

	L_2135_ = L_2143_

	pcall(L_1_.name)
	L_2139_ = pcall
	L_2140_ = L_1_.name

	L_2139_ = {}
	L_2139_.name = "Rivals"
	L_2139_.features = 0
	L_2139_ = {}
	L_2139_.Notify = L_1_.Notify
	L_2147_ = {}
	L_2147_.CreateLib = L_1_.CreateLib
	L_2157_ = {}
	L_2157_.HubName = "Snowy Studios"
	L_2157_.AccentColor = Color3.fromRGB(0, 162, 255)
	L_2159_ = getgenv()
	L_2159_.Window = L_2147_.CreateLib(L_2157_.HubName, "Midnight")
	L_2135_ = L_2139_
	L_2140_ = nil
	L_2141_ = L_1_.callback_45
	L_2142_ = 0
	L_2143_ = nil
	L_2144_ = L_1_.callback_64
	L_2145_ = L_1_.callback_127()
	L_2146_ = L_1_.callback_128
	L_2148_ = game:GetService("Players").LocalPlayer
	L_2149_ = game:GetService("UserInputService")
	L_2150_ = game:GetService("ReplicatedStorage")
	L_2151_ = game:GetService("RunService")
	L_2152_ = workspace.CurrentCamera
	L_2153_ = L_1_.callback_152
	L_2154_ = L_1_.callback_153
	L_2155_ = L_1_.callback_154
	L_2156_ = L_1_.callback_155
	L_2158_ = L_1_.callback_156
	L_2159_ = getgenv().Window
	L_2160_ = getgenv()
	L_2161_ = L_2157_.HubName
	L_2162_ = "Midnight"

	L_2161_ = L_2135_.name

	L_2161_ = "Unknown"

	L_2162_ = {}
	L_2162_.nonce = L_2160_.__SnowyLaunchNonce
	L_2162_.game = L_2161_
	L_2162_.ui = true
	L_2162_.at = os.clock()
	L_2160_.__SnowyPayloadReady = L_2162_
	print("[SnowyHub] Payload UI ready: " .. tostring(L_2161_))
	L_2160_ = getgenv()
	L_2160_.SnowyLib = L_2139_
	L_2160_ = getgenv()
	L_2160_.Kavo = L_2147_
	L_2160_ = getgenv()
	L_2160_.notify = L_2158_
	task.defer(L_1_.gameTab)
	L_2162_ = getgenv()
	L_2162_.gameTab = L_1_.gameTab_183
	L_2160_ = {}
	L_2161_ = L_1_.gameTab_183
	L_2162_ = L_1_.callback_227
	L_2163_ = "[SnowyHub] Payload UI ready: " .. tostring(L_2161_)
	L_2164_ = "[SnowyHub] Payload UI ready: "
	L_2165_ = tostring(L_2161_)
	L_2166_ = L_2161_

	L_2163_ = getgenv()
	L_2163_.HomeTab = L_2159_:NewTab("Home")
	L_2163_ = getgenv()
	L_2163_.PlayerTab = L_2159_:NewTab("Player")
	L_2163_ = getgenv()
	L_2163_.VisualTab = L_2159_:NewTab("Visuals")
	L_2163_ = getgenv()
	L_2163_.UtilTab = L_2159_:NewTab("Utility")
	L_2163_ = getgenv()
	L_2163_.AimbotTab = L_2159_:NewTab("Aimbot")
	L_2163_ = getgenv()
	L_2163_.SettingsTab = L_2159_:NewTab("Settings")
	L_2163_ = getgenv()
	L_2163_.HomeSec = HomeTab:NewSection("Status")
	HomeSec:NewLabel(utf8.char(10052) .. " SNOWY HUB v6.0")
	L_2163_ = getgenv()
	L_2163_.PlayerSection = PlayerTab:NewSection("General")
	L_2163_ = getgenv()
	L_2163_.VisualSection = VisualTab:NewSection("ESP & Effects")
	L_2163_ = getgenv()
	L_2163_.UtilSection = UtilTab:NewSection("General Tools")
	L_2163_ = getgenv()
	L_2163_.AimbotSection = AimbotTab:NewSection("Combat Settings")
	L_2163_ = getgenv()
	L_2163_.UISec = SettingsTab:NewSection("Interface")
	L_2163_ = getgenv()
	L_2163_.InfoSec = SettingsTab:NewSection("Info")
	L_2163_ = getgenv()
	L_2163_.WalkSpeedValue = 16
	L_2163_ = getgenv()
	L_2163_.JumpPowerValue = 50
	L_2163_ = getgenv()
	L_2163_.GodModeEnabled = false
	L_2163_ = getgenv().PlayerModifierLoop
	L_2164_ = getgenv()
	L_2165_ = SettingsTab
	L_2166_ = "Info"
	L_2167_ = " SNOWY HUB v6.0"
	L_2168_ = utf8.char(10052)
	L_2169_ = 10052

	pcall(L_1_.PlayerModifierLoop)
	L_2163_ = getgenv()
	L_2163_.PlayerModifierLoop = nil
	L_2164_ = nil

	L_2164_ = game:GetService("RunService").RenderStepped
	L_2163_ = getgenv()
	L_2163_.PlayerModifierLoop = L_2164_:Connect(L_1_.callback_231)
	PlayerSection:NewSlider("WalkSpeed", "Changes player speed", 250, 16, L_1_.callback_232)
	PlayerSection:NewSlider("JumpPower", "Changes jump height", 250, 50, L_1_.callback_233)
	PlayerSection:NewSlider("Gravity", "Changes world gravity", 196, 0, L_1_.callback_234)
	PlayerSection:NewPremiumToggle("God Mode", "Instantly regenerates health", L_1_.callback_236)
	noclip = L_1_.enableNoclip
	clip = L_1_.disableNoclip
	PlayerSection:NewPremiumToggle("Noclip", "Walk through objects and walls", L_1_.callback_240)
	PlayerSection:NewPremiumToggle("Infinite Jump", "Jump in mid-air", L_1_.callback_242)
	VisualSection:NewSlider("Field of View", "Change camera FOV", 120, 70, L_1_.callback_243)
	VisualSection:NewToggle("Fullbright", "Removes shadows and darkness", L_1_.callback_244)
	VisualSection:NewPremiumToggle("Player ESP", "Highlights all players through walls", L_1_.callback_245)
	VisualSection:NewPremiumSlider("Hitbox Expander", "Make enemies easier to hit", 20, 2, L_1_.callback_248)
	UtilSection:NewButton("Give Btools", "Gives building tools to inventory", L_1_.callback_249)
	UtilSection:NewPremiumButton("Teleport to Random Player", "TPs you to a random user", L_1_.callback_250)
	UtilSection:NewButton("Rejoin Server", "Rejoins the same server", L_1_.callback_251)
	UtilSection:NewPremiumButton("Server Hop", "Joins a random new server", L_1_.callback_253)
	UtilSection:NewToggle("Anti-AFK", "Prevents Roblox disconnects", L_1_.callback_254)
	L_2167_ = {}
	L_2167_.Enabled = false
	L_2167_.ShowFOV = false
	L_2167_.FOVRadius = 80
	L_2167_.Smoothness = 0.5
	L_2167_.TeamCheck = true
	L_2167_.TargetPart = "Head"
	L_2168_ = Drawing.new("Circle")
	L_2168_.Position = Vector2.new((game.Workspace.CurrentCamera.ViewportSize.X / 2), (game.Workspace.CurrentCamera.ViewportSize.Y / 2))
	L_2168_.Radius = L_2167_.FOVRadius
	L_2168_.Filled = false
	L_2168_.Color = Color3.fromRGB(255, 255, 255)
	L_2168_.Visible = false
	L_2168_.Thickness = 1
	L_2170_ = game:GetService("RunService").RenderStepped
	L_2170_:Connect(L_1_.callback_256)
	AimbotSection:NewPremiumToggle("Enable Aimbot (Right Click)", "Locks onto targets in FOV", L_1_.callback_257)
	AimbotSection:NewToggle("Show FOV Circle", "Displays the aimbot radius", L_1_.callback_258)
	AimbotSection:NewSlider("FOV Size", "Target area size", 300, 20, L_1_.callback_259)
	AimbotSection:NewPremiumSlider("Aimbot Smoothness", "100=Instant, 1=Slow", 100, 1, L_1_.callback_260)
	AimbotSection:NewToggle("Team Check", "Ignores teammates", L_1_.callback_261)
	UISec:NewButton("Test Notification", "Test the notification system", L_1_.callback_262)
	UISec:NewButton("Test Premium Alert", "Premium-style notification", L_1_.callback_263)
	UISec:NewSlider("UI Opacity", "Adjust hub transparency", 8, 0, L_1_.callback_265)
	InfoSec:NewLabel("Right-click = Hold to aim (Aimbot)")
	InfoSec:NewLabel("Drag title bar to move")
	InfoSec:NewLabel("discord.gg/getsnowy")
	InfoSec:NewButton("Copy Discord", "Copy invite link", L_1_.callback_266)
	ScriptSec:NewButton("Reload Hub", "Destroys and reloads the UI", L_1_.callback_269)
	ScriptSec:NewLabel("SNOWY HUB v6.0 | Built by Snowy Studios")
	ScriptSec:NewLabel(tostring(#L_2134_) .. " Games Supported")

	L_2163_ = nil
	L_2164_ = nil
	L_2165_ = false
	L_2166_ = {}
	L_2169_ = L_1_.callback_255
	L_2170_ = 0
	L_2171_ = ScriptSec.NewLabel
	L_2172_ = ScriptSec
	L_2173_ = tostring(#L_2134_) .. " Games Supported"
	L_2174_ = tostring(#L_2134_)
	L_2175_ = " Games Supported"
	L_2176_ = tostring(#L_2134_)
	L_2177_ = #L_2134_

	L_2164_ = getgenv()
	L_2164_.HomeTab = L_1_.callback_273()
	L_2164_ = getgenv()
	L_2164_.PlayerTab = L_1_.callback_273()
	L_2164_ = getgenv()
	L_2164_.VisualTab = L_1_.callback_273()
	L_2164_ = getgenv()
	L_2164_.UtilTab = L_1_.callback_273()
	L_2164_ = getgenv()
	L_2164_.AimbotTab = L_1_.callback_273()
	L_2164_ = getgenv()
	L_2164_.SettingsTab = L_1_.callback_273()
	L_2165_ = getgenv()
	L_2165_.HomeSec = HomeTab:NewSection()
	L_2165_ = getgenv()
	L_2165_.PlayerSection = HomeTab:NewSection()
	L_2165_ = getgenv()
	L_2165_.VisualSection = HomeTab:NewSection()
	L_2165_ = getgenv()
	L_2165_.UtilSection = HomeTab:NewSection()
	L_2165_ = getgenv()
	L_2165_.AimbotSection = HomeTab:NewSection()
	L_2165_ = getgenv()
	L_2165_.UISec = HomeTab:NewSection()
	L_2165_ = getgenv()
	L_2165_.InfoSec = HomeTab:NewSection()
	L_2165_ = getgenv()
	L_2165_.ScriptSec = HomeTab:NewSection()
	L_2163_ = L_1_.callback_273
	L_2164_ = HomeTab:NewSection()

	L_2163_ = L_2135_.name
	L_2191_ = "Rivals"
	L_2192_ = (L_2135_.name == "Rivals")

	L_2163_ = L_2161_("Rivals", "Rivals Master Combat Hub")
	L_2180_ = {}
	L_2180_.Aimbot = false
	L_2180_.SilentAim = false
	L_2180_.SilentWallbang = false
	L_2180_.Ragebot = false
	L_2180_.FOVRadius = 180
	L_2180_.ShowFOV = false
	L_2180_.AimPart = "Head"
	L_2180_.Smoothness = 5
	L_2180_.RequireRMB = false
	L_2180_.VisibleOnly = true
	L_2180_.TeamCheck = true
	L_2180_.NoRecoil = false
	L_2180_.NoSpread = false
	L_2180_.HitboxExpander = false
	L_2180_.HitboxSize = 6
	L_2180_.HitboxTransparency = 0.5
	L_2180_.ESPEnabled = false
	L_2180_.ESPBoxType = "2D Corner"
	L_2180_.ESPName = true
	L_2180_.ESPHealth = true
	L_2180_.ESPDistance = true
	L_2180_.ESPWeapon = true
	L_2180_.ESPTracer = false
	L_2180_.CFrameSpeed = false
	L_2180_.SpeedValue = 24
	L_2180_.CFrameFly = false
	L_2180_.FlySpeed = 50
	L_2180_.Noclip = false
	L_2180_.InfJump = false
	L_2180_.StealthMode = false
	L_2180_.PauseOnDamage = true
	L_2180_.AutoRequeue = false
	L_2179_ = getgenv()
	L_2179_.RivFlags = L_2180_
	L_2184_ = game:GetService("RunService").RenderStepped
	L_2184_:Connect(L_1_.callback_283)
	L_2184_ = game:GetService("RunService").RenderStepped
	L_2184_:Connect(L_1_.callback_285)
	L_2184_ = game:GetService("RunService").Heartbeat
	L_2184_:Connect(L_1_.callback_287)
	L_2184_ = game:GetService("RunService").Stepped
	L_2184_:Connect(L_1_.callback_289)
	L_2184_ = game:GetService("UserInputService").JumpRequest
	L_2184_:Connect(L_1_.callback_290)
	L_2164_ = L_2163_:NewSection("Combat & Aimbot Engine")
	L_2164_:NewToggle("Enable Legit Aimbot", "Smooth camera target lock", L_1_.callback_291)
	L_2164_:NewPremiumToggle("Enable Silent Aim", "Bullet magnetism to target", L_1_.callback_292)
	L_2164_:NewPremiumToggle("Silent Wallbang", "Penetrates walls and obstacles", L_1_.callback_293)
	L_2164_:NewPremiumToggle("Enable Ragebot", "Auto fires at all targets in range", L_1_.callback_294)
	L_2164_:NewSlider("FOV Radius", "Lock-on target circle radius", 500, 40, L_1_.callback_295)
	L_2164_:NewSlider("Aimbot Smoothness", "Higher = smoother human aim", 20, 1, L_1_.callback_296)
	L_2187_ = {}
	L_2187_[1] = "Head"
	L_2187_[2] = "HumanoidRootPart"
	L_2187_[3] = "Torso"
	L_2164_:NewDropdown("Aim Target Part", L_2187_, "Head", L_1_.callback_297)
	L_2164_:NewToggle("Require Right-Click (RMB)", "Aim only while holding RMB", L_1_.callback_298)
	L_2164_:NewToggle("Visible Only (Wall Check)", "Ignores enemies behind walls", L_1_.callback_299)
	L_2164_:NewToggle("Team Check", "Ignores teammates", L_1_.callback_300)
	L_2165_ = L_2163_:NewSection("Weapon Mods & Hitbox Expander")
	L_2165_:NewPremiumToggle("Hitbox Expander", "Enlarges enemy head hitboxes", L_1_.callback_301)
	L_2165_:NewPremiumSlider("Hitbox Size", "Target head box scale", 25, 1, L_1_.callback_302)
	L_2165_:NewPremiumToggle("No Recoil", "Removes 100% of weapon recoil", L_1_.callback_303)
	L_2165_:NewPremiumToggle("No Spread", "Removes 100% of bullet spread", L_1_.callback_304)
	L_2166_ = L_2163_:NewSection("ESP & Wallhack Engine")
	L_2166_:NewToggle("Enable Player ESP", "Highlights players through walls", L_1_.callback_305)
	L_2187_ = {}
	L_2187_[1] = "2D Corner"
	L_2187_[2] = "2D Bounding Box"
	L_2187_[3] = "3D Box"
	L_2166_:NewDropdown("ESP Box Type", L_2187_, "2D Corner", L_1_.callback_306)
	L_2166_:NewToggle("Show Names", "Displays player names", L_1_.callback_307)
	L_2166_:NewToggle("Show Health Bars", "Displays player health", L_1_.callback_308)
	L_2166_:NewToggle("Show Distance", "Displays stud distance", L_1_.callback_309)
	L_2166_:NewToggle("Show Equipped Weapon", "Displays enemy held weapon", L_1_.callback_310)
	L_2166_:NewToggle("Show Tracers", "Draws line from screen to player", L_1_.callback_311)
	L_2167_ = L_2163_:NewSection("Movement & Teleports")
	L_2167_:NewPremiumToggle("Enable CFrame Speed", "Anti-cheat bypass speed hack", L_1_.callback_312)
	L_2167_:NewPremiumSlider("Speed Value", "Movement rate speed", 100, 16, L_1_.callback_313)
	L_2167_:NewPremiumToggle("Enable CFrame Fly", "Smooth flying mode (W,A,S,D)", L_1_.callback_314)
	L_2167_:NewPremiumToggle("Noclip (Walk Through Walls)", "Disables part collisions", L_1_.callback_315)
	L_2167_:NewToggle("Infinite Air Jump", "Jump repeatedly in mid-air", L_1_.callback_316)
	L_2167_:NewButton("Teleport Behind Nearest Enemy", "Instant stealth flank", L_1_.callback_317)
	L_2168_ = L_2163_:NewSection("Stealth & Safety")
	L_2168_:NewToggle("Stealth Mode", "Doubles delays & humanizes movements", L_1_.callback_318)
	L_2168_:NewToggle("Pause on Damage", "Auto-disables features 3s on heavy hit", L_1_.callback_319)
	L_2169_ = L_2163_:NewSection("Utilities & Server Hop")
	L_2169_:NewPremiumToggle("Auto Requeue / Server Hop", "Automatically hops server on match finish", L_1_.callback_320)
	L_2169_:NewButton("Server Hop Now", "Joins a new random Rivals match", L_1_.callback_322)
	L_2163_:NewLabel("Snowy Studios Rivals Master Combat Hub v2.0")
	L_2170_ = game:GetService("Players")
	L_2171_ = game:GetService("Players").LocalPlayer
	L_2172_ = game:GetService("Workspace")
	L_2173_ = game:GetService("RunService")
	L_2174_ = game:GetService("ReplicatedStorage")
	L_2175_ = game:GetService("UserInputService")
	L_2176_ = game:GetService("TweenService")
	L_2177_ = game:GetService("TeleportService")
	L_2178_ = L_1_.callback_275
	L_2179_ = L_1_.callback_276
	L_2180_ = L_1_.callback_277
	L_2181_ = L_1_.callback_278
	L_2182_ = L_1_.callback_280
	L_2183_ = L_1_.callback_281
	L_2184_ = L_2163_.NewLabel
	L_2185_ = L_2163_
	L_2186_ = "Snowy Studios Rivals Master Combat Hub v2.0"
	L_2187_ = "Joins a new random Rivals match"
	L_2188_ = L_1_.callback_322
	L_2189_ = 16
	L_2190_ = L_1_.callback_313

	do
		return
	end
end

return L_1_.main(...)
